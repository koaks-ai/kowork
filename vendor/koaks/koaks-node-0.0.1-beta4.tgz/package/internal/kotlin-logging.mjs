import {
  Unit_instance104q5opgivhr8 as Unit_instance,
  VOID7hggqo3abtya as VOID,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  Enum3alwj03lh1n41 as Enum,
  toString30pk9tzaqopn as toString,
  Exceptiondt2hlxn7j7vw as Exception,
  equals2au1ep9vhcato as equals,
  StringBuildermazzzhj6kkai as StringBuilder,
  createThis2j2avj17cvnv2 as createThis,
  hashCodeq5arwsb9dgti as hashCode,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  protoOf180f3jzyo7rfj as protoOf,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  stackTraceToString2670q6lbhdojj as stackTraceToString,
  split2bvyvnrlcifjv as split,
  substringBeforekje8w2lxhyb6 as substringBefore,
  substringAfterLastuw9v7gfiiihe as substringAfterLast,
  contains3ue2qo8xhmpf1 as contains,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class KLogger {}
function debug(message) {
  var tmp = Level_DEBUG_getInstance();
  return this.a5l(tmp, VOID, KLogger$debug$lambda(message));
}
function info(message) {
  var tmp = Level_INFO_getInstance();
  return this.a5l(tmp, VOID, KLogger$info$lambda(message));
}
function warn(message) {
  var tmp = Level_WARN_getInstance();
  return this.a5l(tmp, VOID, KLogger$warn$lambda(message));
}
function error(message) {
  var tmp = Level_ERROR_getInstance();
  return this.a5l(tmp, VOID, KLogger$error$lambda(message));
}
function error_0(throwable, message) {
  var tmp = Level_ERROR_getInstance();
  return this.a5l(tmp, VOID, KLogger$error$lambda_0(message, throwable));
}
function at$default(level, marker, block, $super) {
  marker = marker === VOID ? null : marker;
  var tmp;
  if ($super === VOID) {
    this.f5l(level, marker, block);
    tmp = Unit_instance;
  } else {
    tmp = $super.f5l.call(this, level, marker, block);
  }
  return tmp;
}
class KLoggingEventBuilder {
  constructor() {
    this.u5k_1 = null;
    this.v5k_1 = null;
    this.w5k_1 = null;
    this.x5k_1 = null;
    this.y5k_1 = null;
  }
}
class KotlinLogging {
  g5l(func) {
    return this.i5l(KLoggerNameResolver_instance.h5l(func));
  }
  i5l(name) {
    return KLoggerFactory_instance.i5l(name);
  }
}
class Level extends Enum {
  constructor(name, ordinal, levelInt, levelStr) {
    super(name, ordinal);
    this.l5l_1 = levelInt;
    this.m5l_1 = levelStr;
  }
  toString() {
    return this.m5l_1;
  }
}
class DefaultErrorMessageProducer {
  n5l(e) {
    return 'Log message invocation failed: ' + e.toString();
  }
}
class FormattingAppender {
  p5l(loggingEvent) {
    // Inline function 'kotlin.let' call
    var it = KotlinLoggingConfiguration_getInstance().r5l_1.t5l(loggingEvent);
    this.o5l(loggingEvent, it);
  }
}
class DefaultMessageFormatter {
  constructor(includePrefix) {
    includePrefix = includePrefix === VOID ? true : includePrefix;
    this.u5l_1 = includePrefix;
  }
  t5l(loggingEvent) {
    // Inline function 'kotlin.with' call
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb(prefix(this, loggingEvent.v5l_1, loggingEvent.x5l_1));
    var tmp0_safe_receiver = loggingEvent.w5l_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.b5m();
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this_0.tb(tmp1_safe_receiver);
      this_0.tb(' ');
    }
    this_0.tb(loggingEvent.y5l_1);
    this_0.tb(throwableToString(this, loggingEvent.z5l_1));
    return this_0.toString();
  }
}
class KLoggingEvent {
  static c5m(level, marker, loggerName, message, cause, payload) {
    message = message === VOID ? null : message;
    cause = cause === VOID ? null : cause;
    payload = payload === VOID ? null : payload;
    var $this = createThis(this);
    $this.v5l_1 = level;
    $this.w5l_1 = marker;
    $this.x5l_1 = loggerName;
    $this.y5l_1 = message;
    $this.z5l_1 = cause;
    $this.a5m_1 = payload;
    return $this;
  }
  static d5m(level, marker, loggerName, eventBuilder) {
    return this.c5m(level, marker, loggerName, eventBuilder.u5k_1, eventBuilder.v5k_1, eventBuilder.w5k_1);
  }
  toString() {
    return 'KLoggingEvent(level=' + this.v5l_1.toString() + ', marker=' + toString(this.w5l_1) + ', loggerName=' + this.x5l_1 + ', message=' + this.y5l_1 + ', cause=' + toString(this.z5l_1) + ', payload=' + toString(this.a5m_1) + ')';
  }
  hashCode() {
    var result = this.v5l_1.hashCode();
    result = imul(result, 31) + (this.w5l_1 == null ? 0 : hashCode(this.w5l_1)) | 0;
    result = imul(result, 31) + getStringHashCode(this.x5l_1) | 0;
    result = imul(result, 31) + (this.y5l_1 == null ? 0 : getStringHashCode(this.y5l_1)) | 0;
    result = imul(result, 31) + (this.z5l_1 == null ? 0 : hashCode(this.z5l_1)) | 0;
    result = imul(result, 31) + (this.a5m_1 == null ? 0 : hashCode(this.a5m_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof KLoggingEvent))
      return false;
    var tmp0_other_with_cast = other instanceof KLoggingEvent ? other : THROW_CCE();
    if (!this.v5l_1.equals(tmp0_other_with_cast.v5l_1))
      return false;
    if (!equals(this.w5l_1, tmp0_other_with_cast.w5l_1))
      return false;
    if (!(this.x5l_1 === tmp0_other_with_cast.x5l_1))
      return false;
    if (!(this.y5l_1 == tmp0_other_with_cast.y5l_1))
      return false;
    if (!equals(this.z5l_1, tmp0_other_with_cast.z5l_1))
      return false;
    if (!equals(this.a5m_1, tmp0_other_with_cast.a5m_1))
      return false;
    return true;
  }
}
class KLoggerDirect {
  constructor(name) {
    this.e5m_1 = name;
  }
  f5l(level, marker, block) {
    if (this.f5m(level, marker)) {
      // Inline function 'kotlin.apply' call
      var this_0 = new KLoggingEventBuilder();
      block(this_0);
      // Inline function 'kotlin.run' call
      if (level.o3_1 !== 5) {
        KotlinLoggingConfiguration_getInstance().s5l_1.p5l(KLoggingEvent.d5m(level, marker, this.e5m_1, this_0));
      }
    }
  }
  f5m(level, marker) {
    return isLoggingEnabled(level);
  }
}
class KLoggerFactory {
  i5l(name) {
    return new KLoggerDirect(name);
  }
}
class ConsoleOutputAppender extends FormattingAppender {
  o5l(loggingEvent, formattedMessage) {
    switch (loggingEvent.v5l_1.o3_1) {
      case 0:
        console.log(formattedMessage);
        break;
      case 1:
        console.log(formattedMessage);
        break;
      case 2:
        console.info(formattedMessage);
        break;
      case 3:
        console.warn(formattedMessage);
        break;
      case 4:
        console.error(formattedMessage);
        break;
      case 5:
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
  }
}
class KotlinLoggingConfiguration {
  constructor() {
    KotlinLoggingConfiguration_instance = this;
    this.q5l_1 = Level_INFO_getInstance();
    this.r5l_1 = new DefaultMessageFormatter(true);
    this.s5l_1 = new ConsoleOutputAppender();
  }
}
class KLoggerNameResolver {
  h5l(func) {
    var found = false;
    var exception = Exception.wd();
    var _iterator__ex2g4s = split(stackTraceToString(exception), ['\n']).y();
    while (_iterator__ex2g4s.z()) {
      var line = _iterator__ex2g4s.a1();
      if (found) {
        return substringAfterLast(substringAfterLast(substringBefore(line, '.kt'), '.'), '/');
      }
      if (contains(line, 'at KotlinLogging')) {
        found = true;
      }
    }
    return '';
  }
}
//endregion
function KLogger$debug$lambda($message) {
  return ($this$at) => {
    $this$at.u5k_1 = toStringSafe($message);
    return Unit_instance;
  };
}
function KLogger$info$lambda($message) {
  return ($this$at) => {
    $this$at.u5k_1 = toStringSafe($message);
    return Unit_instance;
  };
}
function KLogger$warn$lambda($message) {
  return ($this$at) => {
    $this$at.u5k_1 = toStringSafe($message);
    return Unit_instance;
  };
}
function KLogger$error$lambda($message) {
  return ($this$at) => {
    $this$at.u5k_1 = toStringSafe($message);
    return Unit_instance;
  };
}
function KLogger$error$lambda_0($message, $throwable) {
  return ($this$at) => {
    $this$at.u5k_1 = toStringSafe($message);
    $this$at.v5k_1 = $throwable;
    return Unit_instance;
  };
}
var KotlinLogging_instance;
function KotlinLogging_getInstance() {
  return KotlinLogging_instance;
}
var Level_TRACE_instance;
var Level_DEBUG_instance;
var Level_INFO_instance;
var Level_WARN_instance;
var Level_ERROR_instance;
var Level_OFF_instance;
var Level_entriesInitialized;
function Level_initEntries() {
  if (Level_entriesInitialized)
    return Unit_instance;
  Level_entriesInitialized = true;
  Level_TRACE_instance = new Level('TRACE', 0, 0, 'TRACE');
  Level_DEBUG_instance = new Level('DEBUG', 1, 10, 'DEBUG');
  Level_INFO_instance = new Level('INFO', 2, 20, 'INFO');
  Level_WARN_instance = new Level('WARN', 3, 30, 'WARN');
  Level_ERROR_instance = new Level('ERROR', 4, 40, 'ERROR');
  Level_OFF_instance = new Level('OFF', 5, 50, 'OFF');
}
function Level_DEBUG_getInstance() {
  Level_initEntries();
  return Level_DEBUG_instance;
}
function Level_INFO_getInstance() {
  Level_initEntries();
  return Level_INFO_instance;
}
function Level_WARN_getInstance() {
  Level_initEntries();
  return Level_WARN_instance;
}
function Level_ERROR_getInstance() {
  Level_initEntries();
  return Level_ERROR_instance;
}
function toStringSafe(_this__u8e3s4) {
  var tmp;
  try {
    tmp = toString(_this__u8e3s4());
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Exception) {
      var e = $p;
      tmp_0 = DefaultErrorMessageProducer_instance.n5l(e);
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
}
var DefaultErrorMessageProducer_instance;
function DefaultErrorMessageProducer_getInstance() {
  return DefaultErrorMessageProducer_instance;
}
function prefix($this, level, loggerName) {
  var tmp;
  if ($this.u5l_1) {
    tmp = level.n3_1 + ': [' + loggerName + '] ';
  } else {
    tmp = '';
  }
  return tmp;
}
function throwableToString($this, _this__u8e3s4) {
  return createThrowableMsg($this, '', _this__u8e3s4);
}
function createThrowableMsg($this, msg, throwable) {
  var $this_0 = $this;
  var msg_0 = msg;
  var throwable_0 = throwable;
  $l$1: do {
    $l$0: do {
      var tmp;
      if (throwable_0 == null || equals(throwable_0.cause, throwable_0)) {
        tmp = msg_0;
      } else {
        var tmp0 = $this_0;
        var tmp1 = msg_0 + ", Caused by: '" + throwable_0.message + "'";
        var tmp2 = throwable_0.cause;
        $this_0 = tmp0;
        msg_0 = tmp1;
        throwable_0 = tmp2;
        continue $l$0;
      }
      return tmp;
    }
     while (false);
  }
   while (true);
}
function isLoggingEnabled(_this__u8e3s4) {
  return _this__u8e3s4.o3_1 >= KotlinLoggingConfiguration_getInstance().q5l_1.o3_1;
}
var KLoggerFactory_instance;
function KLoggerFactory_getInstance() {
  return KLoggerFactory_instance;
}
var KotlinLoggingConfiguration_instance;
function KotlinLoggingConfiguration_getInstance() {
  if (KotlinLoggingConfiguration_instance === VOID)
    new KotlinLoggingConfiguration();
  return KotlinLoggingConfiguration_instance;
}
var KLoggerNameResolver_instance;
function KLoggerNameResolver_getInstance() {
  return KLoggerNameResolver_instance;
}
//region block: post-declaration
initMetadataForInterface(KLogger, 'KLogger');
initMetadataForClass(KLoggingEventBuilder, 'KLoggingEventBuilder', KLoggingEventBuilder);
initMetadataForObject(KotlinLogging, 'KotlinLogging');
initMetadataForClass(Level, 'Level');
initMetadataForObject(DefaultErrorMessageProducer, 'DefaultErrorMessageProducer');
initMetadataForClass(FormattingAppender, 'FormattingAppender');
initMetadataForClass(DefaultMessageFormatter, 'DefaultMessageFormatter', DefaultMessageFormatter);
initMetadataForClass(KLoggingEvent, 'KLoggingEvent');
protoOf(KLoggerDirect).a5l = at$default;
protoOf(KLoggerDirect).z5k = debug;
protoOf(KLoggerDirect).b5l = info;
protoOf(KLoggerDirect).c5l = warn;
protoOf(KLoggerDirect).d5l = error;
protoOf(KLoggerDirect).e5l = error_0;
initMetadataForClass(KLoggerDirect, 'KLoggerDirect', VOID, VOID, [KLogger]);
initMetadataForObject(KLoggerFactory, 'KLoggerFactory');
initMetadataForClass(ConsoleOutputAppender, 'ConsoleOutputAppender', ConsoleOutputAppender);
initMetadataForObject(KotlinLoggingConfiguration, 'KotlinLoggingConfiguration');
initMetadataForObject(KLoggerNameResolver, 'KLoggerNameResolver');
//endregion
//region block: init
KotlinLogging_instance = new KotlinLogging();
DefaultErrorMessageProducer_instance = new DefaultErrorMessageProducer();
KLoggerFactory_instance = new KLoggerFactory();
KLoggerNameResolver_instance = new KLoggerNameResolver();
//endregion
//region block: exports
export {
  KotlinLogging_instance as KotlinLogging_instance20u19uwz7rzsk,
};
//endregion

//# sourceMappingURL=kotlin-logging.mjs.map
