import {
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  VOID7hggqo3abtya as VOID,
  StringCompanionObject_instance2odz3s3zbrixa as StringCompanionObject_instance,
  Unit_instance104q5opgivhr8 as Unit_instance,
  emptyList1g2z5xcrvp2zy as emptyList,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  toString1pkumu07cwy4m as toString,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  zip2suipyqmdw72q as zip,
  toMap1vec9topfei08 as toMap,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  asList2ho2pewtsfvv as asList,
  KtMap140uvy3s5zad8 as KtMap,
  isInterface3d6p8outrmvmk as isInterface,
  captureStack1fzi4aczwc4hg as captureStack,
  listOfvhqybd2zx248 as listOf,
  ArrayList3it5z8td81qkl as ArrayList,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  KClass1cc9rfeybg8hs as KClass,
  Triple1vhi3d0dgpnjb as Triple,
  getKClass1s3j9wy1cofik as getKClass,
  Paire9pteg33gng7 as Pair,
  Entry2xmjmyutzoq3p as Entry,
  KtMutableMap1kqeifoi36kpz as KtMutableMap,
  HashMap1a0ld5kgwhmhv as HashMap,
  KtSetjrjc7fhfd6b9 as KtSet,
  KtMutableSetwuwn7k5m570a as KtMutableSet,
  LinkedHashSet2tkztfx86kyx2 as LinkedHashSet,
  HashSet2dzve9y63nf0v as HashSet,
  Collection1k04j3hzsbod0 as Collection,
  KtList3hktaavzmj137 as KtList,
  KtMutableList1beimitadwkna as KtMutableList,
  copyToArray2j022khrow2yi as copyToArray,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  _Result___get_isFailure__impl__jpirivzehaw445b0cy as _Result___get_isFailure__impl__jpiriv,
  Result3t1vadv16kmzk as Result,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  equals2au1ep9vhcato as equals,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  isBlank1dvkhjjvox3p0 as isBlank,
  toList383f556t1dixk as toList,
  toHashSet1qrcsl3g8ugc8 as toHashSet,
  toBooleanArray2u3qw7fjwsmuh as toBooleanArray,
  withIndex3s8q7w1g0hyfn as withIndex,
  to2cs3ny02qtbcb as to,
  lazy2hsh8ze7j6ikd as lazy_0,
  contentEqualsaf55p28mnw74 as contentEquals,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  Long2qws0ah9gnpki as Long,
  Char19o2r8palgjof as Char,
  createThis2j2avj17cvnv2 as createThis,
  Duration__toIsoString_impl_9h6wsm33t9fmb34wprd as Duration__toIsoString_impl_9h6wsm,
  Duration5ynfiptaqcrg as Duration,
  Companion_getInstance2b73c6hwbaiuw as Companion_getInstance,
  Uuid1zxgztb7abqxx as Uuid,
  Companion_getInstance3tnw2k4njrdpv as Companion_getInstance_0,
  toIntOrNull3w2d066r9pvwm as toIntOrNull,
  hashCodeq5arwsb9dgti as hashCode,
  isArray1hxjqtqy632bc as isArray,
  arrayIterator3lgwvgteckzhv as arrayIterator,
  until1jbpn0z3f8lbg as until,
  step18s9qzr5xwxat as step,
  getValue48kllevslyh6 as getValue,
  longArray288a0fctlmjmj as longArray,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  get_lastIndex1y2f6o9u8hnf7 as get_lastIndex,
  countTrailingZeroBits1k55x07cygoff as countTrailingZeroBits,
  indexOf3ic8eacwbbrog as indexOf,
  contentToString3ujacv8hqfipd as contentToString,
  Enum3alwj03lh1n41 as Enum,
  joinToString1cxrrlmo0chqs as joinToString,
  toString30pk9tzaqopn as toString_0,
  KTypeParameter1s8efufd4mbj5 as KTypeParameter,
  contentHashCode2i020q5tbeh2s as contentHashCode,
  booleanArray2jdug9b51huk7 as booleanArray,
  emptyMapr06gerzljqtm as emptyMap,
  Companion_getInstance2g172z58li19e as Companion_getInstance_1,
  isCharArray21auq5hbrg68m as isCharArray,
  charArray2ujmm1qusno00 as charArray,
  DoubleCompanionObject_instance2yqrcskeqd1tm as DoubleCompanionObject_instance,
  isDoubleArray1wyh4nyf7pjxn as isDoubleArray,
  FloatCompanionObject_instance29smzmmxq0czz as FloatCompanionObject_instance,
  isFloatArrayjjscnqphw92j as isFloatArray,
  Companion_getInstance1pxg306pnafvz as Companion_getInstance_2,
  isLongArray2fdt3z7yu3ef as isLongArray,
  Companion_getInstance1poxudqc1ru3p as Companion_getInstance_3,
  _ULongArray___get_size__impl__ju6dtr1b48sgq5mqufi as _ULongArray___get_size__impl__ju6dtr,
  ULongArray3nd0d80mdwjj8 as ULongArray,
  _ULongArray___init__impl__twm1l3w35zjgwc40e6 as _ULongArray___init__impl__twm1l3,
  _ULong___init__impl__c78o9k2uqxdjm6b0lbg as _ULong___init__impl__c78o9k,
  ULongArray__get_impl_pr71q927jt2k7w7gjei as ULongArray__get_impl_pr71q9,
  _ULong___get_data__impl__fggpzb1jl4xe0gulani as _ULong___get_data__impl__fggpzb,
  IntCompanionObject_instance2nvyd29rdzxbs as IntCompanionObject_instance,
  isIntArrayeijsubfngq38 as isIntArray,
  Companion_getInstance1z323tr26bmxd as Companion_getInstance_4,
  _UIntArray___get_size__impl__r6l8ci9njro21awxk9 as _UIntArray___get_size__impl__r6l8ci,
  UIntArrayrp6cv44n5v4y as UIntArray,
  _UIntArray___init__impl__ghjpc6p9a9ozepj5yp as _UIntArray___init__impl__ghjpc6,
  _UInt___init__impl__l7qpdl1vpobek1e692 as _UInt___init__impl__l7qpdl,
  UIntArray__get_impl_gp5kza3dxey4dpmolyb as UIntArray__get_impl_gp5kza,
  _UInt___get_data__impl__f0vqqw9xdox7iecbly as _UInt___get_data__impl__f0vqqw,
  ShortCompanionObject_instanceyg0ko6hbt9iy as ShortCompanionObject_instance,
  isShortArraywz30zxwtqi8h as isShortArray,
  Companion_getInstanceojp2cj59jqir as Companion_getInstance_5,
  _UShortArray___get_size__impl__jqto1bat9kt7h1kexu as _UShortArray___get_size__impl__jqto1b,
  UShortArray11avpmknxdgvv as UShortArray,
  _UShortArray___init__impl__9b26ef20xbmpmmmp8nr as _UShortArray___init__impl__9b26ef,
  _UShort___init__impl__jigrne3h2nm35iaibum as _UShort___init__impl__jigrne,
  UShortArray__get_impl_fnbhmx2rw6mvd6ywjjn as UShortArray__get_impl_fnbhmx,
  _UShort___get_data__impl__g02459z5yfs6z0kj0 as _UShort___get_data__impl__g0245,
  ByteCompanionObject_instancerp27gpfua1xf as ByteCompanionObject_instance,
  isByteArray4nnzfn1x4o3w as isByteArray,
  Companion_getInstance374brtr06v94p as Companion_getInstance_6,
  _UByteArray___get_size__impl__h6pkdv2ztnvvin1oejd as _UByteArray___get_size__impl__h6pkdv,
  UByteArray2qu4d6gwssdf9 as UByteArray,
  _UByteArray___init__impl__ip4y9n2yrhvr539f00i as _UByteArray___init__impl__ip4y9n,
  _UByte___init__impl__g9hnc415bxbmye0j11o as _UByte___init__impl__g9hnc4,
  UByteArray__get_impl_t5f3hv2yxdiuhsa1bkg as UByteArray__get_impl_t5f3hv,
  _UByte___get_data__impl__jof9qrfj1ch8mjizvj as _UByte___get_data__impl__jof9qr,
  BooleanCompanionObject_instance3nvf6tg77gv83 as BooleanCompanionObject_instance,
  isBooleanArray35llghle4c6w1 as isBooleanArray,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  copyOf2p23ljc5f5ea3 as copyOf,
  copyOfgossjg6lh6js as copyOf_0,
  copyOfq9pcgcgbldck as copyOf_1,
  copyOf9mbsebmgnw4t as copyOf_2,
  _ULongArray___get_storage__impl__28e64jlq4wjpcpg0xb as _ULongArray___get_storage__impl__28e64j,
  _ULongArray___init__impl__twm1l31njh1yo2fhc3d as _ULongArray___init__impl__twm1l3_0,
  ULongArray__set_impl_z19mvh3jq4upxqlu5i0 as ULongArray__set_impl_z19mvh,
  copyOf3rutauicler23 as copyOf_3,
  _UIntArray___get_storage__impl__92a0v03adro3l9nnqca as _UIntArray___get_storage__impl__92a0v0,
  _UIntArray___init__impl__ghjpc61vagysy0rvf as _UIntArray___init__impl__ghjpc6_0,
  UIntArray__set_impl_7f2zu22xxx79utmdcyl as UIntArray__set_impl_7f2zu2,
  copyOf39s58md6y6rn6 as copyOf_4,
  _UShortArray___get_storage__impl__t2jpv53ishea48wnh3x as _UShortArray___get_storage__impl__t2jpv5,
  _UShortArray___init__impl__9b26ef2p62uevidil7h as _UShortArray___init__impl__9b26ef_0,
  UShortArray__set_impl_6d8whp1v6ijtn8ethum as UShortArray__set_impl_6d8whp,
  copyOfwy6h3t5vzqpl as copyOf_5,
  _UByteArray___get_storage__impl__d4kctt24cpxlf9wdrm1 as _UByteArray___get_storage__impl__d4kctt,
  _UByteArray___init__impl__ip4y9n1d0y5mfc7d2ru as _UByteArray___init__impl__ip4y9n_0,
  UByteArray__set_impl_jvcicn17xhe4228sib8 as UByteArray__set_impl_jvcicn,
  copyOf37mht4mx7mjgh as copyOf_6,
  Unitkvevlwgzwiuc as Unit,
  trimIndent1qytc1wvt8suh as trimIndent,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  last1vo29oleiqj36 as last,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  get_lastIndex1yw0x4k50k51w as get_lastIndex_0,
  ULong3f9k7s38t3rfp as ULong,
  UInt1hthisrv6cndi as UInt,
  UShort26xnqty60t7le as UShort,
  UBytep4j7r1t64gz1 as UByte,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  PrimitiveClasses_getInstance28ukyr6i8fs0q as PrimitiveClasses_getInstance,
  mapOf1xd03cq9cnmy8 as mapOf,
  get_js1ale1wr4fbvs0 as get_js,
  findAssociatedObject1kb88g16k1goa as findAssociatedObject,
  IndexOutOfBoundsException1qfr429iumro0 as IndexOutOfBoundsException,
  get_indicesc04v40g017hw as get_indices,
  get_indices377latqcai313 as get_indices_0,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class SerializationStrategy {}
class DeserializationStrategy {}
class KSerializer {}
class AbstractPolymorphicSerializer {
  static x1t() {
    return createThis(this);
  }
  z1t(encoder, value) {
    var actualSerializer = findPolymorphicSerializer(this, encoder, value);
    // Inline function 'kotlinx.serialization.encoding.encodeStructure' call
    var descriptor = this.h1t();
    var composite = encoder.q1x(descriptor);
    composite.g1z(this.h1t(), 0, actualSerializer.h1t().k1u());
    var tmp = this.h1t();
    // Inline function 'kotlinx.serialization.internal.cast' call
    var tmp$ret$0 = isInterface(actualSerializer, SerializationStrategy) ? actualSerializer : THROW_CCE();
    composite.i1z(tmp, 1, tmp$ret$0, value);
    composite.r1x(descriptor);
  }
  i1t(encoder, value) {
    return this.z1t(encoder, !(value == null) ? value : THROW_CCE());
  }
  j1t(decoder) {
    // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
    var descriptor = this.h1t();
    var composite = decoder.q1x(descriptor);
    var tmp$ret$0;
    $l$block: {
      var klassName = null;
      var value = null;
      if (composite.g1y()) {
        tmp$ret$0 = decodeSequentially_0(this, composite);
        break $l$block;
      }
      mainLoop: while (true) {
        var index = composite.h1y(this.h1t());
        switch (index) {
          case -1:
            break mainLoop;
          case 0:
            klassName = composite.a1y(this.h1t(), index);
            break;
          case 1:
            var tmp0 = klassName;
            var tmp$ret$2;
            $l$block_0: {
              // Inline function 'kotlin.requireNotNull' call
              if (tmp0 == null) {
                var message = 'Cannot read polymorphic value before its type token';
                throw IllegalArgumentException.t(toString(message));
              } else {
                tmp$ret$2 = tmp0;
                break $l$block_0;
              }
            }

            klassName = tmp$ret$2;
            var serializer = findPolymorphicSerializer_0(this, composite, klassName);
            value = composite.d1y(this.h1t(), index, serializer);
            break;
          default:
            var tmp0_elvis_lhs = klassName;
            throw SerializationException.t1u('Invalid index in polymorphic deserialization of ' + (tmp0_elvis_lhs == null ? 'unknown class' : tmp0_elvis_lhs) + ('\n Expected 0, 1 or DECODE_DONE(-1), but found ' + index));
        }
      }
      var tmp1 = value;
      var tmp$ret$4;
      $l$block_1: {
        // Inline function 'kotlin.requireNotNull' call
        if (tmp1 == null) {
          var message_0 = 'Polymorphic value has not been read for class ' + klassName;
          throw IllegalArgumentException.t(toString(message_0));
        } else {
          tmp$ret$4 = tmp1;
          break $l$block_1;
        }
      }
      var tmp = tmp$ret$4;
      tmp$ret$0 = !(tmp == null) ? tmp : THROW_CCE();
    }
    var result = tmp$ret$0;
    composite.r1x(descriptor);
    return result;
  }
  a1u(decoder, klassName) {
    return decoder.f1y().p1z(this.y1t(), klassName);
  }
  b1u(encoder, value) {
    return encoder.f1y().q1z(this.y1t(), value);
  }
}
class PolymorphicSerializer extends AbstractPolymorphicSerializer {
  static w1t(baseClass) {
    var $this = this.x1t();
    $this.t1t_1 = baseClass;
    $this.u1t_1 = emptyList();
    var tmp = $this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.v1t_1 = lazy(tmp_0, PolymorphicSerializer$descriptor$delegate$lambda($this));
    return $this;
  }
  y1t() {
    return this.t1t_1;
  }
  h1t() {
    var tmp0 = this.v1t_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory();
    return tmp0.n1();
  }
  toString() {
    return 'kotlinx.serialization.PolymorphicSerializer(baseClass: ' + toString(this.t1t_1) + ')';
  }
}
class SealedClassSerializer$$inlined$groupingBy$1 {
  constructor($this) {
    this.h1u_1 = $this;
  }
  i1u() {
    return this.h1u_1.y();
  }
  j1u(element) {
    return element.n1().h1t().k1u();
  }
  l1u(element) {
    return this.j1u((element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class SealedClassSerializer extends AbstractPolymorphicSerializer {
  static m1u(serialName, baseClass, subclasses, subclassSerializers) {
    var $this = this.x1t();
    $this.c1u_1 = baseClass;
    $this.d1u_1 = emptyList();
    var tmp = $this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.e1u_1 = lazy(tmp_0, SealedClassSerializer$descriptor$delegate$lambda(serialName, $this));
    if (!(subclasses.length === subclassSerializers.length)) {
      throw IllegalArgumentException.t('All subclasses of sealed class ' + $this.c1u_1.hf() + ' should be marked @Serializable');
    }
    $this.f1u_1 = toMap(zip(subclasses, subclassSerializers));
    var tmp_1 = $this;
    // Inline function 'kotlin.collections.groupingBy' call
    var this_0 = $this.f1u_1.l1();
    // Inline function 'kotlin.collections.aggregate' call
    var tmp0 = new SealedClassSerializer$$inlined$groupingBy$1(this_0);
    // Inline function 'kotlin.collections.mutableMapOf' call
    // Inline function 'kotlin.collections.aggregateTo' call
    var destination = LinkedHashMap.hc();
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = tmp0.i1u();
    while (_iterator__ex2g4s.z()) {
      var e = _iterator__ex2g4s.a1();
      var key = tmp0.l1u(e);
      var accumulator = destination.h3(key);
      accumulator == null && !destination.f3(key);
      if (!(accumulator == null)) {
        // Inline function 'kotlin.error' call
        var message = "Multiple sealed subclasses of '" + toString($this.c1u_1) + "' have the same serial name '" + key + "':" + (" '" + toString(accumulator.m1()) + "', '" + toString(e.m1()) + "'");
        throw IllegalStateException.t4(toString(message));
      }
      // Inline function 'kotlin.collections.set' call
      destination.k3(key, e);
    }
    // Inline function 'kotlin.collections.mapValues' call
    // Inline function 'kotlin.collections.mapValuesTo' call
    var destination_0 = LinkedHashMap.ic(mapCapacity(destination.b1()));
    // Inline function 'kotlin.collections.associateByTo' call
    var _iterator__ex2g4s_0 = destination.l1().y();
    while (_iterator__ex2g4s_0.z()) {
      var element = _iterator__ex2g4s_0.a1();
      var tmp_2 = element.m1();
      var tmp$ret$8 = element.n1().n1();
      destination_0.k3(tmp_2, tmp$ret$8);
    }
    tmp_1.g1u_1 = destination_0;
    return $this;
  }
  y1t() {
    return this.c1u_1;
  }
  static n1u(serialName, baseClass, subclasses, subclassSerializers, classAnnotations) {
    var $this = this.m1u(serialName, baseClass, subclasses, subclassSerializers);
    $this.d1u_1 = asList(classAnnotations);
    return $this;
  }
  h1t() {
    var tmp0 = this.e1u_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory_0();
    return tmp0.n1();
  }
  a1u(decoder, klassName) {
    // Inline function 'kotlin.collections.get' call
    var this_0 = this.g1u_1;
    var tmp0_elvis_lhs = (isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).h3(klassName);
    return tmp0_elvis_lhs == null ? super.a1u(decoder, klassName) : tmp0_elvis_lhs;
  }
  b1u(encoder, value) {
    var tmp0_elvis_lhs = this.f1u_1.h3(getKClassFromExpression(value));
    var tmp1_safe_receiver = tmp0_elvis_lhs == null ? super.b1u(encoder, value) : tmp0_elvis_lhs;
    var tmp;
    if (tmp1_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlinx.serialization.internal.cast' call
      tmp = isInterface(tmp1_safe_receiver, SerializationStrategy) ? tmp1_safe_receiver : THROW_CCE();
    }
    return tmp;
  }
}
class SerializationException extends IllegalArgumentException {
  static s1u() {
    var $this = this.zd();
    init_kotlinx_serialization_SerializationException($this);
    return $this;
  }
  static t1u(message) {
    var $this = this.t(message);
    init_kotlinx_serialization_SerializationException($this);
    return $this;
  }
  static u1u(message, cause) {
    var $this = this.ae(message, cause);
    init_kotlinx_serialization_SerializationException($this);
    return $this;
  }
}
class MissingFieldException extends SerializationException {
  static b1v(missingFields, message, cause) {
    var $this = this.u1u(message, cause);
    captureStack($this, $this.a1v_1);
    $this.z1u_1 = missingFields;
    return $this;
  }
  static c1v(missingFields, serialName) {
    return this.b1v(missingFields, missingFields.b1() === 1 ? "Field '" + missingFields.f1(0) + "' is required for type with serial name '" + serialName + "', but it was missing" : 'Fields ' + toString(missingFields) + " are required for type with serial name '" + serialName + "', but they were missing", null);
  }
  static d1v(missingField, serialName) {
    return this.b1v(listOf(missingField), "Field '" + missingField + "' is required for type with serial name '" + serialName + "', but it was missing", null);
  }
}
class UnknownFieldException extends SerializationException {
  static j1v(message) {
    var $this = this.t1u(message);
    captureStack($this, $this.i1v_1);
    return $this;
  }
  static k1v(index) {
    return this.j1v('An unknown field for index ' + index);
  }
}
class SerialDescriptor {}
function get_isNullable() {
  return false;
}
function get_isInline() {
  return false;
}
function get_annotations() {
  return emptyList();
}
class ContextDescriptor {
  constructor(original, kClass) {
    this.r1v_1 = original;
    this.s1v_1 = kClass;
    this.t1v_1 = this.r1v_1.k1u() + '<' + this.s1v_1.hf() + '>';
  }
  k1u() {
    return this.t1v_1;
  }
  equals(other) {
    var tmp0_elvis_lhs = other instanceof ContextDescriptor ? other : null;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return false;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var another = tmp;
    return equals(this.r1v_1, another.r1v_1) && another.s1v_1.equals(this.s1v_1);
  }
  hashCode() {
    var result = this.s1v_1.hashCode();
    result = imul(31, result) + getStringHashCode(this.t1v_1) | 0;
    return result;
  }
  toString() {
    return 'ContextDescriptor(kClass: ' + toString(this.s1v_1) + ', original: ' + toString(this.r1v_1) + ')';
  }
  u1v() {
    return this.r1v_1.u1v();
  }
  q1v() {
    return this.r1v_1.q1v();
  }
  v1v() {
    return this.r1v_1.v1v();
  }
  w1v() {
    return this.r1v_1.w1v();
  }
  x1v() {
    return this.r1v_1.x1v();
  }
  y1v(index) {
    return this.r1v_1.y1v(index);
  }
  z1v(name) {
    return this.r1v_1.z1v(name);
  }
  a1w(index) {
    return this.r1v_1.a1w(index);
  }
  b1w(index) {
    return this.r1v_1.b1w(index);
  }
  c1w(index) {
    return this.r1v_1.c1w(index);
  }
}
class elementDescriptors$1 {
  constructor($this_elementDescriptors) {
    this.h1w_1 = $this_elementDescriptors;
    this.g1w_1 = $this_elementDescriptors.w1v();
  }
  z() {
    return this.g1w_1 > 0;
  }
  a1() {
    var tmp = this.h1w_1.w1v();
    var _unary__edvuaz = this.g1w_1;
    this.g1w_1 = _unary__edvuaz - 1 | 0;
    return this.h1w_1.b1w(tmp - _unary__edvuaz | 0);
  }
}
class elementDescriptors$$inlined$Iterable$1 {
  constructor($this_elementDescriptors) {
    this.i1w_1 = $this_elementDescriptors;
  }
  y() {
    return new elementDescriptors$1(this.i1w_1);
  }
}
class elementNames$1 {
  constructor($this_elementNames) {
    this.k1w_1 = $this_elementNames;
    this.j1w_1 = $this_elementNames.w1v();
  }
  z() {
    return this.j1w_1 > 0;
  }
  a1() {
    var tmp = this.k1w_1.w1v();
    var _unary__edvuaz = this.j1w_1;
    this.j1w_1 = _unary__edvuaz - 1 | 0;
    return this.k1w_1.y1v(tmp - _unary__edvuaz | 0);
  }
}
class elementNames$$inlined$Iterable$1 {
  constructor($this_elementNames) {
    this.l1w_1 = $this_elementNames;
  }
  y() {
    return new elementNames$1(this.l1w_1);
  }
}
class ClassSerialDescriptorBuilder {
  constructor(serialName) {
    this.k1t_1 = serialName;
    this.l1t_1 = false;
    this.m1t_1 = emptyList();
    this.n1t_1 = ArrayList.k();
    this.o1t_1 = HashSet.ga();
    this.p1t_1 = ArrayList.k();
    this.q1t_1 = ArrayList.k();
    this.r1t_1 = ArrayList.k();
  }
  m1w(elementName, descriptor, annotations, isOptional) {
    // Inline function 'kotlin.require' call
    if (!this.o1t_1.l(elementName)) {
      var message = "Element with name '" + elementName + "' is already registered in " + this.k1t_1;
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.collections.plusAssign' call
    this.n1t_1.l(elementName);
    // Inline function 'kotlin.collections.plusAssign' call
    this.p1t_1.l(descriptor);
    // Inline function 'kotlin.collections.plusAssign' call
    this.q1t_1.l(annotations);
    // Inline function 'kotlin.collections.plusAssign' call
    this.r1t_1.l(isOptional);
  }
  s1t(elementName, descriptor, annotations, isOptional, $super) {
    annotations = annotations === VOID ? emptyList() : annotations;
    isOptional = isOptional === VOID ? false : isOptional;
    var tmp;
    if ($super === VOID) {
      this.m1w(elementName, descriptor, annotations, isOptional);
      tmp = Unit_instance;
    } else {
      tmp = $super.m1w.call(this, elementName, descriptor, annotations, isOptional);
    }
    return tmp;
  }
}
class CachedNames {}
class SerialDescriptorImpl {
  constructor(serialName, kind, elementsCount, typeParameters, builder) {
    this.n1w_1 = serialName;
    this.o1w_1 = kind;
    this.p1w_1 = elementsCount;
    this.q1w_1 = builder.m1t_1;
    this.r1w_1 = toHashSet(builder.n1t_1);
    var tmp = this;
    // Inline function 'kotlin.collections.toTypedArray' call
    var this_0 = builder.n1t_1;
    tmp.s1w_1 = copyToArray(this_0);
    this.t1w_1 = compactArray(builder.p1t_1);
    var tmp_0 = this;
    // Inline function 'kotlin.collections.toTypedArray' call
    var this_1 = builder.q1t_1;
    tmp_0.u1w_1 = copyToArray(this_1);
    this.v1w_1 = toBooleanArray(builder.r1t_1);
    var tmp_1 = this;
    // Inline function 'kotlin.collections.map' call
    var this_2 = withIndex(this.s1w_1);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_2, 10));
    var _iterator__ex2g4s = this_2.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$2 = to(item.jl_1, item.il_1);
      destination.l(tmp$ret$2);
    }
    tmp_1.w1w_1 = toMap(destination);
    this.x1w_1 = compactArray(typeParameters);
    var tmp_2 = this;
    tmp_2.y1w_1 = lazy_0(SerialDescriptorImpl$_hashCode$delegate$lambda(this));
  }
  k1u() {
    return this.n1w_1;
  }
  u1v() {
    return this.o1w_1;
  }
  w1v() {
    return this.p1w_1;
  }
  x1v() {
    return this.q1w_1;
  }
  z1w() {
    return this.r1w_1;
  }
  y1v(index) {
    return getChecked(this.s1w_1, index);
  }
  z1v(name) {
    var tmp0_elvis_lhs = this.w1w_1.h3(name);
    return tmp0_elvis_lhs == null ? -3 : tmp0_elvis_lhs;
  }
  a1w(index) {
    return getChecked(this.u1w_1, index);
  }
  b1w(index) {
    return getChecked(this.t1w_1, index);
  }
  c1w(index) {
    return getChecked_0(this.v1w_1, index);
  }
  equals(other) {
    var tmp$ret$0;
    $l$block_5: {
      // Inline function 'kotlinx.serialization.internal.equalsImpl' call
      if (this === other) {
        tmp$ret$0 = true;
        break $l$block_5;
      }
      if (!(other instanceof SerialDescriptorImpl)) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.k1u() === other.k1u())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!contentEquals(this.x1w_1, other.x1w_1)) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.w1v() === other.w1v())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      var inductionVariable = 0;
      var last = this.w1v();
      if (inductionVariable < last)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(this.b1w(index).k1u() === other.b1w(index).k1u())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
          if (!equals(this.b1w(index).u1v(), other.b1w(index).u1v())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
        }
         while (inductionVariable < last);
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  }
  hashCode() {
    return _get__hashCode__tgwhef(this);
  }
  toString() {
    return toStringImpl(this);
  }
}
class SerialKind {
  toString() {
    return ensureNotNull(getKClassFromExpression(this).hf());
  }
  hashCode() {
    return getStringHashCode(this.toString());
  }
}
class ENUM extends SerialKind {
  constructor() {
    ENUM_instance = null;
    super();
    ENUM_instance = this;
  }
}
class CONTEXTUAL extends SerialKind {
  constructor() {
    CONTEXTUAL_instance = null;
    super();
    CONTEXTUAL_instance = this;
  }
}
class PolymorphicKind extends SerialKind {}
class SEALED extends PolymorphicKind {
  constructor() {
    SEALED_instance = null;
    super();
    SEALED_instance = this;
  }
}
class OPEN extends PolymorphicKind {
  constructor() {
    OPEN_instance = null;
    super();
    OPEN_instance = this;
  }
}
class PrimitiveKind extends SerialKind {}
class BOOLEAN extends PrimitiveKind {
  constructor() {
    BOOLEAN_instance = null;
    super();
    BOOLEAN_instance = this;
  }
}
class BYTE extends PrimitiveKind {
  constructor() {
    BYTE_instance = null;
    super();
    BYTE_instance = this;
  }
}
class CHAR extends PrimitiveKind {
  constructor() {
    CHAR_instance = null;
    super();
    CHAR_instance = this;
  }
}
class SHORT extends PrimitiveKind {
  constructor() {
    SHORT_instance = null;
    super();
    SHORT_instance = this;
  }
}
class INT extends PrimitiveKind {
  constructor() {
    INT_instance = null;
    super();
    INT_instance = this;
  }
}
class LONG extends PrimitiveKind {
  constructor() {
    LONG_instance = null;
    super();
    LONG_instance = this;
  }
}
class FLOAT extends PrimitiveKind {
  constructor() {
    FLOAT_instance = null;
    super();
    FLOAT_instance = this;
  }
}
class DOUBLE extends PrimitiveKind {
  constructor() {
    DOUBLE_instance = null;
    super();
    DOUBLE_instance = this;
  }
}
class STRING extends PrimitiveKind {
  constructor() {
    STRING_instance = null;
    super();
    STRING_instance = this;
  }
}
class StructureKind extends SerialKind {}
class CLASS extends StructureKind {
  constructor() {
    CLASS_instance = null;
    super();
    CLASS_instance = this;
  }
}
class LIST extends StructureKind {
  constructor() {
    LIST_instance = null;
    super();
    LIST_instance = this;
  }
}
class MAP extends StructureKind {
  constructor() {
    MAP_instance = null;
    super();
    MAP_instance = this;
  }
}
class OBJECT extends StructureKind {
  constructor() {
    OBJECT_instance = null;
    super();
    OBJECT_instance = this;
  }
}
class Decoder {}
function decodeSerializableValue(deserializer) {
  return deserializer.j1t(this);
}
class CompositeDecoder {}
function decodeSequentially() {
  return false;
}
function decodeCollectionSize(descriptor) {
  return -1;
}
function decodeSerializableElement$default(descriptor, index, deserializer, previousValue, $super) {
  previousValue = previousValue === VOID ? null : previousValue;
  return $super === VOID ? this.c1y(descriptor, index, deserializer, previousValue) : $super.c1y.call(this, descriptor, index, deserializer, previousValue);
}
class AbstractDecoder {
  a1x() {
    throw SerializationException.t1u(toString(getKClassFromExpression(this)) + " can't retrieve untyped values");
  }
  b1x() {
    return true;
  }
  c1x() {
    return null;
  }
  d1x() {
    var tmp = this.a1x();
    return typeof tmp === 'boolean' ? tmp : THROW_CCE();
  }
  e1x() {
    var tmp = this.a1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  f1x() {
    var tmp = this.a1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  g1x() {
    var tmp = this.a1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  h1x() {
    var tmp = this.a1x();
    return tmp instanceof Long ? tmp : THROW_CCE();
  }
  i1x() {
    var tmp = this.a1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  j1x() {
    var tmp = this.a1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  k1x() {
    var tmp = this.a1x();
    return tmp instanceof Char ? tmp.j2_1 : THROW_CCE();
  }
  l1x() {
    var tmp = this.a1x();
    return typeof tmp === 'string' ? tmp : THROW_CCE();
  }
  m1x(enumDescriptor) {
    var tmp = this.a1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  n1x(descriptor) {
    return this;
  }
  o1x(deserializer, previousValue) {
    return this.p1x(deserializer);
  }
  q1x(descriptor) {
    return this;
  }
  r1x(descriptor) {
  }
  s1x(descriptor, index) {
    return this.d1x();
  }
  t1x(descriptor, index) {
    return this.e1x();
  }
  u1x(descriptor, index) {
    return this.f1x();
  }
  v1x(descriptor, index) {
    return this.g1x();
  }
  w1x(descriptor, index) {
    return this.h1x();
  }
  x1x(descriptor, index) {
    return this.i1x();
  }
  y1x(descriptor, index) {
    return this.j1x();
  }
  z1x(descriptor, index) {
    return this.k1x();
  }
  a1y(descriptor, index) {
    return this.l1x();
  }
  b1y(descriptor, index) {
    return this.n1x(descriptor.b1w(index));
  }
  c1y(descriptor, index, deserializer, previousValue) {
    return this.o1x(deserializer, previousValue);
  }
  e1y(descriptor, index, deserializer, previousValue) {
    // Inline function 'kotlinx.serialization.encoding.decodeIfNullable' call
    var isNullabilitySupported = deserializer.h1t().q1v();
    var tmp;
    if (isNullabilitySupported || this.b1x()) {
      tmp = this.o1x(deserializer, previousValue);
    } else {
      tmp = this.c1x();
    }
    return tmp;
  }
}
class Encoder {}
function encodeNotNullMark() {
}
function beginCollection(descriptor, collectionSize) {
  return this.q1x(descriptor);
}
function encodeSerializableValue(serializer, value) {
  serializer.i1t(this, value);
}
function encodeNullableSerializableValue(serializer, value) {
  var isNullabilitySupported = serializer.h1t().q1v();
  if (isNullabilitySupported) {
    return this.j1z(isInterface(serializer, SerializationStrategy) ? serializer : THROW_CCE(), value);
  }
  if (value == null) {
    this.m1y();
  } else {
    this.m1z();
    this.j1z(serializer, value);
  }
}
class CompositeEncoder {}
function shouldEncodeElementDefault(descriptor, index) {
  return true;
}
class AbstractEncoder {
  static j1y($box) {
    return createThis(this, $box);
  }
  q1x(descriptor) {
    return this;
  }
  r1x(descriptor) {
  }
  k1y(descriptor, index) {
    return true;
  }
  l1y(value) {
    throw SerializationException.t1u('Non-serializable ' + toString(getKClassFromExpression(value)) + ' is not supported by ' + toString(getKClassFromExpression(this)) + ' encoder');
  }
  m1y() {
    throw SerializationException.t1u("'null' is not supported by default");
  }
  n1y(value) {
    return this.l1y(value);
  }
  o1y(value) {
    return this.l1y(value);
  }
  p1y(value) {
    return this.l1y(value);
  }
  q1y(value) {
    return this.l1y(value);
  }
  r1y(value) {
    return this.l1y(value);
  }
  s1y(value) {
    return this.l1y(value);
  }
  t1y(value) {
    return this.l1y(value);
  }
  u1y(value) {
    return this.l1y(new Char(value));
  }
  v1y(value) {
    return this.l1y(value);
  }
  w1y(enumDescriptor, index) {
    return this.l1y(index);
  }
  x1y(descriptor) {
    return this;
  }
  y1y(descriptor, index, value) {
    if (this.k1y(descriptor, index)) {
      this.n1y(value);
    }
  }
  z1y(descriptor, index, value) {
    if (this.k1y(descriptor, index)) {
      this.o1y(value);
    }
  }
  a1z(descriptor, index, value) {
    if (this.k1y(descriptor, index)) {
      this.p1y(value);
    }
  }
  b1z(descriptor, index, value) {
    if (this.k1y(descriptor, index)) {
      this.q1y(value);
    }
  }
  c1z(descriptor, index, value) {
    if (this.k1y(descriptor, index)) {
      this.r1y(value);
    }
  }
  d1z(descriptor, index, value) {
    if (this.k1y(descriptor, index)) {
      this.s1y(value);
    }
  }
  e1z(descriptor, index, value) {
    if (this.k1y(descriptor, index)) {
      this.t1y(value);
    }
  }
  f1z(descriptor, index, value) {
    if (this.k1y(descriptor, index)) {
      this.u1y(value);
    }
  }
  g1z(descriptor, index, value) {
    if (this.k1y(descriptor, index)) {
      this.v1y(value);
    }
  }
  h1z(descriptor, index) {
    return this.k1y(descriptor, index) ? this.x1y(descriptor.b1w(index)) : NoOpEncoder_getInstance();
  }
  i1z(descriptor, index, serializer, value) {
    if (this.k1y(descriptor, index)) {
      this.j1z(serializer, value);
    }
  }
  k1z(descriptor, index, serializer, value) {
    if (this.k1y(descriptor, index)) {
      this.l1z(serializer, value);
    }
  }
}
class NothingSerializer {
  constructor() {
    NothingSerializer_instance = this;
    this.r1z_1 = NothingSerialDescriptor_getInstance();
  }
  h1t() {
    return this.r1z_1;
  }
  s1z(encoder, value) {
    throw SerializationException.t1u("'kotlin.Nothing' cannot be serialized");
  }
  i1t(encoder, value) {
    var tmp;
    if (false) {
      tmp = value;
    } else {
      tmp = THROW_CCE();
    }
    return this.s1z(encoder, tmp);
  }
  j1t(decoder) {
    throw SerializationException.t1u("'kotlin.Nothing' does not have instances");
  }
}
class DurationSerializer {
  constructor() {
    DurationSerializer_instance = this;
    this.t1z_1 = new PrimitiveSerialDescriptor('kotlin.time.Duration', STRING_getInstance());
  }
  h1t() {
    return this.t1z_1;
  }
  u1z(encoder, value) {
    encoder.v1y(Duration__toIsoString_impl_9h6wsm(value));
  }
  i1t(encoder, value) {
    return this.u1z(encoder, value instanceof Duration ? value.lj_1 : THROW_CCE());
  }
  v1z(decoder) {
    return Companion_getInstance().jr(decoder.l1x());
  }
  j1t(decoder) {
    return new Duration(this.v1z(decoder));
  }
}
class UuidSerializer {
  constructor() {
    UuidSerializer_instance = this;
    this.w1z_1 = new PrimitiveSerialDescriptor('kotlin.uuid.Uuid', STRING_getInstance());
  }
  h1t() {
    return this.w1z_1;
  }
  x1z(encoder, value) {
    encoder.v1y(value.toString());
  }
  i1t(encoder, value) {
    return this.x1z(encoder, value instanceof Uuid ? value : THROW_CCE());
  }
  j1t(decoder) {
    return Companion_getInstance_0().ds(decoder.l1x());
  }
}
class ListLikeDescriptor {
  constructor(elementDescriptor) {
    this.a20_1 = elementDescriptor;
    this.b20_1 = 1;
  }
  u1v() {
    return LIST_getInstance();
  }
  w1v() {
    return this.b20_1;
  }
  y1v(index) {
    return index.toString();
  }
  z1v(name) {
    var tmp0_elvis_lhs = toIntOrNull(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException.t(name + ' is not a valid list index');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  c1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.k1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return false;
  }
  a1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.k1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return emptyList();
  }
  b1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.k1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return this.a20_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ListLikeDescriptor))
      return false;
    if (equals(this.a20_1, other.a20_1) && this.k1u() === other.k1u())
      return true;
    return false;
  }
  hashCode() {
    return imul(hashCode(this.a20_1), 31) + getStringHashCode(this.k1u()) | 0;
  }
  toString() {
    return this.k1u() + '(' + toString(this.a20_1) + ')';
  }
}
class ArrayListClassDesc extends ListLikeDescriptor {
  k1u() {
    return 'kotlin.collections.ArrayList';
  }
}
class HashSetClassDesc extends ListLikeDescriptor {
  k1u() {
    return 'kotlin.collections.HashSet';
  }
}
class LinkedHashSetClassDesc extends ListLikeDescriptor {
  k1u() {
    return 'kotlin.collections.LinkedHashSet';
  }
}
class MapLikeDescriptor {
  constructor(serialName, keyDescriptor, valueDescriptor) {
    this.g20_1 = serialName;
    this.h20_1 = keyDescriptor;
    this.i20_1 = valueDescriptor;
    this.j20_1 = 2;
  }
  k1u() {
    return this.g20_1;
  }
  u1v() {
    return MAP_getInstance();
  }
  w1v() {
    return this.j20_1;
  }
  y1v(index) {
    return index.toString();
  }
  z1v(name) {
    var tmp0_elvis_lhs = toIntOrNull(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException.t(name + ' is not a valid map index');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  c1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.k1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return false;
  }
  a1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.k1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return emptyList();
  }
  b1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.k1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    var tmp;
    switch (index % 2 | 0) {
      case 0:
        tmp = this.h20_1;
        break;
      case 1:
        tmp = this.i20_1;
        break;
      default:
        var message_0 = 'Unreached';
        throw IllegalStateException.t4(toString(message_0));
    }
    return tmp;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MapLikeDescriptor))
      return false;
    if (!(this.k1u() === other.k1u()))
      return false;
    if (!equals(this.h20_1, other.h20_1))
      return false;
    if (!equals(this.i20_1, other.i20_1))
      return false;
    return true;
  }
  hashCode() {
    var result = getStringHashCode(this.k1u());
    result = imul(31, result) + hashCode(this.h20_1) | 0;
    result = imul(31, result) + hashCode(this.i20_1) | 0;
    return result;
  }
  toString() {
    return this.k1u() + '(' + toString(this.h20_1) + ', ' + toString(this.i20_1) + ')';
  }
}
class HashMapClassDesc extends MapLikeDescriptor {
  constructor(keyDesc, valueDesc) {
    super('kotlin.collections.HashMap', keyDesc, valueDesc);
  }
}
class LinkedHashMapClassDesc extends MapLikeDescriptor {
  constructor(keyDesc, valueDesc) {
    super('kotlin.collections.LinkedHashMap', keyDesc, valueDesc);
  }
}
class ArrayClassDesc extends ListLikeDescriptor {
  k1u() {
    return 'kotlin.Array';
  }
}
class PrimitiveArrayDescriptor extends ListLikeDescriptor {
  constructor(primitive) {
    super(primitive);
    this.o20_1 = primitive.k1u() + 'Array';
  }
  k1u() {
    return this.o20_1;
  }
}
class AbstractCollectionSerializer {
  k21(decoder, previous) {
    var tmp1_elvis_lhs = previous == null ? null : this.x20(previous);
    var builder = tmp1_elvis_lhs == null ? this.r20() : tmp1_elvis_lhs;
    var startIndex = this.t20(builder);
    var compositeDecoder = decoder.q1x(this.h1t());
    if (compositeDecoder.g1y()) {
      this.h21(compositeDecoder, builder, startIndex, readSize(this, compositeDecoder, builder));
    } else {
      $l$loop: while (true) {
        var index = compositeDecoder.h1y(this.h1t());
        if (index === -1)
          break $l$loop;
        this.j21(compositeDecoder, startIndex + index | 0, builder);
      }
    }
    compositeDecoder.r1x(this.h1t());
    return this.v20(builder);
  }
  j1t(decoder) {
    return this.k21(decoder, null);
  }
  j21(decoder, index, builder, checkIndex, $super) {
    checkIndex = checkIndex === VOID ? true : checkIndex;
    var tmp;
    if ($super === VOID) {
      this.i21(decoder, index, builder, checkIndex);
      tmp = Unit_instance;
    } else {
      tmp = $super.i21.call(this, decoder, index, builder, checkIndex);
    }
    return tmp;
  }
}
class CollectionLikeSerializer extends AbstractCollectionSerializer {
  constructor(elementSerializer) {
    super();
    this.f21_1 = elementSerializer;
  }
  g21(encoder, value) {
    var size = this.c22(value);
    // Inline function 'kotlinx.serialization.encoding.encodeCollection' call
    var descriptor = this.h1t();
    var composite = encoder.n1z(descriptor, size);
    var iterator = this.e22(value);
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        composite.i1z(this.h1t(), index, this.f21_1, iterator.a1());
      }
       while (inductionVariable < size);
    composite.r1x(descriptor);
  }
  i1t(encoder, value) {
    return this.g21(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  h21(decoder, builder, startIndex, size) {
    // Inline function 'kotlin.require' call
    if (!(size >= 0)) {
      var message = 'Size must be known in advance when using READ_ALL';
      throw IllegalArgumentException.t(toString(message));
    }
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.i21(decoder, startIndex + index | 0, builder, false);
      }
       while (inductionVariable < size);
  }
  i21(decoder, index, builder, checkIndex) {
    this.b21(builder, index, decoder.d1y(this.h1t(), index, this.f21_1));
  }
}
class CollectionSerializer extends CollectionLikeSerializer {
  d21(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  c22(_this__u8e3s4) {
    return this.d21((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Collection) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  e21(_this__u8e3s4) {
    return _this__u8e3s4.y();
  }
  e22(_this__u8e3s4) {
    return this.e21((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Collection) : false) ? _this__u8e3s4 : THROW_CCE());
  }
}
class ArrayListSerializer extends CollectionSerializer {
  constructor(element) {
    super(element);
    this.q20_1 = new ArrayListClassDesc(element.h1t());
  }
  h1t() {
    return this.q20_1;
  }
  r20() {
    // Inline function 'kotlin.collections.arrayListOf' call
    return ArrayList.k();
  }
  s20(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  t20(_this__u8e3s4) {
    return this.s20(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
  }
  u20(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  v20(_this__u8e3s4) {
    return this.u20(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
  }
  w20(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? ArrayList.h(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  x20(_this__u8e3s4) {
    return this.w20((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtList) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  y20(_this__u8e3s4, size) {
    return _this__u8e3s4.y7(size);
  }
  z20(_this__u8e3s4, size) {
    return this.y20(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE(), size);
  }
  a21(_this__u8e3s4, index, element) {
    _this__u8e3s4.d3(index, element);
  }
  b21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE();
    return this.a21(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class HashSetSerializer extends CollectionSerializer {
  constructor(eSerializer) {
    super(eSerializer);
    this.m21_1 = new HashSetClassDesc(eSerializer.h1t());
  }
  h1t() {
    return this.m21_1;
  }
  r20() {
    return HashSet.ga();
  }
  n21(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  t20(_this__u8e3s4) {
    return this.n21(_this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE());
  }
  o21(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  v20(_this__u8e3s4) {
    return this.o21(_this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE());
  }
  p21(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? HashSet.ha(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  x20(_this__u8e3s4) {
    return this.p21((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtSet) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  q21(_this__u8e3s4, size) {
  }
  z20(_this__u8e3s4, size) {
    return this.q21(_this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE(), size);
  }
  r21(_this__u8e3s4, index, element) {
    _this__u8e3s4.l(element);
  }
  b21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE();
    return this.r21(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class LinkedHashSetSerializer extends CollectionSerializer {
  constructor(eSerializer) {
    super(eSerializer);
    this.t21_1 = new LinkedHashSetClassDesc(eSerializer.h1t());
  }
  h1t() {
    return this.t21_1;
  }
  r20() {
    // Inline function 'kotlin.collections.linkedSetOf' call
    return LinkedHashSet.g1();
  }
  u21(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  t20(_this__u8e3s4) {
    return this.u21(_this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE());
  }
  v21(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  v20(_this__u8e3s4) {
    return this.v21(_this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE());
  }
  p21(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? LinkedHashSet.j1(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  x20(_this__u8e3s4) {
    return this.p21((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtSet) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  w21(_this__u8e3s4, size) {
  }
  z20(_this__u8e3s4, size) {
    return this.w21(_this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE(), size);
  }
  x21(_this__u8e3s4, index, element) {
    _this__u8e3s4.l(element);
  }
  b21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE();
    return this.x21(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class MapLikeSerializer extends AbstractCollectionSerializer {
  constructor(keySerializer, valueSerializer) {
    super();
    this.j22_1 = keySerializer;
    this.k22_1 = valueSerializer;
  }
  l22(decoder, builder, startIndex, size) {
    // Inline function 'kotlin.require' call
    if (!(size >= 0)) {
      var message = 'Size must be known in advance when using READ_ALL';
      throw IllegalArgumentException.t(toString(message));
    }
    var progression = step(until(0, imul(size, 2)), 2);
    var inductionVariable = progression.t1_1;
    var last = progression.u1_1;
    var step_0 = progression.v1_1;
    if (step_0 > 0 && inductionVariable <= last || (step_0 < 0 && last <= inductionVariable))
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + step_0 | 0;
        this.m22(decoder, startIndex + index | 0, builder, false);
      }
       while (!(index === last));
  }
  h21(decoder, builder, startIndex, size) {
    return this.l22(decoder, (!(builder == null) ? isInterface(builder, KtMutableMap) : false) ? builder : THROW_CCE(), startIndex, size);
  }
  m22(decoder, index, builder, checkIndex) {
    var key = decoder.d1y(this.h1t(), index, this.j22_1);
    var tmp;
    if (checkIndex) {
      // Inline function 'kotlin.also' call
      var this_0 = decoder.h1y(this.h1t());
      // Inline function 'kotlin.require' call
      if (!(this_0 === (index + 1 | 0))) {
        var message = 'Value must follow key in a map, index for key: ' + index + ', returned index for value: ' + this_0;
        throw IllegalArgumentException.t(toString(message));
      }
      tmp = this_0;
    } else {
      tmp = index + 1 | 0;
    }
    var vIndex = tmp;
    var tmp_0;
    var tmp_1;
    if (builder.f3(key)) {
      var tmp_2 = this.k22_1.h1t().u1v();
      tmp_1 = !(tmp_2 instanceof PrimitiveKind);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = decoder.c1y(this.h1t(), vIndex, this.k22_1, getValue(builder, key));
    } else {
      tmp_0 = decoder.d1y(this.h1t(), vIndex, this.k22_1);
    }
    var value = tmp_0;
    // Inline function 'kotlin.collections.set' call
    builder.k3(key, value);
  }
  i21(decoder, index, builder, checkIndex) {
    return this.m22(decoder, index, (!(builder == null) ? isInterface(builder, KtMutableMap) : false) ? builder : THROW_CCE(), checkIndex);
  }
  g21(encoder, value) {
    var size = this.c22(value);
    // Inline function 'kotlinx.serialization.encoding.encodeCollection' call
    var descriptor = this.h1t();
    var composite = encoder.n1z(descriptor, size);
    var iterator = this.e22(value);
    var index = 0;
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = iterator;
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var k = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var v = element.n1();
      var tmp = this.h1t();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      composite.i1z(tmp, _unary__edvuaz, this.j22_1, k);
      var tmp_0 = this.h1t();
      var _unary__edvuaz_0 = index;
      index = _unary__edvuaz_0 + 1 | 0;
      composite.i1z(tmp_0, _unary__edvuaz_0, this.k22_1, v);
    }
    composite.r1x(descriptor);
  }
  i1t(encoder, value) {
    return this.g21(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
}
class HashMapSerializer extends MapLikeSerializer {
  constructor(kSerializer, vSerializer) {
    super(kSerializer, vSerializer);
    this.a22_1 = new HashMapClassDesc(kSerializer.h1t(), vSerializer.h1t());
  }
  h1t() {
    return this.a22_1;
  }
  b22(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  c22(_this__u8e3s4) {
    return this.b22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  d22(_this__u8e3s4) {
    // Inline function 'kotlin.collections.iterator' call
    return _this__u8e3s4.l1().y();
  }
  e22(_this__u8e3s4) {
    return this.d22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  r20() {
    return HashMap.l8();
  }
  f22(_this__u8e3s4) {
    return imul(_this__u8e3s4.b1(), 2);
  }
  t20(_this__u8e3s4) {
    return this.f22(_this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : THROW_CCE());
  }
  g22(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  v20(_this__u8e3s4) {
    return this.g22(_this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : THROW_CCE());
  }
  h22(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? HashMap.a9(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  x20(_this__u8e3s4) {
    return this.h22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  i22(_this__u8e3s4, size) {
  }
  z20(_this__u8e3s4, size) {
    return this.i22(_this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : THROW_CCE(), size);
  }
}
class LinkedHashMapSerializer extends MapLikeSerializer {
  constructor(kSerializer, vSerializer) {
    super(kSerializer, vSerializer);
    this.p22_1 = new LinkedHashMapClassDesc(kSerializer.h1t(), vSerializer.h1t());
  }
  h1t() {
    return this.p22_1;
  }
  b22(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  c22(_this__u8e3s4) {
    return this.b22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  d22(_this__u8e3s4) {
    // Inline function 'kotlin.collections.iterator' call
    return _this__u8e3s4.l1().y();
  }
  e22(_this__u8e3s4) {
    return this.d22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  r20() {
    return LinkedHashMap.hc();
  }
  q22(_this__u8e3s4) {
    return imul(_this__u8e3s4.b1(), 2);
  }
  t20(_this__u8e3s4) {
    return this.q22(_this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : THROW_CCE());
  }
  r22(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  v20(_this__u8e3s4) {
    return this.r22(_this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : THROW_CCE());
  }
  h22(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? LinkedHashMap.jc(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  x20(_this__u8e3s4) {
    return this.h22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  s22(_this__u8e3s4, size) {
  }
  z20(_this__u8e3s4, size) {
    return this.s22(_this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : THROW_CCE(), size);
  }
}
class ReferenceArraySerializer extends CollectionLikeSerializer {
  constructor(kClass, eSerializer) {
    super(eSerializer);
    this.u22_1 = kClass;
    this.v22_1 = new ArrayClassDesc(eSerializer.h1t());
  }
  h1t() {
    return this.v22_1;
  }
  w22(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  c22(_this__u8e3s4) {
    return this.w22((!(_this__u8e3s4 == null) ? isArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  x22(_this__u8e3s4) {
    return arrayIterator(_this__u8e3s4);
  }
  e22(_this__u8e3s4) {
    return this.x22((!(_this__u8e3s4 == null) ? isArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  r20() {
    // Inline function 'kotlin.collections.arrayListOf' call
    return ArrayList.k();
  }
  y22(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  t20(_this__u8e3s4) {
    return this.y22(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
  }
  z22(_this__u8e3s4) {
    return toNativeArrayImpl(_this__u8e3s4, this.u22_1);
  }
  v20(_this__u8e3s4) {
    return this.z22(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
  }
  a23(_this__u8e3s4) {
    return ArrayList.h(asList(_this__u8e3s4));
  }
  x20(_this__u8e3s4) {
    return this.a23((!(_this__u8e3s4 == null) ? isArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  b23(_this__u8e3s4, size) {
    return _this__u8e3s4.y7(size);
  }
  z20(_this__u8e3s4, size) {
    return this.b23(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE(), size);
  }
  c23(_this__u8e3s4, index, element) {
    _this__u8e3s4.d3(index, element);
  }
  b21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE();
    return this.c23(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class PrimitiveArraySerializer extends CollectionLikeSerializer {
  constructor(primitiveSerializer) {
    super(primitiveSerializer);
    this.e23_1 = new PrimitiveArrayDescriptor(primitiveSerializer.h1t());
  }
  h1t() {
    return this.e23_1;
  }
  f23(_this__u8e3s4) {
    return _this__u8e3s4.g23();
  }
  t20(_this__u8e3s4) {
    return this.f23(_this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE());
  }
  h23(_this__u8e3s4) {
    return _this__u8e3s4.i23();
  }
  v20(_this__u8e3s4) {
    return this.h23(_this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE());
  }
  j23(_this__u8e3s4, size) {
    return _this__u8e3s4.k23(size);
  }
  z20(_this__u8e3s4, size) {
    return this.j23(_this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE(), size);
  }
  l23(_this__u8e3s4) {
    var message = 'This method lead to boxing and must not be used, use writeContents instead';
    throw IllegalStateException.t4(toString(message));
  }
  e22(_this__u8e3s4) {
    return this.l23((_this__u8e3s4 == null ? true : !(_this__u8e3s4 == null)) ? _this__u8e3s4 : THROW_CCE());
  }
  m23(_this__u8e3s4, index, element) {
    var message = 'This method lead to boxing and must not be used, use Builder.append instead';
    throw IllegalStateException.t4(toString(message));
  }
  b21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE();
    return this.m23(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
  r20() {
    return this.x20(this.n23());
  }
  q23(encoder, value) {
    var size = this.c22(value);
    // Inline function 'kotlinx.serialization.encoding.encodeCollection' call
    var descriptor = this.e23_1;
    var composite = encoder.n1z(descriptor, size);
    this.p23(composite, value, size);
    composite.r1x(descriptor);
  }
  i1t(encoder, value) {
    return this.q23(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  g21(encoder, value) {
    return this.q23(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  j1t(decoder) {
    return this.k21(decoder, null);
  }
}
class PrimitiveArrayBuilder {
  r23(requiredCapacity, $super) {
    requiredCapacity = requiredCapacity === VOID ? this.g23() + 1 | 0 : requiredCapacity;
    var tmp;
    if ($super === VOID) {
      this.k23(requiredCapacity);
      tmp = Unit_instance;
    } else {
      tmp = $super.k23.call(this, requiredCapacity);
    }
    return tmp;
  }
}
class Companion {
  constructor() {
    Companion_instance_0 = this;
    this.s23_1 = longArray(0);
  }
}
class ElementMarker {
  constructor(descriptor, readIfAbsent) {
    Companion_getInstance_7();
    this.t23_1 = descriptor;
    this.u23_1 = readIfAbsent;
    var elementsCount = this.t23_1.w1v();
    if (elementsCount <= 64) {
      var tmp = this;
      var tmp_0;
      if (elementsCount === 64) {
        tmp_0 = new Long(0, 0);
      } else {
        tmp_0 = (new Long(-1, -1)).e4(elementsCount);
      }
      tmp.v23_1 = tmp_0;
      this.w23_1 = Companion_getInstance_7().s23_1;
    } else {
      this.v23_1 = new Long(0, 0);
      this.w23_1 = prepareHighMarksArray(this, elementsCount);
    }
  }
  x23(index) {
    if (index < 64) {
      this.v23_1 = this.v23_1.i4((new Long(1, 0)).e4(index));
    } else {
      markHigh(this, index);
    }
  }
  y23() {
    var elementsCount = this.t23_1.w1v();
    while (!this.v23_1.equals(new Long(-1, -1))) {
      var index = countTrailingZeroBits(this.v23_1.c4());
      this.v23_1 = this.v23_1.i4((new Long(1, 0)).e4(index));
      if (this.u23_1(this.t23_1, index)) {
        return index;
      }
    }
    if (elementsCount > 64) {
      return nextUnmarkedHighIndex(this);
    }
    return -1;
  }
}
class EnumSerializer {
  constructor(serialName, values) {
    this.z23_1 = values;
    this.a24_1 = null;
    var tmp = this;
    tmp.b24_1 = lazy_0(EnumSerializer$descriptor$delegate$lambda(this, serialName));
  }
  h1t() {
    var tmp0 = this.b24_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory_1();
    return tmp0.n1();
  }
  p24(encoder, value) {
    var index = indexOf(this.z23_1, value);
    if (index === -1) {
      throw SerializationException.t1u(toString(value) + ' is not a valid enum ' + this.h1t().k1u() + ', ' + ('must be one of ' + contentToString(this.z23_1)));
    }
    encoder.w1y(this.h1t(), index);
  }
  i1t(encoder, value) {
    return this.p24(encoder, value instanceof Enum ? value : THROW_CCE());
  }
  j1t(decoder) {
    var index = decoder.m1x(this.h1t());
    if (!(0 <= index ? index <= (this.z23_1.length - 1 | 0) : false)) {
      throw SerializationException.t1u('' + index + ' is not among valid ' + this.h1t().k1u() + ' enum values, ' + ('values size is ' + this.z23_1.length));
    }
    return this.z23_1[index];
  }
  toString() {
    return 'kotlinx.serialization.internal.EnumSerializer<' + this.h1t().k1u() + '>';
  }
}
class PluginGeneratedSerialDescriptor {
  constructor(serialName, generatedSerializer, elementsCount) {
    generatedSerializer = generatedSerializer === VOID ? null : generatedSerializer;
    this.c24_1 = serialName;
    this.d24_1 = generatedSerializer;
    this.e24_1 = elementsCount;
    this.f24_1 = -1;
    var tmp = this;
    var tmp_0 = 0;
    var tmp_1 = this.e24_1;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_2 = Array(tmp_1);
    while (tmp_0 < tmp_1) {
      tmp_2[tmp_0] = '[UNINITIALIZED]';
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.g24_1 = tmp_2;
    var tmp_3 = this;
    // Inline function 'kotlin.arrayOfNulls' call
    var size = this.e24_1;
    tmp_3.h24_1 = Array(size);
    this.i24_1 = null;
    this.j24_1 = booleanArray(this.e24_1);
    this.k24_1 = emptyMap();
    var tmp_4 = this;
    var tmp_5 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp_4.l24_1 = lazy(tmp_5, PluginGeneratedSerialDescriptor$childSerializers$delegate$lambda(this));
    var tmp_6 = this;
    var tmp_7 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp_6.m24_1 = lazy(tmp_7, PluginGeneratedSerialDescriptor$typeParameterDescriptors$delegate$lambda(this));
    var tmp_8 = this;
    var tmp_9 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp_8.n24_1 = lazy(tmp_9, PluginGeneratedSerialDescriptor$_hashCode$delegate$lambda(this));
  }
  k1u() {
    return this.c24_1;
  }
  w1v() {
    return this.e24_1;
  }
  u1v() {
    return CLASS_getInstance();
  }
  x1v() {
    var tmp0_elvis_lhs = this.i24_1;
    return tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  }
  z1w() {
    return this.k24_1.i3();
  }
  e25() {
    var tmp0 = this.m24_1;
    // Inline function 'kotlin.getValue' call
    typeParameterDescriptors$factory();
    return tmp0.n1();
  }
  f25(name, isOptional) {
    this.f24_1 = this.f24_1 + 1 | 0;
    this.g24_1[this.f24_1] = name;
    this.j24_1[this.f24_1] = isOptional;
    this.h24_1[this.f24_1] = null;
    if (this.f24_1 === (this.e24_1 - 1 | 0)) {
      this.k24_1 = buildIndices(this);
    }
  }
  o24(name, isOptional, $super) {
    isOptional = isOptional === VOID ? false : isOptional;
    var tmp;
    if ($super === VOID) {
      this.f25(name, isOptional);
      tmp = Unit_instance;
    } else {
      tmp = $super.f25.call(this, name, isOptional);
    }
    return tmp;
  }
  b1w(index) {
    return getChecked(_get_childSerializers__7vnyfa(this), index).h1t();
  }
  c1w(index) {
    return getChecked_0(this.j24_1, index);
  }
  a1w(index) {
    var tmp0_elvis_lhs = getChecked(this.h24_1, index);
    return tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  }
  y1v(index) {
    return getChecked(this.g24_1, index);
  }
  z1v(name) {
    var tmp0_elvis_lhs = this.k24_1.h3(name);
    return tmp0_elvis_lhs == null ? -3 : tmp0_elvis_lhs;
  }
  equals(other) {
    var tmp$ret$0;
    $l$block_5: {
      // Inline function 'kotlinx.serialization.internal.equalsImpl' call
      if (this === other) {
        tmp$ret$0 = true;
        break $l$block_5;
      }
      if (!(other instanceof PluginGeneratedSerialDescriptor)) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.k1u() === other.k1u())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!contentEquals(this.e25(), other.e25())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.w1v() === other.w1v())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      var inductionVariable = 0;
      var last = this.w1v();
      if (inductionVariable < last)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(this.b1w(index).k1u() === other.b1w(index).k1u())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
          if (!equals(this.b1w(index).u1v(), other.b1w(index).u1v())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
        }
         while (inductionVariable < last);
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  }
  hashCode() {
    return _get__hashCode__tgwhef_0(this);
  }
  toString() {
    return toStringImpl(this);
  }
}
class EnumDescriptor extends PluginGeneratedSerialDescriptor {
  constructor(name, elementsCount) {
    super(name, VOID, elementsCount);
    this.c25_1 = ENUM_getInstance();
    var tmp = this;
    tmp.d25_1 = lazy_0(EnumDescriptor$elementDescriptors$delegate$lambda(elementsCount, name, this));
  }
  u1v() {
    return this.c25_1;
  }
  b1w(index) {
    return getChecked(_get_elementDescriptors__y23q9p(this), index);
  }
  equals(other) {
    if (this === other)
      return true;
    if (other == null)
      return false;
    if (!(!(other == null) ? isInterface(other, SerialDescriptor) : false))
      return false;
    if (!(other.u1v() === ENUM_getInstance()))
      return false;
    if (!(this.k1u() === other.k1u()))
      return false;
    if (!equals(cachedSerialNames(this), cachedSerialNames(other)))
      return false;
    return true;
  }
  toString() {
    return joinToString(get_elementNames(this), ', ', this.k1u() + '(', ')');
  }
  hashCode() {
    var result = getStringHashCode(this.k1u());
    // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy' call
    // Inline function 'kotlin.collections.fold' call
    var accumulator = 1;
    var _iterator__ex2g4s = get_elementNames(this).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var hash = accumulator;
      var tmp = imul(31, hash);
      // Inline function 'kotlin.hashCode' call
      var tmp1_elvis_lhs = element == null ? null : hashCode(element);
      accumulator = tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
    }
    var elementsHashCode = accumulator;
    result = imul(31, result) + elementsHashCode | 0;
    return result;
  }
}
class InlineClassDescriptor extends PluginGeneratedSerialDescriptor {
  constructor(name, generatedSerializer) {
    super(name, generatedSerializer, 1);
    this.s25_1 = true;
  }
  v1v() {
    return this.s25_1;
  }
  hashCode() {
    return imul(super.hashCode(), 31);
  }
  equals(other) {
    var tmp$ret$0;
    $l$block_5: {
      // Inline function 'kotlinx.serialization.internal.equalsImpl' call
      if (this === other) {
        tmp$ret$0 = true;
        break $l$block_5;
      }
      if (!(other instanceof InlineClassDescriptor)) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.k1u() === other.k1u())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(other.s25_1 && contentEquals(this.e25(), other.e25()))) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.w1v() === other.w1v())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      var inductionVariable = 0;
      var last = this.w1v();
      if (inductionVariable < last)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(this.b1w(index).k1u() === other.b1w(index).k1u())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
          if (!equals(this.b1w(index).u1v(), other.b1w(index).u1v())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
        }
         while (inductionVariable < last);
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  }
}
class GeneratedSerializer {}
function typeParametersSerializers() {
  return get_EMPTY_SERIALIZER_ARRAY();
}
class InlinePrimitiveDescriptor$1 {
  constructor($primitiveSerializer) {
    this.t25_1 = $primitiveSerializer;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [this.t25_1];
  }
  h1t() {
    var message = 'unsupported';
    throw IllegalStateException.t4(toString(message));
  }
  i1t(encoder, value) {
    // Inline function 'kotlin.error' call
    var message = 'unsupported';
    throw IllegalStateException.t4(toString(message));
  }
  j1t(decoder) {
    // Inline function 'kotlin.error' call
    var message = 'unsupported';
    throw IllegalStateException.t4(toString(message));
  }
}
class NoOpEncoder extends AbstractEncoder {
  static x25() {
    NoOpEncoder_instance = null;
    var $this = this.j1y();
    NoOpEncoder_instance = $this;
    $this.w25_1 = EmptySerializersModule_0();
    return $this;
  }
  f1y() {
    return this.w25_1;
  }
  l1y(value) {
    return Unit_instance;
  }
  m1y() {
    return Unit_instance;
  }
  n1y(value) {
    return Unit_instance;
  }
  o1y(value) {
    return Unit_instance;
  }
  p1y(value) {
    return Unit_instance;
  }
  q1y(value) {
    return Unit_instance;
  }
  r1y(value) {
    return Unit_instance;
  }
  s1y(value) {
    return Unit_instance;
  }
  t1y(value) {
    return Unit_instance;
  }
  u1y(value) {
    return Unit_instance;
  }
  v1y(value) {
    return Unit_instance;
  }
  w1y(enumDescriptor, index) {
    return Unit_instance;
  }
}
class NothingSerialDescriptor {
  constructor() {
    NothingSerialDescriptor_instance = this;
    this.y25_1 = OBJECT_getInstance();
    this.z25_1 = 'kotlin.Nothing';
  }
  u1v() {
    return this.y25_1;
  }
  k1u() {
    return this.z25_1;
  }
  w1v() {
    return 0;
  }
  y1v(index) {
    error(this);
  }
  z1v(name) {
    error(this);
  }
  c1w(index) {
    error(this);
  }
  b1w(index) {
    error(this);
  }
  a1w(index) {
    error(this);
  }
  toString() {
    return 'NothingSerialDescriptor';
  }
  equals(other) {
    return this === other;
  }
  hashCode() {
    return getStringHashCode(this.z25_1) + imul(31, this.y25_1.hashCode()) | 0;
  }
}
class NullableSerializer {
  constructor(serializer) {
    this.a26_1 = serializer;
    this.b26_1 = new SerialDescriptorForNullable(this.a26_1.h1t());
  }
  h1t() {
    return this.b26_1;
  }
  c26(encoder, value) {
    if (!(value == null)) {
      encoder.m1z();
      encoder.j1z(this.a26_1, value);
    } else {
      encoder.m1y();
    }
  }
  i1t(encoder, value) {
    return this.c26(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  j1t(decoder) {
    return decoder.b1x() ? decoder.p1x(this.a26_1) : decoder.c1x();
  }
  equals(other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof NullableSerializer))
      THROW_CCE();
    if (!equals(this.a26_1, other.a26_1))
      return false;
    return true;
  }
  hashCode() {
    return hashCode(this.a26_1);
  }
}
class SerialDescriptorForNullable {
  constructor(original) {
    this.d1w_1 = original;
    this.e1w_1 = this.d1w_1.k1u() + '?';
    this.f1w_1 = cachedSerialNames(this.d1w_1);
  }
  k1u() {
    return this.e1w_1;
  }
  z1w() {
    return this.f1w_1;
  }
  q1v() {
    return true;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SerialDescriptorForNullable))
      return false;
    if (!equals(this.d1w_1, other.d1w_1))
      return false;
    return true;
  }
  toString() {
    return toString(this.d1w_1) + '?';
  }
  hashCode() {
    return imul(hashCode(this.d1w_1), 31);
  }
  u1v() {
    return this.d1w_1.u1v();
  }
  v1v() {
    return this.d1w_1.v1v();
  }
  w1v() {
    return this.d1w_1.w1v();
  }
  x1v() {
    return this.d1w_1.x1v();
  }
  y1v(index) {
    return this.d1w_1.y1v(index);
  }
  z1v(name) {
    return this.d1w_1.z1v(name);
  }
  a1w(index) {
    return this.d1w_1.a1w(index);
  }
  b1w(index) {
    return this.d1w_1.b1w(index);
  }
  c1w(index) {
    return this.d1w_1.c1w(index);
  }
}
class ObjectSerializer {
  constructor(serialName, objectInstance) {
    this.d26_1 = objectInstance;
    this.e26_1 = emptyList();
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.f26_1 = lazy(tmp_0, ObjectSerializer$descriptor$delegate$lambda(serialName, this));
  }
  h1t() {
    var tmp0 = this.f26_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory_2();
    return tmp0.n1();
  }
  z1t(encoder, value) {
    encoder.q1x(this.h1t()).r1x(this.h1t());
  }
  i1t(encoder, value) {
    return this.z1t(encoder, !(value == null) ? value : THROW_CCE());
  }
  j1t(decoder) {
    // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
    var descriptor = this.h1t();
    var composite = decoder.q1x(descriptor);
    var tmp$ret$0;
    $l$block_0: {
      if (composite.g1y()) {
        tmp$ret$0 = Unit_instance;
        break $l$block_0;
      }
      var index = composite.h1y(this.h1t());
      if (index === -1) {
        tmp$ret$0 = Unit_instance;
        break $l$block_0;
      } else
        throw SerializationException.t1u('Unexpected index ' + index);
    }
    var result = tmp$ret$0;
    composite.r1x(descriptor);
    return this.d26_1;
  }
}
class SerializerFactory {}
class CharArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    CharArraySerializer_instance = null;
    super(serializer_2(Companion_getInstance_1()));
    CharArraySerializer_instance = this;
  }
  j26(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  c22(_this__u8e3s4) {
    return this.j26((!(_this__u8e3s4 == null) ? isCharArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  k26(_this__u8e3s4) {
    return new CharArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.k26((!(_this__u8e3s4 == null) ? isCharArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  n23() {
    return charArray(0);
  }
  l26(decoder, index, builder, checkIndex) {
    builder.o26(decoder.z1x(this.e23_1, index));
  }
  i21(decoder, index, builder, checkIndex) {
    return this.l26(decoder, index, builder instanceof CharArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.l26(decoder, index, builder instanceof CharArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  p26(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.f1z(this.e23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.p26(encoder, (!(content == null) ? isCharArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class DoubleArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    DoubleArraySerializer_instance = null;
    super(serializer_3(DoubleCompanionObject_instance));
    DoubleArraySerializer_instance = this;
  }
  s26(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  c22(_this__u8e3s4) {
    return this.s26((!(_this__u8e3s4 == null) ? isDoubleArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  t26(_this__u8e3s4) {
    return new DoubleArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.t26((!(_this__u8e3s4 == null) ? isDoubleArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  n23() {
    return new Float64Array(0);
  }
  u26(decoder, index, builder, checkIndex) {
    builder.x26(decoder.y1x(this.e23_1, index));
  }
  i21(decoder, index, builder, checkIndex) {
    return this.u26(decoder, index, builder instanceof DoubleArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.u26(decoder, index, builder instanceof DoubleArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  y26(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.e1z(this.e23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.y26(encoder, (!(content == null) ? isDoubleArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class FloatArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    FloatArraySerializer_instance = null;
    super(serializer_4(FloatCompanionObject_instance));
    FloatArraySerializer_instance = this;
  }
  b27(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  c22(_this__u8e3s4) {
    return this.b27((!(_this__u8e3s4 == null) ? isFloatArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  c27(_this__u8e3s4) {
    return new FloatArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.c27((!(_this__u8e3s4 == null) ? isFloatArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  n23() {
    return new Float32Array(0);
  }
  d27(decoder, index, builder, checkIndex) {
    builder.g27(decoder.x1x(this.e23_1, index));
  }
  i21(decoder, index, builder, checkIndex) {
    return this.d27(decoder, index, builder instanceof FloatArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.d27(decoder, index, builder instanceof FloatArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  h27(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.d1z(this.e23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.h27(encoder, (!(content == null) ? isFloatArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class LongArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    LongArraySerializer_instance = null;
    super(serializer_5(Companion_getInstance_2()));
    LongArraySerializer_instance = this;
  }
  k27(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  c22(_this__u8e3s4) {
    return this.k27((!(_this__u8e3s4 == null) ? isLongArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  l27(_this__u8e3s4) {
    return new LongArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.l27((!(_this__u8e3s4 == null) ? isLongArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  n23() {
    return longArray(0);
  }
  m27(decoder, index, builder, checkIndex) {
    builder.p27(decoder.w1x(this.e23_1, index));
  }
  i21(decoder, index, builder, checkIndex) {
    return this.m27(decoder, index, builder instanceof LongArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.m27(decoder, index, builder instanceof LongArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  q27(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.c1z(this.e23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.q27(encoder, (!(content == null) ? isLongArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class ULongArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    ULongArraySerializer_instance = null;
    super(serializer_6(Companion_getInstance_3()));
    ULongArraySerializer_instance = this;
  }
  t27(_this__u8e3s4) {
    return _ULongArray___get_size__impl__ju6dtr(_this__u8e3s4);
  }
  c22(_this__u8e3s4) {
    return this.t27(_this__u8e3s4 instanceof ULongArray ? _this__u8e3s4.pt_1 : THROW_CCE());
  }
  u27(_this__u8e3s4) {
    return new ULongArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.u27(_this__u8e3s4 instanceof ULongArray ? _this__u8e3s4.pt_1 : THROW_CCE());
  }
  v27() {
    return _ULongArray___init__impl__twm1l3(0);
  }
  n23() {
    return new ULongArray(this.v27());
  }
  w27(decoder, index, builder, checkIndex) {
    // Inline function 'kotlin.toULong' call
    var this_0 = decoder.b1y(this.e23_1, index).h1x();
    var tmp$ret$0 = _ULong___init__impl__c78o9k(this_0);
    builder.z27(tmp$ret$0);
  }
  i21(decoder, index, builder, checkIndex) {
    return this.w27(decoder, index, builder instanceof ULongArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.w27(decoder, index, builder instanceof ULongArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  a28(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = encoder.h1z(this.e23_1, i);
        // Inline function 'kotlin.ULong.toLong' call
        var this_0 = ULongArray__get_impl_pr71q9(content, i);
        var tmp$ret$0 = _ULong___get_data__impl__fggpzb(this_0);
        tmp.r1y(tmp$ret$0);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.a28(encoder, content instanceof ULongArray ? content.pt_1 : THROW_CCE(), size);
  }
}
class IntArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    IntArraySerializer_instance = null;
    super(serializer_7(IntCompanionObject_instance));
    IntArraySerializer_instance = this;
  }
  d28(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  c22(_this__u8e3s4) {
    return this.d28((!(_this__u8e3s4 == null) ? isIntArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  e28(_this__u8e3s4) {
    return new IntArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.e28((!(_this__u8e3s4 == null) ? isIntArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  n23() {
    return new Int32Array(0);
  }
  f28(decoder, index, builder, checkIndex) {
    builder.i28(decoder.v1x(this.e23_1, index));
  }
  i21(decoder, index, builder, checkIndex) {
    return this.f28(decoder, index, builder instanceof IntArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.f28(decoder, index, builder instanceof IntArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  j28(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.b1z(this.e23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.j28(encoder, (!(content == null) ? isIntArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class UIntArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    UIntArraySerializer_instance = null;
    super(serializer_8(Companion_getInstance_4()));
    UIntArraySerializer_instance = this;
  }
  m28(_this__u8e3s4) {
    return _UIntArray___get_size__impl__r6l8ci(_this__u8e3s4);
  }
  c22(_this__u8e3s4) {
    return this.m28(_this__u8e3s4 instanceof UIntArray ? _this__u8e3s4.dt_1 : THROW_CCE());
  }
  n28(_this__u8e3s4) {
    return new UIntArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.n28(_this__u8e3s4 instanceof UIntArray ? _this__u8e3s4.dt_1 : THROW_CCE());
  }
  o28() {
    return _UIntArray___init__impl__ghjpc6(0);
  }
  n23() {
    return new UIntArray(this.o28());
  }
  p28(decoder, index, builder, checkIndex) {
    // Inline function 'kotlin.toUInt' call
    var this_0 = decoder.b1y(this.e23_1, index).g1x();
    var tmp$ret$0 = _UInt___init__impl__l7qpdl(this_0);
    builder.s28(tmp$ret$0);
  }
  i21(decoder, index, builder, checkIndex) {
    return this.p28(decoder, index, builder instanceof UIntArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.p28(decoder, index, builder instanceof UIntArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  t28(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = encoder.h1z(this.e23_1, i);
        // Inline function 'kotlin.UInt.toInt' call
        var this_0 = UIntArray__get_impl_gp5kza(content, i);
        var tmp$ret$0 = _UInt___get_data__impl__f0vqqw(this_0);
        tmp.q1y(tmp$ret$0);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.t28(encoder, content instanceof UIntArray ? content.dt_1 : THROW_CCE(), size);
  }
}
class ShortArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    ShortArraySerializer_instance = null;
    super(serializer_9(ShortCompanionObject_instance));
    ShortArraySerializer_instance = this;
  }
  w28(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  c22(_this__u8e3s4) {
    return this.w28((!(_this__u8e3s4 == null) ? isShortArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  x28(_this__u8e3s4) {
    return new ShortArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.x28((!(_this__u8e3s4 == null) ? isShortArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  n23() {
    return new Int16Array(0);
  }
  y28(decoder, index, builder, checkIndex) {
    builder.b29(decoder.u1x(this.e23_1, index));
  }
  i21(decoder, index, builder, checkIndex) {
    return this.y28(decoder, index, builder instanceof ShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.y28(decoder, index, builder instanceof ShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  c29(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.a1z(this.e23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.c29(encoder, (!(content == null) ? isShortArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class UShortArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    UShortArraySerializer_instance = null;
    super(serializer_10(Companion_getInstance_5()));
    UShortArraySerializer_instance = this;
  }
  f29(_this__u8e3s4) {
    return _UShortArray___get_size__impl__jqto1b(_this__u8e3s4);
  }
  c22(_this__u8e3s4) {
    return this.f29(_this__u8e3s4 instanceof UShortArray ? _this__u8e3s4.bu_1 : THROW_CCE());
  }
  g29(_this__u8e3s4) {
    return new UShortArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.g29(_this__u8e3s4 instanceof UShortArray ? _this__u8e3s4.bu_1 : THROW_CCE());
  }
  h29() {
    return _UShortArray___init__impl__9b26ef(0);
  }
  n23() {
    return new UShortArray(this.h29());
  }
  i29(decoder, index, builder, checkIndex) {
    // Inline function 'kotlin.toUShort' call
    var this_0 = decoder.b1y(this.e23_1, index).f1x();
    var tmp$ret$0 = _UShort___init__impl__jigrne(this_0);
    builder.l29(tmp$ret$0);
  }
  i21(decoder, index, builder, checkIndex) {
    return this.i29(decoder, index, builder instanceof UShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.i29(decoder, index, builder instanceof UShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  m29(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = encoder.h1z(this.e23_1, i);
        // Inline function 'kotlin.UShort.toShort' call
        var this_0 = UShortArray__get_impl_fnbhmx(content, i);
        var tmp$ret$0 = _UShort___get_data__impl__g0245(this_0);
        tmp.p1y(tmp$ret$0);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.m29(encoder, content instanceof UShortArray ? content.bu_1 : THROW_CCE(), size);
  }
}
class ByteArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    ByteArraySerializer_instance = null;
    super(serializer_11(ByteCompanionObject_instance));
    ByteArraySerializer_instance = this;
  }
  p29(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  c22(_this__u8e3s4) {
    return this.p29((!(_this__u8e3s4 == null) ? isByteArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  q29(_this__u8e3s4) {
    return new ByteArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.q29((!(_this__u8e3s4 == null) ? isByteArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  n23() {
    return new Int8Array(0);
  }
  r29(decoder, index, builder, checkIndex) {
    builder.u29(decoder.t1x(this.e23_1, index));
  }
  i21(decoder, index, builder, checkIndex) {
    return this.r29(decoder, index, builder instanceof ByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.r29(decoder, index, builder instanceof ByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  v29(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.z1y(this.e23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.v29(encoder, (!(content == null) ? isByteArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class UByteArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    UByteArraySerializer_instance = null;
    super(serializer_12(Companion_getInstance_6()));
    UByteArraySerializer_instance = this;
  }
  y29(_this__u8e3s4) {
    return _UByteArray___get_size__impl__h6pkdv(_this__u8e3s4);
  }
  c22(_this__u8e3s4) {
    return this.y29(_this__u8e3s4 instanceof UByteArray ? _this__u8e3s4.rs_1 : THROW_CCE());
  }
  z29(_this__u8e3s4) {
    return new UByteArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.z29(_this__u8e3s4 instanceof UByteArray ? _this__u8e3s4.rs_1 : THROW_CCE());
  }
  a2a() {
    return _UByteArray___init__impl__ip4y9n(0);
  }
  n23() {
    return new UByteArray(this.a2a());
  }
  b2a(decoder, index, builder, checkIndex) {
    // Inline function 'kotlin.toUByte' call
    var this_0 = decoder.b1y(this.e23_1, index).e1x();
    var tmp$ret$0 = _UByte___init__impl__g9hnc4(this_0);
    builder.e2a(tmp$ret$0);
  }
  i21(decoder, index, builder, checkIndex) {
    return this.b2a(decoder, index, builder instanceof UByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.b2a(decoder, index, builder instanceof UByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  f2a(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = encoder.h1z(this.e23_1, i);
        // Inline function 'kotlin.UByte.toByte' call
        var this_0 = UByteArray__get_impl_t5f3hv(content, i);
        var tmp$ret$0 = _UByte___get_data__impl__jof9qr(this_0);
        tmp.o1y(tmp$ret$0);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.f2a(encoder, content instanceof UByteArray ? content.rs_1 : THROW_CCE(), size);
  }
}
class BooleanArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    BooleanArraySerializer_instance = null;
    super(serializer_13(BooleanCompanionObject_instance));
    BooleanArraySerializer_instance = this;
  }
  i2a(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  c22(_this__u8e3s4) {
    return this.i2a((!(_this__u8e3s4 == null) ? isBooleanArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  j2a(_this__u8e3s4) {
    return new BooleanArrayBuilder(_this__u8e3s4);
  }
  x20(_this__u8e3s4) {
    return this.j2a((!(_this__u8e3s4 == null) ? isBooleanArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  n23() {
    return booleanArray(0);
  }
  k2a(decoder, index, builder, checkIndex) {
    builder.n2a(decoder.s1x(this.e23_1, index));
  }
  i21(decoder, index, builder, checkIndex) {
    return this.k2a(decoder, index, builder instanceof BooleanArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o23(decoder, index, builder, checkIndex) {
    return this.k2a(decoder, index, builder instanceof BooleanArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  o2a(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.y1y(this.e23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  p23(encoder, content, size) {
    return this.o2a(encoder, (!(content == null) ? isBooleanArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class CharArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.m26_1 = bufferWithData;
    this.n26_1 = bufferWithData.length;
    this.k23(10);
  }
  g23() {
    return this.n26_1;
  }
  k23(requiredCapacity) {
    if (this.m26_1.length < requiredCapacity)
      this.m26_1 = copyOf(this.m26_1, coerceAtLeast(requiredCapacity, imul(this.m26_1.length, 2)));
  }
  o26(c) {
    this.r23();
    var tmp = this.m26_1;
    var _unary__edvuaz = this.n26_1;
    this.n26_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  i23() {
    return copyOf(this.m26_1, this.n26_1);
  }
}
class DoubleArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.v26_1 = bufferWithData;
    this.w26_1 = bufferWithData.length;
    this.k23(10);
  }
  g23() {
    return this.w26_1;
  }
  k23(requiredCapacity) {
    if (this.v26_1.length < requiredCapacity)
      this.v26_1 = copyOf_0(this.v26_1, coerceAtLeast(requiredCapacity, imul(this.v26_1.length, 2)));
  }
  x26(c) {
    this.r23();
    var tmp = this.v26_1;
    var _unary__edvuaz = this.w26_1;
    this.w26_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  i23() {
    return copyOf_0(this.v26_1, this.w26_1);
  }
}
class FloatArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.e27_1 = bufferWithData;
    this.f27_1 = bufferWithData.length;
    this.k23(10);
  }
  g23() {
    return this.f27_1;
  }
  k23(requiredCapacity) {
    if (this.e27_1.length < requiredCapacity)
      this.e27_1 = copyOf_1(this.e27_1, coerceAtLeast(requiredCapacity, imul(this.e27_1.length, 2)));
  }
  g27(c) {
    this.r23();
    var tmp = this.e27_1;
    var _unary__edvuaz = this.f27_1;
    this.f27_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  i23() {
    return copyOf_1(this.e27_1, this.f27_1);
  }
}
class LongArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.n27_1 = bufferWithData;
    this.o27_1 = bufferWithData.length;
    this.k23(10);
  }
  g23() {
    return this.o27_1;
  }
  k23(requiredCapacity) {
    if (this.n27_1.length < requiredCapacity)
      this.n27_1 = copyOf_2(this.n27_1, coerceAtLeast(requiredCapacity, imul(this.n27_1.length, 2)));
  }
  p27(c) {
    this.r23();
    var tmp = this.n27_1;
    var _unary__edvuaz = this.o27_1;
    this.o27_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  i23() {
    return copyOf_2(this.n27_1, this.o27_1);
  }
}
class ULongArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.x27_1 = bufferWithData;
    this.y27_1 = _ULongArray___get_size__impl__ju6dtr(bufferWithData);
    this.k23(10);
  }
  g23() {
    return this.y27_1;
  }
  k23(requiredCapacity) {
    if (_ULongArray___get_size__impl__ju6dtr(this.x27_1) < requiredCapacity) {
      var tmp = this;
      var tmp0 = this.x27_1;
      // Inline function 'kotlin.collections.copyOf' call
      var newSize = coerceAtLeast(requiredCapacity, imul(_ULongArray___get_size__impl__ju6dtr(this.x27_1), 2));
      tmp.x27_1 = _ULongArray___init__impl__twm1l3_0(copyOf_2(_ULongArray___get_storage__impl__28e64j(tmp0), newSize));
    }
  }
  z27(c) {
    this.r23();
    var tmp = this.x27_1;
    var _unary__edvuaz = this.y27_1;
    this.y27_1 = _unary__edvuaz + 1 | 0;
    ULongArray__set_impl_z19mvh(tmp, _unary__edvuaz, c);
  }
  p2a() {
    var tmp0 = this.x27_1;
    // Inline function 'kotlin.collections.copyOf' call
    var newSize = this.y27_1;
    return _ULongArray___init__impl__twm1l3_0(copyOf_2(_ULongArray___get_storage__impl__28e64j(tmp0), newSize));
  }
  i23() {
    return new ULongArray(this.p2a());
  }
}
class IntArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.g28_1 = bufferWithData;
    this.h28_1 = bufferWithData.length;
    this.k23(10);
  }
  g23() {
    return this.h28_1;
  }
  k23(requiredCapacity) {
    if (this.g28_1.length < requiredCapacity)
      this.g28_1 = copyOf_3(this.g28_1, coerceAtLeast(requiredCapacity, imul(this.g28_1.length, 2)));
  }
  i28(c) {
    this.r23();
    var tmp = this.g28_1;
    var _unary__edvuaz = this.h28_1;
    this.h28_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  i23() {
    return copyOf_3(this.g28_1, this.h28_1);
  }
}
class UIntArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.q28_1 = bufferWithData;
    this.r28_1 = _UIntArray___get_size__impl__r6l8ci(bufferWithData);
    this.k23(10);
  }
  g23() {
    return this.r28_1;
  }
  k23(requiredCapacity) {
    if (_UIntArray___get_size__impl__r6l8ci(this.q28_1) < requiredCapacity) {
      var tmp = this;
      var tmp0 = this.q28_1;
      // Inline function 'kotlin.collections.copyOf' call
      var newSize = coerceAtLeast(requiredCapacity, imul(_UIntArray___get_size__impl__r6l8ci(this.q28_1), 2));
      tmp.q28_1 = _UIntArray___init__impl__ghjpc6_0(copyOf_3(_UIntArray___get_storage__impl__92a0v0(tmp0), newSize));
    }
  }
  s28(c) {
    this.r23();
    var tmp = this.q28_1;
    var _unary__edvuaz = this.r28_1;
    this.r28_1 = _unary__edvuaz + 1 | 0;
    UIntArray__set_impl_7f2zu2(tmp, _unary__edvuaz, c);
  }
  q2a() {
    var tmp0 = this.q28_1;
    // Inline function 'kotlin.collections.copyOf' call
    var newSize = this.r28_1;
    return _UIntArray___init__impl__ghjpc6_0(copyOf_3(_UIntArray___get_storage__impl__92a0v0(tmp0), newSize));
  }
  i23() {
    return new UIntArray(this.q2a());
  }
}
class ShortArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.z28_1 = bufferWithData;
    this.a29_1 = bufferWithData.length;
    this.k23(10);
  }
  g23() {
    return this.a29_1;
  }
  k23(requiredCapacity) {
    if (this.z28_1.length < requiredCapacity)
      this.z28_1 = copyOf_4(this.z28_1, coerceAtLeast(requiredCapacity, imul(this.z28_1.length, 2)));
  }
  b29(c) {
    this.r23();
    var tmp = this.z28_1;
    var _unary__edvuaz = this.a29_1;
    this.a29_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  i23() {
    return copyOf_4(this.z28_1, this.a29_1);
  }
}
class UShortArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.j29_1 = bufferWithData;
    this.k29_1 = _UShortArray___get_size__impl__jqto1b(bufferWithData);
    this.k23(10);
  }
  g23() {
    return this.k29_1;
  }
  k23(requiredCapacity) {
    if (_UShortArray___get_size__impl__jqto1b(this.j29_1) < requiredCapacity) {
      var tmp = this;
      var tmp0 = this.j29_1;
      // Inline function 'kotlin.collections.copyOf' call
      var newSize = coerceAtLeast(requiredCapacity, imul(_UShortArray___get_size__impl__jqto1b(this.j29_1), 2));
      tmp.j29_1 = _UShortArray___init__impl__9b26ef_0(copyOf_4(_UShortArray___get_storage__impl__t2jpv5(tmp0), newSize));
    }
  }
  l29(c) {
    this.r23();
    var tmp = this.j29_1;
    var _unary__edvuaz = this.k29_1;
    this.k29_1 = _unary__edvuaz + 1 | 0;
    UShortArray__set_impl_6d8whp(tmp, _unary__edvuaz, c);
  }
  r2a() {
    var tmp0 = this.j29_1;
    // Inline function 'kotlin.collections.copyOf' call
    var newSize = this.k29_1;
    return _UShortArray___init__impl__9b26ef_0(copyOf_4(_UShortArray___get_storage__impl__t2jpv5(tmp0), newSize));
  }
  i23() {
    return new UShortArray(this.r2a());
  }
}
class ByteArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.s29_1 = bufferWithData;
    this.t29_1 = bufferWithData.length;
    this.k23(10);
  }
  g23() {
    return this.t29_1;
  }
  k23(requiredCapacity) {
    if (this.s29_1.length < requiredCapacity)
      this.s29_1 = copyOf_5(this.s29_1, coerceAtLeast(requiredCapacity, imul(this.s29_1.length, 2)));
  }
  u29(c) {
    this.r23();
    var tmp = this.s29_1;
    var _unary__edvuaz = this.t29_1;
    this.t29_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  i23() {
    return copyOf_5(this.s29_1, this.t29_1);
  }
}
class UByteArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.c2a_1 = bufferWithData;
    this.d2a_1 = _UByteArray___get_size__impl__h6pkdv(bufferWithData);
    this.k23(10);
  }
  g23() {
    return this.d2a_1;
  }
  k23(requiredCapacity) {
    if (_UByteArray___get_size__impl__h6pkdv(this.c2a_1) < requiredCapacity) {
      var tmp = this;
      var tmp0 = this.c2a_1;
      // Inline function 'kotlin.collections.copyOf' call
      var newSize = coerceAtLeast(requiredCapacity, imul(_UByteArray___get_size__impl__h6pkdv(this.c2a_1), 2));
      tmp.c2a_1 = _UByteArray___init__impl__ip4y9n_0(copyOf_5(_UByteArray___get_storage__impl__d4kctt(tmp0), newSize));
    }
  }
  e2a(c) {
    this.r23();
    var tmp = this.c2a_1;
    var _unary__edvuaz = this.d2a_1;
    this.d2a_1 = _unary__edvuaz + 1 | 0;
    UByteArray__set_impl_jvcicn(tmp, _unary__edvuaz, c);
  }
  s2a() {
    var tmp0 = this.c2a_1;
    // Inline function 'kotlin.collections.copyOf' call
    var newSize = this.d2a_1;
    return _UByteArray___init__impl__ip4y9n_0(copyOf_5(_UByteArray___get_storage__impl__d4kctt(tmp0), newSize));
  }
  i23() {
    return new UByteArray(this.s2a());
  }
}
class BooleanArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.l2a_1 = bufferWithData;
    this.m2a_1 = bufferWithData.length;
    this.k23(10);
  }
  g23() {
    return this.m2a_1;
  }
  k23(requiredCapacity) {
    if (this.l2a_1.length < requiredCapacity)
      this.l2a_1 = copyOf_6(this.l2a_1, coerceAtLeast(requiredCapacity, imul(this.l2a_1.length, 2)));
  }
  n2a(c) {
    this.r23();
    var tmp = this.l2a_1;
    var _unary__edvuaz = this.m2a_1;
    this.m2a_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  i23() {
    return copyOf_6(this.l2a_1, this.m2a_1);
  }
}
class StringSerializer {
  constructor() {
    StringSerializer_instance = this;
    this.t2a_1 = new PrimitiveSerialDescriptor('kotlin.String', STRING_getInstance());
  }
  h1t() {
    return this.t2a_1;
  }
  u2a(encoder, value) {
    return encoder.v1y(value);
  }
  i1t(encoder, value) {
    return this.u2a(encoder, (!(value == null) ? typeof value === 'string' : false) ? value : THROW_CCE());
  }
  j1t(decoder) {
    return decoder.l1x();
  }
}
class CharSerializer {
  constructor() {
    CharSerializer_instance = this;
    this.v2a_1 = new PrimitiveSerialDescriptor('kotlin.Char', CHAR_getInstance());
  }
  h1t() {
    return this.v2a_1;
  }
  w2a(encoder, value) {
    return encoder.u1y(value);
  }
  i1t(encoder, value) {
    return this.w2a(encoder, value instanceof Char ? value.j2_1 : THROW_CCE());
  }
  x2a(decoder) {
    return decoder.k1x();
  }
  j1t(decoder) {
    return new Char(this.x2a(decoder));
  }
}
class DoubleSerializer {
  constructor() {
    DoubleSerializer_instance = this;
    this.y2a_1 = new PrimitiveSerialDescriptor('kotlin.Double', DOUBLE_getInstance());
  }
  h1t() {
    return this.y2a_1;
  }
  z2a(encoder, value) {
    return encoder.t1y(value);
  }
  i1t(encoder, value) {
    return this.z2a(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  j1t(decoder) {
    return decoder.j1x();
  }
}
class FloatSerializer {
  constructor() {
    FloatSerializer_instance = this;
    this.a2b_1 = new PrimitiveSerialDescriptor('kotlin.Float', FLOAT_getInstance());
  }
  h1t() {
    return this.a2b_1;
  }
  b2b(encoder, value) {
    return encoder.s1y(value);
  }
  i1t(encoder, value) {
    return this.b2b(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  j1t(decoder) {
    return decoder.i1x();
  }
}
class LongSerializer {
  constructor() {
    LongSerializer_instance = this;
    this.c2b_1 = new PrimitiveSerialDescriptor('kotlin.Long', LONG_getInstance());
  }
  h1t() {
    return this.c2b_1;
  }
  d2b(encoder, value) {
    return encoder.r1y(value);
  }
  i1t(encoder, value) {
    return this.d2b(encoder, value instanceof Long ? value : THROW_CCE());
  }
  j1t(decoder) {
    return decoder.h1x();
  }
}
class IntSerializer {
  constructor() {
    IntSerializer_instance = this;
    this.e2b_1 = new PrimitiveSerialDescriptor('kotlin.Int', INT_getInstance());
  }
  h1t() {
    return this.e2b_1;
  }
  f2b(encoder, value) {
    return encoder.q1y(value);
  }
  i1t(encoder, value) {
    return this.f2b(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  j1t(decoder) {
    return decoder.g1x();
  }
}
class ShortSerializer {
  constructor() {
    ShortSerializer_instance = this;
    this.g2b_1 = new PrimitiveSerialDescriptor('kotlin.Short', SHORT_getInstance());
  }
  h1t() {
    return this.g2b_1;
  }
  h2b(encoder, value) {
    return encoder.p1y(value);
  }
  i1t(encoder, value) {
    return this.h2b(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  j1t(decoder) {
    return decoder.f1x();
  }
}
class ByteSerializer {
  constructor() {
    ByteSerializer_instance = this;
    this.i2b_1 = new PrimitiveSerialDescriptor('kotlin.Byte', BYTE_getInstance());
  }
  h1t() {
    return this.i2b_1;
  }
  j2b(encoder, value) {
    return encoder.o1y(value);
  }
  i1t(encoder, value) {
    return this.j2b(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  j1t(decoder) {
    return decoder.e1x();
  }
}
class BooleanSerializer {
  constructor() {
    BooleanSerializer_instance = this;
    this.k2b_1 = new PrimitiveSerialDescriptor('kotlin.Boolean', BOOLEAN_getInstance());
  }
  h1t() {
    return this.k2b_1;
  }
  l2b(encoder, value) {
    return encoder.n1y(value);
  }
  i1t(encoder, value) {
    return this.l2b(encoder, (!(value == null) ? typeof value === 'boolean' : false) ? value : THROW_CCE());
  }
  j1t(decoder) {
    return decoder.d1x();
  }
}
class UnitSerializer {
  constructor() {
    UnitSerializer_instance = this;
    this.m2b_1 = new ObjectSerializer('kotlin.Unit', Unit_instance);
  }
  h1t() {
    return this.m2b_1.h1t();
  }
  n2b(encoder, value) {
    this.m2b_1.z1t(encoder, Unit_instance);
  }
  i1t(encoder, value) {
    return this.n2b(encoder, value instanceof Unit ? value : THROW_CCE());
  }
  o2b(decoder) {
    this.m2b_1.j1t(decoder);
  }
  j1t(decoder) {
    this.o2b(decoder);
    return Unit_instance;
  }
}
class PrimitiveSerialDescriptor {
  constructor(serialName, kind) {
    this.p2b_1 = serialName;
    this.q2b_1 = kind;
  }
  k1u() {
    return this.p2b_1;
  }
  u1v() {
    return this.q2b_1;
  }
  w1v() {
    return 0;
  }
  y1v(index) {
    error_0(this);
  }
  z1v(name) {
    error_0(this);
  }
  c1w(index) {
    error_0(this);
  }
  b1w(index) {
    error_0(this);
  }
  a1w(index) {
    error_0(this);
  }
  toString() {
    return 'PrimitiveDescriptor(' + this.p2b_1 + ')';
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof PrimitiveSerialDescriptor))
      return false;
    if (this.p2b_1 === other.p2b_1 && equals(this.q2b_1, other.q2b_1))
      return true;
    return false;
  }
  hashCode() {
    return getStringHashCode(this.p2b_1) + imul(31, this.q2b_1.hashCode()) | 0;
  }
}
class TaggedEncoder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.arrayListOf' call
    tmp.v2b_1 = ArrayList.k();
  }
  f1y() {
    return EmptySerializersModule_0();
  }
  y2b(tag, value) {
    throw SerializationException.t1u('Non-serializable ' + toString(getKClassFromExpression(value)) + ' is not supported by ' + toString(getKClassFromExpression(this)) + ' encoder');
  }
  z2b(tag) {
  }
  a2c(tag) {
    throw SerializationException.t1u('null is not supported');
  }
  b2c(tag, value) {
    return this.y2b(tag, value);
  }
  c2c(tag, value) {
    return this.y2b(tag, value);
  }
  d2c(tag, value) {
    return this.y2b(tag, value);
  }
  e2c(tag, value) {
    return this.y2b(tag, value);
  }
  f2c(tag, value) {
    return this.y2b(tag, value);
  }
  g2c(tag, value) {
    return this.y2b(tag, value);
  }
  h2c(tag, value) {
    return this.y2b(tag, value);
  }
  i2c(tag, value) {
    return this.y2b(tag, new Char(value));
  }
  j2c(tag, value) {
    return this.y2b(tag, value);
  }
  k2c(tag, enumDescriptor, ordinal) {
    return this.y2b(tag, ordinal);
  }
  l2c(tag, inlineDescriptor) {
    // Inline function 'kotlin.apply' call
    this.o2c(tag);
    return this;
  }
  x1y(descriptor) {
    return this.l2c(this.p2c(), descriptor);
  }
  m1z() {
    return this.z2b(this.n2c());
  }
  m1y() {
    return this.a2c(this.p2c());
  }
  n1y(value) {
    return this.h2c(this.p2c(), value);
  }
  o1y(value) {
    return this.c2c(this.p2c(), value);
  }
  p1y(value) {
    return this.d2c(this.p2c(), value);
  }
  q1y(value) {
    return this.b2c(this.p2c(), value);
  }
  r1y(value) {
    return this.e2c(this.p2c(), value);
  }
  s1y(value) {
    return this.f2c(this.p2c(), value);
  }
  t1y(value) {
    return this.g2c(this.p2c(), value);
  }
  u1y(value) {
    return this.i2c(this.p2c(), value);
  }
  v1y(value) {
    return this.j2c(this.p2c(), value);
  }
  w1y(enumDescriptor, index) {
    return this.k2c(this.p2c(), enumDescriptor, index);
  }
  q1x(descriptor) {
    return this;
  }
  r1x(descriptor) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this.v2b_1.h1()) {
      this.p2c();
    }
    this.m2c(descriptor);
  }
  m2c(descriptor) {
  }
  y1y(descriptor, index, value) {
    return this.h2c(this.s2b(descriptor, index), value);
  }
  z1y(descriptor, index, value) {
    return this.c2c(this.s2b(descriptor, index), value);
  }
  a1z(descriptor, index, value) {
    return this.d2c(this.s2b(descriptor, index), value);
  }
  b1z(descriptor, index, value) {
    return this.b2c(this.s2b(descriptor, index), value);
  }
  c1z(descriptor, index, value) {
    return this.e2c(this.s2b(descriptor, index), value);
  }
  d1z(descriptor, index, value) {
    return this.f2c(this.s2b(descriptor, index), value);
  }
  e1z(descriptor, index, value) {
    return this.g2c(this.s2b(descriptor, index), value);
  }
  f1z(descriptor, index, value) {
    return this.i2c(this.s2b(descriptor, index), value);
  }
  g1z(descriptor, index, value) {
    return this.j2c(this.s2b(descriptor, index), value);
  }
  h1z(descriptor, index) {
    return this.l2c(this.s2b(descriptor, index), descriptor.b1w(index));
  }
  i1z(descriptor, index, serializer, value) {
    if (encodeElement(this, descriptor, index)) {
      this.j1z(serializer, value);
    }
  }
  k1z(descriptor, index, serializer, value) {
    if (encodeElement(this, descriptor, index)) {
      this.l1z(serializer, value);
    }
  }
  n2c() {
    return last(this.v2b_1);
  }
  w2b() {
    return lastOrNull(this.v2b_1);
  }
  o2c(name) {
    this.v2b_1.l(name);
  }
  p2c() {
    var tmp;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this.v2b_1.h1()) {
      tmp = this.v2b_1.e3(get_lastIndex_0(this.v2b_1));
    } else {
      throw SerializationException.t1u('No tag in stack for requested element');
    }
    return tmp;
  }
}
class NamedValueEncoder extends TaggedEncoder {
  s2b(_this__u8e3s4, index) {
    return this.u2b(this.t2b(_this__u8e3s4, index));
  }
  u2b(nestedName) {
    var tmp0_elvis_lhs = this.w2b();
    return this.x2b(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs, nestedName);
  }
  t2b(descriptor, index) {
    return descriptor.y1v(index);
  }
  x2b(parentName, childName) {
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(parentName) === 0) {
      tmp = childName;
    } else {
      tmp = parentName + '.' + childName;
    }
    return tmp;
  }
}
class TaggedDecoder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.arrayListOf' call
    tmp.s2c_1 = ArrayList.k();
    this.t2c_1 = false;
  }
  f1y() {
    return EmptySerializersModule_0();
  }
  v2c(tag) {
    throw SerializationException.t1u(toString(getKClassFromExpression(this)) + " can't retrieve untyped values");
  }
  w2c(tag) {
    return true;
  }
  x2c(tag) {
    var tmp = this.v2c(tag);
    return typeof tmp === 'boolean' ? tmp : THROW_CCE();
  }
  y2c(tag) {
    var tmp = this.v2c(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  z2c(tag) {
    var tmp = this.v2c(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  a2d(tag) {
    var tmp = this.v2c(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  b2d(tag) {
    var tmp = this.v2c(tag);
    return tmp instanceof Long ? tmp : THROW_CCE();
  }
  c2d(tag) {
    var tmp = this.v2c(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  d2d(tag) {
    var tmp = this.v2c(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  e2d(tag) {
    var tmp = this.v2c(tag);
    return tmp instanceof Char ? tmp.j2_1 : THROW_CCE();
  }
  f2d(tag) {
    var tmp = this.v2c(tag);
    return typeof tmp === 'string' ? tmp : THROW_CCE();
  }
  g2d(tag, enumDescriptor) {
    var tmp = this.v2c(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  h2d(tag, inlineDescriptor) {
    // Inline function 'kotlin.apply' call
    this.o2c(tag);
    return this;
  }
  o1x(deserializer, previousValue) {
    return this.p1x(deserializer);
  }
  n1x(descriptor) {
    return this.h2d(this.p2c(), descriptor);
  }
  b1x() {
    var tmp0_elvis_lhs = this.w2b();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return false;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var currentTag = tmp;
    return this.w2c(currentTag);
  }
  c1x() {
    return null;
  }
  d1x() {
    return this.x2c(this.p2c());
  }
  e1x() {
    return this.y2c(this.p2c());
  }
  f1x() {
    return this.z2c(this.p2c());
  }
  g1x() {
    return this.a2d(this.p2c());
  }
  h1x() {
    return this.b2d(this.p2c());
  }
  i1x() {
    return this.c2d(this.p2c());
  }
  j1x() {
    return this.d2d(this.p2c());
  }
  k1x() {
    return this.e2d(this.p2c());
  }
  l1x() {
    return this.f2d(this.p2c());
  }
  m1x(enumDescriptor) {
    return this.g2d(this.p2c(), enumDescriptor);
  }
  q1x(descriptor) {
    return this;
  }
  r1x(descriptor) {
  }
  s1x(descriptor, index) {
    return this.x2c(this.s2b(descriptor, index));
  }
  t1x(descriptor, index) {
    return this.y2c(this.s2b(descriptor, index));
  }
  u1x(descriptor, index) {
    return this.z2c(this.s2b(descriptor, index));
  }
  v1x(descriptor, index) {
    return this.a2d(this.s2b(descriptor, index));
  }
  w1x(descriptor, index) {
    return this.b2d(this.s2b(descriptor, index));
  }
  x1x(descriptor, index) {
    return this.c2d(this.s2b(descriptor, index));
  }
  y1x(descriptor, index) {
    return this.d2d(this.s2b(descriptor, index));
  }
  z1x(descriptor, index) {
    return this.e2d(this.s2b(descriptor, index));
  }
  a1y(descriptor, index) {
    return this.f2d(this.s2b(descriptor, index));
  }
  b1y(descriptor, index) {
    return this.h2d(this.s2b(descriptor, index), descriptor.b1w(index));
  }
  c1y(descriptor, index, deserializer, previousValue) {
    var tmp = this.s2b(descriptor, index);
    return tagBlock(this, tmp, TaggedDecoder$decodeSerializableElement$lambda(this, deserializer, previousValue));
  }
  e1y(descriptor, index, deserializer, previousValue) {
    var tmp = this.s2b(descriptor, index);
    return tagBlock(this, tmp, TaggedDecoder$decodeNullableSerializableElement$lambda(this, deserializer, previousValue));
  }
  w2b() {
    return lastOrNull(this.s2c_1);
  }
  o2c(name) {
    this.s2c_1.l(name);
  }
  p2c() {
    var r = this.s2c_1.e3(get_lastIndex_0(this.s2c_1));
    this.t2c_1 = true;
    return r;
  }
}
class NamedValueDecoder extends TaggedDecoder {
  s2b(_this__u8e3s4, index) {
    return this.u2b(this.t2b(_this__u8e3s4, index));
  }
  u2b(nestedName) {
    var tmp0_elvis_lhs = this.w2b();
    return this.x2b(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs, nestedName);
  }
  t2b(descriptor, index) {
    return descriptor.y1v(index);
  }
  x2b(parentName, childName) {
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(parentName) === 0) {
      tmp = childName;
    } else {
      tmp = parentName + '.' + childName;
    }
    return tmp;
  }
  u2c() {
    return this.s2c_1.h1() ? '$' : joinToString(this.s2c_1, '.', '$.');
  }
}
class MapEntry {
  constructor(key, value) {
    this.i2d_1 = key;
    this.j2d_1 = value;
  }
  m1() {
    return this.i2d_1;
  }
  n1() {
    return this.j2d_1;
  }
  toString() {
    return 'MapEntry(key=' + toString_0(this.i2d_1) + ', value=' + toString_0(this.j2d_1) + ')';
  }
  hashCode() {
    var result = this.i2d_1 == null ? 0 : hashCode(this.i2d_1);
    result = imul(result, 31) + (this.j2d_1 == null ? 0 : hashCode(this.j2d_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MapEntry))
      return false;
    var tmp0_other_with_cast = other instanceof MapEntry ? other : THROW_CCE();
    if (!equals(this.i2d_1, tmp0_other_with_cast.i2d_1))
      return false;
    if (!equals(this.j2d_1, tmp0_other_with_cast.j2d_1))
      return false;
    return true;
  }
}
class KeyValueSerializer {
  constructor(keySerializer, valueSerializer) {
    this.s2d_1 = keySerializer;
    this.t2d_1 = valueSerializer;
  }
  u2d(encoder, value) {
    var structuredEncoder = encoder.q1x(this.h1t());
    structuredEncoder.i1z(this.h1t(), 0, this.s2d_1, this.o2d(value));
    structuredEncoder.i1z(this.h1t(), 1, this.t2d_1, this.q2d(value));
    structuredEncoder.r1x(this.h1t());
  }
  i1t(encoder, value) {
    return this.u2d(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  j1t(decoder) {
    // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
    var descriptor = this.h1t();
    var composite = decoder.q1x(descriptor);
    var tmp$ret$0;
    $l$block: {
      if (composite.g1y()) {
        var key = composite.d1y(this.h1t(), 0, this.s2d_1);
        var value = composite.d1y(this.h1t(), 1, this.t2d_1);
        tmp$ret$0 = this.r2d(key, value);
        break $l$block;
      }
      var key_0 = get_NULL();
      var value_0 = get_NULL();
      mainLoop: while (true) {
        var idx = composite.h1y(this.h1t());
        switch (idx) {
          case -1:
            break mainLoop;
          case 0:
            key_0 = composite.d1y(this.h1t(), 0, this.s2d_1);
            break;
          case 1:
            value_0 = composite.d1y(this.h1t(), 1, this.t2d_1);
            break;
          default:
            throw SerializationException.t1u('Invalid index: ' + idx);
        }
      }
      if (key_0 === get_NULL())
        throw SerializationException.t1u("Element 'key' is missing");
      if (value_0 === get_NULL())
        throw SerializationException.t1u("Element 'value' is missing");
      var tmp = (key_0 == null ? true : !(key_0 == null)) ? key_0 : THROW_CCE();
      tmp$ret$0 = this.r2d(tmp, (value_0 == null ? true : !(value_0 == null)) ? value_0 : THROW_CCE());
    }
    var result = tmp$ret$0;
    composite.r1x(descriptor);
    return result;
  }
}
class MapEntrySerializer extends KeyValueSerializer {
  constructor(keySerializer, valueSerializer) {
    super(keySerializer, valueSerializer);
    var tmp = this;
    var tmp_0 = MAP_getInstance();
    tmp.m2d_1 = buildSerialDescriptor('kotlin.collections.Map.Entry', tmp_0, [], MapEntrySerializer$descriptor$lambda(keySerializer, valueSerializer));
  }
  h1t() {
    return this.m2d_1;
  }
  n2d(_this__u8e3s4) {
    return _this__u8e3s4.m1();
  }
  o2d(_this__u8e3s4) {
    return this.n2d((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Entry) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  p2d(_this__u8e3s4) {
    return _this__u8e3s4.n1();
  }
  q2d(_this__u8e3s4) {
    return this.p2d((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Entry) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  r2d(key, value) {
    return new MapEntry(key, value);
  }
}
class PairSerializer extends KeyValueSerializer {
  constructor(keySerializer, valueSerializer) {
    super(keySerializer, valueSerializer);
    var tmp = this;
    tmp.x2d_1 = buildClassSerialDescriptor('kotlin.Pair', [], PairSerializer$descriptor$lambda(keySerializer, valueSerializer));
  }
  h1t() {
    return this.x2d_1;
  }
  y2d(_this__u8e3s4) {
    return _this__u8e3s4.rl_1;
  }
  o2d(_this__u8e3s4) {
    return this.y2d(_this__u8e3s4 instanceof Pair ? _this__u8e3s4 : THROW_CCE());
  }
  z2d(_this__u8e3s4) {
    return _this__u8e3s4.sl_1;
  }
  q2d(_this__u8e3s4) {
    return this.z2d(_this__u8e3s4 instanceof Pair ? _this__u8e3s4 : THROW_CCE());
  }
  r2d(key, value) {
    return to(key, value);
  }
}
class TripleSerializer {
  constructor(aSerializer, bSerializer, cSerializer) {
    this.a2e_1 = aSerializer;
    this.b2e_1 = bSerializer;
    this.c2e_1 = cSerializer;
    var tmp = this;
    tmp.d2e_1 = buildClassSerialDescriptor('kotlin.Triple', [], TripleSerializer$descriptor$lambda(this));
  }
  h1t() {
    return this.d2e_1;
  }
  e2e(encoder, value) {
    var structuredEncoder = encoder.q1x(this.d2e_1);
    structuredEncoder.i1z(this.d2e_1, 0, this.a2e_1, value.as_1);
    structuredEncoder.i1z(this.d2e_1, 1, this.b2e_1, value.bs_1);
    structuredEncoder.i1z(this.d2e_1, 2, this.c2e_1, value.cs_1);
    structuredEncoder.r1x(this.d2e_1);
  }
  i1t(encoder, value) {
    return this.e2e(encoder, value instanceof Triple ? value : THROW_CCE());
  }
  j1t(decoder) {
    var composite = decoder.q1x(this.d2e_1);
    if (composite.g1y()) {
      return decodeSequentially_1(this, composite);
    }
    return decodeStructure(this, composite);
  }
}
class ULongSerializer {
  constructor() {
    ULongSerializer_instance = this;
    this.f2e_1 = InlinePrimitiveDescriptor('kotlin.ULong', serializer_5(Companion_getInstance_2()));
  }
  h1t() {
    return this.f2e_1;
  }
  g2e(encoder, value) {
    var tmp = encoder.x1y(this.f2e_1);
    // Inline function 'kotlin.ULong.toLong' call
    var tmp$ret$0 = _ULong___get_data__impl__fggpzb(value);
    tmp.r1y(tmp$ret$0);
  }
  i1t(encoder, value) {
    return this.g2e(encoder, value instanceof ULong ? value.kt_1 : THROW_CCE());
  }
  h2e(decoder) {
    // Inline function 'kotlin.toULong' call
    var this_0 = decoder.n1x(this.f2e_1).h1x();
    return _ULong___init__impl__c78o9k(this_0);
  }
  j1t(decoder) {
    return new ULong(this.h2e(decoder));
  }
}
class UIntSerializer {
  constructor() {
    UIntSerializer_instance = this;
    this.i2e_1 = InlinePrimitiveDescriptor('kotlin.UInt', serializer_7(IntCompanionObject_instance));
  }
  h1t() {
    return this.i2e_1;
  }
  j2e(encoder, value) {
    var tmp = encoder.x1y(this.i2e_1);
    // Inline function 'kotlin.UInt.toInt' call
    var tmp$ret$0 = _UInt___get_data__impl__f0vqqw(value);
    tmp.q1y(tmp$ret$0);
  }
  i1t(encoder, value) {
    return this.j2e(encoder, value instanceof UInt ? value.ys_1 : THROW_CCE());
  }
  k2e(decoder) {
    // Inline function 'kotlin.toUInt' call
    var this_0 = decoder.n1x(this.i2e_1).g1x();
    return _UInt___init__impl__l7qpdl(this_0);
  }
  j1t(decoder) {
    return new UInt(this.k2e(decoder));
  }
}
class UShortSerializer {
  constructor() {
    UShortSerializer_instance = this;
    this.l2e_1 = InlinePrimitiveDescriptor('kotlin.UShort', serializer_9(ShortCompanionObject_instance));
  }
  h1t() {
    return this.l2e_1;
  }
  m2e(encoder, value) {
    var tmp = encoder.x1y(this.l2e_1);
    // Inline function 'kotlin.UShort.toShort' call
    var tmp$ret$0 = _UShort___get_data__impl__g0245(value);
    tmp.p1y(tmp$ret$0);
  }
  i1t(encoder, value) {
    return this.m2e(encoder, value instanceof UShort ? value.wt_1 : THROW_CCE());
  }
  n2e(decoder) {
    // Inline function 'kotlin.toUShort' call
    var this_0 = decoder.n1x(this.l2e_1).f1x();
    return _UShort___init__impl__jigrne(this_0);
  }
  j1t(decoder) {
    return new UShort(this.n2e(decoder));
  }
}
class UByteSerializer {
  constructor() {
    UByteSerializer_instance = this;
    this.o2e_1 = InlinePrimitiveDescriptor('kotlin.UByte', serializer_11(ByteCompanionObject_instance));
  }
  h1t() {
    return this.o2e_1;
  }
  p2e(encoder, value) {
    var tmp = encoder.x1y(this.o2e_1);
    // Inline function 'kotlin.UByte.toByte' call
    var tmp$ret$0 = _UByte___get_data__impl__jof9qr(value);
    tmp.o1y(tmp$ret$0);
  }
  i1t(encoder, value) {
    return this.p2e(encoder, value instanceof UByte ? value.ms_1 : THROW_CCE());
  }
  q2e(decoder) {
    // Inline function 'kotlin.toUByte' call
    var this_0 = decoder.n1x(this.o2e_1).e1x();
    return _UByte___init__impl__g9hnc4(this_0);
  }
  j1t(decoder) {
    return new UByte(this.q2e(decoder));
  }
}
class SerializersModule {
  m1v(kClass, typeArgumentsSerializers, $super) {
    typeArgumentsSerializers = typeArgumentsSerializers === VOID ? emptyList() : typeArgumentsSerializers;
    return $super === VOID ? this.n1v(kClass, typeArgumentsSerializers) : $super.n1v.call(this, kClass, typeArgumentsSerializers);
  }
}
class SerialModuleImpl extends SerializersModule {
  constructor(class2ContextualFactory, polyBase2Serializers, polyBase2DefaultSerializerProvider, polyBase2NamedSerializers, polyBase2DefaultDeserializerProvider, hasInterfaceContextualSerializers) {
    super();
    this.s2e_1 = class2ContextualFactory;
    this.t2e_1 = polyBase2Serializers;
    this.u2e_1 = polyBase2DefaultSerializerProvider;
    this.v2e_1 = polyBase2NamedSerializers;
    this.w2e_1 = polyBase2DefaultDeserializerProvider;
    this.x2e_1 = hasInterfaceContextualSerializers;
  }
  l1v() {
    return this.x2e_1;
  }
  q1z(baseClass, value) {
    if (!baseClass.if(value))
      return null;
    var tmp0_safe_receiver = this.t2e_1.h3(baseClass);
    var tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.h3(getKClassFromExpression(value));
    var registered = (!(tmp == null) ? isInterface(tmp, SerializationStrategy) : false) ? tmp : null;
    if (!(registered == null))
      return registered;
    var tmp_0 = this.u2e_1.h3(baseClass);
    var tmp1_safe_receiver = (!(tmp_0 == null) ? typeof tmp_0 === 'function' : false) ? tmp_0 : null;
    return tmp1_safe_receiver == null ? null : tmp1_safe_receiver(value);
  }
  p1z(baseClass, serializedClassName) {
    var tmp0_safe_receiver = this.v2e_1.h3(baseClass);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.collections.get' call
      tmp = (isInterface(tmp0_safe_receiver, KtMap) ? tmp0_safe_receiver : THROW_CCE()).h3(serializedClassName);
    }
    var tmp_0 = tmp;
    var registered = (!(tmp_0 == null) ? isInterface(tmp_0, KSerializer) : false) ? tmp_0 : null;
    if (!(registered == null))
      return registered;
    var tmp_1 = this.w2e_1.h3(baseClass);
    var tmp1_safe_receiver = (!(tmp_1 == null) ? typeof tmp_1 === 'function' : false) ? tmp_1 : null;
    return tmp1_safe_receiver == null ? null : tmp1_safe_receiver(serializedClassName);
  }
  n1v(kClass, typeArgumentsSerializers) {
    var tmp0_safe_receiver = this.s2e_1.h3(kClass);
    var tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.y2e(typeArgumentsSerializers);
    return (tmp == null ? true : isInterface(tmp, KSerializer)) ? tmp : null;
  }
  r2e(collector) {
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = this.s2e_1.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var kclass = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var serial = element.n1();
      if (serial instanceof Argless) {
        var tmp = isInterface(kclass, KClass) ? kclass : THROW_CCE();
        var tmp_0 = serial.b2f_1;
        collector.c2f(tmp, isInterface(tmp_0, KSerializer) ? tmp_0 : THROW_CCE());
      } else {
        if (serial instanceof WithTypeArguments) {
          collector.a2f(kclass, serial.z2e_1);
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s_0 = this.t2e_1.l1().y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      // Inline function 'kotlin.collections.component1' call
      var baseClass = element_0.m1();
      // Inline function 'kotlin.collections.component2' call
      var classMap = element_0.n1();
      // Inline function 'kotlin.collections.forEach' call
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s_1 = classMap.l1().y();
      while (_iterator__ex2g4s_1.z()) {
        var element_1 = _iterator__ex2g4s_1.a1();
        // Inline function 'kotlin.collections.component1' call
        var actualClass = element_1.m1();
        // Inline function 'kotlin.collections.component2' call
        var serializer = element_1.n1();
        var tmp_1 = isInterface(baseClass, KClass) ? baseClass : THROW_CCE();
        var tmp_2 = isInterface(actualClass, KClass) ? actualClass : THROW_CCE();
        // Inline function 'kotlinx.serialization.internal.cast' call
        var tmp$ret$11 = isInterface(serializer, KSerializer) ? serializer : THROW_CCE();
        collector.d2f(tmp_1, tmp_2, tmp$ret$11);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s_2 = this.u2e_1.l1().y();
    while (_iterator__ex2g4s_2.z()) {
      var element_2 = _iterator__ex2g4s_2.a1();
      // Inline function 'kotlin.collections.component1' call
      var baseClass_0 = element_2.m1();
      // Inline function 'kotlin.collections.component2' call
      var provider = element_2.n1();
      var tmp_3 = isInterface(baseClass_0, KClass) ? baseClass_0 : THROW_CCE();
      collector.e2f(tmp_3, typeof provider === 'function' ? provider : THROW_CCE());
    }
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s_3 = this.w2e_1.l1().y();
    while (_iterator__ex2g4s_3.z()) {
      var element_3 = _iterator__ex2g4s_3.a1();
      // Inline function 'kotlin.collections.component1' call
      var baseClass_1 = element_3.m1();
      // Inline function 'kotlin.collections.component2' call
      var provider_0 = element_3.n1();
      var tmp_4 = isInterface(baseClass_1, KClass) ? baseClass_1 : THROW_CCE();
      collector.f2f(tmp_4, typeof provider_0 === 'function' ? provider_0 : THROW_CCE());
    }
  }
}
class ContextualProvider {}
class Argless extends ContextualProvider {}
class WithTypeArguments extends ContextualProvider {}
class SerializersModuleCollector {}
function contextual(kClass, serializer) {
  return this.a2f(kClass, SerializersModuleCollector$contextual$lambda(serializer));
}
class SerializableWith {
  constructor(serializer) {
    this.g2f_1 = serializer;
  }
  equals(other) {
    if (!(other instanceof SerializableWith))
      return false;
    var tmp0_other_with_cast = other instanceof SerializableWith ? other : THROW_CCE();
    if (!this.g2f_1.equals(tmp0_other_with_cast.g2f_1))
      return false;
    return true;
  }
  hashCode() {
    return imul(getStringHashCode('serializer'), 127) ^ this.g2f_1.hashCode();
  }
  toString() {
    return '@kotlinx.serialization.SerializableWith(' + 'serializer=' + toString(this.g2f_1) + ')';
  }
}
class createCache$1 {
  constructor($factory) {
    this.h2f_1 = $factory;
  }
  o1v(key) {
    return this.h2f_1(key);
  }
}
class createParametrizedCache$1 {
  constructor($factory) {
    this.i2f_1 = $factory;
  }
  p1v(key, types) {
    // Inline function 'kotlin.runCatching' call
    var tmp;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = this.i2f_1(key, types);
      tmp = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
}
//endregion
function PolymorphicSerializer$descriptor$delegate$lambda$lambda(this$0) {
  return ($this$buildSerialDescriptor) => {
    $this$buildSerialDescriptor.s1t('type', serializer_1(StringCompanionObject_instance).h1t());
    $this$buildSerialDescriptor.s1t('value', buildSerialDescriptor('kotlinx.serialization.Polymorphic<' + this$0.t1t_1.hf() + '>', CONTEXTUAL_getInstance(), []));
    $this$buildSerialDescriptor.m1t_1 = this$0.u1t_1;
    return Unit_instance;
  };
}
function PolymorphicSerializer$descriptor$delegate$lambda(this$0) {
  return () => {
    var tmp = OPEN_getInstance();
    return withContext(buildSerialDescriptor('kotlinx.serialization.Polymorphic', tmp, [], PolymorphicSerializer$descriptor$delegate$lambda$lambda(this$0)), this$0.t1t_1);
  };
}
function findPolymorphicSerializer(_this__u8e3s4, encoder, value) {
  var tmp0_elvis_lhs = _this__u8e3s4.b1u(encoder, value);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throwSubtypeNotRegistered(getKClassFromExpression(value), _this__u8e3s4.y1t());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function findPolymorphicSerializer_0(_this__u8e3s4, decoder, klassName) {
  var tmp0_elvis_lhs = _this__u8e3s4.a1u(decoder, klassName);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throwSubtypeNotRegistered_0(klassName, _this__u8e3s4.y1t());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function descriptor$factory() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.h1t(), null);
}
function SealedClassSerializer$descriptor$delegate$lambda$lambda$lambda(this$0) {
  return ($this$buildSerialDescriptor) => {
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = this$0.g1u_1.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var name = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var serializer = element.n1();
      $this$buildSerialDescriptor.s1t(name, serializer.h1t());
    }
    return Unit_instance;
  };
}
function SealedClassSerializer$descriptor$delegate$lambda$lambda(this$0) {
  return ($this$buildSerialDescriptor) => {
    $this$buildSerialDescriptor.s1t('type', serializer_1(StringCompanionObject_instance).h1t());
    var tmp = 'kotlinx.serialization.Sealed<' + this$0.c1u_1.hf() + '>';
    var tmp_0 = CONTEXTUAL_getInstance();
    var elementDescriptor = buildSerialDescriptor(tmp, tmp_0, [], SealedClassSerializer$descriptor$delegate$lambda$lambda$lambda(this$0));
    $this$buildSerialDescriptor.s1t('value', elementDescriptor);
    $this$buildSerialDescriptor.m1t_1 = this$0.d1u_1;
    return Unit_instance;
  };
}
function SealedClassSerializer$descriptor$delegate$lambda($serialName, this$0) {
  return () => {
    var tmp = SEALED_getInstance();
    return buildSerialDescriptor($serialName, tmp, [], SealedClassSerializer$descriptor$delegate$lambda$lambda(this$0));
  };
}
function descriptor$factory_0() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.h1t(), null);
}
function init_kotlinx_serialization_SerializationException(_this__u8e3s4) {
  captureStack(_this__u8e3s4, _this__u8e3s4.r1u_1);
}
function serializerOrNull(_this__u8e3s4) {
  var tmp0_elvis_lhs = compiledSerializerImpl(_this__u8e3s4);
  return tmp0_elvis_lhs == null ? builtinSerializerOrNull(_this__u8e3s4) : tmp0_elvis_lhs;
}
function serializersForParameters(_this__u8e3s4, typeArguments, failOnMissingTypeArgSerializer) {
  var tmp;
  if (failOnMissingTypeArgSerializer) {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(typeArguments, 10));
    var _iterator__ex2g4s = typeArguments.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = serializer(_this__u8e3s4, item);
      destination.l(tmp$ret$0);
    }
    tmp = destination;
  } else {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(typeArguments, 10));
    var _iterator__ex2g4s_0 = typeArguments.y();
    while (_iterator__ex2g4s_0.z()) {
      var item_0 = _iterator__ex2g4s_0.a1();
      var tmp0_elvis_lhs = serializerOrNull_0(_this__u8e3s4, item_0);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        return null;
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      var tmp$ret$3 = tmp_0;
      destination_0.l(tmp$ret$3);
    }
    tmp = destination_0;
  }
  var serializers = tmp;
  return serializers;
}
function parametrizedSerializerOrNull(_this__u8e3s4, serializers, elementClassifierIfArray) {
  var tmp0_elvis_lhs = builtinParametrizedSerializer(_this__u8e3s4, serializers, elementClassifierIfArray);
  return tmp0_elvis_lhs == null ? compiledParametrizedSerializer(_this__u8e3s4, serializers) : tmp0_elvis_lhs;
}
function serializer(_this__u8e3s4, type) {
  var tmp0_elvis_lhs = serializerByKTypeImpl(_this__u8e3s4, type, true);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    platformSpecificSerializerNotRegistered(kclass(type));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function serializerOrNull_0(_this__u8e3s4, type) {
  return serializerByKTypeImpl(_this__u8e3s4, type, false);
}
function builtinParametrizedSerializer(_this__u8e3s4, serializers, elementClassifierIfArray) {
  var tmp;
  if (_this__u8e3s4.equals(getKClass(Collection)) || _this__u8e3s4.equals(getKClass(KtList)) || (_this__u8e3s4.equals(getKClass(KtMutableList)) || _this__u8e3s4.equals(getKClass(ArrayList)))) {
    tmp = new ArrayListSerializer(serializers.f1(0));
  } else if (_this__u8e3s4.equals(getKClass(HashSet))) {
    tmp = new HashSetSerializer(serializers.f1(0));
  } else if (_this__u8e3s4.equals(getKClass(KtSet)) || (_this__u8e3s4.equals(getKClass(KtMutableSet)) || _this__u8e3s4.equals(getKClass(LinkedHashSet)))) {
    tmp = new LinkedHashSetSerializer(serializers.f1(0));
  } else if (_this__u8e3s4.equals(getKClass(HashMap))) {
    tmp = new HashMapSerializer(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(KtMap)) || (_this__u8e3s4.equals(getKClass(KtMutableMap)) || _this__u8e3s4.equals(getKClass(LinkedHashMap)))) {
    tmp = new LinkedHashMapSerializer(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(Entry))) {
    tmp = MapEntrySerializer_0(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(Pair))) {
    tmp = PairSerializer_0(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(Triple))) {
    tmp = TripleSerializer_0(serializers.f1(0), serializers.f1(1), serializers.f1(2));
  } else {
    var tmp_0;
    if (isReferenceArray(_this__u8e3s4)) {
      var tmp_1 = elementClassifierIfArray();
      tmp_0 = ArraySerializer((!(tmp_1 == null) ? isInterface(tmp_1, KClass) : false) ? tmp_1 : THROW_CCE(), serializers.f1(0));
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function compiledParametrizedSerializer(_this__u8e3s4, serializers) {
  // Inline function 'kotlin.collections.toTypedArray' call
  var tmp$ret$0 = copyToArray(serializers);
  return constructSerializerForGivenTypeArgs(_this__u8e3s4, tmp$ret$0.slice());
}
function serializerByKTypeImpl(_this__u8e3s4, type, failOnMissingTypeArgSerializer) {
  var rootClass = kclass(type);
  var isNullable = type.yf();
  // Inline function 'kotlin.collections.map' call
  var this_0 = type.xf();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$0 = typeOrThrow(item);
    destination.l(tmp$ret$0);
  }
  var typeArguments = destination;
  var tmp;
  if (typeArguments.h1()) {
    var tmp_0;
    if (isInterface_0(rootClass) && !(_this__u8e3s4.m1v(rootClass) == null)) {
      tmp_0 = null;
    } else {
      tmp_0 = findCachedSerializer(rootClass, isNullable);
    }
    tmp = tmp_0;
  } else {
    var tmp_1;
    if (_this__u8e3s4.l1v()) {
      tmp_1 = null;
    } else {
      // Inline function 'kotlin.Result.getOrNull' call
      var this_1 = findParametrizedCachedSerializer(rootClass, typeArguments, isNullable);
      var tmp_2;
      if (_Result___get_isFailure__impl__jpiriv(this_1)) {
        tmp_2 = null;
      } else {
        var tmp_3 = _Result___get_value__impl__bjfvqg(this_1);
        tmp_2 = (tmp_3 == null ? true : !(tmp_3 == null)) ? tmp_3 : THROW_CCE();
      }
      tmp_1 = tmp_2;
    }
    tmp = tmp_1;
  }
  var cachedSerializer = tmp;
  if (!(cachedSerializer == null))
    return cachedSerializer;
  var tmp_4;
  if (typeArguments.h1()) {
    var tmp0_elvis_lhs = serializerOrNull(rootClass);
    var tmp1_elvis_lhs = tmp0_elvis_lhs == null ? _this__u8e3s4.m1v(rootClass) : tmp0_elvis_lhs;
    var tmp_5;
    if (tmp1_elvis_lhs == null) {
      // Inline function 'kotlinx.serialization.polymorphicIfInterface' call
      tmp_5 = isInterface_0(rootClass) ? PolymorphicSerializer.w1t(rootClass) : null;
    } else {
      tmp_5 = tmp1_elvis_lhs;
    }
    tmp_4 = tmp_5;
  } else {
    var tmp2_elvis_lhs = serializersForParameters(_this__u8e3s4, typeArguments, failOnMissingTypeArgSerializer);
    var tmp_6;
    if (tmp2_elvis_lhs == null) {
      return null;
    } else {
      tmp_6 = tmp2_elvis_lhs;
    }
    var serializers = tmp_6;
    var tmp3_elvis_lhs = parametrizedSerializerOrNull(rootClass, serializers, serializerByKTypeImpl$lambda(typeArguments));
    var tmp4_elvis_lhs = tmp3_elvis_lhs == null ? _this__u8e3s4.n1v(rootClass, serializers) : tmp3_elvis_lhs;
    var tmp_7;
    if (tmp4_elvis_lhs == null) {
      // Inline function 'kotlinx.serialization.polymorphicIfInterface' call
      tmp_7 = isInterface_0(rootClass) ? PolymorphicSerializer.w1t(rootClass) : null;
    } else {
      tmp_7 = tmp4_elvis_lhs;
    }
    tmp_4 = tmp_7;
  }
  var contextualSerializer = tmp_4;
  var tmp_8;
  if (contextualSerializer == null) {
    tmp_8 = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp_8 = isInterface(contextualSerializer, KSerializer) ? contextualSerializer : THROW_CCE();
  }
  var tmp6_safe_receiver = tmp_8;
  return tmp6_safe_receiver == null ? null : nullable(tmp6_safe_receiver, isNullable);
}
function nullable(_this__u8e3s4, shouldBeNullable) {
  if (shouldBeNullable)
    return get_nullable(_this__u8e3s4);
  return isInterface(_this__u8e3s4, KSerializer) ? _this__u8e3s4 : THROW_CCE();
}
function serializer_0(type) {
  return serializer(EmptySerializersModule_0(), type);
}
function serializerByKTypeImpl$lambda($typeArguments) {
  return () => $typeArguments.f1(0).wf();
}
function get_SERIALIZERS_CACHE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return SERIALIZERS_CACHE;
}
var SERIALIZERS_CACHE;
function get_SERIALIZERS_CACHE_NULLABLE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return SERIALIZERS_CACHE_NULLABLE;
}
var SERIALIZERS_CACHE_NULLABLE;
function get_PARAMETRIZED_SERIALIZERS_CACHE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return PARAMETRIZED_SERIALIZERS_CACHE;
}
var PARAMETRIZED_SERIALIZERS_CACHE;
function get_PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE;
}
var PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE;
function findCachedSerializer(clazz, isNullable) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp;
  if (!isNullable) {
    var tmp0_safe_receiver = get_SERIALIZERS_CACHE().o1v(clazz);
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlinx.serialization.internal.cast' call
      tmp_0 = isInterface(tmp0_safe_receiver, KSerializer) ? tmp0_safe_receiver : THROW_CCE();
    }
    tmp = tmp_0;
  } else {
    tmp = get_SERIALIZERS_CACHE_NULLABLE().o1v(clazz);
  }
  return tmp;
}
function findParametrizedCachedSerializer(clazz, types, isNullable) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp;
  if (!isNullable) {
    var tmp_0 = get_PARAMETRIZED_SERIALIZERS_CACHE().p1v(clazz, types);
    tmp = new Result(tmp_0) instanceof Result ? tmp_0 : THROW_CCE();
  } else {
    tmp = get_PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE().p1v(clazz, types);
  }
  return tmp;
}
function SERIALIZERS_CACHE$lambda(it) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp0_elvis_lhs = serializerOrNull(it);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlinx.serialization.polymorphicIfInterface' call
    tmp = isInterface_0(it) ? PolymorphicSerializer.w1t(it) : null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function SERIALIZERS_CACHE_NULLABLE$lambda(it) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp0_elvis_lhs = serializerOrNull(it);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlinx.serialization.polymorphicIfInterface' call
    tmp = isInterface_0(it) ? PolymorphicSerializer.w1t(it) : null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var tmp1_safe_receiver = tmp;
  var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : get_nullable(tmp1_safe_receiver);
  var tmp_0;
  if (tmp2_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp_0 = isInterface(tmp2_safe_receiver, KSerializer) ? tmp2_safe_receiver : THROW_CCE();
  }
  return tmp_0;
}
function PARAMETRIZED_SERIALIZERS_CACHE$lambda(clazz, types) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var serializers = ensureNotNull(serializersForParameters(EmptySerializersModule_0(), types, true));
  return parametrizedSerializerOrNull(clazz, serializers, PARAMETRIZED_SERIALIZERS_CACHE$lambda$lambda(types));
}
function PARAMETRIZED_SERIALIZERS_CACHE$lambda$lambda($types) {
  return () => $types.f1(0).wf();
}
function PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda(clazz, types) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var serializers = ensureNotNull(serializersForParameters(EmptySerializersModule_0(), types, true));
  var tmp0_safe_receiver = parametrizedSerializerOrNull(clazz, serializers, PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda$lambda(types));
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_nullable(tmp0_safe_receiver);
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp = isInterface(tmp1_safe_receiver, KSerializer) ? tmp1_safe_receiver : THROW_CCE();
  }
  return tmp;
}
function PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda$lambda($types) {
  return () => $types.f1(0).wf();
}
var properties_initialized_SerializersCache_kt_q8kf25;
function _init_properties_SerializersCache_kt__hgwi2p() {
  if (!properties_initialized_SerializersCache_kt_q8kf25) {
    properties_initialized_SerializersCache_kt_q8kf25 = true;
    SERIALIZERS_CACHE = createCache(SERIALIZERS_CACHE$lambda);
    SERIALIZERS_CACHE_NULLABLE = createCache(SERIALIZERS_CACHE_NULLABLE$lambda);
    PARAMETRIZED_SERIALIZERS_CACHE = createParametrizedCache(PARAMETRIZED_SERIALIZERS_CACHE$lambda);
    PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE = createParametrizedCache(PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda);
  }
}
function get_nullable(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4.h1t().q1v()) {
    tmp = isInterface(_this__u8e3s4, KSerializer) ? _this__u8e3s4 : THROW_CCE();
  } else {
    tmp = new NullableSerializer(_this__u8e3s4);
  }
  return tmp;
}
function serializer_1(_this__u8e3s4) {
  return StringSerializer_getInstance();
}
function serializer_2(_this__u8e3s4) {
  return CharSerializer_getInstance();
}
function CharArraySerializer_0() {
  return CharArraySerializer_getInstance();
}
function serializer_3(_this__u8e3s4) {
  return DoubleSerializer_getInstance();
}
function DoubleArraySerializer_0() {
  return DoubleArraySerializer_getInstance();
}
function serializer_4(_this__u8e3s4) {
  return FloatSerializer_getInstance();
}
function FloatArraySerializer_0() {
  return FloatArraySerializer_getInstance();
}
function serializer_5(_this__u8e3s4) {
  return LongSerializer_getInstance();
}
function LongArraySerializer_0() {
  return LongArraySerializer_getInstance();
}
function serializer_6(_this__u8e3s4) {
  return ULongSerializer_getInstance();
}
function ULongArraySerializer_0() {
  return ULongArraySerializer_getInstance();
}
function serializer_7(_this__u8e3s4) {
  return IntSerializer_getInstance();
}
function IntArraySerializer_0() {
  return IntArraySerializer_getInstance();
}
function serializer_8(_this__u8e3s4) {
  return UIntSerializer_getInstance();
}
function UIntArraySerializer_0() {
  return UIntArraySerializer_getInstance();
}
function serializer_9(_this__u8e3s4) {
  return ShortSerializer_getInstance();
}
function ShortArraySerializer_0() {
  return ShortArraySerializer_getInstance();
}
function serializer_10(_this__u8e3s4) {
  return UShortSerializer_getInstance();
}
function UShortArraySerializer_0() {
  return UShortArraySerializer_getInstance();
}
function serializer_11(_this__u8e3s4) {
  return ByteSerializer_getInstance();
}
function ByteArraySerializer_0() {
  return ByteArraySerializer_getInstance();
}
function serializer_12(_this__u8e3s4) {
  return UByteSerializer_getInstance();
}
function UByteArraySerializer_0() {
  return UByteArraySerializer_getInstance();
}
function serializer_13(_this__u8e3s4) {
  return BooleanSerializer_getInstance();
}
function BooleanArraySerializer_0() {
  return BooleanArraySerializer_getInstance();
}
function serializer_14(_this__u8e3s4) {
  return UnitSerializer_getInstance();
}
function NothingSerializer_0() {
  return NothingSerializer_getInstance();
}
function serializer_15(_this__u8e3s4) {
  return DurationSerializer_getInstance();
}
function serializer_16(_this__u8e3s4) {
  return UuidSerializer_getInstance();
}
function MapEntrySerializer_0(keySerializer, valueSerializer) {
  return new MapEntrySerializer(keySerializer, valueSerializer);
}
function PairSerializer_0(keySerializer, valueSerializer) {
  return new PairSerializer(keySerializer, valueSerializer);
}
function TripleSerializer_0(aSerializer, bSerializer, cSerializer) {
  return new TripleSerializer(aSerializer, bSerializer, cSerializer);
}
function ArraySerializer(kClass, elementSerializer) {
  return new ReferenceArraySerializer(kClass, elementSerializer);
}
function MapSerializer(keySerializer, valueSerializer) {
  return new LinkedHashMapSerializer(keySerializer, valueSerializer);
}
function ListSerializer(elementSerializer) {
  return new ArrayListSerializer(elementSerializer);
}
function withContext(_this__u8e3s4, context) {
  return new ContextDescriptor(_this__u8e3s4, context);
}
function getContextualDescriptor(_this__u8e3s4, descriptor) {
  var tmp0_safe_receiver = get_capturedKClass(descriptor);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_safe_receiver_0 = _this__u8e3s4.m1v(tmp0_safe_receiver);
    tmp = tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.h1t();
  }
  return tmp;
}
function get_capturedKClass(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof ContextDescriptor) {
    tmp = _this__u8e3s4.s1v_1;
  } else {
    if (_this__u8e3s4 instanceof SerialDescriptorForNullable) {
      tmp = get_capturedKClass(_this__u8e3s4.d1w_1);
    } else {
      tmp = null;
    }
  }
  return tmp;
}
function get_elementDescriptors(_this__u8e3s4) {
  // Inline function 'kotlin.collections.Iterable' call
  return new elementDescriptors$$inlined$Iterable$1(_this__u8e3s4);
}
function get_elementNames(_this__u8e3s4) {
  // Inline function 'kotlin.collections.Iterable' call
  return new elementNames$$inlined$Iterable$1(_this__u8e3s4);
}
function buildSerialDescriptor(serialName, kind, typeParameters, builder) {
  var tmp;
  if (builder === VOID) {
    tmp = buildSerialDescriptor$lambda;
  } else {
    tmp = builder;
  }
  builder = tmp;
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.require' call
  if (!!isBlank(serialName)) {
    var message = 'Blank serial names are prohibited';
    throw IllegalArgumentException.t(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!equals(kind, CLASS_getInstance())) {
    var message_0 = "For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead";
    throw IllegalArgumentException.t(toString(message_0));
  }
  var sdBuilder = new ClassSerialDescriptorBuilder(serialName);
  builder(sdBuilder);
  return new SerialDescriptorImpl(serialName, kind, sdBuilder.n1t_1.b1(), toList(typeParameters), sdBuilder);
}
function _get__hashCode__tgwhef($this) {
  var tmp0 = $this.y1w_1;
  // Inline function 'kotlin.getValue' call
  _hashCode$factory();
  return tmp0.n1();
}
function SerialDescriptorImpl$_hashCode$delegate$lambda(this$0) {
  return () => hashCodeImpl(this$0, this$0.x1w_1);
}
function buildClassSerialDescriptor(serialName, typeParameters, builderAction) {
  var tmp;
  if (builderAction === VOID) {
    tmp = buildClassSerialDescriptor$lambda;
  } else {
    tmp = builderAction;
  }
  builderAction = tmp;
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.require' call
  if (!!isBlank(serialName)) {
    var message = 'Blank serial names are prohibited';
    throw IllegalArgumentException.t(toString(message));
  }
  var sdBuilder = new ClassSerialDescriptorBuilder(serialName);
  builderAction(sdBuilder);
  return new SerialDescriptorImpl(serialName, CLASS_getInstance(), sdBuilder.n1t_1.b1(), toList(typeParameters), sdBuilder);
}
function PrimitiveSerialDescriptor_0(serialName, kind) {
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.require' call
  if (!!isBlank(serialName)) {
    var message = 'Blank serial names are prohibited';
    throw IllegalArgumentException.t(toString(message));
  }
  return PrimitiveDescriptorSafe(serialName, kind);
}
function get_nullable_0(_this__u8e3s4) {
  if (_this__u8e3s4.q1v())
    return _this__u8e3s4;
  return new SerialDescriptorForNullable(_this__u8e3s4);
}
function buildSerialDescriptor$lambda(_this__u8e3s4) {
  return Unit_instance;
}
function buildClassSerialDescriptor$lambda(_this__u8e3s4) {
  return Unit_instance;
}
function _hashCode$factory() {
  return getPropertyCallableRef('_hashCode', 1, KProperty1, (receiver) => _get__hashCode__tgwhef(receiver), null);
}
var ENUM_instance;
function ENUM_getInstance() {
  if (ENUM_instance === VOID)
    new ENUM();
  return ENUM_instance;
}
var CONTEXTUAL_instance;
function CONTEXTUAL_getInstance() {
  if (CONTEXTUAL_instance === VOID)
    new CONTEXTUAL();
  return CONTEXTUAL_instance;
}
var SEALED_instance;
function SEALED_getInstance() {
  if (SEALED_instance === VOID)
    new SEALED();
  return SEALED_instance;
}
var OPEN_instance;
function OPEN_getInstance() {
  if (OPEN_instance === VOID)
    new OPEN();
  return OPEN_instance;
}
var BOOLEAN_instance;
function BOOLEAN_getInstance() {
  if (BOOLEAN_instance === VOID)
    new BOOLEAN();
  return BOOLEAN_instance;
}
var BYTE_instance;
function BYTE_getInstance() {
  if (BYTE_instance === VOID)
    new BYTE();
  return BYTE_instance;
}
var CHAR_instance;
function CHAR_getInstance() {
  if (CHAR_instance === VOID)
    new CHAR();
  return CHAR_instance;
}
var SHORT_instance;
function SHORT_getInstance() {
  if (SHORT_instance === VOID)
    new SHORT();
  return SHORT_instance;
}
var INT_instance;
function INT_getInstance() {
  if (INT_instance === VOID)
    new INT();
  return INT_instance;
}
var LONG_instance;
function LONG_getInstance() {
  if (LONG_instance === VOID)
    new LONG();
  return LONG_instance;
}
var FLOAT_instance;
function FLOAT_getInstance() {
  if (FLOAT_instance === VOID)
    new FLOAT();
  return FLOAT_instance;
}
var DOUBLE_instance;
function DOUBLE_getInstance() {
  if (DOUBLE_instance === VOID)
    new DOUBLE();
  return DOUBLE_instance;
}
var STRING_instance;
function STRING_getInstance() {
  if (STRING_instance === VOID)
    new STRING();
  return STRING_instance;
}
var CLASS_instance;
function CLASS_getInstance() {
  if (CLASS_instance === VOID)
    new CLASS();
  return CLASS_instance;
}
var LIST_instance;
function LIST_getInstance() {
  if (LIST_instance === VOID)
    new LIST();
  return LIST_instance;
}
var MAP_instance;
function MAP_getInstance() {
  if (MAP_instance === VOID)
    new MAP();
  return MAP_instance;
}
var OBJECT_instance;
function OBJECT_getInstance() {
  if (OBJECT_instance === VOID)
    new OBJECT();
  return OBJECT_instance;
}
function decodeSequentially_0($this, compositeDecoder) {
  var klassName = compositeDecoder.a1y($this.h1t(), 0);
  var serializer = findPolymorphicSerializer_0($this, compositeDecoder, klassName);
  return compositeDecoder.d1y($this.h1t(), 1, serializer);
}
function throwSubtypeNotRegistered(subClass, baseClass) {
  var tmp0_elvis_lhs = subClass.hf();
  throwSubtypeNotRegistered_0(tmp0_elvis_lhs == null ? toString(subClass) : tmp0_elvis_lhs, baseClass);
}
function throwSubtypeNotRegistered_0(subClassName, baseClass) {
  var scope = "in the polymorphic scope of '" + baseClass.hf() + "'";
  throw SerializationException.t1u(subClassName == null ? 'Class discriminator was missing and no default serializers were registered ' + scope + '.' : "Serializer for subclass '" + subClassName + "' is not found " + scope + '.\n' + ("Check if class with serial name '" + subClassName + "' exists and serializer is registered in a corresponding SerializersModule.\n") + ("To be registered automatically, class '" + subClassName + "' has to be '@Serializable', and the base class '" + baseClass.hf() + "' has to be sealed and '@Serializable'."));
}
var NothingSerializer_instance;
function NothingSerializer_getInstance() {
  if (NothingSerializer_instance === VOID)
    new NothingSerializer();
  return NothingSerializer_instance;
}
var DurationSerializer_instance;
function DurationSerializer_getInstance() {
  if (DurationSerializer_instance === VOID)
    new DurationSerializer();
  return DurationSerializer_instance;
}
var UuidSerializer_instance;
function UuidSerializer_getInstance() {
  if (UuidSerializer_instance === VOID)
    new UuidSerializer();
  return UuidSerializer_instance;
}
function readSize($this, decoder, builder) {
  var size = decoder.i1y($this.h1t());
  $this.z20(builder, size);
  return size;
}
var Companion_instance_0;
function Companion_getInstance_7() {
  if (Companion_instance_0 === VOID)
    new Companion();
  return Companion_instance_0;
}
function prepareHighMarksArray($this, elementsCount) {
  var slotsCount = (elementsCount - 1 | 0) >>> 6 | 0;
  var elementsInLastSlot = elementsCount & 63;
  var highMarks = longArray(slotsCount);
  if (!(elementsInLastSlot === 0)) {
    highMarks[get_lastIndex(highMarks)] = (new Long(-1, -1)).e4(elementsCount);
  }
  return highMarks;
}
function markHigh($this, index) {
  var slot = (index >>> 6 | 0) - 1 | 0;
  var offsetInSlot = index & 63;
  $this.w23_1[slot] = $this.w23_1[slot].i4((new Long(1, 0)).e4(offsetInSlot));
}
function nextUnmarkedHighIndex($this) {
  var inductionVariable = 0;
  var last = $this.w23_1.length - 1 | 0;
  if (inductionVariable <= last)
    do {
      var slot = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var slotOffset = imul(slot + 1 | 0, 64);
      var slotMarks = $this.w23_1[slot];
      while (!slotMarks.equals(new Long(-1, -1))) {
        var indexInSlot = countTrailingZeroBits(slotMarks.c4());
        slotMarks = slotMarks.i4((new Long(1, 0)).e4(indexInSlot));
        var index = slotOffset + indexInSlot | 0;
        if ($this.u23_1($this.t23_1, index)) {
          $this.w23_1[slot] = slotMarks;
          return index;
        }
      }
      $this.w23_1[slot] = slotMarks;
    }
     while (inductionVariable <= last);
  return -1;
}
function createSimpleEnumSerializer(serialName, values) {
  return new EnumSerializer(serialName, values);
}
function createUnmarkedDescriptor($this, serialName) {
  var d = new EnumDescriptor(serialName, $this.z23_1.length);
  // Inline function 'kotlin.collections.forEach' call
  var indexedObject = $this.z23_1;
  var inductionVariable = 0;
  var last = indexedObject.length;
  while (inductionVariable < last) {
    var element = indexedObject[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    d.o24(element.n3_1);
  }
  return d;
}
function EnumSerializer$descriptor$delegate$lambda(this$0, $serialName) {
  return () => {
    var tmp0_elvis_lhs = this$0.a24_1;
    return tmp0_elvis_lhs == null ? createUnmarkedDescriptor(this$0, $serialName) : tmp0_elvis_lhs;
  };
}
function _get_elementDescriptors__y23q9p($this) {
  var tmp0 = $this.d25_1;
  // Inline function 'kotlin.getValue' call
  elementDescriptors$factory();
  return tmp0.n1();
}
function EnumDescriptor$elementDescriptors$delegate$lambda($elementsCount, $name, this$0) {
  return () => {
    var tmp = 0;
    var tmp_0 = $elementsCount;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      tmp_1[tmp_2] = buildSerialDescriptor($name + '.' + this$0.y1v(tmp_2), OBJECT_getInstance(), []);
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  };
}
function descriptor$factory_1() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.h1t(), null);
}
function elementDescriptors$factory() {
  return getPropertyCallableRef('elementDescriptors', 1, KProperty1, (receiver) => _get_elementDescriptors__y23q9p(receiver), null);
}
function InlinePrimitiveDescriptor(name, primitiveSerializer) {
  return new InlineClassDescriptor(name, new InlinePrimitiveDescriptor$1(primitiveSerializer));
}
function jsonCachedSerialNames(_this__u8e3s4) {
  return cachedSerialNames(_this__u8e3s4);
}
var NoOpEncoder_instance;
function NoOpEncoder_getInstance() {
  if (NoOpEncoder_instance === VOID)
    NoOpEncoder.x25();
  return NoOpEncoder_instance;
}
function error($this) {
  throw IllegalStateException.t4('Descriptor for type `kotlin.Nothing` does not have elements');
}
var NothingSerialDescriptor_instance;
function NothingSerialDescriptor_getInstance() {
  if (NothingSerialDescriptor_instance === VOID)
    new NothingSerialDescriptor();
  return NothingSerialDescriptor_instance;
}
function ObjectSerializer$descriptor$delegate$lambda$lambda(this$0) {
  return ($this$buildSerialDescriptor) => {
    $this$buildSerialDescriptor.m1t_1 = this$0.e26_1;
    return Unit_instance;
  };
}
function ObjectSerializer$descriptor$delegate$lambda($serialName, this$0) {
  return () => {
    var tmp = OBJECT_getInstance();
    return buildSerialDescriptor($serialName, tmp, [], ObjectSerializer$descriptor$delegate$lambda$lambda(this$0));
  };
}
function descriptor$factory_2() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.h1t(), null);
}
function get_EMPTY_DESCRIPTOR_ARRAY() {
  _init_properties_Platform_common_kt__3qzecs();
  return EMPTY_DESCRIPTOR_ARRAY;
}
var EMPTY_DESCRIPTOR_ARRAY;
function cachedSerialNames(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  if (isInterface(_this__u8e3s4, CachedNames))
    return _this__u8e3s4.z1w();
  var result = HashSet.e1(_this__u8e3s4.w1v());
  var inductionVariable = 0;
  var last = _this__u8e3s4.w1v();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = _this__u8e3s4.y1v(i);
      result.l(element);
    }
     while (inductionVariable < last);
  return result;
}
function kclass(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  var t = _this__u8e3s4.wf();
  var tmp;
  if (!(t == null) ? isInterface(t, KClass) : false) {
    tmp = t;
  } else {
    if (!(t == null) ? isInterface(t, KTypeParameter) : false) {
      throw IllegalArgumentException.t('Captured type parameter ' + toString(t) + ' from generic non-reified function. ' + ('Such functionality cannot be supported because ' + toString(t) + ' is erased, either specify serializer explicitly or make ') + ('calling function inline with reified ' + toString(t) + '.'));
    } else {
      throw IllegalArgumentException.t('Only KClass supported as classifier, got ' + toString_0(t));
    }
  }
  var tmp_0 = tmp;
  return isInterface(tmp_0, KClass) ? tmp_0 : THROW_CCE();
}
function typeOrThrow(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  var tmp0 = _this__u8e3s4.rp_1;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.requireNotNull' call
    if (tmp0 == null) {
      var message = 'Star projections in type arguments are not allowed, but had ' + toString_0(_this__u8e3s4.rp_1);
      throw IllegalArgumentException.t(toString(message));
    } else {
      tmp$ret$1 = tmp0;
      break $l$block;
    }
  }
  return tmp$ret$1;
}
function notRegisteredMessage(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  var tmp0_elvis_lhs = _this__u8e3s4.hf();
  return notRegisteredMessage_0(tmp0_elvis_lhs == null ? '<local class name not available>' : tmp0_elvis_lhs);
}
function compactArray(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  // Inline function 'kotlin.takeUnless' call
  var tmp;
  // Inline function 'kotlin.collections.isNullOrEmpty' call
  if (!(_this__u8e3s4 == null || _this__u8e3s4.h1())) {
    tmp = _this__u8e3s4;
  } else {
    tmp = null;
  }
  var tmp0_safe_receiver = tmp;
  var tmp_0;
  if (tmp0_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.collections.toTypedArray' call
    tmp_0 = copyToArray(tmp0_safe_receiver);
  }
  var tmp1_elvis_lhs = tmp_0;
  return tmp1_elvis_lhs == null ? get_EMPTY_DESCRIPTOR_ARRAY() : tmp1_elvis_lhs;
}
function notRegisteredMessage_0(className) {
  _init_properties_Platform_common_kt__3qzecs();
  return "Serializer for class '" + className + "' is not found.\n" + "Please ensure that class is marked as '@Serializable' and that the serialization compiler plugin is applied.\n";
}
var properties_initialized_Platform_common_kt_i7q4ty;
function _init_properties_Platform_common_kt__3qzecs() {
  if (!properties_initialized_Platform_common_kt_i7q4ty) {
    properties_initialized_Platform_common_kt_i7q4ty = true;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    EMPTY_DESCRIPTOR_ARRAY = [];
  }
}
function throwMissingFieldException(seen, goldenMask, descriptor) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var missingFields = ArrayList.k();
  var missingFieldsBits = goldenMask & ~seen;
  var inductionVariable = 0;
  if (inductionVariable < 32)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (!((missingFieldsBits & 1) === 0)) {
        // Inline function 'kotlin.collections.plusAssign' call
        var element = descriptor.y1v(i);
        missingFields.l(element);
      }
      missingFieldsBits = missingFieldsBits >>> 1 | 0;
    }
     while (inductionVariable < 32);
  throw MissingFieldException.c1v(missingFields, descriptor.k1u());
}
function hashCodeImpl(_this__u8e3s4, typeParams) {
  var result = getStringHashCode(_this__u8e3s4.k1u());
  result = imul(31, result) + contentHashCode(typeParams) | 0;
  var elementDescriptors = get_elementDescriptors(_this__u8e3s4);
  // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy' call
  // Inline function 'kotlin.collections.fold' call
  var accumulator = 1;
  var _iterator__ex2g4s = elementDescriptors.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var hash = accumulator;
    var tmp = imul(31, hash);
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver = element.k1u();
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
    accumulator = tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
  }
  var namesHash = accumulator;
  // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy' call
  // Inline function 'kotlin.collections.fold' call
  var accumulator_0 = 1;
  var _iterator__ex2g4s_0 = elementDescriptors.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    var hash_0 = accumulator_0;
    var tmp_0 = imul(31, hash_0);
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver_0 = element_0.u1v();
    var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
    accumulator_0 = tmp_0 + (tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0) | 0;
  }
  var kindHash = accumulator_0;
  result = imul(31, result) + namesHash | 0;
  result = imul(31, result) + kindHash | 0;
  return result;
}
function toStringImpl(_this__u8e3s4) {
  var tmp = until(0, _this__u8e3s4.w1v());
  var tmp_0 = _this__u8e3s4.k1u() + '(';
  return joinToString(tmp, ', ', tmp_0, ')', VOID, VOID, toStringImpl$lambda(_this__u8e3s4));
}
function _get_childSerializers__7vnyfa($this) {
  var tmp0 = $this.l24_1;
  // Inline function 'kotlin.getValue' call
  childSerializers$factory();
  return tmp0.n1();
}
function _get__hashCode__tgwhef_0($this) {
  var tmp0 = $this.n24_1;
  // Inline function 'kotlin.getValue' call
  _hashCode$factory_0();
  return tmp0.n1();
}
function buildIndices($this) {
  var indices = HashMap.l8();
  var inductionVariable = 0;
  var last = $this.g24_1.length - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.collections.set' call
      var key = $this.g24_1[i];
      indices.k3(key, i);
    }
     while (inductionVariable <= last);
  return indices;
}
function PluginGeneratedSerialDescriptor$childSerializers$delegate$lambda(this$0) {
  return () => {
    var tmp0_safe_receiver = this$0.d24_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u25();
    return tmp1_elvis_lhs == null ? get_EMPTY_SERIALIZER_ARRAY() : tmp1_elvis_lhs;
  };
}
function PluginGeneratedSerialDescriptor$typeParameterDescriptors$delegate$lambda(this$0) {
  return () => {
    var tmp0_safe_receiver = this$0.d24_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.v25();
    var tmp;
    if (tmp1_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(tmp1_safe_receiver.length);
      var inductionVariable = 0;
      var last = tmp1_safe_receiver.length;
      while (inductionVariable < last) {
        var item = tmp1_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        var tmp$ret$0 = item.h1t();
        destination.l(tmp$ret$0);
      }
      tmp = destination;
    }
    return compactArray(tmp);
  };
}
function PluginGeneratedSerialDescriptor$_hashCode$delegate$lambda(this$0) {
  return () => hashCodeImpl(this$0, this$0.e25());
}
function toStringImpl$lambda($this_toStringImpl) {
  return (i) => $this_toStringImpl.y1v(i) + ': ' + $this_toStringImpl.b1w(i).k1u();
}
function childSerializers$factory() {
  return getPropertyCallableRef('childSerializers', 1, KProperty1, (receiver) => _get_childSerializers__7vnyfa(receiver), null);
}
function typeParameterDescriptors$factory() {
  return getPropertyCallableRef('typeParameterDescriptors', 1, KProperty1, (receiver) => receiver.e25(), null);
}
function _hashCode$factory_0() {
  return getPropertyCallableRef('_hashCode', 1, KProperty1, (receiver) => _get__hashCode__tgwhef_0(receiver), null);
}
function get_EMPTY_SERIALIZER_ARRAY() {
  _init_properties_PluginHelperInterfaces_kt__xgvzfp();
  return EMPTY_SERIALIZER_ARRAY;
}
var EMPTY_SERIALIZER_ARRAY;
var properties_initialized_PluginHelperInterfaces_kt_ap8in1;
function _init_properties_PluginHelperInterfaces_kt__xgvzfp() {
  if (!properties_initialized_PluginHelperInterfaces_kt_ap8in1) {
    properties_initialized_PluginHelperInterfaces_kt_ap8in1 = true;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    EMPTY_SERIALIZER_ARRAY = [];
  }
}
var CharArraySerializer_instance;
function CharArraySerializer_getInstance() {
  if (CharArraySerializer_instance === VOID)
    new CharArraySerializer();
  return CharArraySerializer_instance;
}
var DoubleArraySerializer_instance;
function DoubleArraySerializer_getInstance() {
  if (DoubleArraySerializer_instance === VOID)
    new DoubleArraySerializer();
  return DoubleArraySerializer_instance;
}
var FloatArraySerializer_instance;
function FloatArraySerializer_getInstance() {
  if (FloatArraySerializer_instance === VOID)
    new FloatArraySerializer();
  return FloatArraySerializer_instance;
}
var LongArraySerializer_instance;
function LongArraySerializer_getInstance() {
  if (LongArraySerializer_instance === VOID)
    new LongArraySerializer();
  return LongArraySerializer_instance;
}
var ULongArraySerializer_instance;
function ULongArraySerializer_getInstance() {
  if (ULongArraySerializer_instance === VOID)
    new ULongArraySerializer();
  return ULongArraySerializer_instance;
}
var IntArraySerializer_instance;
function IntArraySerializer_getInstance() {
  if (IntArraySerializer_instance === VOID)
    new IntArraySerializer();
  return IntArraySerializer_instance;
}
var UIntArraySerializer_instance;
function UIntArraySerializer_getInstance() {
  if (UIntArraySerializer_instance === VOID)
    new UIntArraySerializer();
  return UIntArraySerializer_instance;
}
var ShortArraySerializer_instance;
function ShortArraySerializer_getInstance() {
  if (ShortArraySerializer_instance === VOID)
    new ShortArraySerializer();
  return ShortArraySerializer_instance;
}
var UShortArraySerializer_instance;
function UShortArraySerializer_getInstance() {
  if (UShortArraySerializer_instance === VOID)
    new UShortArraySerializer();
  return UShortArraySerializer_instance;
}
var ByteArraySerializer_instance;
function ByteArraySerializer_getInstance() {
  if (ByteArraySerializer_instance === VOID)
    new ByteArraySerializer();
  return ByteArraySerializer_instance;
}
var UByteArraySerializer_instance;
function UByteArraySerializer_getInstance() {
  if (UByteArraySerializer_instance === VOID)
    new UByteArraySerializer();
  return UByteArraySerializer_instance;
}
var BooleanArraySerializer_instance;
function BooleanArraySerializer_getInstance() {
  if (BooleanArraySerializer_instance === VOID)
    new BooleanArraySerializer();
  return BooleanArraySerializer_instance;
}
function get_BUILTIN_SERIALIZERS() {
  _init_properties_Primitives_kt__k0eto4();
  return BUILTIN_SERIALIZERS;
}
var BUILTIN_SERIALIZERS;
function builtinSerializerOrNull(_this__u8e3s4) {
  _init_properties_Primitives_kt__k0eto4();
  var tmp = get_BUILTIN_SERIALIZERS().h3(_this__u8e3s4);
  return (tmp == null ? true : isInterface(tmp, KSerializer)) ? tmp : THROW_CCE();
}
var StringSerializer_instance;
function StringSerializer_getInstance() {
  if (StringSerializer_instance === VOID)
    new StringSerializer();
  return StringSerializer_instance;
}
var CharSerializer_instance;
function CharSerializer_getInstance() {
  if (CharSerializer_instance === VOID)
    new CharSerializer();
  return CharSerializer_instance;
}
var DoubleSerializer_instance;
function DoubleSerializer_getInstance() {
  if (DoubleSerializer_instance === VOID)
    new DoubleSerializer();
  return DoubleSerializer_instance;
}
var FloatSerializer_instance;
function FloatSerializer_getInstance() {
  if (FloatSerializer_instance === VOID)
    new FloatSerializer();
  return FloatSerializer_instance;
}
var LongSerializer_instance;
function LongSerializer_getInstance() {
  if (LongSerializer_instance === VOID)
    new LongSerializer();
  return LongSerializer_instance;
}
var IntSerializer_instance;
function IntSerializer_getInstance() {
  if (IntSerializer_instance === VOID)
    new IntSerializer();
  return IntSerializer_instance;
}
var ShortSerializer_instance;
function ShortSerializer_getInstance() {
  if (ShortSerializer_instance === VOID)
    new ShortSerializer();
  return ShortSerializer_instance;
}
var ByteSerializer_instance;
function ByteSerializer_getInstance() {
  if (ByteSerializer_instance === VOID)
    new ByteSerializer();
  return ByteSerializer_instance;
}
var BooleanSerializer_instance;
function BooleanSerializer_getInstance() {
  if (BooleanSerializer_instance === VOID)
    new BooleanSerializer();
  return BooleanSerializer_instance;
}
var UnitSerializer_instance;
function UnitSerializer_getInstance() {
  if (UnitSerializer_instance === VOID)
    new UnitSerializer();
  return UnitSerializer_instance;
}
function error_0($this) {
  throw IllegalStateException.t4('Primitive descriptor ' + $this.p2b_1 + ' does not have elements');
}
function PrimitiveDescriptorSafe(serialName, kind) {
  _init_properties_Primitives_kt__k0eto4();
  checkNameIsNotAPrimitive(serialName);
  return new PrimitiveSerialDescriptor(serialName, kind);
}
function checkNameIsNotAPrimitive(serialName) {
  _init_properties_Primitives_kt__k0eto4();
  var values = get_BUILTIN_SERIALIZERS().j3();
  var _iterator__ex2g4s = values.y();
  while (_iterator__ex2g4s.z()) {
    var primitive = _iterator__ex2g4s.a1();
    var primitiveName = primitive.h1t().k1u();
    if (serialName === primitiveName) {
      throw IllegalArgumentException.t(trimIndent('\n                The name of serial descriptor should uniquely identify associated serializer.\n                For serial name ' + serialName + ' there already exists ' + getKClassFromExpression(primitive).hf() + '.\n                Please refer to SerialDescriptor documentation for additional information.\n            '));
    }
  }
}
var properties_initialized_Primitives_kt_6dpii6;
function _init_properties_Primitives_kt__k0eto4() {
  if (!properties_initialized_Primitives_kt_6dpii6) {
    properties_initialized_Primitives_kt_6dpii6 = true;
    BUILTIN_SERIALIZERS = initBuiltins();
  }
}
function encodeElement($this, desc, index) {
  var tag = $this.s2b(desc, index);
  $this.o2c(tag);
  return true;
}
function tagBlock($this, tag, block) {
  $this.o2c(tag);
  var r = block();
  if (!$this.t2c_1) {
    $this.p2c();
  }
  $this.t2c_1 = false;
  return r;
}
function TaggedDecoder$decodeSerializableElement$lambda(this$0, $deserializer, $previousValue) {
  return () => this$0.o1x($deserializer, $previousValue);
}
function TaggedDecoder$decodeNullableSerializableElement$lambda(this$0, $deserializer, $previousValue) {
  return () => {
    var tmp0 = this$0;
    // Inline function 'kotlinx.serialization.encoding.decodeIfNullable' call
    var isNullabilitySupported = $deserializer.h1t().q1v();
    var tmp;
    if (isNullabilitySupported || tmp0.b1x()) {
      tmp = this$0.o1x($deserializer, $previousValue);
    } else {
      tmp = tmp0.c1x();
    }
    return tmp;
  };
}
function get_NULL() {
  _init_properties_Tuples_kt__dz0qyd();
  return NULL;
}
var NULL;
function MapEntrySerializer$descriptor$lambda($keySerializer, $valueSerializer) {
  return ($this$buildSerialDescriptor) => {
    $this$buildSerialDescriptor.s1t('key', $keySerializer.h1t());
    $this$buildSerialDescriptor.s1t('value', $valueSerializer.h1t());
    return Unit_instance;
  };
}
function PairSerializer$descriptor$lambda($keySerializer, $valueSerializer) {
  return ($this$buildClassSerialDescriptor) => {
    $this$buildClassSerialDescriptor.s1t('first', $keySerializer.h1t());
    $this$buildClassSerialDescriptor.s1t('second', $valueSerializer.h1t());
    return Unit_instance;
  };
}
function decodeSequentially_1($this, composite) {
  var a = composite.d1y($this.d2e_1, 0, $this.a2e_1);
  var b = composite.d1y($this.d2e_1, 1, $this.b2e_1);
  var c = composite.d1y($this.d2e_1, 2, $this.c2e_1);
  composite.r1x($this.d2e_1);
  return new Triple(a, b, c);
}
function decodeStructure($this, composite) {
  var a = get_NULL();
  var b = get_NULL();
  var c = get_NULL();
  mainLoop: while (true) {
    var index = composite.h1y($this.d2e_1);
    switch (index) {
      case -1:
        break mainLoop;
      case 0:
        a = composite.d1y($this.d2e_1, 0, $this.a2e_1);
        break;
      case 1:
        b = composite.d1y($this.d2e_1, 1, $this.b2e_1);
        break;
      case 2:
        c = composite.d1y($this.d2e_1, 2, $this.c2e_1);
        break;
      default:
        throw SerializationException.t1u('Unexpected index ' + index);
    }
  }
  composite.r1x($this.d2e_1);
  if (a === get_NULL())
    throw SerializationException.t1u("Element 'first' is missing");
  if (b === get_NULL())
    throw SerializationException.t1u("Element 'second' is missing");
  if (c === get_NULL())
    throw SerializationException.t1u("Element 'third' is missing");
  var tmp = (a == null ? true : !(a == null)) ? a : THROW_CCE();
  var tmp_0 = (b == null ? true : !(b == null)) ? b : THROW_CCE();
  return new Triple(tmp, tmp_0, (c == null ? true : !(c == null)) ? c : THROW_CCE());
}
function TripleSerializer$descriptor$lambda(this$0) {
  return ($this$buildClassSerialDescriptor) => {
    $this$buildClassSerialDescriptor.s1t('first', this$0.a2e_1.h1t());
    $this$buildClassSerialDescriptor.s1t('second', this$0.b2e_1.h1t());
    $this$buildClassSerialDescriptor.s1t('third', this$0.c2e_1.h1t());
    return Unit_instance;
  };
}
var properties_initialized_Tuples_kt_3vs7ar;
function _init_properties_Tuples_kt__dz0qyd() {
  if (!properties_initialized_Tuples_kt_3vs7ar) {
    properties_initialized_Tuples_kt_3vs7ar = true;
    NULL = new Object();
  }
}
var ULongSerializer_instance;
function ULongSerializer_getInstance() {
  if (ULongSerializer_instance === VOID)
    new ULongSerializer();
  return ULongSerializer_instance;
}
var UIntSerializer_instance;
function UIntSerializer_getInstance() {
  if (UIntSerializer_instance === VOID)
    new UIntSerializer();
  return UIntSerializer_instance;
}
var UShortSerializer_instance;
function UShortSerializer_getInstance() {
  if (UShortSerializer_instance === VOID)
    new UShortSerializer();
  return UShortSerializer_instance;
}
var UByteSerializer_instance;
function UByteSerializer_getInstance() {
  if (UByteSerializer_instance === VOID)
    new UByteSerializer();
  return UByteSerializer_instance;
}
function get_EmptySerializersModuleLegacyJs() {
  _init_properties_SerializersModule_kt__u78ha3();
  return EmptySerializersModule;
}
var EmptySerializersModule;
var properties_initialized_SerializersModule_kt_fjigjn;
function _init_properties_SerializersModule_kt__u78ha3() {
  if (!properties_initialized_SerializersModule_kt_fjigjn) {
    properties_initialized_SerializersModule_kt_fjigjn = true;
    EmptySerializersModule = new SerialModuleImpl(emptyMap(), emptyMap(), emptyMap(), emptyMap(), emptyMap(), false);
  }
}
function EmptySerializersModule_0() {
  return get_EmptySerializersModuleLegacyJs();
}
function SerializersModuleCollector$contextual$lambda($serializer) {
  return (it) => $serializer;
}
function createCache(factory) {
  return new createCache$1(factory);
}
function createParametrizedCache(factory) {
  return new createParametrizedCache$1(factory);
}
function isInterface_0(_this__u8e3s4) {
  return get_isInterface(_this__u8e3s4);
}
function initBuiltins() {
  return mapOf([to(PrimitiveClasses_getInstance().ng(), serializer_1(StringCompanionObject_instance)), to(getKClass(Char), serializer_2(Companion_getInstance_1())), to(PrimitiveClasses_getInstance().qg(), CharArraySerializer_0()), to(PrimitiveClasses_getInstance().lg(), serializer_3(DoubleCompanionObject_instance)), to(PrimitiveClasses_getInstance().wg(), DoubleArraySerializer_0()), to(PrimitiveClasses_getInstance().kg(), serializer_4(FloatCompanionObject_instance)), to(PrimitiveClasses_getInstance().vg(), FloatArraySerializer_0()), to(getKClass(Long), serializer_5(Companion_getInstance_2())), to(PrimitiveClasses_getInstance().ug(), LongArraySerializer_0()), to(getKClass(ULong), serializer_6(Companion_getInstance_3())), to(getKClass(ULongArray), ULongArraySerializer_0()), to(PrimitiveClasses_getInstance().jg(), serializer_7(IntCompanionObject_instance)), to(PrimitiveClasses_getInstance().tg(), IntArraySerializer_0()), to(getKClass(UInt), serializer_8(Companion_getInstance_4())), to(getKClass(UIntArray), UIntArraySerializer_0()), to(PrimitiveClasses_getInstance().ig(), serializer_9(ShortCompanionObject_instance)), to(PrimitiveClasses_getInstance().sg(), ShortArraySerializer_0()), to(getKClass(UShort), serializer_10(Companion_getInstance_5())), to(getKClass(UShortArray), UShortArraySerializer_0()), to(PrimitiveClasses_getInstance().hg(), serializer_11(ByteCompanionObject_instance)), to(PrimitiveClasses_getInstance().rg(), ByteArraySerializer_0()), to(getKClass(UByte), serializer_12(Companion_getInstance_6())), to(getKClass(UByteArray), UByteArraySerializer_0()), to(PrimitiveClasses_getInstance().gg(), serializer_13(BooleanCompanionObject_instance)), to(PrimitiveClasses_getInstance().pg(), BooleanArraySerializer_0()), to(getKClass(Unit), serializer_14(Unit_instance)), to(PrimitiveClasses_getInstance().fg(), NothingSerializer_0()), to(getKClass(Duration), serializer_15(Companion_getInstance())), to(getKClass(Uuid), serializer_16(Companion_getInstance_0()))]);
}
function get_isInterface(_this__u8e3s4) {
  if (_this__u8e3s4 === PrimitiveClasses_getInstance().fg())
    return false;
  // Inline function 'kotlin.js.asDynamic' call
  var tmp0_safe_receiver = get_js(_this__u8e3s4).$metadata$;
  return (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.kind) == 'interface';
}
function compiledSerializerImpl(_this__u8e3s4) {
  var tmp0_elvis_lhs = constructSerializerForGivenTypeArgs(_this__u8e3s4, []);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var tmp_0;
    if (_this__u8e3s4 === PrimitiveClasses_getInstance().fg()) {
      tmp_0 = NothingSerializer_getInstance();
    } else {
      // Inline function 'kotlin.js.asDynamic' call
      var tmp1_safe_receiver = get_js(_this__u8e3s4).Companion;
      tmp_0 = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.serializer();
    }
    var tmp_1 = tmp_0;
    tmp = (!(tmp_1 == null) ? isInterface(tmp_1, KSerializer) : false) ? tmp_1 : null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function platformSpecificSerializerNotRegistered(_this__u8e3s4) {
  throw SerializationException.t1u(notRegisteredMessage(_this__u8e3s4) + 'To get enum serializer on Kotlin/JS, it should be annotated with @Serializable annotation.');
}
function isReferenceArray(rootClass) {
  return rootClass.equals(PrimitiveClasses_getInstance().mg());
}
function constructSerializerForGivenTypeArgs(_this__u8e3s4, args) {
  var tmp;
  try {
    // Inline function 'kotlin.reflect.findAssociatedObject' call
    var assocObject = findAssociatedObject(_this__u8e3s4, getKClass(SerializableWith));
    var tmp_0;
    if (!(assocObject == null) ? isInterface(assocObject, KSerializer) : false) {
      tmp_0 = isInterface(assocObject, KSerializer) ? assocObject : THROW_CCE();
    } else {
      if (!(assocObject == null) ? isInterface(assocObject, SerializerFactory) : false) {
        var tmp_1 = assocObject.g26(args.slice());
        tmp_0 = isInterface(tmp_1, KSerializer) ? tmp_1 : THROW_CCE();
      } else {
        tmp_0 = null;
      }
    }
    tmp = tmp_0;
  } catch ($p) {
    var tmp_2;
    var e = $p;
    tmp_2 = null;
    tmp = tmp_2;
  }
  return tmp;
}
function toNativeArrayImpl(_this__u8e3s4, eClass) {
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(_this__u8e3s4);
}
function getChecked(_this__u8e3s4, index) {
  if (!(0 <= index ? index <= (_this__u8e3s4.length - 1 | 0) : false))
    throw IndexOutOfBoundsException.me('Index ' + index + ' out of bounds ' + get_indices(_this__u8e3s4).toString());
  return _this__u8e3s4[index];
}
function getChecked_0(_this__u8e3s4, index) {
  if (!(0 <= index ? index <= (_this__u8e3s4.length - 1 | 0) : false))
    throw IndexOutOfBoundsException.me('Index ' + index + ' out of bounds ' + get_indices_0(_this__u8e3s4).toString());
  return _this__u8e3s4[index];
}
//region block: post-declaration
initMetadataForInterface(SerializationStrategy, 'SerializationStrategy');
initMetadataForInterface(DeserializationStrategy, 'DeserializationStrategy');
initMetadataForInterface(KSerializer, 'KSerializer', VOID, VOID, [SerializationStrategy, DeserializationStrategy]);
initMetadataForClass(AbstractPolymorphicSerializer, 'AbstractPolymorphicSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(PolymorphicSerializer, 'PolymorphicSerializer');
initMetadataForClass(SealedClassSerializer$$inlined$groupingBy$1);
initMetadataForClass(SealedClassSerializer, 'SealedClassSerializer');
initMetadataForClass(SerializationException, 'SerializationException', SerializationException.s1u);
initMetadataForClass(MissingFieldException, 'MissingFieldException');
initMetadataForClass(UnknownFieldException, 'UnknownFieldException');
initMetadataForInterface(SerialDescriptor, 'SerialDescriptor');
initMetadataForClass(ContextDescriptor, 'ContextDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForClass(elementDescriptors$1);
initMetadataForClass(elementDescriptors$$inlined$Iterable$1);
initMetadataForClass(elementNames$1);
initMetadataForClass(elementNames$$inlined$Iterable$1);
initMetadataForClass(ClassSerialDescriptorBuilder, 'ClassSerialDescriptorBuilder');
initMetadataForInterface(CachedNames, 'CachedNames');
protoOf(SerialDescriptorImpl).q1v = get_isNullable;
protoOf(SerialDescriptorImpl).v1v = get_isInline;
initMetadataForClass(SerialDescriptorImpl, 'SerialDescriptorImpl', VOID, VOID, [SerialDescriptor, CachedNames]);
initMetadataForClass(SerialKind, 'SerialKind');
initMetadataForObject(ENUM, 'ENUM');
initMetadataForObject(CONTEXTUAL, 'CONTEXTUAL');
initMetadataForClass(PolymorphicKind, 'PolymorphicKind');
initMetadataForObject(SEALED, 'SEALED');
initMetadataForObject(OPEN, 'OPEN');
initMetadataForClass(PrimitiveKind, 'PrimitiveKind');
initMetadataForObject(BOOLEAN, 'BOOLEAN');
initMetadataForObject(BYTE, 'BYTE');
initMetadataForObject(CHAR, 'CHAR');
initMetadataForObject(SHORT, 'SHORT');
initMetadataForObject(INT, 'INT');
initMetadataForObject(LONG, 'LONG');
initMetadataForObject(FLOAT, 'FLOAT');
initMetadataForObject(DOUBLE, 'DOUBLE');
initMetadataForObject(STRING, 'STRING');
initMetadataForClass(StructureKind, 'StructureKind');
initMetadataForObject(CLASS, 'CLASS');
initMetadataForObject(LIST, 'LIST');
initMetadataForObject(MAP, 'MAP');
initMetadataForObject(OBJECT, 'OBJECT');
initMetadataForInterface(Decoder, 'Decoder');
initMetadataForInterface(CompositeDecoder, 'CompositeDecoder');
protoOf(AbstractDecoder).d1y = decodeSerializableElement$default;
protoOf(AbstractDecoder).p1x = decodeSerializableValue;
protoOf(AbstractDecoder).g1y = decodeSequentially;
protoOf(AbstractDecoder).i1y = decodeCollectionSize;
initMetadataForClass(AbstractDecoder, 'AbstractDecoder', VOID, VOID, [Decoder, CompositeDecoder]);
initMetadataForInterface(Encoder, 'Encoder');
initMetadataForInterface(CompositeEncoder, 'CompositeEncoder');
protoOf(AbstractEncoder).m1z = encodeNotNullMark;
protoOf(AbstractEncoder).n1z = beginCollection;
protoOf(AbstractEncoder).j1z = encodeSerializableValue;
protoOf(AbstractEncoder).l1z = encodeNullableSerializableValue;
protoOf(AbstractEncoder).o1z = shouldEncodeElementDefault;
initMetadataForClass(AbstractEncoder, 'AbstractEncoder', VOID, VOID, [Encoder, CompositeEncoder]);
initMetadataForObject(NothingSerializer, 'NothingSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(DurationSerializer, 'DurationSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UuidSerializer, 'UuidSerializer', VOID, VOID, [KSerializer]);
protoOf(ListLikeDescriptor).q1v = get_isNullable;
protoOf(ListLikeDescriptor).v1v = get_isInline;
protoOf(ListLikeDescriptor).x1v = get_annotations;
initMetadataForClass(ListLikeDescriptor, 'ListLikeDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForClass(ArrayListClassDesc, 'ArrayListClassDesc');
initMetadataForClass(HashSetClassDesc, 'HashSetClassDesc');
initMetadataForClass(LinkedHashSetClassDesc, 'LinkedHashSetClassDesc');
protoOf(MapLikeDescriptor).q1v = get_isNullable;
protoOf(MapLikeDescriptor).v1v = get_isInline;
protoOf(MapLikeDescriptor).x1v = get_annotations;
initMetadataForClass(MapLikeDescriptor, 'MapLikeDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForClass(HashMapClassDesc, 'HashMapClassDesc');
initMetadataForClass(LinkedHashMapClassDesc, 'LinkedHashMapClassDesc');
initMetadataForClass(ArrayClassDesc, 'ArrayClassDesc');
initMetadataForClass(PrimitiveArrayDescriptor, 'PrimitiveArrayDescriptor');
initMetadataForClass(AbstractCollectionSerializer, 'AbstractCollectionSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(CollectionLikeSerializer, 'CollectionLikeSerializer');
initMetadataForClass(CollectionSerializer, 'CollectionSerializer');
initMetadataForClass(ArrayListSerializer, 'ArrayListSerializer');
initMetadataForClass(HashSetSerializer, 'HashSetSerializer');
initMetadataForClass(LinkedHashSetSerializer, 'LinkedHashSetSerializer');
initMetadataForClass(MapLikeSerializer, 'MapLikeSerializer');
initMetadataForClass(HashMapSerializer, 'HashMapSerializer');
initMetadataForClass(LinkedHashMapSerializer, 'LinkedHashMapSerializer');
initMetadataForClass(ReferenceArraySerializer, 'ReferenceArraySerializer');
initMetadataForClass(PrimitiveArraySerializer, 'PrimitiveArraySerializer');
initMetadataForClass(PrimitiveArrayBuilder, 'PrimitiveArrayBuilder');
initMetadataForCompanion(Companion);
initMetadataForClass(ElementMarker, 'ElementMarker');
initMetadataForClass(EnumSerializer, 'EnumSerializer', VOID, VOID, [KSerializer]);
protoOf(PluginGeneratedSerialDescriptor).q1v = get_isNullable;
protoOf(PluginGeneratedSerialDescriptor).v1v = get_isInline;
initMetadataForClass(PluginGeneratedSerialDescriptor, 'PluginGeneratedSerialDescriptor', VOID, VOID, [SerialDescriptor, CachedNames]);
initMetadataForClass(EnumDescriptor, 'EnumDescriptor');
initMetadataForClass(InlineClassDescriptor, 'InlineClassDescriptor');
initMetadataForInterface(GeneratedSerializer, 'GeneratedSerializer', VOID, VOID, [KSerializer]);
protoOf(InlinePrimitiveDescriptor$1).v25 = typeParametersSerializers;
initMetadataForClass(InlinePrimitiveDescriptor$1, VOID, VOID, VOID, [GeneratedSerializer]);
initMetadataForObject(NoOpEncoder, 'NoOpEncoder');
protoOf(NothingSerialDescriptor).q1v = get_isNullable;
protoOf(NothingSerialDescriptor).v1v = get_isInline;
protoOf(NothingSerialDescriptor).x1v = get_annotations;
initMetadataForObject(NothingSerialDescriptor, 'NothingSerialDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForClass(NullableSerializer, 'NullableSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(SerialDescriptorForNullable, 'SerialDescriptorForNullable', VOID, VOID, [SerialDescriptor, CachedNames]);
initMetadataForClass(ObjectSerializer, 'ObjectSerializer', VOID, VOID, [KSerializer]);
initMetadataForInterface(SerializerFactory, 'SerializerFactory');
initMetadataForObject(CharArraySerializer, 'CharArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(DoubleArraySerializer, 'DoubleArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(FloatArraySerializer, 'FloatArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(LongArraySerializer, 'LongArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(ULongArraySerializer, 'ULongArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(IntArraySerializer, 'IntArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(UIntArraySerializer, 'UIntArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(ShortArraySerializer, 'ShortArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(UShortArraySerializer, 'UShortArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(ByteArraySerializer, 'ByteArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(UByteArraySerializer, 'UByteArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(BooleanArraySerializer, 'BooleanArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForClass(CharArrayBuilder, 'CharArrayBuilder');
initMetadataForClass(DoubleArrayBuilder, 'DoubleArrayBuilder');
initMetadataForClass(FloatArrayBuilder, 'FloatArrayBuilder');
initMetadataForClass(LongArrayBuilder, 'LongArrayBuilder');
initMetadataForClass(ULongArrayBuilder, 'ULongArrayBuilder');
initMetadataForClass(IntArrayBuilder, 'IntArrayBuilder');
initMetadataForClass(UIntArrayBuilder, 'UIntArrayBuilder');
initMetadataForClass(ShortArrayBuilder, 'ShortArrayBuilder');
initMetadataForClass(UShortArrayBuilder, 'UShortArrayBuilder');
initMetadataForClass(ByteArrayBuilder, 'ByteArrayBuilder');
initMetadataForClass(UByteArrayBuilder, 'UByteArrayBuilder');
initMetadataForClass(BooleanArrayBuilder, 'BooleanArrayBuilder');
initMetadataForObject(StringSerializer, 'StringSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(CharSerializer, 'CharSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(DoubleSerializer, 'DoubleSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(FloatSerializer, 'FloatSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(LongSerializer, 'LongSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(IntSerializer, 'IntSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(ShortSerializer, 'ShortSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(ByteSerializer, 'ByteSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(BooleanSerializer, 'BooleanSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UnitSerializer, 'UnitSerializer', VOID, VOID, [KSerializer]);
protoOf(PrimitiveSerialDescriptor).q1v = get_isNullable;
protoOf(PrimitiveSerialDescriptor).v1v = get_isInline;
protoOf(PrimitiveSerialDescriptor).x1v = get_annotations;
initMetadataForClass(PrimitiveSerialDescriptor, 'PrimitiveSerialDescriptor', VOID, VOID, [SerialDescriptor]);
protoOf(TaggedEncoder).n1z = beginCollection;
protoOf(TaggedEncoder).j1z = encodeSerializableValue;
protoOf(TaggedEncoder).l1z = encodeNullableSerializableValue;
protoOf(TaggedEncoder).o1z = shouldEncodeElementDefault;
initMetadataForClass(TaggedEncoder, 'TaggedEncoder', VOID, VOID, [Encoder, CompositeEncoder]);
initMetadataForClass(NamedValueEncoder, 'NamedValueEncoder');
protoOf(TaggedDecoder).d1y = decodeSerializableElement$default;
protoOf(TaggedDecoder).p1x = decodeSerializableValue;
protoOf(TaggedDecoder).g1y = decodeSequentially;
protoOf(TaggedDecoder).i1y = decodeCollectionSize;
initMetadataForClass(TaggedDecoder, 'TaggedDecoder', VOID, VOID, [Decoder, CompositeDecoder]);
initMetadataForClass(NamedValueDecoder, 'NamedValueDecoder');
initMetadataForClass(MapEntry, 'MapEntry', VOID, VOID, [Entry]);
initMetadataForClass(KeyValueSerializer, 'KeyValueSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(MapEntrySerializer, 'MapEntrySerializer');
initMetadataForClass(PairSerializer, 'PairSerializer');
initMetadataForClass(TripleSerializer, 'TripleSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(ULongSerializer, 'ULongSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UIntSerializer, 'UIntSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UShortSerializer, 'UShortSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UByteSerializer, 'UByteSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(SerializersModule, 'SerializersModule');
initMetadataForClass(SerialModuleImpl, 'SerialModuleImpl');
initMetadataForClass(ContextualProvider, 'ContextualProvider');
initMetadataForClass(Argless, 'Argless');
initMetadataForClass(WithTypeArguments, 'WithTypeArguments');
initMetadataForInterface(SerializersModuleCollector, 'SerializersModuleCollector');
initMetadataForClass(SerializableWith, 'SerializableWith', VOID, VOID, VOID, VOID, 0);
initMetadataForClass(createCache$1);
initMetadataForClass(createParametrizedCache$1);
//endregion
//region block: exports
export {
  OPEN_getInstance as OPEN_getInstance1ppfglhtdde20,
  SEALED_getInstance as SEALED_getInstance15u0wl5f5h4qk,
  BOOLEAN_getInstance as BOOLEAN_getInstance1s8i8e2xmvmon,
  BYTE_getInstance as BYTE_getInstance3l0en7kumss35,
  CHAR_getInstance as CHAR_getInstance136x8e9sqt1t7,
  DOUBLE_getInstance as DOUBLE_getInstance3nog56dy847km,
  FLOAT_getInstance as FLOAT_getInstance1j10ivnvurzks,
  INT_getInstance as INT_getInstance3cjna3yzozsnp,
  LONG_getInstance as LONG_getInstance3ud8vh8r2ot7x,
  SHORT_getInstance as SHORT_getInstance34lbpnul1ebqc,
  STRING_getInstance as STRING_getInstance2gbamclnmtzqa,
  CONTEXTUAL_getInstance as CONTEXTUAL_getInstance40twmib99zqv,
  ENUM_getInstance as ENUM_getInstance3doea03ve3rgg,
  CLASS_getInstance as CLASS_getInstance1ss90e870vddp,
  LIST_getInstance as LIST_getInstance3iji3zetpdcxm,
  MAP_getInstance as MAP_getInstance2l4ulrz8ljw5i,
  OBJECT_getInstance as OBJECT_getInstancee89a3hlgr5ys,
  BooleanSerializer_getInstance as BooleanSerializer_getInstancet3wtk7fl7i4f,
  DoubleSerializer_getInstance as DoubleSerializer_getInstance2avi1jm48x8le,
  IntSerializer_getInstance as IntSerializer_getInstance9scrtcljaiv6,
  LongSerializer_getInstance as LongSerializer_getInstance3iic24guzegu7,
  StringSerializer_getInstance as StringSerializer_getInstance1k1oz5j50sfik,
  ListSerializer as ListSerializer1hxuk9dx5n9du,
  MapSerializer as MapSerializer11kmegt3g5c1g,
  get_nullable as get_nullable197rfua9r7fsz,
  serializer_1 as serializer1x79l67jvwntn,
  serializer_10 as serializer1q7c5q67ysppr,
  serializer_8 as serializer3ikrxnm8b29d6,
  serializer_12 as serializer36584sjyg5661,
  serializer_6 as serializer2lw83vwvpnyms,
  PolymorphicKind as PolymorphicKindla9gurooefwb,
  BOOLEAN as BOOLEANwrdyi6z6g9t5,
  BYTE as BYTE3998jn8in9237,
  CHAR as CHARm37y40it075g,
  DOUBLE as DOUBLExcx7tue0m1mu,
  FLOAT as FLOAT2bpqq59z4fuiu,
  INT as INT3fyso8r94fmo5,
  LONG as LONG2pk1o9ze1il7c,
  SHORT as SHORTo7q5gsuxaxs,
  STRING as STRINGrrr0wq2m1c2f,
  PrimitiveKind as PrimitiveKindndgbuh6is7ze,
  PrimitiveSerialDescriptor_0 as PrimitiveSerialDescriptor3egfp53lutxj2,
  get_annotations as get_annotationshjxdbdcl8kmv,
  get_isInline as get_isInline5x26qrhi9qs6,
  get_isNullable as get_isNullable36pbikm8xb7bz,
  SerialDescriptor as SerialDescriptor2pelqekb5ic3a,
  CONTEXTUAL as CONTEXTUAL2e1gz2tojnpmj,
  ENUM as ENUMlmq49cvwy4ow,
  CLASS as CLASS3e32wwn6b97hz,
  LIST as LIST2gzos3vzn3slg,
  MAP as MAPtg3mcyan4256,
  OBJECT as OBJECT2nknkrqb4pf7m,
  buildClassSerialDescriptor as buildClassSerialDescriptors2a6xdp6mrtw,
  buildSerialDescriptor as buildSerialDescriptor2873qmkp8r2ib,
  get_elementNames as get_elementNamesl5b6t976dltd,
  getContextualDescriptor as getContextualDescriptor2n1gf3b895yb8,
  get_nullable_0 as get_nullable1xmxlk8ba6b4f,
  AbstractDecoder as AbstractDecoder35guh02ubh2hm,
  AbstractEncoder as AbstractEncoder2gxtu3xmy3f8j,
  CompositeDecoder as CompositeDecoder2tzm7wpwkr0og,
  CompositeEncoder as CompositeEncoderknecpkexzn3v,
  Decoder as Decoder23nde051s631g,
  Encoder as Encoderqvmrpqtq8hnu,
  AbstractPolymorphicSerializer as AbstractPolymorphicSerializer1ccxwp48nfy58,
  ArrayListSerializer as ArrayListSerializer7k5wnrulb3y6,
  ElementMarker as ElementMarker33ojvsajwmzts,
  typeParametersSerializers as typeParametersSerializers2likxjr48tr7y,
  GeneratedSerializer as GeneratedSerializer1f7t7hssdd2ws,
  InlineClassDescriptor as InlineClassDescriptor2odlvyasjrmr0,
  InlinePrimitiveDescriptor as InlinePrimitiveDescriptor3i6ccn1a4fw94,
  NamedValueDecoder as NamedValueDecoderzk26ztf92xbq,
  NamedValueEncoder as NamedValueEncoder1lca9edk1lf89,
  PluginGeneratedSerialDescriptor as PluginGeneratedSerialDescriptorqdzeg5asqhfg,
  SerializerFactory as SerializerFactory1qv9hivitncuv,
  createSimpleEnumSerializer as createSimpleEnumSerializer2guioz11kk1m0,
  jsonCachedSerialNames as jsonCachedSerialNameslxufy2gu43jt,
  throwMissingFieldException as throwMissingFieldException2cmke0v3ynf14,
  EmptySerializersModule_0 as EmptySerializersModule991ju6pz9b79,
  contextual as contextual3hpp1gupsu4al,
  SerializersModuleCollector as SerializersModuleCollector3dddz14wd7brg,
  DeserializationStrategy as DeserializationStrategy1z3z5pj9f7zc8,
  KSerializer as KSerializerzf77vz1967fq,
  MissingFieldException as MissingFieldException24tqif29emcmi,
  SealedClassSerializer as SealedClassSerializeriwipiibk55zc,
  SerializationException as SerializationExceptioneqrdve3ts2n9,
  SerializationStrategy as SerializationStrategyh6ouydnm6hci,
  UnknownFieldException as UnknownFieldExceptiona60e3a6v1xqo,
  findPolymorphicSerializer_0 as findPolymorphicSerializer1nm87hvemahcj,
  findPolymorphicSerializer as findPolymorphicSerializerk638ixyjovk5,
  serializer_0 as serializer1hwzc6m64v1op,
};
//endregion

//# sourceMappingURL=kotlinx-serialization-kotlinx-serialization-core.mjs.map
