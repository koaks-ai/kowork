import {
  Companion_instance3fplhgf4ipvld as Companion_instance,
  Unit_instance104q5opgivhr8 as Unit_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  VOID7hggqo3abtya as VOID,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  toString30pk9tzaqopn as toString,
  hashCodeq5arwsb9dgti as hashCode,
  equals2au1ep9vhcato as equals,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  createFailure8paxfkfa5dc7 as createFailure,
  Result3t1vadv16kmzk as Result,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  toString1h6jjoch8cjt8 as toString_0,
  newThrowablezl37abp36p5f as newThrowable,
  stackTraceToString2670q6lbhdojj as stackTraceToString,
  protoOf180f3jzyo7rfj as protoOf,
  toLongw1zpgk99d84b as toLong,
  numberToLong1a4cndvg6c52s as numberToLong,
  intercepted2ogpsikxxj4u0 as intercepted,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  isInterface3d6p8outrmvmk as isInterface,
  returnIfSuspended31u0py81m9mma as returnIfSuspended,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  Long2qws0ah9gnpki as Long,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  captureStack1fzi4aczwc4hg as captureStack,
  replace3le3ie7l9k8aq as replace,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString_1,
  StringBuildermazzzhj6kkai as StringBuilder,
  closeFinally1sadm0w9gt3u4 as closeFinally,
  EmptyCoroutineContext_getInstance2bxophqwsfm9n as EmptyCoroutineContext_getInstance,
  Continuation1aa2oekvx7jm7 as Continuation,
  initMetadataForFunctionReferencen3g5fpj34t8u as initMetadataForFunctionReference,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  CancellationException3b36o9qz53rgr as CancellationException,
  ArrayList3it5z8td81qkl as ArrayList,
  listOf1jh22dvmctj1r as listOf,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  encodeToByteArray22651fhg4p67t as encodeToByteArray,
  AutoCloseable1l5p57f9lp7kv as AutoCloseable,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  replaceqbix900hl8kl as replace_0,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  toByte4i43936u611k as toByte,
  decodeToString1x4faah2liw2p as decodeToString,
  setOf45ia9pnfhe90 as setOf,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
} from './kotlin-kotlin-stdlib.mjs';
import {
  CancellableContinuationImpl1cx201opicavg as CancellableContinuationImpl,
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
  launch1c91vkjzdi9sd as launch,
  startCoroutineCancellable18shtfwdieib as startCoroutineCancellable,
  get_job2zvlvce9o9a29 as get_job,
  Job13y4jkazwjho0 as Job,
  cancel1xim2hrvjmwpn as cancel,
  CopyableThrowable1mvc99jcyvivf as CopyableThrowable,
} from './kotlinx-coroutines-core.mjs';
import {
  Buffergs925ekssbch as Buffer,
  IOException1wyutdmfe71nu as IOException,
  indexOf29nspdgx2e3ap as indexOf,
  readStringo8i62qxt5m4m as readString,
  EOFExceptionh831u25jcq9n as EOFException,
  readByteString2hnsbql6t4ads as readByteString,
  readString2nvggcfaijfhd as readString_0,
  readByteArray1fhzfwi2j014k as readByteArray,
  readString3v6duspiz33tv as readString_1,
  writeString33ca4btrgctw7 as writeString,
  readByteArray1ri21h2rciakw as readByteArray_0,
} from './kotlinx-io-kotlinx-io-core.mjs';
import { atomic$ref$130aurmcwdfdf1 as atomic$ref$1 } from './kotlinx-atomicfu.mjs';
import { decodeToString2ede220pr5xir as decodeToString_0 } from './kotlinx-io-kotlinx-io-bytestring.mjs';
//region block: imports
//endregion
//region block: pre-declaration
class Companion {
  constructor() {
    Companion_instance_0 = this;
    this.m1o_1 = new Closed(null);
    var tmp = this;
    // Inline function 'kotlin.Companion.success' call
    tmp.n1o_1 = _Result___init__impl__xyqfz8(Unit_instance);
  }
}
class Empty {
  toString() {
    return 'Empty';
  }
  hashCode() {
    return -231472095;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Empty))
      return false;
    other instanceof Empty || THROW_CCE();
    return true;
  }
}
class Closed {
  constructor(cause) {
    this.o1o_1 = cause;
  }
  toString() {
    return 'Closed(cause=' + toString(this.o1o_1) + ')';
  }
  hashCode() {
    return this.o1o_1 == null ? 0 : hashCode(this.o1o_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Closed))
      return false;
    var tmp0_other_with_cast = other instanceof Closed ? other : THROW_CCE();
    if (!equals(this.o1o_1, tmp0_other_with_cast.o1o_1))
      return false;
    return true;
  }
}
class Task {}
function resume() {
  return this.q1o().nc(Companion_getInstance().n1o_1);
}
function resume_0(throwable) {
  var tmp = this.q1o();
  var tmp_0;
  if (throwable == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.Companion.failure' call
    var tmp$ret$2 = _Result___init__impl__xyqfz8(createFailure(throwable));
    tmp_0 = new Result(tmp$ret$2);
  }
  var tmp1_elvis_lhs = tmp_0;
  return tmp.nc(tmp1_elvis_lhs == null ? Companion_getInstance().n1o_1 : tmp1_elvis_lhs.zr_1);
}
class Read {
  constructor(continuation) {
    this.u1o_1 = continuation;
    this.v1o_1 = null;
    if (get_DEVELOPMENT_MODE()) {
      var tmp = this;
      // Inline function 'kotlin.also' call
      var this_0 = newThrowable('ReadTask 0x' + toString_0(hashCode(this.u1o_1), 16));
      stackTraceToString(this_0);
      tmp.v1o_1 = this_0;
    }
  }
  q1o() {
    return this.u1o_1;
  }
  p1o() {
    return this.v1o_1;
  }
  r1o() {
    return 'read';
  }
}
class Write {
  constructor(continuation) {
    this.w1o_1 = continuation;
    this.x1o_1 = null;
    if (get_DEVELOPMENT_MODE()) {
      var tmp = this;
      // Inline function 'kotlin.also' call
      var this_0 = newThrowable('WriteTask 0x' + toString_0(hashCode(this.w1o_1), 16));
      stackTraceToString(this_0);
      tmp.x1o_1 = this_0;
    }
  }
  q1o() {
    return this.w1o_1;
  }
  p1o() {
    return this.x1o_1;
  }
  r1o() {
    return 'write';
  }
}
class ByteReadChannel {}
function awaitContent$default(min, $completion, $super) {
  min = min === VOID ? 1 : min;
  return $super === VOID ? this.f1q(min, $completion) : $super.f1q.call(this, min, $completion);
}
class ByteChannel {
  constructor(autoFlush) {
    autoFlush = autoFlush === VOID ? false : autoFlush;
    this.y1o_1 = autoFlush;
    this.z1o_1 = new Buffer();
    this.a1p_1 = 0;
    this.b1p_1 = new Object();
    this.c1p_1 = atomic$ref$1(Empty_instance);
    this.d1p_1 = new Buffer();
    this.e1p_1 = new Buffer();
    this.f1p_1 = atomic$ref$1(null);
  }
  x1p() {
    var tmp0_safe_receiver = this.f1p_1.kotlinx$atomicfu$value;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.z1p(ClosedReadChannelException$_init_$ref_ix0089());
    }
    if (this.d1p_1.h1l()) {
      moveFlushToReadBuffer(this);
    }
    return this.d1p_1;
  }
  a1q() {
    if (this.b1q()) {
      var tmp0_safe_receiver = this.f1p_1.kotlinx$atomicfu$value;
      var tmp;
      if (tmp0_safe_receiver == null) {
        tmp = null;
      } else {
        tmp = tmp0_safe_receiver.z1p(ClosedWriteChannelException$_init_$ref_ef15ty());
      }
      if (tmp == null)
        throw ClosedWriteChannelException.w1p();
    }
    return this.e1p_1;
  }
  c1q() {
    var tmp0_safe_receiver = this.f1p_1.kotlinx$atomicfu$value;
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.d1q();
  }
  b1q() {
    return !(this.f1p_1.kotlinx$atomicfu$value == null);
  }
  e1q() {
    return !(this.c1q() == null) || (this.b1q() && this.a1p_1 === 0 && this.d1p_1.h1l());
  }
  f1q(min, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_awaitContent__vf28kb.bind(VOID, this, min), $completion);
  }
  m1p($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_flush__owbk1c.bind(VOID, this), $completion);
  }
  l1p() {
    if (this.e1p_1.h1l())
      return Unit_instance;
    // Inline function 'io.ktor.utils.io.locks.synchronized' call
    this.b1p_1;
    var count = this.e1p_1.b1().x1();
    this.z1o_1.y1m(this.e1p_1);
    this.a1p_1 = this.a1p_1 + count | 0;
    // Inline function 'io.ktor.utils.io.ByteChannel.resumeSlot' call
    var current = this.c1p_1.kotlinx$atomicfu$value;
    var tmp;
    if (current instanceof Read) {
      tmp = this.c1p_1.atomicfu$compareAndSet(current, Empty_instance);
    } else {
      tmp = false;
    }
    if (tmp) {
      current.s1o();
    }
  }
  a6() {
    this.l1p();
    if (!this.f1p_1.atomicfu$compareAndSet(null, get_CLOSED()))
      return Unit_instance;
    closeSlot(this, null);
  }
  h1q($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_flushAndClose__wsi7db.bind(VOID, this), $completion);
  }
  i1q(cause) {
    if (!(this.f1p_1.kotlinx$atomicfu$value == null))
      return Unit_instance;
    var closedToken = new CloseToken(cause);
    this.f1p_1.atomicfu$compareAndSet(null, closedToken);
    var wrappedCause = closedToken.d1q();
    closeSlot(this, wrappedCause);
  }
  toString() {
    return 'ByteChannel[' + hashCode(this) + ']';
  }
}
class ConcurrentIOException extends IllegalStateException {
  static k1p(taskName, cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.pd('Concurrent ' + taskName + ' attempts', cause);
    captureStack($this, $this.j1p_1);
    return $this;
  }
}
class ByteChannelScanner {
  constructor(channel, matchString, writeChannel, limit) {
    limit = limit === VOID ? new Long(-1, 2147483647) : limit;
    this.j1q_1 = channel;
    this.k1q_1 = matchString;
    this.l1q_1 = writeChannel;
    this.m1q_1 = limit;
    // Inline function 'kotlin.require' call
    if (!(this.k1q_1.b1() > 0)) {
      var message = 'Empty match string not permitted for scanning';
      throw IllegalArgumentException.t(toString_1(message));
    }
    this.n1q_1 = this.j1q_1.x1p();
    this.o1q_1 = buildPartialMatchTable(this);
    this.p1q_1 = new Buffer();
    this.q1q_1 = new Long(0, 0);
    this.r1q_1 = 0;
  }
  s1q(ignoreMissing, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_findNext__stdkn8.bind(VOID, this, ignoreMissing), $completion);
  }
}
class ByteReadChannel$Companion$Empty$1 {
  constructor() {
    this.t1q_1 = null;
    this.u1q_1 = new Buffer();
  }
  c1q() {
    return this.t1q_1;
  }
  e1q() {
    return true;
  }
  x1p() {
    return this.u1q_1;
  }
  f1q(min, $completion) {
    return false;
  }
  i1q(cause) {
  }
}
class Companion_0 {
  constructor() {
    Companion_instance_1 = this;
    var tmp = this;
    tmp.v1q_1 = new ByteReadChannel$Companion$Empty$1();
  }
}
class WriterJob {
  constructor(channel, job) {
    this.g1r_1 = channel;
    this.h1r_1 = job;
  }
  ux() {
    return this.h1r_1;
  }
}
class WriterScope {
  constructor(channel, coroutineContext) {
    this.i1r_1 = channel;
    this.j1r_1 = coroutineContext;
  }
  ru() {
    return this.j1r_1;
  }
}
class NO_CALLBACK$1 {
  constructor() {
    this.k1r_1 = EmptyCoroutineContext_getInstance();
  }
  lc() {
    return this.k1r_1;
  }
  mc(result) {
    return Unit_instance;
  }
  nc(result) {
    return this.mc(result);
  }
}
class ByteWriteChannel$flushAndClose$ref {
  constructor($boundThis) {
    this.l1r_1 = $boundThis;
  }
  vd($completion) {
    return this.l1r_1.h1q($completion);
  }
}
class writer$slambda {
  constructor($block, $channel) {
    this.m1r_1 = $block;
    this.n1r_1 = $channel;
  }
  r1f($this$launch, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8.bind(VOID, this, $this$launch), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class CloseToken {
  constructor(origin) {
    this.y1p_1 = origin;
  }
  s1r(wrap) {
    var tmp0_subject = this.y1p_1;
    var tmp;
    if (tmp0_subject == null) {
      tmp = null;
    } else {
      if (!(tmp0_subject == null) ? isInterface(tmp0_subject, CopyableThrowable) : false) {
        tmp = this.y1p_1.m12();
      } else {
        if (tmp0_subject instanceof CancellationException) {
          tmp = CancellationException.od(this.y1p_1.message, this.y1p_1);
        } else {
          tmp = wrap(this.y1p_1);
        }
      }
    }
    return tmp;
  }
  d1q(wrap, $super) {
    var tmp;
    if (wrap === VOID) {
      tmp = ClosedByteChannelException$_init_$ref_yjp351();
    } else {
      tmp = wrap;
    }
    wrap = tmp;
    return $super === VOID ? this.s1r(wrap) : $super.s1r.call(this, wrap);
  }
  z1p(wrap) {
    var tmp0_safe_receiver = this.s1r(wrap);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      throw tmp0_safe_receiver;
    }
    return tmp;
  }
}
class CountedByteReadChannel {
  constructor(delegate) {
    this.t1r_1 = delegate;
    this.u1r_1 = new Buffer();
    this.v1r_1 = new Long(0, 0);
    this.w1r_1 = new Long(0, 0);
  }
  x1r() {
    updateConsumed(this);
    return this.w1r_1;
  }
  c1q() {
    return this.t1r_1.c1q();
  }
  e1q() {
    return this.u1r_1.h1l() && this.t1r_1.e1q();
  }
  x1p() {
    transferFromDelegate(this);
    return this.u1r_1;
  }
  f1q(min, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_awaitContent__vf28kb_0.bind(VOID, this, min), $completion);
  }
  i1q(cause) {
    this.t1r_1.i1q(cause);
    this.u1r_1.a6();
  }
}
class ClosedByteChannelException extends IOException {
  static r1r(cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.k1o(cause == null ? null : cause.message, cause);
    captureStack($this, $this.q1r_1);
    return $this;
  }
}
class ClosedReadChannelException extends ClosedByteChannelException {
  static r1p(cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.r1r(cause);
    captureStack($this, $this.q1p_1);
    return $this;
  }
}
class ClosedWriteChannelException extends ClosedByteChannelException {
  static w1p(cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.r1r(cause);
    captureStack($this, $this.v1p_1);
    return $this;
  }
}
class Companion_1 {
  constructor() {
    Companion_instance_2 = this;
    this.w1q_1 = _LineEndingMode___init__impl__jo5bul(1);
    this.x1q_1 = _LineEndingMode___init__impl__jo5bul(2);
    this.y1q_1 = _LineEndingMode___init__impl__jo5bul(4);
    this.z1q_1 = _LineEndingMode___init__impl__jo5bul(7);
    this.a1r_1 = listOf([new LineEndingMode(this.w1q_1), new LineEndingMode(this.x1q_1), new LineEndingMode(this.y1q_1)]);
  }
}
class LineEndingMode {
  constructor(mode) {
    Companion_getInstance_1();
    this.y1r_1 = mode;
  }
  toString() {
    return LineEndingMode__toString_impl_j4h76r(this.y1r_1);
  }
  hashCode() {
    return LineEndingMode__hashCode_impl_2mopm4(this.y1r_1);
  }
  equals(other) {
    return LineEndingMode__equals_impl_qyr4nk(this.y1r_1, other);
  }
}
class SourceByteReadChannel {
  constructor(source) {
    this.z1r_1 = source;
    this.a1s_1 = null;
  }
  c1q() {
    var tmp0_safe_receiver = this.a1s_1;
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.d1q();
  }
  e1q() {
    return this.z1r_1.h1l();
  }
  x1p() {
    var tmp0_safe_receiver = this.c1q();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      throw tmp0_safe_receiver;
    }
    return this.z1r_1.g1l();
  }
  f1q(min, $completion) {
    var tmp0_safe_receiver = this.c1q();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      throw tmp0_safe_receiver;
    }
    return this.z1r_1.j1l(toLong(min));
  }
  i1q(cause) {
    if (!(this.a1s_1 == null))
      return Unit_instance;
    this.z1r_1.a6();
    var tmp = this;
    var tmp1_elvis_lhs = cause == null ? null : cause.message;
    tmp.a1s_1 = new CloseToken(IOException.k1o(tmp1_elvis_lhs == null ? 'Channel was cancelled' : tmp1_elvis_lhs, cause));
  }
}
class MalformedInputException extends IOException {
  static e1s(message) {
    var $this = this.j1o(message);
    captureStack($this, $this.d1s_1);
    return $this;
  }
}
class TooLongLineException extends MalformedInputException {
  static f1r(message) {
    var $this = this.e1s(message);
    captureStack($this, $this.e1r_1);
    return $this;
  }
}
class ObjectPool {}
function close() {
  this.ix();
}
class DefaultPool {
  constructor(capacity) {
    this.o1s_1 = capacity;
    var tmp = this;
    // Inline function 'kotlin.arrayOfNulls' call
    var size = this.o1s_1;
    tmp.p1s_1 = Array(size);
    this.q1s_1 = 0;
  }
  r1s(instance) {
  }
  s1s(instance) {
    return instance;
  }
  t1s(instance) {
  }
  u1s() {
    if (this.q1s_1 === 0)
      return this.n1s();
    this.q1s_1 = this.q1s_1 - 1 | 0;
    var idx = this.q1s_1;
    var tmp = this.p1s_1[idx];
    var instance = !(tmp == null) ? tmp : THROW_CCE();
    this.p1s_1[idx] = null;
    return this.s1s(instance);
  }
  v1s(instance) {
    this.t1s(instance);
    if (this.q1s_1 === this.o1s_1) {
      this.r1s(instance);
    } else {
      var _unary__edvuaz = this.q1s_1;
      this.q1s_1 = _unary__edvuaz + 1 | 0;
      this.p1s_1[_unary__edvuaz] = instance;
    }
  }
  ix() {
    var inductionVariable = 0;
    var last = this.q1s_1;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = this.p1s_1[i];
        var instance = !(tmp == null) ? tmp : THROW_CCE();
        this.p1s_1[i] = null;
        this.r1s(instance);
      }
       while (inductionVariable < last);
    this.q1s_1 = 0;
  }
}
class ByteArrayPool$1 extends DefaultPool {
  constructor() {
    super(128);
  }
  n1s() {
    return new Int8Array(4096);
  }
}
class NoPoolImpl {
  v1s(instance) {
    return Unit_instance;
  }
  ix() {
    return Unit_instance;
  }
}
class Companion_2 {
  w1s(name) {
    switch (name) {
      case 'UTF-8':
      case 'utf-8':
      case 'UTF8':
      case 'utf8':
        return Charsets_getInstance().f1s_1;
    }
    var tmp;
    var tmp_0;
    switch (name) {
      case 'ISO-8859-1':
      case 'iso-8859-1':
        tmp_0 = true;
        break;
      default:
        // Inline function 'kotlin.let' call

        var it = replace_0(name, _Char___init__impl__6a9atx(95), _Char___init__impl__6a9atx(45));
        var tmp_1;
        if (it === 'iso-8859-1') {
          tmp_1 = true;
        } else {
          // Inline function 'kotlin.text.lowercase' call
          // Inline function 'kotlin.js.asDynamic' call
          tmp_1 = it.toLowerCase() === 'iso-8859-1';
        }

        tmp_0 = tmp_1;
        break;
    }
    if (tmp_0) {
      tmp = true;
    } else {
      tmp = name === 'latin1' || name === 'Latin1';
    }
    if (tmp) {
      return Charsets_getInstance().g1s_1;
    }
    throw IllegalArgumentException.t('Charset ' + name + ' is not supported');
  }
}
class Charset {
  constructor(_name) {
    this.h1s_1 = _name;
  }
  equals(other) {
    if (this === other)
      return true;
    if (other == null || !(this.constructor == other.constructor))
      return false;
    if (!(other instanceof Charset))
      THROW_CCE();
    return this.h1s_1 === other.h1s_1;
  }
  hashCode() {
    return getStringHashCode(this.h1s_1);
  }
  toString() {
    return this.h1s_1;
  }
}
class Charsets {
  constructor() {
    Charsets_instance = this;
    this.f1s_1 = new CharsetImpl('UTF-8');
    this.g1s_1 = new CharsetImpl('ISO-8859-1');
  }
}
class CharsetDecoder {
  constructor(_charset) {
    this.x1s_1 = _charset;
  }
}
class CharsetEncoder {
  constructor(_charset) {
    this.y1s_1 = _charset;
  }
}
class CharsetImpl extends Charset {
  i1s() {
    return new CharsetEncoderImpl(this);
  }
  j1s() {
    return new CharsetDecoderImpl(this);
  }
}
class CharsetEncoderImpl extends CharsetEncoder {
  constructor(charset) {
    super(charset);
    this.b1t_1 = charset;
  }
  toString() {
    return 'CharsetEncoderImpl(charset=' + this.b1t_1.toString() + ')';
  }
  hashCode() {
    return this.b1t_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CharsetEncoderImpl))
      return false;
    var tmp0_other_with_cast = other instanceof CharsetEncoderImpl ? other : THROW_CCE();
    if (!this.b1t_1.equals(tmp0_other_with_cast.b1t_1))
      return false;
    return true;
  }
}
class CharsetDecoderImpl extends CharsetDecoder {
  constructor(charset) {
    super(charset);
    this.d1t_1 = charset;
  }
  toString() {
    return 'CharsetDecoderImpl(charset=' + this.d1t_1.toString() + ')';
  }
  hashCode() {
    return this.d1t_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CharsetDecoderImpl))
      return false;
    var tmp0_other_with_cast = other instanceof CharsetDecoderImpl ? other : THROW_CCE();
    if (!this.d1t_1.equals(tmp0_other_with_cast.d1t_1))
      return false;
    return true;
  }
}
class toKtor$1 {
  constructor($this_toKtor) {
    this.f1t_1 = $this_toKtor;
  }
  e1t(buffer) {
    return this.f1t_1.decode(buffer);
  }
}
class TextDecoderFallback {
  constructor(encoding, fatal) {
    this.g1t_1 = fatal;
    // Inline function 'kotlin.text.trim' call
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var requestedEncoding = toString_1(trim(isCharSequence(encoding) ? encoding : THROW_CCE())).toLowerCase();
    // Inline function 'kotlin.check' call
    if (!get_ENCODING_ALIASES().v2(requestedEncoding)) {
      var message = encoding + ' is not supported.';
      throw IllegalStateException.t4(toString_1(message));
    }
  }
  e1t(buffer) {
    // Inline function 'io.ktor.utils.io.core.buildPacket' call
    var builder = new Buffer();
    var bytes = buffer instanceof Int8Array ? buffer : THROW_CCE();
    var inductionVariable = 0;
    var last = bytes.length;
    if (inductionVariable < last)
      $l$loop: do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'org.khronos.webgl.get' call
        // Inline function 'kotlin.js.asDynamic' call
        var byte = bytes[index];
        var point = toCodePoint(byte);
        if (point < 0) {
          // Inline function 'kotlin.check' call
          if (!!this.g1t_1) {
            var message = 'Invalid character: ' + point;
            throw IllegalStateException.t4(toString_1(message));
          }
          writeFully_0(builder, get_REPLACEMENT());
          continue $l$loop;
        }
        if (point > 255) {
          builder.z1m(toByte(point >> 8));
        }
        builder.z1m(toByte(point & 255));
      }
       while (inductionVariable < last);
    return decodeToString(readByteArray_0(builder));
  }
}
//endregion
var Companion_instance_0;
function Companion_getInstance() {
  if (Companion_instance_0 === VOID)
    new Companion();
  return Companion_instance_0;
}
var Empty_instance;
function Empty_getInstance() {
  return Empty_instance;
}
function *_generator_awaitContent__vf28kb($this, min, $completion) {
  rethrowCloseCauseIfNeeded_0($this);
  if ($this.d1p_1.b1().s1(toLong(min)) >= 0)
    return true;
  // Inline function 'io.ktor.utils.io.ByteChannel.sleepWhile' call
  $l$loop: while (numberToLong($this.a1p_1).u3($this.d1p_1.b1()).s1(toLong(min)) < 0 && $this.f1p_1.kotlinx$atomicfu$value == null) {
    // Inline function 'kotlinx.coroutines.suspendCancellableCoroutine' call
    // Inline function 'kotlin.js.suspendCoroutineUninterceptedOrReturnJS' call
    var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
    cancellable.iy();
    var tmp1 = new Read(cancellable);
    $l$block_0: {
      // Inline function 'io.ktor.utils.io.ByteChannel.trySuspend' call
      var previous = $this.c1p_1.kotlinx$atomicfu$value;
      if (!(previous instanceof Closed)) {
        if (!$this.c1p_1.atomicfu$compareAndSet(previous, tmp1)) {
          tmp1.s1o();
          break $l$block_0;
        }
      }
      if (previous instanceof Read) {
        previous.t1o(ConcurrentIOException.k1p(tmp1.r1o(), previous.p1o()));
      } else {
        if (isInterface(previous, Task)) {
          previous.s1o();
        } else {
          if (previous instanceof Closed) {
            tmp1.t1o(previous.o1o_1);
            break $l$block_0;
          } else {
            if (!equals(previous, Empty_instance)) {
              noWhenBranchMatchedException();
            }
          }
        }
      }
      if (!(numberToLong($this.a1p_1).u3($this.d1p_1.b1()).s1(toLong(min)) < 0 && $this.f1p_1.kotlinx$atomicfu$value == null)) {
        // Inline function 'io.ktor.utils.io.ByteChannel.resumeSlot' call
        var current = $this.c1p_1.kotlinx$atomicfu$value;
        var tmp;
        if (current instanceof Read) {
          tmp = $this.c1p_1.atomicfu$compareAndSet(current, Empty_instance);
        } else {
          tmp = false;
        }
        if (tmp) {
          current.s1o();
        }
      }
    }
    var tmp$ret$6 = cancellable.jy();
    var tmp_0 = returnIfSuspended(tmp$ret$6, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
  }
  if ($this.d1p_1.b1().s1(new Long(1048576, 0)) < 0) {
    moveFlushToReadBuffer($this);
  }
  return $this.d1p_1.b1().s1(toLong(min)) >= 0;
}
function moveFlushToReadBuffer($this) {
  // Inline function 'io.ktor.utils.io.locks.synchronized' call
  $this.b1p_1;
  $this.z1o_1.k1m($this.d1p_1);
  $this.a1p_1 = 0;
  // Inline function 'io.ktor.utils.io.ByteChannel.resumeSlot' call
  var current = $this.c1p_1.kotlinx$atomicfu$value;
  var tmp;
  if (current instanceof Write) {
    tmp = $this.c1p_1.atomicfu$compareAndSet(current, Empty_instance);
  } else {
    tmp = false;
  }
  if (tmp) {
    current.s1o();
  }
}
function *_generator_flush__owbk1c($this, $completion) {
  rethrowCloseCauseIfNeeded_0($this);
  $this.l1p();
  if ($this.a1p_1 < 1048576)
    return Unit_instance;
  // Inline function 'io.ktor.utils.io.ByteChannel.sleepWhile' call
  $l$loop: while ($this.a1p_1 >= 1048576 && $this.f1p_1.kotlinx$atomicfu$value == null) {
    // Inline function 'kotlinx.coroutines.suspendCancellableCoroutine' call
    // Inline function 'kotlin.js.suspendCoroutineUninterceptedOrReturnJS' call
    var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
    cancellable.iy();
    var tmp1 = new Write(cancellable);
    $l$block_0: {
      // Inline function 'io.ktor.utils.io.ByteChannel.trySuspend' call
      var previous = $this.c1p_1.kotlinx$atomicfu$value;
      if (!(previous instanceof Closed)) {
        if (!$this.c1p_1.atomicfu$compareAndSet(previous, tmp1)) {
          tmp1.s1o();
          break $l$block_0;
        }
      }
      if (previous instanceof Write) {
        previous.t1o(ConcurrentIOException.k1p(tmp1.r1o(), previous.p1o()));
      } else {
        if (isInterface(previous, Task)) {
          previous.s1o();
        } else {
          if (previous instanceof Closed) {
            tmp1.t1o(previous.o1o_1);
            break $l$block_0;
          } else {
            if (!equals(previous, Empty_instance)) {
              noWhenBranchMatchedException();
            }
          }
        }
      }
      if (!($this.a1p_1 >= 1048576 && $this.f1p_1.kotlinx$atomicfu$value == null)) {
        // Inline function 'io.ktor.utils.io.ByteChannel.resumeSlot' call
        var current = $this.c1p_1.kotlinx$atomicfu$value;
        var tmp;
        if (current instanceof Write) {
          tmp = $this.c1p_1.atomicfu$compareAndSet(current, Empty_instance);
        } else {
          tmp = false;
        }
        if (tmp) {
          current.s1o();
        }
      }
    }
    var tmp$ret$6 = cancellable.jy();
    var tmp_0 = returnIfSuspended(tmp$ret$6, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
  }
  return Unit_instance;
}
function *_generator_flushAndClose__wsi7db($this, $completion) {
  // Inline function 'kotlin.runCatching' call
  var tmp;
  try {
    var tmp_0 = $this.m1p($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    // Inline function 'kotlin.Companion.success' call
    tmp = _Result___init__impl__xyqfz8(Unit_instance);
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var e = $p;
      // Inline function 'kotlin.Companion.failure' call
      tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  if (!$this.f1p_1.atomicfu$compareAndSet(null, get_CLOSED()))
    return Unit_instance;
  closeSlot($this, null);
  return Unit_instance;
}
function closeSlot($this, cause) {
  var closeContinuation = !(cause == null) ? new Closed(cause) : Companion_getInstance().m1o_1;
  var continuation = $this.c1p_1.atomicfu$getAndSet(closeContinuation);
  if (isInterface(continuation, Task)) {
    continuation.t1o(cause);
  }
}
function ClosedReadChannelException$_init_$ref_ix0089() {
  var l = (p0) => ClosedReadChannelException.r1p(p0);
  l.callableName = '<init>';
  return l;
}
function ClosedWriteChannelException$_init_$ref_ef15ty() {
  var l = (p0) => ClosedWriteChannelException.w1p(p0);
  l.callableName = '<init>';
  return l;
}
function ByteReadChannel_0(content, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? content.length : length;
  // Inline function 'kotlin.also' call
  var this_0 = new Buffer();
  this_0.q1m(content, offset, offset + length | 0);
  var source = this_0;
  return ByteReadChannel_1(source);
}
function ByteReadChannel_1(source) {
  return new SourceByteReadChannel(source);
}
function *_generator_findNext__stdkn8($this, ignoreMissing, $completion) {
  $this.q1q_1 = new Long(0, 0);
  $l$loop: while (true) {
    var tmp;
    if (!$this.n1q_1.h1l()) {
      tmp = true;
    } else {
      var tmp_0 = $this.j1q_1.g1q(VOID, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      tmp = tmp_0;
    }
    if (!tmp) {
      break $l$loop;
    }
    var tmp_1 = advanceToNextPotentialMatch($this, $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    var tmp_2 = checkFullMatch($this, $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    if (tmp_2) {
      return $this.q1q_1;
    }
  }
  if (!ignoreMissing) {
    throw IOException.j1o('Expected "' + toSingleLineString($this, $this.k1q_1) + '" but encountered end of input');
  }
  $this.q1q_1 = $this.q1q_1.u3($this.p1q_1.k1m($this.l1q_1.a1q()));
  var tmp_3 = $this.l1q_1.m1p($completion);
  if (tmp_3 === get_COROUTINE_SUSPENDED())
    tmp_3 = yield tmp_3;
  return $this.q1q_1;
}
function buildPartialMatchTable($this) {
  var table = new Int32Array($this.k1q_1.b1());
  var j = 0;
  var inductionVariable = 1;
  var last = $this.k1q_1.b1();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      while (j > 0 && !($this.k1q_1.f1(i) === $this.k1q_1.f1(j))) {
        j = table[j - 1 | 0];
      }
      if ($this.k1q_1.f1(i) === $this.k1q_1.f1(j)) {
        j = j + 1 | 0;
      }
      table[i] = j;
    }
     while (inductionVariable < last);
  return table;
}
function *_generator_advanceToNextPotentialMatch__2ypy7x($this, $completion) {
  $l$loop: while (true) {
    var tmp;
    if (!$this.n1q_1.h1l()) {
      tmp = true;
    } else {
      var tmp_0 = $this.j1q_1.g1q(VOID, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      tmp = tmp_0;
    }
    if (!tmp) {
      break $l$loop;
    }
    var nextMatch = indexOf($this.n1q_1, $this.k1q_1.f1(0));
    if (nextMatch.equals(new Long(-1, -1))) {
      var tmp_1 = $this.n1q_1;
      checkBounds($this, (tmp_1 instanceof Buffer ? tmp_1 : THROW_CCE()).b1());
      $this.q1q_1 = $this.q1q_1.u3($this.n1q_1.k1m($this.l1q_1.a1q()));
      var tmp_2 = flushIfNeeded($this.l1q_1, $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
    } else {
      checkBounds($this, nextMatch);
      var tmp_3 = $this;
      var tmp_4 = $this.q1q_1;
      var tmp_5 = $this.l1q_1.a1q();
      tmp_3.q1q_1 = tmp_4.u3($this.n1q_1.h1m(tmp_5 instanceof Buffer ? tmp_5 : THROW_CCE(), nextMatch));
      var tmp_6 = flushIfNeeded($this.l1q_1, $completion);
      if (tmp_6 === get_COROUTINE_SUSPENDED())
        tmp_6 = yield tmp_6;
      return Unit_instance;
    }
  }
  return Unit_instance;
}
function advanceToNextPotentialMatch($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_advanceToNextPotentialMatch__2ypy7x.bind(VOID, $this), $completion);
}
function *_generator_checkFullMatch__turpx6($this, $completion) {
  $l$loop: while (true) {
    var tmp;
    if (!$this.n1q_1.h1l()) {
      tmp = true;
    } else {
      var tmp_0 = $this.j1q_1.g1q(VOID, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      tmp = tmp_0;
    }
    if (!tmp) {
      break $l$loop;
    }
    var byte = $this.n1q_1.k1l();
    if ($this.r1q_1 > 0 && !(byte === $this.k1q_1.f1($this.r1q_1))) {
      var oldMatchIndex = $this.r1q_1;
      while ($this.r1q_1 > 0 && !(byte === $this.k1q_1.f1($this.r1q_1))) {
        $this.r1q_1 = $this.o1q_1[$this.r1q_1 - 1 | 0];
      }
      var retained = toLong(oldMatchIndex - $this.r1q_1 | 0);
      checkBounds($this, retained);
      var tmp_1 = $this;
      var tmp_2 = $this.q1q_1;
      var tmp_3 = $this.l1q_1.a1q();
      tmp_1.q1q_1 = tmp_2.u3($this.p1q_1.h1m(tmp_3 instanceof Buffer ? tmp_3 : THROW_CCE(), retained));
      if ($this.r1q_1 === 0 && !(byte === $this.k1q_1.f1($this.r1q_1))) {
        var tmp_4 = writeByte($this.l1q_1, byte, $completion);
        if (tmp_4 === get_COROUTINE_SUSPENDED())
          tmp_4 = yield tmp_4;
        $this.q1q_1 = $this.q1q_1.z3();
        return false;
      }
    }
    $this.r1q_1 = $this.r1q_1 + 1 | 0;
    if ($this.r1q_1 === $this.k1q_1.b1()) {
      return true;
    }
    $this.p1q_1.z1m(byte);
  }
  return false;
}
function checkFullMatch($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_checkFullMatch__turpx6.bind(VOID, $this), $completion);
}
function checkBounds($this, extra) {
  if ($this.q1q_1.u3(extra).s1($this.m1q_1) > 0) {
    throw IOException.j1o('Limit of ' + $this.m1q_1.toString() + ' bytes exceeded ' + ('while searching for "' + toSingleLineString($this, $this.k1q_1) + '"'));
  }
}
function toSingleLineString($this, _this__u8e3s4) {
  return replace(decodeToString_0(_this__u8e3s4), '\n', '\\n');
}
var Companion_instance_1;
function Companion_getInstance_0() {
  if (Companion_instance_1 === VOID)
    new Companion_0();
  return Companion_instance_1;
}
function cancel_0(_this__u8e3s4) {
  _this__u8e3s4.i1q(IOException.j1o('Channel was cancelled'));
}
function *_generator_readRemaining__kd4xx0(_this__u8e3s4, $completion) {
  var result = BytePacketBuilder();
  while (!_this__u8e3s4.e1q()) {
    result.y1m(_this__u8e3s4.x1p());
    var tmp = _this__u8e3s4.g1q(VOID, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }
  rethrowCloseCauseIfNeeded(_this__u8e3s4);
  return result.g1l();
}
function readRemaining(_this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readRemaining__kd4xx0.bind(VOID, _this__u8e3s4), $completion);
}
function *_generator_discard__skcevq(_this__u8e3s4, max, $completion) {
  max = max === VOID ? new Long(-1, 2147483647) : max;
  var remaining = max;
  while (remaining.s1(new Long(0, 0)) > 0 && !_this__u8e3s4.e1q()) {
    if (get_availableForRead(_this__u8e3s4) === 0) {
      var tmp = _this__u8e3s4.g1q(VOID, $completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
    }
    var tmp0 = remaining;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = get_remaining(_this__u8e3s4.x1p());
    var count = tmp0.s1(b) <= 0 ? tmp0 : b;
    discard_0(_this__u8e3s4.x1p(), count);
    remaining = remaining.v3(count);
  }
  return max.v3(remaining);
}
function discard(_this__u8e3s4, max, $completion) {
  max = max === VOID ? new Long(-1, 2147483647) : max;
  return suspendOrReturn(/*#__NOINLINE__*/_generator_discard__skcevq.bind(VOID, _this__u8e3s4, max), $completion);
}
function *_generator_readAvailable__ki7w73(_this__u8e3s4, buffer, offset, length, $completion) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? buffer.length - offset | 0 : length;
  if (_this__u8e3s4.e1q())
    return -1;
  if (_this__u8e3s4.x1p().h1l()) {
    var tmp = _this__u8e3s4.g1q(VOID, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }
  if (_this__u8e3s4.e1q())
    return -1;
  return readAvailable_0(_this__u8e3s4.x1p(), buffer, offset, length);
}
function readAvailable(_this__u8e3s4, buffer, offset, length, $completion) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? buffer.length - offset | 0 : length;
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readAvailable__ki7w73.bind(VOID, _this__u8e3s4, buffer, offset, length), $completion);
}
function *_generator_readUTF8Line__dbdzfx(_this__u8e3s4, max, $completion) {
  max = max === VOID ? 2147483647 : max;
  var result = StringBuilder.v();
  var tmp = readUTF8LineTo(_this__u8e3s4, result, max, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var completed = tmp;
  return !completed ? null : result.toString();
}
function readUTF8Line(_this__u8e3s4, max, $completion) {
  max = max === VOID ? 2147483647 : max;
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readUTF8Line__dbdzfx.bind(VOID, _this__u8e3s4, max), $completion);
}
function *_generator_toByteArray__v3q9dq(_this__u8e3s4, $completion) {
  var tmp = readBuffer(_this__u8e3s4, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return readBytes(tmp);
}
function toByteArray(_this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_toByteArray__v3q9dq.bind(VOID, _this__u8e3s4), $completion);
}
function *_generator_copyTo__iu4794(_this__u8e3s4, channel, limit, $completion) {
  var remaining = limit;
  try {
    while (!_this__u8e3s4.e1q() && remaining.s1(new Long(0, 0)) > 0) {
      if (_this__u8e3s4.x1p().h1l()) {
        var tmp = _this__u8e3s4.g1q(VOID, $completion);
        if (tmp === get_COROUTINE_SUSPENDED())
          tmp = yield tmp;
      }
      var tmp0 = remaining;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = get_remaining(_this__u8e3s4.x1p());
      var count = tmp0.s1(b) <= 0 ? tmp0 : b;
      _this__u8e3s4.x1p().j1m(channel.a1q(), count);
      remaining = remaining.v3(count);
      var tmp_0 = channel.m1p($completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var cause = $p;
      _this__u8e3s4.i1q(cause);
      close_0(channel, cause);
      throw cause;
    } else {
      throw $p;
    }
  }
  finally {
    var tmp_1 = channel.m1p($completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
  }
  return limit.v3(remaining);
}
function copyTo(_this__u8e3s4, channel, limit, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_copyTo__iu4794.bind(VOID, _this__u8e3s4, channel, limit), $completion);
}
function rethrowCloseCauseIfNeeded(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.c1q();
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    throw tmp0_safe_receiver;
  }
}
function get_availableForRead(_this__u8e3s4) {
  return _this__u8e3s4.x1p().g1l().b1().x1();
}
function readUTF8LineTo(_this__u8e3s4, out, max, $completion) {
  max = max === VOID ? 2147483647 : max;
  return readUTF8LineTo_0(_this__u8e3s4, out, max, Companion_getInstance_1().z1q_1, $completion);
}
function *_generator_readBuffer__s1sw5u(_this__u8e3s4, $completion) {
  var result = new Buffer();
  while (!_this__u8e3s4.e1q()) {
    result.y1m(_this__u8e3s4.x1p());
    var tmp = _this__u8e3s4.g1q(VOID, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }
  var tmp0_safe_receiver = _this__u8e3s4.c1q();
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    throw tmp0_safe_receiver;
  }
  return result;
}
function readBuffer(_this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readBuffer__s1sw5u.bind(VOID, _this__u8e3s4), $completion);
}
function *_generator_readUTF8LineTo__bg1rci(_this__u8e3s4, out, max, lineEnding, $completion) {
  max = max === VOID ? 2147483647 : max;
  lineEnding = lineEnding === VOID ? Companion_getInstance_1().z1q_1 : lineEnding;
  if (_this__u8e3s4.x1p().h1l()) {
    var tmp = _this__u8e3s4.g1q(VOID, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }
  if (_this__u8e3s4.e1q())
    return false;
  // Inline function 'kotlin.use' call
  var this_0 = new Buffer();
  var exception = null;
  try {
    while (!_this__u8e3s4.e1q()) {
      while (!_this__u8e3s4.x1p().h1l()) {
        var b = _this__u8e3s4.x1p().k1l();
        if (b === 13) {
          if (_this__u8e3s4.x1p().h1l()) {
            var tmp_0 = _this__u8e3s4.g1q(VOID, $completion);
            if (tmp_0 === get_COROUTINE_SUSPENDED())
              tmp_0 = yield tmp_0;
          }
          if (_this__u8e3s4.x1p().g1l().c1m(new Long(0, 0)) === 10) {
            readUTF8LineTo$checkLineEndingAllowed(lineEnding, Companion_getInstance_1().y1q_1);
            discard_0(_this__u8e3s4.x1p(), new Long(1, 0));
          } else {
            readUTF8LineTo$checkLineEndingAllowed(lineEnding, Companion_getInstance_1().w1q_1);
          }
          out.w(readString(this_0));
          return true;
        } else if (b === 10) {
          readUTF8LineTo$checkLineEndingAllowed(lineEnding, Companion_getInstance_1().x1q_1);
          out.w(readString(this_0));
          return true;
        } else {
          this_0.z1m(b);
        }
      }
      if (this_0.b1().s1(toLong(max)) >= 0) {
        throw TooLongLineException.f1r('Line exceeds limit of ' + max + ' characters');
      }
      var tmp_1 = _this__u8e3s4.g1q(VOID, $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
    }
    // Inline function 'kotlin.also' call
    var this_1 = this_0.b1().s1(new Long(0, 0)) > 0;
    if (this_1) {
      out.w(readString(this_0));
    }
    return this_1;
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      exception = e;
      throw e;
    } else {
      throw $p;
    }
  }
  finally {
    closeFinally(this_0, exception);
  }
}
function readUTF8LineTo_0(_this__u8e3s4, out, max, lineEnding, $completion) {
  max = max === VOID ? 2147483647 : max;
  lineEnding = lineEnding === VOID ? Companion_getInstance_1().z1q_1 : lineEnding;
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readUTF8LineTo__bg1rci.bind(VOID, _this__u8e3s4, out, max, lineEnding), $completion);
}
function rethrowCloseCauseIfNeeded_0(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.c1q();
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    throw tmp0_safe_receiver;
  }
}
function rethrowCloseCauseIfNeeded_1(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.c1q();
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    throw tmp0_safe_receiver;
  }
}
function *_generator_skipIfFound__8uzshe(_this__u8e3s4, byteString, $completion) {
  var tmp = peek(_this__u8e3s4, byteString.b1(), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  if (equals(tmp, byteString)) {
    var tmp_0 = discard(_this__u8e3s4, toLong(byteString.b1()), $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    return true;
  }
  return false;
}
function skipIfFound(_this__u8e3s4, byteString, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_skipIfFound__8uzshe.bind(VOID, _this__u8e3s4, byteString), $completion);
}
function *_generator_readPacket__axk2oa(_this__u8e3s4, packet, $completion) {
  var result = new Buffer();
  $l$loop: while (result.b1().s1(toLong(packet)) < 0) {
    if (_this__u8e3s4.x1p().h1l()) {
      var tmp = _this__u8e3s4.g1q(VOID, $completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
    }
    if (_this__u8e3s4.e1q())
      break $l$loop;
    if (get_remaining(_this__u8e3s4.x1p()).s1(numberToLong(packet).v3(result.b1())) > 0) {
      _this__u8e3s4.x1p().j1m(result, numberToLong(packet).v3(result.b1()));
    } else {
      _this__u8e3s4.x1p().k1m(result);
    }
  }
  if (result.b1().s1(toLong(packet)) < 0) {
    throw EOFException.f1l('Not enough data available, required ' + packet + ' bytes but only ' + result.b1().toString() + ' available');
  }
  return result;
}
function readPacket(_this__u8e3s4, packet, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readPacket__axk2oa.bind(VOID, _this__u8e3s4, packet), $completion);
}
function readUntil(_this__u8e3s4, matchString, writeChannel, limit, ignoreMissing, $completion) {
  limit = limit === VOID ? new Long(-1, 2147483647) : limit;
  ignoreMissing = ignoreMissing === VOID ? false : ignoreMissing;
  return (new ByteChannelScanner(_this__u8e3s4, matchString, writeChannel, limit)).s1q(ignoreMissing, $completion);
}
function *_generator_peek__qjkkqb(_this__u8e3s4, count, $completion) {
  if (_this__u8e3s4.e1q())
    return null;
  var tmp = _this__u8e3s4.f1q(count, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  if (!tmp)
    return null;
  return readByteString(_this__u8e3s4.x1p().l1m(), count);
}
function peek(_this__u8e3s4, count, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_peek__qjkkqb.bind(VOID, _this__u8e3s4, count), $completion);
}
function readUTF8LineTo$checkLineEndingAllowed($lineEnding, lineEndingToCheck) {
  if (!LineEndingMode__contains_impl_q5pr68($lineEnding, lineEndingToCheck)) {
    throw IOException.j1o('Unexpected line ending ' + LineEndingMode__toString_impl_j4h76r(lineEndingToCheck) + ', while expected ' + LineEndingMode__toString_impl_j4h76r($lineEnding));
  }
}
function *_generator_flushIfNeeded__xji6le(_this__u8e3s4, $completion) {
  rethrowCloseCauseIfNeeded_1(_this__u8e3s4);
  var tmp;
  var tmp0_safe_receiver = _this__u8e3s4 instanceof ByteChannel ? _this__u8e3s4 : null;
  if ((tmp0_safe_receiver == null ? null : tmp0_safe_receiver.y1o_1) === true) {
    tmp = true;
  } else {
    tmp = get_size(_this__u8e3s4.a1q()) >= 1048576;
  }
  if (tmp) {
    var tmp_0 = _this__u8e3s4.m1p($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
  }
  return Unit_instance;
}
function flushIfNeeded(_this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_flushIfNeeded__xji6le.bind(VOID, _this__u8e3s4), $completion);
}
function get_NO_CALLBACK() {
  _init_properties_ByteWriteChannelOperations_kt__i7slrs();
  return NO_CALLBACK;
}
var NO_CALLBACK;
function writer(_this__u8e3s4, coroutineContext, autoFlush, block) {
  coroutineContext = coroutineContext === VOID ? EmptyCoroutineContext_getInstance() : coroutineContext;
  autoFlush = autoFlush === VOID ? false : autoFlush;
  _init_properties_ByteWriteChannelOperations_kt__i7slrs();
  return writer_0(_this__u8e3s4, coroutineContext, new ByteChannel(), block);
}
function *_generator_writeFully__hb5mir(_this__u8e3s4, value, startIndex, endIndex, $completion) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  endIndex = endIndex === VOID ? value.length : endIndex;
  _this__u8e3s4.a1q().q1m(value, startIndex, endIndex);
  var tmp = flushIfNeeded(_this__u8e3s4, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function writeFully(_this__u8e3s4, value, startIndex, endIndex, $completion) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  endIndex = endIndex === VOID ? value.length : endIndex;
  return suspendOrReturn(/*#__NOINLINE__*/_generator_writeFully__hb5mir.bind(VOID, _this__u8e3s4, value, startIndex, endIndex), $completion);
}
function close_0(_this__u8e3s4, cause) {
  _init_properties_ByteWriteChannelOperations_kt__i7slrs();
  if (cause == null) {
    fireAndForget(ByteWriteChannel$flushAndClose$ref_0(_this__u8e3s4));
  } else {
    _this__u8e3s4.i1q(cause);
  }
}
function invokeOnCompletion(_this__u8e3s4, block) {
  _init_properties_ByteWriteChannelOperations_kt__i7slrs();
  return _this__u8e3s4.ux().uv(block);
}
function writer_0(_this__u8e3s4, coroutineContext, channel, block) {
  coroutineContext = coroutineContext === VOID ? EmptyCoroutineContext_getInstance() : coroutineContext;
  _init_properties_ByteWriteChannelOperations_kt__i7slrs();
  // Inline function 'kotlin.apply' call
  var this_0 = launch(_this__u8e3s4, coroutineContext, VOID, writer$slambda_0(block, channel));
  this_0.uv(writer$lambda(channel));
  var job = this_0;
  return new WriterJob(channel, job);
}
function fireAndForget(_this__u8e3s4) {
  _init_properties_ByteWriteChannelOperations_kt__i7slrs();
  startCoroutineCancellable(_this__u8e3s4, get_NO_CALLBACK());
}
function *_generator_writeByte__k05tl9(_this__u8e3s4, value, $completion) {
  _this__u8e3s4.a1q().z1m(value);
  var tmp = flushIfNeeded(_this__u8e3s4, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function writeByte(_this__u8e3s4, value, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_writeByte__k05tl9.bind(VOID, _this__u8e3s4, value), $completion);
}
function ByteWriteChannel$flushAndClose$ref_0($boundThis) {
  var i = new ByteWriteChannel$flushAndClose$ref($boundThis);
  var l = ($completion) => i.vd($completion);
  l.callableName = 'flushAndClose';
  l.$arity = 0;
  return l;
}
function *_generator_invoke__zhh2q8($this, $this$launch, $completion) {
  var nested = Job(get_job($this$launch.ru()));
  try {
    var tmp = $this.m1r_1(new WriterScope($this.n1r_1, $this$launch.ru().kn(nested)), $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    nested.b12();
    if (get_job($this$launch.ru()).ov()) {
      $this.n1r_1.i1q(get_job($this$launch.ru()).rv());
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var cause = $p;
      cancel(nested, 'Exception thrown while writing to channel', cause);
      $this.n1r_1.i1q(cause);
    } else {
      throw $p;
    }
  }
  finally {
    var tmp_0 = nested.yv($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    // Inline function 'kotlin.runCatching' call
    var tmp_1;
    try {
      var tmp_2 = $this.n1r_1.h1q($completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      // Inline function 'kotlin.Companion.success' call
      tmp_1 = _Result___init__impl__xyqfz8(Unit_instance);
    } catch ($p) {
      var tmp_3;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_3 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_1 = tmp_3;
    }
  }
  return Unit_instance;
}
function writer$slambda_0($block, $channel) {
  var i = new writer$slambda($block, $channel);
  var l = ($this$launch, $completion) => i.r1f($this$launch, $completion);
  l.$arity = 1;
  return l;
}
function writer$lambda($channel) {
  return (it) => {
    var tmp;
    if (!(it == null) && !$channel.b1q()) {
      $channel.i1q(it);
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
var properties_initialized_ByteWriteChannelOperations_kt_acrf6u;
function _init_properties_ByteWriteChannelOperations_kt__i7slrs() {
  if (!properties_initialized_ByteWriteChannelOperations_kt_acrf6u) {
    properties_initialized_ByteWriteChannelOperations_kt_acrf6u = true;
    NO_CALLBACK = new NO_CALLBACK$1();
  }
}
function get_CLOSED() {
  _init_properties_CloseToken_kt__9ucr41();
  return CLOSED;
}
var CLOSED;
function ClosedByteChannelException$_init_$ref_yjp351() {
  var l = (p0) => ClosedByteChannelException.r1r(p0);
  l.callableName = '<init>';
  return l;
}
var properties_initialized_CloseToken_kt_lgg8zn;
function _init_properties_CloseToken_kt__9ucr41() {
  if (!properties_initialized_CloseToken_kt_lgg8zn) {
    properties_initialized_CloseToken_kt_lgg8zn = true;
    CLOSED = new CloseToken(null);
  }
}
function *_generator_awaitContent__vf28kb_0($this, min, $completion) {
  if ($this.x1p().b1().s1(toLong(min)) >= 0) {
    return true;
  }
  var tmp = $this.t1r_1.f1q(min, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  if (tmp) {
    transferFromDelegate($this);
    return true;
  }
  return false;
}
function transferFromDelegate($this) {
  updateConsumed($this);
  var appended = $this.u1r_1.y1m($this.t1r_1.x1p());
  $this.v1r_1 = $this.v1r_1.u3(appended);
}
function updateConsumed($this) {
  $this.w1r_1 = $this.w1r_1.u3($this.v1r_1.v3($this.u1r_1.b1()));
  $this.v1r_1 = $this.u1r_1.b1();
}
function counted(_this__u8e3s4) {
  return new CountedByteReadChannel(_this__u8e3s4);
}
function readText(_this__u8e3s4) {
  return readString_0(_this__u8e3s4);
}
function _LineEndingMode___init__impl__jo5bul(mode) {
  return mode;
}
function _get_mode__dah3bc($this) {
  return $this;
}
function LineEndingMode__contains_impl_q5pr68($this, other) {
  return (_get_mode__dah3bc($this) | _get_mode__dah3bc(other)) === _get_mode__dah3bc($this);
}
function LineEndingMode__plus_impl_ttpz2j($this, other) {
  return _LineEndingMode___init__impl__jo5bul(_get_mode__dah3bc($this) | _get_mode__dah3bc(other));
}
function LineEndingMode__toString_impl_j4h76r($this) {
  var tmp;
  if ($this === Companion_getInstance_1().w1q_1) {
    tmp = 'CR';
  } else if ($this === Companion_getInstance_1().x1q_1) {
    tmp = 'LF';
  } else if ($this === Companion_getInstance_1().y1q_1) {
    tmp = 'CRLF';
  } else {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = Companion_getInstance_1().a1r_1;
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var it = element.y1r_1;
      if (LineEndingMode__contains_impl_q5pr68($this, it)) {
        destination.l(element);
      }
    }
    tmp = toString_1(destination);
  }
  return tmp;
}
var Companion_instance_2;
function Companion_getInstance_1() {
  if (Companion_instance_2 === VOID)
    new Companion_1();
  return Companion_instance_2;
}
function LineEndingMode__hashCode_impl_2mopm4($this) {
  return $this;
}
function LineEndingMode__equals_impl_qyr4nk($this, other) {
  if (!(other instanceof LineEndingMode))
    return false;
  if (!($this === (other instanceof LineEndingMode ? other.y1r_1 : THROW_CCE())))
    return false;
  return true;
}
function decode(_this__u8e3s4, input, max) {
  max = max === VOID ? 2147483647 : max;
  var tmp0 = toLong(max);
  // Inline function 'kotlin.comparisons.minOf' call
  var b = input.g1l().b1();
  // Inline function 'kotlin.text.buildString' call
  var capacity = (tmp0.s1(b) <= 0 ? tmp0 : b).x1();
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.xb(capacity);
  decode_0(_this__u8e3s4, input, this_0, max);
  return this_0.toString();
}
function encodeToImpl(_this__u8e3s4, destination, input, fromIndex, toIndex) {
  var start = fromIndex;
  if (start >= toIndex)
    return Unit_instance;
  $l$loop: while (true) {
    var rc = encodeImpl(_this__u8e3s4, input, start, toIndex, destination);
    // Inline function 'kotlin.check' call
    if (!(rc >= 0)) {
      throw IllegalStateException.t4('Check failed.');
    }
    start = start + rc | 0;
    if (start >= toIndex)
      break $l$loop;
  }
}
function encode(_this__u8e3s4, input, fromIndex, toIndex) {
  fromIndex = fromIndex === VOID ? 0 : fromIndex;
  toIndex = toIndex === VOID ? charSequenceLength(input) : toIndex;
  // Inline function 'io.ktor.utils.io.core.buildPacket' call
  var builder = new Buffer();
  encodeToImpl(_this__u8e3s4, builder, input, fromIndex, toIndex);
  return builder;
}
function canRead(_this__u8e3s4) {
  return !_this__u8e3s4.h1l();
}
function readBytes(_this__u8e3s4, count) {
  count = count === VOID ? _this__u8e3s4.b1().x1() : count;
  return readByteArray(_this__u8e3s4, count);
}
function writeFully_0(_this__u8e3s4, buffer, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? buffer.length - offset | 0 : length;
  _this__u8e3s4.q1m(buffer, offset, offset + length | 0);
}
function BytePacketBuilder() {
  return new Buffer();
}
function get_size(_this__u8e3s4) {
  return _this__u8e3s4.g1l().b1().x1();
}
var ByteReadPacketEmpty;
function get_remaining(_this__u8e3s4) {
  _init_properties_ByteReadPacket_kt__28475y();
  return _this__u8e3s4.g1l().b1();
}
function discard_0(_this__u8e3s4, count) {
  count = count === VOID ? new Long(-1, 2147483647) : count;
  _init_properties_ByteReadPacket_kt__28475y();
  _this__u8e3s4.j1l(count);
  // Inline function 'kotlin.comparisons.minOf' call
  var b = get_remaining(_this__u8e3s4);
  var countToDiscard = count.s1(b) <= 0 ? count : b;
  _this__u8e3s4.g1l().e1m(countToDiscard);
  return countToDiscard;
}
function takeWhile(_this__u8e3s4, block) {
  _init_properties_ByteReadPacket_kt__28475y();
  while (!_this__u8e3s4.h1l() && block(_this__u8e3s4.g1l())) {
  }
}
var properties_initialized_ByteReadPacket_kt_hw4st4;
function _init_properties_ByteReadPacket_kt__28475y() {
  if (!properties_initialized_ByteReadPacket_kt_hw4st4) {
    properties_initialized_ByteReadPacket_kt_hw4st4 = true;
    ByteReadPacketEmpty = new Buffer();
  }
}
function readAvailable_0(_this__u8e3s4, buffer, offset, length) {
  offset = offset === VOID ? 0 : offset;
  length = length === VOID ? buffer.length - offset | 0 : length;
  var result = _this__u8e3s4.f1m(buffer, offset, offset + length | 0);
  return result === -1 ? 0 : result;
}
function toByteArray_0(_this__u8e3s4, charset) {
  charset = charset === VOID ? Charsets_getInstance().f1s_1 : charset;
  if (charset.equals(Charsets_getInstance().f1s_1))
    return encodeToByteArray(_this__u8e3s4, VOID, VOID, true);
  return encodeToByteArray_0(charset.i1s(), _this__u8e3s4, 0, _this__u8e3s4.length);
}
function readText_0(_this__u8e3s4, charset, max) {
  charset = charset === VOID ? Charsets_getInstance().f1s_1 : charset;
  max = max === VOID ? 2147483647 : max;
  if (charset.equals(Charsets_getInstance().f1s_1)) {
    if (max === 2147483647)
      return readString_0(_this__u8e3s4);
    var tmp0 = _this__u8e3s4.g1l().b1();
    // Inline function 'kotlin.math.min' call
    var b = toLong(max);
    var count = tmp0.s1(b) <= 0 ? tmp0 : b;
    return readString_1(_this__u8e3s4, count);
  }
  return decode(charset.j1s(), _this__u8e3s4, max);
}
function writeText(_this__u8e3s4, text, fromIndex, toIndex, charset) {
  fromIndex = fromIndex === VOID ? 0 : fromIndex;
  toIndex = toIndex === VOID ? charSequenceLength(text) : toIndex;
  charset = charset === VOID ? Charsets_getInstance().f1s_1 : charset;
  if (charset === Charsets_getInstance().f1s_1) {
    return writeString(_this__u8e3s4, toString_1(text), fromIndex, toIndex);
  }
  encodeToImpl(charset.i1s(), _this__u8e3s4, text, fromIndex, toIndex);
}
function get_ByteArrayPool() {
  _init_properties_ByteArrayPool_kt__kfi3uj();
  return ByteArrayPool;
}
var ByteArrayPool;
var properties_initialized_ByteArrayPool_kt_td6pfh;
function _init_properties_ByteArrayPool_kt__kfi3uj() {
  if (!properties_initialized_ByteArrayPool_kt_td6pfh) {
    properties_initialized_ByteArrayPool_kt_td6pfh = true;
    ByteArrayPool = new ByteArrayPool$1();
  }
}
var Companion_instance_3;
function Companion_getInstance_2() {
  return Companion_instance_3;
}
function get_name(_this__u8e3s4) {
  return _this__u8e3s4.h1s_1;
}
var Charsets_instance;
function Charsets_getInstance() {
  if (Charsets_instance === VOID)
    new Charsets();
  return Charsets_instance;
}
function encodeToByteArray_0(_this__u8e3s4, input, fromIndex, toIndex) {
  fromIndex = fromIndex === VOID ? 0 : fromIndex;
  toIndex = toIndex === VOID ? charSequenceLength(input) : toIndex;
  return encodeToByteArrayImpl(_this__u8e3s4, input, fromIndex, toIndex);
}
function encodeToByteArrayImpl(_this__u8e3s4, input, fromIndex, toIndex) {
  fromIndex = fromIndex === VOID ? 0 : fromIndex;
  toIndex = toIndex === VOID ? charSequenceLength(input) : toIndex;
  var start = fromIndex;
  if (start >= toIndex)
    return new Int8Array(0);
  var dst = new Buffer();
  var rc = encodeImpl(_this__u8e3s4, input, start, toIndex, dst);
  start = start + rc | 0;
  if (start === toIndex) {
    return readByteArray_0(dst);
  }
  encodeToImpl(_this__u8e3s4, dst, input, start, toIndex);
  return readByteArray_0(dst);
}
function encodeImpl(_this__u8e3s4, input, fromIndex, toIndex, dst) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(fromIndex <= toIndex)) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException.t(toString_1(message));
  }
  if (get_charset(_this__u8e3s4).equals(Charsets_getInstance().g1s_1)) {
    return encodeISO88591(input, fromIndex, toIndex, dst);
  }
  // Inline function 'kotlin.require' call
  if (!(get_charset(_this__u8e3s4) === Charsets_getInstance().f1s_1)) {
    var message_0 = 'Only UTF-8 encoding is supported in JS';
    throw IllegalArgumentException.t(toString_1(message_0));
  }
  var encoder = new TextEncoder();
  // Inline function 'kotlin.text.substring' call
  var tmp$ret$5 = toString_1(charSequenceSubSequence(input, fromIndex, toIndex));
  var result = encoder.encode(tmp$ret$5);
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  dst.t1m(result);
  return result.length;
}
function get_charset(_this__u8e3s4) {
  return _this__u8e3s4.y1s_1;
}
function decode_0(_this__u8e3s4, input, dst, max) {
  var decoder = Decoder(get_name(get_charset_0(_this__u8e3s4)), true);
  var tmp0 = input.g1l().b1();
  // Inline function 'kotlin.comparisons.minOf' call
  var b = toLong(max);
  var count = tmp0.s1(b) <= 0 ? tmp0 : b;
  var tmp = readByteArray(input, count.x1());
  var array = tmp instanceof Int8Array ? tmp : THROW_CCE();
  var tmp_0;
  try {
    tmp_0 = decoder.e1t(array);
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var cause = $p;
      var tmp0_elvis_lhs = cause.message;
      throw MalformedInputException.e1s('Failed to decode bytes: ' + (tmp0_elvis_lhs == null ? 'no cause provided' : tmp0_elvis_lhs));
    } else {
      throw $p;
    }
  }
  var result = tmp_0;
  dst.w(result);
  return result.length;
}
function get_charset_0(_this__u8e3s4) {
  return _this__u8e3s4.x1s_1;
}
function forName(_this__u8e3s4, name) {
  return Companion_instance_3.w1s(name);
}
function Decoder(encoding, fatal) {
  fatal = fatal === VOID ? true : fatal;
  var tmp;
  try {
    tmp = toKtor(new TextDecoder(encoding, textDecoderOptions(fatal)));
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var cause = $p;
      tmp_0 = new TextDecoderFallback(encoding, fatal);
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function toKtor(_this__u8e3s4) {
  return new toKtor$1(_this__u8e3s4);
}
function textDecoderOptions(fatal) {
  fatal = fatal === VOID ? false : fatal;
  // Inline function 'kotlin.apply' call
  var this_0 = new Object();
  // Inline function 'kotlin.js.asDynamic' call
  // Inline function 'kotlin.with' call
  this_0.fatal = fatal;
  return this_0;
}
function get_ENCODING_ALIASES() {
  _init_properties_TextDecoderFallback_js_kt__an7r6m();
  return ENCODING_ALIASES;
}
var ENCODING_ALIASES;
function get_REPLACEMENT() {
  _init_properties_TextDecoderFallback_js_kt__an7r6m();
  return REPLACEMENT;
}
var REPLACEMENT;
function toCodePoint(_this__u8e3s4) {
  _init_properties_TextDecoderFallback_js_kt__an7r6m();
  var value = _this__u8e3s4 & 255;
  if (isASCII(value)) {
    return value;
  }
  return get_WIN1252_TABLE()[value - 128 | 0];
}
function isASCII(_this__u8e3s4) {
  _init_properties_TextDecoderFallback_js_kt__an7r6m();
  return 0 <= _this__u8e3s4 ? _this__u8e3s4 <= 127 : false;
}
var properties_initialized_TextDecoderFallback_js_kt_6rekzk;
function _init_properties_TextDecoderFallback_js_kt__an7r6m() {
  if (!properties_initialized_TextDecoderFallback_js_kt_6rekzk) {
    properties_initialized_TextDecoderFallback_js_kt_6rekzk = true;
    ENCODING_ALIASES = setOf(['ansi_x3.4-1968', 'ascii', 'cp1252', 'cp819', 'csisolatin1', 'ibm819', 'iso-8859-1', 'iso-ir-100', 'iso8859-1', 'iso88591', 'iso_8859-1', 'iso_8859-1:1987', 'l1', 'latin1', 'us-ascii', 'windows-1252', 'x-cp1252']);
    // Inline function 'kotlin.byteArrayOf' call
    REPLACEMENT = new Int8Array([-17, -65, -67]);
  }
}
function get_DEVELOPMENT_MODE() {
  return false;
}
function encodeISO88591(input, fromIndex, toIndex, dst) {
  if (fromIndex >= toIndex)
    return 0;
  var inductionVariable = fromIndex;
  if (inductionVariable < toIndex)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(input, index);
      var character = Char__toInt_impl_vasixd(this_0);
      if (character > 255) {
        failedToMapError(character);
      }
      dst.z1m(toByte(character));
    }
     while (inductionVariable < toIndex);
  return toIndex - fromIndex | 0;
}
function failedToMapError(ch) {
  throw MalformedInputException.e1s('The character with unicode point ' + ch + " couldn't be mapped to ISO-8859-1 character");
}
function get_WIN1252_TABLE() {
  _init_properties_Win1252Table_kt__tl0v64();
  return WIN1252_TABLE;
}
var WIN1252_TABLE;
var properties_initialized_Win1252Table_kt_pkmjoq;
function _init_properties_Win1252Table_kt__tl0v64() {
  if (!properties_initialized_Win1252Table_kt_pkmjoq) {
    properties_initialized_Win1252Table_kt_pkmjoq = true;
    // Inline function 'kotlin.intArrayOf' call
    WIN1252_TABLE = new Int32Array([8364, -1, 8218, 402, 8222, 8230, 8224, 8225, 710, 8240, 352, 8249, 338, -1, 381, -1, -1, 8216, 8217, 8220, 8221, 8226, 8211, 8212, 732, 8482, 353, 8250, 339, -1, 382, 376, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255]);
  }
}
//region block: post-declaration
initMetadataForCompanion(Companion);
initMetadataForObject(Empty, 'Empty');
initMetadataForClass(Closed, 'Closed');
initMetadataForInterface(Task, 'Task');
protoOf(Read).s1o = resume;
protoOf(Read).t1o = resume_0;
initMetadataForClass(Read, 'Read', VOID, VOID, [Task]);
protoOf(Write).s1o = resume;
protoOf(Write).t1o = resume_0;
initMetadataForClass(Write, 'Write', VOID, VOID, [Task]);
initMetadataForInterface(ByteReadChannel, 'ByteReadChannel', VOID, VOID, VOID, [1]);
protoOf(ByteChannel).g1q = awaitContent$default;
initMetadataForClass(ByteChannel, 'ByteChannel', ByteChannel, VOID, [ByteReadChannel], [1, 0]);
initMetadataForClass(ConcurrentIOException, 'ConcurrentIOException');
initMetadataForClass(ByteChannelScanner, 'ByteChannelScanner', VOID, VOID, VOID, [1, 0]);
protoOf(ByteReadChannel$Companion$Empty$1).g1q = awaitContent$default;
initMetadataForClass(ByteReadChannel$Companion$Empty$1, VOID, VOID, VOID, [ByteReadChannel], [1]);
initMetadataForCompanion(Companion_0);
initMetadataForClass(WriterJob, 'WriterJob');
initMetadataForClass(WriterScope, 'WriterScope', VOID, VOID, [CoroutineScope]);
initMetadataForClass(NO_CALLBACK$1, VOID, VOID, VOID, [Continuation]);
initMetadataForFunctionReference(ByteWriteChannel$flushAndClose$ref, VOID, VOID, [0]);
initMetadataForLambda(writer$slambda, VOID, VOID, [1]);
initMetadataForClass(CloseToken, 'CloseToken');
protoOf(CountedByteReadChannel).g1q = awaitContent$default;
initMetadataForClass(CountedByteReadChannel, 'CountedByteReadChannel', VOID, VOID, [ByteReadChannel], [1]);
initMetadataForClass(ClosedByteChannelException, 'ClosedByteChannelException', ClosedByteChannelException.r1r);
initMetadataForClass(ClosedReadChannelException, 'ClosedReadChannelException', ClosedReadChannelException.r1p);
initMetadataForClass(ClosedWriteChannelException, 'ClosedWriteChannelException', ClosedWriteChannelException.w1p);
initMetadataForCompanion(Companion_1);
initMetadataForClass(LineEndingMode, 'LineEndingMode');
protoOf(SourceByteReadChannel).g1q = awaitContent$default;
initMetadataForClass(SourceByteReadChannel, 'SourceByteReadChannel', VOID, VOID, [ByteReadChannel], [1]);
initMetadataForClass(MalformedInputException, 'MalformedInputException');
initMetadataForClass(TooLongLineException, 'TooLongLineException');
initMetadataForInterface(ObjectPool, 'ObjectPool', VOID, VOID, [AutoCloseable]);
protoOf(DefaultPool).a6 = close;
initMetadataForClass(DefaultPool, 'DefaultPool', VOID, VOID, [ObjectPool]);
initMetadataForClass(ByteArrayPool$1);
protoOf(NoPoolImpl).a6 = close;
initMetadataForClass(NoPoolImpl, 'NoPoolImpl', VOID, VOID, [ObjectPool]);
initMetadataForCompanion(Companion_2);
initMetadataForClass(Charset, 'Charset');
initMetadataForObject(Charsets, 'Charsets');
initMetadataForClass(CharsetDecoder, 'CharsetDecoder');
initMetadataForClass(CharsetEncoder, 'CharsetEncoder');
initMetadataForClass(CharsetImpl, 'CharsetImpl');
initMetadataForClass(CharsetEncoderImpl, 'CharsetEncoderImpl');
initMetadataForClass(CharsetDecoderImpl, 'CharsetDecoderImpl');
initMetadataForClass(toKtor$1);
initMetadataForClass(TextDecoderFallback, 'TextDecoderFallback');
//endregion
//region block: init
Empty_instance = new Empty();
Companion_instance_3 = new Companion_2();
//endregion
//region block: exports
export {
  copyTo as copyTo2bqjr21is71ky,
  readAvailable as readAvailablep1f2sbmaa5jo,
  readPacket as readPacket12c3kakna35tv,
  readRemaining as readRemaining33cdmbznvdvtg,
  readUTF8LineTo_0 as readUTF8LineTo2rqyj2iri7j7e,
  readUTF8Line as readUTF8Line221we5la1oywq,
  readUntil as readUntilqaod88ylrtua,
  skipIfFound as skipIfFound2s927ggnjlzu8,
  toByteArray as toByteArray3qclveibivokh,
  writeFully as writeFully2bplh4smpa61x,
  LineEndingMode__plus_impl_ttpz2j as LineEndingMode__plus_impl_ttpz2j1fo728zjvbdzc,
  Charsets_getInstance as Charsets_getInstancemd62gu5po4os,
  Companion_getInstance_0 as Companion_getInstancekyay2rfrglll,
  Companion_getInstance_1 as Companion_getInstance2golwmcx6d471,
  MalformedInputException as MalformedInputExceptionbvc6h5ij0ias,
  decode as decode1t43jmuxrxpmo,
  encode as encode35e4rpnc94tb5,
  forName as forName2faodmskqnoz5,
  get_name as get_name2f11g4r0d5pxp,
  canRead as canRead1guo8vbveth0f,
  readText_0 as readText27783kyxjxi1g,
  get_remaining as get_remaining1lapv95kcmm0y,
  takeWhile as takeWhile34751tcfg6owx,
  toByteArray_0 as toByteArray1i3ns5jnoqlv6,
  writeFully_0 as writeFully359t6q8kam2g5,
  writeText as writeText19qfzm98fbm4l,
  get_ByteArrayPool as get_ByteArrayPool3f7yrgvqxz9ct,
  DefaultPool as DefaultPool2gb1fm4epwgu9,
  NoPoolImpl as NoPoolImplgos9n8jphzjp,
  ByteChannel as ByteChannel3cxdguezl3lu7,
  ByteReadChannel_0 as ByteReadChannel1cb89sbyipkce,
  ByteReadChannel as ByteReadChannel2wzou76jce72d,
  WriterScope as WriterScope3b0bo1enaee6b,
  cancel_0 as canceldn4b3cdqcfny,
  close_0 as close3semq7pafb42g,
  counted as counted3iniv3aql3f9n,
  invokeOnCompletion as invokeOnCompletion1ziuxzoag0iwj,
  readText as readText3frapgncbqrcg,
  writer as writer1eia5its2a1fh,
};
//endregion

//# sourceMappingURL=ktor-ktor-io.mjs.map
