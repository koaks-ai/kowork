import {
  VOID7hggqo3abtya as VOID,
  StringBuildermazzzhj6kkai as StringBuilder,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  emptyList1g2z5xcrvp2zy as emptyList,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  listOfvhqybd2zx248 as listOf,
  equals2au1ep9vhcato as equals,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  isInterface3d6p8outrmvmk as isInterface,
  Comparator2b3maoeh98xtg as Comparator,
  hashCodeq5arwsb9dgti as hashCode,
  compareValues1n2ayl87ihzfk as compareValues,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  ArrayList3it5z8td81qkl as ArrayList,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  isBlank1dvkhjjvox3p0 as isBlank,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  Unit_instance104q5opgivhr8 as Unit_instance,
  plus310ted5e4i90h as plus,
  firstOrNull1982767dljvdy as firstOrNull,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  sortedWith2csnbbb21k0lg as sortedWith,
  toList3jhuyej2anx2q as toList,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  toString1pkumu07cwy4m as toString,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  trimEndvvzjdhan75g as trimEnd,
  endsWith3cq61xxngobwh as endsWith,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  toString30pk9tzaqopn as toString_0,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  get_lastIndex1yw0x4k50k51w as get_lastIndex,
  plus20p0vtfmu0596 as plus_0,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  createThis2j2avj17cvnv2 as createThis,
} from './kotlin-kotlin-stdlib.mjs';
import {
  Companion_instance13097inxmcdi as Companion_instance_0,
  Failed2mkg32d93x5tt as Failed,
  Finished4z9e5g7v1wyk as Finished,
  Companion_getInstance2m4xts4fuklfa as Companion_getInstance,
  ModelErrori9ofbqyilwwf as ModelError,
  HttpError1wj82nej166el as HttpError,
  Body2ccosqk3y8ycb as Body,
  Ndjson1kkk3x9modr28 as Ndjson,
  Sset7uvtqde4kyu as Sse,
  JsonUtil_getInstance3itlrleq4m1cs as JsonUtil_getInstance,
  Started1sf5a44qjgp0u as Started,
  _ProviderId___get_value__impl__xo1tux1l8qcslmantkx as _ProviderId___get_value__impl__xo1tux,
  Usage3sdv1daz6y20z as Usage,
  ReasoningDeltaytmmln995w27 as ReasoningDelta,
  TextDeltaq9h7728thclc as TextDelta,
  _ItemRef___get_value__impl__fpjuyb3vqbahagzpip9 as _ItemRef___get_value__impl__fpjuyb,
  ToolCallDelta1owom9vbem28s as ToolCallDelta,
  Companion_instancelgypg95btxw8 as Companion_instance_1,
  ProviderScopedId2kn7so5x8kdlf as ProviderScopedId,
  ToolCallsfyoaxshhyk as ToolCall,
  ToolCallCompleted225u0jsfjmco7 as ToolCallCompleted,
  Completedf7bahq5rqxjz as Completed,
  ChatModel1ekuxcd3gk3yy as ChatModel,
  ModelCapabilities1z2n3zkdibnvb as ModelCapabilities,
  HttpMethod_POST_getInstance2vunzl2e30rwd as HttpMethod_POST_getInstance,
  authHeaders3pbiyo76b6dd9 as authHeaders,
  Framing_Sse_getInstance1id84wnv2jikt as Framing_Sse_getInstance,
  timeoutsvuf8aepeqg28 as timeouts,
  WireCall3namx761k5vmg as WireCall,
  ensureDroppable3mu5lhcnsp146 as ensureDroppable,
  ProviderItem17hp0vuxmlwze as ProviderItem,
  ReasoningSummary2dl0lxzty5z0 as ReasoningSummary,
  ToolCall27jatgdodcelb as ToolCall_0,
  rawFor3526oyw9fazp7 as rawFor,
  ToolResult2fndzcq38kgpy as ToolResult,
  Message1x6kaj8ypdoee as Message,
  JsonSchema1bzd59uqo2uv as JsonSchema,
  JsonObject_instance30hvkp8z8mfx9 as JsonObject_instance,
  Text_instance936fuxqirkv3 as Text_instance,
} from './koaks-core.mjs';
import {
  JsonObjectBuilder2nl6rv6vdayuk as JsonObjectBuilder,
  JsonPrimitiveolttw629wj53 as JsonPrimitive,
  JsonPrimitive1xkjzc5d7ihuv as JsonPrimitive_0,
  JsonObjectSerializer_getInstance197qdg6ernwdp as JsonObjectSerializer_getInstance,
} from './kotlinx-serialization-kotlinx-serialization-json.mjs';
import {
  ArrayListSerializer7k5wnrulb3y6 as ArrayListSerializer,
  StringSerializer_getInstance1k1oz5j50sfik as StringSerializer_getInstance,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  BooleanSerializer_getInstancet3wtk7fl7i4f as BooleanSerializer_getInstance,
  DoubleSerializer_getInstance2avi1jm48x8le as DoubleSerializer_getInstance,
  IntSerializer_getInstance9scrtcljaiv6 as IntSerializer_getInstance,
  UnknownFieldExceptiona60e3a6v1xqo as UnknownFieldException,
  get_nullable197rfua9r7fsz as get_nullable,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class ToolAcc {
  constructor(id, name, args, ref) {
    id = id === VOID ? null : id;
    name = name === VOID ? StringBuilder.v() : name;
    args = args === VOID ? StringBuilder.v() : args;
    ref = ref === VOID ? Companion_instance_0.q60('call') : ref;
    this.t7a_1 = id;
    this.u7a_1 = name;
    this.v7a_1 = args;
    this.w7a_1 = ref;
  }
}
class sam$kotlin_Comparator$0 {
  constructor(function_0) {
    this.h7b_1 = function_0;
  }
  vi(a, b) {
    return this.h7b_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.h7b_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class ChatCompletionsDecoder {
  constructor(providerId) {
    this.x7a_1 = providerId;
    this.y7a_1 = LinkedHashMap.hc();
    this.z7a_1 = StringBuilder.v();
    this.a7b_1 = Companion_instance_0.q60('msg');
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.b7b_1 = ArrayList.k();
    this.c7b_1 = Companion_getInstance().t5r_1;
    this.d7b_1 = null;
    this.e7b_1 = null;
    this.f7b_1 = false;
    this.g7b_1 = false;
  }
  g6g(frame) {
    var tmp;
    if (frame instanceof Sse) {
      tmp = frame.w6m_1;
    } else {
      if (frame instanceof Ndjson) {
        tmp = frame.a6n_1;
      } else {
        if (frame instanceof Body) {
          tmp = frame.z6m_1;
        } else {
          if (frame instanceof HttpError) {
            this.e7b_1 = new ModelError('HTTP ' + frame.a6m_1 + ': ' + frame.c6m_1, frame.a6m_1 === 429 || frame.a6m_1 >= 500);
            return finishFailed(this);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
    var json = tmp;
    if (isBlank(json) || json === '[DONE]')
      return emptyList();
    // Inline function 'kotlin.runCatching' call
    var tmp_0;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = JsonUtil_getInstance().l6f(json, Companion_getInstance_15().c3o());
      tmp_0 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_1;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    // Inline function 'kotlin.getOrElse' call
    var this_0 = tmp_0;
    var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
    var tmp_2;
    if (exception == null) {
      var tmp_3 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_2 = (tmp_3 == null ? true : !(tmp_3 == null)) ? tmp_3 : THROW_CCE();
    } else {
      return emptyList();
    }
    var chunk = tmp_2;
    return this.j7b(chunk);
  }
  j7b(chunk) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    var tmp0_safe_receiver = chunk.k7b_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.d7b_1 = tmp0_safe_receiver;
    }
    if (!this.g7b_1 && !(this.d7b_1 == null)) {
      this.g7b_1 = true;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = new Started(this.d7b_1);
      events.l(element);
    }
    var tmp1_safe_receiver = chunk.o7b_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var tmp = this;
      var tmp0_elvis_lhs = tmp1_safe_receiver.r7b_1;
      tmp.e7b_1 = new ModelError(tmp0_elvis_lhs == null ? _ProviderId___get_value__impl__xo1tux(this.x7a_1) + ' error ' + tmp1_safe_receiver.p7b_1 : tmp0_elvis_lhs, false);
      return plus(events, finishFailed(this));
    }
    var tmp2_safe_receiver = chunk.n7b_1;
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var tmp_0 = this;
      var tmp0_elvis_lhs_0 = tmp2_safe_receiver.t7b_1;
      var tmp_1 = tmp0_elvis_lhs_0 == null ? 0 : tmp0_elvis_lhs_0;
      var tmp1_elvis_lhs = tmp2_safe_receiver.u7b_1;
      var tmp_2 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
      var tmp2_elvis_lhs = tmp2_safe_receiver.v7b_1;
      var tmp_3 = tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs;
      var tmp3_safe_receiver = tmp2_safe_receiver.w7b_1;
      var tmp4_elvis_lhs = tmp3_safe_receiver == null ? null : tmp3_safe_receiver.y7b_1;
      var tmp_4 = tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs;
      var tmp5_safe_receiver = tmp2_safe_receiver.x7b_1;
      var tmp6_elvis_lhs = tmp5_safe_receiver == null ? null : tmp5_safe_receiver.z7b_1;
      tmp_0.c7b_1 = new Usage(tmp_1, tmp_2, tmp_3, tmp_4, tmp6_elvis_lhs == null ? 0 : tmp6_elvis_lhs);
    }
    var tmp3_safe_receiver_0 = chunk.m7b_1;
    var tmp4_safe_receiver = tmp3_safe_receiver_0 == null ? null : firstOrNull(tmp3_safe_receiver_0);
    var tmp5_elvis_lhs = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.e7c();
    var tmp_5;
    if (tmp5_elvis_lhs == null) {
      return events;
    } else {
      tmp_5 = tmp5_elvis_lhs;
    }
    var payload = tmp_5;
    var tmp6_safe_receiver = payload.h7c_1;
    if (tmp6_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.text.isNotEmpty' call
      if (charSequenceLength(tmp6_safe_receiver) > 0) {
        // Inline function 'kotlin.collections.plusAssign' call
        var element_0 = new ReasoningDelta(tmp6_safe_receiver);
        events.l(element_0);
      }
    }
    var tmp7_safe_receiver = payload.g7c_1;
    if (tmp7_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.text.isNotEmpty' call
      if (charSequenceLength(tmp7_safe_receiver) > 0) {
        this.z7a_1.tb(tmp7_safe_receiver);
        // Inline function 'kotlin.collections.plusAssign' call
        var element_1 = new TextDelta(tmp7_safe_receiver, this.a7b_1);
        events.l(element_1);
      }
    }
    var tmp8_safe_receiver = payload.i7c_1;
    if (tmp8_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = tmp8_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var element_2 = _iterator__ex2g4s.a1();
        var tmp0 = this.y7a_1;
        // Inline function 'kotlin.collections.getOrPut' call
        var key = element_2.k7c_1;
        var value = tmp0.h3(key);
        var tmp_6;
        if (value == null) {
          var answer = new ToolAcc();
          tmp0.k3(key, answer);
          tmp_6 = answer;
        } else {
          tmp_6 = value;
        }
        var acc = tmp_6;
        var tmp0_safe_receiver_0 = element_2.l7c_1;
        if (tmp0_safe_receiver_0 == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          if (acc.t7a_1 == null)
            acc.t7a_1 = tmp0_safe_receiver_0;
        }
        var tmp1_safe_receiver_0 = element_2.n7c_1;
        var tmp2_safe_receiver_0 = tmp1_safe_receiver_0 == null ? null : tmp1_safe_receiver_0.o7c_1;
        if (tmp2_safe_receiver_0 == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          acc.u7a_1.tb(tmp2_safe_receiver_0);
        }
        var tmp3_safe_receiver_1 = element_2.n7c_1;
        var tmp4_safe_receiver_0 = tmp3_safe_receiver_1 == null ? null : tmp3_safe_receiver_1.p7c_1;
        if (tmp4_safe_receiver_0 == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          acc.v7a_1.tb(tmp4_safe_receiver_0);
        }
        var tmp5_elvis_lhs_0 = element_2.l7c_1;
        var tmp6_elvis_lhs_0 = tmp5_elvis_lhs_0 == null ? acc.t7a_1 : tmp5_elvis_lhs_0;
        var tmp_7 = tmp6_elvis_lhs_0 == null ? _ItemRef___get_value__impl__fpjuyb(acc.w7a_1) : tmp6_elvis_lhs_0;
        var tmp7_safe_receiver_0 = element_2.n7c_1;
        var tmp_8 = tmp7_safe_receiver_0 == null ? null : tmp7_safe_receiver_0.o7c_1;
        var tmp8_safe_receiver_0 = element_2.n7c_1;
        // Inline function 'kotlin.collections.plusAssign' call
        var element_3 = new ToolCallDelta(tmp_7, element_2.k7c_1, tmp_8, tmp8_safe_receiver_0 == null ? null : tmp8_safe_receiver_0.p7c_1, acc.w7a_1);
        events.l(element_3);
      }
    }
    return events;
  }
  n6g() {
    if (this.f7b_1)
      return emptyList();
    if (!(this.e7b_1 == null))
      return finishFailed(this);
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    // Inline function 'kotlin.text.isNotEmpty' call
    var this_0 = this.z7a_1;
    if (charSequenceLength(this_0) > 0) {
      var tmp1 = this.b7b_1;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = Companion_instance_1.m5t(this.z7a_1.toString(), this.a7b_1);
      tmp1.l(element);
    }
    // Inline function 'kotlin.collections.sortedBy' call
    var this_1 = this.y7a_1.l1();
    // Inline function 'kotlin.comparisons.compareBy' call
    var tmp = ChatCompletionsDecoder$finish$lambda;
    var tmp$ret$3 = new sam$kotlin_Comparator$0(tmp);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = sortedWith(this_1, tmp$ret$3).y();
    while (_iterator__ex2g4s.z()) {
      var element_0 = _iterator__ex2g4s.a1();
      $l$block: {
        // Inline function 'kotlin.collections.component2' call
        var acc = element_0.n1();
        var tmp_0;
        var tmp_1;
        // Inline function 'kotlin.text.isEmpty' call
        var this_2 = acc.u7a_1;
        if (charSequenceLength(this_2) === 0) {
          // Inline function 'kotlin.text.isEmpty' call
          var this_3 = acc.v7a_1;
          tmp_1 = charSequenceLength(this_3) === 0;
        } else {
          tmp_1 = false;
        }
        if (tmp_1) {
          tmp_0 = acc.t7a_1 == null;
        } else {
          tmp_0 = false;
        }
        if (tmp_0) {
          break $l$block;
        }
        var tmp_2 = _ItemRef___get_value__impl__fpjuyb(acc.w7a_1);
        var tmp_3 = acc.u7a_1.toString();
        // Inline function 'kotlin.text.ifBlank' call
        var this_4 = acc.v7a_1.toString();
        var tmp_4;
        if (isBlank(this_4)) {
          tmp_4 = '{}';
        } else {
          tmp_4 = this_4;
        }
        var tmp_5 = tmp_4;
        var tmp0_safe_receiver = acc.t7a_1;
        var tmp_6;
        if (tmp0_safe_receiver == null) {
          tmp_6 = null;
        } else {
          // Inline function 'kotlin.let' call
          tmp_6 = new ProviderScopedId(this.x7a_1, tmp0_safe_receiver);
        }
        var call = new ToolCall(tmp_2, tmp_3, tmp_5, tmp_6);
        var tmp6 = this.b7b_1;
        // Inline function 'kotlin.collections.plusAssign' call
        var element_1 = call.u60();
        tmp6.l(element_1);
        // Inline function 'kotlin.collections.plusAssign' call
        var element_2 = new ToolCallCompleted(call);
        events.l(element_2);
      }
    }
    this.f7b_1 = true;
    // Inline function 'kotlin.collections.plusAssign' call
    var element_3 = new Finished(new Completed(this.d7b_1, toList(this.b7b_1), this.c7b_1));
    events.l(element_3);
    return events;
  }
}
class ChatCompletionsModel extends ChatModel {
  constructor(config, transport, providerId, params, capabilities) {
    params = params === VOID ? new ChatCompletionsParams() : params;
    capabilities = capabilities === VOID ? new ModelCapabilities() : capabilities;
    super(config, transport);
    this.s7c_1 = providerId;
    this.t7c_1 = params;
    this.u7c_1 = capabilities;
  }
  l5o() {
    return this.u7c_1;
  }
  j1s() {
    return new ChatCompletionsDecoder(this.s7c_1);
  }
  q6g(req) {
    var body = JsonUtil_getInstance().k6f(this.v7c(req), Companion_getInstance_0().c3o());
    return new WireCall(HttpMethod_POST_getInstance(), this.j6g_1.u6g_1, authHeaders(this.j6g_1), body, Framing_Sse_getInstance(), req.l5y_1, timeouts(this.j6g_1), this.j6g_1.d6h_1, this.j6g_1.e6h_1);
  }
  v7c(req) {
    var tmp;
    switch (this.l5o().g5o_1.o3_1) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = null;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    var parallel = tmp;
    var tmp_0 = toChatMessages(req, this.s7c_1);
    // Inline function 'kotlin.takeIf' call
    var this_0 = req.i5y_1;
    var tmp_1;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this_0.h1()) {
      tmp_1 = this_0;
    } else {
      tmp_1 = null;
    }
    var tmp1_safe_receiver = tmp_1;
    var tmp_2;
    if (tmp1_safe_receiver == null) {
      tmp_2 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(tmp1_safe_receiver, 10));
      var _iterator__ex2g4s = tmp1_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$3 = toChatTool(item);
        destination.l(tmp$ret$3);
      }
      tmp_2 = destination;
    }
    var tmp_3 = tmp_2;
    var tmp_4;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!req.i5y_1.h1()) {
      tmp_4 = parallel;
    } else {
      tmp_4 = null;
    }
    return new ChatCompletionsRequest(this.j6g_1.w6g_1, tmp_0, tmp_3, tmp_4, true, new ChatStreamOptions(true), this.t7c_1.x7c_1, this.t7c_1.y7c_1, this.t7c_1.z7c_1, this.t7c_1.a7d_1, this.t7c_1.b7d_1, this.t7c_1.c7d_1, this.t7c_1.d7d_1, this.t7c_1.e7d_1, this.t7c_1.f7d_1, toResponseFormat(req.j5y_1));
  }
}
class ChatCompletionsParams {
  constructor(temperature, maxTokens, maxCompletionTokens, topP, stop, presencePenalty, frequencyPenalty, reasoningEffort, enableThinking) {
    temperature = temperature === VOID ? null : temperature;
    maxTokens = maxTokens === VOID ? null : maxTokens;
    maxCompletionTokens = maxCompletionTokens === VOID ? null : maxCompletionTokens;
    topP = topP === VOID ? null : topP;
    stop = stop === VOID ? null : stop;
    presencePenalty = presencePenalty === VOID ? null : presencePenalty;
    frequencyPenalty = frequencyPenalty === VOID ? null : frequencyPenalty;
    reasoningEffort = reasoningEffort === VOID ? null : reasoningEffort;
    enableThinking = enableThinking === VOID ? null : enableThinking;
    this.x7c_1 = temperature;
    this.y7c_1 = maxTokens;
    this.z7c_1 = maxCompletionTokens;
    this.a7d_1 = topP;
    this.b7d_1 = stop;
    this.c7d_1 = presencePenalty;
    this.d7d_1 = frequencyPenalty;
    this.e7d_1 = reasoningEffort;
    this.f7d_1 = enableThinking;
  }
  toString() {
    return 'ChatCompletionsParams(temperature=' + this.x7c_1 + ', maxTokens=' + this.y7c_1 + ', maxCompletionTokens=' + this.z7c_1 + ', topP=' + this.a7d_1 + ', stop=' + toString_0(this.b7d_1) + ', presencePenalty=' + this.c7d_1 + ', frequencyPenalty=' + this.d7d_1 + ', reasoningEffort=' + this.e7d_1 + ', enableThinking=' + this.f7d_1 + ')';
  }
  hashCode() {
    var result = this.x7c_1 == null ? 0 : getNumberHashCode(this.x7c_1);
    result = imul(result, 31) + (this.y7c_1 == null ? 0 : this.y7c_1) | 0;
    result = imul(result, 31) + (this.z7c_1 == null ? 0 : this.z7c_1) | 0;
    result = imul(result, 31) + (this.a7d_1 == null ? 0 : getNumberHashCode(this.a7d_1)) | 0;
    result = imul(result, 31) + (this.b7d_1 == null ? 0 : hashCode(this.b7d_1)) | 0;
    result = imul(result, 31) + (this.c7d_1 == null ? 0 : getNumberHashCode(this.c7d_1)) | 0;
    result = imul(result, 31) + (this.d7d_1 == null ? 0 : getNumberHashCode(this.d7d_1)) | 0;
    result = imul(result, 31) + (this.e7d_1 == null ? 0 : getStringHashCode(this.e7d_1)) | 0;
    result = imul(result, 31) + (this.f7d_1 == null ? 0 : getBooleanHashCode(this.f7d_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatCompletionsParams))
      return false;
    var tmp0_other_with_cast = other instanceof ChatCompletionsParams ? other : THROW_CCE();
    if (!equals(this.x7c_1, tmp0_other_with_cast.x7c_1))
      return false;
    if (!(this.y7c_1 == tmp0_other_with_cast.y7c_1))
      return false;
    if (!(this.z7c_1 == tmp0_other_with_cast.z7c_1))
      return false;
    if (!equals(this.a7d_1, tmp0_other_with_cast.a7d_1))
      return false;
    if (!equals(this.b7d_1, tmp0_other_with_cast.b7d_1))
      return false;
    if (!equals(this.c7d_1, tmp0_other_with_cast.c7d_1))
      return false;
    if (!equals(this.d7d_1, tmp0_other_with_cast.d7d_1))
      return false;
    if (!(this.e7d_1 == tmp0_other_with_cast.e7d_1))
      return false;
    if (!(this.f7d_1 == tmp0_other_with_cast.f7d_1))
      return false;
    return true;
  }
}
class Companion {
  constructor() {
    Companion_instance_2 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_1 = lazy(tmp_0, ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba);
    var tmp_2 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_3 = lazy(tmp_2, ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba_0);
    var tmp_4 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.w7c_1 = [null, tmp_1, tmp_3, null, null, null, null, null, null, null, lazy(tmp_4, ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba_1), null, null, null, null, null];
  }
  c3o() {
    return $serializer_getInstance();
  }
}
class $serializer {
  constructor() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsRequest', this, 16);
    tmp0_serialDesc.f25('model', false);
    tmp0_serialDesc.f25('messages', false);
    tmp0_serialDesc.f25('tools', true);
    tmp0_serialDesc.f25('parallel_tool_calls', true);
    tmp0_serialDesc.f25('stream', true);
    tmp0_serialDesc.f25('stream_options', true);
    tmp0_serialDesc.f25('temperature', true);
    tmp0_serialDesc.f25('max_tokens', true);
    tmp0_serialDesc.f25('max_completion_tokens', true);
    tmp0_serialDesc.f25('top_p', true);
    tmp0_serialDesc.f25('stop', true);
    tmp0_serialDesc.f25('presence_penalty', true);
    tmp0_serialDesc.f25('frequency_penalty', true);
    tmp0_serialDesc.f25('reasoning_effort', true);
    tmp0_serialDesc.f25('enable_thinking', true);
    tmp0_serialDesc.f25('response_format', true);
    this.l7d_1 = tmp0_serialDesc;
  }
  m7d(encoder, value) {
    var tmp0_desc = this.l7d_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    var tmp2_cached = Companion_getInstance_0().w7c_1;
    tmp1_output.g1z(tmp0_desc, 0, value.n7d_1);
    tmp1_output.i1z(tmp0_desc, 1, tmp2_cached[1].n1(), value.o7d_1);
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.p7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.p7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.q7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, BooleanSerializer_getInstance(), value.q7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.r7d_1 === true)) {
      tmp1_output.y1y(tmp0_desc, 4, value.r7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 5) ? true : !(value.s7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 5, $serializer_getInstance_2(), value.s7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 6) ? true : !(value.t7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 6, DoubleSerializer_getInstance(), value.t7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 7) ? true : !(value.u7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 7, IntSerializer_getInstance(), value.u7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 8) ? true : !(value.v7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 8, IntSerializer_getInstance(), value.v7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 9) ? true : !(value.w7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 9, DoubleSerializer_getInstance(), value.w7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 10) ? true : !(value.x7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 10, tmp2_cached[10].n1(), value.x7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 11) ? true : !(value.y7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 11, DoubleSerializer_getInstance(), value.y7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 12) ? true : !(value.z7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 12, DoubleSerializer_getInstance(), value.z7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 13) ? true : !(value.a7e_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 13, StringSerializer_getInstance(), value.a7e_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 14) ? true : !(value.b7e_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 14, BooleanSerializer_getInstance(), value.b7e_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 15) ? true : !(value.c7e_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 15, JsonObjectSerializer_getInstance(), value.c7e_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.m7d(encoder, value instanceof ChatCompletionsRequest ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.l7d_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = false;
    var tmp9_local5 = null;
    var tmp10_local6 = null;
    var tmp11_local7 = null;
    var tmp12_local8 = null;
    var tmp13_local9 = null;
    var tmp14_local10 = null;
    var tmp15_local11 = null;
    var tmp16_local12 = null;
    var tmp17_local13 = null;
    var tmp18_local14 = null;
    var tmp19_local15 = null;
    var tmp20_input = decoder.q1x(tmp0_desc);
    var tmp21_cached = Companion_getInstance_0().w7c_1;
    if (tmp20_input.g1y()) {
      tmp4_local0 = tmp20_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp20_input.c1y(tmp0_desc, 1, tmp21_cached[1].n1(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp20_input.e1y(tmp0_desc, 2, tmp21_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp20_input.e1y(tmp0_desc, 3, BooleanSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp20_input.s1x(tmp0_desc, 4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp20_input.e1y(tmp0_desc, 5, $serializer_getInstance_2(), tmp9_local5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp20_input.e1y(tmp0_desc, 6, DoubleSerializer_getInstance(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
      tmp11_local7 = tmp20_input.e1y(tmp0_desc, 7, IntSerializer_getInstance(), tmp11_local7);
      tmp3_bitMask0 = tmp3_bitMask0 | 128;
      tmp12_local8 = tmp20_input.e1y(tmp0_desc, 8, IntSerializer_getInstance(), tmp12_local8);
      tmp3_bitMask0 = tmp3_bitMask0 | 256;
      tmp13_local9 = tmp20_input.e1y(tmp0_desc, 9, DoubleSerializer_getInstance(), tmp13_local9);
      tmp3_bitMask0 = tmp3_bitMask0 | 512;
      tmp14_local10 = tmp20_input.e1y(tmp0_desc, 10, tmp21_cached[10].n1(), tmp14_local10);
      tmp3_bitMask0 = tmp3_bitMask0 | 1024;
      tmp15_local11 = tmp20_input.e1y(tmp0_desc, 11, DoubleSerializer_getInstance(), tmp15_local11);
      tmp3_bitMask0 = tmp3_bitMask0 | 2048;
      tmp16_local12 = tmp20_input.e1y(tmp0_desc, 12, DoubleSerializer_getInstance(), tmp16_local12);
      tmp3_bitMask0 = tmp3_bitMask0 | 4096;
      tmp17_local13 = tmp20_input.e1y(tmp0_desc, 13, StringSerializer_getInstance(), tmp17_local13);
      tmp3_bitMask0 = tmp3_bitMask0 | 8192;
      tmp18_local14 = tmp20_input.e1y(tmp0_desc, 14, BooleanSerializer_getInstance(), tmp18_local14);
      tmp3_bitMask0 = tmp3_bitMask0 | 16384;
      tmp19_local15 = tmp20_input.e1y(tmp0_desc, 15, JsonObjectSerializer_getInstance(), tmp19_local15);
      tmp3_bitMask0 = tmp3_bitMask0 | 32768;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp20_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp20_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp20_input.c1y(tmp0_desc, 1, tmp21_cached[1].n1(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp20_input.e1y(tmp0_desc, 2, tmp21_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp20_input.e1y(tmp0_desc, 3, BooleanSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp20_input.s1x(tmp0_desc, 4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp20_input.e1y(tmp0_desc, 5, $serializer_getInstance_2(), tmp9_local5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp20_input.e1y(tmp0_desc, 6, DoubleSerializer_getInstance(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          case 7:
            tmp11_local7 = tmp20_input.e1y(tmp0_desc, 7, IntSerializer_getInstance(), tmp11_local7);
            tmp3_bitMask0 = tmp3_bitMask0 | 128;
            break;
          case 8:
            tmp12_local8 = tmp20_input.e1y(tmp0_desc, 8, IntSerializer_getInstance(), tmp12_local8);
            tmp3_bitMask0 = tmp3_bitMask0 | 256;
            break;
          case 9:
            tmp13_local9 = tmp20_input.e1y(tmp0_desc, 9, DoubleSerializer_getInstance(), tmp13_local9);
            tmp3_bitMask0 = tmp3_bitMask0 | 512;
            break;
          case 10:
            tmp14_local10 = tmp20_input.e1y(tmp0_desc, 10, tmp21_cached[10].n1(), tmp14_local10);
            tmp3_bitMask0 = tmp3_bitMask0 | 1024;
            break;
          case 11:
            tmp15_local11 = tmp20_input.e1y(tmp0_desc, 11, DoubleSerializer_getInstance(), tmp15_local11);
            tmp3_bitMask0 = tmp3_bitMask0 | 2048;
            break;
          case 12:
            tmp16_local12 = tmp20_input.e1y(tmp0_desc, 12, DoubleSerializer_getInstance(), tmp16_local12);
            tmp3_bitMask0 = tmp3_bitMask0 | 4096;
            break;
          case 13:
            tmp17_local13 = tmp20_input.e1y(tmp0_desc, 13, StringSerializer_getInstance(), tmp17_local13);
            tmp3_bitMask0 = tmp3_bitMask0 | 8192;
            break;
          case 14:
            tmp18_local14 = tmp20_input.e1y(tmp0_desc, 14, BooleanSerializer_getInstance(), tmp18_local14);
            tmp3_bitMask0 = tmp3_bitMask0 | 16384;
            break;
          case 15:
            tmp19_local15 = tmp20_input.e1y(tmp0_desc, 15, JsonObjectSerializer_getInstance(), tmp19_local15);
            tmp3_bitMask0 = tmp3_bitMask0 | 32768;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp20_input.r1x(tmp0_desc);
    return ChatCompletionsRequest.d7e(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, tmp12_local8, tmp13_local9, tmp14_local10, tmp15_local11, tmp16_local12, tmp17_local13, tmp18_local14, tmp19_local15, null);
  }
  h1t() {
    return this.l7d_1;
  }
  u25() {
    var tmp0_cached = Companion_getInstance_0().w7c_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), tmp0_cached[1].n1(), get_nullable(tmp0_cached[2].n1()), get_nullable(BooleanSerializer_getInstance()), BooleanSerializer_getInstance(), get_nullable($serializer_getInstance_2()), get_nullable(DoubleSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(tmp0_cached[10].n1()), get_nullable(DoubleSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(BooleanSerializer_getInstance()), get_nullable(JsonObjectSerializer_getInstance())];
  }
}
class ChatCompletionsRequest {
  constructor(model, messages, tools, parallelToolCalls, stream, streamOptions, temperature, maxTokens, maxCompletionTokens, topP, stop, presencePenalty, frequencyPenalty, reasoningEffort, enableThinking, responseFormat) {
    Companion_getInstance_0();
    tools = tools === VOID ? null : tools;
    parallelToolCalls = parallelToolCalls === VOID ? null : parallelToolCalls;
    stream = stream === VOID ? true : stream;
    streamOptions = streamOptions === VOID ? null : streamOptions;
    temperature = temperature === VOID ? null : temperature;
    maxTokens = maxTokens === VOID ? null : maxTokens;
    maxCompletionTokens = maxCompletionTokens === VOID ? null : maxCompletionTokens;
    topP = topP === VOID ? null : topP;
    stop = stop === VOID ? null : stop;
    presencePenalty = presencePenalty === VOID ? null : presencePenalty;
    frequencyPenalty = frequencyPenalty === VOID ? null : frequencyPenalty;
    reasoningEffort = reasoningEffort === VOID ? null : reasoningEffort;
    enableThinking = enableThinking === VOID ? null : enableThinking;
    responseFormat = responseFormat === VOID ? null : responseFormat;
    this.n7d_1 = model;
    this.o7d_1 = messages;
    this.p7d_1 = tools;
    this.q7d_1 = parallelToolCalls;
    this.r7d_1 = stream;
    this.s7d_1 = streamOptions;
    this.t7d_1 = temperature;
    this.u7d_1 = maxTokens;
    this.v7d_1 = maxCompletionTokens;
    this.w7d_1 = topP;
    this.x7d_1 = stop;
    this.y7d_1 = presencePenalty;
    this.z7d_1 = frequencyPenalty;
    this.a7e_1 = reasoningEffort;
    this.b7e_1 = enableThinking;
    this.c7e_1 = responseFormat;
  }
  toString() {
    return 'ChatCompletionsRequest(model=' + this.n7d_1 + ', messages=' + toString(this.o7d_1) + ', tools=' + toString_0(this.p7d_1) + ', parallelToolCalls=' + this.q7d_1 + ', stream=' + this.r7d_1 + ', streamOptions=' + toString_0(this.s7d_1) + ', temperature=' + this.t7d_1 + ', maxTokens=' + this.u7d_1 + ', maxCompletionTokens=' + this.v7d_1 + ', topP=' + this.w7d_1 + ', stop=' + toString_0(this.x7d_1) + ', presencePenalty=' + this.y7d_1 + ', frequencyPenalty=' + this.z7d_1 + ', reasoningEffort=' + this.a7e_1 + ', enableThinking=' + this.b7e_1 + ', responseFormat=' + toString_0(this.c7e_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.n7d_1);
    result = imul(result, 31) + hashCode(this.o7d_1) | 0;
    result = imul(result, 31) + (this.p7d_1 == null ? 0 : hashCode(this.p7d_1)) | 0;
    result = imul(result, 31) + (this.q7d_1 == null ? 0 : getBooleanHashCode(this.q7d_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.r7d_1) | 0;
    result = imul(result, 31) + (this.s7d_1 == null ? 0 : this.s7d_1.hashCode()) | 0;
    result = imul(result, 31) + (this.t7d_1 == null ? 0 : getNumberHashCode(this.t7d_1)) | 0;
    result = imul(result, 31) + (this.u7d_1 == null ? 0 : this.u7d_1) | 0;
    result = imul(result, 31) + (this.v7d_1 == null ? 0 : this.v7d_1) | 0;
    result = imul(result, 31) + (this.w7d_1 == null ? 0 : getNumberHashCode(this.w7d_1)) | 0;
    result = imul(result, 31) + (this.x7d_1 == null ? 0 : hashCode(this.x7d_1)) | 0;
    result = imul(result, 31) + (this.y7d_1 == null ? 0 : getNumberHashCode(this.y7d_1)) | 0;
    result = imul(result, 31) + (this.z7d_1 == null ? 0 : getNumberHashCode(this.z7d_1)) | 0;
    result = imul(result, 31) + (this.a7e_1 == null ? 0 : getStringHashCode(this.a7e_1)) | 0;
    result = imul(result, 31) + (this.b7e_1 == null ? 0 : getBooleanHashCode(this.b7e_1)) | 0;
    result = imul(result, 31) + (this.c7e_1 == null ? 0 : this.c7e_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatCompletionsRequest))
      return false;
    var tmp0_other_with_cast = other instanceof ChatCompletionsRequest ? other : THROW_CCE();
    if (!(this.n7d_1 === tmp0_other_with_cast.n7d_1))
      return false;
    if (!equals(this.o7d_1, tmp0_other_with_cast.o7d_1))
      return false;
    if (!equals(this.p7d_1, tmp0_other_with_cast.p7d_1))
      return false;
    if (!(this.q7d_1 == tmp0_other_with_cast.q7d_1))
      return false;
    if (!(this.r7d_1 === tmp0_other_with_cast.r7d_1))
      return false;
    if (!equals(this.s7d_1, tmp0_other_with_cast.s7d_1))
      return false;
    if (!equals(this.t7d_1, tmp0_other_with_cast.t7d_1))
      return false;
    if (!(this.u7d_1 == tmp0_other_with_cast.u7d_1))
      return false;
    if (!(this.v7d_1 == tmp0_other_with_cast.v7d_1))
      return false;
    if (!equals(this.w7d_1, tmp0_other_with_cast.w7d_1))
      return false;
    if (!equals(this.x7d_1, tmp0_other_with_cast.x7d_1))
      return false;
    if (!equals(this.y7d_1, tmp0_other_with_cast.y7d_1))
      return false;
    if (!equals(this.z7d_1, tmp0_other_with_cast.z7d_1))
      return false;
    if (!(this.a7e_1 == tmp0_other_with_cast.a7e_1))
      return false;
    if (!(this.b7e_1 == tmp0_other_with_cast.b7e_1))
      return false;
    if (!equals(this.c7e_1, tmp0_other_with_cast.c7e_1))
      return false;
    return true;
  }
  static d7e(seen0, model, messages, tools, parallelToolCalls, stream, streamOptions, temperature, maxTokens, maxCompletionTokens, topP, stop, presencePenalty, frequencyPenalty, reasoningEffort, enableThinking, responseFormat, serializationConstructorMarker) {
    Companion_getInstance_0();
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance().l7d_1);
    }
    var $this = createThis(this);
    $this.n7d_1 = model;
    $this.o7d_1 = messages;
    if (0 === (seen0 & 4))
      $this.p7d_1 = null;
    else
      $this.p7d_1 = tools;
    if (0 === (seen0 & 8))
      $this.q7d_1 = null;
    else
      $this.q7d_1 = parallelToolCalls;
    if (0 === (seen0 & 16))
      $this.r7d_1 = true;
    else
      $this.r7d_1 = stream;
    if (0 === (seen0 & 32))
      $this.s7d_1 = null;
    else
      $this.s7d_1 = streamOptions;
    if (0 === (seen0 & 64))
      $this.t7d_1 = null;
    else
      $this.t7d_1 = temperature;
    if (0 === (seen0 & 128))
      $this.u7d_1 = null;
    else
      $this.u7d_1 = maxTokens;
    if (0 === (seen0 & 256))
      $this.v7d_1 = null;
    else
      $this.v7d_1 = maxCompletionTokens;
    if (0 === (seen0 & 512))
      $this.w7d_1 = null;
    else
      $this.w7d_1 = topP;
    if (0 === (seen0 & 1024))
      $this.x7d_1 = null;
    else
      $this.x7d_1 = stop;
    if (0 === (seen0 & 2048))
      $this.y7d_1 = null;
    else
      $this.y7d_1 = presencePenalty;
    if (0 === (seen0 & 4096))
      $this.z7d_1 = null;
    else
      $this.z7d_1 = frequencyPenalty;
    if (0 === (seen0 & 8192))
      $this.a7e_1 = null;
    else
      $this.a7e_1 = reasoningEffort;
    if (0 === (seen0 & 16384))
      $this.b7e_1 = null;
    else
      $this.b7e_1 = enableThinking;
    if (0 === (seen0 & 32768))
      $this.c7e_1 = null;
    else
      $this.c7e_1 = responseFormat;
    return $this;
  }
}
class Companion_0 {
  constructor() {
    Companion_instance_3 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.e7e_1 = [null, null, lazy(tmp_0, ChatMessage$Companion$$childSerializers$_anonymous__qywqat), null];
  }
}
class $serializer_0 {
  constructor() {
    $serializer_instance_0 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatMessage', this, 4);
    tmp0_serialDesc.f25('role', false);
    tmp0_serialDesc.f25('content', true);
    tmp0_serialDesc.f25('tool_calls', true);
    tmp0_serialDesc.f25('tool_call_id', true);
    this.f7e_1 = tmp0_serialDesc;
  }
  g7e(encoder, value) {
    var tmp0_desc = this.f7e_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    var tmp2_cached = Companion_getInstance_1().e7e_1;
    tmp1_output.g1z(tmp0_desc, 0, value.g7d_1);
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.h7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.h7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.i7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.i7d_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.j7d_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, StringSerializer_getInstance(), value.j7d_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.g7e(encoder, value instanceof ChatMessage ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.f7e_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    var tmp9_cached = Companion_getInstance_1().e7e_1;
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, tmp9_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, tmp9_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return ChatMessage.h7e(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.f7e_1;
  }
  u25() {
    var tmp0_cached = Companion_getInstance_1().e7e_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[2].n1()), get_nullable(StringSerializer_getInstance())];
  }
}
class ChatMessage {
  constructor(role, content, toolCalls, toolCallId) {
    Companion_getInstance_1();
    content = content === VOID ? null : content;
    toolCalls = toolCalls === VOID ? null : toolCalls;
    toolCallId = toolCallId === VOID ? null : toolCallId;
    this.g7d_1 = role;
    this.h7d_1 = content;
    this.i7d_1 = toolCalls;
    this.j7d_1 = toolCallId;
  }
  i7e(role, content, toolCalls, toolCallId) {
    return new ChatMessage(role, content, toolCalls, toolCallId);
  }
  k7d(role, content, toolCalls, toolCallId, $super) {
    role = role === VOID ? this.g7d_1 : role;
    content = content === VOID ? this.h7d_1 : content;
    toolCalls = toolCalls === VOID ? this.i7d_1 : toolCalls;
    toolCallId = toolCallId === VOID ? this.j7d_1 : toolCallId;
    return $super === VOID ? this.i7e(role, content, toolCalls, toolCallId) : $super.i7e.call(this, role, content, toolCalls, toolCallId);
  }
  toString() {
    return 'ChatMessage(role=' + this.g7d_1 + ', content=' + this.h7d_1 + ', toolCalls=' + toString_0(this.i7d_1) + ', toolCallId=' + this.j7d_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.g7d_1);
    result = imul(result, 31) + (this.h7d_1 == null ? 0 : getStringHashCode(this.h7d_1)) | 0;
    result = imul(result, 31) + (this.i7d_1 == null ? 0 : hashCode(this.i7d_1)) | 0;
    result = imul(result, 31) + (this.j7d_1 == null ? 0 : getStringHashCode(this.j7d_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatMessage))
      return false;
    var tmp0_other_with_cast = other instanceof ChatMessage ? other : THROW_CCE();
    if (!(this.g7d_1 === tmp0_other_with_cast.g7d_1))
      return false;
    if (!(this.h7d_1 == tmp0_other_with_cast.h7d_1))
      return false;
    if (!equals(this.i7d_1, tmp0_other_with_cast.i7d_1))
      return false;
    if (!(this.j7d_1 == tmp0_other_with_cast.j7d_1))
      return false;
    return true;
  }
  static h7e(seen0, role, content, toolCalls, toolCallId, serializationConstructorMarker) {
    Companion_getInstance_1();
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_0().f7e_1);
    }
    var $this = createThis(this);
    $this.g7d_1 = role;
    if (0 === (seen0 & 2))
      $this.h7d_1 = null;
    else
      $this.h7d_1 = content;
    if (0 === (seen0 & 4))
      $this.i7d_1 = null;
    else
      $this.i7d_1 = toolCalls;
    if (0 === (seen0 & 8))
      $this.j7d_1 = null;
    else
      $this.j7d_1 = toolCallId;
    return $this;
  }
}
class Companion_1 {}
class $serializer_1 {
  constructor() {
    $serializer_instance_1 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatTool', this, 2);
    tmp0_serialDesc.f25('type', true);
    tmp0_serialDesc.f25('function', false);
    this.j7e_1 = tmp0_serialDesc;
  }
  k7e(encoder, value) {
    var tmp0_desc = this.j7e_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.l7e_1 === 'function')) {
      tmp1_output.g1z(tmp0_desc, 0, value.l7e_1);
    }
    tmp1_output.i1z(tmp0_desc, 1, $serializer_getInstance_5(), value.m7e_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.k7e(encoder, value instanceof ChatTool ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.j7e_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.c1y(tmp0_desc, 1, $serializer_getInstance_5(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.c1y(tmp0_desc, 1, $serializer_getInstance_5(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return ChatTool.n7e(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.j7e_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), $serializer_getInstance_5()];
  }
}
class ChatTool {
  constructor(type, function_0) {
    type = type === VOID ? 'function' : type;
    this.l7e_1 = type;
    this.m7e_1 = function_0;
  }
  toString() {
    return 'ChatTool(type=' + this.l7e_1 + ', function=' + this.m7e_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.l7e_1);
    result = imul(result, 31) + this.m7e_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatTool))
      return false;
    var tmp0_other_with_cast = other instanceof ChatTool ? other : THROW_CCE();
    if (!(this.l7e_1 === tmp0_other_with_cast.l7e_1))
      return false;
    if (!this.m7e_1.equals(tmp0_other_with_cast.m7e_1))
      return false;
    return true;
  }
  static n7e(seen0, type, function_0, serializationConstructorMarker) {
    if (!(2 === (2 & seen0))) {
      throwMissingFieldException(seen0, 2, $serializer_getInstance_1().j7e_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.l7e_1 = 'function';
    else
      $this.l7e_1 = type;
    $this.m7e_1 = function_0;
    return $this;
  }
}
class Companion_2 {}
class $serializer_2 {
  constructor() {
    $serializer_instance_2 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatStreamOptions', this, 1);
    tmp0_serialDesc.f25('include_usage', true);
    this.o7e_1 = tmp0_serialDesc;
  }
  p7e(encoder, value) {
    var tmp0_desc = this.o7e_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.q7e_1 === true)) {
      tmp1_output.y1y(tmp0_desc, 0, value.q7e_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.p7e(encoder, value instanceof ChatStreamOptions ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.o7e_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = false;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.s1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.s1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return ChatStreamOptions.r7e(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.o7e_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [BooleanSerializer_getInstance()];
  }
}
class ChatStreamOptions {
  constructor(includeUsage) {
    includeUsage = includeUsage === VOID ? true : includeUsage;
    this.q7e_1 = includeUsage;
  }
  toString() {
    return 'ChatStreamOptions(includeUsage=' + this.q7e_1 + ')';
  }
  hashCode() {
    return getBooleanHashCode(this.q7e_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatStreamOptions))
      return false;
    var tmp0_other_with_cast = other instanceof ChatStreamOptions ? other : THROW_CCE();
    if (!(this.q7e_1 === tmp0_other_with_cast.q7e_1))
      return false;
    return true;
  }
  static r7e(seen0, includeUsage, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_2().o7e_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.q7e_1 = true;
    else
      $this.q7e_1 = includeUsage;
    return $this;
  }
}
class Companion_3 {}
class $serializer_3 {
  constructor() {
    $serializer_instance_3 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatReqToolCall', this, 3);
    tmp0_serialDesc.f25('id', false);
    tmp0_serialDesc.f25('type', true);
    tmp0_serialDesc.f25('function', false);
    this.s7e_1 = tmp0_serialDesc;
  }
  t7e(encoder, value) {
    var tmp0_desc = this.s7e_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.u7e_1);
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.v7e_1 === 'function')) {
      tmp1_output.g1z(tmp0_desc, 1, value.v7e_1);
    }
    tmp1_output.i1z(tmp0_desc, 2, $serializer_getInstance_4(), value.w7e_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.t7e(encoder, value instanceof ChatReqToolCall ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.s7e_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, $serializer_getInstance_4(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, $serializer_getInstance_4(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return ChatReqToolCall.x7e(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.s7e_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), $serializer_getInstance_4()];
  }
}
class ChatReqToolCall {
  constructor(id, type, function_0) {
    type = type === VOID ? 'function' : type;
    this.u7e_1 = id;
    this.v7e_1 = type;
    this.w7e_1 = function_0;
  }
  toString() {
    return 'ChatReqToolCall(id=' + this.u7e_1 + ', type=' + this.v7e_1 + ', function=' + this.w7e_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.u7e_1);
    result = imul(result, 31) + getStringHashCode(this.v7e_1) | 0;
    result = imul(result, 31) + this.w7e_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatReqToolCall))
      return false;
    var tmp0_other_with_cast = other instanceof ChatReqToolCall ? other : THROW_CCE();
    if (!(this.u7e_1 === tmp0_other_with_cast.u7e_1))
      return false;
    if (!(this.v7e_1 === tmp0_other_with_cast.v7e_1))
      return false;
    if (!this.w7e_1.equals(tmp0_other_with_cast.w7e_1))
      return false;
    return true;
  }
  static x7e(seen0, id, type, function_0, serializationConstructorMarker) {
    if (!(5 === (5 & seen0))) {
      throwMissingFieldException(seen0, 5, $serializer_getInstance_3().s7e_1);
    }
    var $this = createThis(this);
    $this.u7e_1 = id;
    if (0 === (seen0 & 2))
      $this.v7e_1 = 'function';
    else
      $this.v7e_1 = type;
    $this.w7e_1 = function_0;
    return $this;
  }
}
class Companion_4 {}
class $serializer_4 {
  constructor() {
    $serializer_instance_4 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatReqFunction', this, 2);
    tmp0_serialDesc.f25('name', false);
    tmp0_serialDesc.f25('arguments', false);
    this.y7e_1 = tmp0_serialDesc;
  }
  z7e(encoder, value) {
    var tmp0_desc = this.y7e_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.a7f_1);
    tmp1_output.g1z(tmp0_desc, 1, value.b7f_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.z7e(encoder, value instanceof ChatReqFunction ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.y7e_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return ChatReqFunction.c7f(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.y7e_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance()];
  }
}
class ChatReqFunction {
  constructor(name, arguments_0) {
    this.a7f_1 = name;
    this.b7f_1 = arguments_0;
  }
  toString() {
    return 'ChatReqFunction(name=' + this.a7f_1 + ', arguments=' + this.b7f_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.a7f_1);
    result = imul(result, 31) + getStringHashCode(this.b7f_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatReqFunction))
      return false;
    var tmp0_other_with_cast = other instanceof ChatReqFunction ? other : THROW_CCE();
    if (!(this.a7f_1 === tmp0_other_with_cast.a7f_1))
      return false;
    if (!(this.b7f_1 === tmp0_other_with_cast.b7f_1))
      return false;
    return true;
  }
  static c7f(seen0, name, arguments_0, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_4().y7e_1);
    }
    var $this = createThis(this);
    $this.a7f_1 = name;
    $this.b7f_1 = arguments_0;
    return $this;
  }
}
class Companion_5 {}
class $serializer_5 {
  constructor() {
    $serializer_instance_5 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatFunctionDef', this, 3);
    tmp0_serialDesc.f25('name', false);
    tmp0_serialDesc.f25('description', false);
    tmp0_serialDesc.f25('parameters', false);
    this.d7f_1 = tmp0_serialDesc;
  }
  e7f(encoder, value) {
    var tmp0_desc = this.d7f_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.f7f_1);
    tmp1_output.g1z(tmp0_desc, 1, value.g7f_1);
    tmp1_output.i1z(tmp0_desc, 2, JsonObjectSerializer_getInstance(), value.h7f_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.e7f(encoder, value instanceof ChatFunctionDef ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.d7f_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return ChatFunctionDef.i7f(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.d7f_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), JsonObjectSerializer_getInstance()];
  }
}
class ChatFunctionDef {
  constructor(name, description, parameters) {
    this.f7f_1 = name;
    this.g7f_1 = description;
    this.h7f_1 = parameters;
  }
  toString() {
    return 'ChatFunctionDef(name=' + this.f7f_1 + ', description=' + this.g7f_1 + ', parameters=' + this.h7f_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.f7f_1);
    result = imul(result, 31) + getStringHashCode(this.g7f_1) | 0;
    result = imul(result, 31) + this.h7f_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatFunctionDef))
      return false;
    var tmp0_other_with_cast = other instanceof ChatFunctionDef ? other : THROW_CCE();
    if (!(this.f7f_1 === tmp0_other_with_cast.f7f_1))
      return false;
    if (!(this.g7f_1 === tmp0_other_with_cast.g7f_1))
      return false;
    if (!this.h7f_1.equals(tmp0_other_with_cast.h7f_1))
      return false;
    return true;
  }
  static i7f(seen0, name, description, parameters, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_5().d7f_1);
    }
    var $this = createThis(this);
    $this.f7f_1 = name;
    $this.g7f_1 = description;
    $this.h7f_1 = parameters;
    return $this;
  }
}
class Companion_6 {}
class $serializer_6 {
  constructor() {
    $serializer_instance_6 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.Choice', this, 4);
    tmp0_serialDesc.f25('index', true);
    tmp0_serialDesc.f25('delta', true);
    tmp0_serialDesc.f25('message', true);
    tmp0_serialDesc.f25('finish_reason', true);
    this.j7f_1 = tmp0_serialDesc;
  }
  k7f(encoder, value) {
    var tmp0_desc = this.j7f_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.a7c_1 === 0)) {
      tmp1_output.b1z(tmp0_desc, 0, value.a7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.b7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, $serializer_getInstance_7(), value.b7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.c7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, $serializer_getInstance_7(), value.c7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.d7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, StringSerializer_getInstance(), value.d7c_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.k7f(encoder, value instanceof Choice ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.j7f_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = 0;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.v1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, $serializer_getInstance_7(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.v1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, $serializer_getInstance_7(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return Choice.l7f(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.j7f_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [IntSerializer_getInstance(), get_nullable($serializer_getInstance_7()), get_nullable($serializer_getInstance_7()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_7 {
  constructor() {
    Companion_instance_10 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.m7f_1 = [null, null, null, lazy(tmp_0, ChatCompletionsResponse$Delta$Companion$$childSerializers$_anonymous__fygqye), null];
  }
}
class $serializer_7 {
  constructor() {
    $serializer_instance_7 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.Delta', this, 5);
    tmp0_serialDesc.f25('role', true);
    tmp0_serialDesc.f25('content', true);
    tmp0_serialDesc.f25('reasoning_content', true);
    tmp0_serialDesc.f25('tool_calls', true);
    tmp0_serialDesc.f25('refusal', true);
    this.n7f_1 = tmp0_serialDesc;
  }
  o7f(encoder, value) {
    var tmp0_desc = this.n7f_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    var tmp2_cached = Companion_getInstance_8().m7f_1;
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.f7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.f7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.g7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.g7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.h7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, StringSerializer_getInstance(), value.h7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.i7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, tmp2_cached[3].n1(), value.i7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.j7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 4, StringSerializer_getInstance(), value.j7c_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.o7f(encoder, value instanceof Delta ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.n7f_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.q1x(tmp0_desc);
    var tmp10_cached = Companion_getInstance_8().m7f_1;
    if (tmp9_input.g1y()) {
      tmp4_local0 = tmp9_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, tmp10_cached[3].n1(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, tmp10_cached[3].n1(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp9_input.r1x(tmp0_desc);
    return Delta.p7f(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  h1t() {
    return this.n7f_1;
  }
  u25() {
    var tmp0_cached = Companion_getInstance_8().m7f_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[3].n1()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_8 {}
class $serializer_8 {
  constructor() {
    $serializer_instance_8 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.ToolCallChunk', this, 4);
    tmp0_serialDesc.f25('index', true);
    tmp0_serialDesc.f25('id', true);
    tmp0_serialDesc.f25('type', true);
    tmp0_serialDesc.f25('function', true);
    this.q7f_1 = tmp0_serialDesc;
  }
  r7f(encoder, value) {
    var tmp0_desc = this.q7f_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.k7c_1 === 0)) {
      tmp1_output.b1z(tmp0_desc, 0, value.k7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.l7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.l7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.m7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, StringSerializer_getInstance(), value.m7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.n7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, $serializer_getInstance_9(), value.n7c_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.r7f(encoder, value instanceof ToolCallChunk ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.q7f_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = 0;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.v1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, $serializer_getInstance_9(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.v1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, $serializer_getInstance_9(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return ToolCallChunk.s7f(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.q7f_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [IntSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable($serializer_getInstance_9())];
  }
}
class Companion_9 {}
class $serializer_9 {
  constructor() {
    $serializer_instance_9 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.FunctionChunk', this, 2);
    tmp0_serialDesc.f25('name', true);
    tmp0_serialDesc.f25('arguments', true);
    this.t7f_1 = tmp0_serialDesc;
  }
  u7f(encoder, value) {
    var tmp0_desc = this.t7f_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.o7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.o7c_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.p7c_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.p7c_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.u7f(encoder, value instanceof FunctionChunk ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.t7f_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return FunctionChunk.v7f(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.t7f_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_10 {}
class $serializer_10 {
  constructor() {
    $serializer_instance_10 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.Usage', this, 5);
    tmp0_serialDesc.f25('prompt_tokens', true);
    tmp0_serialDesc.f25('completion_tokens', true);
    tmp0_serialDesc.f25('total_tokens', true);
    tmp0_serialDesc.f25('prompt_tokens_details', true);
    tmp0_serialDesc.f25('completion_tokens_details', true);
    this.w7f_1 = tmp0_serialDesc;
  }
  x7f(encoder, value) {
    var tmp0_desc = this.w7f_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.t7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, IntSerializer_getInstance(), value.t7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.u7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, IntSerializer_getInstance(), value.u7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.v7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, IntSerializer_getInstance(), value.v7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.w7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, $serializer_getInstance_11(), value.w7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.x7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 4, $serializer_getInstance_12(), value.x7b_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.x7f(encoder, value instanceof Usage_0 ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.w7f_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.q1x(tmp0_desc);
    if (tmp9_input.g1y()) {
      tmp4_local0 = tmp9_input.e1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, IntSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, $serializer_getInstance_11(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, $serializer_getInstance_12(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.e1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, IntSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, $serializer_getInstance_11(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, $serializer_getInstance_12(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp9_input.r1x(tmp0_desc);
    return Usage_0.y7f(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  h1t() {
    return this.w7f_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable($serializer_getInstance_11()), get_nullable($serializer_getInstance_12())];
  }
}
class Companion_11 {}
class $serializer_11 {
  constructor() {
    $serializer_instance_11 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.PromptDetails', this, 1);
    tmp0_serialDesc.f25('cached_tokens', true);
    this.z7f_1 = tmp0_serialDesc;
  }
  a7g(encoder, value) {
    var tmp0_desc = this.z7f_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.y7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, IntSerializer_getInstance(), value.y7b_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.a7g(encoder, value instanceof PromptDetails ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.z7f_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.e1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.e1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return PromptDetails.b7g(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.z7f_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(IntSerializer_getInstance())];
  }
}
class Companion_12 {}
class $serializer_12 {
  constructor() {
    $serializer_instance_12 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.CompletionDetails', this, 1);
    tmp0_serialDesc.f25('reasoning_tokens', true);
    this.c7g_1 = tmp0_serialDesc;
  }
  d7g(encoder, value) {
    var tmp0_desc = this.c7g_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.z7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, IntSerializer_getInstance(), value.z7b_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.d7g(encoder, value instanceof CompletionDetails ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.c7g_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.e1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.e1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return CompletionDetails.e7g(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.c7g_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(IntSerializer_getInstance())];
  }
}
class Companion_13 {}
class $serializer_13 {
  constructor() {
    $serializer_instance_13 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.ErrorOutput', this, 4);
    tmp0_serialDesc.f25('code', true);
    tmp0_serialDesc.f25('param', true);
    tmp0_serialDesc.f25('message', true);
    tmp0_serialDesc.f25('type', true);
    this.f7g_1 = tmp0_serialDesc;
  }
  g7g(encoder, value) {
    var tmp0_desc = this.f7g_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.p7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.p7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.q7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.q7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.r7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, StringSerializer_getInstance(), value.r7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.s7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, StringSerializer_getInstance(), value.s7b_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.g7g(encoder, value instanceof ErrorOutput ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.f7g_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return ErrorOutput.h7g(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.f7g_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Choice {
  constructor(index, delta, message, finishReason) {
    index = index === VOID ? 0 : index;
    delta = delta === VOID ? null : delta;
    message = message === VOID ? null : message;
    finishReason = finishReason === VOID ? null : finishReason;
    this.a7c_1 = index;
    this.b7c_1 = delta;
    this.c7c_1 = message;
    this.d7c_1 = finishReason;
  }
  e7c() {
    var tmp0_elvis_lhs = this.b7c_1;
    return tmp0_elvis_lhs == null ? this.c7c_1 : tmp0_elvis_lhs;
  }
  toString() {
    return 'Choice(index=' + this.a7c_1 + ', delta=' + toString_0(this.b7c_1) + ', message=' + toString_0(this.c7c_1) + ', finishReason=' + this.d7c_1 + ')';
  }
  hashCode() {
    var result = this.a7c_1;
    result = imul(result, 31) + (this.b7c_1 == null ? 0 : this.b7c_1.hashCode()) | 0;
    result = imul(result, 31) + (this.c7c_1 == null ? 0 : this.c7c_1.hashCode()) | 0;
    result = imul(result, 31) + (this.d7c_1 == null ? 0 : getStringHashCode(this.d7c_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Choice))
      return false;
    var tmp0_other_with_cast = other instanceof Choice ? other : THROW_CCE();
    if (!(this.a7c_1 === tmp0_other_with_cast.a7c_1))
      return false;
    if (!equals(this.b7c_1, tmp0_other_with_cast.b7c_1))
      return false;
    if (!equals(this.c7c_1, tmp0_other_with_cast.c7c_1))
      return false;
    if (!(this.d7c_1 == tmp0_other_with_cast.d7c_1))
      return false;
    return true;
  }
  static l7f(seen0, index, delta, message, finishReason, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_6().j7f_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.a7c_1 = 0;
    else
      $this.a7c_1 = index;
    if (0 === (seen0 & 2))
      $this.b7c_1 = null;
    else
      $this.b7c_1 = delta;
    if (0 === (seen0 & 4))
      $this.c7c_1 = null;
    else
      $this.c7c_1 = message;
    if (0 === (seen0 & 8))
      $this.d7c_1 = null;
    else
      $this.d7c_1 = finishReason;
    return $this;
  }
}
class Delta {
  constructor(role, content, reasoningContent, toolCalls, refusal) {
    Companion_getInstance_8();
    role = role === VOID ? null : role;
    content = content === VOID ? null : content;
    reasoningContent = reasoningContent === VOID ? null : reasoningContent;
    toolCalls = toolCalls === VOID ? null : toolCalls;
    refusal = refusal === VOID ? null : refusal;
    this.f7c_1 = role;
    this.g7c_1 = content;
    this.h7c_1 = reasoningContent;
    this.i7c_1 = toolCalls;
    this.j7c_1 = refusal;
  }
  toString() {
    return 'Delta(role=' + this.f7c_1 + ', content=' + this.g7c_1 + ', reasoningContent=' + this.h7c_1 + ', toolCalls=' + toString_0(this.i7c_1) + ', refusal=' + this.j7c_1 + ')';
  }
  hashCode() {
    var result = this.f7c_1 == null ? 0 : getStringHashCode(this.f7c_1);
    result = imul(result, 31) + (this.g7c_1 == null ? 0 : getStringHashCode(this.g7c_1)) | 0;
    result = imul(result, 31) + (this.h7c_1 == null ? 0 : getStringHashCode(this.h7c_1)) | 0;
    result = imul(result, 31) + (this.i7c_1 == null ? 0 : hashCode(this.i7c_1)) | 0;
    result = imul(result, 31) + (this.j7c_1 == null ? 0 : getStringHashCode(this.j7c_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Delta))
      return false;
    var tmp0_other_with_cast = other instanceof Delta ? other : THROW_CCE();
    if (!(this.f7c_1 == tmp0_other_with_cast.f7c_1))
      return false;
    if (!(this.g7c_1 == tmp0_other_with_cast.g7c_1))
      return false;
    if (!(this.h7c_1 == tmp0_other_with_cast.h7c_1))
      return false;
    if (!equals(this.i7c_1, tmp0_other_with_cast.i7c_1))
      return false;
    if (!(this.j7c_1 == tmp0_other_with_cast.j7c_1))
      return false;
    return true;
  }
  static p7f(seen0, role, content, reasoningContent, toolCalls, refusal, serializationConstructorMarker) {
    Companion_getInstance_8();
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_7().n7f_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.f7c_1 = null;
    else
      $this.f7c_1 = role;
    if (0 === (seen0 & 2))
      $this.g7c_1 = null;
    else
      $this.g7c_1 = content;
    if (0 === (seen0 & 4))
      $this.h7c_1 = null;
    else
      $this.h7c_1 = reasoningContent;
    if (0 === (seen0 & 8))
      $this.i7c_1 = null;
    else
      $this.i7c_1 = toolCalls;
    if (0 === (seen0 & 16))
      $this.j7c_1 = null;
    else
      $this.j7c_1 = refusal;
    return $this;
  }
}
class ToolCallChunk {
  constructor(index, id, type, function_0) {
    index = index === VOID ? 0 : index;
    id = id === VOID ? null : id;
    type = type === VOID ? null : type;
    function_0 = function_0 === VOID ? null : function_0;
    this.k7c_1 = index;
    this.l7c_1 = id;
    this.m7c_1 = type;
    this.n7c_1 = function_0;
  }
  toString() {
    return 'ToolCallChunk(index=' + this.k7c_1 + ', id=' + this.l7c_1 + ', type=' + this.m7c_1 + ', function=' + toString_0(this.n7c_1) + ')';
  }
  hashCode() {
    var result = this.k7c_1;
    result = imul(result, 31) + (this.l7c_1 == null ? 0 : getStringHashCode(this.l7c_1)) | 0;
    result = imul(result, 31) + (this.m7c_1 == null ? 0 : getStringHashCode(this.m7c_1)) | 0;
    result = imul(result, 31) + (this.n7c_1 == null ? 0 : this.n7c_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolCallChunk))
      return false;
    var tmp0_other_with_cast = other instanceof ToolCallChunk ? other : THROW_CCE();
    if (!(this.k7c_1 === tmp0_other_with_cast.k7c_1))
      return false;
    if (!(this.l7c_1 == tmp0_other_with_cast.l7c_1))
      return false;
    if (!(this.m7c_1 == tmp0_other_with_cast.m7c_1))
      return false;
    if (!equals(this.n7c_1, tmp0_other_with_cast.n7c_1))
      return false;
    return true;
  }
  static s7f(seen0, index, id, type, function_0, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_8().q7f_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.k7c_1 = 0;
    else
      $this.k7c_1 = index;
    if (0 === (seen0 & 2))
      $this.l7c_1 = null;
    else
      $this.l7c_1 = id;
    if (0 === (seen0 & 4))
      $this.m7c_1 = null;
    else
      $this.m7c_1 = type;
    if (0 === (seen0 & 8))
      $this.n7c_1 = null;
    else
      $this.n7c_1 = function_0;
    return $this;
  }
}
class FunctionChunk {
  constructor(name, arguments_0) {
    name = name === VOID ? null : name;
    arguments_0 = arguments_0 === VOID ? null : arguments_0;
    this.o7c_1 = name;
    this.p7c_1 = arguments_0;
  }
  toString() {
    return 'FunctionChunk(name=' + this.o7c_1 + ', arguments=' + this.p7c_1 + ')';
  }
  hashCode() {
    var result = this.o7c_1 == null ? 0 : getStringHashCode(this.o7c_1);
    result = imul(result, 31) + (this.p7c_1 == null ? 0 : getStringHashCode(this.p7c_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof FunctionChunk))
      return false;
    var tmp0_other_with_cast = other instanceof FunctionChunk ? other : THROW_CCE();
    if (!(this.o7c_1 == tmp0_other_with_cast.o7c_1))
      return false;
    if (!(this.p7c_1 == tmp0_other_with_cast.p7c_1))
      return false;
    return true;
  }
  static v7f(seen0, name, arguments_0, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_9().t7f_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.o7c_1 = null;
    else
      $this.o7c_1 = name;
    if (0 === (seen0 & 2))
      $this.p7c_1 = null;
    else
      $this.p7c_1 = arguments_0;
    return $this;
  }
}
class Usage_0 {
  constructor(promptTokens, completionTokens, totalTokens, promptDetails, completionDetails) {
    promptTokens = promptTokens === VOID ? null : promptTokens;
    completionTokens = completionTokens === VOID ? null : completionTokens;
    totalTokens = totalTokens === VOID ? null : totalTokens;
    promptDetails = promptDetails === VOID ? null : promptDetails;
    completionDetails = completionDetails === VOID ? null : completionDetails;
    this.t7b_1 = promptTokens;
    this.u7b_1 = completionTokens;
    this.v7b_1 = totalTokens;
    this.w7b_1 = promptDetails;
    this.x7b_1 = completionDetails;
  }
  toString() {
    return 'Usage(promptTokens=' + this.t7b_1 + ', completionTokens=' + this.u7b_1 + ', totalTokens=' + this.v7b_1 + ', promptDetails=' + toString_0(this.w7b_1) + ', completionDetails=' + toString_0(this.x7b_1) + ')';
  }
  hashCode() {
    var result = this.t7b_1 == null ? 0 : this.t7b_1;
    result = imul(result, 31) + (this.u7b_1 == null ? 0 : this.u7b_1) | 0;
    result = imul(result, 31) + (this.v7b_1 == null ? 0 : this.v7b_1) | 0;
    result = imul(result, 31) + (this.w7b_1 == null ? 0 : this.w7b_1.hashCode()) | 0;
    result = imul(result, 31) + (this.x7b_1 == null ? 0 : this.x7b_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Usage_0))
      return false;
    var tmp0_other_with_cast = other instanceof Usage_0 ? other : THROW_CCE();
    if (!(this.t7b_1 == tmp0_other_with_cast.t7b_1))
      return false;
    if (!(this.u7b_1 == tmp0_other_with_cast.u7b_1))
      return false;
    if (!(this.v7b_1 == tmp0_other_with_cast.v7b_1))
      return false;
    if (!equals(this.w7b_1, tmp0_other_with_cast.w7b_1))
      return false;
    if (!equals(this.x7b_1, tmp0_other_with_cast.x7b_1))
      return false;
    return true;
  }
  static y7f(seen0, promptTokens, completionTokens, totalTokens, promptDetails, completionDetails, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_10().w7f_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.t7b_1 = null;
    else
      $this.t7b_1 = promptTokens;
    if (0 === (seen0 & 2))
      $this.u7b_1 = null;
    else
      $this.u7b_1 = completionTokens;
    if (0 === (seen0 & 4))
      $this.v7b_1 = null;
    else
      $this.v7b_1 = totalTokens;
    if (0 === (seen0 & 8))
      $this.w7b_1 = null;
    else
      $this.w7b_1 = promptDetails;
    if (0 === (seen0 & 16))
      $this.x7b_1 = null;
    else
      $this.x7b_1 = completionDetails;
    return $this;
  }
}
class PromptDetails {
  constructor(cachedTokens) {
    cachedTokens = cachedTokens === VOID ? null : cachedTokens;
    this.y7b_1 = cachedTokens;
  }
  toString() {
    return 'PromptDetails(cachedTokens=' + this.y7b_1 + ')';
  }
  hashCode() {
    return this.y7b_1 == null ? 0 : this.y7b_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof PromptDetails))
      return false;
    var tmp0_other_with_cast = other instanceof PromptDetails ? other : THROW_CCE();
    if (!(this.y7b_1 == tmp0_other_with_cast.y7b_1))
      return false;
    return true;
  }
  static b7g(seen0, cachedTokens, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_11().z7f_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.y7b_1 = null;
    else
      $this.y7b_1 = cachedTokens;
    return $this;
  }
}
class CompletionDetails {
  constructor(reasoningTokens) {
    reasoningTokens = reasoningTokens === VOID ? null : reasoningTokens;
    this.z7b_1 = reasoningTokens;
  }
  toString() {
    return 'CompletionDetails(reasoningTokens=' + this.z7b_1 + ')';
  }
  hashCode() {
    return this.z7b_1 == null ? 0 : this.z7b_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CompletionDetails))
      return false;
    var tmp0_other_with_cast = other instanceof CompletionDetails ? other : THROW_CCE();
    if (!(this.z7b_1 == tmp0_other_with_cast.z7b_1))
      return false;
    return true;
  }
  static e7g(seen0, reasoningTokens, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_12().c7g_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.z7b_1 = null;
    else
      $this.z7b_1 = reasoningTokens;
    return $this;
  }
}
class ErrorOutput {
  constructor(code, param, message, type) {
    code = code === VOID ? null : code;
    param = param === VOID ? null : param;
    message = message === VOID ? null : message;
    type = type === VOID ? null : type;
    this.p7b_1 = code;
    this.q7b_1 = param;
    this.r7b_1 = message;
    this.s7b_1 = type;
  }
  toString() {
    return 'ErrorOutput(code=' + this.p7b_1 + ', param=' + this.q7b_1 + ', message=' + this.r7b_1 + ', type=' + this.s7b_1 + ')';
  }
  hashCode() {
    var result = this.p7b_1 == null ? 0 : getStringHashCode(this.p7b_1);
    result = imul(result, 31) + (this.q7b_1 == null ? 0 : getStringHashCode(this.q7b_1)) | 0;
    result = imul(result, 31) + (this.r7b_1 == null ? 0 : getStringHashCode(this.r7b_1)) | 0;
    result = imul(result, 31) + (this.s7b_1 == null ? 0 : getStringHashCode(this.s7b_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ErrorOutput))
      return false;
    var tmp0_other_with_cast = other instanceof ErrorOutput ? other : THROW_CCE();
    if (!(this.p7b_1 == tmp0_other_with_cast.p7b_1))
      return false;
    if (!(this.q7b_1 == tmp0_other_with_cast.q7b_1))
      return false;
    if (!(this.r7b_1 == tmp0_other_with_cast.r7b_1))
      return false;
    if (!(this.s7b_1 == tmp0_other_with_cast.s7b_1))
      return false;
    return true;
  }
  static h7g(seen0, code, param, message, type, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_13().f7g_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.p7b_1 = null;
    else
      $this.p7b_1 = code;
    if (0 === (seen0 & 2))
      $this.q7b_1 = null;
    else
      $this.q7b_1 = param;
    if (0 === (seen0 & 4))
      $this.r7b_1 = null;
    else
      $this.r7b_1 = message;
    if (0 === (seen0 & 8))
      $this.s7b_1 = null;
    else
      $this.s7b_1 = type;
    return $this;
  }
}
class Companion_14 {
  constructor() {
    Companion_instance_17 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.i7b_1 = [null, null, lazy(tmp_0, ChatCompletionsResponse$Companion$$childSerializers$_anonymous__8hhtau), null, null];
  }
  c3o() {
    return $serializer_getInstance_14();
  }
}
class $serializer_14 {
  constructor() {
    $serializer_instance_14 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse', this, 5);
    tmp0_serialDesc.f25('id', true);
    tmp0_serialDesc.f25('model', true);
    tmp0_serialDesc.f25('choices', true);
    tmp0_serialDesc.f25('usage', true);
    tmp0_serialDesc.f25('error', true);
    this.i7g_1 = tmp0_serialDesc;
  }
  j7g(encoder, value) {
    var tmp0_desc = this.i7g_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    var tmp2_cached = Companion_getInstance_15().i7b_1;
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.k7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.k7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.l7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.l7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.m7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.m7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.n7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, $serializer_getInstance_10(), value.n7b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.o7b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 4, $serializer_getInstance_13(), value.o7b_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.j7g(encoder, value instanceof ChatCompletionsResponse ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.i7g_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.q1x(tmp0_desc);
    var tmp10_cached = Companion_getInstance_15().i7b_1;
    if (tmp9_input.g1y()) {
      tmp4_local0 = tmp9_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, tmp10_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, $serializer_getInstance_10(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, $serializer_getInstance_13(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, tmp10_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, $serializer_getInstance_10(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, $serializer_getInstance_13(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp9_input.r1x(tmp0_desc);
    return ChatCompletionsResponse.k7g(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  h1t() {
    return this.i7g_1;
  }
  u25() {
    var tmp0_cached = Companion_getInstance_15().i7b_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[2].n1()), get_nullable($serializer_getInstance_10()), get_nullable($serializer_getInstance_13())];
  }
}
class ChatCompletionsResponse {
  constructor(id, model, choices, usage, error) {
    Companion_getInstance_15();
    id = id === VOID ? null : id;
    model = model === VOID ? null : model;
    choices = choices === VOID ? null : choices;
    usage = usage === VOID ? null : usage;
    error = error === VOID ? null : error;
    this.k7b_1 = id;
    this.l7b_1 = model;
    this.m7b_1 = choices;
    this.n7b_1 = usage;
    this.o7b_1 = error;
  }
  toString() {
    return 'ChatCompletionsResponse(id=' + this.k7b_1 + ', model=' + this.l7b_1 + ', choices=' + toString_0(this.m7b_1) + ', usage=' + toString_0(this.n7b_1) + ', error=' + toString_0(this.o7b_1) + ')';
  }
  hashCode() {
    var result = this.k7b_1 == null ? 0 : getStringHashCode(this.k7b_1);
    result = imul(result, 31) + (this.l7b_1 == null ? 0 : getStringHashCode(this.l7b_1)) | 0;
    result = imul(result, 31) + (this.m7b_1 == null ? 0 : hashCode(this.m7b_1)) | 0;
    result = imul(result, 31) + (this.n7b_1 == null ? 0 : this.n7b_1.hashCode()) | 0;
    result = imul(result, 31) + (this.o7b_1 == null ? 0 : this.o7b_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatCompletionsResponse))
      return false;
    var tmp0_other_with_cast = other instanceof ChatCompletionsResponse ? other : THROW_CCE();
    if (!(this.k7b_1 == tmp0_other_with_cast.k7b_1))
      return false;
    if (!(this.l7b_1 == tmp0_other_with_cast.l7b_1))
      return false;
    if (!equals(this.m7b_1, tmp0_other_with_cast.m7b_1))
      return false;
    if (!equals(this.n7b_1, tmp0_other_with_cast.n7b_1))
      return false;
    if (!equals(this.o7b_1, tmp0_other_with_cast.o7b_1))
      return false;
    return true;
  }
  static k7g(seen0, id, model, choices, usage, error, serializationConstructorMarker) {
    Companion_getInstance_15();
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_14().i7g_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.k7b_1 = null;
    else
      $this.k7b_1 = id;
    if (0 === (seen0 & 2))
      $this.l7b_1 = null;
    else
      $this.l7b_1 = model;
    if (0 === (seen0 & 4))
      $this.m7b_1 = null;
    else
      $this.m7b_1 = choices;
    if (0 === (seen0 & 8))
      $this.n7b_1 = null;
    else
      $this.n7b_1 = usage;
    if (0 === (seen0 & 16))
      $this.o7b_1 = null;
    else
      $this.o7b_1 = error;
    return $this;
  }
}
//endregion
function finishFailed($this) {
  if ($this.f7b_1)
    return emptyList();
  $this.f7b_1 = true;
  return listOf(new Finished(new Failed(ensureNotNull($this.e7b_1), $this.d7b_1, VOID, $this.c7b_1)));
}
function ChatCompletionsDecoder$finish$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = a.m1();
  var tmp$ret$1 = b.m1();
  return compareValues(tmp, tmp$ret$1);
}
function normalizeChatCompletionsUrl(baseUrl) {
  // Inline function 'kotlin.text.trim' call
  var tmp$ret$0 = toString(trim(isCharSequence(baseUrl) ? baseUrl : THROW_CCE()));
  var trimmed = trimEnd(tmp$ret$0, charArrayOf([_Char___init__impl__6a9atx(47)]));
  return endsWith(trimmed, '/chat/completions') ? trimmed : endsWith(trimmed, '/v1') ? trimmed + '/chat/completions' : trimmed + '/v1/chat/completions';
}
function toChatMessages(_this__u8e3s4, providerId) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var out = ArrayList.k();
  var tmp0_safe_receiver = _this__u8e3s4.g5y_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.takeIf' call
    var tmp_0;
    // Inline function 'kotlin.text.isNotBlank' call
    if (!isBlank(tmp0_safe_receiver)) {
      tmp_0 = tmp0_safe_receiver;
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  var tmp1_safe_receiver = tmp;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.collections.plusAssign' call
    var element = new ChatMessage('system', tmp1_safe_receiver);
    out.l(element);
  }
  var _iterator__ex2g4s = _this__u8e3s4.h5y_1.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    if (item instanceof Message) {
      switch (item.c5o_1.o3_1) {
        case 0:
          // Inline function 'kotlin.collections.plusAssign' call

          var element_0 = new ChatMessage('system', item.f5t());
          out.l(element_0);
          break;
        case 1:
          // Inline function 'kotlin.text.ifEmpty' call

          var this_0 = item.f5t();
          var tmp_1;
          // Inline function 'kotlin.text.isEmpty' call

          if (charSequenceLength(this_0) === 0) {
            tmp_1 = null;
          } else {
            tmp_1 = this_0;
          }

          var tmp$ret$10 = tmp_1;
          // Inline function 'kotlin.collections.plusAssign' call

          var element_1 = new ChatMessage('user', tmp$ret$10);
          out.l(element_1);
          break;
        case 2:
          var calls = emptyList();
          // Inline function 'kotlin.text.ifEmpty' call

          var this_1 = item.f5t();
          var tmp_2;
          // Inline function 'kotlin.text.isEmpty' call

          if (charSequenceLength(this_1) === 0) {
            tmp_2 = null;
          } else {
            tmp_2 = this_1;
          }

          var tmp_3 = tmp_2;
          // Inline function 'kotlin.takeIf' call

          var tmp_4;
          // Inline function 'kotlin.collections.isNotEmpty' call

          if (!calls.h1()) {
            tmp_4 = calls;
          } else {
            tmp_4 = null;
          }

          var tmp$ret$17 = tmp_4;
          // Inline function 'kotlin.collections.plusAssign' call

          var element_2 = new ChatMessage('assistant', tmp_3, tmp$ret$17);
          out.l(element_2);
          break;
        case 3:
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
    } else {
      if (item instanceof ToolCall_0) {
        var last = lastOrNull(out);
        var tmp4_elvis_lhs = rawFor(item.e69_1, providerId);
        var native = tmp4_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(item.d69_1) : tmp4_elvis_lhs;
        var call = new ChatReqToolCall(native, VOID, new ChatReqFunction(item.f69_1, item.g69_1));
        if (!(last == null) && last.g7d_1 === 'assistant') {
          var tmp_5 = get_lastIndex(out);
          var tmp5_elvis_lhs = last.i7d_1;
          out.c3(tmp_5, last.k7d(VOID, VOID, plus_0(tmp5_elvis_lhs == null ? emptyList() : tmp5_elvis_lhs, call)));
        } else {
          // Inline function 'kotlin.collections.plusAssign' call
          var element_3 = new ChatMessage('assistant', VOID, listOf(call));
          out.l(element_3);
        }
      } else {
        if (item instanceof ToolResult) {
          // Inline function 'kotlin.collections.filterIsInstance' call
          var tmp0 = _this__u8e3s4.h5y_1;
          // Inline function 'kotlin.collections.filterIsInstanceTo' call
          var destination = ArrayList.k();
          var _iterator__ex2g4s_0 = tmp0.y();
          while (_iterator__ex2g4s_0.z()) {
            var element_4 = _iterator__ex2g4s_0.a1();
            if (element_4 instanceof ToolCall_0) {
              destination.l(element_4);
            }
          }
          var tmp$ret$23;
          $l$block: {
            // Inline function 'kotlin.collections.firstOrNull' call
            var _iterator__ex2g4s_1 = destination.y();
            while (_iterator__ex2g4s_1.z()) {
              var element_5 = _iterator__ex2g4s_1.a1();
              if (element_5.d69_1 === item.a69_1) {
                tmp$ret$23 = element_5;
                break $l$block;
              }
            }
            tmp$ret$23 = null;
          }
          var tmp6_safe_receiver = tmp$ret$23;
          var tmp_6;
          if (tmp6_safe_receiver == null) {
            tmp_6 = null;
          } else {
            // Inline function 'kotlin.let' call
            var tmp0_elvis_lhs = rawFor(tmp6_safe_receiver.e69_1, providerId);
            tmp_6 = tmp0_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(tmp6_safe_receiver.d69_1) : tmp0_elvis_lhs;
          }
          var tmp7_elvis_lhs = tmp_6;
          var callId = tmp7_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(item.a69_1) : tmp7_elvis_lhs;
          // Inline function 'kotlin.collections.plusAssign' call
          var element_6 = new ChatMessage('tool', item.b69_1, VOID, callId);
          out.l(element_6);
        } else {
          if (!(item instanceof ReasoningSummary)) {
            if (item instanceof ProviderItem) {
              ensureDroppable(item, 'chat-completions');
            } else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
  }
  return out;
}
function toChatTool(_this__u8e3s4) {
  return new ChatTool(VOID, new ChatFunctionDef(_this__u8e3s4.u6k_1, _this__u8e3s4.v6k_1, _this__u8e3s4.w6k_1));
}
function toResponseFormat(_this__u8e3s4) {
  var tmp;
  if (equals(_this__u8e3s4, Text_instance)) {
    tmp = null;
  } else {
    if (equals(_this__u8e3s4, JsonObject_instance)) {
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder = new JsonObjectBuilder();
      builder.r3o('type', JsonPrimitive('json_object'));
      tmp = builder.i3n();
    } else {
      if (_this__u8e3s4 instanceof JsonSchema) {
        // Inline function 'kotlinx.serialization.json.buildJsonObject' call
        var builder_0 = new JsonObjectBuilder();
        builder_0.r3o('type', JsonPrimitive('json_schema'));
        // Inline function 'kotlinx.serialization.json.buildJsonObject' call
        var builder_1 = new JsonObjectBuilder();
        builder_1.r3o('name', JsonPrimitive(_this__u8e3s4.k6e_1));
        builder_1.r3o('schema', _this__u8e3s4.l6e_1);
        builder_1.r3o('strict', JsonPrimitive_0(_this__u8e3s4.m6e_1));
        var tmp$ret$3 = builder_1.i3n();
        builder_0.r3o('json_schema', tmp$ret$3);
        tmp = builder_0.i3n();
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return tmp;
}
function ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba() {
  return new ArrayListSerializer($serializer_getInstance_0());
}
function ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba_0() {
  return new ArrayListSerializer($serializer_getInstance_1());
}
function ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba_1() {
  return new ArrayListSerializer(StringSerializer_getInstance());
}
var Companion_instance_2;
function Companion_getInstance_0() {
  if (Companion_instance_2 === VOID)
    new Companion();
  return Companion_instance_2;
}
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance === VOID)
    new $serializer();
  return $serializer_instance;
}
function ChatMessage$Companion$$childSerializers$_anonymous__qywqat() {
  return new ArrayListSerializer($serializer_getInstance_3());
}
var Companion_instance_3;
function Companion_getInstance_1() {
  if (Companion_instance_3 === VOID)
    new Companion_0();
  return Companion_instance_3;
}
var $serializer_instance_0;
function $serializer_getInstance_0() {
  if ($serializer_instance_0 === VOID)
    new $serializer_0();
  return $serializer_instance_0;
}
var Companion_instance_4;
function Companion_getInstance_2() {
  return Companion_instance_4;
}
var $serializer_instance_1;
function $serializer_getInstance_1() {
  if ($serializer_instance_1 === VOID)
    new $serializer_1();
  return $serializer_instance_1;
}
var Companion_instance_5;
function Companion_getInstance_3() {
  return Companion_instance_5;
}
var $serializer_instance_2;
function $serializer_getInstance_2() {
  if ($serializer_instance_2 === VOID)
    new $serializer_2();
  return $serializer_instance_2;
}
var Companion_instance_6;
function Companion_getInstance_4() {
  return Companion_instance_6;
}
var $serializer_instance_3;
function $serializer_getInstance_3() {
  if ($serializer_instance_3 === VOID)
    new $serializer_3();
  return $serializer_instance_3;
}
var Companion_instance_7;
function Companion_getInstance_5() {
  return Companion_instance_7;
}
var $serializer_instance_4;
function $serializer_getInstance_4() {
  if ($serializer_instance_4 === VOID)
    new $serializer_4();
  return $serializer_instance_4;
}
var Companion_instance_8;
function Companion_getInstance_6() {
  return Companion_instance_8;
}
var $serializer_instance_5;
function $serializer_getInstance_5() {
  if ($serializer_instance_5 === VOID)
    new $serializer_5();
  return $serializer_instance_5;
}
var Companion_instance_9;
function Companion_getInstance_7() {
  return Companion_instance_9;
}
var $serializer_instance_6;
function $serializer_getInstance_6() {
  if ($serializer_instance_6 === VOID)
    new $serializer_6();
  return $serializer_instance_6;
}
function ChatCompletionsResponse$Delta$Companion$$childSerializers$_anonymous__fygqye() {
  return new ArrayListSerializer($serializer_getInstance_8());
}
var Companion_instance_10;
function Companion_getInstance_8() {
  if (Companion_instance_10 === VOID)
    new Companion_7();
  return Companion_instance_10;
}
var $serializer_instance_7;
function $serializer_getInstance_7() {
  if ($serializer_instance_7 === VOID)
    new $serializer_7();
  return $serializer_instance_7;
}
var Companion_instance_11;
function Companion_getInstance_9() {
  return Companion_instance_11;
}
var $serializer_instance_8;
function $serializer_getInstance_8() {
  if ($serializer_instance_8 === VOID)
    new $serializer_8();
  return $serializer_instance_8;
}
var Companion_instance_12;
function Companion_getInstance_10() {
  return Companion_instance_12;
}
var $serializer_instance_9;
function $serializer_getInstance_9() {
  if ($serializer_instance_9 === VOID)
    new $serializer_9();
  return $serializer_instance_9;
}
var Companion_instance_13;
function Companion_getInstance_11() {
  return Companion_instance_13;
}
var $serializer_instance_10;
function $serializer_getInstance_10() {
  if ($serializer_instance_10 === VOID)
    new $serializer_10();
  return $serializer_instance_10;
}
var Companion_instance_14;
function Companion_getInstance_12() {
  return Companion_instance_14;
}
var $serializer_instance_11;
function $serializer_getInstance_11() {
  if ($serializer_instance_11 === VOID)
    new $serializer_11();
  return $serializer_instance_11;
}
var Companion_instance_15;
function Companion_getInstance_13() {
  return Companion_instance_15;
}
var $serializer_instance_12;
function $serializer_getInstance_12() {
  if ($serializer_instance_12 === VOID)
    new $serializer_12();
  return $serializer_instance_12;
}
var Companion_instance_16;
function Companion_getInstance_14() {
  return Companion_instance_16;
}
var $serializer_instance_13;
function $serializer_getInstance_13() {
  if ($serializer_instance_13 === VOID)
    new $serializer_13();
  return $serializer_instance_13;
}
function ChatCompletionsResponse$Companion$$childSerializers$_anonymous__8hhtau() {
  return new ArrayListSerializer($serializer_getInstance_6());
}
var Companion_instance_17;
function Companion_getInstance_15() {
  if (Companion_instance_17 === VOID)
    new Companion_14();
  return Companion_instance_17;
}
var $serializer_instance_14;
function $serializer_getInstance_14() {
  if ($serializer_instance_14 === VOID)
    new $serializer_14();
  return $serializer_instance_14;
}
//region block: post-declaration
initMetadataForClass(ToolAcc, 'ToolAcc', ToolAcc);
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(ChatCompletionsDecoder, 'ChatCompletionsDecoder');
initMetadataForClass(ChatCompletionsModel, 'ChatCompletionsModel', VOID, VOID, VOID, [1]);
initMetadataForClass(ChatCompletionsParams, 'ChatCompletionsParams', ChatCompletionsParams);
initMetadataForCompanion(Companion);
protoOf($serializer).v25 = typeParametersSerializers;
initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatCompletionsRequest, 'ChatCompletionsRequest', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
initMetadataForCompanion(Companion_0);
protoOf($serializer_0).v25 = typeParametersSerializers;
initMetadataForObject($serializer_0, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatMessage, 'ChatMessage', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
initMetadataForCompanion(Companion_1);
protoOf($serializer_1).v25 = typeParametersSerializers;
initMetadataForObject($serializer_1, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatTool, 'ChatTool', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_1});
initMetadataForCompanion(Companion_2);
protoOf($serializer_2).v25 = typeParametersSerializers;
initMetadataForObject($serializer_2, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatStreamOptions, 'ChatStreamOptions', ChatStreamOptions, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_2});
initMetadataForCompanion(Companion_3);
protoOf($serializer_3).v25 = typeParametersSerializers;
initMetadataForObject($serializer_3, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatReqToolCall, 'ChatReqToolCall', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_3});
initMetadataForCompanion(Companion_4);
protoOf($serializer_4).v25 = typeParametersSerializers;
initMetadataForObject($serializer_4, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatReqFunction, 'ChatReqFunction', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_4});
initMetadataForCompanion(Companion_5);
protoOf($serializer_5).v25 = typeParametersSerializers;
initMetadataForObject($serializer_5, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatFunctionDef, 'ChatFunctionDef', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_5});
initMetadataForCompanion(Companion_6);
protoOf($serializer_6).v25 = typeParametersSerializers;
initMetadataForObject($serializer_6, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_7);
protoOf($serializer_7).v25 = typeParametersSerializers;
initMetadataForObject($serializer_7, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_8);
protoOf($serializer_8).v25 = typeParametersSerializers;
initMetadataForObject($serializer_8, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_9);
protoOf($serializer_9).v25 = typeParametersSerializers;
initMetadataForObject($serializer_9, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_10);
protoOf($serializer_10).v25 = typeParametersSerializers;
initMetadataForObject($serializer_10, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_11);
protoOf($serializer_11).v25 = typeParametersSerializers;
initMetadataForObject($serializer_11, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_12);
protoOf($serializer_12).v25 = typeParametersSerializers;
initMetadataForObject($serializer_12, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_13);
protoOf($serializer_13).v25 = typeParametersSerializers;
initMetadataForObject($serializer_13, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(Choice, 'Choice', Choice, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_6});
initMetadataForClass(Delta, 'Delta', Delta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_7});
initMetadataForClass(ToolCallChunk, 'ToolCallChunk', ToolCallChunk, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_8});
initMetadataForClass(FunctionChunk, 'FunctionChunk', FunctionChunk, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_9});
initMetadataForClass(Usage_0, 'Usage', Usage_0, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_10});
initMetadataForClass(PromptDetails, 'PromptDetails', PromptDetails, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_11});
initMetadataForClass(CompletionDetails, 'CompletionDetails', CompletionDetails, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_12});
initMetadataForClass(ErrorOutput, 'ErrorOutput', ErrorOutput, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_13});
initMetadataForCompanion(Companion_14);
protoOf($serializer_14).v25 = typeParametersSerializers;
initMetadataForObject($serializer_14, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatCompletionsResponse, 'ChatCompletionsResponse', ChatCompletionsResponse, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_14});
//endregion
//region block: init
Companion_instance_4 = new Companion_1();
Companion_instance_5 = new Companion_2();
Companion_instance_6 = new Companion_3();
Companion_instance_7 = new Companion_4();
Companion_instance_8 = new Companion_5();
Companion_instance_9 = new Companion_6();
Companion_instance_11 = new Companion_8();
Companion_instance_12 = new Companion_9();
Companion_instance_13 = new Companion_10();
Companion_instance_14 = new Companion_11();
Companion_instance_15 = new Companion_12();
Companion_instance_16 = new Companion_13();
//endregion
//region block: exports
export {
  ChatCompletionsModel as ChatCompletionsModel2rl4figp5zhty,
  ChatCompletionsParams as ChatCompletionsParams2phuyy1p28jz5,
  normalizeChatCompletionsUrl as normalizeChatCompletionsUrlbu0jml6vp44x,
};
//endregion

//# sourceMappingURL=koaks-model-provider-chat-completions.mjs.map
