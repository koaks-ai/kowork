import {
  PrimitiveClasses_getInstance28ukyr6i8fs0q as PrimitiveClasses_getInstance,
  arrayOf1akklvh2at202 as arrayOf,
  createKType1lgox3mzhchp5 as createKType,
  Unit_instance104q5opgivhr8 as Unit_instance,
  VOID7hggqo3abtya as VOID,
  isBlank1dvkhjjvox3p0 as isBlank,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  equals2au1ep9vhcato as equals,
  hashCodeq5arwsb9dgti as hashCode,
  KtMutableMap1kqeifoi36kpz as KtMutableMap,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  Entry2xmjmyutzoq3p as Entry,
  isInterface3d6p8outrmvmk as isInterface,
  toString30pk9tzaqopn as toString_0,
  charArray2ujmm1qusno00 as charArray,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  toString35i91qxh73cps as toString_1,
  AbstractCoroutineContextElement2rpehg0hv5szw as AbstractCoroutineContextElement,
  Element2gr7ezmxqaln7 as Element,
  ArrayList3it5z8td81qkl as ArrayList,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  toSet2orjxp16sotqu as toSet,
  KtSetjrjc7fhfd6b9 as KtSet,
  KtMutableSetwuwn7k5m570a as KtMutableSet,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  Enum3alwj03lh1n41 as Enum,
  firstOrNull1982767dljvdy as firstOrNull,
  KtMap140uvy3s5zad8 as KtMap,
  addAll1k27qatfgp3k5 as addAll,
  emptySetcxexqki71qfa as emptySet,
  emptyMapr06gerzljqtm as emptyMap,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  equals2v6cggk171b6e as equals_0,
  setOf1u3mizs95ngxo as setOf,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  StringBuildermazzzhj6kkai as StringBuilder,
  get_lastIndexld83bqhfgcdd as get_lastIndex,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  Char__plus_impl_qi7pgj1zq2c0uiotg93 as Char__plus_impl_qi7pgj,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  Long2qws0ah9gnpki as Long,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  protoOf180f3jzyo7rfj as protoOf,
  createThis2j2avj17cvnv2 as createThis,
  Comparable198qfk8pnblz0 as Comparable,
  enumEntries20mr21zbe3az4 as enumEntries,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  toMutableList20rdgwi7d3cwi as toMutableList,
  KtMutableList1beimitadwkna as KtMutableList,
  emptyList1g2z5xcrvp2zy as emptyList,
  get_lastIndex1yw0x4k50k51w as get_lastIndex_0,
  last1vo29oleiqj36 as last,
  mutableListOf6oorvk2mtdmp as mutableListOf,
  anyToString3ho3k49fc56mj as anyToString,
  KMutableProperty11e8g1gb0ecb9j as KMutableProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  setPropertiesToThrowableInstance1w2jjvl9y77yc as setPropertiesToThrowableInstance,
  captureStack1fzi4aczwc4hg as captureStack,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  _Result___get_isFailure__impl__jpirivzehaw445b0cy as _Result___get_isFailure__impl__jpiriv,
  Continuation1aa2oekvx7jm7 as Continuation,
  intercepted2ogpsikxxj4u0 as intercepted,
  KProperty1ca4yb4wlo496 as KProperty1,
  lazy2hsh8ze7j6ikd as lazy_0,
  isNaNymqb93xtq8w8 as isNaN_0,
  numberToLong1a4cndvg6c52s as numberToLong,
  toList3jhuyej2anx2q as toList,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
} from './kotlin-kotlin-stdlib.mjs';
import {
  SupervisorJobythnfxkr3jxc as SupervisorJob,
  Key_instancexdagtxajq561 as Key_instance,
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
  recoverStackTrace2i3si2i8nvw1k as recoverStackTrace,
} from './kotlinx-coroutines-core.mjs';
import { atomic$ref$130aurmcwdfdf1 as atomic$ref$1 } from './kotlinx-atomicfu.mjs';
import {
  createSimpleEnumSerializer2guioz11kk1m0 as createSimpleEnumSerializer,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  UnknownFieldExceptiona60e3a6v1xqo as UnknownFieldException,
  IntSerializer_getInstance9scrtcljaiv6 as IntSerializer_getInstance,
  LongSerializer_getInstance3iic24guzegu7 as LongSerializer_getInstance,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class AttributeKey {
  constructor(name, type) {
    var tmp;
    if (type === VOID) {
      // Inline function 'io.ktor.util.reflect.typeInfo' call
      var tmp_0 = PrimitiveClasses_getInstance().dg();
      // Inline function 'io.ktor.util.reflect.typeOfOrNull' call
      var tmp_1;
      try {
        tmp_1 = createKType(PrimitiveClasses_getInstance().dg(), arrayOf([]), false);
      } catch ($p) {
        var tmp_2;
        if ($p instanceof Error) {
          var _unused_var__etf5q3 = $p;
          tmp_2 = null;
        } else {
          throw $p;
        }
        tmp_1 = tmp_2;
      }
      var tmp$ret$0 = tmp_1;
      tmp = new TypeInfo(tmp_0, tmp$ret$0);
    } else {
      tmp = type;
    }
    type = tmp;
    this.j2f_1 = name;
    this.k2f_1 = type;
    // Inline function 'kotlin.text.isNotBlank' call
    var this_0 = this.j2f_1;
    // Inline function 'kotlin.require' call
    if (!!isBlank(this_0)) {
      var message = "Name can't be blank";
      throw IllegalArgumentException.t(toString(message));
    }
  }
  toString() {
    return 'AttributeKey: ' + this.j2f_1;
  }
  hashCode() {
    var result = getStringHashCode(this.j2f_1);
    result = imul(result, 31) + this.k2f_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AttributeKey))
      return false;
    var tmp0_other_with_cast = other instanceof AttributeKey ? other : THROW_CCE();
    if (!(this.j2f_1 === tmp0_other_with_cast.j2f_1))
      return false;
    if (!this.k2f_1.equals(tmp0_other_with_cast.k2f_1))
      return false;
    return true;
  }
}
class Attributes {}
function get(key) {
  var tmp0_elvis_lhs = this.m2f(key);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException.t4('No instance for key ' + key.toString());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
class CaseInsensitiveMap {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.u2f_1 = LinkedHashMap.hc();
  }
  b1() {
    return this.u2f_1.b1();
  }
  v2f(key) {
    return this.u2f_1.f3(new CaseInsensitiveString(key));
  }
  f3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return false;
    return this.v2f((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  w2f(key) {
    return this.u2f_1.h3(caseInsensitive(key));
  }
  h3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return null;
    return this.w2f((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  h1() {
    return this.u2f_1.h1();
  }
  b3() {
    this.u2f_1.b3();
  }
  x2f(key, value) {
    return this.u2f_1.k3(caseInsensitive(key), value);
  }
  k3(key, value) {
    var tmp = (!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE();
    return this.x2f(tmp, !(value == null) ? value : THROW_CCE());
  }
  y2f(from) {
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = from.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var key = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var value = element.n1();
      this.x2f(key, value);
    }
  }
  m3(from) {
    return this.y2f(from);
  }
  z2f(key) {
    return this.u2f_1.l3(caseInsensitive(key));
  }
  l3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return null;
    return this.z2f((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  i3() {
    var tmp = this.u2f_1.i3();
    var tmp_0 = CaseInsensitiveMap$_get_keys_$lambda_ptzlqj;
    return new DelegatingMutableSet(tmp, tmp_0, CaseInsensitiveMap$_get_keys_$lambda_ptzlqj_0);
  }
  l1() {
    var tmp = this.u2f_1.l1();
    var tmp_0 = CaseInsensitiveMap$_get_entries_$lambda_r32w19;
    return new DelegatingMutableSet(tmp, tmp_0, CaseInsensitiveMap$_get_entries_$lambda_r32w19_0);
  }
  j3() {
    return this.u2f_1.j3();
  }
  equals(other) {
    var tmp;
    if (other == null) {
      tmp = true;
    } else {
      tmp = !(other instanceof CaseInsensitiveMap);
    }
    if (tmp)
      return false;
    return equals(other.u2f_1, this.u2f_1);
  }
  hashCode() {
    return hashCode(this.u2f_1);
  }
}
class Entry_0 {
  constructor(key, value) {
    this.a2g_1 = key;
    this.b2g_1 = value;
  }
  m1() {
    return this.a2g_1;
  }
  n1() {
    return this.b2g_1;
  }
  hashCode() {
    return (527 + hashCode(ensureNotNull(this.a2g_1)) | 0) + hashCode(ensureNotNull(this.b2g_1)) | 0;
  }
  equals(other) {
    var tmp;
    if (other == null) {
      tmp = true;
    } else {
      tmp = !(!(other == null) ? isInterface(other, Entry) : false);
    }
    if (tmp)
      return false;
    return equals(other.m1(), this.a2g_1) && equals(other.n1(), this.b2g_1);
  }
  toString() {
    return toString_0(this.a2g_1) + '=' + toString_0(this.b2g_1);
  }
}
class SilentSupervisor$$inlined$CoroutineExceptionHandler$1 extends AbstractCoroutineContextElement {
  constructor() {
    super(Key_instance);
  }
  j12(context, exception) {
    return Unit_instance;
  }
}
class DelegatingMutableSet$iterator$1 {
  constructor(this$0) {
    this.e2g_1 = this$0;
    this.d2g_1 = this$0.f2g_1.y();
  }
  z() {
    return this.d2g_1.z();
  }
  a1() {
    return this.e2g_1.g2g_1(this.d2g_1.a1());
  }
  e6() {
    return this.d2g_1.e6();
  }
}
class DelegatingMutableSet {
  constructor(delegate, convertTo, convert) {
    this.f2g_1 = delegate;
    this.g2g_1 = convertTo;
    this.h2g_1 = convert;
    this.i2g_1 = this.f2g_1.b1();
  }
  j2g(_this__u8e3s4) {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(_this__u8e3s4, 10));
    var _iterator__ex2g4s = _this__u8e3s4.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = this.h2g_1(item);
      destination.l(tmp$ret$0);
    }
    return destination;
  }
  k2g(_this__u8e3s4) {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(_this__u8e3s4, 10));
    var _iterator__ex2g4s = _this__u8e3s4.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = this.g2g_1(item);
      destination.l(tmp$ret$0);
    }
    return destination;
  }
  b1() {
    return this.i2g_1;
  }
  l2g(element) {
    return this.f2g_1.l(this.h2g_1(element));
  }
  l(element) {
    return this.l2g((element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
  m2g(elements) {
    return this.f2g_1.c1(this.j2g(elements));
  }
  c1(elements) {
    return this.m2g(elements);
  }
  b3() {
    this.f2g_1.b3();
  }
  n2g(element) {
    return this.f2g_1.z2(this.h2g_1(element));
  }
  z2(element) {
    if (!(element == null ? true : !(element == null)))
      return false;
    return this.n2g((element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
  o2g(elements) {
    return this.f2g_1.a3(toSet(this.j2g(elements)));
  }
  a3(elements) {
    return this.o2g(elements);
  }
  p2g(element) {
    return this.f2g_1.v2(this.h2g_1(element));
  }
  v2(element) {
    if (!(element == null ? true : !(element == null)))
      return false;
    return this.p2g((element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
  q2g(elements) {
    return this.f2g_1.w2(this.j2g(elements));
  }
  w2(elements) {
    return this.q2g(elements);
  }
  h1() {
    return this.f2g_1.h1();
  }
  y() {
    return new DelegatingMutableSet$iterator$1(this);
  }
  hashCode() {
    return hashCode(this.f2g_1);
  }
  equals(other) {
    var tmp;
    if (other == null) {
      tmp = true;
    } else {
      tmp = !(!(other == null) ? isInterface(other, KtSet) : false);
    }
    if (tmp)
      return false;
    var elements = this.k2g(this.f2g_1);
    var tmp_0;
    if (other.w2(elements)) {
      // Inline function 'kotlin.collections.containsAll' call
      tmp_0 = elements.w2(other);
    } else {
      tmp_0 = false;
    }
    return tmp_0;
  }
  toString() {
    return toString(this.k2g(this.f2g_1));
  }
}
class Platform {}
class Jvm extends Platform {
  constructor() {
    Jvm_instance = null;
    super();
    Jvm_instance = this;
  }
  toString() {
    return 'Jvm';
  }
  hashCode() {
    return 1051825272;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Jvm))
      return false;
    other instanceof Jvm || THROW_CCE();
    return true;
  }
}
class Native extends Platform {
  constructor() {
    Native_instance = null;
    super();
    Native_instance = this;
  }
  toString() {
    return 'Native';
  }
  hashCode() {
    return -1059277600;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Native))
      return false;
    other instanceof Native || THROW_CCE();
    return true;
  }
}
class Js extends Platform {
  constructor(jsPlatform) {
    super();
    this.r2g_1 = jsPlatform;
  }
  toString() {
    return 'Js(jsPlatform=' + this.r2g_1.toString() + ')';
  }
  hashCode() {
    return this.r2g_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Js))
      return false;
    var tmp0_other_with_cast = other instanceof Js ? other : THROW_CCE();
    if (!this.r2g_1.equals(tmp0_other_with_cast.r2g_1))
      return false;
    return true;
  }
}
class WasmJs extends Platform {}
class JsPlatform extends Enum {}
class PlatformUtils {
  constructor() {
    PlatformUtils_instance = this;
    var tmp = this;
    var platform = get_platform(this);
    var tmp_0;
    if (platform instanceof Js) {
      tmp_0 = platform.r2g_1.equals(JsPlatform_Browser_getInstance());
    } else {
      if (platform instanceof WasmJs) {
        tmp_0 = platform.s2g_1.equals(JsPlatform_Browser_getInstance());
      } else {
        tmp_0 = false;
      }
    }
    tmp.t2g_1 = tmp_0;
    var tmp_1 = this;
    var platform_0 = get_platform(this);
    var tmp_2;
    if (platform_0 instanceof Js) {
      tmp_2 = platform_0.r2g_1.equals(JsPlatform_Node_getInstance());
    } else {
      if (platform_0 instanceof WasmJs) {
        tmp_2 = platform_0.s2g_1.equals(JsPlatform_Node_getInstance());
      } else {
        tmp_2 = false;
      }
    }
    tmp_1.u2g_1 = tmp_2;
    var tmp_3 = this;
    var tmp_4 = get_platform(this);
    tmp_3.v2g_1 = tmp_4 instanceof Js;
    var tmp_5 = this;
    var tmp_6 = get_platform(this);
    tmp_5.w2g_1 = tmp_6 instanceof WasmJs;
    this.x2g_1 = equals(get_platform(this), Jvm_getInstance());
    this.y2g_1 = equals(get_platform(this), Native_getInstance());
    this.z2g_1 = get_isDevelopmentMode(this);
    this.a2h_1 = true;
  }
}
class StringValues {}
function get_0(name) {
  var tmp0_safe_receiver = this.c2h(name);
  return tmp0_safe_receiver == null ? null : firstOrNull(tmp0_safe_receiver);
}
function forEach(body) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = this.e2h().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var k = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var v = element.n1();
    body(k, v);
  }
  return Unit_instance;
}
class StringValuesBuilderImpl {
  constructor(caseInsensitiveName, size) {
    caseInsensitiveName = caseInsensitiveName === VOID ? false : caseInsensitiveName;
    size = size === VOID ? 8 : size;
    this.g2h_1 = caseInsensitiveName;
    this.h2h_1 = this.g2h_1 ? caseInsensitiveMap() : LinkedHashMap.ic(size);
  }
  b2h() {
    return this.g2h_1;
  }
  c2h(name) {
    return this.h2h_1.h3(name);
  }
  k2h(name) {
    // Inline function 'kotlin.collections.contains' call
    // Inline function 'kotlin.collections.containsKey' call
    var this_0 = this.h2h_1;
    return (isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).f3(name);
  }
  d2h() {
    return this.h2h_1.i3();
  }
  h1() {
    return this.h2h_1.h1();
  }
  e2h() {
    return unmodifiable(this.h2h_1.l1());
  }
  l2h(name, value) {
    this.m2h(value);
    var list = ensureListForKey(this, name);
    list.b3();
    list.l(value);
  }
  w2f(name) {
    var tmp0_safe_receiver = this.c2h(name);
    return tmp0_safe_receiver == null ? null : firstOrNull(tmp0_safe_receiver);
  }
  n2h(name, value) {
    this.m2h(value);
    ensureListForKey(this, name).l(value);
  }
  o2h(stringValues) {
    stringValues.f2h(StringValuesBuilderImpl$appendAll$lambda(this));
  }
  j2h(name, values) {
    // Inline function 'kotlin.let' call
    var list = ensureListForKey(this, name);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = values.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      this.m2h(element);
    }
    addAll(list, values);
  }
  p2h(name, values) {
    var tmp0_safe_receiver = this.h2h_1.h3(name);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toSet(tmp0_safe_receiver);
    var existing = tmp1_elvis_lhs == null ? emptySet() : tmp1_elvis_lhs;
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = values.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (!existing.v2(element)) {
        destination.l(element);
      }
    }
    this.j2h(name, destination);
  }
  q2h(name) {
    this.h2h_1.l3(name);
  }
  b3() {
    this.h2h_1.b3();
  }
  i2h(name) {
  }
  m2h(value) {
  }
}
class StringValuesImpl {
  constructor(caseInsensitiveName, values) {
    caseInsensitiveName = caseInsensitiveName === VOID ? false : caseInsensitiveName;
    values = values === VOID ? emptyMap() : values;
    this.r2h_1 = caseInsensitiveName;
    var tmp;
    if (this.r2h_1) {
      tmp = caseInsensitiveMap();
    } else {
      // Inline function 'kotlin.collections.mutableMapOf' call
      tmp = LinkedHashMap.hc();
    }
    var newMap = tmp;
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = values.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var key = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var value = element.n1();
      // Inline function 'kotlin.collections.List' call
      // Inline function 'kotlin.collections.MutableList' call
      var size = value.b1();
      var list = ArrayList.x(size);
      // Inline function 'kotlin.repeat' call
      var inductionVariable = 0;
      if (inductionVariable < size)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var tmp$ret$4 = value.f1(index);
          list.l(tmp$ret$4);
        }
         while (inductionVariable < size);
      // Inline function 'kotlin.collections.set' call
      newMap.k3(key, list);
    }
    this.s2h_1 = newMap;
  }
  b2h() {
    return this.r2h_1;
  }
  w2f(name) {
    var tmp0_safe_receiver = listForKey(this, name);
    return tmp0_safe_receiver == null ? null : firstOrNull(tmp0_safe_receiver);
  }
  c2h(name) {
    return listForKey(this, name);
  }
  d2h() {
    return unmodifiable(this.s2h_1.i3());
  }
  h1() {
    return this.s2h_1.h1();
  }
  e2h() {
    return unmodifiable(this.s2h_1.l1());
  }
  f2h(body) {
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = this.s2h_1.l1().y();
    while (_iterator__ex2g4s.z()) {
      var _destruct__k2r9zo = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var key = _destruct__k2r9zo.m1();
      // Inline function 'kotlin.collections.component2' call
      var value = _destruct__k2r9zo.n1();
      body(key, value);
    }
  }
  toString() {
    return 'StringValues(case=' + !this.r2h_1 + ') ' + toString(this.e2h());
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(!(other == null) ? isInterface(other, StringValues) : false))
      return false;
    if (!(this.r2h_1 === other.b2h()))
      return false;
    return entriesEquals(this.e2h(), other.e2h());
  }
  hashCode() {
    return entriesHashCode(this.e2h(), imul(31, getBooleanHashCode(this.r2h_1)));
  }
}
class StringValuesSingleImpl$entries$1 {
  constructor(this$0) {
    this.t2h_1 = this$0.w2h_1;
    this.u2h_1 = this$0.x2h_1;
  }
  m1() {
    return this.t2h_1;
  }
  n1() {
    return this.u2h_1;
  }
  toString() {
    return this.t2h_1 + '=' + toString(this.u2h_1);
  }
  equals(other) {
    var tmp;
    var tmp_0;
    if (!(other == null) ? isInterface(other, Entry) : false) {
      tmp_0 = equals(other.m1(), this.t2h_1);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = equals(other.n1(), this.u2h_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return getStringHashCode(this.t2h_1) ^ hashCode(this.u2h_1);
  }
}
class StringValuesSingleImpl {
  constructor(caseInsensitiveName, name, values) {
    this.v2h_1 = caseInsensitiveName;
    this.w2h_1 = name;
    this.x2h_1 = values;
  }
  b2h() {
    return this.v2h_1;
  }
  c2h(name) {
    return equals_0(this.w2h_1, name, this.b2h()) ? this.x2h_1 : null;
  }
  e2h() {
    return setOf(new StringValuesSingleImpl$entries$1(this));
  }
  d2h() {
    return setOf(this.w2h_1);
  }
  toString() {
    return 'StringValues(case=' + !this.b2h() + ') ' + toString(this.e2h());
  }
  hashCode() {
    return entriesHashCode(this.e2h(), imul(31, getBooleanHashCode(this.b2h())));
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(!(other == null) ? isInterface(other, StringValues) : false))
      return false;
    if (!(this.b2h() === other.b2h()))
      return false;
    return entriesEquals(this.e2h(), other.e2h());
  }
  f2h(body) {
    return body(this.w2h_1, this.x2h_1);
  }
  w2f(name) {
    return equals_0(name, this.w2h_1, this.b2h()) ? firstOrNull(this.x2h_1) : null;
  }
}
class CaseInsensitiveString {
  constructor(content) {
    this.s2f_1 = content;
    var temp = 0;
    var indexedObject = this.s2f_1;
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var element = charSequenceGet(indexedObject, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = imul(temp, 31);
      // Inline function 'kotlin.text.lowercaseChar' call
      // Inline function 'kotlin.text.lowercase' call
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'kotlin.js.unsafeCast' call
      var tmp$ret$2 = toString_1(element).toLowerCase();
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(tmp$ret$2, 0);
      temp = tmp + Char__toInt_impl_vasixd(this_0) | 0;
    }
    this.t2f_1 = temp;
  }
  equals(other) {
    var tmp0_safe_receiver = other instanceof CaseInsensitiveString ? other : null;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.s2f_1;
    return (tmp1_safe_receiver == null ? null : equals_0(tmp1_safe_receiver, this.s2f_1, true)) === true;
  }
  hashCode() {
    return this.t2f_1;
  }
  toString() {
    return this.s2f_1;
  }
}
class CopyOnWriteHashMap {
  constructor() {
    this.y2h_1 = atomic$ref$1(emptyMap());
  }
  z2h(key) {
    return this.y2h_1.kotlinx$atomicfu$value.h3(key);
  }
}
class Companion {
  constructor() {
    Companion_instance_0 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_1 = lazy(tmp_0, GMTDate$Companion$$childSerializers$_anonymous__gyfycy);
    var tmp_2 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.a2i_1 = [null, null, null, tmp_1, null, null, lazy(tmp_2, GMTDate$Companion$$childSerializers$_anonymous__gyfycy_0), null, null];
    this.b2i_1 = GMTDate_0(new Long(0, 0));
  }
}
class $serializer {
  constructor() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('io.ktor.util.date.GMTDate', this, 9);
    tmp0_serialDesc.f25('seconds', false);
    tmp0_serialDesc.f25('minutes', false);
    tmp0_serialDesc.f25('hours', false);
    tmp0_serialDesc.f25('dayOfWeek', false);
    tmp0_serialDesc.f25('dayOfMonth', false);
    tmp0_serialDesc.f25('dayOfYear', false);
    tmp0_serialDesc.f25('month', false);
    tmp0_serialDesc.f25('year', false);
    tmp0_serialDesc.f25('timestamp', false);
    this.c2i_1 = tmp0_serialDesc;
  }
  d2i(encoder, value) {
    var tmp0_desc = this.c2i_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    var tmp2_cached = Companion_getInstance().a2i_1;
    tmp1_output.b1z(tmp0_desc, 0, value.e2i_1);
    tmp1_output.b1z(tmp0_desc, 1, value.f2i_1);
    tmp1_output.b1z(tmp0_desc, 2, value.g2i_1);
    tmp1_output.i1z(tmp0_desc, 3, tmp2_cached[3].n1(), value.h2i_1);
    tmp1_output.b1z(tmp0_desc, 4, value.i2i_1);
    tmp1_output.b1z(tmp0_desc, 5, value.j2i_1);
    tmp1_output.i1z(tmp0_desc, 6, tmp2_cached[6].n1(), value.k2i_1);
    tmp1_output.b1z(tmp0_desc, 7, value.l2i_1);
    tmp1_output.c1z(tmp0_desc, 8, value.m2i_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.d2i(encoder, value instanceof GMTDate ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.c2i_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = 0;
    var tmp5_local1 = 0;
    var tmp6_local2 = 0;
    var tmp7_local3 = null;
    var tmp8_local4 = 0;
    var tmp9_local5 = 0;
    var tmp10_local6 = null;
    var tmp11_local7 = 0;
    var tmp12_local8 = new Long(0, 0);
    var tmp13_input = decoder.q1x(tmp0_desc);
    var tmp14_cached = Companion_getInstance().a2i_1;
    if (tmp13_input.g1y()) {
      tmp4_local0 = tmp13_input.v1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp13_input.v1x(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp13_input.v1x(tmp0_desc, 2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp13_input.c1y(tmp0_desc, 3, tmp14_cached[3].n1(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp13_input.v1x(tmp0_desc, 4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp13_input.v1x(tmp0_desc, 5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp13_input.c1y(tmp0_desc, 6, tmp14_cached[6].n1(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
      tmp11_local7 = tmp13_input.v1x(tmp0_desc, 7);
      tmp3_bitMask0 = tmp3_bitMask0 | 128;
      tmp12_local8 = tmp13_input.w1x(tmp0_desc, 8);
      tmp3_bitMask0 = tmp3_bitMask0 | 256;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp13_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp13_input.v1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp13_input.v1x(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp13_input.v1x(tmp0_desc, 2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp13_input.c1y(tmp0_desc, 3, tmp14_cached[3].n1(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp13_input.v1x(tmp0_desc, 4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp13_input.v1x(tmp0_desc, 5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp13_input.c1y(tmp0_desc, 6, tmp14_cached[6].n1(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          case 7:
            tmp11_local7 = tmp13_input.v1x(tmp0_desc, 7);
            tmp3_bitMask0 = tmp3_bitMask0 | 128;
            break;
          case 8:
            tmp12_local8 = tmp13_input.w1x(tmp0_desc, 8);
            tmp3_bitMask0 = tmp3_bitMask0 | 256;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp13_input.r1x(tmp0_desc);
    return GMTDate.n2i(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, tmp12_local8, null);
  }
  h1t() {
    return this.c2i_1;
  }
  u25() {
    var tmp0_cached = Companion_getInstance().a2i_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [IntSerializer_getInstance(), IntSerializer_getInstance(), IntSerializer_getInstance(), tmp0_cached[3].n1(), IntSerializer_getInstance(), IntSerializer_getInstance(), tmp0_cached[6].n1(), IntSerializer_getInstance(), LongSerializer_getInstance()];
  }
}
class GMTDate {
  constructor(seconds, minutes, hours, dayOfWeek, dayOfMonth, dayOfYear, month, year, timestamp) {
    Companion_getInstance();
    this.e2i_1 = seconds;
    this.f2i_1 = minutes;
    this.g2i_1 = hours;
    this.h2i_1 = dayOfWeek;
    this.i2i_1 = dayOfMonth;
    this.j2i_1 = dayOfYear;
    this.k2i_1 = month;
    this.l2i_1 = year;
    this.m2i_1 = timestamp;
  }
  o2i(other) {
    return this.m2i_1.s1(other.m2i_1);
  }
  d(other) {
    return this.o2i(other instanceof GMTDate ? other : THROW_CCE());
  }
  toString() {
    return 'GMTDate(seconds=' + this.e2i_1 + ', minutes=' + this.f2i_1 + ', hours=' + this.g2i_1 + ', dayOfWeek=' + this.h2i_1.toString() + ', dayOfMonth=' + this.i2i_1 + ', dayOfYear=' + this.j2i_1 + ', month=' + this.k2i_1.toString() + ', year=' + this.l2i_1 + ', timestamp=' + this.m2i_1.toString() + ')';
  }
  hashCode() {
    var result = this.e2i_1;
    result = imul(result, 31) + this.f2i_1 | 0;
    result = imul(result, 31) + this.g2i_1 | 0;
    result = imul(result, 31) + this.h2i_1.hashCode() | 0;
    result = imul(result, 31) + this.i2i_1 | 0;
    result = imul(result, 31) + this.j2i_1 | 0;
    result = imul(result, 31) + this.k2i_1.hashCode() | 0;
    result = imul(result, 31) + this.l2i_1 | 0;
    result = imul(result, 31) + this.m2i_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof GMTDate))
      return false;
    var tmp0_other_with_cast = other instanceof GMTDate ? other : THROW_CCE();
    if (!(this.e2i_1 === tmp0_other_with_cast.e2i_1))
      return false;
    if (!(this.f2i_1 === tmp0_other_with_cast.f2i_1))
      return false;
    if (!(this.g2i_1 === tmp0_other_with_cast.g2i_1))
      return false;
    if (!this.h2i_1.equals(tmp0_other_with_cast.h2i_1))
      return false;
    if (!(this.i2i_1 === tmp0_other_with_cast.i2i_1))
      return false;
    if (!(this.j2i_1 === tmp0_other_with_cast.j2i_1))
      return false;
    if (!this.k2i_1.equals(tmp0_other_with_cast.k2i_1))
      return false;
    if (!(this.l2i_1 === tmp0_other_with_cast.l2i_1))
      return false;
    if (!this.m2i_1.equals(tmp0_other_with_cast.m2i_1))
      return false;
    return true;
  }
  static n2i(seen0, seconds, minutes, hours, dayOfWeek, dayOfMonth, dayOfYear, month, year, timestamp, serializationConstructorMarker) {
    Companion_getInstance();
    if (!(511 === (511 & seen0))) {
      throwMissingFieldException(seen0, 511, $serializer_getInstance().c2i_1);
    }
    var $this = createThis(this);
    $this.e2i_1 = seconds;
    $this.f2i_1 = minutes;
    $this.g2i_1 = hours;
    $this.h2i_1 = dayOfWeek;
    $this.i2i_1 = dayOfMonth;
    $this.j2i_1 = dayOfYear;
    $this.k2i_1 = month;
    $this.l2i_1 = year;
    $this.m2i_1 = timestamp;
    return $this;
  }
}
class Companion_0 {
  p2i(ordinal) {
    return get_entries().f1(ordinal);
  }
}
class WeekDay extends Enum {
  constructor(name, ordinal, value) {
    super(name, ordinal);
    this.s2i_1 = value;
  }
}
class Companion_1 {
  p2i(ordinal) {
    return get_entries_0().f1(ordinal);
  }
}
class Month extends Enum {
  constructor(name, ordinal, value) {
    super(name, ordinal);
    this.v2i_1 = value;
  }
}
class Symbol {
  constructor(symbol) {
    this.w2i_1 = symbol;
  }
  toString() {
    return this.w2i_1;
  }
}
class LockFreeLinkedListNode {
  u18() {
    // Inline function 'kotlinx.atomicfu.loop' call
    var this_0 = this.x2i_1;
    while (true) {
      var next = this_0.kotlinx$atomicfu$value;
      if (!(next instanceof OpDescriptor))
        return next;
      next.y2i(this);
    }
  }
  z2i() {
    return unwrap(this.u18());
  }
}
class Removed {}
class OpDescriptor {}
class PipelineContext {
  constructor(context) {
    this.g2k_1 = context;
  }
}
class DebugPipelineContext extends PipelineContext {
  constructor(context, interceptors, subject, coroutineContext) {
    super(context);
    this.c2j_1 = interceptors;
    this.d2j_1 = coroutineContext;
    this.e2j_1 = subject;
    this.f2j_1 = 0;
  }
  ru() {
    return this.d2j_1;
  }
  h2j() {
    return this.e2j_1;
  }
  g2j() {
    this.f2j_1 = -1;
  }
  i2j(subject, $completion) {
    this.e2j_1 = subject;
    return this.j2j($completion);
  }
  j2j($completion) {
    var index = this.f2j_1;
    if (index < 0)
      return this.e2j_1;
    if (index >= this.c2j_1.b1()) {
      this.g2j();
      return this.e2j_1;
    }
    return proceedLoop(this, $completion);
  }
  k2j(initial, $completion) {
    this.f2j_1 = 0;
    this.e2j_1 = initial;
    return this.j2j($completion);
  }
}
class Companion_2 {
  constructor() {
    Companion_instance_3 = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.p2j_1 = ArrayList.k();
  }
}
class PhaseContent {
  static q2j(phase, relation, interceptors) {
    Companion_getInstance_2();
    var $this = createThis(this);
    $this.l2j_1 = phase;
    $this.m2j_1 = relation;
    $this.n2j_1 = interceptors;
    $this.o2j_1 = true;
    return $this;
  }
  static r2j(phase, relation) {
    Companion_getInstance_2();
    var tmp = Companion_getInstance_2().p2j_1;
    var $this = this.q2j(phase, relation, isInterface(tmp, KtMutableList) ? tmp : THROW_CCE());
    // Inline function 'kotlin.check' call
    if (!Companion_getInstance_2().p2j_1.h1()) {
      var message = 'The shared empty array list has been modified';
      throw IllegalStateException.t4(toString(message));
    }
    return $this;
  }
  s2j() {
    return this.n2j_1.h1();
  }
  b1() {
    return this.n2j_1.b1();
  }
  t2j(interceptor) {
    if (this.o2j_1) {
      copyInterceptors(this);
    }
    this.n2j_1.l(interceptor);
  }
  u2j(destination) {
    var interceptors = this.n2j_1;
    if (destination instanceof ArrayList) {
      destination.y7(destination.b1() + interceptors.b1() | 0);
    }
    var inductionVariable = 0;
    var last = interceptors.b1();
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        destination.l(interceptors.f1(index));
      }
       while (inductionVariable < last);
  }
  v2j() {
    this.o2j_1 = true;
    return this.n2j_1;
  }
  toString() {
    return 'Phase `' + this.l2j_1.w2j_1 + '`, ' + this.b1() + ' handlers';
  }
}
class Pipeline {
  constructor(phases) {
    this.x2j_1 = AttributesJsFn(true);
    this.y2j_1 = false;
    this.z2j_1 = mutableListOf(phases.slice());
    this.a2k_1 = 0;
    this.b2k_1 = atomic$ref$1(null);
    this.c2k_1 = false;
    this.d2k_1 = null;
  }
  e2k() {
    return this.y2j_1;
  }
  f2k(context, subject, $completion) {
    // Inline function 'kotlin.js.getCoroutineContext' call
    var tmp$ret$0 = $completion.lc();
    return createContext(this, context, subject, tmp$ret$0).k2j(subject, $completion);
  }
  h2k(reference, phase) {
    if (hasPhase(this, phase))
      return Unit_instance;
    var index = findPhaseIndex(this, reference);
    if (index === -1) {
      throw InvalidPhaseException.j2k('Phase ' + reference.toString() + ' was not registered for this pipeline');
    }
    var lastRelatedPhaseIndex = index;
    var inductionVariable = index + 1 | 0;
    var last = get_lastIndex_0(this.z2j_1);
    if (inductionVariable <= last)
      $l$loop_0: do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = this.z2j_1.f1(i);
        var tmp0_safe_receiver = tmp instanceof PhaseContent ? tmp : null;
        var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m2j_1;
        var tmp_0;
        if (tmp1_elvis_lhs == null) {
          break $l$loop_0;
        } else {
          tmp_0 = tmp1_elvis_lhs;
        }
        var relation = tmp_0;
        var tmp2_safe_receiver = relation instanceof After ? relation : null;
        var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.k2k_1;
        var tmp_1;
        if (tmp3_elvis_lhs == null) {
          continue $l$loop_0;
        } else {
          tmp_1 = tmp3_elvis_lhs;
        }
        var relatedTo = tmp_1;
        lastRelatedPhaseIndex = equals(relatedTo, reference) ? i : lastRelatedPhaseIndex;
      }
       while (!(i === last));
    this.z2j_1.d3(lastRelatedPhaseIndex + 1 | 0, PhaseContent.r2j(phase, new After(reference)));
  }
  l2k(reference, phase) {
    if (hasPhase(this, phase))
      return Unit_instance;
    var index = findPhaseIndex(this, reference);
    if (index === -1) {
      throw InvalidPhaseException.j2k('Phase ' + reference.toString() + ' was not registered for this pipeline');
    }
    this.z2j_1.d3(index, PhaseContent.r2j(phase, new Before(reference)));
  }
  m2k(phase, block) {
    var tmp0_elvis_lhs = findPhase(this, phase);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw InvalidPhaseException.j2k('Phase ' + phase.toString() + ' was not registered for this pipeline');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var phaseContent = tmp;
    if (tryAddToPhaseFastPath(this, phase, block)) {
      this.a2k_1 = this.a2k_1 + 1 | 0;
      return Unit_instance;
    }
    phaseContent.t2j(block);
    this.a2k_1 = this.a2k_1 + 1 | 0;
    resetInterceptorsList(this);
    this.n2k();
  }
  n2k() {
  }
  toString() {
    return anyToString(this);
  }
}
class PipelinePhase {
  constructor(name) {
    this.w2j_1 = name;
  }
  toString() {
    return "Phase('" + this.w2j_1 + "')";
  }
}
class InvalidPhaseException extends Error {
  static j2k(message) {
    var $this = createThis(this);
    setPropertiesToThrowableInstance($this, message);
    captureStack($this, $this.i2k_1);
    return $this;
  }
}
class PipelinePhaseRelation {}
class After extends PipelinePhaseRelation {
  constructor(relativeTo) {
    super();
    this.k2k_1 = relativeTo;
  }
}
class Before extends PipelinePhaseRelation {
  constructor(relativeTo) {
    super();
    this.o2k_1 = relativeTo;
  }
}
class Last extends PipelinePhaseRelation {
  constructor() {
    Last_instance = null;
    super();
    Last_instance = this;
  }
  toString() {
    return 'Last';
  }
  hashCode() {
    return 967869129;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Last))
      return false;
    other instanceof Last || THROW_CCE();
    return true;
  }
}
class SuspendFunctionGun$continuation$1 {
  constructor(this$0) {
    this.x2k_1 = this$0;
    this.w2k_1 = -2147483648;
  }
  lc() {
    var continuation = this.x2k_1.t2k_1[this.x2k_1.u2k_1];
    if (!(continuation === this) && !(continuation == null))
      return continuation.lc();
    var index = this.x2k_1.u2k_1 - 1 | 0;
    while (index >= 0) {
      var _unary__edvuaz = index;
      index = _unary__edvuaz - 1 | 0;
      var cont = this.x2k_1.t2k_1[_unary__edvuaz];
      if (!(cont === this) && !(cont == null))
        return cont.lc();
    }
    // Inline function 'kotlin.error' call
    var message = 'Not started';
    throw IllegalStateException.t4(toString(message));
  }
  pm(result) {
    if (_Result___get_isFailure__impl__jpiriv(result)) {
      // Inline function 'kotlin.Companion.failure' call
      var exception = ensureNotNull(Result__exceptionOrNull_impl_p6xea9(result));
      var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception));
      resumeRootWith(this.x2k_1, tmp$ret$0);
      return Unit_instance;
    }
    loop(this.x2k_1, false);
  }
  nc(result) {
    return this.pm(result);
  }
}
class SuspendFunctionGun extends PipelineContext {
  constructor(initial, context, blocks) {
    super(context);
    this.q2k_1 = blocks;
    var tmp = this;
    tmp.r2k_1 = new SuspendFunctionGun$continuation$1(this);
    this.s2k_1 = initial;
    var tmp_0 = this;
    // Inline function 'kotlin.arrayOfNulls' call
    var size = this.q2k_1.b1();
    tmp_0.t2k_1 = Array(size);
    this.u2k_1 = -1;
    this.v2k_1 = 0;
  }
  ru() {
    return this.r2k_1.lc();
  }
  h2j() {
    return this.s2k_1;
  }
  j2j($completion) {
    var tmp$ret$0;
    $l$block_0: {
      if (this.v2k_1 === this.q2k_1.b1()) {
        tmp$ret$0 = this.s2k_1;
        break $l$block_0;
      }
      this.y2k(intercepted($completion));
      if (loop(this, true)) {
        discardLastRootContinuation(this);
        tmp$ret$0 = this.s2k_1;
        break $l$block_0;
      }
      tmp$ret$0 = get_COROUTINE_SUSPENDED();
    }
    return tmp$ret$0;
  }
  i2j(subject, $completion) {
    this.s2k_1 = subject;
    return this.j2j($completion);
  }
  k2j(initial, $completion) {
    this.v2k_1 = 0;
    if (this.v2k_1 === this.q2k_1.b1())
      return initial;
    this.s2k_1 = initial;
    if (this.u2k_1 >= 0)
      throw IllegalStateException.t4('Already started');
    return this.j2j($completion);
  }
  y2k(continuation) {
    this.u2k_1 = this.u2k_1 + 1 | 0;
    this.t2k_1[this.u2k_1] = continuation;
  }
}
class TypeInfo {
  constructor(type, kotlinType) {
    kotlinType = kotlinType === VOID ? null : kotlinType;
    this.z2k_1 = type;
    this.a2l_1 = kotlinType;
  }
  hashCode() {
    var tmp0_safe_receiver = this.a2l_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
    return tmp1_elvis_lhs == null ? this.z2k_1.hashCode() : tmp1_elvis_lhs;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof TypeInfo))
      return false;
    var tmp;
    if (!(this.a2l_1 == null) || !(other.a2l_1 == null)) {
      tmp = equals(this.a2l_1, other.a2l_1);
    } else {
      tmp = this.z2k_1.equals(other.z2k_1);
    }
    return tmp;
  }
  toString() {
    var tmp0_elvis_lhs = this.a2l_1;
    return 'TypeInfo(' + toString(tmp0_elvis_lhs == null ? this.z2k_1 : tmp0_elvis_lhs) + ')';
  }
}
class InvalidTimestampException extends IllegalStateException {
  static f2l(timestamp) {
    var $this = this.t4('Invalid date timestamp exception: ' + timestamp.toString());
    captureStack($this, $this.e2l_1);
    return $this;
  }
}
class AttributesJs {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.g2l_1 = LinkedHashMap.hc();
  }
  m2f(key) {
    var tmp = this.g2l_1.h3(key);
    return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  }
  n2f(key) {
    return this.g2l_1.f3(key);
  }
  o2f(key, value) {
    // Inline function 'kotlin.collections.set' call
    this.g2l_1.k3(key, value);
  }
  p2f(key) {
    this.g2l_1.l3(key);
  }
  q2f(key, block) {
    var tmp0_safe_receiver = this.g2l_1.h3(key);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return !(tmp0_safe_receiver == null) ? tmp0_safe_receiver : THROW_CCE();
    }
    // Inline function 'kotlin.also' call
    var this_0 = block();
    // Inline function 'kotlin.collections.set' call
    this.g2l_1.k3(key, this_0);
    return this_0;
  }
  r2f() {
    return toList(this.g2l_1.i3());
  }
}
class KtorSimpleLogger$1 {
  constructor() {
    var tmp = this;
    var tmp_0;
    switch (PlatformUtils_getInstance().u2g_1 || PlatformUtils_getInstance().t2g_1) {
      case true:
        // Inline function 'kotlin.runCatching' call

        var tmp_1;
        try {
          // Inline function 'kotlin.Companion.success' call
          var value = getKtorLogLevel();
          tmp_1 = _Result___init__impl__xyqfz8(value);
        } catch ($p) {
          var tmp_2;
          if ($p instanceof Error) {
            var e = $p;
            // Inline function 'kotlin.Companion.failure' call
            tmp_2 = _Result___init__impl__xyqfz8(createFailure(e));
          } else {
            throw $p;
          }
          tmp_1 = tmp_2;
        }

        // Inline function 'kotlin.Result.getOrNull' call

        var this_0 = tmp_1;
        var tmp_3;
        if (_Result___get_isFailure__impl__jpiriv(this_0)) {
          tmp_3 = null;
        } else {
          var tmp_4 = _Result___get_value__impl__bjfvqg(this_0);
          tmp_3 = (tmp_4 == null ? true : !(tmp_4 == null)) ? tmp_4 : THROW_CCE();
        }

        var tmp1_safe_receiver = tmp_3;
        var tmp_5;
        if (tmp1_safe_receiver == null) {
          tmp_5 = null;
        } else {
          // Inline function 'kotlin.let' call
          var tmp0 = get_entries_1();
          var tmp$ret$6;
          $l$block: {
            // Inline function 'kotlin.collections.firstOrNull' call
            var _iterator__ex2g4s = tmp0.y();
            while (_iterator__ex2g4s.z()) {
              var element = _iterator__ex2g4s.a1();
              if (element.n3_1 === tmp1_safe_receiver) {
                tmp$ret$6 = element;
                break $l$block;
              }
            }
            tmp$ret$6 = null;
          }
          tmp_5 = tmp$ret$6;
        }

        var tmp2_elvis_lhs = tmp_5;
        tmp_0 = tmp2_elvis_lhs == null ? LogLevel_INFO_getInstance() : tmp2_elvis_lhs;
        break;
      case false:
        tmp_0 = LogLevel_TRACE_getInstance();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    tmp.h2l_1 = tmp_0;
  }
  i2l() {
    return this.h2l_1;
  }
  j2l(message) {
    if (this.h2l_1.p3(LogLevel_WARN_getInstance()) > 0)
      return Unit_instance;
    console.warn(message);
  }
  k2l(message, cause) {
    if (this.h2l_1.p3(LogLevel_DEBUG_getInstance()) > 0)
      return Unit_instance;
    console.debug('DEBUG: ' + message + ', cause: ' + cause.toString());
  }
  l2l(message) {
    if (this.h2l_1.p3(LogLevel_TRACE_getInstance()) > 0)
      return Unit_instance;
    console.debug('TRACE: ' + message);
  }
}
class LogLevel extends Enum {}
//endregion
function putAll(_this__u8e3s4, other) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = other.r2f().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    _this__u8e3s4.o2f(element instanceof AttributeKey ? element : THROW_CCE(), other.l2f(element));
  }
}
function CaseInsensitiveMap$_get_keys_$lambda_ptzlqj($this$DelegatingMutableSet) {
  return $this$DelegatingMutableSet.s2f_1;
}
function CaseInsensitiveMap$_get_keys_$lambda_ptzlqj_0($this$DelegatingMutableSet) {
  return caseInsensitive($this$DelegatingMutableSet);
}
function CaseInsensitiveMap$_get_entries_$lambda_r32w19($this$DelegatingMutableSet) {
  return new Entry_0($this$DelegatingMutableSet.m1().s2f_1, $this$DelegatingMutableSet.n1());
}
function CaseInsensitiveMap$_get_entries_$lambda_r32w19_0($this$DelegatingMutableSet) {
  return new Entry_0(caseInsensitive($this$DelegatingMutableSet.m1()), $this$DelegatingMutableSet.n1());
}
function toCharArray(_this__u8e3s4) {
  var tmp = 0;
  var tmp_0 = _this__u8e3s4.length;
  var tmp_1 = charArray(tmp_0);
  while (tmp < tmp_0) {
    var tmp_2 = tmp;
    tmp_1[tmp_2] = charSequenceGet(_this__u8e3s4, tmp_2);
    tmp = tmp + 1 | 0;
  }
  return tmp_1;
}
function isLowerCase(_this__u8e3s4) {
  // Inline function 'kotlin.text.lowercaseChar' call
  // Inline function 'kotlin.text.lowercase' call
  // Inline function 'kotlin.js.asDynamic' call
  // Inline function 'kotlin.js.unsafeCast' call
  var tmp$ret$2 = toString_1(_this__u8e3s4).toLowerCase();
  return charSequenceGet(tmp$ret$2, 0) === _this__u8e3s4;
}
function caseInsensitiveMap() {
  return new CaseInsensitiveMap();
}
function SilentSupervisor(parent) {
  parent = parent === VOID ? null : parent;
  var tmp = SupervisorJob(parent);
  // Inline function 'kotlinx.coroutines.CoroutineExceptionHandler' call
  var tmp$ret$0 = new SilentSupervisor$$inlined$CoroutineExceptionHandler$1();
  return tmp.kn(tmp$ret$0);
}
var JsPlatform_Browser_instance;
var JsPlatform_Node_instance;
var JsPlatform_entriesInitialized;
function JsPlatform_initEntries() {
  if (JsPlatform_entriesInitialized)
    return Unit_instance;
  JsPlatform_entriesInitialized = true;
  JsPlatform_Browser_instance = new JsPlatform('Browser', 0);
  JsPlatform_Node_instance = new JsPlatform('Node', 1);
}
var Jvm_instance;
function Jvm_getInstance() {
  if (Jvm_instance === VOID)
    new Jvm();
  return Jvm_instance;
}
var Native_instance;
function Native_getInstance() {
  if (Native_instance === VOID)
    new Native();
  return Native_instance;
}
function JsPlatform_Browser_getInstance() {
  JsPlatform_initEntries();
  return JsPlatform_Browser_instance;
}
function JsPlatform_Node_getInstance() {
  JsPlatform_initEntries();
  return JsPlatform_Node_instance;
}
var PlatformUtils_instance;
function PlatformUtils_getInstance() {
  if (PlatformUtils_instance === VOID)
    new PlatformUtils();
  return PlatformUtils_instance;
}
function ensureListForKey($this, name) {
  var tmp0_elvis_lhs = $this.h2h_1.h3(name);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.collections.mutableListOf' call
    // Inline function 'kotlin.also' call
    var this_0 = ArrayList.k();
    $this.i2h(name);
    // Inline function 'kotlin.collections.set' call
    $this.h2h_1.k3(name, this_0);
    tmp = this_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function StringValuesBuilderImpl$appendAll$lambda(this$0) {
  return (name, values) => {
    this$0.j2h(name, values);
    return Unit_instance;
  };
}
function listForKey($this, name) {
  return $this.s2h_1.h3(name);
}
function appendAll(_this__u8e3s4, builder) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = builder.e2h().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var name = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var values = element.n1();
    _this__u8e3s4.j2h(name, values);
  }
  return _this__u8e3s4;
}
function entriesEquals(a, b) {
  return equals(a, b);
}
function entriesHashCode(entries, seed) {
  return imul(seed, 31) + hashCode(entries) | 0;
}
function toLowerCasePreservingASCIIRules(_this__u8e3s4) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.text.indexOfFirst' call
    var inductionVariable = 0;
    var last = charSequenceLength(_this__u8e3s4) - 1 | 0;
    if (inductionVariable <= last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var it = charSequenceGet(_this__u8e3s4, index);
        if (!(toLowerCasePreservingASCII(it) === it)) {
          tmp$ret$1 = index;
          break $l$block;
        }
      }
       while (inductionVariable <= last);
    tmp$ret$1 = -1;
  }
  var firstIndex = tmp$ret$1;
  if (firstIndex === -1) {
    return _this__u8e3s4;
  }
  var original = _this__u8e3s4;
  // Inline function 'kotlin.text.buildString' call
  var capacity = _this__u8e3s4.length;
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.xb(capacity);
  this_0.ch(original, 0, firstIndex);
  var inductionVariable_0 = firstIndex;
  var last_0 = get_lastIndex(original);
  if (inductionVariable_0 <= last_0)
    do {
      var index_0 = inductionVariable_0;
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      this_0.ub(toLowerCasePreservingASCII(charSequenceGet(original, index_0)));
    }
     while (!(index_0 === last_0));
  return this_0.toString();
}
function toLowerCasePreservingASCII(ch) {
  var tmp;
  if (_Char___init__impl__6a9atx(65) <= ch ? ch <= _Char___init__impl__6a9atx(90) : false) {
    tmp = Char__plus_impl_qi7pgj(ch, 32);
  } else if (_Char___init__impl__6a9atx(0) <= ch ? ch <= _Char___init__impl__6a9atx(127) : false) {
    tmp = ch;
  } else {
    // Inline function 'kotlin.text.lowercaseChar' call
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'kotlin.js.unsafeCast' call
    var tmp$ret$2 = toString_1(ch).toLowerCase();
    tmp = charSequenceGet(tmp$ret$2, 0);
  }
  return tmp;
}
function caseInsensitive(_this__u8e3s4) {
  return new CaseInsensitiveString(_this__u8e3s4);
}
function GMTDate$Companion$$childSerializers$_anonymous__gyfycy() {
  return createSimpleEnumSerializer('io.ktor.util.date.WeekDay', values());
}
function GMTDate$Companion$$childSerializers$_anonymous__gyfycy_0() {
  return createSimpleEnumSerializer('io.ktor.util.date.Month', values_0());
}
var Companion_instance_0;
function Companion_getInstance() {
  if (Companion_instance_0 === VOID)
    new Companion();
  return Companion_instance_0;
}
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance === VOID)
    new $serializer();
  return $serializer_instance;
}
var WeekDay_MONDAY_instance;
var WeekDay_TUESDAY_instance;
var WeekDay_WEDNESDAY_instance;
var WeekDay_THURSDAY_instance;
var WeekDay_FRIDAY_instance;
var WeekDay_SATURDAY_instance;
var WeekDay_SUNDAY_instance;
var Companion_instance_1;
function Companion_getInstance_0() {
  return Companion_instance_1;
}
function values() {
  return [WeekDay_MONDAY_getInstance(), WeekDay_TUESDAY_getInstance(), WeekDay_WEDNESDAY_getInstance(), WeekDay_THURSDAY_getInstance(), WeekDay_FRIDAY_getInstance(), WeekDay_SATURDAY_getInstance(), WeekDay_SUNDAY_getInstance()];
}
function get_entries() {
  if ($ENTRIES == null)
    $ENTRIES = enumEntries(values());
  return $ENTRIES;
}
var WeekDay_entriesInitialized;
function WeekDay_initEntries() {
  if (WeekDay_entriesInitialized)
    return Unit_instance;
  WeekDay_entriesInitialized = true;
  WeekDay_MONDAY_instance = new WeekDay('MONDAY', 0, 'Mon');
  WeekDay_TUESDAY_instance = new WeekDay('TUESDAY', 1, 'Tue');
  WeekDay_WEDNESDAY_instance = new WeekDay('WEDNESDAY', 2, 'Wed');
  WeekDay_THURSDAY_instance = new WeekDay('THURSDAY', 3, 'Thu');
  WeekDay_FRIDAY_instance = new WeekDay('FRIDAY', 4, 'Fri');
  WeekDay_SATURDAY_instance = new WeekDay('SATURDAY', 5, 'Sat');
  WeekDay_SUNDAY_instance = new WeekDay('SUNDAY', 6, 'Sun');
}
var $ENTRIES;
var Month_JANUARY_instance;
var Month_FEBRUARY_instance;
var Month_MARCH_instance;
var Month_APRIL_instance;
var Month_MAY_instance;
var Month_JUNE_instance;
var Month_JULY_instance;
var Month_AUGUST_instance;
var Month_SEPTEMBER_instance;
var Month_OCTOBER_instance;
var Month_NOVEMBER_instance;
var Month_DECEMBER_instance;
var Companion_instance_2;
function Companion_getInstance_1() {
  return Companion_instance_2;
}
function values_0() {
  return [Month_JANUARY_getInstance(), Month_FEBRUARY_getInstance(), Month_MARCH_getInstance(), Month_APRIL_getInstance(), Month_MAY_getInstance(), Month_JUNE_getInstance(), Month_JULY_getInstance(), Month_AUGUST_getInstance(), Month_SEPTEMBER_getInstance(), Month_OCTOBER_getInstance(), Month_NOVEMBER_getInstance(), Month_DECEMBER_getInstance()];
}
function get_entries_0() {
  if ($ENTRIES_0 == null)
    $ENTRIES_0 = enumEntries(values_0());
  return $ENTRIES_0;
}
var Month_entriesInitialized;
function Month_initEntries() {
  if (Month_entriesInitialized)
    return Unit_instance;
  Month_entriesInitialized = true;
  Month_JANUARY_instance = new Month('JANUARY', 0, 'Jan');
  Month_FEBRUARY_instance = new Month('FEBRUARY', 1, 'Feb');
  Month_MARCH_instance = new Month('MARCH', 2, 'Mar');
  Month_APRIL_instance = new Month('APRIL', 3, 'Apr');
  Month_MAY_instance = new Month('MAY', 4, 'May');
  Month_JUNE_instance = new Month('JUNE', 5, 'Jun');
  Month_JULY_instance = new Month('JULY', 6, 'Jul');
  Month_AUGUST_instance = new Month('AUGUST', 7, 'Aug');
  Month_SEPTEMBER_instance = new Month('SEPTEMBER', 8, 'Sep');
  Month_OCTOBER_instance = new Month('OCTOBER', 9, 'Oct');
  Month_NOVEMBER_instance = new Month('NOVEMBER', 10, 'Nov');
  Month_DECEMBER_instance = new Month('DECEMBER', 11, 'Dec');
}
var $ENTRIES_0;
function WeekDay_MONDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_MONDAY_instance;
}
function WeekDay_TUESDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_TUESDAY_instance;
}
function WeekDay_WEDNESDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_WEDNESDAY_instance;
}
function WeekDay_THURSDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_THURSDAY_instance;
}
function WeekDay_FRIDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_FRIDAY_instance;
}
function WeekDay_SATURDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_SATURDAY_instance;
}
function WeekDay_SUNDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_SUNDAY_instance;
}
function Month_JANUARY_getInstance() {
  Month_initEntries();
  return Month_JANUARY_instance;
}
function Month_FEBRUARY_getInstance() {
  Month_initEntries();
  return Month_FEBRUARY_instance;
}
function Month_MARCH_getInstance() {
  Month_initEntries();
  return Month_MARCH_instance;
}
function Month_APRIL_getInstance() {
  Month_initEntries();
  return Month_APRIL_instance;
}
function Month_MAY_getInstance() {
  Month_initEntries();
  return Month_MAY_instance;
}
function Month_JUNE_getInstance() {
  Month_initEntries();
  return Month_JUNE_instance;
}
function Month_JULY_getInstance() {
  Month_initEntries();
  return Month_JULY_instance;
}
function Month_AUGUST_getInstance() {
  Month_initEntries();
  return Month_AUGUST_instance;
}
function Month_SEPTEMBER_getInstance() {
  Month_initEntries();
  return Month_SEPTEMBER_instance;
}
function Month_OCTOBER_getInstance() {
  Month_initEntries();
  return Month_OCTOBER_instance;
}
function Month_NOVEMBER_getInstance() {
  Month_initEntries();
  return Month_NOVEMBER_instance;
}
function Month_DECEMBER_getInstance() {
  Month_initEntries();
  return Month_DECEMBER_instance;
}
var CONDITION_FALSE;
var ALREADY_REMOVED;
var LIST_EMPTY;
var REMOVE_PREPARED;
var NO_DECISION;
function unwrap(_this__u8e3s4) {
  _init_properties_LockFreeLinkedList_kt__wekxce();
  var tmp0_safe_receiver = _this__u8e3s4 instanceof Removed ? _this__u8e3s4 : null;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.a2j_1;
  var tmp;
  if (tmp1_elvis_lhs == null) {
    tmp = _this__u8e3s4 instanceof LockFreeLinkedListNode ? _this__u8e3s4 : THROW_CCE();
  } else {
    tmp = tmp1_elvis_lhs;
  }
  return tmp;
}
var properties_initialized_LockFreeLinkedList_kt_lnmdgw;
function _init_properties_LockFreeLinkedList_kt__wekxce() {
  if (!properties_initialized_LockFreeLinkedList_kt_lnmdgw) {
    properties_initialized_LockFreeLinkedList_kt_lnmdgw = true;
    CONDITION_FALSE = new Symbol('CONDITION_FALSE');
    ALREADY_REMOVED = new Symbol('ALREADY_REMOVED');
    LIST_EMPTY = new Symbol('LIST_EMPTY');
    REMOVE_PREPARED = new Symbol('REMOVE_PREPARED');
    NO_DECISION = new Symbol('NO_DECISION');
  }
}
function *_generator_proceedLoop__sfimma($this, $completion) {
  $l$loop_0: do {
    var index = $this.f2j_1;
    if (index === -1) {
      break $l$loop_0;
    }
    var interceptors = $this.c2j_1;
    if (index >= interceptors.b1()) {
      $this.g2j();
      break $l$loop_0;
    }
    var executeInterceptor = interceptors.f1(index);
    $this.f2j_1 = index + 1 | 0;
    var tmp = executeInterceptor($this, $this.e2j_1, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }
   while (true);
  return $this.e2j_1;
}
function proceedLoop($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_proceedLoop__sfimma.bind(VOID, $this), $completion);
}
function copiedInterceptors($this) {
  return toMutableList($this.n2j_1);
}
function copyInterceptors($this) {
  $this.n2j_1 = copiedInterceptors($this);
  $this.o2j_1 = false;
}
var Companion_instance_3;
function Companion_getInstance_2() {
  if (Companion_instance_3 === VOID)
    new Companion_2();
  return Companion_instance_3;
}
function _set_interceptors__wod97b($this, _set____db54di) {
  var tmp0 = $this.b2k_1;
  // Inline function 'kotlinx.atomicfu.AtomicRef.setValue' call
  interceptors$factory();
  tmp0.kotlinx$atomicfu$value = _set____db54di;
  return Unit_instance;
}
function _get_interceptors__h4min7($this) {
  var tmp0 = $this.b2k_1;
  // Inline function 'kotlinx.atomicfu.AtomicRef.getValue' call
  interceptors$factory_0();
  return tmp0.kotlinx$atomicfu$value;
}
function createContext($this, context, subject, coroutineContext) {
  return pipelineContextFor(context, sharedInterceptorsList($this), subject, coroutineContext, $this.e2k());
}
function findPhase($this, phase) {
  var phasesList = $this.z2j_1;
  var inductionVariable = 0;
  var last = phasesList.b1();
  if (inductionVariable < last)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var current = phasesList.f1(index);
      if (current === phase) {
        var content = PhaseContent.r2j(phase, Last_getInstance());
        phasesList.c3(index, content);
        return content;
      }
      var tmp;
      if (current instanceof PhaseContent) {
        tmp = current.l2j_1 === phase;
      } else {
        tmp = false;
      }
      if (tmp) {
        return current instanceof PhaseContent ? current : THROW_CCE();
      }
    }
     while (inductionVariable < last);
  return null;
}
function findPhaseIndex($this, phase) {
  var phasesList = $this.z2j_1;
  var inductionVariable = 0;
  var last = phasesList.b1();
  if (inductionVariable < last)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var current = phasesList.f1(index);
      var tmp;
      if (current === phase) {
        tmp = true;
      } else {
        var tmp_0;
        if (current instanceof PhaseContent) {
          tmp_0 = current.l2j_1 === phase;
        } else {
          tmp_0 = false;
        }
        tmp = tmp_0;
      }
      if (tmp) {
        return index;
      }
    }
     while (inductionVariable < last);
  return -1;
}
function hasPhase($this, phase) {
  var phasesList = $this.z2j_1;
  var inductionVariable = 0;
  var last = phasesList.b1();
  if (inductionVariable < last)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var current = phasesList.f1(index);
      var tmp;
      if (current === phase) {
        tmp = true;
      } else {
        var tmp_0;
        if (current instanceof PhaseContent) {
          tmp_0 = current.l2j_1 === phase;
        } else {
          tmp_0 = false;
        }
        tmp = tmp_0;
      }
      if (tmp) {
        return true;
      }
    }
     while (inductionVariable < last);
  return false;
}
function cacheInterceptors($this) {
  var interceptorsQuantity = $this.a2k_1;
  if (interceptorsQuantity === 0) {
    notSharedInterceptorsList($this, emptyList());
    return emptyList();
  }
  var phases = $this.z2j_1;
  if (interceptorsQuantity === 1) {
    var inductionVariable = 0;
    var last = get_lastIndex_0(phases);
    if (inductionVariable <= last)
      $l$loop_0: do {
        var phaseIndex = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = phases.f1(phaseIndex);
        var tmp0_elvis_lhs = tmp instanceof PhaseContent ? tmp : null;
        var tmp_0;
        if (tmp0_elvis_lhs == null) {
          continue $l$loop_0;
        } else {
          tmp_0 = tmp0_elvis_lhs;
        }
        var phaseContent = tmp_0;
        if (phaseContent.s2j())
          continue $l$loop_0;
        var interceptors = phaseContent.v2j();
        setInterceptorsListFromPhase($this, phaseContent);
        return interceptors;
      }
       while (!(phaseIndex === last));
  }
  // Inline function 'kotlin.collections.mutableListOf' call
  var destination = ArrayList.k();
  var inductionVariable_0 = 0;
  var last_0 = get_lastIndex_0(phases);
  if (inductionVariable_0 <= last_0)
    $l$loop_1: do {
      var phaseIndex_0 = inductionVariable_0;
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      var tmp_1 = phases.f1(phaseIndex_0);
      var tmp1_elvis_lhs = tmp_1 instanceof PhaseContent ? tmp_1 : null;
      var tmp_2;
      if (tmp1_elvis_lhs == null) {
        continue $l$loop_1;
      } else {
        tmp_2 = tmp1_elvis_lhs;
      }
      var phase = tmp_2;
      phase.u2j(destination);
    }
     while (!(phaseIndex_0 === last_0));
  notSharedInterceptorsList($this, destination);
  return destination;
}
function sharedInterceptorsList($this) {
  if (_get_interceptors__h4min7($this) == null) {
    cacheInterceptors($this);
  }
  $this.c2k_1 = true;
  return ensureNotNull(_get_interceptors__h4min7($this));
}
function resetInterceptorsList($this) {
  _set_interceptors__wod97b($this, null);
  $this.c2k_1 = false;
  $this.d2k_1 = null;
}
function notSharedInterceptorsList($this, list) {
  _set_interceptors__wod97b($this, list);
  $this.c2k_1 = false;
  $this.d2k_1 = null;
}
function setInterceptorsListFromPhase($this, phaseContent) {
  _set_interceptors__wod97b($this, phaseContent.v2j());
  $this.c2k_1 = false;
  $this.d2k_1 = phaseContent.l2j_1;
}
function tryAddToPhaseFastPath($this, phase, block) {
  var currentInterceptors = _get_interceptors__h4min7($this);
  if ($this.z2j_1.h1() || currentInterceptors == null) {
    return false;
  }
  var tmp;
  if ($this.c2k_1) {
    tmp = true;
  } else {
    tmp = !(!(currentInterceptors == null) ? isInterface(currentInterceptors, KtMutableList) : false);
  }
  if (tmp) {
    return false;
  }
  if (equals($this.d2k_1, phase)) {
    currentInterceptors.l(block);
    return true;
  }
  if (equals(phase, last($this.z2j_1)) || findPhaseIndex($this, phase) === get_lastIndex_0($this.z2j_1)) {
    ensureNotNull(findPhase($this, phase)).t2j(block);
    currentInterceptors.l(block);
    return true;
  }
  return false;
}
function interceptors$factory() {
  return getPropertyCallableRef('interceptors', 1, KMutableProperty1, (receiver) => _get_interceptors__h4min7(receiver), (receiver, value) => _set_interceptors__wod97b(receiver, value));
}
function interceptors$factory_0() {
  return getPropertyCallableRef('interceptors', 1, KMutableProperty1, (receiver) => _get_interceptors__h4min7(receiver), (receiver, value) => _set_interceptors__wod97b(receiver, value));
}
function pipelineContextFor(context, interceptors, subject, coroutineContext, debugMode) {
  debugMode = debugMode === VOID ? false : debugMode;
  var tmp;
  if (get_DISABLE_SFG() || debugMode) {
    tmp = new DebugPipelineContext(context, interceptors, subject, coroutineContext);
  } else {
    tmp = new SuspendFunctionGun(subject, context, interceptors);
  }
  return tmp;
}
var Last_instance;
function Last_getInstance() {
  if (Last_instance === VOID)
    new Last();
  return Last_instance;
}
function recoverStackTraceBridge(exception, continuation) {
  var tmp;
  try {
    tmp = withCause(recoverStackTrace(exception, continuation), exception.cause);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var _unused_var__etf5q3 = $p;
      tmp_0 = exception;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function loop($this, direct) {
  do {
    var currentIndex = $this.v2k_1;
    if (currentIndex === $this.q2k_1.b1()) {
      if (!direct) {
        // Inline function 'kotlin.Companion.success' call
        var value = $this.s2k_1;
        var tmp$ret$0 = _Result___init__impl__xyqfz8(value);
        resumeRootWith($this, tmp$ret$0);
        return false;
      }
      return true;
    }
    $this.v2k_1 = currentIndex + 1 | 0;
    var next = $this.q2k_1.f1(currentIndex);
    try {
      var result = pipelineStartCoroutineUninterceptedOrReturn(next, $this, $this.s2k_1, $this.r2k_1);
      if (result === get_COROUTINE_SUSPENDED())
        return false;
    } catch ($p) {
      if ($p instanceof Error) {
        var cause = $p;
        // Inline function 'kotlin.Companion.failure' call
        var tmp$ret$1 = _Result___init__impl__xyqfz8(createFailure(cause));
        resumeRootWith($this, tmp$ret$1);
        return false;
      } else {
        throw $p;
      }
    }
  }
   while (true);
}
function resumeRootWith($this, result) {
  if ($this.u2k_1 < 0) {
    // Inline function 'kotlin.error' call
    var message = 'No more continuations to resume';
    throw IllegalStateException.t4(toString(message));
  }
  var next = ensureNotNull($this.t2k_1[$this.u2k_1]);
  var _unary__edvuaz = $this.u2k_1;
  $this.u2k_1 = _unary__edvuaz - 1 | 0;
  $this.t2k_1[_unary__edvuaz] = null;
  if (!_Result___get_isFailure__impl__jpiriv(result)) {
    next.nc(result);
  } else {
    var exception = recoverStackTraceBridge(ensureNotNull(Result__exceptionOrNull_impl_p6xea9(result)), next);
    // Inline function 'kotlin.coroutines.resumeWithException' call
    // Inline function 'kotlin.Companion.failure' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception));
    next.nc(tmp$ret$0);
  }
}
function discardLastRootContinuation($this) {
  if ($this.u2k_1 < 0)
    throw IllegalStateException.t4('No more continuations to resume');
  var _unary__edvuaz = $this.u2k_1;
  $this.u2k_1 = _unary__edvuaz - 1 | 0;
  $this.t2k_1[_unary__edvuaz] = null;
}
function get_platform(_this__u8e3s4) {
  _init_properties_PlatformUtils_js_kt__7rxm8p();
  var tmp0 = platform$delegate;
  // Inline function 'kotlin.getValue' call
  platform$factory();
  return tmp0.n1();
}
var platform$delegate;
function platform$delegate$lambda() {
  _init_properties_PlatformUtils_js_kt__7rxm8p();
  return new Js(hasNodeApi() ? JsPlatform_Node_getInstance() : JsPlatform_Browser_getInstance());
}
function platform$factory() {
  return getPropertyCallableRef('platform', 1, KProperty1, (receiver) => get_platform(receiver), null);
}
var properties_initialized_PlatformUtils_js_kt_8g036j;
function _init_properties_PlatformUtils_js_kt__7rxm8p() {
  if (!properties_initialized_PlatformUtils_js_kt_8g036j) {
    properties_initialized_PlatformUtils_js_kt_8g036j = true;
    platform$delegate = lazy_0(platform$delegate$lambda);
  }
}
function GMTDate_0(timestamp) {
  timestamp = timestamp === VOID ? null : timestamp;
  var tmp1_safe_receiver = timestamp == null ? null : timestamp.m4();
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = new Date(tmp1_safe_receiver);
  }
  var tmp2_elvis_lhs = tmp;
  var date = tmp2_elvis_lhs == null ? new Date() : tmp2_elvis_lhs;
  if (isNaN_0(date.getTime()))
    throw InvalidTimestampException.f2l(ensureNotNull(timestamp));
  // Inline function 'kotlin.with' call
  var dayOfWeek = Companion_instance_1.p2i((date.getUTCDay() + 6 | 0) % 7 | 0);
  var month = Companion_instance_2.p2i(date.getUTCMonth());
  return new GMTDate(date.getUTCSeconds(), date.getUTCMinutes(), date.getUTCHours(), dayOfWeek, date.getUTCDate(), date.getUTCFullYear(), month, date.getUTCFullYear(), numberToLong(date.getTime()));
}
function pipelineStartCoroutineUninterceptedOrReturn(interceptor, context, subject, continuation) {
  return (typeof interceptor === 'function' ? interceptor : THROW_CCE())(context, subject, continuation);
}
function AttributesJsFn(concurrent) {
  concurrent = concurrent === VOID ? false : concurrent;
  return new AttributesJs();
}
function unmodifiable(_this__u8e3s4) {
  return _this__u8e3s4;
}
function hasNodeApi() {
  return typeof process !== 'undefined' && process.versions != null && process.versions.node != null || (typeof window !== 'undefined' && typeof window.process !== 'undefined' && window.process.versions != null && window.process.versions.node != null);
}
function get_isDevelopmentMode(_this__u8e3s4) {
  return false;
}
function KtorSimpleLogger(name) {
  return new KtorSimpleLogger$1();
}
function getKtorLogLevel() {
  return process ? process.env.KTOR_LOG_LEVEL : null;
}
var LogLevel_TRACE_instance;
var LogLevel_DEBUG_instance;
var LogLevel_INFO_instance;
var LogLevel_WARN_instance;
var LogLevel_ERROR_instance;
var LogLevel_NONE_instance;
function values_1() {
  return [LogLevel_TRACE_getInstance(), LogLevel_DEBUG_getInstance(), LogLevel_INFO_getInstance(), LogLevel_WARN_getInstance(), LogLevel_ERROR_getInstance(), LogLevel_NONE_getInstance()];
}
function get_entries_1() {
  if ($ENTRIES_1 == null)
    $ENTRIES_1 = enumEntries(values_1());
  return $ENTRIES_1;
}
var LogLevel_entriesInitialized;
function LogLevel_initEntries() {
  if (LogLevel_entriesInitialized)
    return Unit_instance;
  LogLevel_entriesInitialized = true;
  LogLevel_TRACE_instance = new LogLevel('TRACE', 0);
  LogLevel_DEBUG_instance = new LogLevel('DEBUG', 1);
  LogLevel_INFO_instance = new LogLevel('INFO', 2);
  LogLevel_WARN_instance = new LogLevel('WARN', 3);
  LogLevel_ERROR_instance = new LogLevel('ERROR', 4);
  LogLevel_NONE_instance = new LogLevel('NONE', 5);
}
var $ENTRIES_1;
function get_isTraceEnabled(_this__u8e3s4) {
  return _this__u8e3s4.i2l().p3(LogLevel_TRACE_getInstance()) <= 0;
}
function LogLevel_TRACE_getInstance() {
  LogLevel_initEntries();
  return LogLevel_TRACE_instance;
}
function LogLevel_DEBUG_getInstance() {
  LogLevel_initEntries();
  return LogLevel_DEBUG_instance;
}
function LogLevel_INFO_getInstance() {
  LogLevel_initEntries();
  return LogLevel_INFO_instance;
}
function LogLevel_WARN_getInstance() {
  LogLevel_initEntries();
  return LogLevel_WARN_instance;
}
function LogLevel_ERROR_getInstance() {
  LogLevel_initEntries();
  return LogLevel_ERROR_instance;
}
function LogLevel_NONE_getInstance() {
  LogLevel_initEntries();
  return LogLevel_NONE_instance;
}
function get_DISABLE_SFG() {
  return DISABLE_SFG;
}
var DISABLE_SFG;
function withCause(_this__u8e3s4, cause) {
  return _this__u8e3s4;
}
function instanceOf(_this__u8e3s4, type) {
  return type.if(_this__u8e3s4);
}
//region block: post-declaration
initMetadataForClass(AttributeKey, 'AttributeKey');
initMetadataForInterface(Attributes, 'Attributes');
initMetadataForClass(CaseInsensitiveMap, 'CaseInsensitiveMap', CaseInsensitiveMap, VOID, [KtMutableMap]);
initMetadataForClass(Entry_0, 'Entry', VOID, VOID, [Entry]);
initMetadataForClass(SilentSupervisor$$inlined$CoroutineExceptionHandler$1, VOID, VOID, VOID, [AbstractCoroutineContextElement, Element]);
initMetadataForClass(DelegatingMutableSet$iterator$1);
initMetadataForClass(DelegatingMutableSet, 'DelegatingMutableSet', VOID, VOID, [KtMutableSet]);
initMetadataForClass(Platform, 'Platform');
initMetadataForObject(Jvm, 'Jvm');
initMetadataForObject(Native, 'Native');
initMetadataForClass(Js, 'Js');
initMetadataForClass(WasmJs, 'WasmJs');
initMetadataForClass(JsPlatform, 'JsPlatform');
initMetadataForObject(PlatformUtils, 'PlatformUtils');
initMetadataForInterface(StringValues, 'StringValues');
initMetadataForClass(StringValuesBuilderImpl, 'StringValuesBuilderImpl', StringValuesBuilderImpl);
initMetadataForClass(StringValuesImpl, 'StringValuesImpl', StringValuesImpl, VOID, [StringValues]);
initMetadataForClass(StringValuesSingleImpl$entries$1, VOID, VOID, VOID, [Entry]);
initMetadataForClass(StringValuesSingleImpl, 'StringValuesSingleImpl', VOID, VOID, [StringValues]);
initMetadataForClass(CaseInsensitiveString, 'CaseInsensitiveString');
initMetadataForClass(CopyOnWriteHashMap, 'CopyOnWriteHashMap', CopyOnWriteHashMap);
initMetadataForCompanion(Companion);
protoOf($serializer).v25 = typeParametersSerializers;
initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(GMTDate, 'GMTDate', VOID, VOID, [Comparable], VOID, VOID, {0: $serializer_getInstance});
initMetadataForCompanion(Companion_0);
initMetadataForClass(WeekDay, 'WeekDay');
initMetadataForCompanion(Companion_1);
initMetadataForClass(Month, 'Month');
initMetadataForClass(Symbol, 'Symbol');
initMetadataForClass(LockFreeLinkedListNode, 'LockFreeLinkedListNode');
initMetadataForClass(Removed, 'Removed');
initMetadataForClass(OpDescriptor, 'OpDescriptor');
initMetadataForClass(PipelineContext, 'PipelineContext', VOID, VOID, [CoroutineScope], [1, 0]);
initMetadataForClass(DebugPipelineContext, 'DebugPipelineContext', VOID, VOID, VOID, [1, 0]);
initMetadataForCompanion(Companion_2);
initMetadataForClass(PhaseContent, 'PhaseContent');
initMetadataForClass(Pipeline, 'Pipeline', VOID, VOID, VOID, [2]);
initMetadataForClass(PipelinePhase, 'PipelinePhase');
initMetadataForClass(InvalidPhaseException, 'InvalidPhaseException');
initMetadataForClass(PipelinePhaseRelation, 'PipelinePhaseRelation');
initMetadataForClass(After, 'After');
initMetadataForClass(Before, 'Before');
initMetadataForObject(Last, 'Last');
initMetadataForClass(SuspendFunctionGun$continuation$1, VOID, VOID, VOID, [Continuation]);
initMetadataForClass(SuspendFunctionGun, 'SuspendFunctionGun', VOID, VOID, VOID, [0, 1]);
initMetadataForClass(TypeInfo, 'TypeInfo');
initMetadataForClass(InvalidTimestampException, 'InvalidTimestampException');
protoOf(AttributesJs).l2f = get;
initMetadataForClass(AttributesJs, 'AttributesJs', AttributesJs, VOID, [Attributes]);
initMetadataForClass(KtorSimpleLogger$1);
initMetadataForClass(LogLevel, 'LogLevel');
//endregion
//region block: init
Companion_instance_1 = new Companion_0();
Companion_instance_2 = new Companion_1();
DISABLE_SFG = false;
//endregion
//region block: exports
export {
  PlatformUtils_getInstance as PlatformUtils_getInstance3trl22jwg7wgb,
  CopyOnWriteHashMap as CopyOnWriteHashMap2wz01l72sexe7,
  GMTDate_0 as GMTDate36bhedawynxlf,
  LockFreeLinkedListNode as LockFreeLinkedListNode1f5fxflchw0ko,
  KtorSimpleLogger as KtorSimpleLogger1xdphsp5l4e48,
  get_isTraceEnabled as get_isTraceEnabled82xibuu04nxp,
  PipelineContext as PipelineContext34fsb0mycu471,
  PipelinePhase as PipelinePhase2q3d54imxjlma,
  Pipeline as Pipeline2vw6c5wpzxajt,
  TypeInfo as TypeInfo2nbxsuf4v8os2,
  instanceOf as instanceOf2cx3k00nj6a0p,
  AttributeKey as AttributeKey3aq8ytwgx54f7,
  AttributesJsFn as AttributesJsFn25rjfgcprgprf,
  Attributes as Attributes2dg90yv0ot9wx,
  SilentSupervisor as SilentSupervisorlzoikirj0zeo,
  forEach as forEachghjt92rkrpzo,
  get_0 as get3oezx9z3zutmm,
  StringValuesBuilderImpl as StringValuesBuilderImpl3ey9etj3bwnqf,
  StringValuesImpl as StringValuesImpl2l95y9du7b61t,
  StringValuesSingleImpl as StringValuesSingleImpl1uh7q2c2zm7va,
  StringValues as StringValuesjqid5a6cuday,
  appendAll as appendAlltwnjnu28pmtx,
  isLowerCase as isLowerCase2jodys5jo7d58,
  putAll as putAll10o0q8e6mgnzr,
  toCharArray as toCharArray1qby3f4cdahde,
  toLowerCasePreservingASCIIRules as toLowerCasePreservingASCIIRulesa2d90zyoc6kw,
};
//endregion

//# sourceMappingURL=ktor-ktor-utils.mjs.map
