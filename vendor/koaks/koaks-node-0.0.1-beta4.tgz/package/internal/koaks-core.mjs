import {
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  Unit_instance104q5opgivhr8 as Unit_instance,
  ArrayList3it5z8td81qkl as ArrayList,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  plus20p0vtfmu0596 as plus,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  VOID7hggqo3abtya as VOID,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isInterface3d6p8outrmvmk as isInterface,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  equals2au1ep9vhcato as equals,
  AutoCloseable1l5p57f9lp7kv as AutoCloseable,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  Long2qws0ah9gnpki as Long,
  toLongw1zpgk99d84b as toLong,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString,
  toList3jhuyej2anx2q as toList,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  AbstractCoroutineContextElement2rpehg0hv5szw as AbstractCoroutineContextElement,
  isBlank1dvkhjjvox3p0 as isBlank,
  emptyList1g2z5xcrvp2zy as emptyList,
  CancellationException3b36o9qz53rgr as CancellationException,
  protoOf180f3jzyo7rfj as protoOf,
  take3onnpy6q7ctcz as take,
  asReversed308kw52j6ls1u as asReversed,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  checkIndexOverflow3frtmheghr0th as checkIndexOverflow,
  Companion_getInstance2b73c6hwbaiuw as Companion_getInstance,
  DurationUnit_MILLISECONDS_getInstance1vv9i8zf23p5u as DurationUnit_MILLISECONDS_getInstance,
  toDurationba1nlt78o6vu as toDuration,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  takeLasttm5u17ojwaaq as takeLast,
  listOfNotNull1v4ggfackvuny as listOfNotNull,
  plus310ted5e4i90h as plus_0,
  setOfNotNull1ug1800sfjuu0 as setOfNotNull,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  setOf45ia9pnfhe90 as setOf,
  toMutableList20rdgwi7d3cwi as toMutableList,
  toString30pk9tzaqopn as toString_0,
  joinToString1cxrrlmo0chqs as joinToString,
  listOfvhqybd2zx248 as listOf,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  Exceptiondt2hlxn7j7vw as Exception,
  captureStack1fzi4aczwc4hg as captureStack,
  createThis2j2avj17cvnv2 as createThis,
  singleOrNullrknfaxokm1sl as singleOrNull,
  StringBuildermazzzhj6kkai as StringBuilder,
  HashSet2dzve9y63nf0v as HashSet,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  removeAll3o43e67jmwdpc as removeAll,
  drop3na99dw9feawf as drop,
  PrimitiveClasses_getInstance28ukyr6i8fs0q as PrimitiveClasses_getInstance,
  arrayOf1akklvh2at202 as arrayOf,
  createKType1lgox3mzhchp5 as createKType,
  emptyMapr06gerzljqtm as emptyMap,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  RuntimeException1r3t0zl97011n as RuntimeException,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  Enum3alwj03lh1n41 as Enum,
  Collection1k04j3hzsbod0 as Collection,
  toHashSet1qrcsl3g8ugc8 as toHashSet,
  last1vo29oleiqj36 as last,
  mutableListOf6oorvk2mtdmp as mutableListOf,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  ArrayDeque2dzc9uld4xi7n as ArrayDeque,
  flatten2dh4kibw1u0qq as flatten,
  get_lastIndex1yw0x4k50k51w as get_lastIndex,
  first58ocm7j58k3q as first,
  setPropertiesToThrowableInstance1w2jjvl9y77yc as setPropertiesToThrowableInstance,
  Default_getInstance324kkay623mzd as Default_getInstance,
  _ULong___init__impl__c78o9k2uqxdjm6b0lbg as _ULong___init__impl__c78o9k,
  toString1ced4mxyj2b43 as toString_1,
  THROW_IAE23kobfj9wdoxr as THROW_IAE,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  Result3t1vadv16kmzk as Result,
  _Result___get_isSuccess__impl__sndoy82z6txcyihce8z as _Result___get_isSuccess__impl__sndoy8,
  to2cs3ny02qtbcb as to,
  lineSequencefj20mplblw0p as lineSequence,
  removePrefix279df90bhrqqg as removePrefix,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  startsWith1bgirhbedtv2y as startsWith,
  indexOf1xbs558u7wr52 as indexOf,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  trimEndvvzjdhan75g as trimEnd,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  getOrNull1go7ef9ldk0df as getOrNull,
  isLowSurrogateujxcv7hjn4ma as isLowSurrogate,
  isHighSurrogate11jfjw70ar0zf as isHighSurrogate,
  Char19o2r8palgjof as Char,
  replace3le3ie7l9k8aq as replace,
  replaceqbix900hl8kl as replace_0,
  toMap1vec9topfei08 as toMap,
  Regexxgw0gjiagf4z as Regex,
  singleo93pzdgfc557 as single,
  sortedWith2csnbbb21k0lg as sortedWith,
  addAll1k27qatfgp3k5 as addAll,
  Comparator2b3maoeh98xtg as Comparator,
  compareValues1n2ayl87ihzfk as compareValues,
  trimEnd17pt8cbotbalj as trimEnd_0,
  toMutableSetjdpdbr9jsqq8 as toMutableSet,
  KtMap140uvy3s5zad8 as KtMap,
  setOf1u3mizs95ngxo as setOf_0,
  firstOrNull1982767dljvdy as firstOrNull,
  substringAfterLast3r0t0my8cpqhk as substringAfterLast,
  substringBefore3n7kj60w69hju as substringBefore,
  trimStart5ewg8zf6cs5u as trimStart,
  startsWith26w8qjqapeeq6 as startsWith_0,
  numberToLong1a4cndvg6c52s as numberToLong,
  coerceAtLeast3qxv4gros2xti as coerceAtLeast_0,
  ValueTimeMark__elapsedNow_impl_eonqvsu7rzs9skj3fu as ValueTimeMark__elapsedNow_impl_eonqvs,
  _Duration___get_inWholeMilliseconds__impl__msfiryzor4f65wcski as _Duration___get_inWholeMilliseconds__impl__msfiry,
  coerceAtMostfyc3emgaderp as coerceAtMost,
  Monotonic_instance19wu6xfdyzm85 as Monotonic_instance,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  getValue48kllevslyh6 as getValue,
  plus2lr02ok6jhhxu as plus_1,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  minus1f3bieyodk5vw as minus,
  checkCountOverflow1ro2fe1r4xvgf as checkCountOverflow,
  minus3k3m1sk1cdx2b as minus_0,
  minus1djrl64vbav3y as minus_1,
  asSequence2phdjljfh9jhx as asSequence,
  filter184huxd00uyfg as filter,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  reversenv3adafjrtzo as reverse,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  ValueTimeMark3e7hmed1q029a as ValueTimeMark,
  HashMap1a0ld5kgwhmhv as HashMap,
  minWithOrNull30i4uakvje35v as minWithOrNull,
  toSet2orjxp16sotqu as toSet,
  plus18eogev54fmsa as plus_2,
  isNumberiramasdbon0i as isNumber,
  isArray1hxjqtqy632bc as isArray,
} from './kotlin-kotlin-stdlib.mjs';
import {
  emitAllzzmeew3d68ub as emitAll,
  FlowCollector26clgpmzihvke as FlowCollector,
  flow3tazazxj2t7g4 as flow,
  MutableStateFlow34bfoyvwu8czu as MutableStateFlow,
  Mutex16li1l0asjv17 as Mutex,
  asyncz02dsa2nb2zt as async,
  awaitAlls867ch610czr as awaitAll,
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
  delay1gna29w5m8r2h as delay,
  coroutineScope327xjtgzh1k2v as coroutineScope,
  ProducerScopeb3mmhvfa6ll7 as ProducerScope,
  channelFlow1or0c85tk04v1 as channelFlow,
  Flow3375h4584bu3w as Flow,
  first1bt0pe0qnx8f4 as first_0,
  TimeoutCancellationException198b5zwr3v3uw as TimeoutCancellationException,
  withTimeoutOrNull30gvkflmp8gj3 as withTimeoutOrNull,
  CompletableDeferred2lnqvsbvx74d3 as CompletableDeferred,
  launch1c91vkjzdi9sd as launch,
  NonCancellable_getInstance1ugmverrxjd6t as NonCancellable_getInstance,
  withContext7utithjmd2zo as withContext,
  withTimeoutma886m9gez3y as withTimeout,
  ensureActive2yo7199srjlgl as ensureActive,
  SupervisorJobythnfxkr3jxc as SupervisorJob,
  CoroutineName2g5zosw74tf0f as CoroutineName,
  CoroutineScopelux7s7zphw7e as CoroutineScope_0,
  MutableSharedFlow3g4w4npzofx4w as MutableSharedFlow,
  asSharedFlow2buz3fbrowsyg as asSharedFlow,
  Dispatchers_getInstance1nk2l7rcqz5wi as Dispatchers_getInstance,
  asStateFlow34rribx643ke5 as asStateFlow,
  firstm7c7rh2w8aro as first_1,
  delay1mo3xq8p6x68f as delay_0,
  Channel3r72atmcithql as Channel,
  get_isActive3hyjjajobpa4m as get_isActive,
  await3mtczq8ld88gb as await_0,
} from './kotlinx-coroutines-core.mjs';
import { KotlinLogging_instance20u19uwz7rzsk as KotlinLogging_instance } from './kotlin-logging.mjs';
import {
  serializer1hwzc6m64v1op as serializer,
  KSerializerzf77vz1967fq as KSerializer,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  UnknownFieldExceptiona60e3a6v1xqo as UnknownFieldException,
  StringSerializer_getInstance1k1oz5j50sfik as StringSerializer_getInstance,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
  BooleanSerializer_getInstancet3wtk7fl7i4f as BooleanSerializer_getInstance,
  IntSerializer_getInstance9scrtcljaiv6 as IntSerializer_getInstance,
  get_nullable197rfua9r7fsz as get_nullable,
  ArrayListSerializer7k5wnrulb3y6 as ArrayListSerializer,
  SerializerFactory1qv9hivitncuv as SerializerFactory,
  InlineClassDescriptor2odlvyasjrmr0 as InlineClassDescriptor,
  createSimpleEnumSerializer2guioz11kk1m0 as createSimpleEnumSerializer,
  ENUM_getInstance3doea03ve3rgg as ENUM_getInstance,
  SEALED_getInstance15u0wl5f5h4qk as SEALED_getInstance,
  OPEN_getInstance1ppfglhtdde20 as OPEN_getInstance,
  CLASS_getInstance1ss90e870vddp as CLASS_getInstance,
  OBJECT_getInstancee89a3hlgr5ys as OBJECT_getInstance,
  MAP_getInstance2l4ulrz8ljw5i as MAP_getInstance,
  LIST_getInstance3iji3zetpdcxm as LIST_getInstance,
  PrimitiveKindndgbuh6is7ze as PrimitiveKind,
  FLOAT_getInstance1j10ivnvurzks as FLOAT_getInstance,
  DOUBLE_getInstance3nog56dy847km as DOUBLE_getInstance,
  BYTE_getInstance3l0en7kumss35 as BYTE_getInstance,
  SHORT_getInstance34lbpnul1ebqc as SHORT_getInstance,
  INT_getInstance3cjna3yzozsnp as INT_getInstance,
  LONG_getInstance3ud8vh8r2ot7x as LONG_getInstance,
  BOOLEAN_getInstance1s8i8e2xmvmon as BOOLEAN_getInstance,
  STRING_getInstance2gbamclnmtzqa as STRING_getInstance,
  CHAR_getInstance136x8e9sqt1t7 as CHAR_getInstance,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  JsonObjectee06ihoeeiqj as JsonObject,
  Companion_instance20spzcd6u6icp as Companion_instance_0,
  Jsonsmkyu9xjl7fv as Json,
  JsonObjectSerializer_getInstance197qdg6ernwdp as JsonObjectSerializer_getInstance,
  JsonElementSerializer_getInstance1rgo1giz8g15y as JsonElementSerializer_getInstance,
  JsonObjectBuilder2nl6rv6vdayuk as JsonObjectBuilder,
  JsonPrimitiveolttw629wj53 as JsonPrimitive,
  JsonArrayBuilderu8edol6ui3pj as JsonArrayBuilder,
  JsonArray2urf8ey7u44sd as JsonArray,
  JsonPrimitive3ttzjh2ft5dnx as JsonPrimitive_0,
} from './kotlinx-serialization-kotlinx-serialization-json.mjs';
import { System_instance3bcuv0kn0rmcj as System_instance } from './Kotlin-DateTime-library-kotlinx-datetime.mjs';
import {
  Buffer3384y49aj0pxr as Buffer,
  Companion_getInstance3n3majy04gpy as Companion_getInstance_0,
  Companion_getInstancexulw4ei34734 as Companion_getInstance_1,
} from './okio-parent-okio.mjs';
import {
  HttpRequestBuilder15f2nnx9sjuv1 as HttpRequestBuilder,
  HttpStatement3zxb33q8lku as HttpStatement,
  bodyAsText3vst3l5mns5py as bodyAsText,
  SocketTimeoutException2zstjwq2yf3s9 as SocketTimeoutException,
  accept2gi3b7wj4jds9 as accept,
  header3kx6g3yb4df1r as header,
  get_HttpTimeout3mcrbvfnvmyx2 as get_HttpTimeout,
  defaultRequest2ux1d5xxixv6z as defaultRequest,
  HttpClient2x7qc5z8fmeal as HttpClient,
  bodyAsChannelnoof5wjyzubm as bodyAsChannel,
  url2l6iw5ri21nxb as url,
  timeout39ggydbhmf7b9 as timeout,
  HttpResponse1532ob1hsse1y as HttpResponse,
  Js_instance3bkccyof8y1tc as Js_instance,
} from './ktor-ktor-client-core.mjs';
import {
  Companion_getInstancepumzx9q4106p as Companion_getInstance_2,
  OutgoingContent3t2ohmyam9o76 as OutgoingContent,
  NullBody_instance9oj4j8z4op1j as NullBody_instance,
  Application_getInstance1d4ly18wdhadx as Application_getInstance,
  contentType1lwcfjsjo0z8g as contentType,
  HttpHeaders_getInstancekqele34vb34f as HttpHeaders_getInstance,
  contentType317fn4f991q9a as contentType_0,
  isSuccess1pokn37fdu56v as isSuccess,
  Companion_getInstance2t5xhismubxj4 as Companion_getInstance_3,
} from './ktor-ktor-http.mjs';
import { TypeInfo2nbxsuf4v8os2 as TypeInfo } from './ktor-ktor-utils.mjs';
import { IOException1wyutdmfe71nu as IOException } from './kotlinx-io-kotlinx-io-core.mjs';
import {
  Companion_getInstance3kevo0bkbnsry as Companion_getInstance_4,
  YamlMapg7x473jl53e as YamlMap,
  YamlScalar1ksv41lpvdq25 as YamlScalar,
} from './kaml.mjs';
import { readUTF8Line221we5la1oywq as readUTF8Line } from './ktor-ktor-io.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class Agent$executeStream$slambda {
  constructor(this$0, $input, $context, $turn, $checkpoint) {
    this.b5n_1 = this$0;
    this.c5n_1 = $input;
    this.d5n_1 = $context;
    this.e5n_1 = $turn;
    this.f5n_1 = $checkpoint;
  }
  m5o($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.m5o((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class Agent$executeStructuredStream$slambda {
  constructor(this$0, $input, $context, $spec, $turn, $checkpoint) {
    this.s5n_1 = this$0;
    this.t5n_1 = $input;
    this.u5n_1 = $context;
    this.v5n_1 = $spec;
    this.w5n_1 = $turn;
    this.x5n_1 = $checkpoint;
  }
  m5o($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_0.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.m5o((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class Agent {
  constructor(id, name, instructions, model, tools, hooks, listeners, termination, suspendTermination, errorPolicy, suspendErrorPolicy, runBudget, preparation, memoryProvider, clientActionHandlers, transport, ownsTransport) {
    this.i5m_1 = id;
    this.j5m_1 = name;
    this.k5m_1 = instructions;
    this.l5m_1 = model;
    this.m5m_1 = tools;
    this.n5m_1 = hooks;
    this.o5m_1 = listeners;
    this.p5m_1 = termination;
    this.q5m_1 = suspendTermination;
    this.r5m_1 = errorPolicy;
    this.s5m_1 = suspendErrorPolicy;
    this.t5m_1 = runBudget;
    this.u5m_1 = preparation;
    this.v5m_1 = memoryProvider;
    this.w5m_1 = clientActionHandlers;
    this.x5m_1 = transport;
    this.y5m_1 = ownsTransport;
    this.z5m_1 = AgentDefinitionIds_getInstance().a1();
    this.a5n_1 = new AgentRunner(this);
  }
  o5o($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_prepare__2w4w0d.bind(VOID, this), $completion);
  }
  p5o(input, context, turn, checkpoint) {
    return flow(Agent$executeStream$slambda_0(this, input, context, turn, checkpoint));
  }
  q5o(input, context, spec, turn, checkpoint) {
    return flow(Agent$executeStructuredStream$slambda_0(this, input, context, spec, turn, checkpoint));
  }
  r5o(state, idempotencyKey, outputFormat) {
    if (equals(outputFormat, JsonObject_instance)) {
      rejectIfUnsupported(this.l5m_1.l5o(), 'json object', this.l5m_1.l5o().i5o_1, 'outputFormat');
    } else {
      if (outputFormat instanceof JsonSchema) {
        rejectIfUnsupported(this.l5m_1.l5o(), 'json schema', this.l5m_1.l5o().j5o_1, 'outputFormat');
      } else {
        if (!equals(outputFormat, Text_instance)) {
          noWhenBranchMatchedException();
        }
      }
    }
    return new ModelRequest(state.t5o_1, state.s5o_1, this.m5m_1.d5p(), outputFormat, state.u5o_1, idempotencyKey);
  }
  a6() {
    if (this.y5m_1) {
      var tmp0_safe_receiver = this.x5m_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        tmp0_safe_receiver.a6();
      }
    }
  }
}
class AgentDefinitionIds {
  constructor() {
    AgentDefinitionIds_instance = this;
    this.n5o_1 = MutableStateFlow(new Long(0, 0));
  }
  a1() {
    var tmp0 = this.n5o_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.getAndUpdate' call
      while (true) {
        var prevValue = tmp0.n1();
        // Inline function 'kotlin.Long.plus' call
        var nextValue = prevValue.u3(toLong(1));
        if (tmp0.u1e(prevValue, nextValue)) {
          tmp$ret$2 = prevValue;
          break $l$block;
        }
      }
    }
    return tmp$ret$2;
  }
}
class AgentBuilder {
  constructor() {
    this.e5p_1 = null;
    this.f5p_1 = 'agent';
    this.g5p_1 = null;
    this.h5p_1 = null;
    this.i5p_1 = null;
    this.j5p_1 = null;
    this.k5p_1 = new ToolRegistry();
    this.l5p_1 = null;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.m5p_1 = ArrayList.k();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.n5p_1 = ArrayList.k();
    this.o5p_1 = Companion_instance_42.w5p(2147483647);
    this.p5p_1 = null;
    this.q5p_1 = Companion_getInstance_44().x5p_1;
    this.r5p_1 = null;
    this.s5p_1 = null;
    this.t5p_1 = Companion_getInstance_45().y5p_1;
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_1.u5p_1 = ArrayList.k();
  }
  z5p(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new InstructionsScope();
    block(this_0);
    tmp.h5p_1 = this_0.v5p();
  }
  b5q(block) {
    var scope = new ModelScope();
    this.j5p_1 = block(scope);
    this.i5p_1 = scope;
  }
  c5q(block) {
    // Inline function 'kotlin.apply' call
    block(new ToolScope(this.k5p_1));
  }
  d5q(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new SkillsScope();
    block(this_0);
    tmp.l5p_1 = this_0.v5p();
  }
  g5q(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new MemoryScope();
    block(this_0);
    tmp.s5p_1 = this_0.v5p();
  }
  i5q(hook) {
    // Inline function 'kotlin.collections.plusAssign' call
    this.m5p_1.l(hook);
  }
  j5q(listener) {
    // Inline function 'kotlin.collections.plusAssign' call
    this.n5p_1.l(listener);
  }
  k5q(policy) {
    this.o5p_1 = policy;
    this.p5p_1 = null;
  }
  l5q(policy) {
    this.p5p_1 = policy;
  }
  m5q(maxTotalSteps, maxTotalTokens) {
    this.t5p_1 = new RunBudget(maxTotalSteps, maxTotalTokens);
  }
  n5q(policy) {
    this.q5p_1 = policy;
    this.r5p_1 = null;
  }
  o5q(policy) {
    this.r5p_1 = policy;
  }
  p5q(handler) {
    // Inline function 'kotlin.collections.plusAssign' call
    this.u5p_1.l(handler);
  }
  v5p() {
    var tmp0 = this.e5p_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.requireNotNull' call
      if (tmp0 == null) {
        var message = 'agent id is required (e.g. id = "assistant")';
        throw IllegalArgumentException.t(toString(message));
      } else {
        tmp$ret$1 = tmp0;
        break $l$block;
      }
    }
    var agentId = _AgentId___init__impl__m6udbt(tmp$ret$1);
    var tmp1 = this.i5p_1;
    var tmp$ret$3;
    $l$block_0: {
      // Inline function 'kotlin.requireNotNull' call
      if (tmp1 == null) {
        var message_0 = 'model { } block is required';
        throw IllegalArgumentException.t(toString(message_0));
      } else {
        tmp$ret$3 = tmp1;
        break $l$block_0;
      }
    }
    var scope = tmp$ret$3;
    var tmp2 = this.j5p_1;
    var tmp$ret$5;
    $l$block_1: {
      // Inline function 'kotlin.requireNotNull' call
      if (tmp2 == null) {
        var message_1 = 'a model is required (e.g. model { qwen(...) })';
        throw IllegalArgumentException.t(toString(message_1));
      } else {
        tmp$ret$5 = tmp2;
        break $l$block_1;
      }
    }
    var model = tmp$ret$5.r5q();
    var transportInfo = scope.u5q();
    var tmp0_elvis_lhs = this.h5p_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      var tmp1_safe_receiver = this.g5p_1;
      var tmp_0;
      if (tmp1_safe_receiver == null) {
        tmp_0 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_0 = Companion_getInstance_5().w5q(tmp1_safe_receiver);
      }
      tmp = tmp_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var tmp2_elvis_lhs = tmp;
    var resolvedInstructions = tmp2_elvis_lhs == null ? Companion_getInstance_5().v5q_1 : tmp2_elvis_lhs;
    var preparation = new AgentPreparation(resolvedInstructions, this.k5p_1, this.l5p_1);
    return new Agent(agentId, this.f5p_1, resolvedInstructions, model, this.k5p_1, toList(this.m5p_1), toList(this.n5p_1), this.o5p_1, this.p5p_1, this.q5p_1, this.r5p_1, this.t5p_1, preparation, this.s5p_1, toList(this.u5p_1), transportInfo.x5q_1, transportInfo.y5q_1);
  }
}
class MemoryScope {
  constructor() {
    this.h5q_1 = null;
  }
  z5q(id, provider) {
    // Inline function 'kotlin.require' call
    if (!(provider.a5r() === id)) {
      var message = "custom provider id '" + _MemoryProviderId___get_value__impl__90yl20(provider.a5r()) + "' does not match declared id '" + _MemoryProviderId___get_value__impl__90yl20(id) + "'";
      throw IllegalArgumentException.t(toString(message));
    }
    this.h5q_1 = provider;
  }
  v5p() {
    return this.h5q_1;
  }
}
class AgentEvent {}
class TextDelta {
  constructor(text) {
    this.b5r_1 = text;
  }
  toString() {
    return 'TextDelta(text=' + this.b5r_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.b5r_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof TextDelta))
      return false;
    var tmp0_other_with_cast = other instanceof TextDelta ? other : THROW_CCE();
    if (!(this.b5r_1 === tmp0_other_with_cast.b5r_1))
      return false;
    return true;
  }
}
class ReasoningDelta {
  constructor(text) {
    this.c5r_1 = text;
  }
  toString() {
    return 'ReasoningDelta(text=' + this.c5r_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.c5r_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ReasoningDelta))
      return false;
    var tmp0_other_with_cast = other instanceof ReasoningDelta ? other : THROW_CCE();
    if (!(this.c5r_1 === tmp0_other_with_cast.c5r_1))
      return false;
    return true;
  }
}
class ToolCallRequested {
  constructor(call) {
    this.d5r_1 = call;
  }
  toString() {
    return 'ToolCallRequested(call=' + this.d5r_1.toString() + ')';
  }
  hashCode() {
    return this.d5r_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolCallRequested))
      return false;
    var tmp0_other_with_cast = other instanceof ToolCallRequested ? other : THROW_CCE();
    if (!this.d5r_1.equals(tmp0_other_with_cast.d5r_1))
      return false;
    return true;
  }
}
class ToolResult {
  constructor(callId, output, isError) {
    this.e5r_1 = callId;
    this.f5r_1 = output;
    this.g5r_1 = isError;
  }
  toString() {
    return 'ToolResult(callId=' + this.e5r_1 + ', output=' + this.f5r_1 + ', isError=' + this.g5r_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.e5r_1);
    result = imul(result, 31) + getStringHashCode(this.f5r_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.g5r_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolResult))
      return false;
    var tmp0_other_with_cast = other instanceof ToolResult ? other : THROW_CCE();
    if (!(this.e5r_1 === tmp0_other_with_cast.e5r_1))
      return false;
    if (!(this.f5r_1 === tmp0_other_with_cast.f5r_1))
      return false;
    if (!(this.g5r_1 === tmp0_other_with_cast.g5r_1))
      return false;
    return true;
  }
}
class ToolProgress {
  constructor(callId, progress) {
    this.h5r_1 = callId;
    this.i5r_1 = progress;
  }
  toString() {
    return 'ToolProgress(callId=' + this.h5r_1 + ', progress=' + toString(this.i5r_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.h5r_1);
    result = imul(result, 31) + hashCode(this.i5r_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolProgress))
      return false;
    var tmp0_other_with_cast = other instanceof ToolProgress ? other : THROW_CCE();
    if (!(this.h5r_1 === tmp0_other_with_cast.h5r_1))
      return false;
    if (!equals(this.i5r_1, tmp0_other_with_cast.i5r_1))
      return false;
    return true;
  }
}
class StepCompleted {
  constructor(step) {
    this.j5r_1 = step;
  }
  toString() {
    return 'StepCompleted(step=' + this.j5r_1 + ')';
  }
  hashCode() {
    return this.j5r_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof StepCompleted))
      return false;
    var tmp0_other_with_cast = other instanceof StepCompleted ? other : THROW_CCE();
    if (!(this.j5r_1 === tmp0_other_with_cast.j5r_1))
      return false;
    return true;
  }
}
class Terminal {}
class Completed {
  constructor(message, usage) {
    this.l5r_1 = message;
    this.m5r_1 = usage;
  }
  k5r() {
    return this.m5r_1;
  }
  toString() {
    return 'Completed(message=' + this.l5r_1.toString() + ', usage=' + this.m5r_1.toString() + ')';
  }
  hashCode() {
    var result = this.l5r_1.hashCode();
    result = imul(result, 31) + this.m5r_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Completed))
      return false;
    var tmp0_other_with_cast = other instanceof Completed ? other : THROW_CCE();
    if (!this.l5r_1.equals(tmp0_other_with_cast.l5r_1))
      return false;
    if (!this.m5r_1.equals(tmp0_other_with_cast.m5r_1))
      return false;
    return true;
  }
}
class Incomplete {
  constructor(message, usage, reason) {
    this.n5r_1 = message;
    this.o5r_1 = usage;
    this.p5r_1 = reason;
  }
  k5r() {
    return this.o5r_1;
  }
  toString() {
    return 'Incomplete(message=' + this.n5r_1.toString() + ', usage=' + this.o5r_1.toString() + ', reason=' + toString(this.p5r_1) + ')';
  }
  hashCode() {
    var result = this.n5r_1.hashCode();
    result = imul(result, 31) + this.o5r_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.p5r_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Incomplete))
      return false;
    var tmp0_other_with_cast = other instanceof Incomplete ? other : THROW_CCE();
    if (!this.n5r_1.equals(tmp0_other_with_cast.n5r_1))
      return false;
    if (!this.o5r_1.equals(tmp0_other_with_cast.o5r_1))
      return false;
    if (!equals(this.p5r_1, tmp0_other_with_cast.p5r_1))
      return false;
    return true;
  }
}
class Terminated {
  constructor(message, usage, reason) {
    this.q5r_1 = message;
    this.r5r_1 = usage;
    this.s5r_1 = reason;
  }
  k5r() {
    return this.r5r_1;
  }
  toString() {
    return 'Terminated(message=' + this.q5r_1.toString() + ', usage=' + this.r5r_1.toString() + ', reason=' + toString(this.s5r_1) + ')';
  }
  hashCode() {
    var result = this.q5r_1.hashCode();
    result = imul(result, 31) + this.r5r_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.s5r_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Terminated))
      return false;
    var tmp0_other_with_cast = other instanceof Terminated ? other : THROW_CCE();
    if (!this.q5r_1.equals(tmp0_other_with_cast.q5r_1))
      return false;
    if (!this.r5r_1.equals(tmp0_other_with_cast.r5r_1))
      return false;
    if (!equals(this.s5r_1, tmp0_other_with_cast.s5r_1))
      return false;
    return true;
  }
}
class Failed {
  constructor(error, usage) {
    usage = usage === VOID ? Companion_getInstance_43().t5r_1 : usage;
    this.u5r_1 = error;
    this.v5r_1 = usage;
  }
  toString() {
    return 'Failed(error=' + toString(this.u5r_1) + ', usage=' + this.v5r_1.toString() + ')';
  }
  hashCode() {
    var result = hashCode(this.u5r_1);
    result = imul(result, 31) + this.v5r_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Failed))
      return false;
    var tmp0_other_with_cast = other instanceof Failed ? other : THROW_CCE();
    if (!equals(this.u5r_1, tmp0_other_with_cast.u5r_1))
      return false;
    if (!this.v5r_1.equals(tmp0_other_with_cast.v5r_1))
      return false;
    return true;
  }
}
class Key {}
class AgentExecutionContext extends AbstractCoroutineContextElement {
  constructor() {
    super(Key_instance);
  }
  c5s() {
    return null;
  }
  d5s(block, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_waiting__s4e4jr.bind(VOID, this, block), $completion);
  }
}
class ExecutionIdentity {
  constructor(runId, agentId, threadId, turnId, correlationId) {
    threadId = threadId === VOID ? null : threadId;
    turnId = turnId === VOID ? null : turnId;
    correlationId = correlationId === VOID ? null : correlationId;
    this.g5s_1 = runId;
    this.h5s_1 = agentId;
    this.i5s_1 = threadId;
    this.j5s_1 = turnId;
    this.k5s_1 = correlationId;
  }
  toString() {
    return 'ExecutionIdentity(runId=' + this.g5s_1 + ', agentId=' + this.h5s_1 + ', threadId=' + this.i5s_1 + ', turnId=' + this.j5s_1 + ', correlationId=' + this.k5s_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.g5s_1);
    result = imul(result, 31) + getStringHashCode(this.h5s_1) | 0;
    result = imul(result, 31) + (this.i5s_1 == null ? 0 : getStringHashCode(this.i5s_1)) | 0;
    result = imul(result, 31) + (this.j5s_1 == null ? 0 : getStringHashCode(this.j5s_1)) | 0;
    result = imul(result, 31) + (this.k5s_1 == null ? 0 : getStringHashCode(this.k5s_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ExecutionIdentity))
      return false;
    var tmp0_other_with_cast = other instanceof ExecutionIdentity ? other : THROW_CCE();
    if (!(this.g5s_1 === tmp0_other_with_cast.g5s_1))
      return false;
    if (!(this.h5s_1 === tmp0_other_with_cast.h5s_1))
      return false;
    if (!(this.i5s_1 == tmp0_other_with_cast.i5s_1))
      return false;
    if (!(this.j5s_1 == tmp0_other_with_cast.j5s_1))
      return false;
    if (!(this.k5s_1 == tmp0_other_with_cast.k5s_1))
      return false;
    return true;
  }
}
class AgentId {
  constructor(value) {
    this.l5s_1 = value;
  }
  toString() {
    return AgentId__toString_impl_gf4an3(this.l5s_1);
  }
  hashCode() {
    return AgentId__hashCode_impl_wutuj6(this.l5s_1);
  }
  equals(other) {
    return AgentId__equals_impl_gtr9u(this.l5s_1, other);
  }
}
class Pending {
  toString() {
    return 'Pending';
  }
  hashCode() {
    return -1103321979;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Pending))
      return false;
    other instanceof Pending || THROW_CCE();
    return true;
  }
}
class Ready {
  constructor(definition) {
    this.m5s_1 = definition;
  }
  toString() {
    return 'Ready(definition=' + this.m5s_1.toString() + ')';
  }
  hashCode() {
    return this.m5s_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Ready))
      return false;
    var tmp0_other_with_cast = other instanceof Ready ? other : THROW_CCE();
    if (!this.m5s_1.equals(tmp0_other_with_cast.m5s_1))
      return false;
    return true;
  }
}
class Failed_0 {
  constructor(failure) {
    this.n5s_1 = failure;
  }
  toString() {
    return 'Failed(failure=' + this.n5s_1.toString() + ')';
  }
  hashCode() {
    return hashCode(this.n5s_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Failed_0))
      return false;
    var tmp0_other_with_cast = other instanceof Failed_0 ? other : THROW_CCE();
    if (!equals(this.n5s_1, tmp0_other_with_cast.n5s_1))
      return false;
    return true;
  }
}
class AgentPreparation {
  constructor(baseInstructions, tools, skillPlan) {
    this.g5n_1 = baseInstructions;
    this.h5n_1 = tools;
    this.i5n_1 = skillPlan;
    this.j5n_1 = Mutex();
    this.k5n_1 = MutableStateFlow(Pending_instance);
  }
  vw($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_await__mos7q6.bind(VOID, this), $completion);
  }
}
class PreparedAgentDefinition {
  constructor(instructions, skillDescriptors) {
    this.l5n_1 = instructions;
    this.m5n_1 = skillDescriptors;
  }
  toString() {
    return 'PreparedAgentDefinition(instructions=' + toString(this.l5n_1) + ', skillDescriptors=' + toString(this.m5n_1) + ')';
  }
  hashCode() {
    var result = hashCode(this.l5n_1);
    result = imul(result, 31) + hashCode(this.m5n_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof PreparedAgentDefinition))
      return false;
    var tmp0_other_with_cast = other instanceof PreparedAgentDefinition ? other : THROW_CCE();
    if (!equals(this.l5n_1, tmp0_other_with_cast.l5n_1))
      return false;
    if (!equals(this.m5n_1, tmp0_other_with_cast.m5n_1))
      return false;
    return true;
  }
}
class AgentResult {}
function get_text() {
  return this.h2().f5t();
}
class Completed_0 {
  constructor(message, usage) {
    this.d5t_1 = message;
    this.e5t_1 = usage;
  }
  h2() {
    return this.d5t_1;
  }
  k5r() {
    return this.e5t_1;
  }
  toString() {
    return 'Completed(message=' + this.d5t_1.toString() + ', usage=' + this.e5t_1.toString() + ')';
  }
  hashCode() {
    var result = this.d5t_1.hashCode();
    result = imul(result, 31) + this.e5t_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Completed_0))
      return false;
    var tmp0_other_with_cast = other instanceof Completed_0 ? other : THROW_CCE();
    if (!this.d5t_1.equals(tmp0_other_with_cast.d5t_1))
      return false;
    if (!this.e5t_1.equals(tmp0_other_with_cast.e5t_1))
      return false;
    return true;
  }
}
class Incomplete_0 {
  constructor(message, usage, reason) {
    this.g5t_1 = message;
    this.h5t_1 = usage;
    this.i5t_1 = reason;
  }
  h2() {
    return this.g5t_1;
  }
  k5r() {
    return this.h5t_1;
  }
  toString() {
    return 'Incomplete(message=' + this.g5t_1.toString() + ', usage=' + this.h5t_1.toString() + ', reason=' + toString(this.i5t_1) + ')';
  }
  hashCode() {
    var result = this.g5t_1.hashCode();
    result = imul(result, 31) + this.h5t_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.i5t_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Incomplete_0))
      return false;
    var tmp0_other_with_cast = other instanceof Incomplete_0 ? other : THROW_CCE();
    if (!this.g5t_1.equals(tmp0_other_with_cast.g5t_1))
      return false;
    if (!this.h5t_1.equals(tmp0_other_with_cast.h5t_1))
      return false;
    if (!equals(this.i5t_1, tmp0_other_with_cast.i5t_1))
      return false;
    return true;
  }
}
class Terminated_0 {
  constructor(message, usage, reason) {
    this.j5t_1 = message;
    this.k5t_1 = usage;
    this.l5t_1 = reason;
  }
  h2() {
    return this.j5t_1;
  }
  k5r() {
    return this.k5t_1;
  }
  toString() {
    return 'Terminated(message=' + this.j5t_1.toString() + ', usage=' + this.k5t_1.toString() + ', reason=' + toString(this.l5t_1) + ')';
  }
  hashCode() {
    var result = this.j5t_1.hashCode();
    result = imul(result, 31) + this.k5t_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.l5t_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Terminated_0))
      return false;
    var tmp0_other_with_cast = other instanceof Terminated_0 ? other : THROW_CCE();
    if (!this.j5t_1.equals(tmp0_other_with_cast.j5t_1))
      return false;
    if (!this.k5t_1.equals(tmp0_other_with_cast.k5t_1))
      return false;
    if (!equals(this.l5t_1, tmp0_other_with_cast.l5t_1))
      return false;
    return true;
  }
}
class Failed_1 {
  constructor(error, usage, message) {
    usage = usage === VOID ? Companion_getInstance_43().t5r_1 : usage;
    message = message === VOID ? Companion_instance_36.m5t('') : message;
    this.n5t_1 = error;
    this.o5t_1 = usage;
    this.p5t_1 = message;
  }
  k5r() {
    return this.o5t_1;
  }
  h2() {
    return this.p5t_1;
  }
  toString() {
    return 'Failed(error=' + toString(this.n5t_1) + ', usage=' + this.o5t_1.toString() + ', message=' + this.p5t_1.toString() + ')';
  }
  hashCode() {
    var result = hashCode(this.n5t_1);
    result = imul(result, 31) + this.o5t_1.hashCode() | 0;
    result = imul(result, 31) + this.p5t_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Failed_1))
      return false;
    var tmp0_other_with_cast = other instanceof Failed_1 ? other : THROW_CCE();
    if (!equals(this.n5t_1, tmp0_other_with_cast.n5t_1))
      return false;
    if (!this.o5t_1.equals(tmp0_other_with_cast.o5t_1))
      return false;
    if (!this.p5t_1.equals(tmp0_other_with_cast.p5t_1))
      return false;
    return true;
  }
}
class AgentRunner$stream$slambda$slambda {
  constructor($this_channelFlow) {
    this.q5t_1 = $this_channelFlow;
  }
  w5t(it, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_1.bind(VOID, this, it), $completion);
  }
  td(p1, $completion) {
    return this.w5t((!(p1 == null) ? isInterface(p1, AgentEvent) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRunner$runLoop$slambda$slambda$slambda$slambda {
  constructor($current, $outputMutex, this$0, $emit) {
    this.i5v_1 = $current;
    this.j5v_1 = $outputMutex;
    this.k5v_1 = this$0;
    this.l5v_1 = $emit;
  }
  d5w(progress, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_4.bind(VOID, this, progress), $completion);
  }
  td(p1, $completion) {
    return this.d5w((!(p1 == null) ? isInterface(p1, ToolProgress_0) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRunner$runLoop$slambda$slambda$slambda {
  constructor($call, this$0, $state, $exec, $outputMutex, $emit) {
    this.r5v_1 = $call;
    this.s5v_1 = this$0;
    this.t5v_1 = $state;
    this.u5v_1 = $exec;
    this.v5v_1 = $outputMutex;
    this.w5v_1 = $emit;
  }
  vd($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_5.bind(VOID, this), $completion);
  }
}
class AgentRunner$runLoop$slambda$slambda$slambda_0 {
  constructor($body) {
    this.m5w_1 = $body;
  }
  vd($completion) {
    return this.m5w_1($completion);
  }
}
class AgentRunner$runLoop$slambda$slambda {
  constructor($branch, $call, this$0, $state, $exec, $outputMutex, $emit) {
    this.e5w_1 = $branch;
    this.f5w_1 = $call;
    this.g5w_1 = this$0;
    this.h5w_1 = $state;
    this.i5w_1 = $exec;
    this.j5w_1 = $outputMutex;
    this.k5w_1 = $emit;
  }
  r1f($this$async, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_6.bind(VOID, this, $this$async), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRunner$runLoop$slambda$slambda_0 {
  constructor($deferreds) {
    this.t5w_1 = $deferreds;
  }
  vd($completion) {
    return awaitAll(this.t5w_1, $completion);
  }
}
class AgentRunner$streamStructured$slambda$slambda {
  constructor($this_flow) {
    this.u5w_1 = $this_flow;
  }
  w5t(it, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_8.bind(VOID, this, it), $completion);
  }
  td(p1, $completion) {
    return this.w5t((!(p1 == null) ? isInterface(p1, AgentEvent) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class LoopRun {
  constructor(state) {
    this.h5x_1 = state;
  }
  toString() {
    return 'LoopRun(state=' + this.h5x_1.toString() + ')';
  }
  hashCode() {
    return this.h5x_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof LoopRun))
      return false;
    var tmp0_other_with_cast = other instanceof LoopRun ? other : THROW_CCE();
    if (!this.h5x_1.equals(tmp0_other_with_cast.h5x_1))
      return false;
    return true;
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0 {
  constructor(function_0) {
    this.g5z_1 = function_0;
  }
  t1c(value, $completion) {
    return this.g5z_1(value, $completion);
  }
  n4() {
    return this.g5z_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_0 {
  constructor(function_0) {
    this.h5z_1 = function_0;
  }
  t1c(value, $completion) {
    return this.h5z_1(value, $completion);
  }
  n4() {
    return this.h5z_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class AgentRunner$stream$slambda {
  constructor(this$0, $initial, $instructions, $turn, $checkpoint) {
    this.r5t_1 = this$0;
    this.s5t_1 = $initial;
    this.t5t_1 = $instructions;
    this.u5t_1 = $turn;
    this.v5t_1 = $checkpoint;
  }
  i5z($this$channelFlow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_2.bind(VOID, this, $this$channelFlow), $completion);
  }
  td(p1, $completion) {
    return this.i5z((!(p1 == null) ? isInterface(p1, ProducerScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRunner$runLoop$slambda {
  constructor($turn, this$0, $emittedText, $terminalResponse, $state, $outputMutex, $emit) {
    this.x5t_1 = $turn;
    this.y5t_1 = this$0;
    this.z5t_1 = $emittedText;
    this.a5u_1 = $terminalResponse;
    this.b5u_1 = $state;
    this.c5u_1 = $outputMutex;
    this.d5u_1 = $emit;
  }
  j5z(event, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_3.bind(VOID, this, event), $completion);
  }
  td(p1, $completion) {
    return this.j5z((!(p1 == null) ? isInterface(p1, ModelEvent) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRunner$runLoop$slambda_0 {
  constructor($exec, $calls, this$0, $state, $outputMutex, $emit) {
    this.n5w_1 = $exec;
    this.o5w_1 = $calls;
    this.p5w_1 = this$0;
    this.q5w_1 = $state;
    this.r5w_1 = $outputMutex;
    this.s5w_1 = $emit;
  }
  r1f($this$coroutineScope, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_7.bind(VOID, this, $this$coroutineScope), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRunner$streamStructured$slambda {
  constructor(this$0, $initial, $instructions, $spec, $turn, $checkpoint) {
    this.v5w_1 = this$0;
    this.w5w_1 = $initial;
    this.x5w_1 = $instructions;
    this.y5w_1 = $spec;
    this.z5w_1 = $turn;
    this.a5x_1 = $checkpoint;
  }
  m5o($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_9.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.m5o((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRunner$runStructured$slambda {
  constructor($events, $emit) {
    this.b5x_1 = $events;
    this.c5x_1 = $emit;
  }
  w5t(event, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_10.bind(VOID, this, event), $completion);
  }
  td(p1, $completion) {
    return this.w5t((!(p1 == null) ? isInterface(p1, AgentEvent) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRunner$runStructured$slambda_0 {
  constructor($turn, this$0, $emit, $finalizationResponse) {
    this.d5x_1 = $turn;
    this.e5x_1 = this$0;
    this.f5x_1 = $emit;
    this.g5x_1 = $finalizationResponse;
  }
  j5z(event, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_11.bind(VOID, this, event), $completion);
  }
  td(p1, $completion) {
    return this.j5z((!(p1 == null) ? isInterface(p1, ModelEvent) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRunner {
  constructor(agent) {
    this.p5n_1 = agent;
    var tmp = this;
    var tmp_0 = KotlinLogging_instance;
    tmp.q5n_1 = tmp_0.g5l(AgentRunner$logger$lambda);
  }
  r5n(initial, instructions, turn, checkpoint) {
    return channelFlow(AgentRunner$stream$slambda_0(this, initial, instructions, turn, checkpoint));
  }
  y5n(initial, instructions, spec, turn, checkpoint) {
    return flow(AgentRunner$streamStructured$slambda_0(this, initial, instructions, spec, turn, checkpoint));
  }
}
class AgentState {
  constructor(items, instructions, checkpoint, globalStep, localStep, usage, activeAgentName) {
    instructions = instructions === VOID ? null : instructions;
    checkpoint = checkpoint === VOID ? null : checkpoint;
    globalStep = globalStep === VOID ? 0 : globalStep;
    localStep = localStep === VOID ? 0 : localStep;
    usage = usage === VOID ? Companion_getInstance_43().t5r_1 : usage;
    activeAgentName = activeAgentName === VOID ? 'agent' : activeAgentName;
    this.s5o_1 = items;
    this.t5o_1 = instructions;
    this.u5o_1 = checkpoint;
    this.v5o_1 = globalStep;
    this.w5o_1 = localStep;
    this.x5o_1 = usage;
    this.y5o_1 = activeAgentName;
  }
  v5x() {
    return this.v5o_1;
  }
  o5x(item) {
    return this.f5y(plus(this.s5o_1, item), VOID, VOID, this.v5o_1 + 1 | 0, this.w5o_1 + 1 | 0);
  }
  b5y(newItems) {
    return this.f5y(plus_0(this.s5o_1, newItems), VOID, VOID, this.v5o_1 + newItems.b1() | 0, this.w5o_1 + newItems.b1() | 0);
  }
  r5u(delta) {
    return this.f5y(VOID, VOID, VOID, VOID, VOID, this.x5o_1.s5y(delta));
  }
  t5u(checkpoint) {
    return this.f5y(VOID, VOID, checkpoint);
  }
  t5x(output) {
    var merged = toMutableList(this.s5o_1);
    var _iterator__ex2g4s = output.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.collections.indexOfFirst' call
        var index = 0;
        var _iterator__ex2g4s_0 = merged.y();
        while (_iterator__ex2g4s_0.z()) {
          var item_0 = _iterator__ex2g4s_0.a1();
          if (item_0.s5z() === item.s5z()) {
            tmp$ret$1 = index;
            break $l$block;
          }
          index = index + 1 | 0;
        }
        tmp$ret$1 = -1;
      }
      var index_0 = tmp$ret$1;
      if (index_0 >= 0) {
        merged.c3(index_0, item);
      } else {
        // Inline function 'kotlin.collections.plusAssign' call
        merged.l(item);
      }
    }
    return this.f5y(merged, VOID, VOID, this.v5o_1 + 1 | 0, this.w5o_1 + 1 | 0);
  }
  c5y(calls, outcomes) {
    // Inline function 'kotlin.collections.mapIndexed' call
    // Inline function 'kotlin.collections.mapIndexedTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(calls, 10));
    var index = 0;
    var _iterator__ex2g4s = calls.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var i = checkIndexOverflow(_unary__edvuaz);
      var o = outcomes.f1(i);
      var tmp;
      if (o instanceof Success) {
        tmp = new ToolResult_0(VOID, VOID, item.s5z(), o.x5r_1, false);
      } else {
        if (o instanceof Failure) {
          tmp = new ToolResult_0(VOID, VOID, item.s5z(), o.w5r_1.h2(), true);
        } else {
          noWhenBranchMatchedException();
        }
      }
      var tmp$ret$0 = tmp;
      destination.l(tmp$ret$0);
    }
    var results = destination;
    return this.f5y(plus_0(this.s5o_1, results));
  }
  i5x() {
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = this.s5o_1;
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element instanceof Message) {
        destination.l(element);
      }
    }
    var tmp$ret$3;
    $l$block: {
      // Inline function 'kotlin.collections.lastOrNull' call
      var iterator = destination.i1(destination.b1());
      while (iterator.p6()) {
        var element_0 = iterator.r6();
        if (element_0.c5o_1.equals(Role_ASSISTANT_getInstance())) {
          tmp$ret$3 = element_0;
          break $l$block;
        }
      }
      tmp$ret$3 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$3;
    return tmp0_elvis_lhs == null ? Companion_instance_36.m5t('') : tmp0_elvis_lhs;
  }
  t5z(items, instructions, checkpoint, globalStep, localStep, usage, activeAgentName) {
    return new AgentState(items, instructions, checkpoint, globalStep, localStep, usage, activeAgentName);
  }
  f5y(items, instructions, checkpoint, globalStep, localStep, usage, activeAgentName, $super) {
    items = items === VOID ? this.s5o_1 : items;
    instructions = instructions === VOID ? this.t5o_1 : instructions;
    checkpoint = checkpoint === VOID ? this.u5o_1 : checkpoint;
    globalStep = globalStep === VOID ? this.v5o_1 : globalStep;
    localStep = localStep === VOID ? this.w5o_1 : localStep;
    usage = usage === VOID ? this.x5o_1 : usage;
    activeAgentName = activeAgentName === VOID ? this.y5o_1 : activeAgentName;
    return $super === VOID ? this.t5z(items, instructions, checkpoint, globalStep, localStep, usage, activeAgentName) : $super.t5z.call(this, items, instructions, checkpoint, globalStep, localStep, usage, activeAgentName);
  }
  toString() {
    return 'AgentState(items=' + toString(this.s5o_1) + ', instructions=' + this.t5o_1 + ', checkpoint=' + toString_0(this.u5o_1) + ', globalStep=' + this.v5o_1 + ', localStep=' + this.w5o_1 + ', usage=' + this.x5o_1.toString() + ', activeAgentName=' + this.y5o_1 + ')';
  }
  hashCode() {
    var result = hashCode(this.s5o_1);
    result = imul(result, 31) + (this.t5o_1 == null ? 0 : getStringHashCode(this.t5o_1)) | 0;
    result = imul(result, 31) + (this.u5o_1 == null ? 0 : this.u5o_1.hashCode()) | 0;
    result = imul(result, 31) + this.v5o_1 | 0;
    result = imul(result, 31) + this.w5o_1 | 0;
    result = imul(result, 31) + this.x5o_1.hashCode() | 0;
    result = imul(result, 31) + getStringHashCode(this.y5o_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AgentState))
      return false;
    var tmp0_other_with_cast = other instanceof AgentState ? other : THROW_CCE();
    if (!equals(this.s5o_1, tmp0_other_with_cast.s5o_1))
      return false;
    if (!(this.t5o_1 == tmp0_other_with_cast.t5o_1))
      return false;
    if (!equals(this.u5o_1, tmp0_other_with_cast.u5o_1))
      return false;
    if (!(this.v5o_1 === tmp0_other_with_cast.v5o_1))
      return false;
    if (!(this.w5o_1 === tmp0_other_with_cast.w5o_1))
      return false;
    if (!this.x5o_1.equals(tmp0_other_with_cast.x5o_1))
      return false;
    if (!(this.y5o_1 === tmp0_other_with_cast.y5o_1))
      return false;
    return true;
  }
}
class InstructionsScope {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.a5q_1 = ArrayList.k();
  }
  u5z(value) {
    var tmp0 = this.a5q_1;
    // Inline function 'kotlin.collections.plusAssign' call
    var element = new Static(value);
    tmp0.l(element);
  }
  v5z(provider) {
    var tmp0 = this.a5q_1;
    // Inline function 'kotlin.collections.plusAssign' call
    var element = new Dynamic(provider);
    tmp0.l(element);
  }
  v5p() {
    return new Instructions(toList(this.a5q_1));
  }
}
class Companion {
  constructor() {
    Companion_instance_1 = this;
    this.v5q_1 = new Instructions(emptyList());
  }
  w5q(text) {
    return new Instructions(listOf(new Static(text)));
  }
}
class Instructions {
  constructor(segments) {
    Companion_getInstance_5();
    this.n5n_1 = segments;
  }
  o5n($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_resolve__ieq9xk.bind(VOID, this), $completion);
  }
  u5s(values) {
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = values.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.text.isNotBlank' call
      if (!isBlank(element)) {
        destination.l(element);
      }
    }
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(destination, 10));
    var _iterator__ex2g4s_0 = destination.y();
    while (_iterator__ex2g4s_0.z()) {
      var item = _iterator__ex2g4s_0.a1();
      var tmp$ret$4 = new Static(item);
      destination_0.l(tmp$ret$4);
    }
    return new Instructions(plus_0(this.n5n_1, destination_0));
  }
}
class Static {
  constructor(text) {
    this.x5z_1 = text;
  }
  toString() {
    return 'Static(text=' + this.x5z_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.x5z_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Static))
      return false;
    var tmp0_other_with_cast = other instanceof Static ? other : THROW_CCE();
    if (!(this.x5z_1 === tmp0_other_with_cast.x5z_1))
      return false;
    return true;
  }
}
class Dynamic {
  constructor(provider) {
    this.w5z_1 = provider;
  }
}
class ModelFailure extends Exception {
  static c5v(error) {
    var $this = this.xd(error.h2(), error.i2());
    captureStack($this, $this.b5v_1);
    $this.a5v_1 = error;
    return $this;
  }
}
class ModelScope {
  constructor() {
    this.s5q_1 = null;
    this.t5q_1 = null;
  }
  y5z(transport) {
    this.s5q_1 = transport;
  }
  z5z(model) {
    return ModelSelection.a60(model);
  }
  b60() {
    var tmp0_elvis_lhs = this.s5q_1;
    var tmp1_elvis_lhs = tmp0_elvis_lhs == null ? this.t5q_1 : tmp0_elvis_lhs;
    var tmp;
    if (tmp1_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_0 = new KtorTransport();
      this.t5q_1 = this_0;
      tmp = this_0;
    } else {
      tmp = tmp1_elvis_lhs;
    }
    return tmp;
  }
  u5q() {
    var tmp0_elvis_lhs = this.s5q_1;
    return new TransportInfo(tmp0_elvis_lhs == null ? this.t5q_1 : tmp0_elvis_lhs, this.s5q_1 == null && !(this.t5q_1 == null));
  }
}
class ModelSelection {
  static c60(models) {
    var $this = createThis(this);
    $this.q5q_1 = models;
    return $this;
  }
  static a60(model) {
    return this.c60(listOf(model));
  }
  d60(next) {
    return ModelSelection.c60(plus_0(this.q5q_1, next.q5q_1));
  }
  r5q() {
    var tmp0_elvis_lhs = singleOrNull(this.q5q_1);
    return tmp0_elvis_lhs == null ? new FallbackModel(this.q5q_1) : tmp0_elvis_lhs;
  }
}
class TransportInfo {
  constructor(transport, ownsTransport) {
    this.x5q_1 = transport;
    this.y5q_1 = ownsTransport;
  }
  toString() {
    return 'TransportInfo(transport=' + toString_0(this.x5q_1) + ', ownsTransport=' + this.y5q_1 + ')';
  }
  hashCode() {
    var result = this.x5q_1 == null ? 0 : hashCode(this.x5q_1);
    result = imul(result, 31) + getBooleanHashCode(this.y5q_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof TransportInfo))
      return false;
    var tmp0_other_with_cast = other instanceof TransportInfo ? other : THROW_CCE();
    if (!equals(this.x5q_1, tmp0_other_with_cast.x5q_1))
      return false;
    if (!(this.y5q_1 === tmp0_other_with_cast.y5q_1))
      return false;
    return true;
  }
}
class OutputSpec {
  constructor(schema, schemaName) {
    this.d5y_1 = schema;
    this.e5y_1 = schemaName;
  }
  toString() {
    return 'OutputSpec(schema=' + this.d5y_1.toString() + ', schemaName=' + this.e5y_1 + ')';
  }
  hashCode() {
    var result = this.d5y_1.hashCode();
    result = imul(result, 31) + getStringHashCode(this.e5y_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OutputSpec))
      return false;
    var tmp0_other_with_cast = other instanceof OutputSpec ? other : THROW_CCE();
    if (!this.d5y_1.equals(tmp0_other_with_cast.d5y_1))
      return false;
    if (!(this.e5y_1 === tmp0_other_with_cast.e5y_1))
      return false;
    return true;
  }
}
class ToolCallBuilder {
  constructor() {
    this.e60_1 = null;
    this.f60_1 = null;
    this.g60_1 = null;
    this.h60_1 = StringBuilder.v();
    this.i60_1 = StringBuilder.v();
  }
  j60(id, nameDelta, argumentsDelta) {
    if (!(id == null) && this.e60_1 == null)
      this.e60_1 = id;
    if (!(nameDelta == null)) {
      this.h60_1.tb(nameDelta);
    }
    if (!(argumentsDelta == null)) {
      this.i60_1.tb(argumentsDelta);
    }
  }
  k60(call) {
    this.e60_1 = call.m5v_1;
    this.f60_1 = call.p5v_1;
    this.g60_1 = call.q5v_1;
    this.h60_1 = StringBuilder.bh(call.n5v_1);
    this.i60_1 = StringBuilder.bh(call.o5v_1);
  }
}
class ToolScope {
  constructor(registry) {
    this.l60_1 = registry;
  }
  m60(tool) {
    this.l60_1.n60(tool);
  }
  o60(gateway) {
    this.l60_1.p60(new McpToolSource(gateway));
  }
}
class TurnBuilder {
  constructor(turnId, seed) {
    seed = seed === VOID ? emptyList() : seed;
    this.e5u_1 = turnId;
    this.f5u_1 = toMutableList(seed);
    this.g5u_1 = StringBuilder.v();
    this.h5u_1 = null;
    this.i5u_1 = HashSet.ga();
    this.j5u_1 = LinkedHashMap.hc();
    this.k5u_1 = Companion_getInstance_43().t5r_1;
    this.l5u_1 = null;
    this.m5u_1 = null;
    this.n5u_1 = null;
  }
  o5u(event) {
    if (event instanceof Started) {
      this.m5u_1 = event.d61_1;
    } else {
      if (event instanceof CheckpointUpdated) {
        this.l5u_1 = event.c61_1;
      } else {
        if (event instanceof TextDelta_0) {
          var tmp;
          var tmp_0;
          // Inline function 'kotlin.text.isNotEmpty' call
          var this_0 = this.g5u_1;
          if (charSequenceLength(this_0) > 0) {
            var tmp_1 = event.h5v_1;
            tmp_0 = !((tmp_1 == null ? null : new ItemRef(tmp_1)) == null);
          } else {
            tmp_0 = false;
          }
          if (tmp_0) {
            var tmp_2 = event.h5v_1;
            var tmp_3 = tmp_2 == null ? null : new ItemRef(tmp_2);
            var tmp_4 = this.h5u_1;
            tmp = !equals(tmp_3, tmp_4 == null ? null : new ItemRef(tmp_4));
          } else {
            tmp = false;
          }
          if (tmp) {
            flushPartialText(this);
          }
          var tmp_5 = this.h5u_1;
          if ((tmp_5 == null ? null : new ItemRef(tmp_5)) == null) {
            var tmp_6 = this;
            var tmp1_elvis_lhs = event.h5v_1;
            var tmp_7;
            var tmp_8 = tmp1_elvis_lhs;
            if ((tmp_8 == null ? null : new ItemRef(tmp_8)) == null) {
              tmp_7 = Companion_instance_32.q60('msg');
            } else {
              tmp_7 = tmp1_elvis_lhs;
            }
            tmp_6.h5u_1 = tmp_7;
          }
          var tmp2 = this.i5u_1;
          var tmp_9 = this.h5u_1;
          // Inline function 'kotlin.requireNotNull' call
          var tmp0 = tmp_9 == null ? null : new ItemRef(tmp_9);
          var tmp$ret$2;
          $l$block: {
            // Inline function 'kotlin.requireNotNull' call
            if (tmp0 == null) {
              var message = 'Required value was null.';
              throw IllegalArgumentException.t(toString(message));
            } else {
              tmp$ret$2 = tmp0;
              break $l$block;
            }
          }
          var tmp$ret$3 = tmp$ret$2.b61_1;
          // Inline function 'kotlin.collections.plusAssign' call
          var element = new ItemRef(tmp$ret$3);
          tmp2.l(element);
          this.g5u_1.tb(event.g5v_1);
        } else {
          if (!(event instanceof ReasoningDelta_0)) {
            if (event instanceof ItemAdded) {
              flushPartialText(this);
              upsert(this, event.a61_1);
            } else {
              if (event instanceof ToolCallDelta) {
                var tmp2_safe_receiver = event.z60_1;
                var tmp_10;
                var tmp_11 = tmp2_safe_receiver;
                if ((tmp_11 == null ? null : new ItemRef(tmp_11)) == null) {
                  tmp_10 = null;
                } else {
                  tmp_10 = _ItemRef___get_value__impl__fpjuyb(tmp2_safe_receiver);
                }
                var tmp3_elvis_lhs = tmp_10;
                var tmp_12;
                if (tmp3_elvis_lhs == null) {
                  // Inline function 'kotlin.text.ifBlank' call
                  var this_1 = event.v60_1;
                  var tmp_13;
                  if (isBlank(this_1)) {
                    var tmp0_elvis_lhs = event.w60_1;
                    tmp_13 = 'idx-' + (tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs);
                  } else {
                    tmp_13 = this_1;
                  }
                  tmp_12 = tmp_13;
                } else {
                  tmp_12 = tmp3_elvis_lhs;
                }
                var key = tmp_12;
                // Inline function 'kotlin.collections.getOrPut' call
                var this_2 = this.j5u_1;
                var value = this_2.h3(key);
                var tmp_14;
                if (value == null) {
                  var answer = new ToolCallBuilder();
                  this_2.k3(key, answer);
                  tmp_14 = answer;
                } else {
                  tmp_14 = value;
                }
                var tmp_15 = tmp_14;
                // Inline function 'kotlin.text.ifBlank' call
                var this_3 = event.v60_1;
                var tmp_16;
                if (isBlank(this_3)) {
                  tmp_16 = null;
                } else {
                  tmp_16 = this_3;
                }
                var tmp$ret$10 = tmp_16;
                tmp_15.j60(tmp$ret$10, event.x60_1, event.y60_1);
              } else {
                if (event instanceof ToolCallCompleted) {
                  flushPartialText(this);
                  // Inline function 'kotlin.text.ifBlank' call
                  var this_4 = _ItemRef___get_value__impl__fpjuyb(event.d5v_1.s5z());
                  var tmp_17;
                  if (isBlank(this_4)) {
                    // Inline function 'kotlin.text.ifBlank' call
                    var this_5 = event.d5v_1.m5v_1;
                    var tmp_18;
                    if (isBlank(this_5)) {
                      tmp_18 = 'idx-' + this.j5u_1.b1();
                    } else {
                      tmp_18 = this_5;
                    }
                    tmp_17 = tmp_18;
                  } else {
                    tmp_17 = this_4;
                  }
                  var key_0 = tmp_17;
                  // Inline function 'kotlin.collections.getOrPut' call
                  var this_6 = this.j5u_1;
                  var value_0 = this_6.h3(key_0);
                  var tmp_19;
                  if (value_0 == null) {
                    var answer_0 = new ToolCallBuilder();
                    this_6.k3(key_0, answer_0);
                    tmp_19 = answer_0;
                  } else {
                    tmp_19 = value_0;
                  }
                  tmp_19.k60(event.d5v_1);
                  upsert(this, event.d5v_1.u60());
                } else {
                  if (!(event instanceof ProviderEvent)) {
                    if (event instanceof Finished) {
                      flushPartialText(this);
                      this.n5u_1 = event.q5u_1;
                      this.k5u_1 = this.k5u_1.s5y(event.q5u_1.k5r());
                      var tmp4_safe_receiver = event.q5u_1.s5u();
                      if (tmp4_safe_receiver == null)
                        null;
                      else {
                        // Inline function 'kotlin.let' call
                        this.l5u_1 = tmp4_safe_receiver;
                      }
                      var tmp_20 = this;
                      var tmp5_elvis_lhs = event.q5u_1.t60();
                      tmp_20.m5u_1 = tmp5_elvis_lhs == null ? this.m5u_1 : tmp5_elvis_lhs;
                      mergeResponseOutput(this, event.q5u_1);
                    } else {
                      noWhenBranchMatchedException();
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  p5x(item) {
    upsert(this, item);
  }
  u5x() {
    flushPartialText(this);
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = this.f5u_1;
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element instanceof Message) {
        destination.l(element);
      }
    }
    var tmp$ret$3;
    $l$block: {
      // Inline function 'kotlin.collections.lastOrNull' call
      var iterator = destination.i1(destination.b1());
      while (iterator.p6()) {
        var element_0 = iterator.r6();
        if (element_0.c5o_1.equals(Role_ASSISTANT_getInstance())) {
          tmp$ret$3 = element_0;
          break $l$block;
        }
      }
      tmp$ret$3 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$3;
    return tmp0_elvis_lhs == null ? Companion_instance_36.m5t(this.g5u_1.toString()) : tmp0_elvis_lhs;
  }
  e61() {
    return this.m5u_1;
  }
  s5x(response) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = response.r60();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp0 = this.f5u_1;
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s_0 = tmp0.y();
        while (_iterator__ex2g4s_0.z()) {
          var element = _iterator__ex2g4s_0.a1();
          if (element.s5z() === item.s5z()) {
            tmp$ret$1 = element;
            break $l$block;
          }
        }
        tmp$ret$1 = null;
      }
      var tmp0_elvis_lhs = tmp$ret$1;
      var tmp$ret$2 = tmp0_elvis_lhs == null ? item : tmp0_elvis_lhs;
      destination.l(tmp$ret$2);
    }
    return destination;
  }
  f61(status) {
    return new ConversationTurn(this.e5u_1, status, toList(this.f5u_1), this.l5u_1, this.k5u_1);
  }
  g61() {
    return this.f61(Completed_instance);
  }
  t5y(finalAssistant, dropRefs) {
    flushPartialText(this);
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!dropRefs.h1()) {
      removeAll(this.f5u_1, TurnBuilder$collapseToFinalAssistant$lambda(dropRefs));
    }
    var tmp1 = this.f5u_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlin.collections.indexOfLast' call
      var iterator = tmp1.i1(tmp1.b1());
      while (iterator.p6()) {
        var it = iterator.r6();
        var tmp;
        if (it instanceof Message) {
          tmp = it.c5o_1.equals(Role_USER_getInstance());
        } else {
          tmp = false;
        }
        if (tmp) {
          tmp$ret$2 = iterator.q6();
          break $l$block;
        }
      }
      tmp$ret$2 = -1;
    }
    var lastUser = tmp$ret$2;
    var head = lastUser >= 0 ? take(this.f5u_1, lastUser + 1 | 0) : emptyList();
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = drop(this.f5u_1, head.b1());
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp_0;
      if (!(element instanceof Message)) {
        tmp_0 = true;
      } else {
        tmp_0 = !element.c5o_1.equals(Role_ASSISTANT_getInstance());
      }
      if (tmp_0) {
        destination.l(element);
      }
    }
    var tail = destination;
    this.f5u_1.b3();
    this.f5u_1.c1(head);
    this.f5u_1.c1(tail);
    // Inline function 'kotlin.collections.plusAssign' call
    this.f5u_1.l(finalAssistant);
    this.g5u_1.jh();
    this.h5u_1 = null;
  }
  h61(reason) {
    // Inline function 'kotlin.text.ifEmpty' call
    var this_0 = this.g5u_1.toString();
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(this_0) === 0) {
      tmp = null;
    } else {
      tmp = this_0;
    }
    var partialText = tmp;
    var tmp_0;
    if (!(partialText == null)) {
      var tmp0_elvis_lhs = this.h5u_1;
      var tmp_1;
      var tmp_2 = tmp0_elvis_lhs;
      if ((tmp_2 == null ? null : new ItemRef(tmp_2)) == null) {
        // Inline function 'kotlin.also' call
        var this_1 = new ItemRef(Companion_instance_32.q60('msg'));
        this.h5u_1 = this_1.b61_1;
        tmp_1 = this_1.b61_1;
      } else {
        tmp_1 = tmp0_elvis_lhs;
      }
      tmp_0 = tmp_1;
    } else {
      tmp_0 = null;
    }
    var partialItem = tmp_0;
    flushPartialText(this);
    var pending = new PendingWork(unresolvedCallRefs(this.f5u_1), partialText, partialItem);
    return this.f61(new Interrupted(reason, pending));
  }
}
class McpToolSource {
  constructor(gateway) {
    this.i61_1 = gateway;
  }
  k61($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_discover__xd3vwf.bind(VOID, this), $completion);
  }
}
class Tool {}
function get_returnDirectly() {
  return false;
}
function get_hasSideEffects() {
  return false;
}
function get_parametersOverride() {
  return null;
}
function get_acceptsRawJson() {
  return false;
}
class McpToolAdapter {
  constructor(mcpTool, gateway) {
    this.l61_1 = mcpTool;
    this.m61_1 = gateway;
    var tmp = this;
    // Inline function 'kotlinx.serialization.serializer' call
    // Inline function 'kotlinx.serialization.internal.cast' call
    var this_0 = serializer(createKType(PrimitiveClasses_getInstance().ng(), arrayOf([]), false));
    tmp.n61_1 = isInterface(this_0, KSerializer) ? this_0 : THROW_CCE();
  }
  e44() {
    return this.l61_1.o61_1;
  }
  r61() {
    return this.l61_1.p61_1;
  }
  s61() {
    return this.n61_1;
  }
  t61() {
    return true;
  }
  u61() {
    var tmp0_elvis_lhs = this.l61_1.q61_1;
    return tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  }
  v61(input, $completion) {
    return this.m61_1.w61(this.e44(), input, $completion);
  }
  x61(input, $completion) {
    return this.v61((!(input == null) ? typeof input === 'string' : false) ? input : THROW_CCE(), $completion);
  }
}
class DefaultMcpClient {
  constructor(mcpUrl, mcpClientConfig, customHeaders) {
    customHeaders = customHeaders === VOID ? emptyMap() : customHeaders;
    this.a62_1 = mcpUrl;
    this.b62_1 = mcpClientConfig;
    this.c62_1 = customHeaders;
    var tmp = this;
    var tmp_0 = KotlinLogging_instance;
    tmp.d62_1 = tmp_0.g5l(DefaultMcpClient$logger$lambda);
    var tmp_1 = this;
    tmp_1.e62_1 = Json(VOID, DefaultMcpClient$json$lambda);
    this.f62_1 = new KtorHttpClient(new HttpClientConfig(this.a62_1, VOID, VOID, VOID, VOID, VOID, VOID, this.c62_1));
    this.g62_1 = new HttpMcpTransport(this.f62_1);
    this.h62_1 = Mutex();
    this.i62_1 = MutableStateFlow(false);
    this.j62_1 = false;
  }
  l62(request, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_initialize__e44cg8.bind(VOID, this, request), $completion);
  }
  t62(request, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_initialized__bd2d5s.bind(VOID, this, request), $completion);
  }
  j61($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_listTools__xmth8p.bind(VOID, this), $completion);
  }
  g63(name, arguments_0, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_callTool__hwc8fm.bind(VOID, this, name, arguments_0), $completion);
  }
  w61(name, argumentsJson, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_callTool__hwc8fm_0.bind(VOID, this, name, argumentsJson), $completion);
  }
  a6() {
    if (!this.i62_1.u1e(false, true))
      return Unit_instance;
    this.f62_1.a6();
  }
}
class Companion_0 {
  c3o() {
    return $serializer_getInstance();
  }
}
class $serializer {
  constructor() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.client.CallToolParams', this, 2);
    tmp0_serialDesc.f25('name', false);
    tmp0_serialDesc.f25('arguments', false);
    this.i63_1 = tmp0_serialDesc;
  }
  j63(encoder, value) {
    var tmp0_desc = this.i63_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.k63_1);
    tmp1_output.i1z(tmp0_desc, 1, JsonObjectSerializer_getInstance(), value.l63_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.j63(encoder, value instanceof CallToolParams ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.i63_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.c1y(tmp0_desc, 1, JsonObjectSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.c1y(tmp0_desc, 1, JsonObjectSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return CallToolParams.m63(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.i63_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), JsonObjectSerializer_getInstance()];
  }
}
class CallToolParams {
  constructor(name, arguments_0) {
    this.k63_1 = name;
    this.l63_1 = arguments_0;
  }
  toString() {
    return 'CallToolParams(name=' + this.k63_1 + ', arguments=' + this.l63_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.k63_1);
    result = imul(result, 31) + this.l63_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CallToolParams))
      return false;
    var tmp0_other_with_cast = other instanceof CallToolParams ? other : THROW_CCE();
    if (!(this.k63_1 === tmp0_other_with_cast.k63_1))
      return false;
    if (!this.l63_1.equals(tmp0_other_with_cast.l63_1))
      return false;
    return true;
  }
  static m63(seen0, name, arguments_0, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance().i63_1);
    }
    var $this = createThis(this);
    $this.k63_1 = name;
    $this.l63_1 = arguments_0;
    return $this;
  }
}
class HttpMcpTransport {
  constructor(httpClient) {
    this.a63_1 = httpClient;
    var tmp = this;
    var tmp_0 = KotlinLogging_instance;
    tmp.b63_1 = tmp_0.g5l(HttpMcpTransport$logger$lambda);
    var tmp_1 = this;
    tmp_1.c63_1 = Json(VOID, HttpMcpTransport$json$lambda);
    this.d63_1 = MutableStateFlow(0);
  }
  e63(method, params, requestSerializer, responseSerializer, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_request__hjt9xh.bind(VOID, this, method, params, requestSerializer, responseSerializer), $completion);
  }
}
class Companion_1 {}
class $serializer_0 {
  constructor() {
    $serializer_instance_0 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitRequest.Params', this, 3);
    tmp0_serialDesc.f25('protocolVersion', false);
    tmp0_serialDesc.f25('capabilities', false);
    tmp0_serialDesc.f25('clientInfo', false);
    this.w63_1 = tmp0_serialDesc;
  }
  x63(encoder, value) {
    var tmp0_desc = this.w63_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.y63_1);
    tmp1_output.i1z(tmp0_desc, 1, $serializer_getInstance_1(), value.z63_1);
    tmp1_output.i1z(tmp0_desc, 2, $serializer_getInstance_4(), value.a64_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.x63(encoder, value instanceof Params ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.w63_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.c1y(tmp0_desc, 1, $serializer_getInstance_1(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, $serializer_getInstance_4(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.c1y(tmp0_desc, 1, $serializer_getInstance_1(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, $serializer_getInstance_4(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return Params.b64(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.w63_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), $serializer_getInstance_1(), $serializer_getInstance_4()];
  }
}
class Companion_2 {}
class $serializer_1 {
  constructor() {
    $serializer_instance_1 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitRequest.Capabilities', this, 2);
    tmp0_serialDesc.f25('roots', false);
    tmp0_serialDesc.f25('sampling', false);
    this.c64_1 = tmp0_serialDesc;
  }
  d64(encoder, value) {
    var tmp0_desc = this.c64_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.i1z(tmp0_desc, 0, $serializer_getInstance_2(), value.e64_1);
    tmp1_output.i1z(tmp0_desc, 1, $serializer_getInstance_3(), value.f64_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.d64(encoder, value instanceof Capabilities ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.c64_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.c1y(tmp0_desc, 0, $serializer_getInstance_2(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.c1y(tmp0_desc, 1, $serializer_getInstance_3(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.c1y(tmp0_desc, 0, $serializer_getInstance_2(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.c1y(tmp0_desc, 1, $serializer_getInstance_3(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return Capabilities.g64(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.c64_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [$serializer_getInstance_2(), $serializer_getInstance_3()];
  }
}
class Companion_3 {}
class $serializer_2 {
  constructor() {
    $serializer_instance_2 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitRequest.Roots', this, 1);
    tmp0_serialDesc.f25('listChanged', false);
    this.h64_1 = tmp0_serialDesc;
  }
  i64(encoder, value) {
    var tmp0_desc = this.h64_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.y1y(tmp0_desc, 0, value.j64_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.i64(encoder, value instanceof Roots ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.h64_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = false;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.s1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.s1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return Roots.k64(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.h64_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [BooleanSerializer_getInstance()];
  }
}
class Companion_4 {}
class $serializer_3 {
  constructor() {
    $serializer_instance_3 = this;
    this.l64_1 = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitRequest.Sampling', this, 0);
  }
  m64(encoder, value) {
    var tmp0_desc = this.l64_1;
    encoder.q1x(tmp0_desc).r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.m64(encoder, value instanceof Sampling ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.l64_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp4_input = decoder.q1x(tmp0_desc);
    if (!tmp4_input.g1y())
      while (tmp1_flag) {
        tmp2_index = tmp4_input.h1y(tmp0_desc);
        if (tmp2_index === -1)
          tmp1_flag = false;
        else
          throw UnknownFieldException.k1v(tmp2_index);
      }
    tmp4_input.r1x(tmp0_desc);
    return Sampling.n64(0, null);
  }
  h1t() {
    return this.l64_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [];
  }
}
class Companion_5 {}
class $serializer_4 {
  constructor() {
    $serializer_instance_4 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitRequest.ClientInfo', this, 2);
    tmp0_serialDesc.f25('name', false);
    tmp0_serialDesc.f25('version', false);
    this.o64_1 = tmp0_serialDesc;
  }
  p64(encoder, value) {
    var tmp0_desc = this.o64_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.q64_1);
    tmp1_output.g1z(tmp0_desc, 1, value.r64_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.p64(encoder, value instanceof ClientInfo ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.o64_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return ClientInfo.s64(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.o64_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance()];
  }
}
class Params {
  toString() {
    return 'Params(protocolVersion=' + this.y63_1 + ', capabilities=' + this.z63_1.toString() + ', clientInfo=' + this.a64_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.y63_1);
    result = imul(result, 31) + this.z63_1.hashCode() | 0;
    result = imul(result, 31) + this.a64_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Params))
      return false;
    var tmp0_other_with_cast = other instanceof Params ? other : THROW_CCE();
    if (!(this.y63_1 === tmp0_other_with_cast.y63_1))
      return false;
    if (!this.z63_1.equals(tmp0_other_with_cast.z63_1))
      return false;
    if (!this.a64_1.equals(tmp0_other_with_cast.a64_1))
      return false;
    return true;
  }
  static b64(seen0, protocolVersion, capabilities, clientInfo, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_0().w63_1);
    }
    var $this = createThis(this);
    $this.y63_1 = protocolVersion;
    $this.z63_1 = capabilities;
    $this.a64_1 = clientInfo;
    return $this;
  }
}
class Capabilities {
  toString() {
    return 'Capabilities(roots=' + this.e64_1.toString() + ', sampling=' + toString(this.f64_1) + ')';
  }
  hashCode() {
    var result = this.e64_1.hashCode();
    result = imul(result, 31) + hashCode(this.f64_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Capabilities))
      return false;
    var tmp0_other_with_cast = other instanceof Capabilities ? other : THROW_CCE();
    if (!this.e64_1.equals(tmp0_other_with_cast.e64_1))
      return false;
    if (!equals(this.f64_1, tmp0_other_with_cast.f64_1))
      return false;
    return true;
  }
  static g64(seen0, roots, sampling, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_1().c64_1);
    }
    var $this = createThis(this);
    $this.e64_1 = roots;
    $this.f64_1 = sampling;
    return $this;
  }
}
class Roots {
  toString() {
    return 'Roots(listChanged=' + this.j64_1 + ')';
  }
  hashCode() {
    return getBooleanHashCode(this.j64_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Roots))
      return false;
    var tmp0_other_with_cast = other instanceof Roots ? other : THROW_CCE();
    if (!(this.j64_1 === tmp0_other_with_cast.j64_1))
      return false;
    return true;
  }
  static k64(seen0, listChanged, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_2().h64_1);
    }
    var $this = createThis(this);
    $this.j64_1 = listChanged;
    return $this;
  }
}
class Sampling {
  static n64(seen0, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_3().l64_1);
    }
    return createThis(this);
  }
}
class ClientInfo {
  toString() {
    return 'ClientInfo(name=' + this.q64_1 + ', version=' + this.r64_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.q64_1);
    result = imul(result, 31) + getStringHashCode(this.r64_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ClientInfo))
      return false;
    var tmp0_other_with_cast = other instanceof ClientInfo ? other : THROW_CCE();
    if (!(this.q64_1 === tmp0_other_with_cast.q64_1))
      return false;
    if (!(this.r64_1 === tmp0_other_with_cast.r64_1))
      return false;
    return true;
  }
  static s64(seen0, name, version, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_4().o64_1);
    }
    var $this = createThis(this);
    $this.q64_1 = name;
    $this.r64_1 = version;
    return $this;
  }
}
class Companion_6 {
  c3o() {
    return $serializer_getInstance_5();
  }
}
class $serializer_5 {
  constructor() {
    $serializer_instance_5 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitRequest', this, 4);
    tmp0_serialDesc.f25('jsonrpc', true);
    tmp0_serialDesc.f25('id', false);
    tmp0_serialDesc.f25('method', true);
    tmp0_serialDesc.f25('params', true);
    this.t64_1 = tmp0_serialDesc;
  }
  u64(encoder, value) {
    var tmp0_desc = this.t64_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.v64_1 === '2.0')) {
      tmp1_output.g1z(tmp0_desc, 0, value.v64_1);
    }
    tmp1_output.b1z(tmp0_desc, 1, value.w64_1);
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.x64_1 === 'initialize')) {
      tmp1_output.g1z(tmp0_desc, 2, value.x64_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.y64_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, $serializer_getInstance_0(), value.y64_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.u64(encoder, value instanceof InitRequest ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.t64_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = 0;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.v1x(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.a1y(tmp0_desc, 2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, $serializer_getInstance_0(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.v1x(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.a1y(tmp0_desc, 2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, $serializer_getInstance_0(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return InitRequest.z64(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.t64_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), IntSerializer_getInstance(), StringSerializer_getInstance(), get_nullable($serializer_getInstance_0())];
  }
}
class InitRequest {
  constructor(jsonrpc, id, method, params) {
    jsonrpc = jsonrpc === VOID ? '2.0' : jsonrpc;
    method = method === VOID ? 'initialize' : method;
    params = params === VOID ? null : params;
    this.v64_1 = jsonrpc;
    this.w64_1 = id;
    this.x64_1 = method;
    this.y64_1 = params;
  }
  toString() {
    return 'InitRequest(jsonrpc=' + this.v64_1 + ', id=' + this.w64_1 + ', method=' + this.x64_1 + ', params=' + toString_0(this.y64_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.v64_1);
    result = imul(result, 31) + this.w64_1 | 0;
    result = imul(result, 31) + getStringHashCode(this.x64_1) | 0;
    result = imul(result, 31) + (this.y64_1 == null ? 0 : this.y64_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof InitRequest))
      return false;
    var tmp0_other_with_cast = other instanceof InitRequest ? other : THROW_CCE();
    if (!(this.v64_1 === tmp0_other_with_cast.v64_1))
      return false;
    if (!(this.w64_1 === tmp0_other_with_cast.w64_1))
      return false;
    if (!(this.x64_1 === tmp0_other_with_cast.x64_1))
      return false;
    if (!equals(this.y64_1, tmp0_other_with_cast.y64_1))
      return false;
    return true;
  }
  static z64(seen0, jsonrpc, id, method, params, serializationConstructorMarker) {
    if (!(2 === (2 & seen0))) {
      throwMissingFieldException(seen0, 2, $serializer_getInstance_5().t64_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.v64_1 = '2.0';
    else
      $this.v64_1 = jsonrpc;
    $this.w64_1 = id;
    if (0 === (seen0 & 4))
      $this.x64_1 = 'initialize';
    else
      $this.x64_1 = method;
    if (0 === (seen0 & 8))
      $this.y64_1 = null;
    else
      $this.y64_1 = params;
    return $this;
  }
}
class Companion_7 {}
class $serializer_6 {
  constructor() {
    $serializer_instance_6 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitResponse.Result', this, 4);
    tmp0_serialDesc.f25('protocolVersion', false);
    tmp0_serialDesc.f25('capabilities', false);
    tmp0_serialDesc.f25('serverInfo', false);
    tmp0_serialDesc.f25('instructions', true);
    this.a65_1 = tmp0_serialDesc;
  }
  b65(encoder, value) {
    var tmp0_desc = this.a65_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.c65_1);
    tmp1_output.i1z(tmp0_desc, 1, $serializer_getInstance_7(), value.d65_1);
    tmp1_output.i1z(tmp0_desc, 2, $serializer_getInstance_12(), value.e65_1);
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.f65_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, StringSerializer_getInstance(), value.f65_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.b65(encoder, value instanceof Result_0 ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.a65_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.c1y(tmp0_desc, 1, $serializer_getInstance_7(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.c1y(tmp0_desc, 2, $serializer_getInstance_12(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.c1y(tmp0_desc, 1, $serializer_getInstance_7(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.c1y(tmp0_desc, 2, $serializer_getInstance_12(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return Result_0.g65(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.a65_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), $serializer_getInstance_7(), $serializer_getInstance_12(), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_8 {}
class $serializer_7 {
  constructor() {
    $serializer_instance_7 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitResponse.Capabilities', this, 4);
    tmp0_serialDesc.f25('logging', false);
    tmp0_serialDesc.f25('prompts', false);
    tmp0_serialDesc.f25('resources', false);
    tmp0_serialDesc.f25('tools', false);
    this.h65_1 = tmp0_serialDesc;
  }
  i65(encoder, value) {
    var tmp0_desc = this.h65_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.i1z(tmp0_desc, 0, $serializer_getInstance_8(), value.j65_1);
    tmp1_output.i1z(tmp0_desc, 1, $serializer_getInstance_9(), value.k65_1);
    tmp1_output.i1z(tmp0_desc, 2, $serializer_getInstance_10(), value.l65_1);
    tmp1_output.i1z(tmp0_desc, 3, $serializer_getInstance_11(), value.m65_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.i65(encoder, value instanceof Capabilities_0 ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.h65_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.c1y(tmp0_desc, 0, $serializer_getInstance_8(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.c1y(tmp0_desc, 1, $serializer_getInstance_9(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.c1y(tmp0_desc, 2, $serializer_getInstance_10(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.c1y(tmp0_desc, 3, $serializer_getInstance_11(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.c1y(tmp0_desc, 0, $serializer_getInstance_8(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.c1y(tmp0_desc, 1, $serializer_getInstance_9(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.c1y(tmp0_desc, 2, $serializer_getInstance_10(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.c1y(tmp0_desc, 3, $serializer_getInstance_11(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return Capabilities_0.n65(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.h65_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [$serializer_getInstance_8(), $serializer_getInstance_9(), $serializer_getInstance_10(), $serializer_getInstance_11()];
  }
}
class Companion_9 {}
class $serializer_8 {
  constructor() {
    $serializer_instance_8 = this;
    this.o65_1 = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitResponse.Logging', this, 0);
  }
  p65(encoder, value) {
    var tmp0_desc = this.o65_1;
    encoder.q1x(tmp0_desc).r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.p65(encoder, value instanceof Logging ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.o65_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp4_input = decoder.q1x(tmp0_desc);
    if (!tmp4_input.g1y())
      while (tmp1_flag) {
        tmp2_index = tmp4_input.h1y(tmp0_desc);
        if (tmp2_index === -1)
          tmp1_flag = false;
        else
          throw UnknownFieldException.k1v(tmp2_index);
      }
    tmp4_input.r1x(tmp0_desc);
    return Logging.q65(0, null);
  }
  h1t() {
    return this.o65_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [];
  }
}
class Companion_10 {}
class $serializer_9 {
  constructor() {
    $serializer_instance_9 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitResponse.Prompts', this, 1);
    tmp0_serialDesc.f25('listChanged', false);
    this.r65_1 = tmp0_serialDesc;
  }
  s65(encoder, value) {
    var tmp0_desc = this.r65_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.y1y(tmp0_desc, 0, value.t65_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.s65(encoder, value instanceof Prompts ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.r65_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = false;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.s1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.s1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return Prompts.u65(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.r65_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [BooleanSerializer_getInstance()];
  }
}
class Companion_11 {}
class $serializer_10 {
  constructor() {
    $serializer_instance_10 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitResponse.Resources', this, 2);
    tmp0_serialDesc.f25('subscribe', false);
    tmp0_serialDesc.f25('listChanged', false);
    this.v65_1 = tmp0_serialDesc;
  }
  w65(encoder, value) {
    var tmp0_desc = this.v65_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.y1y(tmp0_desc, 0, value.x65_1);
    tmp1_output.y1y(tmp0_desc, 1, value.y65_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.w65(encoder, value instanceof Resources ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.v65_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = false;
    var tmp5_local1 = false;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.s1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.s1x(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.s1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.s1x(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return Resources.z65(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.v65_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [BooleanSerializer_getInstance(), BooleanSerializer_getInstance()];
  }
}
class Companion_12 {}
class $serializer_11 {
  constructor() {
    $serializer_instance_11 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitResponse.Tools', this, 1);
    tmp0_serialDesc.f25('listChanged', false);
    this.a66_1 = tmp0_serialDesc;
  }
  b66(encoder, value) {
    var tmp0_desc = this.a66_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.y1y(tmp0_desc, 0, value.c66_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.b66(encoder, value instanceof Tools ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.a66_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = false;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.s1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.s1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return Tools.d66(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.a66_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [BooleanSerializer_getInstance()];
  }
}
class Companion_13 {}
class $serializer_12 {
  constructor() {
    $serializer_instance_12 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitResponse.ServerInfo', this, 2);
    tmp0_serialDesc.f25('name', false);
    tmp0_serialDesc.f25('version', false);
    this.e66_1 = tmp0_serialDesc;
  }
  f66(encoder, value) {
    var tmp0_desc = this.e66_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.g66_1);
    tmp1_output.g1z(tmp0_desc, 1, value.h66_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.f66(encoder, value instanceof ServerInfo ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.e66_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return ServerInfo.i66(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.e66_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance()];
  }
}
class Result_0 {
  toString() {
    return 'Result(protocolVersion=' + this.c65_1 + ', capabilities=' + this.d65_1.toString() + ', serverInfo=' + this.e65_1.toString() + ', instructions=' + this.f65_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.c65_1);
    result = imul(result, 31) + this.d65_1.hashCode() | 0;
    result = imul(result, 31) + this.e65_1.hashCode() | 0;
    result = imul(result, 31) + (this.f65_1 == null ? 0 : getStringHashCode(this.f65_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Result_0))
      return false;
    var tmp0_other_with_cast = other instanceof Result_0 ? other : THROW_CCE();
    if (!(this.c65_1 === tmp0_other_with_cast.c65_1))
      return false;
    if (!this.d65_1.equals(tmp0_other_with_cast.d65_1))
      return false;
    if (!this.e65_1.equals(tmp0_other_with_cast.e65_1))
      return false;
    if (!(this.f65_1 == tmp0_other_with_cast.f65_1))
      return false;
    return true;
  }
  static g65(seen0, protocolVersion, capabilities, serverInfo, instructions, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_6().a65_1);
    }
    var $this = createThis(this);
    $this.c65_1 = protocolVersion;
    $this.d65_1 = capabilities;
    $this.e65_1 = serverInfo;
    if (0 === (seen0 & 8))
      $this.f65_1 = null;
    else
      $this.f65_1 = instructions;
    return $this;
  }
}
class Capabilities_0 {
  toString() {
    return 'Capabilities(logging=' + toString(this.j65_1) + ', prompts=' + this.k65_1.toString() + ', resources=' + this.l65_1.toString() + ', tools=' + this.m65_1.toString() + ')';
  }
  hashCode() {
    var result = hashCode(this.j65_1);
    result = imul(result, 31) + this.k65_1.hashCode() | 0;
    result = imul(result, 31) + this.l65_1.hashCode() | 0;
    result = imul(result, 31) + this.m65_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Capabilities_0))
      return false;
    var tmp0_other_with_cast = other instanceof Capabilities_0 ? other : THROW_CCE();
    if (!equals(this.j65_1, tmp0_other_with_cast.j65_1))
      return false;
    if (!this.k65_1.equals(tmp0_other_with_cast.k65_1))
      return false;
    if (!this.l65_1.equals(tmp0_other_with_cast.l65_1))
      return false;
    if (!this.m65_1.equals(tmp0_other_with_cast.m65_1))
      return false;
    return true;
  }
  static n65(seen0, logging, prompts, resources, tools, serializationConstructorMarker) {
    if (!(15 === (15 & seen0))) {
      throwMissingFieldException(seen0, 15, $serializer_getInstance_7().h65_1);
    }
    var $this = createThis(this);
    $this.j65_1 = logging;
    $this.k65_1 = prompts;
    $this.l65_1 = resources;
    $this.m65_1 = tools;
    return $this;
  }
}
class Logging {
  static q65(seen0, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_8().o65_1);
    }
    return createThis(this);
  }
}
class Prompts {
  toString() {
    return 'Prompts(listChanged=' + this.t65_1 + ')';
  }
  hashCode() {
    return getBooleanHashCode(this.t65_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Prompts))
      return false;
    var tmp0_other_with_cast = other instanceof Prompts ? other : THROW_CCE();
    if (!(this.t65_1 === tmp0_other_with_cast.t65_1))
      return false;
    return true;
  }
  static u65(seen0, listChanged, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_9().r65_1);
    }
    var $this = createThis(this);
    $this.t65_1 = listChanged;
    return $this;
  }
}
class Resources {
  toString() {
    return 'Resources(subscribe=' + this.x65_1 + ', listChanged=' + this.y65_1 + ')';
  }
  hashCode() {
    var result = getBooleanHashCode(this.x65_1);
    result = imul(result, 31) + getBooleanHashCode(this.y65_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Resources))
      return false;
    var tmp0_other_with_cast = other instanceof Resources ? other : THROW_CCE();
    if (!(this.x65_1 === tmp0_other_with_cast.x65_1))
      return false;
    if (!(this.y65_1 === tmp0_other_with_cast.y65_1))
      return false;
    return true;
  }
  static z65(seen0, subscribe, listChanged, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_10().v65_1);
    }
    var $this = createThis(this);
    $this.x65_1 = subscribe;
    $this.y65_1 = listChanged;
    return $this;
  }
}
class Tools {
  toString() {
    return 'Tools(listChanged=' + this.c66_1 + ')';
  }
  hashCode() {
    return getBooleanHashCode(this.c66_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Tools))
      return false;
    var tmp0_other_with_cast = other instanceof Tools ? other : THROW_CCE();
    if (!(this.c66_1 === tmp0_other_with_cast.c66_1))
      return false;
    return true;
  }
  static d66(seen0, listChanged, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_11().a66_1);
    }
    var $this = createThis(this);
    $this.c66_1 = listChanged;
    return $this;
  }
}
class ServerInfo {
  toString() {
    return 'ServerInfo(name=' + this.g66_1 + ', version=' + this.h66_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.g66_1);
    result = imul(result, 31) + getStringHashCode(this.h66_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ServerInfo))
      return false;
    var tmp0_other_with_cast = other instanceof ServerInfo ? other : THROW_CCE();
    if (!(this.g66_1 === tmp0_other_with_cast.g66_1))
      return false;
    if (!(this.h66_1 === tmp0_other_with_cast.h66_1))
      return false;
    return true;
  }
  static i66(seen0, name, version, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_12().e66_1);
    }
    var $this = createThis(this);
    $this.g66_1 = name;
    $this.h66_1 = version;
    return $this;
  }
}
class Companion_14 {
  c3o() {
    return $serializer_getInstance_13();
  }
}
class $serializer_13 {
  constructor() {
    $serializer_instance_13 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitResponse', this, 4);
    tmp0_serialDesc.f25('jsonrpc', true);
    tmp0_serialDesc.f25('id', true);
    tmp0_serialDesc.f25('result', true);
    tmp0_serialDesc.f25('error', true);
    this.j66_1 = tmp0_serialDesc;
  }
  k66(encoder, value) {
    var tmp0_desc = this.j66_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.m62_1 === '2.0')) {
      tmp1_output.g1z(tmp0_desc, 0, value.m62_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.n62_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, IntSerializer_getInstance(), value.n62_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.o62_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, $serializer_getInstance_6(), value.o62_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.p62_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, $serializer_getInstance_16(), value.p62_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.k66(encoder, value instanceof InitResponse ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.j66_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, $serializer_getInstance_6(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, $serializer_getInstance_16(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, $serializer_getInstance_6(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, $serializer_getInstance_16(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return InitResponse.l66(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.j66_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), get_nullable(IntSerializer_getInstance()), get_nullable($serializer_getInstance_6()), get_nullable($serializer_getInstance_16())];
  }
}
class InitResponse {
  constructor(jsonrpc, id, result, error) {
    jsonrpc = jsonrpc === VOID ? '2.0' : jsonrpc;
    id = id === VOID ? null : id;
    result = result === VOID ? null : result;
    error = error === VOID ? null : error;
    this.m62_1 = jsonrpc;
    this.n62_1 = id;
    this.o62_1 = result;
    this.p62_1 = error;
  }
  toString() {
    return 'InitResponse(jsonrpc=' + this.m62_1 + ', id=' + this.n62_1 + ', result=' + toString_0(this.o62_1) + ', error=' + toString_0(this.p62_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.m62_1);
    result = imul(result, 31) + (this.n62_1 == null ? 0 : this.n62_1) | 0;
    result = imul(result, 31) + (this.o62_1 == null ? 0 : this.o62_1.hashCode()) | 0;
    result = imul(result, 31) + (this.p62_1 == null ? 0 : this.p62_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof InitResponse))
      return false;
    var tmp0_other_with_cast = other instanceof InitResponse ? other : THROW_CCE();
    if (!(this.m62_1 === tmp0_other_with_cast.m62_1))
      return false;
    if (!(this.n62_1 == tmp0_other_with_cast.n62_1))
      return false;
    if (!equals(this.o62_1, tmp0_other_with_cast.o62_1))
      return false;
    if (!equals(this.p62_1, tmp0_other_with_cast.p62_1))
      return false;
    return true;
  }
  static l66(seen0, jsonrpc, id, result, error, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_13().j66_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.m62_1 = '2.0';
    else
      $this.m62_1 = jsonrpc;
    if (0 === (seen0 & 2))
      $this.n62_1 = null;
    else
      $this.n62_1 = id;
    if (0 === (seen0 & 4))
      $this.o62_1 = null;
    else
      $this.o62_1 = result;
    if (0 === (seen0 & 8))
      $this.p62_1 = null;
    else
      $this.p62_1 = error;
    return $this;
  }
}
class Companion_15 {
  c3o() {
    return $serializer_getInstance_14();
  }
}
class $serializer_14 {
  constructor() {
    $serializer_instance_14 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.InitializedRequest', this, 2);
    tmp0_serialDesc.f25('jsonrpc', true);
    tmp0_serialDesc.f25('method', true);
    this.m66_1 = tmp0_serialDesc;
  }
  n66(encoder, value) {
    var tmp0_desc = this.m66_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.o66_1 === '2.0')) {
      tmp1_output.g1z(tmp0_desc, 0, value.o66_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.p66_1 === 'notifications/initialized')) {
      tmp1_output.g1z(tmp0_desc, 1, value.p66_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.n66(encoder, value instanceof InitializedRequest ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.m66_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return InitializedRequest.q66(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.m66_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance()];
  }
}
class InitializedRequest {
  constructor(jsonrpc, method) {
    jsonrpc = jsonrpc === VOID ? '2.0' : jsonrpc;
    method = method === VOID ? 'notifications/initialized' : method;
    this.o66_1 = jsonrpc;
    this.p66_1 = method;
  }
  toString() {
    return 'InitializedRequest(jsonrpc=' + this.o66_1 + ', method=' + this.p66_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.o66_1);
    result = imul(result, 31) + getStringHashCode(this.p66_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof InitializedRequest))
      return false;
    var tmp0_other_with_cast = other instanceof InitializedRequest ? other : THROW_CCE();
    if (!(this.o66_1 === tmp0_other_with_cast.o66_1))
      return false;
    if (!(this.p66_1 === tmp0_other_with_cast.p66_1))
      return false;
    return true;
  }
  static q66(seen0, jsonrpc, method, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_14().m66_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.o66_1 = '2.0';
    else
      $this.o66_1 = jsonrpc;
    if (0 === (seen0 & 2))
      $this.p66_1 = 'notifications/initialized';
    else
      $this.p66_1 = method;
    return $this;
  }
}
class McpClientConfig {
  constructor(id) {
    this.k62_1 = id;
  }
  toString() {
    return 'McpClientConfig(id=' + this.k62_1 + ')';
  }
  hashCode() {
    return this.k62_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof McpClientConfig))
      return false;
    var tmp0_other_with_cast = other instanceof McpClientConfig ? other : THROW_CCE();
    if (!(this.k62_1 === tmp0_other_with_cast.k62_1))
      return false;
    return true;
  }
}
class Companion_16 {
  constructor() {
    Companion_instance_18 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.r66_1 = [lazy(tmp_0, McpError$Data$Companion$$childSerializers$_anonymous__pzfn0q), null];
  }
}
class $serializer_15 {
  constructor() {
    $serializer_instance_15 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.McpError.Data', this, 2);
    tmp0_serialDesc.f25('supported', false);
    tmp0_serialDesc.f25('requested', false);
    this.s66_1 = tmp0_serialDesc;
  }
  t66(encoder, value) {
    var tmp0_desc = this.s66_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    var tmp2_cached = Companion_getInstance_22().r66_1;
    tmp1_output.i1z(tmp0_desc, 0, tmp2_cached[0].n1(), value.u66_1);
    tmp1_output.g1z(tmp0_desc, 1, value.v66_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.t66(encoder, value instanceof Data ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.s66_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    var tmp7_cached = Companion_getInstance_22().r66_1;
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.c1y(tmp0_desc, 0, tmp7_cached[0].n1(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.c1y(tmp0_desc, 0, tmp7_cached[0].n1(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return Data.w66(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.s66_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [Companion_getInstance_22().r66_1[0].n1(), StringSerializer_getInstance()];
  }
}
class Data {
  toString() {
    return 'Data(supported=' + toString(this.u66_1) + ', requested=' + this.v66_1 + ')';
  }
  hashCode() {
    var result = hashCode(this.u66_1);
    result = imul(result, 31) + getStringHashCode(this.v66_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Data))
      return false;
    var tmp0_other_with_cast = other instanceof Data ? other : THROW_CCE();
    if (!equals(this.u66_1, tmp0_other_with_cast.u66_1))
      return false;
    if (!(this.v66_1 === tmp0_other_with_cast.v66_1))
      return false;
    return true;
  }
  static w66(seen0, supported, requested, serializationConstructorMarker) {
    Companion_getInstance_22();
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_15().s66_1);
    }
    var $this = createThis(this);
    $this.u66_1 = supported;
    $this.v66_1 = requested;
    return $this;
  }
}
class Companion_17 {}
class $serializer_16 {
  constructor() {
    $serializer_instance_16 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.McpError', this, 3);
    tmp0_serialDesc.f25('code', false);
    tmp0_serialDesc.f25('message', false);
    tmp0_serialDesc.f25('data', false);
    this.x66_1 = tmp0_serialDesc;
  }
  y66(encoder, value) {
    var tmp0_desc = this.x66_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.b1z(tmp0_desc, 0, value.q62_1);
    tmp1_output.g1z(tmp0_desc, 1, value.r62_1);
    tmp1_output.i1z(tmp0_desc, 2, $serializer_getInstance_15(), value.s62_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.y66(encoder, value instanceof McpError ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.x66_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = 0;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.v1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, $serializer_getInstance_15(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.v1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, $serializer_getInstance_15(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return McpError.z66(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.x66_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [IntSerializer_getInstance(), StringSerializer_getInstance(), $serializer_getInstance_15()];
  }
}
class McpError {
  toString() {
    return 'McpError(code=' + this.q62_1 + ', message=' + this.r62_1 + ', data=' + this.s62_1.toString() + ')';
  }
  hashCode() {
    var result = this.q62_1;
    result = imul(result, 31) + getStringHashCode(this.r62_1) | 0;
    result = imul(result, 31) + this.s62_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof McpError))
      return false;
    var tmp0_other_with_cast = other instanceof McpError ? other : THROW_CCE();
    if (!(this.q62_1 === tmp0_other_with_cast.q62_1))
      return false;
    if (!(this.r62_1 === tmp0_other_with_cast.r62_1))
      return false;
    if (!this.s62_1.equals(tmp0_other_with_cast.s62_1))
      return false;
    return true;
  }
  static z66(seen0, code, message, data, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_16().x66_1);
    }
    var $this = createThis(this);
    $this.q62_1 = code;
    $this.r62_1 = message;
    $this.s62_1 = data;
    return $this;
  }
}
class Companion_18 {}
class $serializer_17 {
  constructor() {
    $serializer_instance_17 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.McpTool', this, 3);
    tmp0_serialDesc.f25('name', false);
    tmp0_serialDesc.f25('description', true);
    tmp0_serialDesc.f25('inputSchema', true);
    this.a67_1 = tmp0_serialDesc;
  }
  b67(encoder, value) {
    var tmp0_desc = this.a67_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.o61_1);
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.p61_1 === '')) {
      tmp1_output.g1z(tmp0_desc, 1, value.p61_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.q61_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, JsonObjectSerializer_getInstance(), value.q61_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.b67(encoder, value instanceof McpTool ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.a67_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.e1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.e1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return McpTool.c67(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.a67_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(JsonObjectSerializer_getInstance())];
  }
}
class McpTool {
  constructor(name, description, inputSchema) {
    description = description === VOID ? '' : description;
    inputSchema = inputSchema === VOID ? null : inputSchema;
    this.o61_1 = name;
    this.p61_1 = description;
    this.q61_1 = inputSchema;
  }
  toString() {
    return 'McpTool(name=' + this.o61_1 + ', description=' + this.p61_1 + ', inputSchema=' + toString_0(this.q61_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.o61_1);
    result = imul(result, 31) + getStringHashCode(this.p61_1) | 0;
    result = imul(result, 31) + (this.q61_1 == null ? 0 : this.q61_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof McpTool))
      return false;
    var tmp0_other_with_cast = other instanceof McpTool ? other : THROW_CCE();
    if (!(this.o61_1 === tmp0_other_with_cast.o61_1))
      return false;
    if (!(this.p61_1 === tmp0_other_with_cast.p61_1))
      return false;
    if (!equals(this.q61_1, tmp0_other_with_cast.q61_1))
      return false;
    return true;
  }
  static c67(seen0, name, description, inputSchema, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_17().a67_1);
    }
    var $this = createThis(this);
    $this.o61_1 = name;
    if (0 === (seen0 & 2))
      $this.p61_1 = '';
    else
      $this.p61_1 = description;
    if (0 === (seen0 & 4))
      $this.q61_1 = null;
    else
      $this.q61_1 = inputSchema;
    return $this;
  }
}
class Companion_19 {
  constructor() {
    Companion_instance_21 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.z62_1 = [lazy(tmp_0, ListToolsResult$Companion$$childSerializers$_anonymous__opdre8)];
  }
  c3o() {
    return $serializer_getInstance_18();
  }
}
class $serializer_18 {
  constructor() {
    $serializer_instance_18 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.ListToolsResult', this, 1);
    tmp0_serialDesc.f25('tools', true);
    this.d67_1 = tmp0_serialDesc;
  }
  e67(encoder, value) {
    var tmp0_desc = this.d67_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    var tmp2_cached = Companion_getInstance_25().z62_1;
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !equals(value.f63_1, emptyList())) {
      tmp1_output.i1z(tmp0_desc, 0, tmp2_cached[0].n1(), value.f63_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.e67(encoder, value instanceof ListToolsResult ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.d67_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.q1x(tmp0_desc);
    var tmp6_cached = Companion_getInstance_25().z62_1;
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.c1y(tmp0_desc, 0, tmp6_cached[0].n1(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.c1y(tmp0_desc, 0, tmp6_cached[0].n1(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return ListToolsResult.f67(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.d67_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [Companion_getInstance_25().z62_1[0].n1()];
  }
}
class ListToolsResult {
  constructor(tools) {
    Companion_getInstance_25();
    tools = tools === VOID ? emptyList() : tools;
    this.f63_1 = tools;
  }
  toString() {
    return 'ListToolsResult(tools=' + toString(this.f63_1) + ')';
  }
  hashCode() {
    return hashCode(this.f63_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ListToolsResult))
      return false;
    var tmp0_other_with_cast = other instanceof ListToolsResult ? other : THROW_CCE();
    if (!equals(this.f63_1, tmp0_other_with_cast.f63_1))
      return false;
    return true;
  }
  static f67(seen0, tools, serializationConstructorMarker) {
    Companion_getInstance_25();
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_18().d67_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.f63_1 = emptyList();
    else
      $this.f63_1 = tools;
    return $this;
  }
}
class Companion_20 {
  c3o() {
    return $serializer_getInstance_19();
  }
}
class $serializer_19 {
  constructor() {
    $serializer_instance_19 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.ToolResponse', this, 1);
    tmp0_serialDesc.f25('result', false);
    this.g67_1 = tmp0_serialDesc;
  }
  h67(encoder, value) {
    var tmp0_desc = this.g67_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.i1z(tmp0_desc, 0, JsonElementSerializer_getInstance(), value.h63_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.h67(encoder, value instanceof ToolResponse ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.g67_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.c1y(tmp0_desc, 0, JsonElementSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.c1y(tmp0_desc, 0, JsonElementSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return ToolResponse.i67(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.g67_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [JsonElementSerializer_getInstance()];
  }
}
class ToolResponse {
  toString() {
    return 'ToolResponse(result=' + toString(this.h63_1) + ')';
  }
  hashCode() {
    return hashCode(this.h63_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolResponse))
      return false;
    var tmp0_other_with_cast = other instanceof ToolResponse ? other : THROW_CCE();
    if (!equals(this.h63_1, tmp0_other_with_cast.h63_1))
      return false;
    return true;
  }
  static i67(seen0, result, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_19().g67_1);
    }
    var $this = createThis(this);
    $this.h63_1 = result;
    return $this;
  }
}
class Companion_21 {
  c3o() {
    return $serializer_getInstance_20();
  }
}
class $serializer_20 {
  constructor() {
    $serializer_instance_20 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.RpcEnvelope', this, 4);
    tmp0_serialDesc.f25('jsonrpc', true);
    tmp0_serialDesc.f25('id', true);
    tmp0_serialDesc.f25('method', false);
    tmp0_serialDesc.f25('params', true);
    this.j67_1 = tmp0_serialDesc;
  }
  k67(encoder, value) {
    var tmp0_desc = this.j67_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.l67_1 === '2.0')) {
      tmp1_output.g1z(tmp0_desc, 0, value.l67_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.m67_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, IntSerializer_getInstance(), value.m67_1);
    }
    tmp1_output.g1z(tmp0_desc, 2, value.n67_1);
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.o67_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, JsonElementSerializer_getInstance(), value.o67_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.k67(encoder, value instanceof RpcEnvelope ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.j67_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.a1y(tmp0_desc, 2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, JsonElementSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.a1y(tmp0_desc, 2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, JsonElementSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return RpcEnvelope.p67(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.j67_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), get_nullable(IntSerializer_getInstance()), StringSerializer_getInstance(), get_nullable(JsonElementSerializer_getInstance())];
  }
}
class RpcEnvelope {
  constructor(jsonrpc, id, method, params) {
    jsonrpc = jsonrpc === VOID ? '2.0' : jsonrpc;
    id = id === VOID ? null : id;
    params = params === VOID ? null : params;
    this.l67_1 = jsonrpc;
    this.m67_1 = id;
    this.n67_1 = method;
    this.o67_1 = params;
  }
  toString() {
    return 'RpcEnvelope(jsonrpc=' + this.l67_1 + ', id=' + this.m67_1 + ', method=' + this.n67_1 + ', params=' + toString_0(this.o67_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.l67_1);
    result = imul(result, 31) + (this.m67_1 == null ? 0 : this.m67_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.n67_1) | 0;
    result = imul(result, 31) + (this.o67_1 == null ? 0 : hashCode(this.o67_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RpcEnvelope))
      return false;
    var tmp0_other_with_cast = other instanceof RpcEnvelope ? other : THROW_CCE();
    if (!(this.l67_1 === tmp0_other_with_cast.l67_1))
      return false;
    if (!(this.m67_1 == tmp0_other_with_cast.m67_1))
      return false;
    if (!(this.n67_1 === tmp0_other_with_cast.n67_1))
      return false;
    if (!equals(this.o67_1, tmp0_other_with_cast.o67_1))
      return false;
    return true;
  }
  static p67(seen0, jsonrpc, id, method, params, serializationConstructorMarker) {
    if (!(4 === (4 & seen0))) {
      throwMissingFieldException(seen0, 4, $serializer_getInstance_20().j67_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.l67_1 = '2.0';
    else
      $this.l67_1 = jsonrpc;
    if (0 === (seen0 & 2))
      $this.m67_1 = null;
    else
      $this.m67_1 = id;
    $this.n67_1 = method;
    if (0 === (seen0 & 8))
      $this.o67_1 = null;
    else
      $this.o67_1 = params;
    return $this;
  }
}
class Companion_22 {
  constructor() {
    Companion_instance_24 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.RpcResponse', null, 4);
    tmp0_serialDesc.f25('jsonrpc', true);
    tmp0_serialDesc.f25('id', true);
    tmp0_serialDesc.f25('result', true);
    tmp0_serialDesc.f25('error', true);
    this.n63_1 = tmp0_serialDesc;
  }
  o63(typeSerial0) {
    return $serializer_21.s67(typeSerial0);
  }
  g26(typeParamsSerializers) {
    return this.o63(typeParamsSerializers[0]);
  }
}
class $serializer_21 {
  static t67() {
    var $this = createThis(this);
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.RpcResponse', $this, 4);
    tmp0_serialDesc.f25('jsonrpc', true);
    tmp0_serialDesc.f25('id', true);
    tmp0_serialDesc.f25('result', true);
    tmp0_serialDesc.f25('error', true);
    $this.q67_1 = tmp0_serialDesc;
    return $this;
  }
  u67(encoder, value) {
    var tmp0_desc = this.q67_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.s63_1 === '2.0')) {
      tmp1_output.g1z(tmp0_desc, 0, value.s63_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.t63_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, IntSerializer_getInstance(), value.t63_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.u63_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, this.r67_1, value.u63_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.v63_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, $serializer_getInstance_21(), value.v63_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.u67(encoder, value instanceof RpcResponse ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.q67_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, this.r67_1, tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, $serializer_getInstance_21(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, this.r67_1, tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, $serializer_getInstance_21(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return RpcResponse.v67(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.q67_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), get_nullable(IntSerializer_getInstance()), get_nullable(this.r67_1), get_nullable($serializer_getInstance_21())];
  }
  v25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [this.r67_1];
  }
  static s67(typeSerial0) {
    var $this = this.t67();
    $this.r67_1 = typeSerial0;
    return $this;
  }
}
class RpcResponse {
  constructor(jsonrpc, id, result, error) {
    Companion_getInstance_28();
    jsonrpc = jsonrpc === VOID ? '2.0' : jsonrpc;
    id = id === VOID ? null : id;
    result = result === VOID ? null : result;
    error = error === VOID ? null : error;
    this.s63_1 = jsonrpc;
    this.t63_1 = id;
    this.u63_1 = result;
    this.v63_1 = error;
  }
  toString() {
    return 'RpcResponse(jsonrpc=' + this.s63_1 + ', id=' + this.t63_1 + ', result=' + toString_0(this.u63_1) + ', error=' + toString_0(this.v63_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.s63_1);
    result = imul(result, 31) + (this.t63_1 == null ? 0 : this.t63_1) | 0;
    result = imul(result, 31) + (this.u63_1 == null ? 0 : hashCode(this.u63_1)) | 0;
    result = imul(result, 31) + (this.v63_1 == null ? 0 : this.v63_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RpcResponse))
      return false;
    var tmp0_other_with_cast = other instanceof RpcResponse ? other : THROW_CCE();
    if (!(this.s63_1 === tmp0_other_with_cast.s63_1))
      return false;
    if (!(this.t63_1 == tmp0_other_with_cast.t63_1))
      return false;
    if (!equals(this.u63_1, tmp0_other_with_cast.u63_1))
      return false;
    if (!equals(this.v63_1, tmp0_other_with_cast.v63_1))
      return false;
    return true;
  }
  static v67(seen0, jsonrpc, id, result, error, serializationConstructorMarker) {
    Companion_getInstance_28();
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, Companion_getInstance_28().n63_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.s63_1 = '2.0';
    else
      $this.s63_1 = jsonrpc;
    if (0 === (seen0 & 2))
      $this.t63_1 = null;
    else
      $this.t63_1 = id;
    if (0 === (seen0 & 4))
      $this.u63_1 = null;
    else
      $this.u63_1 = result;
    if (0 === (seen0 & 8))
      $this.v63_1 = null;
    else
      $this.v63_1 = error;
    return $this;
  }
}
class Companion_23 {}
class $serializer_22 {
  constructor() {
    $serializer_instance_21 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.mcp.entity.RpcError', this, 3);
    tmp0_serialDesc.f25('code', false);
    tmp0_serialDesc.f25('message', false);
    tmp0_serialDesc.f25('data', true);
    this.w67_1 = tmp0_serialDesc;
  }
  x67(encoder, value) {
    var tmp0_desc = this.w67_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.b1z(tmp0_desc, 0, value.p63_1);
    tmp1_output.g1z(tmp0_desc, 1, value.q63_1);
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.r63_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, JsonElementSerializer_getInstance(), value.r63_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.x67(encoder, value instanceof RpcError ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.w67_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = 0;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.v1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.e1y(tmp0_desc, 2, JsonElementSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.v1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.e1y(tmp0_desc, 2, JsonElementSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return RpcError.y67(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.w67_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [IntSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(JsonElementSerializer_getInstance())];
  }
}
class RpcError {
  toString() {
    return 'RpcError(code=' + this.p63_1 + ', message=' + this.q63_1 + ', data=' + toString_0(this.r63_1) + ')';
  }
  hashCode() {
    var result = this.p63_1;
    result = imul(result, 31) + getStringHashCode(this.q63_1) | 0;
    result = imul(result, 31) + (this.r63_1 == null ? 0 : hashCode(this.r63_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RpcError))
      return false;
    var tmp0_other_with_cast = other instanceof RpcError ? other : THROW_CCE();
    if (!(this.p63_1 === tmp0_other_with_cast.p63_1))
      return false;
    if (!(this.q63_1 === tmp0_other_with_cast.q63_1))
      return false;
    if (!equals(this.r63_1, tmp0_other_with_cast.r63_1))
      return false;
    return true;
  }
  static y67(seen0, code, message, data, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_21().w67_1);
    }
    var $this = createThis(this);
    $this.p63_1 = code;
    $this.q63_1 = message;
    if (0 === (seen0 & 4))
      $this.r63_1 = null;
    else
      $this.r63_1 = data;
    return $this;
  }
}
class TurnRetention extends Enum {}
class ConversationTurn {
  constructor(id, status, items, checkpoint, usage) {
    checkpoint = checkpoint === VOID ? null : checkpoint;
    usage = usage === VOID ? Companion_getInstance_43().t5r_1 : usage;
    this.z67_1 = id;
    this.a68_1 = status;
    this.b68_1 = items;
    this.c68_1 = checkpoint;
    this.d68_1 = usage;
  }
  e68(id, status, items, checkpoint, usage) {
    return new ConversationTurn(id, status, items, checkpoint, usage);
  }
  f68(id, status, items, checkpoint, usage, $super) {
    id = id === VOID ? this.z67_1 : id;
    status = status === VOID ? this.a68_1 : status;
    items = items === VOID ? this.b68_1 : items;
    checkpoint = checkpoint === VOID ? this.c68_1 : checkpoint;
    usage = usage === VOID ? this.d68_1 : usage;
    return $super === VOID ? this.e68(id, status, items, checkpoint, usage) : $super.e68.call(this, id, status, items, checkpoint, usage);
  }
  toString() {
    return 'ConversationTurn(id=' + this.z67_1 + ', status=' + toString(this.a68_1) + ', items=' + toString(this.b68_1) + ', checkpoint=' + toString_0(this.c68_1) + ', usage=' + this.d68_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.z67_1);
    result = imul(result, 31) + hashCode(this.a68_1) | 0;
    result = imul(result, 31) + hashCode(this.b68_1) | 0;
    result = imul(result, 31) + (this.c68_1 == null ? 0 : this.c68_1.hashCode()) | 0;
    result = imul(result, 31) + this.d68_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ConversationTurn))
      return false;
    var tmp0_other_with_cast = other instanceof ConversationTurn ? other : THROW_CCE();
    if (!(this.z67_1 === tmp0_other_with_cast.z67_1))
      return false;
    if (!equals(this.a68_1, tmp0_other_with_cast.a68_1))
      return false;
    if (!equals(this.b68_1, tmp0_other_with_cast.b68_1))
      return false;
    if (!equals(this.c68_1, tmp0_other_with_cast.c68_1))
      return false;
    if (!this.d68_1.equals(tmp0_other_with_cast.d68_1))
      return false;
    return true;
  }
}
class Completed_1 {
  toString() {
    return 'Completed';
  }
  hashCode() {
    return 1884807990;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Completed_1))
      return false;
    other instanceof Completed_1 || THROW_CCE();
    return true;
  }
}
class Interrupted {
  constructor(reason, pending) {
    this.g68_1 = reason;
    this.h68_1 = pending;
  }
  toString() {
    return 'Interrupted(reason=' + toString(this.g68_1) + ', pending=' + this.h68_1.toString() + ')';
  }
  hashCode() {
    var result = hashCode(this.g68_1);
    result = imul(result, 31) + this.h68_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Interrupted))
      return false;
    var tmp0_other_with_cast = other instanceof Interrupted ? other : THROW_CCE();
    if (!equals(this.g68_1, tmp0_other_with_cast.g68_1))
      return false;
    if (!this.h68_1.equals(tmp0_other_with_cast.h68_1))
      return false;
    return true;
  }
}
class Cancelled {
  toString() {
    return 'Cancelled';
  }
  hashCode() {
    return 889062240;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Cancelled))
      return false;
    other instanceof Cancelled || THROW_CCE();
    return true;
  }
}
class Failed_2 {
  toString() {
    return 'Failed';
  }
  hashCode() {
    return 805473422;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Failed_2))
      return false;
    other instanceof Failed_2 || THROW_CCE();
    return true;
  }
}
class Incomplete_1 {
  constructor(reason) {
    this.i68_1 = reason;
  }
  toString() {
    return 'Incomplete(reason=' + toString(this.i68_1) + ')';
  }
  hashCode() {
    return hashCode(this.i68_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Incomplete_1))
      return false;
    var tmp0_other_with_cast = other instanceof Incomplete_1 ? other : THROW_CCE();
    if (!equals(this.i68_1, tmp0_other_with_cast.i68_1))
      return false;
    return true;
  }
}
class Policy {
  constructor(detail) {
    this.j68_1 = detail;
  }
  toString() {
    return 'Policy(detail=' + this.j68_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.j68_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Policy))
      return false;
    var tmp0_other_with_cast = other instanceof Policy ? other : THROW_CCE();
    if (!(this.j68_1 === tmp0_other_with_cast.j68_1))
      return false;
    return true;
  }
}
class PendingWork {
  constructor(unresolvedCalls, partialText, partialItem) {
    unresolvedCalls = unresolvedCalls === VOID ? emptyList() : unresolvedCalls;
    partialText = partialText === VOID ? null : partialText;
    partialItem = partialItem === VOID ? null : partialItem;
    this.k68_1 = unresolvedCalls;
    this.l68_1 = partialText;
    this.m68_1 = partialItem;
  }
  toString() {
    var tmp = toString(this.k68_1);
    var tmp_0 = this.m68_1;
    return 'PendingWork(unresolvedCalls=' + tmp + ', partialText=' + this.l68_1 + ', partialItem=' + toString_0(tmp_0 == null ? null : new ItemRef(tmp_0)) + ')';
  }
  hashCode() {
    var result = hashCode(this.k68_1);
    result = imul(result, 31) + (this.l68_1 == null ? 0 : getStringHashCode(this.l68_1)) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.m68_1;
    if ((tmp_1 == null ? null : new ItemRef(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ItemRef__hashCode_impl_1dj73i(this.m68_1);
    }
    result = tmp + tmp_0 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof PendingWork))
      return false;
    var tmp0_other_with_cast = other instanceof PendingWork ? other : THROW_CCE();
    if (!equals(this.k68_1, tmp0_other_with_cast.k68_1))
      return false;
    if (!(this.l68_1 == tmp0_other_with_cast.l68_1))
      return false;
    var tmp = this.m68_1;
    var tmp_0 = tmp == null ? null : new ItemRef(tmp);
    var tmp_1 = tmp0_other_with_cast.m68_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ItemRef(tmp_1)))
      return false;
    return true;
  }
}
class ThreadId {
  constructor(value) {
    this.n68_1 = value;
  }
  toString() {
    return ThreadId__toString_impl_tri2rg(this.n68_1);
  }
  hashCode() {
    return ThreadId__hashCode_impl_80c5yl(this.n68_1);
  }
  equals(other) {
    return ThreadId__equals_impl_437u15(this.n68_1, other);
  }
}
class NoMemoryProvider {
  constructor() {
    NoMemoryProvider_instance = this;
    this.o68_1 = _MemoryProviderId___init__impl__vkxuto('none');
  }
  a5r() {
    return this.o68_1;
  }
  p68(thread, $completion) {
    return NoMemory_instance;
  }
}
class FixedMemoryProvider {
  constructor(id, opener) {
    this.q68_1 = id;
    this.r68_1 = opener;
  }
  a5r() {
    return this.q68_1;
  }
  p68(thread, $completion) {
    return this.r68_1(new ThreadId(thread), $completion);
  }
}
class ThreadMemory {}
function get_retention() {
  return TurnRetention_Interrupted_getInstance();
}
function close() {
}
class NoMemory {
  t68(query, $completion) {
    return Companion_getInstance_30().x68_1;
  }
  u68(turn, $completion) {
  }
}
class Companion_24 {
  constructor() {
    Companion_instance_26 = this;
    this.x68_1 = new MemoryView(emptyList(), null);
  }
}
class MemoryView {
  constructor(transcript, checkpoint) {
    Companion_getInstance_30();
    checkpoint = checkpoint === VOID ? null : checkpoint;
    this.v68_1 = transcript;
    this.w68_1 = checkpoint;
  }
  toString() {
    return 'MemoryView(transcript=' + toString(this.v68_1) + ', checkpoint=' + toString_0(this.w68_1) + ')';
  }
  hashCode() {
    var result = hashCode(this.v68_1);
    result = imul(result, 31) + (this.w68_1 == null ? 0 : this.w68_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MemoryView))
      return false;
    var tmp0_other_with_cast = other instanceof MemoryView ? other : THROW_CCE();
    if (!equals(this.v68_1, tmp0_other_with_cast.v68_1))
      return false;
    if (!equals(this.w68_1, tmp0_other_with_cast.w68_1))
      return false;
    return true;
  }
}
class WindowMemoryProvider {
  constructor(maxMessages, retention) {
    retention = retention === VOID ? TurnRetention_Interrupted_getInstance() : retention;
    this.i69_1 = maxMessages;
    this.j69_1 = retention;
    this.k69_1 = _MemoryProviderId___init__impl__vkxuto('window:' + this.i69_1);
  }
  a5r() {
    return this.k69_1;
  }
  p68(thread, $completion) {
    return new WindowMemory(this.i69_1, this.j69_1);
  }
}
class Companion_25 {
  q69(items, max) {
    if (items.b1() <= max)
      return items;
    // Inline function 'kotlin.collections.takeWhile' call
    var list = ArrayList.k();
    var _iterator__ex2g4s = items.y();
    $l$loop: while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      if (!isSystem(item))
        break $l$loop;
      list.l(item);
    }
    var system = list;
    var rest = drop(items, system.b1());
    var turns = groupIntoTurns(this, rest);
    var budget = coerceAtLeast(max - system.b1() | 0, 0);
    var kept = ArrayDeque.rk();
    var count = 0;
    var _iterator__ex2g4s_0 = asReversed(turns).y();
    $l$loop_0: while (_iterator__ex2g4s_0.z()) {
      var turn = _iterator__ex2g4s_0.a1();
      var tmp;
      if ((count + turn.b1() | 0) > budget) {
        // Inline function 'kotlin.collections.isNotEmpty' call
        tmp = !kept.h1();
      } else {
        tmp = false;
      }
      if (tmp)
        break $l$loop_0;
      kept.uk(turn);
      count = count + turn.b1() | 0;
    }
    var result = plus_0(system, flatten(kept));
    rejectDroppedRequired(this, items, result);
    return result;
  }
}
class WindowMemory {
  constructor(maxMessages, retention) {
    retention = retention === VOID ? TurnRetention_Interrupted_getInstance() : retention;
    this.l69_1 = maxMessages;
    this.m69_1 = retention;
    this.n69_1 = Mutex();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.o69_1 = ArrayList.k();
    this.p69_1 = null;
  }
  s68() {
    return this.m69_1;
  }
  t68(query, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda.bind(VOID, this, query), $completion);
  }
  u68(turn, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_commit__is9lbl.bind(VOID, this, turn), $completion);
  }
}
class AgentListener {}
function onModelEvent(event) {
}
function onAgentEvent(event) {
}
function onStep(state) {
}
class Hook {}
function onModelRequest(ctx, $completion) {
  return ctx.s69_1;
}
function onModelStream(ctx, events) {
  return events;
}
function onToolCall(ctx, $completion) {
  return Proceed_instance;
}
function onToolResult(ctx, outcome, $completion) {
  return outcome;
}
class StepContext {
  constructor(state, request, phase) {
    phase = phase === VOID ? ModelCallPhase_Normal_getInstance() : phase;
    this.r69_1 = state;
    this.s69_1 = request;
    this.t69_1 = phase;
  }
  toString() {
    return 'StepContext(state=' + this.r69_1.toString() + ', request=' + this.s69_1.toString() + ', phase=' + this.t69_1.toString() + ')';
  }
  hashCode() {
    var result = this.r69_1.hashCode();
    result = imul(result, 31) + this.s69_1.hashCode() | 0;
    result = imul(result, 31) + this.t69_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof StepContext))
      return false;
    var tmp0_other_with_cast = other instanceof StepContext ? other : THROW_CCE();
    if (!this.r69_1.equals(tmp0_other_with_cast.r69_1))
      return false;
    if (!this.s69_1.equals(tmp0_other_with_cast.s69_1))
      return false;
    if (!this.t69_1.equals(tmp0_other_with_cast.t69_1))
      return false;
    return true;
  }
}
class ToolContext {
  constructor(call, state, execution) {
    execution = execution === VOID ? null : execution;
    this.u69_1 = call;
    this.v69_1 = state;
    this.w69_1 = execution;
  }
  toString() {
    return 'ToolContext(call=' + this.u69_1.toString() + ', state=' + this.v69_1.toString() + ', execution=' + toString_0(this.w69_1) + ')';
  }
  hashCode() {
    var result = this.u69_1.hashCode();
    result = imul(result, 31) + this.v69_1.hashCode() | 0;
    result = imul(result, 31) + (this.w69_1 == null ? 0 : this.w69_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolContext))
      return false;
    var tmp0_other_with_cast = other instanceof ToolContext ? other : THROW_CCE();
    if (!this.u69_1.equals(tmp0_other_with_cast.u69_1))
      return false;
    if (!this.v69_1.equals(tmp0_other_with_cast.v69_1))
      return false;
    if (!equals(this.w69_1, tmp0_other_with_cast.w69_1))
      return false;
    return true;
  }
}
class ModelCallPhase extends Enum {}
class Proceed {
  toString() {
    return 'Proceed';
  }
  hashCode() {
    return -771560147;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Proceed))
      return false;
    other instanceof Proceed || THROW_CCE();
    return true;
  }
}
class ProceedWith {
  constructor(call) {
    this.z5v_1 = call;
  }
  toString() {
    return 'ProceedWith(call=' + this.z5v_1.toString() + ')';
  }
  hashCode() {
    return this.z5v_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ProceedWith))
      return false;
    var tmp0_other_with_cast = other instanceof ProceedWith ? other : THROW_CCE();
    if (!this.z5v_1.equals(tmp0_other_with_cast.z5v_1))
      return false;
    return true;
  }
}
class Deny {
  constructor(reason) {
    this.y5v_1 = reason;
  }
  toString() {
    return 'Deny(reason=' + this.y5v_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.y5v_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Deny))
      return false;
    var tmp0_other_with_cast = other instanceof Deny ? other : THROW_CCE();
    if (!(this.y5v_1 === tmp0_other_with_cast.y5v_1))
      return false;
    return true;
  }
}
class AgentError {}
class ModelError {
  constructor(message, retriable, cause) {
    cause = cause === VOID ? null : cause;
    this.x69_1 = message;
    this.y69_1 = retriable;
    this.z69_1 = cause;
  }
  h2() {
    return this.x69_1;
  }
  i2() {
    return this.z69_1;
  }
  toString() {
    return 'ModelError(message=' + this.x69_1 + ', retriable=' + this.y69_1 + ', cause=' + toString_0(this.z69_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.x69_1);
    result = imul(result, 31) + getBooleanHashCode(this.y69_1) | 0;
    result = imul(result, 31) + (this.z69_1 == null ? 0 : hashCode(this.z69_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ModelError))
      return false;
    var tmp0_other_with_cast = other instanceof ModelError ? other : THROW_CCE();
    if (!(this.x69_1 === tmp0_other_with_cast.x69_1))
      return false;
    if (!(this.y69_1 === tmp0_other_with_cast.y69_1))
      return false;
    if (!equals(this.z69_1, tmp0_other_with_cast.z69_1))
      return false;
    return true;
  }
}
class ToolError {
  constructor(toolName, message, retriable, cause) {
    cause = cause === VOID ? null : cause;
    this.a6a_1 = toolName;
    this.b6a_1 = message;
    this.c6a_1 = retriable;
    this.d6a_1 = cause;
  }
  h2() {
    return this.b6a_1;
  }
  i2() {
    return this.d6a_1;
  }
  toString() {
    return 'ToolError(toolName=' + this.a6a_1 + ', message=' + this.b6a_1 + ', retriable=' + this.c6a_1 + ', cause=' + toString_0(this.d6a_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.a6a_1);
    result = imul(result, 31) + getStringHashCode(this.b6a_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.c6a_1) | 0;
    result = imul(result, 31) + (this.d6a_1 == null ? 0 : hashCode(this.d6a_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolError))
      return false;
    var tmp0_other_with_cast = other instanceof ToolError ? other : THROW_CCE();
    if (!(this.a6a_1 === tmp0_other_with_cast.a6a_1))
      return false;
    if (!(this.b6a_1 === tmp0_other_with_cast.b6a_1))
      return false;
    if (!(this.c6a_1 === tmp0_other_with_cast.c6a_1))
      return false;
    if (!equals(this.d6a_1, tmp0_other_with_cast.d6a_1))
      return false;
    return true;
  }
}
class ParseError {
  constructor(message, raw, cause) {
    cause = cause === VOID ? null : cause;
    this.e6a_1 = message;
    this.f6a_1 = raw;
    this.g6a_1 = cause;
  }
  h2() {
    return this.e6a_1;
  }
  i2() {
    return this.g6a_1;
  }
  toString() {
    return 'ParseError(message=' + this.e6a_1 + ', raw=' + this.f6a_1 + ', cause=' + toString_0(this.g6a_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.e6a_1);
    result = imul(result, 31) + getStringHashCode(this.f6a_1) | 0;
    result = imul(result, 31) + (this.g6a_1 == null ? 0 : hashCode(this.g6a_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ParseError))
      return false;
    var tmp0_other_with_cast = other instanceof ParseError ? other : THROW_CCE();
    if (!(this.e6a_1 === tmp0_other_with_cast.e6a_1))
      return false;
    if (!(this.f6a_1 === tmp0_other_with_cast.f6a_1))
      return false;
    if (!equals(this.g6a_1, tmp0_other_with_cast.g6a_1))
      return false;
    return true;
  }
}
class ToolNotFound {
  constructor(toolName) {
    this.h6a_1 = toolName;
  }
  h2() {
    return 'tool not found: ' + this.h6a_1;
  }
  i2() {
    return null;
  }
  toString() {
    return 'ToolNotFound(toolName=' + this.h6a_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.h6a_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolNotFound))
      return false;
    var tmp0_other_with_cast = other instanceof ToolNotFound ? other : THROW_CCE();
    if (!(this.h6a_1 === tmp0_other_with_cast.h6a_1))
      return false;
    return true;
  }
}
class SkillError {
  constructor(skillId, stage, message, cause) {
    cause = cause === VOID ? null : cause;
    this.i6a_1 = skillId;
    this.j6a_1 = stage;
    this.k6a_1 = message;
    this.l6a_1 = cause;
  }
  h2() {
    return this.k6a_1;
  }
  i2() {
    return this.l6a_1;
  }
  toString() {
    var tmp = this.i6a_1;
    return 'SkillError(skillId=' + toString_0(tmp == null ? null : new SkillId(tmp)) + ', stage=' + this.j6a_1.toString() + ', message=' + this.k6a_1 + ', cause=' + toString_0(this.l6a_1) + ')';
  }
  hashCode() {
    var tmp;
    var tmp_0 = this.i6a_1;
    if ((tmp_0 == null ? null : new SkillId(tmp_0)) == null) {
      tmp = 0;
    } else {
      tmp = SkillId__hashCode_impl_vhfju(this.i6a_1);
    }
    var result = tmp;
    result = imul(result, 31) + this.j6a_1.hashCode() | 0;
    result = imul(result, 31) + getStringHashCode(this.k6a_1) | 0;
    result = imul(result, 31) + (this.l6a_1 == null ? 0 : hashCode(this.l6a_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SkillError))
      return false;
    var tmp0_other_with_cast = other instanceof SkillError ? other : THROW_CCE();
    var tmp = this.i6a_1;
    var tmp_0 = tmp == null ? null : new SkillId(tmp);
    var tmp_1 = tmp0_other_with_cast.i6a_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new SkillId(tmp_1)))
      return false;
    if (!this.j6a_1.equals(tmp0_other_with_cast.j6a_1))
      return false;
    if (!(this.k6a_1 === tmp0_other_with_cast.k6a_1))
      return false;
    if (!equals(this.l6a_1, tmp0_other_with_cast.l6a_1))
      return false;
    return true;
  }
}
class PreparationError {
  constructor(component, message, cause) {
    cause = cause === VOID ? null : cause;
    this.m6a_1 = component;
    this.n6a_1 = message;
    this.o6a_1 = cause;
  }
  h2() {
    return this.n6a_1;
  }
  i2() {
    return this.o6a_1;
  }
  toString() {
    return 'PreparationError(component=' + this.m6a_1 + ', message=' + this.n6a_1 + ', cause=' + toString_0(this.o6a_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.m6a_1);
    result = imul(result, 31) + getStringHashCode(this.n6a_1) | 0;
    result = imul(result, 31) + (this.o6a_1 == null ? 0 : hashCode(this.o6a_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof PreparationError))
      return false;
    var tmp0_other_with_cast = other instanceof PreparationError ? other : THROW_CCE();
    if (!(this.m6a_1 === tmp0_other_with_cast.m6a_1))
      return false;
    if (!(this.n6a_1 === tmp0_other_with_cast.n6a_1))
      return false;
    if (!equals(this.o6a_1, tmp0_other_with_cast.o6a_1))
      return false;
    return true;
  }
}
class Timeout {
  constructor(stage, elapsedMs) {
    this.p6a_1 = stage;
    this.q6a_1 = elapsedMs;
  }
  h2() {
    return this.p6a_1 + ' timed out after ' + this.q6a_1.toString() + 'ms';
  }
  i2() {
    return null;
  }
  toString() {
    return 'Timeout(stage=' + this.p6a_1 + ', elapsedMs=' + this.q6a_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.p6a_1);
    result = imul(result, 31) + this.q6a_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Timeout))
      return false;
    var tmp0_other_with_cast = other instanceof Timeout ? other : THROW_CCE();
    if (!(this.p6a_1 === tmp0_other_with_cast.p6a_1))
      return false;
    if (!this.q6a_1.equals(tmp0_other_with_cast.q6a_1))
      return false;
    return true;
  }
}
class AgentFrameworkException extends IllegalStateException {
  static b5t(error, cause) {
    cause = cause === VOID ? error.i2() : cause;
    var $this = this.pd(error.h2(), cause);
    captureStack($this, $this.a5t_1);
    $this.z5s_1 = error;
    return $this;
  }
}
class UrlCitation {
  constructor(url, title, startIndex, endIndex) {
    title = title === VOID ? null : title;
    startIndex = startIndex === VOID ? null : startIndex;
    endIndex = endIndex === VOID ? null : endIndex;
    this.r6a_1 = url;
    this.s6a_1 = title;
    this.t6a_1 = startIndex;
    this.u6a_1 = endIndex;
  }
  toString() {
    return 'UrlCitation(url=' + this.r6a_1 + ', title=' + this.s6a_1 + ', startIndex=' + this.t6a_1 + ', endIndex=' + this.u6a_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.r6a_1);
    result = imul(result, 31) + (this.s6a_1 == null ? 0 : getStringHashCode(this.s6a_1)) | 0;
    result = imul(result, 31) + (this.t6a_1 == null ? 0 : this.t6a_1) | 0;
    result = imul(result, 31) + (this.u6a_1 == null ? 0 : this.u6a_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof UrlCitation))
      return false;
    var tmp0_other_with_cast = other instanceof UrlCitation ? other : THROW_CCE();
    if (!(this.r6a_1 === tmp0_other_with_cast.r6a_1))
      return false;
    if (!(this.s6a_1 == tmp0_other_with_cast.s6a_1))
      return false;
    if (!(this.t6a_1 == tmp0_other_with_cast.t6a_1))
      return false;
    if (!(this.u6a_1 == tmp0_other_with_cast.u6a_1))
      return false;
    return true;
  }
}
class FileCitation {
  constructor(fileId, filename, startIndex, endIndex) {
    filename = filename === VOID ? null : filename;
    startIndex = startIndex === VOID ? null : startIndex;
    endIndex = endIndex === VOID ? null : endIndex;
    this.v6a_1 = fileId;
    this.w6a_1 = filename;
    this.x6a_1 = startIndex;
    this.y6a_1 = endIndex;
  }
  toString() {
    return 'FileCitation(fileId=' + this.v6a_1 + ', filename=' + this.w6a_1 + ', startIndex=' + this.x6a_1 + ', endIndex=' + this.y6a_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.v6a_1);
    result = imul(result, 31) + (this.w6a_1 == null ? 0 : getStringHashCode(this.w6a_1)) | 0;
    result = imul(result, 31) + (this.x6a_1 == null ? 0 : this.x6a_1) | 0;
    result = imul(result, 31) + (this.y6a_1 == null ? 0 : this.y6a_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof FileCitation))
      return false;
    var tmp0_other_with_cast = other instanceof FileCitation ? other : THROW_CCE();
    if (!(this.v6a_1 === tmp0_other_with_cast.v6a_1))
      return false;
    if (!(this.w6a_1 == tmp0_other_with_cast.w6a_1))
      return false;
    if (!(this.x6a_1 == tmp0_other_with_cast.x6a_1))
      return false;
    if (!(this.y6a_1 == tmp0_other_with_cast.y6a_1))
      return false;
    return true;
  }
}
class Generic {
  constructor(kind, payload) {
    this.z6a_1 = kind;
    this.a6b_1 = payload;
  }
  toString() {
    return 'Generic(kind=' + this.z6a_1 + ', payload=' + this.a6b_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.z6a_1);
    result = imul(result, 31) + getStringHashCode(this.a6b_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Generic))
      return false;
    var tmp0_other_with_cast = other instanceof Generic ? other : THROW_CCE();
    if (!(this.z6a_1 === tmp0_other_with_cast.z6a_1))
      return false;
    if (!(this.a6b_1 === tmp0_other_with_cast.a6b_1))
      return false;
    return true;
  }
}
class Companion_26 {
  b6b(items) {
    var canonical = new Buffer();
    canonical.n43(items.b1());
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = items.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      writeItem(canonical, element);
    }
    return new TranscriptBasis(items.b1(), 'sha256:' + canonical.s43().g42().f42());
  }
}
class TranscriptBasis {
  constructor(itemCount, digest) {
    this.c6b_1 = itemCount;
    this.d6b_1 = digest;
  }
  toString() {
    return 'TranscriptBasis(itemCount=' + this.c6b_1 + ', digest=' + this.d6b_1 + ')';
  }
  hashCode() {
    var result = this.c6b_1;
    result = imul(result, 31) + getStringHashCode(this.d6b_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof TranscriptBasis))
      return false;
    var tmp0_other_with_cast = other instanceof TranscriptBasis ? other : THROW_CCE();
    if (!(this.c6b_1 === tmp0_other_with_cast.c6b_1))
      return false;
    if (!(this.d6b_1 === tmp0_other_with_cast.d6b_1))
      return false;
    return true;
  }
}
class ProviderCheckpoint {
  constructor(providerId, codecVersion, basis, scope, payload, expiresAtEpochMs) {
    expiresAtEpochMs = expiresAtEpochMs === VOID ? null : expiresAtEpochMs;
    this.e6b_1 = providerId;
    this.f6b_1 = codecVersion;
    this.g6b_1 = basis;
    this.h6b_1 = scope;
    this.i6b_1 = payload;
    this.j6b_1 = expiresAtEpochMs;
  }
  k6b(items) {
    var actual = Companion_instance_28.b6b(items);
    return this.g6b_1.c6b_1 === actual.c6b_1 && this.g6b_1.d6b_1 === actual.d6b_1;
  }
  toString() {
    return 'ProviderCheckpoint(providerId=' + ProviderId__toString_impl_hyxggb(this.e6b_1) + ', codecVersion=' + this.f6b_1 + ', basis=' + this.g6b_1.toString() + ', scope=' + this.h6b_1.toString() + ', payload=' + this.i6b_1.toString() + ', expiresAtEpochMs=' + toString_0(this.j6b_1) + ')';
  }
  hashCode() {
    var result = ProviderId__hashCode_impl_vb0opy(this.e6b_1);
    result = imul(result, 31) + this.f6b_1 | 0;
    result = imul(result, 31) + this.g6b_1.hashCode() | 0;
    result = imul(result, 31) + this.h6b_1.hashCode() | 0;
    result = imul(result, 31) + this.i6b_1.hashCode() | 0;
    result = imul(result, 31) + (this.j6b_1 == null ? 0 : this.j6b_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ProviderCheckpoint))
      return false;
    var tmp0_other_with_cast = other instanceof ProviderCheckpoint ? other : THROW_CCE();
    if (!(this.e6b_1 === tmp0_other_with_cast.e6b_1))
      return false;
    if (!(this.f6b_1 === tmp0_other_with_cast.f6b_1))
      return false;
    if (!this.g6b_1.equals(tmp0_other_with_cast.g6b_1))
      return false;
    if (!this.h6b_1.equals(tmp0_other_with_cast.h6b_1))
      return false;
    if (!this.i6b_1.equals(tmp0_other_with_cast.i6b_1))
      return false;
    if (!equals(this.j6b_1, tmp0_other_with_cast.j6b_1))
      return false;
    return true;
  }
}
class CheckpointScope extends Enum {}
class Companion_27 {}
class $serializer_23 {
  constructor() {
    $serializer_instance_22 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('text', this, 1);
    tmp0_serialDesc.f25('text', false);
    this.x6b_1 = tmp0_serialDesc;
  }
  y6b(encoder, value) {
    var tmp0_desc = this.x6b_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.w6b_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.y6b(encoder, value instanceof Text ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.x6b_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return Text.z6b(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.x6b_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance()];
  }
}
class Companion_28 {}
class $serializer_24 {
  constructor() {
    $serializer_instance_23 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('image', this, 2);
    tmp0_serialDesc.f25('url', true);
    tmp0_serialDesc.f25('base64', true);
    this.a6c_1 = tmp0_serialDesc;
  }
  b6c(encoder, value) {
    var tmp0_desc = this.a6c_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.u6b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.u6b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.v6b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.v6b_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.b6c(encoder, value instanceof Image ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.a6c_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return Image.c6c(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.a6c_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_29 {}
class $serializer_25 {
  constructor() {
    $serializer_instance_24 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('audio', this, 3);
    tmp0_serialDesc.f25('url', true);
    tmp0_serialDesc.f25('base64', true);
    tmp0_serialDesc.f25('format', false);
    this.d6c_1 = tmp0_serialDesc;
  }
  e6c(encoder, value) {
    var tmp0_desc = this.d6c_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.r6b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.r6b_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.s6b_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.s6b_1);
    }
    tmp1_output.g1z(tmp0_desc, 2, value.t6b_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.e6c(encoder, value instanceof Audio ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.d6c_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.a1y(tmp0_desc, 2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.a1y(tmp0_desc, 2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return Audio.f6c(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.d6c_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), StringSerializer_getInstance()];
  }
}
class Text {
  constructor(text) {
    this.w6b_1 = text;
  }
  toString() {
    return 'Text(text=' + this.w6b_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.w6b_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Text))
      return false;
    var tmp0_other_with_cast = other instanceof Text ? other : THROW_CCE();
    if (!(this.w6b_1 === tmp0_other_with_cast.w6b_1))
      return false;
    return true;
  }
  static z6b(seen0, text, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_22().x6b_1);
    }
    var $this = createThis(this);
    $this.w6b_1 = text;
    return $this;
  }
}
class Image {
  constructor(url, base64) {
    url = url === VOID ? null : url;
    base64 = base64 === VOID ? null : base64;
    this.u6b_1 = url;
    this.v6b_1 = base64;
  }
  toString() {
    return 'Image(url=' + this.u6b_1 + ', base64=' + this.v6b_1 + ')';
  }
  hashCode() {
    var result = this.u6b_1 == null ? 0 : getStringHashCode(this.u6b_1);
    result = imul(result, 31) + (this.v6b_1 == null ? 0 : getStringHashCode(this.v6b_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Image))
      return false;
    var tmp0_other_with_cast = other instanceof Image ? other : THROW_CCE();
    if (!(this.u6b_1 == tmp0_other_with_cast.u6b_1))
      return false;
    if (!(this.v6b_1 == tmp0_other_with_cast.v6b_1))
      return false;
    return true;
  }
  static c6c(seen0, url, base64, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_23().a6c_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.u6b_1 = null;
    else
      $this.u6b_1 = url;
    if (0 === (seen0 & 2))
      $this.v6b_1 = null;
    else
      $this.v6b_1 = base64;
    return $this;
  }
}
class Audio {
  constructor(url, base64, format) {
    url = url === VOID ? null : url;
    base64 = base64 === VOID ? null : base64;
    this.r6b_1 = url;
    this.s6b_1 = base64;
    this.t6b_1 = format;
  }
  toString() {
    return 'Audio(url=' + this.r6b_1 + ', base64=' + this.s6b_1 + ', format=' + this.t6b_1 + ')';
  }
  hashCode() {
    var result = this.r6b_1 == null ? 0 : getStringHashCode(this.r6b_1);
    result = imul(result, 31) + (this.s6b_1 == null ? 0 : getStringHashCode(this.s6b_1)) | 0;
    result = imul(result, 31) + getStringHashCode(this.t6b_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Audio))
      return false;
    var tmp0_other_with_cast = other instanceof Audio ? other : THROW_CCE();
    if (!(this.r6b_1 == tmp0_other_with_cast.r6b_1))
      return false;
    if (!(this.s6b_1 == tmp0_other_with_cast.s6b_1))
      return false;
    if (!(this.t6b_1 === tmp0_other_with_cast.t6b_1))
      return false;
    return true;
  }
  static f6c(seen0, url, base64, format, serializationConstructorMarker) {
    if (!(4 === (4 & seen0))) {
      throwMissingFieldException(seen0, 4, $serializer_getInstance_24().d6c_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.r6b_1 = null;
    else
      $this.r6b_1 = url;
    if (0 === (seen0 & 2))
      $this.s6b_1 = null;
    else
      $this.s6b_1 = base64;
    $this.t6b_1 = format;
    return $this;
  }
}
class FallbackModel$stream$slambda$slambda {
  constructor($emitted, $isLast, $lastError, $this_flow) {
    this.g6c_1 = $emitted;
    this.h6c_1 = $isLast;
    this.i6c_1 = $lastError;
    this.j6c_1 = $this_flow;
  }
  j5z(event, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_12.bind(VOID, this, event), $completion);
  }
  td(p1, $completion) {
    return this.j5z((!(p1 == null) ? isInterface(p1, ModelEvent) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class FallbackSignal extends Error {
  static q6c() {
    FallbackSignal_instance = null;
    var $this = createThis(this);
    FallbackSignal_instance = $this;
    setPropertiesToThrowableInstance($this);
    captureStack($this, $this.p6c_1);
    return $this;
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_1 {
  constructor(function_0) {
    this.r6c_1 = function_0;
  }
  t1c(value, $completion) {
    return this.r6c_1(value, $completion);
  }
  n4() {
    return this.r6c_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class FallbackModel$stream$slambda {
  constructor(this$0, $request) {
    this.m6c_1 = this$0;
    this.n6c_1 = $request;
  }
  s6c($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_13.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.s6c((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class LanguageModel {}
function abandon(responseId, $completion) {
}
class FallbackModel {
  constructor(models) {
    this.k6c_1 = models;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.require' call
    if (!!this.k6c_1.h1()) {
      var message = 'FallbackModel requires at least one model';
      throw IllegalArgumentException.t(toString(message));
    }
    this.l6c_1 = first(this.k6c_1).l5o();
  }
  l5o() {
    return this.l6c_1;
  }
  w5y(request) {
    return flow(FallbackModel$stream$slambda_0(this, request));
  }
  o6c(responseId, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_abandon__qxshi9.bind(VOID, this, responseId), $completion);
  }
}
class Companion_30 {
  q60(prefix) {
    return _ItemRef___init__impl__ipmeex(prefix + '_' + randomToken());
  }
  w6c(prefix, $super) {
    prefix = prefix === VOID ? 'item' : prefix;
    return $super === VOID ? this.q60(prefix) : $super.q60.call(this, prefix).b61_1;
  }
}
class ItemRef {
  constructor(value) {
    this.b61_1 = value;
  }
  toString() {
    return ItemRef__toString_impl_kdmppd(this.b61_1);
  }
  hashCode() {
    return ItemRef__hashCode_impl_1dj73i(this.b61_1);
  }
  equals(other) {
    return ItemRef__equals_impl_csc7m(this.b61_1, other);
  }
}
class Companion_31 {
  constructor() {
    Companion_instance_33 = this;
    this.x6c_1 = _ProviderId___init__impl__nor0vf('openai');
    this.y6c_1 = _ProviderId___init__impl__nor0vf('openai-responses');
    this.z6c_1 = _ProviderId___init__impl__nor0vf('anthropic');
    this.a6d_1 = _ProviderId___init__impl__nor0vf('ollama');
    this.b6d_1 = _ProviderId___init__impl__nor0vf('qwen');
    this.c6d_1 = _ProviderId___init__impl__nor0vf('chat-completions');
  }
}
class $serializer_26 {
  constructor() {
    $serializer_instance_25 = this;
    var tmp0_serialDesc = new InlineClassDescriptor('org.koaks.framework.model.ProviderId', this);
    tmp0_serialDesc.f25('value', false);
    this.d6d_1 = tmp0_serialDesc;
  }
  e6d(encoder, value) {
    var tmp0_inlineEncoder = encoder.x1y(this.d6d_1);
    if (tmp0_inlineEncoder == null)
      null;
    else {
      tmp0_inlineEncoder.v1y(_ProviderId___get_value__impl__xo1tux(value));
    }
  }
  i1t(encoder, value) {
    return this.e6d(encoder, value instanceof ProviderId ? value.f6d_1 : THROW_CCE());
  }
  g6d(decoder) {
    return _ProviderId___init__impl__nor0vf(decoder.n1x(this.d6d_1).l1x());
  }
  j1t(decoder) {
    return new ProviderId(this.g6d(decoder));
  }
  h1t() {
    return this.d6d_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance()];
  }
}
class ProviderId {
  constructor(value) {
    Companion_getInstance_37();
    this.f6d_1 = value;
  }
  toString() {
    return ProviderId__toString_impl_hyxggb(this.f6d_1);
  }
  hashCode() {
    return ProviderId__hashCode_impl_vb0opy(this.f6d_1);
  }
  equals(other) {
    return ProviderId__equals_impl_icthxa(this.f6d_1, other);
  }
}
class Companion_32 {}
class $serializer_27 {
  constructor() {
    $serializer_instance_26 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.model.ProviderScopedId', this, 2);
    tmp0_serialDesc.f25('providerId', false);
    tmp0_serialDesc.f25('raw', false);
    this.h6d_1 = tmp0_serialDesc;
  }
  i6d(encoder, value) {
    var tmp0_desc = this.h6d_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.i1z(tmp0_desc, 0, $serializer_getInstance_25(), new ProviderId(value.p6b_1));
    tmp1_output.g1z(tmp0_desc, 1, value.q6b_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.i6d(encoder, value instanceof ProviderScopedId ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.h6d_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      var tmp = $serializer_getInstance_25();
      var tmp_0 = tmp4_local0;
      var tmp_1 = tmp6_input.c1y(tmp0_desc, 0, tmp, tmp_0 == null ? null : new ProviderId(tmp_0));
      tmp4_local0 = tmp_1 == null ? null : tmp_1.f6d_1;
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            var tmp_2 = $serializer_getInstance_25();
            var tmp_3 = tmp4_local0;
            var tmp_4 = tmp6_input.c1y(tmp0_desc, 0, tmp_2, tmp_3 == null ? null : new ProviderId(tmp_3));
            tmp4_local0 = tmp_4 == null ? null : tmp_4.f6d_1;
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return ProviderScopedId.j6d(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.h6d_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [$serializer_getInstance_25(), StringSerializer_getInstance()];
  }
}
class ProviderScopedId {
  constructor(providerId, raw) {
    this.p6b_1 = providerId;
    this.q6b_1 = raw;
  }
  toString() {
    return 'ProviderScopedId(providerId=' + ProviderId__toString_impl_hyxggb(this.p6b_1) + ', raw=' + this.q6b_1 + ')';
  }
  hashCode() {
    var result = ProviderId__hashCode_impl_vb0opy(this.p6b_1);
    result = imul(result, 31) + getStringHashCode(this.q6b_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ProviderScopedId))
      return false;
    var tmp0_other_with_cast = other instanceof ProviderScopedId ? other : THROW_CCE();
    if (!(this.p6b_1 === tmp0_other_with_cast.p6b_1))
      return false;
    if (!(this.q6b_1 === tmp0_other_with_cast.q6b_1))
      return false;
    return true;
  }
  static j6d(seen0, providerId, raw, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_26().h6d_1);
    }
    var $this = createThis(this);
    $this.p6b_1 = providerId;
    $this.q6b_1 = raw;
    return $this;
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_2 {
  constructor(function_0) {
    this.m6d_1 = function_0;
  }
  t1c(value, $completion) {
    return this.m6d_1(value, $completion);
  }
  n4() {
    return this.m6d_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class generate$o$collect$slambda {
  constructor($$this$unsafeFlow) {
    this.k6d_1 = $$this$unsafeFlow;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_14.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class generate$$inlined$filterIsInstance$1 {
  constructor($this) {
    this.l6d_1 = $this;
  }
  o6d(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy.bind(VOID, this, collector), $completion);
  }
  g1c(collector, $completion) {
    return this.o6d(collector, $completion);
  }
}
class Companion_33 {
  constructor() {
    Companion_instance_35 = this;
    this.p6d_1 = new ModelCapabilities();
  }
}
class ModelCapabilities {
  constructor(parallelToolCalls, vision, jsonObject, jsonSchema, assistantPrefill) {
    Companion_getInstance_39();
    parallelToolCalls = parallelToolCalls === VOID ? Support_Supported_getInstance() : parallelToolCalls;
    vision = vision === VOID ? Support_Unknown_getInstance() : vision;
    jsonObject = jsonObject === VOID ? Support_Unknown_getInstance() : jsonObject;
    jsonSchema = jsonSchema === VOID ? Support_Unknown_getInstance() : jsonSchema;
    assistantPrefill = assistantPrefill === VOID ? Support_Unknown_getInstance() : assistantPrefill;
    this.g5o_1 = parallelToolCalls;
    this.h5o_1 = vision;
    this.i5o_1 = jsonObject;
    this.j5o_1 = jsonSchema;
    this.k5o_1 = assistantPrefill;
  }
  toString() {
    return 'ModelCapabilities(parallelToolCalls=' + this.g5o_1.toString() + ', vision=' + this.h5o_1.toString() + ', jsonObject=' + this.i5o_1.toString() + ', jsonSchema=' + this.j5o_1.toString() + ', assistantPrefill=' + this.k5o_1.toString() + ')';
  }
  hashCode() {
    var result = this.g5o_1.hashCode();
    result = imul(result, 31) + this.h5o_1.hashCode() | 0;
    result = imul(result, 31) + this.i5o_1.hashCode() | 0;
    result = imul(result, 31) + this.j5o_1.hashCode() | 0;
    result = imul(result, 31) + this.k5o_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ModelCapabilities))
      return false;
    var tmp0_other_with_cast = other instanceof ModelCapabilities ? other : THROW_CCE();
    if (!this.g5o_1.equals(tmp0_other_with_cast.g5o_1))
      return false;
    if (!this.h5o_1.equals(tmp0_other_with_cast.h5o_1))
      return false;
    if (!this.i5o_1.equals(tmp0_other_with_cast.i5o_1))
      return false;
    if (!this.j5o_1.equals(tmp0_other_with_cast.j5o_1))
      return false;
    if (!this.k5o_1.equals(tmp0_other_with_cast.k5o_1))
      return false;
    return true;
  }
}
class ModelEvent {}
class Started {
  constructor(responseId) {
    this.d61_1 = responseId;
  }
  toString() {
    return 'Started(responseId=' + this.d61_1 + ')';
  }
  hashCode() {
    return this.d61_1 == null ? 0 : getStringHashCode(this.d61_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Started))
      return false;
    var tmp0_other_with_cast = other instanceof Started ? other : THROW_CCE();
    if (!(this.d61_1 == tmp0_other_with_cast.d61_1))
      return false;
    return true;
  }
}
class CheckpointUpdated {
  constructor(checkpoint) {
    this.c61_1 = checkpoint;
  }
  toString() {
    return 'CheckpointUpdated(checkpoint=' + this.c61_1.toString() + ')';
  }
  hashCode() {
    return this.c61_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CheckpointUpdated))
      return false;
    var tmp0_other_with_cast = other instanceof CheckpointUpdated ? other : THROW_CCE();
    if (!this.c61_1.equals(tmp0_other_with_cast.c61_1))
      return false;
    return true;
  }
}
class TextDelta_0 {
  constructor(text, itemRef) {
    itemRef = itemRef === VOID ? null : itemRef;
    this.g5v_1 = text;
    this.h5v_1 = itemRef;
  }
  toString() {
    var tmp = this.h5v_1;
    return 'TextDelta(text=' + this.g5v_1 + ', itemRef=' + toString_0(tmp == null ? null : new ItemRef(tmp)) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.g5v_1);
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.h5v_1;
    if ((tmp_1 == null ? null : new ItemRef(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ItemRef__hashCode_impl_1dj73i(this.h5v_1);
    }
    result = tmp + tmp_0 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof TextDelta_0))
      return false;
    var tmp0_other_with_cast = other instanceof TextDelta_0 ? other : THROW_CCE();
    if (!(this.g5v_1 === tmp0_other_with_cast.g5v_1))
      return false;
    var tmp = this.h5v_1;
    var tmp_0 = tmp == null ? null : new ItemRef(tmp);
    var tmp_1 = tmp0_other_with_cast.h5v_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ItemRef(tmp_1)))
      return false;
    return true;
  }
}
class ReasoningDelta_0 {
  constructor(text, itemRef) {
    itemRef = itemRef === VOID ? null : itemRef;
    this.e5v_1 = text;
    this.f5v_1 = itemRef;
  }
  toString() {
    var tmp = this.f5v_1;
    return 'ReasoningDelta(text=' + this.e5v_1 + ', itemRef=' + toString_0(tmp == null ? null : new ItemRef(tmp)) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.e5v_1);
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.f5v_1;
    if ((tmp_1 == null ? null : new ItemRef(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ItemRef__hashCode_impl_1dj73i(this.f5v_1);
    }
    result = tmp + tmp_0 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ReasoningDelta_0))
      return false;
    var tmp0_other_with_cast = other instanceof ReasoningDelta_0 ? other : THROW_CCE();
    if (!(this.e5v_1 === tmp0_other_with_cast.e5v_1))
      return false;
    var tmp = this.f5v_1;
    var tmp_0 = tmp == null ? null : new ItemRef(tmp);
    var tmp_1 = tmp0_other_with_cast.f5v_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ItemRef(tmp_1)))
      return false;
    return true;
  }
}
class ItemAdded {
  constructor(item) {
    this.a61_1 = item;
  }
  toString() {
    return 'ItemAdded(item=' + toString(this.a61_1) + ')';
  }
  hashCode() {
    return hashCode(this.a61_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ItemAdded))
      return false;
    var tmp0_other_with_cast = other instanceof ItemAdded ? other : THROW_CCE();
    if (!equals(this.a61_1, tmp0_other_with_cast.a61_1))
      return false;
    return true;
  }
}
class ToolCallDelta {
  constructor(id, index, nameDelta, argumentsDelta, itemRef) {
    index = index === VOID ? null : index;
    nameDelta = nameDelta === VOID ? null : nameDelta;
    argumentsDelta = argumentsDelta === VOID ? null : argumentsDelta;
    itemRef = itemRef === VOID ? null : itemRef;
    this.v60_1 = id;
    this.w60_1 = index;
    this.x60_1 = nameDelta;
    this.y60_1 = argumentsDelta;
    this.z60_1 = itemRef;
  }
  toString() {
    var tmp = this.z60_1;
    return 'ToolCallDelta(id=' + this.v60_1 + ', index=' + this.w60_1 + ', nameDelta=' + this.x60_1 + ', argumentsDelta=' + this.y60_1 + ', itemRef=' + toString_0(tmp == null ? null : new ItemRef(tmp)) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.v60_1);
    result = imul(result, 31) + (this.w60_1 == null ? 0 : this.w60_1) | 0;
    result = imul(result, 31) + (this.x60_1 == null ? 0 : getStringHashCode(this.x60_1)) | 0;
    result = imul(result, 31) + (this.y60_1 == null ? 0 : getStringHashCode(this.y60_1)) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.z60_1;
    if ((tmp_1 == null ? null : new ItemRef(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ItemRef__hashCode_impl_1dj73i(this.z60_1);
    }
    result = tmp + tmp_0 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolCallDelta))
      return false;
    var tmp0_other_with_cast = other instanceof ToolCallDelta ? other : THROW_CCE();
    if (!(this.v60_1 === tmp0_other_with_cast.v60_1))
      return false;
    if (!(this.w60_1 == tmp0_other_with_cast.w60_1))
      return false;
    if (!(this.x60_1 == tmp0_other_with_cast.x60_1))
      return false;
    if (!(this.y60_1 == tmp0_other_with_cast.y60_1))
      return false;
    var tmp = this.z60_1;
    var tmp_0 = tmp == null ? null : new ItemRef(tmp);
    var tmp_1 = tmp0_other_with_cast.z60_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ItemRef(tmp_1)))
      return false;
    return true;
  }
}
class ToolCallCompleted {
  constructor(call) {
    this.d5v_1 = call;
  }
  toString() {
    return 'ToolCallCompleted(call=' + this.d5v_1.toString() + ')';
  }
  hashCode() {
    return this.d5v_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolCallCompleted))
      return false;
    var tmp0_other_with_cast = other instanceof ToolCallCompleted ? other : THROW_CCE();
    if (!this.d5v_1.equals(tmp0_other_with_cast.d5v_1))
      return false;
    return true;
  }
}
class ProviderEvent {
  constructor(providerId, type, payload) {
    this.t6d_1 = providerId;
    this.u6d_1 = type;
    this.v6d_1 = payload;
  }
  toString() {
    return 'ProviderEvent(providerId=' + ProviderId__toString_impl_hyxggb(this.t6d_1) + ', type=' + this.u6d_1 + ', payload=' + this.v6d_1 + ')';
  }
  hashCode() {
    var result = ProviderId__hashCode_impl_vb0opy(this.t6d_1);
    result = imul(result, 31) + getStringHashCode(this.u6d_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.v6d_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ProviderEvent))
      return false;
    var tmp0_other_with_cast = other instanceof ProviderEvent ? other : THROW_CCE();
    if (!(this.t6d_1 === tmp0_other_with_cast.t6d_1))
      return false;
    if (!(this.u6d_1 === tmp0_other_with_cast.u6d_1))
      return false;
    if (!(this.v6d_1 === tmp0_other_with_cast.v6d_1))
      return false;
    return true;
  }
}
class Finished {
  constructor(response) {
    this.q5u_1 = response;
  }
  toString() {
    return 'Finished(response=' + toString(this.q5u_1) + ')';
  }
  hashCode() {
    return hashCode(this.q5u_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Finished))
      return false;
    var tmp0_other_with_cast = other instanceof Finished ? other : THROW_CCE();
    if (!equals(this.q5u_1, tmp0_other_with_cast.q5u_1))
      return false;
    return true;
  }
}
class Message {
  constructor(ref, nativeId, role, content, refusal, annotations) {
    ref = ref === VOID ? Companion_instance_32.q60('msg') : ref;
    nativeId = nativeId === VOID ? null : nativeId;
    refusal = refusal === VOID ? null : refusal;
    annotations = annotations === VOID ? emptyList() : annotations;
    this.a5o_1 = ref;
    this.b5o_1 = nativeId;
    this.c5o_1 = role;
    this.d5o_1 = content;
    this.e5o_1 = refusal;
    this.f5o_1 = annotations;
  }
  s5z() {
    return this.a5o_1;
  }
  l6b() {
    return this.b5o_1;
  }
  f5t() {
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = this.d5o_1;
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element instanceof Text) {
        destination.l(element);
      }
    }
    var tmp = destination;
    return joinToString(tmp, '', VOID, VOID, VOID, VOID, ModelItem$Message$_get_text_$lambda_5ch3ig);
  }
  w6d(ref, nativeId, role, content, refusal, annotations) {
    return new Message(ref, nativeId, role, content, refusal, annotations);
  }
  s60(ref, nativeId, role, content, refusal, annotations, $super) {
    ref = ref === VOID ? this.a5o_1 : ref;
    nativeId = nativeId === VOID ? this.b5o_1 : nativeId;
    role = role === VOID ? this.c5o_1 : role;
    content = content === VOID ? this.d5o_1 : content;
    refusal = refusal === VOID ? this.e5o_1 : refusal;
    annotations = annotations === VOID ? this.f5o_1 : annotations;
    return $super === VOID ? this.w6d(ref, nativeId, role, content, refusal, annotations) : $super.w6d.call(this, new ItemRef(ref), nativeId, role, content, refusal, annotations);
  }
  toString() {
    return 'Message(ref=' + ItemRef__toString_impl_kdmppd(this.a5o_1) + ', nativeId=' + toString_0(this.b5o_1) + ', role=' + this.c5o_1.toString() + ', content=' + toString(this.d5o_1) + ', refusal=' + this.e5o_1 + ', annotations=' + toString(this.f5o_1) + ')';
  }
  hashCode() {
    var result = ItemRef__hashCode_impl_1dj73i(this.a5o_1);
    result = imul(result, 31) + (this.b5o_1 == null ? 0 : this.b5o_1.hashCode()) | 0;
    result = imul(result, 31) + this.c5o_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.d5o_1) | 0;
    result = imul(result, 31) + (this.e5o_1 == null ? 0 : getStringHashCode(this.e5o_1)) | 0;
    result = imul(result, 31) + hashCode(this.f5o_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Message))
      return false;
    var tmp0_other_with_cast = other instanceof Message ? other : THROW_CCE();
    if (!(this.a5o_1 === tmp0_other_with_cast.a5o_1))
      return false;
    if (!equals(this.b5o_1, tmp0_other_with_cast.b5o_1))
      return false;
    if (!this.c5o_1.equals(tmp0_other_with_cast.c5o_1))
      return false;
    if (!equals(this.d5o_1, tmp0_other_with_cast.d5o_1))
      return false;
    if (!(this.e5o_1 == tmp0_other_with_cast.e5o_1))
      return false;
    if (!equals(this.f5o_1, tmp0_other_with_cast.f5o_1))
      return false;
    return true;
  }
}
class ToolCall {
  constructor(ref, nativeId, name, arguments_0, nativeItemId) {
    ref = ref === VOID ? Companion_instance_32.q60('call') : ref;
    nativeId = nativeId === VOID ? null : nativeId;
    nativeItemId = nativeItemId === VOID ? null : nativeItemId;
    this.d69_1 = ref;
    this.e69_1 = nativeId;
    this.f69_1 = name;
    this.g69_1 = arguments_0;
    this.h69_1 = nativeItemId;
  }
  s5z() {
    return this.d69_1;
  }
  l6b() {
    return this.e69_1;
  }
  x6d(ref, nativeId, name, arguments_0, nativeItemId) {
    return new ToolCall(ref, nativeId, name, arguments_0, nativeItemId);
  }
  v6c(ref, nativeId, name, arguments_0, nativeItemId, $super) {
    ref = ref === VOID ? this.d69_1 : ref;
    nativeId = nativeId === VOID ? this.e69_1 : nativeId;
    name = name === VOID ? this.f69_1 : name;
    arguments_0 = arguments_0 === VOID ? this.g69_1 : arguments_0;
    nativeItemId = nativeItemId === VOID ? this.h69_1 : nativeItemId;
    return $super === VOID ? this.x6d(ref, nativeId, name, arguments_0, nativeItemId) : $super.x6d.call(this, new ItemRef(ref), nativeId, name, arguments_0, nativeItemId);
  }
  toString() {
    return 'ToolCall(ref=' + ItemRef__toString_impl_kdmppd(this.d69_1) + ', nativeId=' + toString_0(this.e69_1) + ', name=' + this.f69_1 + ', arguments=' + this.g69_1 + ', nativeItemId=' + toString_0(this.h69_1) + ')';
  }
  hashCode() {
    var result = ItemRef__hashCode_impl_1dj73i(this.d69_1);
    result = imul(result, 31) + (this.e69_1 == null ? 0 : this.e69_1.hashCode()) | 0;
    result = imul(result, 31) + getStringHashCode(this.f69_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.g69_1) | 0;
    result = imul(result, 31) + (this.h69_1 == null ? 0 : this.h69_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolCall))
      return false;
    var tmp0_other_with_cast = other instanceof ToolCall ? other : THROW_CCE();
    if (!(this.d69_1 === tmp0_other_with_cast.d69_1))
      return false;
    if (!equals(this.e69_1, tmp0_other_with_cast.e69_1))
      return false;
    if (!(this.f69_1 === tmp0_other_with_cast.f69_1))
      return false;
    if (!(this.g69_1 === tmp0_other_with_cast.g69_1))
      return false;
    if (!equals(this.h69_1, tmp0_other_with_cast.h69_1))
      return false;
    return true;
  }
}
class ToolResult_0 {
  constructor(ref, nativeId, callRef, output, isError) {
    ref = ref === VOID ? Companion_instance_32.q60('result') : ref;
    nativeId = nativeId === VOID ? null : nativeId;
    isError = isError === VOID ? false : isError;
    this.y68_1 = ref;
    this.z68_1 = nativeId;
    this.a69_1 = callRef;
    this.b69_1 = output;
    this.c69_1 = isError;
  }
  s5z() {
    return this.y68_1;
  }
  l6b() {
    return this.z68_1;
  }
  y6d(ref, nativeId, callRef, output, isError) {
    return new ToolResult_0(ref, nativeId, callRef, output, isError);
  }
  u6c(ref, nativeId, callRef, output, isError, $super) {
    ref = ref === VOID ? this.y68_1 : ref;
    nativeId = nativeId === VOID ? this.z68_1 : nativeId;
    callRef = callRef === VOID ? this.a69_1 : callRef;
    output = output === VOID ? this.b69_1 : output;
    isError = isError === VOID ? this.c69_1 : isError;
    return $super === VOID ? this.y6d(ref, nativeId, callRef, output, isError) : $super.y6d.call(this, new ItemRef(ref), nativeId, new ItemRef(callRef), output, isError);
  }
  toString() {
    return 'ToolResult(ref=' + ItemRef__toString_impl_kdmppd(this.y68_1) + ', nativeId=' + toString_0(this.z68_1) + ', callRef=' + ItemRef__toString_impl_kdmppd(this.a69_1) + ', output=' + this.b69_1 + ', isError=' + this.c69_1 + ')';
  }
  hashCode() {
    var result = ItemRef__hashCode_impl_1dj73i(this.y68_1);
    result = imul(result, 31) + (this.z68_1 == null ? 0 : this.z68_1.hashCode()) | 0;
    result = imul(result, 31) + ItemRef__hashCode_impl_1dj73i(this.a69_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.b69_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.c69_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolResult_0))
      return false;
    var tmp0_other_with_cast = other instanceof ToolResult_0 ? other : THROW_CCE();
    if (!(this.y68_1 === tmp0_other_with_cast.y68_1))
      return false;
    if (!equals(this.z68_1, tmp0_other_with_cast.z68_1))
      return false;
    if (!(this.a69_1 === tmp0_other_with_cast.a69_1))
      return false;
    if (!(this.b69_1 === tmp0_other_with_cast.b69_1))
      return false;
    if (!(this.c69_1 === tmp0_other_with_cast.c69_1))
      return false;
    return true;
  }
}
class ReasoningSummary {
  constructor(ref, nativeId, text) {
    ref = ref === VOID ? Companion_instance_32.q60('reason') : ref;
    nativeId = nativeId === VOID ? null : nativeId;
    this.m6b_1 = ref;
    this.n6b_1 = nativeId;
    this.o6b_1 = text;
  }
  s5z() {
    return this.m6b_1;
  }
  l6b() {
    return this.n6b_1;
  }
  z6d(ref, nativeId, text) {
    return new ReasoningSummary(ref, nativeId, text);
  }
  t6c(ref, nativeId, text, $super) {
    ref = ref === VOID ? this.m6b_1 : ref;
    nativeId = nativeId === VOID ? this.n6b_1 : nativeId;
    text = text === VOID ? this.o6b_1 : text;
    return $super === VOID ? this.z6d(ref, nativeId, text) : $super.z6d.call(this, new ItemRef(ref), nativeId, text);
  }
  toString() {
    return 'ReasoningSummary(ref=' + ItemRef__toString_impl_kdmppd(this.m6b_1) + ', nativeId=' + toString_0(this.n6b_1) + ', text=' + this.o6b_1 + ')';
  }
  hashCode() {
    var result = ItemRef__hashCode_impl_1dj73i(this.m6b_1);
    result = imul(result, 31) + (this.n6b_1 == null ? 0 : this.n6b_1.hashCode()) | 0;
    result = imul(result, 31) + getStringHashCode(this.o6b_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ReasoningSummary))
      return false;
    var tmp0_other_with_cast = other instanceof ReasoningSummary ? other : THROW_CCE();
    if (!(this.m6b_1 === tmp0_other_with_cast.m6b_1))
      return false;
    if (!equals(this.n6b_1, tmp0_other_with_cast.n6b_1))
      return false;
    if (!(this.o6b_1 === tmp0_other_with_cast.o6b_1))
      return false;
    return true;
  }
}
class ProviderItem {
  constructor(ref, nativeId, providerId, kind, displayText, replay, payload) {
    ref = ref === VOID ? Companion_instance_32.q60('ext') : ref;
    nativeId = nativeId === VOID ? null : nativeId;
    this.y5y_1 = ref;
    this.z5y_1 = nativeId;
    this.a5z_1 = providerId;
    this.b5z_1 = kind;
    this.c5z_1 = displayText;
    this.d5z_1 = replay;
    this.e5z_1 = payload;
  }
  s5z() {
    return this.y5y_1;
  }
  l6b() {
    return this.z5y_1;
  }
  toString() {
    return 'ProviderItem(ref=' + ItemRef__toString_impl_kdmppd(this.y5y_1) + ', nativeId=' + toString_0(this.z5y_1) + ', providerId=' + ProviderId__toString_impl_hyxggb(this.a5z_1) + ', kind=' + this.b5z_1 + ', displayText=' + this.c5z_1 + ', replay=' + this.d5z_1.toString() + ', payload=' + this.e5z_1.toString() + ')';
  }
  hashCode() {
    var result = ItemRef__hashCode_impl_1dj73i(this.y5y_1);
    result = imul(result, 31) + (this.z5y_1 == null ? 0 : this.z5y_1.hashCode()) | 0;
    result = imul(result, 31) + ProviderId__hashCode_impl_vb0opy(this.a5z_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.b5z_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.c5z_1) | 0;
    result = imul(result, 31) + this.d5z_1.hashCode() | 0;
    result = imul(result, 31) + this.e5z_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ProviderItem))
      return false;
    var tmp0_other_with_cast = other instanceof ProviderItem ? other : THROW_CCE();
    if (!(this.y5y_1 === tmp0_other_with_cast.y5y_1))
      return false;
    if (!equals(this.z5y_1, tmp0_other_with_cast.z5y_1))
      return false;
    if (!(this.a5z_1 === tmp0_other_with_cast.a5z_1))
      return false;
    if (!(this.b5z_1 === tmp0_other_with_cast.b5z_1))
      return false;
    if (!(this.c5z_1 === tmp0_other_with_cast.c5z_1))
      return false;
    if (!this.d5z_1.equals(tmp0_other_with_cast.d5z_1))
      return false;
    if (!this.e5z_1.equals(tmp0_other_with_cast.e5z_1))
      return false;
    return true;
  }
}
class Companion_34 {
  a6e(text, ref) {
    return new Message(ref, VOID, Role_SYSTEM_getInstance(), listOf(new Text(text)));
  }
  b6e(text, ref, $super) {
    ref = ref === VOID ? Companion_instance_32.q60('msg') : ref;
    return $super === VOID ? this.a6e(text, ref) : $super.a6e.call(this, text, new ItemRef(ref));
  }
  c6e(text, ref) {
    return new Message(ref, VOID, Role_USER_getInstance(), listOf(new Text(text)));
  }
  z5n(text, ref, $super) {
    ref = ref === VOID ? Companion_instance_32.q60('msg') : ref;
    return $super === VOID ? this.c6e(text, ref) : $super.c6e.call(this, text, new ItemRef(ref));
  }
  d6e(text, ref, nativeId, refusal, annotations) {
    var tmp = Role_ASSISTANT_getInstance();
    var tmp_0;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(text) === 0) {
      tmp_0 = emptyList();
    } else {
      tmp_0 = listOf(new Text(text));
    }
    return new Message(ref, nativeId, tmp, tmp_0, refusal, annotations);
  }
  m5t(text, ref, nativeId, refusal, annotations, $super) {
    ref = ref === VOID ? Companion_instance_32.q60('msg') : ref;
    nativeId = nativeId === VOID ? null : nativeId;
    refusal = refusal === VOID ? null : refusal;
    annotations = annotations === VOID ? emptyList() : annotations;
    return $super === VOID ? this.d6e(text, ref, nativeId, refusal, annotations) : $super.d6e.call(this, text, new ItemRef(ref), nativeId, refusal, annotations);
  }
}
class ModelRequest {
  constructor(instructions, items, tools, outputFormat, checkpoint, idempotencyKey) {
    tools = tools === VOID ? emptyList() : tools;
    outputFormat = outputFormat === VOID ? Text_instance : outputFormat;
    checkpoint = checkpoint === VOID ? null : checkpoint;
    this.g5y_1 = instructions;
    this.h5y_1 = items;
    this.i5y_1 = tools;
    this.j5y_1 = outputFormat;
    this.k5y_1 = checkpoint;
    this.l5y_1 = idempotencyKey;
  }
  e6e(instructions, items, tools, outputFormat, checkpoint, idempotencyKey) {
    return new ModelRequest(instructions, items, tools, outputFormat, checkpoint, idempotencyKey);
  }
  m5y(instructions, items, tools, outputFormat, checkpoint, idempotencyKey, $super) {
    instructions = instructions === VOID ? this.g5y_1 : instructions;
    items = items === VOID ? this.h5y_1 : items;
    tools = tools === VOID ? this.i5y_1 : tools;
    outputFormat = outputFormat === VOID ? this.j5y_1 : outputFormat;
    checkpoint = checkpoint === VOID ? this.k5y_1 : checkpoint;
    idempotencyKey = idempotencyKey === VOID ? this.l5y_1 : idempotencyKey;
    return $super === VOID ? this.e6e(instructions, items, tools, outputFormat, checkpoint, idempotencyKey) : $super.e6e.call(this, instructions, items, tools, outputFormat, checkpoint, idempotencyKey);
  }
  toString() {
    return 'ModelRequest(instructions=' + this.g5y_1 + ', items=' + toString(this.h5y_1) + ', tools=' + toString(this.i5y_1) + ', outputFormat=' + toString(this.j5y_1) + ', checkpoint=' + toString_0(this.k5y_1) + ', idempotencyKey=' + this.l5y_1 + ')';
  }
  hashCode() {
    var result = this.g5y_1 == null ? 0 : getStringHashCode(this.g5y_1);
    result = imul(result, 31) + hashCode(this.h5y_1) | 0;
    result = imul(result, 31) + hashCode(this.i5y_1) | 0;
    result = imul(result, 31) + hashCode(this.j5y_1) | 0;
    result = imul(result, 31) + (this.k5y_1 == null ? 0 : this.k5y_1.hashCode()) | 0;
    result = imul(result, 31) + getStringHashCode(this.l5y_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ModelRequest))
      return false;
    var tmp0_other_with_cast = other instanceof ModelRequest ? other : THROW_CCE();
    if (!(this.g5y_1 == tmp0_other_with_cast.g5y_1))
      return false;
    if (!equals(this.h5y_1, tmp0_other_with_cast.h5y_1))
      return false;
    if (!equals(this.i5y_1, tmp0_other_with_cast.i5y_1))
      return false;
    if (!equals(this.j5y_1, tmp0_other_with_cast.j5y_1))
      return false;
    if (!equals(this.k5y_1, tmp0_other_with_cast.k5y_1))
      return false;
    if (!(this.l5y_1 === tmp0_other_with_cast.l5y_1))
      return false;
    return true;
  }
}
class Completed_2 {
  constructor(id, output, usage, checkpoint) {
    id = id === VOID ? null : id;
    output = output === VOID ? emptyList() : output;
    usage = usage === VOID ? Companion_getInstance_43().t5r_1 : usage;
    checkpoint = checkpoint === VOID ? null : checkpoint;
    this.f6e_1 = id;
    this.g6e_1 = output;
    this.h6e_1 = usage;
    this.i6e_1 = checkpoint;
  }
  t60() {
    return this.f6e_1;
  }
  r60() {
    return this.g6e_1;
  }
  k5r() {
    return this.h6e_1;
  }
  s5u() {
    return this.i6e_1;
  }
  toString() {
    return 'Completed(id=' + this.f6e_1 + ', output=' + toString(this.g6e_1) + ', usage=' + this.h6e_1.toString() + ', checkpoint=' + toString_0(this.i6e_1) + ')';
  }
  hashCode() {
    var result = this.f6e_1 == null ? 0 : getStringHashCode(this.f6e_1);
    result = imul(result, 31) + hashCode(this.g6e_1) | 0;
    result = imul(result, 31) + this.h6e_1.hashCode() | 0;
    result = imul(result, 31) + (this.i6e_1 == null ? 0 : this.i6e_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Completed_2))
      return false;
    var tmp0_other_with_cast = other instanceof Completed_2 ? other : THROW_CCE();
    if (!(this.f6e_1 == tmp0_other_with_cast.f6e_1))
      return false;
    if (!equals(this.g6e_1, tmp0_other_with_cast.g6e_1))
      return false;
    if (!this.h6e_1.equals(tmp0_other_with_cast.h6e_1))
      return false;
    if (!equals(this.i6e_1, tmp0_other_with_cast.i6e_1))
      return false;
    return true;
  }
}
class Incomplete_2 {
  constructor(id, reason, output, usage, checkpoint) {
    id = id === VOID ? null : id;
    output = output === VOID ? emptyList() : output;
    usage = usage === VOID ? Companion_getInstance_43().t5r_1 : usage;
    checkpoint = checkpoint === VOID ? null : checkpoint;
    this.w5x_1 = id;
    this.x5x_1 = reason;
    this.y5x_1 = output;
    this.z5x_1 = usage;
    this.a5y_1 = checkpoint;
  }
  t60() {
    return this.w5x_1;
  }
  r60() {
    return this.y5x_1;
  }
  k5r() {
    return this.z5x_1;
  }
  s5u() {
    return this.a5y_1;
  }
  toString() {
    return 'Incomplete(id=' + this.w5x_1 + ', reason=' + toString(this.x5x_1) + ', output=' + toString(this.y5x_1) + ', usage=' + this.z5x_1.toString() + ', checkpoint=' + toString_0(this.a5y_1) + ')';
  }
  hashCode() {
    var result = this.w5x_1 == null ? 0 : getStringHashCode(this.w5x_1);
    result = imul(result, 31) + hashCode(this.x5x_1) | 0;
    result = imul(result, 31) + hashCode(this.y5x_1) | 0;
    result = imul(result, 31) + this.z5x_1.hashCode() | 0;
    result = imul(result, 31) + (this.a5y_1 == null ? 0 : this.a5y_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Incomplete_2))
      return false;
    var tmp0_other_with_cast = other instanceof Incomplete_2 ? other : THROW_CCE();
    if (!(this.w5x_1 == tmp0_other_with_cast.w5x_1))
      return false;
    if (!equals(this.x5x_1, tmp0_other_with_cast.x5x_1))
      return false;
    if (!equals(this.y5x_1, tmp0_other_with_cast.y5x_1))
      return false;
    if (!this.z5x_1.equals(tmp0_other_with_cast.z5x_1))
      return false;
    if (!equals(this.a5y_1, tmp0_other_with_cast.a5y_1))
      return false;
    return true;
  }
}
class Failed_3 {
  constructor(error, id, output, usage, checkpoint) {
    id = id === VOID ? null : id;
    output = output === VOID ? emptyList() : output;
    usage = usage === VOID ? Companion_getInstance_43().t5r_1 : usage;
    checkpoint = checkpoint === VOID ? null : checkpoint;
    this.u5u_1 = error;
    this.v5u_1 = id;
    this.w5u_1 = output;
    this.x5u_1 = usage;
    this.y5u_1 = checkpoint;
  }
  t60() {
    return this.v5u_1;
  }
  r60() {
    return this.w5u_1;
  }
  k5r() {
    return this.x5u_1;
  }
  s5u() {
    return this.y5u_1;
  }
  toString() {
    return 'Failed(error=' + this.u5u_1.toString() + ', id=' + this.v5u_1 + ', output=' + toString(this.w5u_1) + ', usage=' + this.x5u_1.toString() + ', checkpoint=' + toString_0(this.y5u_1) + ')';
  }
  hashCode() {
    var result = this.u5u_1.hashCode();
    result = imul(result, 31) + (this.v5u_1 == null ? 0 : getStringHashCode(this.v5u_1)) | 0;
    result = imul(result, 31) + hashCode(this.w5u_1) | 0;
    result = imul(result, 31) + this.x5u_1.hashCode() | 0;
    result = imul(result, 31) + (this.y5u_1 == null ? 0 : this.y5u_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Failed_3))
      return false;
    var tmp0_other_with_cast = other instanceof Failed_3 ? other : THROW_CCE();
    if (!this.u5u_1.equals(tmp0_other_with_cast.u5u_1))
      return false;
    if (!(this.v5u_1 == tmp0_other_with_cast.v5u_1))
      return false;
    if (!equals(this.w5u_1, tmp0_other_with_cast.w5u_1))
      return false;
    if (!this.x5u_1.equals(tmp0_other_with_cast.x5u_1))
      return false;
    if (!equals(this.y5u_1, tmp0_other_with_cast.y5u_1))
      return false;
    return true;
  }
}
class MaxOutputTokens {
  toString() {
    return 'MaxOutputTokens';
  }
  hashCode() {
    return -1414698917;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MaxOutputTokens))
      return false;
    other instanceof MaxOutputTokens || THROW_CCE();
    return true;
  }
}
class ContentFilter {
  toString() {
    return 'ContentFilter';
  }
  hashCode() {
    return -1428335827;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ContentFilter))
      return false;
    other instanceof ContentFilter || THROW_CCE();
    return true;
  }
}
class Cancelled_0 {
  toString() {
    return 'Cancelled';
  }
  hashCode() {
    return 603643181;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Cancelled_0))
      return false;
    other instanceof Cancelled_0 || THROW_CCE();
    return true;
  }
}
class Other {
  constructor(code) {
    this.j6e_1 = code;
  }
  toString() {
    return 'Other(code=' + this.j6e_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.j6e_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Other))
      return false;
    var tmp0_other_with_cast = other instanceof Other ? other : THROW_CCE();
    if (!(this.j6e_1 === tmp0_other_with_cast.j6e_1))
      return false;
    return true;
  }
}
class Text_0 {
  toString() {
    return 'Text';
  }
  hashCode() {
    return -652062085;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Text_0))
      return false;
    other instanceof Text_0 || THROW_CCE();
    return true;
  }
}
class JsonObject_0 {
  toString() {
    return 'JsonObject';
  }
  hashCode() {
    return 1513130261;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof JsonObject_0))
      return false;
    other instanceof JsonObject_0 || THROW_CCE();
    return true;
  }
}
class JsonSchema {
  constructor(name, schema, strict) {
    strict = strict === VOID ? false : strict;
    this.k6e_1 = name;
    this.l6e_1 = schema;
    this.m6e_1 = strict;
  }
  toString() {
    return 'JsonSchema(name=' + this.k6e_1 + ', schema=' + this.l6e_1.toString() + ', strict=' + this.m6e_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.k6e_1);
    result = imul(result, 31) + this.l6e_1.hashCode() | 0;
    result = imul(result, 31) + getBooleanHashCode(this.m6e_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof JsonSchema))
      return false;
    var tmp0_other_with_cast = other instanceof JsonSchema ? other : THROW_CCE();
    if (!(this.k6e_1 === tmp0_other_with_cast.k6e_1))
      return false;
    if (!this.l6e_1.equals(tmp0_other_with_cast.l6e_1))
      return false;
    if (!(this.m6e_1 === tmp0_other_with_cast.m6e_1))
      return false;
    return true;
  }
}
class ReplayPolicy extends Enum {}
class Companion_35 {
  constructor() {
    Companion_instance_37 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.n6e_1 = lazy(tmp_0, Role$Companion$_anonymous__n893s7);
  }
  c3o() {
    return _get_$cachedSerializer__te6jhj(this);
  }
  g26(typeParamsSerializers) {
    return this.c3o();
  }
}
class Role extends Enum {}
class Support extends Enum {
  s6d() {
    return this.equals(Support_Unsupported_getInstance());
  }
}
class Companion_36 {}
class $serializer_28 {
  constructor() {
    $serializer_instance_27 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.model.ToolCall', this, 5);
    tmp0_serialDesc.f25('id', false);
    tmp0_serialDesc.f25('name', false);
    tmp0_serialDesc.f25('arguments', false);
    tmp0_serialDesc.f25('nativeId', true);
    tmp0_serialDesc.f25('nativeItemId', true);
    this.o6e_1 = tmp0_serialDesc;
  }
  p6e(encoder, value) {
    var tmp0_desc = this.o6e_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.m5v_1);
    tmp1_output.g1z(tmp0_desc, 1, value.n5v_1);
    tmp1_output.g1z(tmp0_desc, 2, value.o5v_1);
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.p5v_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, $serializer_getInstance_26(), value.p5v_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.q5v_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 4, $serializer_getInstance_26(), value.q5v_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.p6e(encoder, value instanceof ToolCall_0 ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.o6e_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.q1x(tmp0_desc);
    if (tmp9_input.g1y()) {
      tmp4_local0 = tmp9_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.a1y(tmp0_desc, 2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, $serializer_getInstance_26(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, $serializer_getInstance_26(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.a1y(tmp0_desc, 2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, $serializer_getInstance_26(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, $serializer_getInstance_26(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp9_input.r1x(tmp0_desc);
    return ToolCall_0.q6e(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  h1t() {
    return this.o6e_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), StringSerializer_getInstance(), get_nullable($serializer_getInstance_26()), get_nullable($serializer_getInstance_26())];
  }
}
class ToolCall_0 {
  constructor(id, name, arguments_0, nativeId, nativeItemId) {
    nativeId = nativeId === VOID ? null : nativeId;
    nativeItemId = nativeItemId === VOID ? null : nativeItemId;
    this.m5v_1 = id;
    this.n5v_1 = name;
    this.o5v_1 = arguments_0;
    this.p5v_1 = nativeId;
    this.q5v_1 = nativeItemId;
  }
  s5z() {
    return _ItemRef___init__impl__ipmeex(this.m5v_1);
  }
  u60() {
    var tmp0_ref = this.s5z();
    var tmp1_nativeId = this.p5v_1;
    var tmp2_nativeItemId = this.q5v_1;
    var tmp3_name = this.n5v_1;
    var tmp4_arguments = this.o5v_1;
    return new ToolCall(tmp0_ref, tmp1_nativeId, tmp3_name, tmp4_arguments, tmp2_nativeItemId);
  }
  r6e(id, name, arguments_0, nativeId, nativeItemId) {
    return new ToolCall_0(id, name, arguments_0, nativeId, nativeItemId);
  }
  a5w(id, name, arguments_0, nativeId, nativeItemId, $super) {
    id = id === VOID ? this.m5v_1 : id;
    name = name === VOID ? this.n5v_1 : name;
    arguments_0 = arguments_0 === VOID ? this.o5v_1 : arguments_0;
    nativeId = nativeId === VOID ? this.p5v_1 : nativeId;
    nativeItemId = nativeItemId === VOID ? this.q5v_1 : nativeItemId;
    return $super === VOID ? this.r6e(id, name, arguments_0, nativeId, nativeItemId) : $super.r6e.call(this, id, name, arguments_0, nativeId, nativeItemId);
  }
  toString() {
    return 'ToolCall(id=' + this.m5v_1 + ', name=' + this.n5v_1 + ', arguments=' + this.o5v_1 + ', nativeId=' + toString_0(this.p5v_1) + ', nativeItemId=' + toString_0(this.q5v_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.m5v_1);
    result = imul(result, 31) + getStringHashCode(this.n5v_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.o5v_1) | 0;
    result = imul(result, 31) + (this.p5v_1 == null ? 0 : this.p5v_1.hashCode()) | 0;
    result = imul(result, 31) + (this.q5v_1 == null ? 0 : this.q5v_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolCall_0))
      return false;
    var tmp0_other_with_cast = other instanceof ToolCall_0 ? other : THROW_CCE();
    if (!(this.m5v_1 === tmp0_other_with_cast.m5v_1))
      return false;
    if (!(this.n5v_1 === tmp0_other_with_cast.n5v_1))
      return false;
    if (!(this.o5v_1 === tmp0_other_with_cast.o5v_1))
      return false;
    if (!equals(this.p5v_1, tmp0_other_with_cast.p5v_1))
      return false;
    if (!equals(this.q5v_1, tmp0_other_with_cast.q5v_1))
      return false;
    return true;
  }
  static q6e(seen0, id, name, arguments_0, nativeId, nativeItemId, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_27().o6e_1);
    }
    var $this = createThis(this);
    $this.m5v_1 = id;
    $this.n5v_1 = name;
    $this.o5v_1 = arguments_0;
    if (0 === (seen0 & 8))
      $this.p5v_1 = null;
    else
      $this.p5v_1 = nativeId;
    if (0 === (seen0 & 16))
      $this.q5v_1 = null;
    else
      $this.q5v_1 = nativeItemId;
    return $this;
  }
}
class TypeAdapter {
  constructor(serializer, deserializer) {
    this.s6e_1 = serializer;
    this.t6e_1 = deserializer;
  }
  toString() {
    return 'TypeAdapter(serializer=' + toString(this.s6e_1) + ', deserializer=' + toString(this.t6e_1) + ')';
  }
  hashCode() {
    var result = hashCode(this.s6e_1);
    result = imul(result, 31) + hashCode(this.t6e_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof TypeAdapter))
      return false;
    var tmp0_other_with_cast = other instanceof TypeAdapter ? other : THROW_CCE();
    if (!equals(this.s6e_1, tmp0_other_with_cast.s6e_1))
      return false;
    if (!equals(this.t6e_1, tmp0_other_with_cast.t6e_1))
      return false;
    return true;
  }
}
class Companion_37 {
  constructor() {
    Companion_instance_39 = this;
    this.t5r_1 = new Usage();
  }
}
class $serializer_29 {
  constructor() {
    $serializer_instance_28 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.model.Usage', this, 5);
    tmp0_serialDesc.f25('promptTokens', true);
    tmp0_serialDesc.f25('completionTokens', true);
    tmp0_serialDesc.f25('totalTokens', true);
    tmp0_serialDesc.f25('cachedInputTokens', true);
    tmp0_serialDesc.f25('reasoningOutputTokens', true);
    this.u6e_1 = tmp0_serialDesc;
  }
  v6e(encoder, value) {
    var tmp0_desc = this.u6e_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.n5y_1 === 0)) {
      tmp1_output.b1z(tmp0_desc, 0, value.n5y_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.o5y_1 === 0)) {
      tmp1_output.b1z(tmp0_desc, 1, value.o5y_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.p5y_1 === 0)) {
      tmp1_output.b1z(tmp0_desc, 2, value.p5y_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.q5y_1 === 0)) {
      tmp1_output.b1z(tmp0_desc, 3, value.q5y_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.r5y_1 === 0)) {
      tmp1_output.b1z(tmp0_desc, 4, value.r5y_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.v6e(encoder, value instanceof Usage ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.u6e_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = 0;
    var tmp5_local1 = 0;
    var tmp6_local2 = 0;
    var tmp7_local3 = 0;
    var tmp8_local4 = 0;
    var tmp9_input = decoder.q1x(tmp0_desc);
    if (tmp9_input.g1y()) {
      tmp4_local0 = tmp9_input.v1x(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.v1x(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.v1x(tmp0_desc, 2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.v1x(tmp0_desc, 3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.v1x(tmp0_desc, 4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.v1x(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.v1x(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.v1x(tmp0_desc, 2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.v1x(tmp0_desc, 3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.v1x(tmp0_desc, 4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp9_input.r1x(tmp0_desc);
    return Usage.w6e(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  h1t() {
    return this.u6e_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [IntSerializer_getInstance(), IntSerializer_getInstance(), IntSerializer_getInstance(), IntSerializer_getInstance(), IntSerializer_getInstance()];
  }
}
class Usage {
  constructor(promptTokens, completionTokens, totalTokens, cachedInputTokens, reasoningOutputTokens) {
    Companion_getInstance_43();
    promptTokens = promptTokens === VOID ? 0 : promptTokens;
    completionTokens = completionTokens === VOID ? 0 : completionTokens;
    totalTokens = totalTokens === VOID ? 0 : totalTokens;
    cachedInputTokens = cachedInputTokens === VOID ? 0 : cachedInputTokens;
    reasoningOutputTokens = reasoningOutputTokens === VOID ? 0 : reasoningOutputTokens;
    this.n5y_1 = promptTokens;
    this.o5y_1 = completionTokens;
    this.p5y_1 = totalTokens;
    this.q5y_1 = cachedInputTokens;
    this.r5y_1 = reasoningOutputTokens;
  }
  s5y(other) {
    return new Usage(this.n5y_1 + other.n5y_1 | 0, this.o5y_1 + other.o5y_1 | 0, this.p5y_1 + other.p5y_1 | 0, this.q5y_1 + other.q5y_1 | 0, this.r5y_1 + other.r5y_1 | 0);
  }
  toString() {
    return 'Usage(promptTokens=' + this.n5y_1 + ', completionTokens=' + this.o5y_1 + ', totalTokens=' + this.p5y_1 + ', cachedInputTokens=' + this.q5y_1 + ', reasoningOutputTokens=' + this.r5y_1 + ')';
  }
  hashCode() {
    var result = this.n5y_1;
    result = imul(result, 31) + this.o5y_1 | 0;
    result = imul(result, 31) + this.p5y_1 | 0;
    result = imul(result, 31) + this.q5y_1 | 0;
    result = imul(result, 31) + this.r5y_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Usage))
      return false;
    var tmp0_other_with_cast = other instanceof Usage ? other : THROW_CCE();
    if (!(this.n5y_1 === tmp0_other_with_cast.n5y_1))
      return false;
    if (!(this.o5y_1 === tmp0_other_with_cast.o5y_1))
      return false;
    if (!(this.p5y_1 === tmp0_other_with_cast.p5y_1))
      return false;
    if (!(this.q5y_1 === tmp0_other_with_cast.q5y_1))
      return false;
    if (!(this.r5y_1 === tmp0_other_with_cast.r5y_1))
      return false;
    return true;
  }
  static w6e(seen0, promptTokens, completionTokens, totalTokens, cachedInputTokens, reasoningOutputTokens, serializationConstructorMarker) {
    Companion_getInstance_43();
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_28().u6e_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.n5y_1 = 0;
    else
      $this.n5y_1 = promptTokens;
    if (0 === (seen0 & 2))
      $this.o5y_1 = 0;
    else
      $this.o5y_1 = completionTokens;
    if (0 === (seen0 & 4))
      $this.p5y_1 = 0;
    else
      $this.p5y_1 = totalTokens;
    if (0 === (seen0 & 8))
      $this.q5y_1 = 0;
    else
      $this.q5y_1 = cachedInputTokens;
    if (0 === (seen0 & 16))
      $this.r5y_1 = 0;
    else
      $this.r5y_1 = reasoningOutputTokens;
    return $this;
  }
}
class HttpClientConfig {
  constructor(baseUrl, apiKey, connectTimeout, writeTimeout, readTimeout, callTimeout, streamEndMarker, customHeaders) {
    apiKey = apiKey === VOID ? null : apiKey;
    connectTimeout = connectTimeout === VOID ? new Long(5, 0) : connectTimeout;
    writeTimeout = writeTimeout === VOID ? new Long(60, 0) : writeTimeout;
    readTimeout = readTimeout === VOID ? new Long(600, 0) : readTimeout;
    callTimeout = callTimeout === VOID ? new Long(600, 0) : callTimeout;
    streamEndMarker = streamEndMarker === VOID ? '[DONE]' : streamEndMarker;
    customHeaders = customHeaders === VOID ? emptyMap() : customHeaders;
    this.x6e_1 = baseUrl;
    this.y6e_1 = apiKey;
    this.z6e_1 = connectTimeout;
    this.a6f_1 = writeTimeout;
    this.b6f_1 = readTimeout;
    this.c6f_1 = callTimeout;
    this.d6f_1 = streamEndMarker;
    this.e6f_1 = customHeaders;
  }
  toString() {
    return 'HttpClientConfig(baseUrl=' + this.x6e_1 + ', apiKey=' + this.y6e_1 + ', connectTimeout=' + this.z6e_1.toString() + ', writeTimeout=' + this.a6f_1.toString() + ', readTimeout=' + this.b6f_1.toString() + ', callTimeout=' + this.c6f_1.toString() + ', streamEndMarker=' + this.d6f_1 + ', customHeaders=' + toString(this.e6f_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.x6e_1);
    result = imul(result, 31) + (this.y6e_1 == null ? 0 : getStringHashCode(this.y6e_1)) | 0;
    result = imul(result, 31) + this.z6e_1.hashCode() | 0;
    result = imul(result, 31) + this.a6f_1.hashCode() | 0;
    result = imul(result, 31) + this.b6f_1.hashCode() | 0;
    result = imul(result, 31) + this.c6f_1.hashCode() | 0;
    result = imul(result, 31) + getStringHashCode(this.d6f_1) | 0;
    result = imul(result, 31) + hashCode(this.e6f_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof HttpClientConfig))
      return false;
    var tmp0_other_with_cast = other instanceof HttpClientConfig ? other : THROW_CCE();
    if (!(this.x6e_1 === tmp0_other_with_cast.x6e_1))
      return false;
    if (!(this.y6e_1 == tmp0_other_with_cast.y6e_1))
      return false;
    if (!this.z6e_1.equals(tmp0_other_with_cast.z6e_1))
      return false;
    if (!this.a6f_1.equals(tmp0_other_with_cast.a6f_1))
      return false;
    if (!this.b6f_1.equals(tmp0_other_with_cast.b6f_1))
      return false;
    if (!this.c6f_1.equals(tmp0_other_with_cast.c6f_1))
      return false;
    if (!(this.d6f_1 === tmp0_other_with_cast.d6f_1))
      return false;
    if (!equals(this.e6f_1, tmp0_other_with_cast.e6f_1))
      return false;
    return true;
  }
}
class HttpClientException extends RuntimeException {
  static i6f(message, cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.be(message, cause);
    captureStack($this, $this.h6f_1);
    return $this;
  }
}
class JsonParseException extends RuntimeException {}
class KtorHttpClient {
  constructor(config) {
    this.u62_1 = config;
    var tmp = this;
    var tmp_0 = KotlinLogging_instance;
    tmp.v62_1 = tmp_0.g5l(KtorHttpClient$logger$lambda);
    var tmp_1 = this;
    var tmp_2 = provideEngine();
    tmp_1.w62_1 = HttpClient(tmp_2, KtorHttpClient$ktorClient$lambda(this));
  }
  y62(request, serializer, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_postAsString__w3dwat.bind(VOID, this, request, serializer), $completion);
  }
  x62(request, adapter, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_postAsObject__z9hk89.bind(VOID, this, request, adapter), $completion);
  }
  a6() {
    this.w62_1.a6();
  }
}
class SuspendErrorPolicy {}
class ErrorPolicy {}
class sam$org_koaks_framework_policy_ErrorPolicy$0 {
  constructor(function_0) {
    this.m6f_1 = function_0;
  }
  m5x(error, state) {
    return this.m6f_1(error, state);
  }
  n4() {
    return this.m6f_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, ErrorPolicy) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$org_koaks_framework_policy_ErrorPolicy$0_0 {
  constructor(function_0) {
    this.n6f_1 = function_0;
  }
  m5x(error, state) {
    return this.n6f_1(error, state);
  }
  n4() {
    return this.n6f_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, ErrorPolicy) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$org_koaks_framework_policy_ErrorPolicy$0_1 {
  constructor(function_0) {
    this.o6f_1 = function_0;
  }
  m5x(error, state) {
    return this.o6f_1(error, state);
  }
  n4() {
    return this.o6f_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, ErrorPolicy) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class Companion_38 {
  constructor() {
    Companion_instance_40 = this;
    var tmp = this;
    var tmp_0 = ErrorPolicy$Companion$PROPAGATE$lambda;
    tmp.x5p_1 = new sam$org_koaks_framework_policy_ErrorPolicy$0(tmp_0);
  }
  p6f(maxRetries, delayMs) {
    var tmp = ErrorPolicy$Companion$retryRetriable$lambda(delayMs, maxRetries);
    return new sam$org_koaks_framework_policy_ErrorPolicy$0_0(tmp);
  }
  q6f(fallbackMessage) {
    var tmp = ErrorPolicy$Companion$substituteOnError$lambda(fallbackMessage);
    return new sam$org_koaks_framework_policy_ErrorPolicy$0_1(tmp);
  }
}
class Propagate {
  toString() {
    return 'Propagate';
  }
  hashCode() {
    return 2000104457;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Propagate))
      return false;
    other instanceof Propagate || THROW_CCE();
    return true;
  }
}
class Retry {
  constructor(delayMs, maxRetries) {
    this.q5x_1 = delayMs;
    this.r5x_1 = maxRetries;
  }
  toString() {
    return 'Retry(delayMs=' + this.q5x_1.toString() + ', maxRetries=' + this.r5x_1 + ')';
  }
  hashCode() {
    var result = this.q5x_1.hashCode();
    result = imul(result, 31) + this.r5x_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Retry))
      return false;
    var tmp0_other_with_cast = other instanceof Retry ? other : THROW_CCE();
    if (!this.q5x_1.equals(tmp0_other_with_cast.q5x_1))
      return false;
    if (!(this.r5x_1 === tmp0_other_with_cast.r5x_1))
      return false;
    return true;
  }
}
class Substitute {
  constructor(message) {
    this.n5x_1 = message;
  }
  toString() {
    return 'Substitute(message=' + toString(this.n5x_1) + ')';
  }
  hashCode() {
    return hashCode(this.n5x_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Substitute))
      return false;
    var tmp0_other_with_cast = other instanceof Substitute ? other : THROW_CCE();
    if (!equals(this.n5x_1, tmp0_other_with_cast.n5x_1))
      return false;
    return true;
  }
}
class Companion_39 {
  constructor() {
    Companion_instance_41 = this;
    this.y5p_1 = new RunBudget();
  }
}
class RunBudget {
  constructor(maxTotalSteps, maxTotalTokens) {
    Companion_getInstance_45();
    maxTotalSteps = maxTotalSteps === VOID ? null : maxTotalSteps;
    maxTotalTokens = maxTotalTokens === VOID ? null : maxTotalTokens;
    this.k5z_1 = maxTotalSteps;
    this.l5z_1 = maxTotalTokens;
  }
  m5z(state) {
    if (!(this.k5z_1 == null) && state.v5o_1 >= this.k5z_1) {
      return new Stop(new RunBudgetSteps(this.k5z_1));
    }
    if (!(this.l5z_1 == null) && state.x5o_1.p5y_1 >= this.l5z_1) {
      return new Stop(new RunBudgetTokens(this.l5z_1));
    }
    return Continue_instance;
  }
  toString() {
    return 'RunBudget(maxTotalSteps=' + this.k5z_1 + ', maxTotalTokens=' + this.l5z_1 + ')';
  }
  hashCode() {
    var result = this.k5z_1 == null ? 0 : this.k5z_1;
    result = imul(result, 31) + (this.l5z_1 == null ? 0 : this.l5z_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RunBudget))
      return false;
    var tmp0_other_with_cast = other instanceof RunBudget ? other : THROW_CCE();
    if (!(this.k5z_1 == tmp0_other_with_cast.k5z_1))
      return false;
    if (!(this.l5z_1 == tmp0_other_with_cast.l5z_1))
      return false;
    return true;
  }
}
class TerminationPolicy {}
class sam$org_koaks_framework_policy_TerminationPolicy$0 {
  constructor(function_0) {
    this.r6f_1 = function_0;
  }
  m5z(state) {
    return this.r6f_1(state);
  }
  n4() {
    return this.r6f_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, TerminationPolicy) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$org_koaks_framework_policy_TerminationPolicy$0_0 {
  constructor(function_0) {
    this.s6f_1 = function_0;
  }
  m5z(state) {
    return this.s6f_1(state);
  }
  n4() {
    return this.s6f_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, TerminationPolicy) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$org_koaks_framework_policy_TerminationPolicy$0_1 {
  constructor(function_0) {
    this.t6f_1 = function_0;
  }
  m5z(state) {
    return this.t6f_1(state);
  }
  n4() {
    return this.t6f_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, TerminationPolicy) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class Companion_40 {
  w5p(n) {
    var tmp = TerminationPolicy$Companion$maxSteps$lambda(n);
    return new sam$org_koaks_framework_policy_TerminationPolicy$0(tmp);
  }
  u6f(n) {
    var tmp = TerminationPolicy$Companion$maxTokens$lambda(n);
    return new sam$org_koaks_framework_policy_TerminationPolicy$0_0(tmp);
  }
  v6f(policies) {
    var tmp = TerminationPolicy$Companion$anyOf$lambda(policies);
    return new sam$org_koaks_framework_policy_TerminationPolicy$0_1(tmp);
  }
}
class SuspendTerminationPolicy {}
class Continue {
  toString() {
    return 'Continue';
  }
  hashCode() {
    return 1891203278;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Continue))
      return false;
    other instanceof Continue || THROW_CCE();
    return true;
  }
}
class Stop {
  constructor(reason) {
    this.j5x_1 = reason;
  }
  toString() {
    return 'Stop(reason=' + toString(this.j5x_1) + ')';
  }
  hashCode() {
    return hashCode(this.j5x_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Stop))
      return false;
    var tmp0_other_with_cast = other instanceof Stop ? other : THROW_CCE();
    if (!equals(this.j5x_1, tmp0_other_with_cast.j5x_1))
      return false;
    return true;
  }
}
class MaxSteps {
  constructor(maxSteps) {
    this.w6f_1 = maxSteps;
  }
  toString() {
    return 'MaxSteps(maxSteps=' + this.w6f_1 + ')';
  }
  hashCode() {
    return this.w6f_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MaxSteps))
      return false;
    var tmp0_other_with_cast = other instanceof MaxSteps ? other : THROW_CCE();
    if (!(this.w6f_1 === tmp0_other_with_cast.w6f_1))
      return false;
    return true;
  }
}
class MaxTokens {
  constructor(maxTokens) {
    this.x6f_1 = maxTokens;
  }
  toString() {
    return 'MaxTokens(maxTokens=' + this.x6f_1 + ')';
  }
  hashCode() {
    return this.x6f_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MaxTokens))
      return false;
    var tmp0_other_with_cast = other instanceof MaxTokens ? other : THROW_CCE();
    if (!(this.x6f_1 === tmp0_other_with_cast.x6f_1))
      return false;
    return true;
  }
}
class RunBudgetSteps {
  constructor(maxTotalSteps) {
    this.y6f_1 = maxTotalSteps;
  }
  toString() {
    return 'RunBudgetSteps(maxTotalSteps=' + this.y6f_1 + ')';
  }
  hashCode() {
    return this.y6f_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RunBudgetSteps))
      return false;
    var tmp0_other_with_cast = other instanceof RunBudgetSteps ? other : THROW_CCE();
    if (!(this.y6f_1 === tmp0_other_with_cast.y6f_1))
      return false;
    return true;
  }
}
class RunBudgetTokens {
  constructor(maxTotalTokens) {
    this.z6f_1 = maxTotalTokens;
  }
  toString() {
    return 'RunBudgetTokens(maxTotalTokens=' + this.z6f_1 + ')';
  }
  hashCode() {
    return this.z6f_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RunBudgetTokens))
      return false;
    var tmp0_other_with_cast = other instanceof RunBudgetTokens ? other : THROW_CCE();
    if (!(this.z6f_1 === tmp0_other_with_cast.z6f_1))
      return false;
    return true;
  }
}
class Custom {
  constructor(message) {
    this.a6g_1 = message;
  }
  toString() {
    return 'Custom(message=' + this.a6g_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.a6g_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Custom))
      return false;
    var tmp0_other_with_cast = other instanceof Custom ? other : THROW_CCE();
    if (!(this.a6g_1 === tmp0_other_with_cast.a6g_1))
      return false;
    return true;
  }
}
class Bearer {
  b6g(apiKey) {
    var tmp;
    // Inline function 'kotlin.text.isNullOrBlank' call
    if (apiKey == null || isBlank(apiKey)) {
      tmp = emptyList();
    } else {
      tmp = listOf(to('Authorization', 'Bearer ' + apiKey));
    }
    return tmp;
  }
  toString() {
    return 'Bearer';
  }
  hashCode() {
    return 67895848;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Bearer))
      return false;
    other instanceof Bearer || THROW_CCE();
    return true;
  }
}
class Header {
  constructor(name) {
    this.c6g_1 = name;
  }
  b6g(apiKey) {
    var tmp;
    // Inline function 'kotlin.text.isNullOrBlank' call
    if (apiKey == null || isBlank(apiKey)) {
      tmp = emptyList();
    } else {
      tmp = listOf(to(this.c6g_1, apiKey));
    }
    return tmp;
  }
  toString() {
    return 'Header(name=' + this.c6g_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.c6g_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Header))
      return false;
    var tmp0_other_with_cast = other instanceof Header ? other : THROW_CCE();
    if (!(this.c6g_1 === tmp0_other_with_cast.c6g_1))
      return false;
    return true;
  }
}
class ChatModel$stream$slambda$slambda {
  constructor($decoder, $finished, $this_flow) {
    this.d6g_1 = $decoder;
    this.e6g_1 = $finished;
    this.f6g_1 = $this_flow;
  }
  o6g(frame, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_15.bind(VOID, this, frame), $completion);
  }
  td(p1, $completion) {
    return this.o6g((!(p1 == null) ? isInterface(p1, WireFrame) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_3 {
  constructor(function_0) {
    this.p6g_1 = function_0;
  }
  t1c(value, $completion) {
    return this.p6g_1(value, $completion);
  }
  n4() {
    return this.p6g_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class ChatModel$stream$slambda {
  constructor(this$0, $request) {
    this.h6g_1 = this$0;
    this.i6g_1 = $request;
  }
  s6c($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_16.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.s6c((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class ChatModel {
  constructor(config, transport) {
    this.j6g_1 = config;
    this.k6g_1 = transport;
  }
  l6g(request) {
    return this.j1s();
  }
  m6g(request) {
    return this.k6g_1.r6g(this.q6g(request));
  }
  w5y(request) {
    return flow(ChatModel$stream$slambda_0(this, request));
  }
}
class RetryBudget {
  constructor(maxRetries, initialBackoffMs) {
    maxRetries = maxRetries === VOID ? 2 : maxRetries;
    initialBackoffMs = initialBackoffMs === VOID ? new Long(200, 0) : initialBackoffMs;
    this.s6g_1 = maxRetries;
    this.t6g_1 = initialBackoffMs;
  }
  toString() {
    return 'RetryBudget(maxRetries=' + this.s6g_1 + ', initialBackoffMs=' + this.t6g_1.toString() + ')';
  }
  hashCode() {
    var result = this.s6g_1;
    result = imul(result, 31) + this.t6g_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RetryBudget))
      return false;
    var tmp0_other_with_cast = other instanceof RetryBudget ? other : THROW_CCE();
    if (!(this.s6g_1 === tmp0_other_with_cast.s6g_1))
      return false;
    if (!this.t6g_1.equals(tmp0_other_with_cast.t6g_1))
      return false;
    return true;
  }
}
class ModelConfig {
  constructor(baseUrl, apiKey, modelName, auth, customHeaders, connectTimeoutMs, requestTimeoutMs, socketTimeoutMs, streamIdleTimeoutMs, retry, rateLimit) {
    apiKey = apiKey === VOID ? null : apiKey;
    auth = auth === VOID ? Bearer_instance : auth;
    customHeaders = customHeaders === VOID ? emptyMap() : customHeaders;
    connectTimeoutMs = connectTimeoutMs === VOID ? new Long(5000, 0) : connectTimeoutMs;
    requestTimeoutMs = requestTimeoutMs === VOID ? new Long(600000, 0) : requestTimeoutMs;
    socketTimeoutMs = socketTimeoutMs === VOID ? new Long(600000, 0) : socketTimeoutMs;
    streamIdleTimeoutMs = streamIdleTimeoutMs === VOID ? new Long(60000, 0) : streamIdleTimeoutMs;
    retry = retry === VOID ? new RetryBudget() : retry;
    rateLimit = rateLimit === VOID ? null : rateLimit;
    this.u6g_1 = baseUrl;
    this.v6g_1 = apiKey;
    this.w6g_1 = modelName;
    this.x6g_1 = auth;
    this.y6g_1 = customHeaders;
    this.z6g_1 = connectTimeoutMs;
    this.a6h_1 = requestTimeoutMs;
    this.b6h_1 = socketTimeoutMs;
    this.c6h_1 = streamIdleTimeoutMs;
    this.d6h_1 = retry;
    this.e6h_1 = rateLimit;
    // Inline function 'kotlin.require' call
    if (!(this.z6g_1.s1(new Long(0, 0)) > 0)) {
      var message = 'connectTimeoutMs must be positive';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.a6h_1.s1(new Long(0, 0)) > 0)) {
      var message_0 = 'requestTimeoutMs must be positive';
      throw IllegalArgumentException.t(toString(message_0));
    }
    // Inline function 'kotlin.require' call
    if (!(this.b6h_1.s1(new Long(0, 0)) > 0)) {
      var message_1 = 'socketTimeoutMs must be positive';
      throw IllegalArgumentException.t(toString(message_1));
    }
    // Inline function 'kotlin.require' call
    if (!(this.c6h_1.s1(new Long(0, 0)) > 0)) {
      var message_2 = 'streamIdleTimeoutMs must be positive';
      throw IllegalArgumentException.t(toString(message_2));
    }
  }
  toString() {
    return 'ModelConfig(baseUrl=' + this.u6g_1 + ', apiKey=' + this.v6g_1 + ', modelName=' + this.w6g_1 + ', auth=' + toString(this.x6g_1) + ', customHeaders=' + toString(this.y6g_1) + ', connectTimeoutMs=' + this.z6g_1.toString() + ', requestTimeoutMs=' + this.a6h_1.toString() + ', socketTimeoutMs=' + this.b6h_1.toString() + ', streamIdleTimeoutMs=' + this.c6h_1.toString() + ', retry=' + this.d6h_1.toString() + ', rateLimit=' + toString_0(this.e6h_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.u6g_1);
    result = imul(result, 31) + (this.v6g_1 == null ? 0 : getStringHashCode(this.v6g_1)) | 0;
    result = imul(result, 31) + getStringHashCode(this.w6g_1) | 0;
    result = imul(result, 31) + hashCode(this.x6g_1) | 0;
    result = imul(result, 31) + hashCode(this.y6g_1) | 0;
    result = imul(result, 31) + this.z6g_1.hashCode() | 0;
    result = imul(result, 31) + this.a6h_1.hashCode() | 0;
    result = imul(result, 31) + this.b6h_1.hashCode() | 0;
    result = imul(result, 31) + this.c6h_1.hashCode() | 0;
    result = imul(result, 31) + this.d6h_1.hashCode() | 0;
    result = imul(result, 31) + (this.e6h_1 == null ? 0 : this.e6h_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ModelConfig))
      return false;
    var tmp0_other_with_cast = other instanceof ModelConfig ? other : THROW_CCE();
    if (!(this.u6g_1 === tmp0_other_with_cast.u6g_1))
      return false;
    if (!(this.v6g_1 == tmp0_other_with_cast.v6g_1))
      return false;
    if (!(this.w6g_1 === tmp0_other_with_cast.w6g_1))
      return false;
    if (!equals(this.x6g_1, tmp0_other_with_cast.x6g_1))
      return false;
    if (!equals(this.y6g_1, tmp0_other_with_cast.y6g_1))
      return false;
    if (!this.z6g_1.equals(tmp0_other_with_cast.z6g_1))
      return false;
    if (!this.a6h_1.equals(tmp0_other_with_cast.a6h_1))
      return false;
    if (!this.b6h_1.equals(tmp0_other_with_cast.b6h_1))
      return false;
    if (!this.c6h_1.equals(tmp0_other_with_cast.c6h_1))
      return false;
    if (!this.d6h_1.equals(tmp0_other_with_cast.d6h_1))
      return false;
    if (!equals(this.e6h_1, tmp0_other_with_cast.e6h_1))
      return false;
    return true;
  }
}
class MarkdownDirectorySkillLoader {
  static k6i(root, explicitFileSystem) {
    var $this = createThis(this);
    $this.f6h_1 = root;
    // Inline function 'kotlin.text.isNotBlank' call
    var this_0 = $this.f6h_1;
    // Inline function 'kotlin.require' call
    if (!!isBlank(this_0)) {
      var message = 'skill source path must not be blank';
      throw IllegalArgumentException.t(toString(message));
    }
    $this.g6h_1 = Mutex();
    $this.h6h_1 = explicitFileSystem;
    $this.i6h_1 = !(explicitFileSystem == null);
    $this.j6h_1 = Mutex();
    $this.k6h_1 = null;
    return $this;
  }
  static l6i(root) {
    return this.k6i(root, null);
  }
  k61($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_discover__xd3vwf_0.bind(VOID, this), $completion);
  }
  m6i(id, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda_0.bind(VOID, this, id), $completion);
  }
}
class IndexedSkill {
  constructor(skillRoot, skillFile, descriptor) {
    this.u6h_1 = skillRoot;
    this.v6h_1 = skillFile;
    this.w6h_1 = descriptor;
  }
  toString() {
    return 'IndexedSkill(skillRoot=' + this.u6h_1.toString() + ', skillFile=' + this.v6h_1.toString() + ', descriptor=' + this.w6h_1.toString() + ')';
  }
  hashCode() {
    var result = this.u6h_1.hashCode();
    result = imul(result, 31) + this.v6h_1.hashCode() | 0;
    result = imul(result, 31) + this.w6h_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof IndexedSkill))
      return false;
    var tmp0_other_with_cast = other instanceof IndexedSkill ? other : THROW_CCE();
    if (!this.u6h_1.equals(tmp0_other_with_cast.u6h_1))
      return false;
    if (!this.v6h_1.equals(tmp0_other_with_cast.v6h_1))
      return false;
    if (!this.w6h_1.equals(tmp0_other_with_cast.w6h_1))
      return false;
    return true;
  }
}
class ParsedSkillDocument {
  constructor(descriptor, body) {
    this.f6i_1 = descriptor;
    this.g6i_1 = body;
  }
  toString() {
    return 'ParsedSkillDocument(descriptor=' + this.f6i_1.toString() + ', body=' + this.g6i_1 + ')';
  }
  hashCode() {
    var result = this.f6i_1.hashCode();
    result = imul(result, 31) + getStringHashCode(this.g6i_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ParsedSkillDocument))
      return false;
    var tmp0_other_with_cast = other instanceof ParsedSkillDocument ? other : THROW_CCE();
    if (!this.f6i_1.equals(tmp0_other_with_cast.f6i_1))
      return false;
    if (!(this.g6i_1 === tmp0_other_with_cast.g6i_1))
      return false;
    return true;
  }
}
class DirectorySkillResourceProvider {
  constructor(skillId, skillRoot, fileSystem) {
    this.n6i_1 = skillId;
    this.o6i_1 = skillRoot;
    this.p6i_1 = fileSystem;
  }
  w6i(request, $completion) {
    var path = request.q6i_1;
    var tmp;
    try {
      tmp = Companion_getInstance_1().a44(path);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var failure = $p;
        throw resourceError(this, "invalid resource path '" + path + "'", failure);
      } else {
        throw $p;
      }
    }
    var relative = tmp;
    var tmp_1;
    var tmp_2;
    if (isBlank(path) || relative.u40()) {
      tmp_2 = true;
    } else {
      var tmp_3 = relative.t40();
      tmp_2 = !((tmp_3 == null ? null : new Char(tmp_3)) == null);
    }
    if (tmp_2) {
      tmp_1 = true;
    } else {
      var tmp0 = relative.c44();
      var tmp$ret$0;
      $l$block_0: {
        // Inline function 'kotlin.collections.any' call
        var tmp_4;
        if (isInterface(tmp0, Collection)) {
          tmp_4 = tmp0.h1();
        } else {
          tmp_4 = false;
        }
        if (tmp_4) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
        var _iterator__ex2g4s = tmp0.y();
        while (_iterator__ex2g4s.z()) {
          var element = _iterator__ex2g4s.a1();
          if (element === '..') {
            tmp$ret$0 = true;
            break $l$block_0;
          }
        }
        tmp$ret$0 = false;
      }
      tmp_1 = tmp$ret$0;
    }
    if (tmp_1) {
      throw resourceError$default(this, "resource path must be relative and must not contain '..': '" + path + "'");
    }
    if (relative.e44() === 'SKILL.md') {
      throw resourceError$default(this, 'SKILL.md is instructions, not a Skill resource');
    }
    try {
      var canonicalRoot = this.p6i_1.h6i(this.o6i_1);
      var canonicalResource = this.p6i_1.h6i(this.o6i_1.h44(relative));
      if (!isInside(canonicalResource, canonicalRoot)) {
        throw resourceError$default(this, "resource path escapes the Skill directory: '" + path + "'");
      }
      var metadata_0 = metadata(this.p6i_1, canonicalResource);
      var size = metadata_0.z6h_1;
      if (!metadata_0.y6h_1 || size == null) {
        throw resourceError$default(this, "resource is not a regular file: '" + path + "'");
      }
      if (size.s1(new Long(1000000, 0)) > 0) {
        throw resourceError$default(this, "resource '" + path + "' exceeds 1000000 bytes");
      }
      var text = replace_0(replace(this.p6i_1.b6i(canonicalResource), '\r\n', '\n'), _Char___init__impl__6a9atx(13), _Char___init__impl__6a9atx(10));
      return pageResource(this, text, request);
    } catch ($p) {
      if ($p instanceof SkillException) {
        var skill = $p;
        throw skill;
      } else {
        if ($p instanceof Error) {
          var failure_0 = $p;
          var tmp0_elvis_lhs = failure_0.message;
          throw resourceError(this, "failed to read resource '" + path + "': " + (tmp0_elvis_lhs == null ? 'unknown error' : tmp0_elvis_lhs), failure_0);
        } else {
          throw $p;
        }
      }
    }
  }
}
class SkillDescriptor {
  constructor(id, description, metadata) {
    metadata = metadata === VOID ? emptyMap() : metadata;
    this.c6i_1 = id;
    this.d6i_1 = description;
    this.e6i_1 = metadata;
    // Inline function 'kotlin.text.isNotBlank' call
    var this_0 = this.d6i_1;
    // Inline function 'kotlin.require' call
    if (!!isBlank(this_0)) {
      var message = "skill '" + _SkillId___get_value__impl__n6yl35(this.c6i_1) + "' description must not be blank";
      throw IllegalArgumentException.t(toString(message));
    }
  }
  toString() {
    return 'SkillDescriptor(id=' + SkillId__toString_impl_kvoh91(this.c6i_1) + ', description=' + this.d6i_1 + ', metadata=' + toString(this.e6i_1) + ')';
  }
  hashCode() {
    var result = SkillId__hashCode_impl_vhfju(this.c6i_1);
    result = imul(result, 31) + getStringHashCode(this.d6i_1) | 0;
    result = imul(result, 31) + hashCode(this.e6i_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SkillDescriptor))
      return false;
    var tmp0_other_with_cast = other instanceof SkillDescriptor ? other : THROW_CCE();
    if (!(this.c6i_1 === tmp0_other_with_cast.c6i_1))
      return false;
    if (!(this.d6i_1 === tmp0_other_with_cast.d6i_1))
      return false;
    if (!equals(this.e6i_1, tmp0_other_with_cast.e6i_1))
      return false;
    return true;
  }
}
class SkillDefinition {
  constructor(descriptor, instructions, resources, tools) {
    resources = resources === VOID ? null : resources;
    tools = tools === VOID ? emptyList() : tools;
    this.x6i_1 = descriptor;
    this.y6i_1 = instructions;
    this.z6i_1 = resources;
    this.a6j_1 = tools;
  }
  toString() {
    return 'SkillDefinition(descriptor=' + this.x6i_1.toString() + ', instructions=' + this.y6i_1 + ', resources=' + toString_0(this.z6i_1) + ', tools=' + toString(this.a6j_1) + ')';
  }
  hashCode() {
    var result = this.x6i_1.hashCode();
    result = imul(result, 31) + getStringHashCode(this.y6i_1) | 0;
    result = imul(result, 31) + (this.z6i_1 == null ? 0 : hashCode(this.z6i_1)) | 0;
    result = imul(result, 31) + hashCode(this.a6j_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SkillDefinition))
      return false;
    var tmp0_other_with_cast = other instanceof SkillDefinition ? other : THROW_CCE();
    if (!this.x6i_1.equals(tmp0_other_with_cast.x6i_1))
      return false;
    if (!(this.y6i_1 === tmp0_other_with_cast.y6i_1))
      return false;
    if (!equals(this.z6i_1, tmp0_other_with_cast.z6i_1))
      return false;
    if (!equals(this.a6j_1, tmp0_other_with_cast.a6j_1))
      return false;
    return true;
  }
}
class SkillId {
  constructor(value) {
    this.b6j_1 = value;
  }
  toString() {
    return SkillId__toString_impl_kvoh91(this.b6j_1);
  }
  hashCode() {
    return SkillId__hashCode_impl_vhfju(this.b6j_1);
  }
  equals(other) {
    return SkillId__equals_impl_845tem(this.b6j_1, other);
  }
}
class SkillResource {
  constructor(path, content, firstLine, lastLine, totalLines, nextCursor) {
    nextCursor = nextCursor === VOID ? null : nextCursor;
    this.c6j_1 = path;
    this.d6j_1 = content;
    this.e6j_1 = firstLine;
    this.f6j_1 = lastLine;
    this.g6j_1 = totalLines;
    this.h6j_1 = nextCursor;
  }
  toString() {
    return 'SkillResource(path=' + this.c6j_1 + ', content=' + this.d6j_1 + ', firstLine=' + this.e6j_1 + ', lastLine=' + this.f6j_1 + ', totalLines=' + this.g6j_1 + ', nextCursor=' + toString_0(this.h6j_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.c6j_1);
    result = imul(result, 31) + getStringHashCode(this.d6j_1) | 0;
    result = imul(result, 31) + this.e6j_1 | 0;
    result = imul(result, 31) + this.f6j_1 | 0;
    result = imul(result, 31) + this.g6j_1 | 0;
    result = imul(result, 31) + (this.h6j_1 == null ? 0 : this.h6j_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SkillResource))
      return false;
    var tmp0_other_with_cast = other instanceof SkillResource ? other : THROW_CCE();
    if (!(this.c6j_1 === tmp0_other_with_cast.c6j_1))
      return false;
    if (!(this.d6j_1 === tmp0_other_with_cast.d6j_1))
      return false;
    if (!(this.e6j_1 === tmp0_other_with_cast.e6j_1))
      return false;
    if (!(this.f6j_1 === tmp0_other_with_cast.f6j_1))
      return false;
    if (!(this.g6j_1 === tmp0_other_with_cast.g6j_1))
      return false;
    if (!equals(this.h6j_1, tmp0_other_with_cast.h6j_1))
      return false;
    return true;
  }
}
class SkillResourceRequest {
  constructor(path, cursor, maxLines, maxChars) {
    cursor = cursor === VOID ? new SkillResourceCursor(1, 1) : cursor;
    maxLines = maxLines === VOID ? 200 : maxLines;
    maxChars = maxChars === VOID ? 30000 : maxChars;
    this.q6i_1 = path;
    this.r6i_1 = cursor;
    this.s6i_1 = maxLines;
    this.t6i_1 = maxChars;
    // Inline function 'kotlin.text.isNotBlank' call
    var this_0 = this.q6i_1;
    // Inline function 'kotlin.require' call
    if (!!isBlank(this_0)) {
      var message = 'resource path must not be blank';
      throw IllegalArgumentException.t(toString(message));
    }
    var containsArg = this.s6i_1;
    // Inline function 'kotlin.require' call
    if (!(1 <= containsArg ? containsArg <= 400 : false)) {
      var message_0 = 'resource maxLines must be between 1 and 400';
      throw IllegalArgumentException.t(toString(message_0));
    }
    // Inline function 'kotlin.require' call
    if (!(this.t6i_1 >= 1)) {
      var message_1 = 'resource maxChars must be 1 or greater';
      throw IllegalArgumentException.t(toString(message_1));
    }
  }
  toString() {
    return 'SkillResourceRequest(path=' + this.q6i_1 + ', cursor=' + this.r6i_1.toString() + ', maxLines=' + this.s6i_1 + ', maxChars=' + this.t6i_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.q6i_1);
    result = imul(result, 31) + this.r6i_1.hashCode() | 0;
    result = imul(result, 31) + this.s6i_1 | 0;
    result = imul(result, 31) + this.t6i_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SkillResourceRequest))
      return false;
    var tmp0_other_with_cast = other instanceof SkillResourceRequest ? other : THROW_CCE();
    if (!(this.q6i_1 === tmp0_other_with_cast.q6i_1))
      return false;
    if (!this.r6i_1.equals(tmp0_other_with_cast.r6i_1))
      return false;
    if (!(this.s6i_1 === tmp0_other_with_cast.s6i_1))
      return false;
    if (!(this.t6i_1 === tmp0_other_with_cast.t6i_1))
      return false;
    return true;
  }
}
class SkillResourceCursor {
  constructor(line, column) {
    this.u6i_1 = line;
    this.v6i_1 = column;
    // Inline function 'kotlin.require' call
    if (!(this.u6i_1 >= 1)) {
      var message = 'resource cursor line must be 1 or greater';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.v6i_1 >= 1)) {
      var message_0 = 'resource cursor column must be 1 or greater';
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
  toString() {
    return 'SkillResourceCursor(line=' + this.u6i_1 + ', column=' + this.v6i_1 + ')';
  }
  hashCode() {
    var result = this.u6i_1;
    result = imul(result, 31) + this.v6i_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SkillResourceCursor))
      return false;
    var tmp0_other_with_cast = other instanceof SkillResourceCursor ? other : THROW_CCE();
    if (!(this.u6i_1 === tmp0_other_with_cast.u6i_1))
      return false;
    if (!(this.v6i_1 === tmp0_other_with_cast.v6i_1))
      return false;
    return true;
  }
}
class SkillStage extends Enum {}
class SkillException extends AgentFrameworkException {
  static t6h(stage, skillId, message, cause) {
    skillId = skillId === VOID ? null : skillId;
    cause = cause === VOID ? null : cause;
    var $this = this.b5t(new SkillError(skillId, stage, message, cause), cause);
    captureStack($this, $this.s6h_1);
    $this.q6h_1 = stage;
    $this.r6h_1 = skillId;
    return $this;
  }
}
class SkillFileMetadata {
  constructor(isDirectory, isRegularFile, size, isSymbolicLink) {
    this.x6h_1 = isDirectory;
    this.y6h_1 = isRegularFile;
    this.z6h_1 = size;
    this.a6i_1 = isSymbolicLink;
  }
  toString() {
    return 'SkillFileMetadata(isDirectory=' + this.x6h_1 + ', isRegularFile=' + this.y6h_1 + ', size=' + toString_0(this.z6h_1) + ', isSymbolicLink=' + this.a6i_1 + ')';
  }
  hashCode() {
    var result = getBooleanHashCode(this.x6h_1);
    result = imul(result, 31) + getBooleanHashCode(this.y6h_1) | 0;
    result = imul(result, 31) + (this.z6h_1 == null ? 0 : this.z6h_1.hashCode()) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.a6i_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SkillFileMetadata))
      return false;
    var tmp0_other_with_cast = other instanceof SkillFileMetadata ? other : THROW_CCE();
    if (!(this.x6h_1 === tmp0_other_with_cast.x6h_1))
      return false;
    if (!(this.y6h_1 === tmp0_other_with_cast.y6h_1))
      return false;
    if (!equals(this.z6h_1, tmp0_other_with_cast.z6h_1))
      return false;
    if (!(this.a6i_1 === tmp0_other_with_cast.a6i_1))
      return false;
    return true;
  }
}
class SkillsScope {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.e5q_1 = ArrayList.k();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.f5q_1 = ArrayList.k();
  }
  i6j(path) {
    // Inline function 'kotlin.text.isNotBlank' call
    // Inline function 'kotlin.require' call
    if (!!isBlank(path)) {
      var message = 'skill source path must not be blank';
      throw IllegalArgumentException.t(toString(message));
    }
    var tmp2 = this.e5q_1;
    // Inline function 'kotlin.collections.plusAssign' call
    var element = MarkdownDirectorySkillLoader.l6i(path);
    tmp2.l(element);
  }
  j6j(loader) {
    // Inline function 'kotlin.collections.plusAssign' call
    this.e5q_1.l(loader);
  }
  k6j(id) {
    var skillId = _SkillId___init__impl__ou80gj(id);
    // Inline function 'kotlin.require' call
    if (!!this.f5q_1.v2(new SkillId(skillId))) {
      var message = 'duplicate skill selection: ' + id;
      throw IllegalArgumentException.t(toString(message));
    }
    var tmp1 = this.f5q_1;
    // Inline function 'kotlin.collections.plusAssign' call
    var element = new SkillId(skillId);
    tmp1.l(element);
  }
  v5p() {
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.require' call
    if (!!this.e5q_1.h1()) {
      var message = 'skills { } requires at least one source(...)';
      throw IllegalArgumentException.t(toString(message));
    }
    return new SkillPlan(toList(this.e5q_1), toList(this.f5q_1));
  }
}
class SkillPlan$prepare$slambda$slambda {
  constructor(this$0, $index, $loader) {
    this.l6j_1 = this$0;
    this.m6j_1 = $index;
    this.n6j_1 = $loader;
  }
  r1f($this$async, $completion) {
    return discover(this.l6j_1, this.m6j_1, this.n6j_1, $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class sam$kotlin_Comparator$0 {
  constructor(function_0) {
    this.r6j_1 = function_0;
  }
  vi(a, b) {
    return this.r6j_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.r6j_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class SkillPlan$prepare$slambda {
  constructor(this$0) {
    this.s6j_1 = this$0;
  }
  r1f($this$coroutineScope, $completion) {
    // Inline function 'kotlin.collections.mapIndexed' call
    var this_0 = this.s6j_1.o5s_1;
    // Inline function 'kotlin.collections.mapIndexedTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var index = 0;
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var index_0 = checkIndexOverflow(_unary__edvuaz);
      var tmp$ret$0 = async($this$coroutineScope, VOID, VOID, SkillPlan$prepare$slambda$slambda_0(this.s6j_1, index_0, item));
      destination.l(tmp$ret$0);
    }
    return awaitAll(destination, $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class SkillPlan {
  constructor(loaders, selected) {
    this.o5s_1 = loaders;
    this.p5s_1 = selected;
  }
  o5o($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_prepare__2w4w0d_0.bind(VOID, this), $completion);
  }
}
class PreparedSkills {
  constructor(definitions) {
    this.r5s_1 = definitions;
    var tmp = this;
    // Inline function 'kotlin.collections.mapNotNull' call
    var tmp0 = this.r5s_1;
    // Inline function 'kotlin.collections.mapNotNullTo' call
    var destination = ArrayList.k();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp0_safe_receiver = element.z6i_1;
      var tmp_0;
      if (tmp0_safe_receiver == null) {
        tmp_0 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_0 = to(new SkillId(element.x6i_1.c6i_1), tmp0_safe_receiver);
      }
      var tmp0_safe_receiver_0 = tmp_0;
      if (tmp0_safe_receiver_0 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        destination.l(tmp0_safe_receiver_0);
      }
    }
    tmp.s5s_1 = toMap(destination);
  }
  v5s() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.r5s_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = item.x6i_1;
      destination.l(tmp$ret$0);
    }
    return destination;
  }
  c5t() {
    // Inline function 'kotlin.collections.flatMap' call
    var tmp0 = this.r5s_1;
    // Inline function 'kotlin.collections.flatMapTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var list = element.a6j_1;
      addAll(destination, list);
    }
    return destination;
  }
  t5s() {
    // Inline function 'kotlin.collections.mapNotNull' call
    var tmp0 = this.r5s_1;
    // Inline function 'kotlin.collections.mapNotNullTo' call
    var destination = ArrayList.k();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.takeIf' call
      var this_0 = element.y6i_1;
      var tmp;
      // Inline function 'kotlin.text.isNotBlank' call
      if (!isBlank(this_0)) {
        tmp = this_0;
      } else {
        tmp = null;
      }
      var tmp0_safe_receiver = tmp;
      var tmp_0;
      if (tmp0_safe_receiver == null) {
        tmp_0 = null;
      } else {
        // Inline function 'kotlin.let' call
        // Inline function 'kotlin.text.buildString' call
        // Inline function 'kotlin.apply' call
        var this_1 = StringBuilder.v();
        this_1.tb('## Skill: ');
        // Inline function 'kotlin.text.appendLine' call
        var value = _SkillId___get_value__impl__n6yl35(element.x6i_1.c6i_1);
        // Inline function 'kotlin.text.appendLine' call
        this_1.tb(value).ub(_Char___init__impl__6a9atx(10));
        this_1.tb('Description: ');
        // Inline function 'kotlin.text.appendLine' call
        var value_0 = element.x6i_1.d6i_1;
        // Inline function 'kotlin.text.appendLine' call
        this_1.tb(value_0).ub(_Char___init__impl__6a9atx(10));
        // Inline function 'kotlin.text.appendLine' call
        this_1.ub(_Char___init__impl__6a9atx(10));
        // Inline function 'kotlin.text.trim' call
        var tmp$ret$8 = toString(trim(isCharSequence(tmp0_safe_receiver) ? tmp0_safe_receiver : THROW_CCE()));
        this_1.tb(tmp$ret$8);
        tmp_0 = this_1.toString();
      }
      var tmp0_safe_receiver_0 = tmp_0;
      if (tmp0_safe_receiver_0 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        destination.l(tmp0_safe_receiver_0);
      }
    }
    return destination;
  }
  toString() {
    return 'PreparedSkills(definitions=' + toString(this.r5s_1) + ')';
  }
  hashCode() {
    return hashCode(this.r5s_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof PreparedSkills))
      return false;
    var tmp0_other_with_cast = other instanceof PreparedSkills ? other : THROW_CCE();
    if (!equals(this.r5s_1, tmp0_other_with_cast.r5s_1))
      return false;
    return true;
  }
}
class LocatedSkill {
  constructor(sourceIndex, loader, descriptor) {
    this.o6j_1 = sourceIndex;
    this.p6j_1 = loader;
    this.q6j_1 = descriptor;
  }
  toString() {
    return 'LocatedSkill(sourceIndex=' + this.o6j_1 + ', loader=' + toString(this.p6j_1) + ', descriptor=' + this.q6j_1.toString() + ')';
  }
  hashCode() {
    var result = this.o6j_1;
    result = imul(result, 31) + hashCode(this.p6j_1) | 0;
    result = imul(result, 31) + this.q6j_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof LocatedSkill))
      return false;
    var tmp0_other_with_cast = other instanceof LocatedSkill ? other : THROW_CCE();
    if (!(this.o6j_1 === tmp0_other_with_cast.o6j_1))
      return false;
    if (!equals(this.p6j_1, tmp0_other_with_cast.p6j_1))
      return false;
    if (!this.q6j_1.equals(tmp0_other_with_cast.q6j_1))
      return false;
    return true;
  }
}
class SkillResourceTool {
  constructor(providers) {
    this.y6j_1 = providers;
    this.z6j_1 = 'read_skill_resource';
    var tmp = this;
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb('Read a UTF-8 text resource owned by an enabled Skill. ');
    this_0.tb('Only relative paths inside the Skill directory are allowed. ');
    this_0.tb('line and column form a 1-based cursor; limit is at most 400. ');
    this_0.tb('Enabled Skills with resources: ');
    var tmp_0 = this.y6j_1.i3();
    this_0.tb(joinToString(tmp_0, ', ', VOID, VOID, VOID, VOID, SkillResourceTool$description$lambda));
    tmp.a6k_1 = this_0.toString();
    this.b6k_1 = Companion_instance_43.c3o();
  }
  e44() {
    return this.z6j_1;
  }
  r61() {
    return this.a6k_1;
  }
  s61() {
    return this.b6k_1;
  }
  c6k(input, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_execute__d6syw1.bind(VOID, this, input), $completion);
  }
  x61(input, $completion) {
    return this.c6k(input instanceof SkillResourceInput ? input : THROW_CCE(), $completion);
  }
}
class Companion_41 {
  c3o() {
    return $serializer_getInstance_29();
  }
}
class $serializer_30 {
  constructor() {
    $serializer_instance_29 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.framework.skill.SkillResourceInput', this, 5);
    tmp0_serialDesc.f25('skill', false);
    tmp0_serialDesc.f25('path', false);
    tmp0_serialDesc.f25('line', true);
    tmp0_serialDesc.f25('column', true);
    tmp0_serialDesc.f25('limit', true);
    this.d6k_1 = tmp0_serialDesc;
  }
  e6k(encoder, value) {
    var tmp0_desc = this.d6k_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.t6j_1);
    tmp1_output.g1z(tmp0_desc, 1, value.u6j_1);
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.v6j_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, IntSerializer_getInstance(), value.v6j_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.w6j_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, IntSerializer_getInstance(), value.w6j_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.x6j_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 4, IntSerializer_getInstance(), value.x6j_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.e6k(encoder, value instanceof SkillResourceInput ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.d6k_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.q1x(tmp0_desc);
    if (tmp9_input.g1y()) {
      tmp4_local0 = tmp9_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, IntSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, IntSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, IntSerializer_getInstance(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, IntSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, IntSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, IntSerializer_getInstance(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp9_input.r1x(tmp0_desc);
    return SkillResourceInput.f6k(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  h1t() {
    return this.d6k_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance())];
  }
}
class SkillResourceInput {
  toString() {
    return 'SkillResourceInput(skill=' + this.t6j_1 + ', path=' + this.u6j_1 + ', line=' + this.v6j_1 + ', column=' + this.w6j_1 + ', limit=' + this.x6j_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.t6j_1);
    result = imul(result, 31) + getStringHashCode(this.u6j_1) | 0;
    result = imul(result, 31) + (this.v6j_1 == null ? 0 : this.v6j_1) | 0;
    result = imul(result, 31) + (this.w6j_1 == null ? 0 : this.w6j_1) | 0;
    result = imul(result, 31) + (this.x6j_1 == null ? 0 : this.x6j_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SkillResourceInput))
      return false;
    var tmp0_other_with_cast = other instanceof SkillResourceInput ? other : THROW_CCE();
    if (!(this.t6j_1 === tmp0_other_with_cast.t6j_1))
      return false;
    if (!(this.u6j_1 === tmp0_other_with_cast.u6j_1))
      return false;
    if (!(this.v6j_1 == tmp0_other_with_cast.v6j_1))
      return false;
    if (!(this.w6j_1 == tmp0_other_with_cast.w6j_1))
      return false;
    if (!(this.x6j_1 == tmp0_other_with_cast.x6j_1))
      return false;
    return true;
  }
  static f6k(seen0, skill, path, line, column, limit, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_29().d6k_1);
    }
    var $this = createThis(this);
    $this.t6j_1 = skill;
    $this.u6j_1 = path;
    if (0 === (seen0 & 4))
      $this.v6j_1 = null;
    else
      $this.v6j_1 = line;
    if (0 === (seen0 & 8))
      $this.w6j_1 = null;
    else
      $this.w6j_1 = column;
    if (0 === (seen0 & 16))
      $this.x6j_1 = null;
    else
      $this.x6j_1 = limit;
    return $this;
  }
}
class ToolInvocationContext {
  constructor(callId, toolName, execution, reporter) {
    this.g6k_1 = callId;
    this.h6k_1 = toolName;
    this.i6k_1 = execution;
    this.j6k_1 = reporter;
  }
  k6k(progress, $completion) {
    return this.j6k_1(progress, $completion);
  }
}
class ToolProgress_0 {}
class Output {
  constructor(text, stream) {
    stream = stream === VOID ? ToolOutputStream_Stdout_getInstance() : stream;
    this.l6k_1 = text;
    this.m6k_1 = stream;
  }
  toString() {
    return 'Output(text=' + this.l6k_1 + ', stream=' + this.m6k_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.l6k_1);
    result = imul(result, 31) + this.m6k_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Output))
      return false;
    var tmp0_other_with_cast = other instanceof Output ? other : THROW_CCE();
    if (!(this.l6k_1 === tmp0_other_with_cast.l6k_1))
      return false;
    if (!this.m6k_1.equals(tmp0_other_with_cast.m6k_1))
      return false;
    return true;
  }
}
class Status {
  constructor(message) {
    this.n6k_1 = message;
  }
  toString() {
    return 'Status(message=' + this.n6k_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.n6k_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Status))
      return false;
    var tmp0_other_with_cast = other instanceof Status ? other : THROW_CCE();
    if (!(this.n6k_1 === tmp0_other_with_cast.n6k_1))
      return false;
    return true;
  }
}
class Custom_0 {
  constructor(kind, payload) {
    this.o6k_1 = kind;
    this.p6k_1 = payload;
    // Inline function 'kotlin.text.isNotBlank' call
    var this_0 = this.o6k_1;
    // Inline function 'kotlin.require' call
    if (!!isBlank(this_0)) {
      var message = 'custom tool progress kind must not be blank';
      throw IllegalArgumentException.t(toString(message));
    }
  }
  toString() {
    return 'Custom(kind=' + this.o6k_1 + ', payload=' + toString(this.p6k_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.o6k_1);
    result = imul(result, 31) + hashCode(this.p6k_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Custom_0))
      return false;
    var tmp0_other_with_cast = other instanceof Custom_0 ? other : THROW_CCE();
    if (!(this.o6k_1 === tmp0_other_with_cast.o6k_1))
      return false;
    if (!equals(this.p6k_1, tmp0_other_with_cast.p6k_1))
      return false;
    return true;
  }
}
class ToolOutputStream extends Enum {}
class ContextualTool {}
class Success {
  constructor(output, returnDirectly) {
    returnDirectly = returnDirectly === VOID ? false : returnDirectly;
    this.x5r_1 = output;
    this.y5r_1 = returnDirectly;
  }
  toString() {
    return 'Success(output=' + this.x5r_1 + ', returnDirectly=' + this.y5r_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.x5r_1);
    result = imul(result, 31) + getBooleanHashCode(this.y5r_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Success))
      return false;
    var tmp0_other_with_cast = other instanceof Success ? other : THROW_CCE();
    if (!(this.x5r_1 === tmp0_other_with_cast.x5r_1))
      return false;
    if (!(this.y5r_1 === tmp0_other_with_cast.y5r_1))
      return false;
    return true;
  }
}
class Failure {
  constructor(error) {
    this.w5r_1 = error;
  }
  toString() {
    return 'Failure(error=' + toString(this.w5r_1) + ')';
  }
  hashCode() {
    return hashCode(this.w5r_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Failure))
      return false;
    var tmp0_other_with_cast = other instanceof Failure ? other : THROW_CCE();
    if (!equals(this.w5r_1, tmp0_other_with_cast.w5r_1))
      return false;
    return true;
  }
}
class ToolRegistry {
  constructor() {
    this.z5o_1 = LinkedHashMap.hc();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.a5p_1 = ArrayList.k();
    this.b5p_1 = Mutex();
    this.c5p_1 = false;
  }
  n60(tool) {
    // Inline function 'kotlin.check' call
    if (!!this.c5p_1) {
      var message = 'tool registry is already prepared';
      throw IllegalStateException.t4(toString(message));
    }
    var tmp1 = this.z5o_1;
    // Inline function 'kotlin.collections.contains' call
    // Inline function 'kotlin.collections.containsKey' call
    var key = tool.e44();
    // Inline function 'kotlin.require' call
    if (!!(isInterface(tmp1, KtMap) ? tmp1 : THROW_CCE()).f3(key)) {
      var message_0 = 'duplicate tool: ' + tool.e44();
      throw IllegalArgumentException.t(toString(message_0));
    }
    var tmp4 = this.z5o_1;
    // Inline function 'kotlin.collections.set' call
    var key_0 = tool.e44();
    tmp4.k3(key_0, tool);
  }
  p60(source) {
    // Inline function 'kotlin.check' call
    if (!!this.c5p_1) {
      var message = 'tool sources can only be added before preparation';
      throw IllegalStateException.t4(toString(message));
    }
    // Inline function 'kotlin.collections.plusAssign' call
    this.a5p_1.l(source);
  }
  q5s(additionalTools, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_prepare__2w4w0d_1.bind(VOID, this, additionalTools), $completion);
  }
  d5p() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.z5o_1.j3();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp = item.e44();
      var tmp_0 = item.r61();
      var tmp0_elvis_lhs = item.u61();
      var tmp$ret$0 = new ToolSchema(tmp, tmp_0, tmp0_elvis_lhs == null ? SerialDescriptorToJsonSchema_instance.t6k(item.s61().h1t()) : tmp0_elvis_lhs);
      destination.l(tmp$ret$0);
    }
    return destination;
  }
  b5w(call, execution, reportProgress, onSideEffect, $completion) {
    var tmp0_elvis_lhs = this.z5o_1.h3(call.n5v_1);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return new Failure(new ToolNotFound(call.n5v_1));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var tool = tmp;
    var context = new ToolInvocationContext(call.m5v_1, call.n5v_1, execution, reportProgress);
    return invoke(this, tool, call.o5v_1, onSideEffect, context, $completion);
  }
}
class ToolSchema {
  constructor(name, description, parameters) {
    this.u6k_1 = name;
    this.v6k_1 = description;
    this.w6k_1 = parameters;
  }
  toString() {
    return 'ToolSchema(name=' + this.u6k_1 + ', description=' + this.v6k_1 + ', parameters=' + this.w6k_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.u6k_1);
    result = imul(result, 31) + getStringHashCode(this.v6k_1) | 0;
    result = imul(result, 31) + this.w6k_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolSchema))
      return false;
    var tmp0_other_with_cast = other instanceof ToolSchema ? other : THROW_CCE();
    if (!(this.u6k_1 === tmp0_other_with_cast.u6k_1))
      return false;
    if (!(this.v6k_1 === tmp0_other_with_cast.v6k_1))
      return false;
    if (!this.w6k_1.equals(tmp0_other_with_cast.w6k_1))
      return false;
    return true;
  }
}
class Ctx {
  constructor() {
    this.x6k_1 = LinkedHashMap.hc();
    this.y6k_1 = HashSet.ga();
  }
  a6l(descriptor, inlineTopLevel) {
    if (equals(descriptor.u1v(), ENUM_getInstance()))
      return enumSchema(SerialDescriptorToJsonSchema_instance, descriptor);
    var kind = descriptor.u1v();
    var tmp;
    if (kind instanceof PrimitiveKind) {
      tmp = primitiveSchema(SerialDescriptorToJsonSchema_instance, kind);
    } else {
      if (equals(kind, LIST_getInstance())) {
        tmp = listSchema(this, descriptor);
      } else {
        if (equals(kind, MAP_getInstance())) {
          tmp = mapSchema(this, descriptor);
        } else {
          if (equals(kind, CLASS_getInstance()) || equals(kind, OBJECT_getInstance())) {
            var tmp_0;
            if (inlineTopLevel) {
              tmp_0 = objectSchema(this, descriptor);
            } else {
              tmp_0 = refForNamed(this, descriptor, SerialDescriptorToJsonSchema$Ctx$schemaFor$lambda(this));
            }
            tmp = tmp_0;
          } else {
            if (equals(kind, SEALED_getInstance()) || equals(kind, OPEN_getInstance())) {
              var tmp_1;
              if (inlineTopLevel) {
                tmp_1 = sealedSchema(this, descriptor);
              } else {
                tmp_1 = refForNamed(this, descriptor, SerialDescriptorToJsonSchema$Ctx$schemaFor$lambda_0(this));
              }
              tmp = tmp_1;
            } else {
              var message = 'unsupported descriptor kind ' + kind.toString() + " for '" + descriptor.k1u() + "'";
              throw IllegalStateException.t4(toString(message));
            }
          }
        }
      }
    }
    return tmp;
  }
  b6l(descriptor, inlineTopLevel, $super) {
    inlineTopLevel = inlineTopLevel === VOID ? false : inlineTopLevel;
    return $super === VOID ? this.a6l(descriptor, inlineTopLevel) : $super.a6l.call(this, descriptor, inlineTopLevel);
  }
  z6k(descriptor) {
    var base = this.b6l(descriptor);
    return descriptor.q1v() ? withNull(SerialDescriptorToJsonSchema_instance, base) : base;
  }
}
class SerialDescriptorToJsonSchema {
  constructor() {
    this.r6k_1 = '$defs';
    this.s6k_1 = '$ref';
  }
  t6k(descriptor) {
    var ctx = new Ctx();
    var tmp = ctx.a6l(descriptor, true);
    var tmp0_safe_receiver = param(this, descriptor.x1v());
    var root = withDescription(this, tmp, tmp0_safe_receiver == null ? null : get_resolvedDescription(tmp0_safe_receiver));
    if (ctx.x6k_1.h1())
      return root;
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = root.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var k = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var v = element.n1();
      builder.r3o(k, v);
    }
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder_0 = new JsonObjectBuilder();
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s_0 = ctx.x6k_1.l1().y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      // Inline function 'kotlin.collections.component1' call
      var k_0 = element_0.m1();
      // Inline function 'kotlin.collections.component2' call
      var v_0 = element_0.n1();
      builder_0.r3o(k_0, v_0);
    }
    var tmp$ret$11 = builder_0.i3n();
    builder.r3o('$defs', tmp$ret$11);
    return builder.i3n();
  }
}
class KtorTransport$call$slambda$slambda {
  constructor($emittedAny, $this_flow) {
    this.c6l_1 = $emittedAny;
    this.d6l_1 = $this_flow;
  }
  o6g(frame, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_18.bind(VOID, this, frame), $completion);
  }
  td(p1, $completion) {
    return this.o6g((!(p1 == null) ? isInterface(p1, WireFrame) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class KtorTransport$call$slambda {
  constructor($call, this$0) {
    this.n6l_1 = $call;
    this.o6l_1 = this$0;
  }
  k6m($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_19.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.k6m((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class KtorTransport$execute$slambda {
  constructor($httpError, $call, $onFrame) {
    this.d6m_1 = $httpError;
    this.e6m_1 = $call;
    this.f6m_1 = $onFrame;
  }
  o3b(response, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_20.bind(VOID, this, response), $completion);
  }
  td(p1, $completion) {
    return this.o3b(p1 instanceof HttpResponse ? p1 : THROW_CCE(), $completion);
  }
}
class KtorTransport {
  constructor(engineClient) {
    var tmp;
    if (engineClient === VOID) {
      var tmp_0 = provideEngine();
      tmp = HttpClient(tmp_0, KtorTransport$_init_$lambda_gsh77y);
    } else {
      tmp = engineClient;
    }
    engineClient = tmp;
    this.w6l_1 = engineClient;
    var tmp_1 = this;
    var tmp_2 = KotlinLogging_instance;
    tmp_1.x6l_1 = tmp_2.g5l(KtorTransport$logger$lambda);
    var tmp_3 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_3.y6l_1 = LinkedHashMap.hc();
    this.z6l_1 = Mutex();
  }
  r6g(call) {
    return flow(KtorTransport$call$slambda_0(call, this));
  }
  a6() {
    this.w6l_1.a6();
  }
}
class TransportException extends RuntimeException {
  static p6m(message, statusCode, cause) {
    statusCode = statusCode === VOID ? null : statusCode;
    cause = cause === VOID ? null : cause;
    var $this = this.be(message, cause);
    captureStack($this, $this.o6m_1);
    $this.n6m_1 = statusCode;
    return $this;
  }
}
class StreamLine {
  constructor(value) {
    this.r6m_1 = value;
  }
  toString() {
    return 'StreamLine(value=' + this.r6m_1 + ')';
  }
  hashCode() {
    return this.r6m_1 == null ? 0 : getStringHashCode(this.r6m_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof StreamLine))
      return false;
    var tmp0_other_with_cast = other instanceof StreamLine ? other : THROW_CCE();
    if (!(this.r6m_1 == tmp0_other_with_cast.r6m_1))
      return false;
    return true;
  }
}
class StreamIdleTimeoutException extends RuntimeException {
  static q6m(idleTimeoutMs) {
    var $this = this.ra('model response stream was idle for ' + idleTimeoutMs.toString() + 'ms');
    captureStack($this, $this.r5z_1);
    $this.q5z_1 = idleTimeoutMs;
    return $this;
  }
}
class readStreamLine$slambda {
  constructor($channel) {
    this.s6m_1 = $channel;
  }
  r1f($this$withTimeoutOrNull, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_21.bind(VOID, this, $this$withTimeoutOrNull), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class RateLimiter {
  constructor(limit) {
    this.p6l_1 = limit;
    this.q6l_1 = Mutex();
    this.r6l_1 = Monotonic_instance.fj();
    this.s6l_1 = this.p6l_1.t6m_1;
    this.t6l_1 = _Duration___get_inWholeMilliseconds__impl__msfiry(ValueTimeMark__elapsedNow_impl_eonqvs(this.r6l_1));
    this.u6l_1 = this.p6l_1.t6m_1 / this.p6l_1.u6m_1.m4();
  }
  v6l($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_acquire__4kqfvm.bind(VOID, this), $completion);
  }
}
class WireFrame {}
class Sse {
  constructor(event, data, id) {
    this.v6m_1 = event;
    this.w6m_1 = data;
    this.x6m_1 = id;
  }
  toString() {
    return 'Sse(event=' + this.v6m_1 + ', data=' + this.w6m_1 + ', id=' + this.x6m_1 + ')';
  }
  hashCode() {
    var result = this.v6m_1 == null ? 0 : getStringHashCode(this.v6m_1);
    result = imul(result, 31) + getStringHashCode(this.w6m_1) | 0;
    result = imul(result, 31) + (this.x6m_1 == null ? 0 : getStringHashCode(this.x6m_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Sse))
      return false;
    var tmp0_other_with_cast = other instanceof Sse ? other : THROW_CCE();
    if (!(this.v6m_1 == tmp0_other_with_cast.v6m_1))
      return false;
    if (!(this.w6m_1 === tmp0_other_with_cast.w6m_1))
      return false;
    if (!(this.x6m_1 == tmp0_other_with_cast.x6m_1))
      return false;
    return true;
  }
}
class Body {
  constructor(contentType, text) {
    this.y6m_1 = contentType;
    this.z6m_1 = text;
  }
  toString() {
    return 'Body(contentType=' + this.y6m_1 + ', text=' + this.z6m_1 + ')';
  }
  hashCode() {
    var result = this.y6m_1 == null ? 0 : getStringHashCode(this.y6m_1);
    result = imul(result, 31) + getStringHashCode(this.z6m_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Body))
      return false;
    var tmp0_other_with_cast = other instanceof Body ? other : THROW_CCE();
    if (!(this.y6m_1 == tmp0_other_with_cast.y6m_1))
      return false;
    if (!(this.z6m_1 === tmp0_other_with_cast.z6m_1))
      return false;
    return true;
  }
}
class Ndjson {
  constructor(line) {
    this.a6n_1 = line;
  }
  toString() {
    return 'Ndjson(line=' + this.a6n_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.a6n_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Ndjson))
      return false;
    var tmp0_other_with_cast = other instanceof Ndjson ? other : THROW_CCE();
    if (!(this.a6n_1 === tmp0_other_with_cast.a6n_1))
      return false;
    return true;
  }
}
class HttpError {
  constructor(status, contentType, body) {
    this.a6m_1 = status;
    this.b6m_1 = contentType;
    this.c6m_1 = body;
  }
  toString() {
    return 'HttpError(status=' + this.a6m_1 + ', contentType=' + this.b6m_1 + ', body=' + this.c6m_1 + ')';
  }
  hashCode() {
    var result = this.a6m_1;
    result = imul(result, 31) + (this.b6m_1 == null ? 0 : getStringHashCode(this.b6m_1)) | 0;
    result = imul(result, 31) + getStringHashCode(this.c6m_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof HttpError))
      return false;
    var tmp0_other_with_cast = other instanceof HttpError ? other : THROW_CCE();
    if (!(this.a6m_1 === tmp0_other_with_cast.a6m_1))
      return false;
    if (!(this.b6m_1 == tmp0_other_with_cast.b6m_1))
      return false;
    if (!(this.c6m_1 === tmp0_other_with_cast.c6m_1))
      return false;
    return true;
  }
}
class WireCall {
  constructor(method, url, headers, body, expect, idempotencyKey, timeouts, retry, rateLimit) {
    headers = headers === VOID ? emptyMap() : headers;
    body = body === VOID ? null : body;
    idempotencyKey = idempotencyKey === VOID ? null : idempotencyKey;
    timeouts = timeouts === VOID ? new Timeouts() : timeouts;
    retry = retry === VOID ? new RetryBudget() : retry;
    rateLimit = rateLimit === VOID ? null : rateLimit;
    this.e6l_1 = method;
    this.f6l_1 = url;
    this.g6l_1 = headers;
    this.h6l_1 = body;
    this.i6l_1 = expect;
    this.j6l_1 = idempotencyKey;
    this.k6l_1 = timeouts;
    this.l6l_1 = retry;
    this.m6l_1 = rateLimit;
  }
  toString() {
    return 'WireCall(method=' + this.e6l_1.toString() + ', url=' + this.f6l_1 + ', headers=' + toString(this.g6l_1) + ', body=' + this.h6l_1 + ', expect=' + this.i6l_1.toString() + ', idempotencyKey=' + this.j6l_1 + ', timeouts=' + this.k6l_1.toString() + ', retry=' + this.l6l_1.toString() + ', rateLimit=' + toString_0(this.m6l_1) + ')';
  }
  hashCode() {
    var result = this.e6l_1.hashCode();
    result = imul(result, 31) + getStringHashCode(this.f6l_1) | 0;
    result = imul(result, 31) + hashCode(this.g6l_1) | 0;
    result = imul(result, 31) + (this.h6l_1 == null ? 0 : getStringHashCode(this.h6l_1)) | 0;
    result = imul(result, 31) + this.i6l_1.hashCode() | 0;
    result = imul(result, 31) + (this.j6l_1 == null ? 0 : getStringHashCode(this.j6l_1)) | 0;
    result = imul(result, 31) + this.k6l_1.hashCode() | 0;
    result = imul(result, 31) + this.l6l_1.hashCode() | 0;
    result = imul(result, 31) + (this.m6l_1 == null ? 0 : this.m6l_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof WireCall))
      return false;
    var tmp0_other_with_cast = other instanceof WireCall ? other : THROW_CCE();
    if (!this.e6l_1.equals(tmp0_other_with_cast.e6l_1))
      return false;
    if (!(this.f6l_1 === tmp0_other_with_cast.f6l_1))
      return false;
    if (!equals(this.g6l_1, tmp0_other_with_cast.g6l_1))
      return false;
    if (!(this.h6l_1 == tmp0_other_with_cast.h6l_1))
      return false;
    if (!this.i6l_1.equals(tmp0_other_with_cast.i6l_1))
      return false;
    if (!(this.j6l_1 == tmp0_other_with_cast.j6l_1))
      return false;
    if (!this.k6l_1.equals(tmp0_other_with_cast.k6l_1))
      return false;
    if (!this.l6l_1.equals(tmp0_other_with_cast.l6l_1))
      return false;
    if (!equals(this.m6l_1, tmp0_other_with_cast.m6l_1))
      return false;
    return true;
  }
}
class HttpMethod extends Enum {}
class Framing extends Enum {}
class Timeouts {
  constructor(connectTimeoutMs, requestTimeoutMs, socketTimeoutMs, streamIdleTimeoutMs) {
    connectTimeoutMs = connectTimeoutMs === VOID ? new Long(5000, 0) : connectTimeoutMs;
    requestTimeoutMs = requestTimeoutMs === VOID ? new Long(600000, 0) : requestTimeoutMs;
    socketTimeoutMs = socketTimeoutMs === VOID ? new Long(600000, 0) : socketTimeoutMs;
    streamIdleTimeoutMs = streamIdleTimeoutMs === VOID ? new Long(60000, 0) : streamIdleTimeoutMs;
    this.g6m_1 = connectTimeoutMs;
    this.h6m_1 = requestTimeoutMs;
    this.i6m_1 = socketTimeoutMs;
    this.j6m_1 = streamIdleTimeoutMs;
  }
  toString() {
    return 'Timeouts(connectTimeoutMs=' + this.g6m_1.toString() + ', requestTimeoutMs=' + this.h6m_1.toString() + ', socketTimeoutMs=' + this.i6m_1.toString() + ', streamIdleTimeoutMs=' + this.j6m_1.toString() + ')';
  }
  hashCode() {
    var result = this.g6m_1.hashCode();
    result = imul(result, 31) + this.h6m_1.hashCode() | 0;
    result = imul(result, 31) + this.i6m_1.hashCode() | 0;
    result = imul(result, 31) + this.j6m_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Timeouts))
      return false;
    var tmp0_other_with_cast = other instanceof Timeouts ? other : THROW_CCE();
    if (!this.g6m_1.equals(tmp0_other_with_cast.g6m_1))
      return false;
    if (!this.h6m_1.equals(tmp0_other_with_cast.h6m_1))
      return false;
    if (!this.i6m_1.equals(tmp0_other_with_cast.i6m_1))
      return false;
    if (!this.j6m_1.equals(tmp0_other_with_cast.j6m_1))
      return false;
    return true;
  }
}
class JsonUtil {
  constructor() {
    JsonUtil_instance = this;
    var tmp = this;
    tmp.j6f_1 = Json(VOID, JsonUtil$json$lambda);
  }
  k6f(obj, serializer) {
    return this.j6f_1.y3l(serializer, obj);
  }
  l6f(jsonStr, deserializer) {
    var tmp;
    if (jsonStr == null) {
      tmp = this.j6f_1.z3l(deserializer, '{}');
    } else {
      tmp = this.j6f_1.z3l(deserializer, jsonStr);
    }
    return tmp;
  }
}
class AgentRuntime$stream$slambda$slambda {
  constructor($this_flow) {
    this.s6n_1 = $this_flow;
  }
  o6p(envelope, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_22.bind(VOID, this, envelope), $completion);
  }
  td(p1, $completion) {
    return this.o6p(p1 instanceof RunEventEnvelope ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$resume$slambda$slambda {
  constructor($this_flow) {
    this.p6p_1 = $this_flow;
  }
  o6p(envelope, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_24.bind(VOID, this, envelope), $completion);
  }
  td(p1, $completion) {
    return this.o6p(p1 instanceof RunEventEnvelope ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$spawnSupervised$slambda$slambda {
  constructor(this$0, $agent, $priority, $quota, $contextRefs, $thread, $latest) {
    this.d6w_1 = this$0;
    this.e6w_1 = $agent;
    this.f6w_1 = $priority;
    this.g6w_1 = $quota;
    this.h6w_1 = $contextRefs;
    this.i6w_1 = $thread;
    this.j6w_1 = $latest;
  }
  k6w(attemptInput, $completion) {
    var handle = this.d6w_1.l6w(this.e6w_1, attemptInput, this.f6w_1, this.g6w_1, this.h6w_1, this.i6w_1);
    this.j6w_1.t1e(handle);
    return handle.vw($completion);
  }
  td(p1, $completion) {
    return this.k6w((!(p1 == null) ? typeof p1 === 'string' : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$submit$slambda$slambda {
  constructor($node, $results, this$0) {
    this.r6w_1 = $node;
    this.s6w_1 = $results;
    this.t6w_1 = this$0;
  }
  r1f($this$launch, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_36.bind(VOID, this, $this$launch), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class Companion_42 {}
class sam$kotlinx_coroutines_flow_FlowCollector$0_4 {
  constructor(function_0) {
    this.j6z_1 = function_0;
  }
  t1c(value, $completion) {
    return this.j6z_1(value, $completion);
  }
  n4() {
    return this.j6z_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_5 {
  constructor(function_0) {
    this.k6z_1 = function_0;
  }
  t1c(value, $completion) {
    return this.k6z_1(value, $completion);
  }
  n4() {
    return this.k6z_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class AgentSpawner {}
class sam$org_koaks_runtime_resource_AgentSpawner$0 {
  constructor(function_0) {
    this.l6z_1 = function_0;
  }
  m6z(agent, input, priority, quota, contextRefs, failurePolicy, conversation) {
    return this.l6z_1(agent, input, priority, quota, contextRefs, failurePolicy, conversation);
  }
  n4() {
    return this.l6z_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, AgentSpawner) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_6 {
  constructor(function_0) {
    this.n6z_1 = function_0;
  }
  t1c(value, $completion) {
    return this.n6z_1(value, $completion);
  }
  n4() {
    return this.n6z_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class AgentRuntime$stream$slambda {
  constructor(this$0, $agent, $input, $priority, $quota, $contextRefs, $thread, $correlationId) {
    this.u6n_1 = this$0;
    this.v6n_1 = $agent;
    this.w6n_1 = $input;
    this.x6n_1 = $priority;
    this.y6n_1 = $quota;
    this.z6n_1 = $contextRefs;
    this.a6o_1 = $thread;
    this.b6o_1 = $correlationId;
  }
  m5o($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_23.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.m5o((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$resume$slambda {
  constructor(this$0, $agent, $thread, $priority, $quota, $contextRefs, $correlationId) {
    this.q6p_1 = this$0;
    this.r6p_1 = $agent;
    this.s6p_1 = $thread;
    this.t6p_1 = $priority;
    this.u6p_1 = $quota;
    this.v6p_1 = $contextRefs;
    this.w6p_1 = $correlationId;
  }
  m5o($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_25.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.m5o((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$spawnInternal$slambda {
  constructor(this$0, $contextRefs, $parent, $runId, $gate, $agent, $input, $acb, $control, $priority, $effectiveQuota, $sink, $effectiveThread, $turnId, $turnContext, $turnOwner, $turnReservation, $structuredSpec, $resume) {
    this.y6p_1 = this$0;
    this.z6p_1 = $contextRefs;
    this.a6q_1 = $parent;
    this.b6q_1 = $runId;
    this.c6q_1 = $gate;
    this.d6q_1 = $agent;
    this.e6q_1 = $input;
    this.f6q_1 = $acb;
    this.g6q_1 = $control;
    this.h6q_1 = $priority;
    this.i6q_1 = $effectiveQuota;
    this.j6q_1 = $sink;
    this.k6q_1 = $effectiveThread;
    this.l6q_1 = $turnId;
    this.m6q_1 = $turnContext;
    this.n6q_1 = $turnOwner;
    this.o6q_1 = $turnReservation;
    this.p6q_1 = $structuredSpec;
    this.q6q_1 = $resume;
  }
  r1f($this$async, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_26.bind(VOID, this, $this$async), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$runInstance$slambda {
  constructor($gate, $acb, this$0, $agent, $thread, $turnId, $input, $resume, $effectiveContext, $control, $quota, $sink, $turnContext, $structuredSpec, $terminalUsage) {
    this.o6r_1 = $gate;
    this.p6r_1 = $acb;
    this.q6r_1 = this$0;
    this.r6r_1 = $agent;
    this.s6r_1 = $thread;
    this.t6r_1 = $turnId;
    this.u6r_1 = $input;
    this.v6r_1 = $resume;
    this.w6r_1 = $effectiveContext;
    this.x6r_1 = $control;
    this.y6r_1 = $quota;
    this.z6r_1 = $sink;
    this.a6s_1 = $turnContext;
    this.b6s_1 = $structuredSpec;
    this.c6s_1 = $terminalUsage;
  }
  q6z(lease, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_27.bind(VOID, this, lease), $completion);
  }
  td(p1, $completion) {
    return this.q6z((!(p1 == null) ? isInterface(p1, SlotLease) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$runInstance$slambda_0 {
  constructor($turnCommitted, this$0, $threadMemory, $turnContext, $acb, $result, $agent, $thread, $turnId) {
    this.q6s_1 = $turnCommitted;
    this.r6s_1 = this$0;
    this.s6s_1 = $threadMemory;
    this.t6s_1 = $turnContext;
    this.u6s_1 = $acb;
    this.v6s_1 = $result;
    this.w6s_1 = $agent;
    this.x6s_1 = $thread;
    this.y6s_1 = $turnId;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_28.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$runInstance$slambda_1 {
  constructor($turnCommitted, this$0, $threadMemory, $turnContext, $result, $acb, $agent, $thread, $turnId) {
    this.a6t_1 = $turnCommitted;
    this.b6t_1 = this$0;
    this.c6t_1 = $threadMemory;
    this.d6t_1 = $turnContext;
    this.e6t_1 = $result;
    this.f6t_1 = $acb;
    this.g6t_1 = $agent;
    this.h6t_1 = $thread;
    this.i6t_1 = $turnId;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_29.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$runInstance$slambda_2 {
  constructor($turnCommitted, this$0, $threadMemory, $turnContext, $result, $acb, $agent, $thread, $turnId) {
    this.j6t_1 = $turnCommitted;
    this.k6t_1 = this$0;
    this.l6t_1 = $threadMemory;
    this.m6t_1 = $turnContext;
    this.n6t_1 = $result;
    this.o6t_1 = $acb;
    this.p6t_1 = $agent;
    this.q6t_1 = $thread;
    this.r6t_1 = $turnId;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_30.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$runInstance$slambda_3 {
  constructor($turnCommitted, this$0, $threadMemory, $turnContext) {
    this.s6t_1 = $turnCommitted;
    this.t6t_1 = this$0;
    this.u6t_1 = $threadMemory;
    this.v6t_1 = $turnContext;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_31.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$runInstance$slambda_4 {
  constructor($turnContext, $agent, $turnCommitted, this$0, $threadMemory, $acb) {
    this.w6t_1 = $turnContext;
    this.x6t_1 = $agent;
    this.y6t_1 = $turnCommitted;
    this.z6t_1 = this$0;
    this.a6u_1 = $threadMemory;
    this.b6u_1 = $acb;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_32.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$runInstance$slambda_5 {
  constructor($turnCommitted, this$0, $threadMemory, $turnContext, $acb) {
    this.i6u_1 = $turnCommitted;
    this.j6u_1 = this$0;
    this.k6u_1 = $threadMemory;
    this.l6u_1 = $turnContext;
    this.m6u_1 = $acb;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_33.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$runInstance$slambda_6 {
  constructor($threadLease, $turnCommitted, $turnContext, this$0, $acb, $agent, $turnId) {
    this.n6u_1 = $threadLease;
    this.o6u_1 = $turnCommitted;
    this.p6u_1 = $turnContext;
    this.q6u_1 = this$0;
    this.r6u_1 = $acb;
    this.s6u_1 = $agent;
    this.t6u_1 = $turnId;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_34.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$runWithQuota$slambda {
  constructor(this$0, $agent, $input, $contextPrefix, $acb, $control, $quota, $sink, $turnContext, $structuredSpec, $terminalUsage) {
    this.r6z_1 = this$0;
    this.s6z_1 = $agent;
    this.t6z_1 = $input;
    this.u6z_1 = $contextPrefix;
    this.v6z_1 = $acb;
    this.w6z_1 = $control;
    this.x6z_1 = $quota;
    this.y6z_1 = $sink;
    this.z6z_1 = $turnContext;
    this.a70_1 = $structuredSpec;
    this.b70_1 = $terminalUsage;
  }
  r1f($this$withTimeout, $completion) {
    return collectStream(this.r6z_1, this.s6z_1, this.t6z_1, this.u6z_1, this.v6z_1, this.w6z_1, this.x6z_1, this.y6z_1, this.z6z_1, this.a70_1, this.b70_1, $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$collectStream$slambda {
  constructor($control, $acb, this$0, $agent, $sink, $stepText, $toolCalls, $quota, $steps, $lastAssistant, $terminal, $usage, $terminalUsage, $lastFailure) {
    this.z6u_1 = $control;
    this.a6v_1 = $acb;
    this.b6v_1 = this$0;
    this.c6v_1 = $agent;
    this.d6v_1 = $sink;
    this.e6v_1 = $stepText;
    this.f6v_1 = $toolCalls;
    this.g6v_1 = $quota;
    this.h6v_1 = $steps;
    this.i6v_1 = $lastAssistant;
    this.j6v_1 = $terminal;
    this.k6v_1 = $usage;
    this.l6v_1 = $terminalUsage;
    this.m6v_1 = $lastFailure;
  }
  w5t(event, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_35.bind(VOID, this, event), $completion);
  }
  td(p1, $completion) {
    return this.w5t((!(p1 == null) ? isInterface(p1, AgentEvent) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$spawnSupervised$slambda {
  constructor(this$0, $agent, $input, $policy, $latest, $thread, $priority, $quota, $contextRefs) {
    this.c70_1 = this$0;
    this.d70_1 = $agent;
    this.e70_1 = $input;
    this.f70_1 = $policy;
    this.g70_1 = $latest;
    this.h70_1 = $thread;
    this.i70_1 = $priority;
    this.j70_1 = $quota;
    this.k70_1 = $contextRefs;
  }
  r1f($this$async, $completion) {
    var tmp = AgentRuntime$spawnSupervised$slambda$lambda(this.g70_1, this.c70_1, this.d70_1, this.h70_1);
    var tmp_0 = AgentRuntime$spawnSupervised$slambda$lambda_0(this.g70_1, this.c70_1, this.d70_1, this.h70_1);
    return this.c70_1.i6o_1.o70(this.d70_1.j5m_1, this.e70_1, this.f70_1, tmp, tmp_0, AgentRuntime$spawnSupervised$slambda$slambda_0(this.c70_1, this.d70_1, this.i70_1, this.j70_1, this.k70_1, this.h70_1, this.g70_1), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$submit$slambda {
  constructor($graph, this$0) {
    this.w6w_1 = $graph;
    this.x6w_1 = this$0;
  }
  r1f($this$coroutineScope, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_37.bind(VOID, this, $this$coroutineScope), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime$cancelAndJoin$slambda {
  constructor($handle) {
    this.y6w_1 = $handle;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_38.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class AgentRuntime {
  constructor(config) {
    this.c6o_1 = config.p70_1;
    this.d6o_1 = config.r70_1;
    var tmp = this;
    // Inline function 'kotlin.also' call
    var this_0 = config.t70_1;
    // Inline function 'kotlin.require' call
    if (!(this_0 > 0)) {
      var message = 'runEventBufferCapacity must be positive';
      throw IllegalArgumentException.t(toString(message));
    }
    tmp.e6o_1 = this_0;
    this.f6o_1 = SupervisorJob();
    this.g6o_1 = CoroutineScope_0(config.q70_1.kn(this.f6o_1).kn(new CoroutineName('agent-runtime')));
    this.h6o_1 = new Scheduler(config.p70_1);
    this.i6o_1 = new Supervisor();
    this.j6o_1 = new ThreadRegistry(config.s70_1);
    this.k6o_1 = MutableSharedFlow(VOID, 256);
    this.l6o_1 = new ResourceRegistry();
    this.m6o_1 = new IpcHub();
    this.n6o_1 = new ContextStore();
    this.o6o_1 = MutableStateFlow(new Long(0, 0));
    this.p6o_1 = MutableStateFlow(new Long(0, 0));
    this.q6o_1 = MutableStateFlow(emptyMap());
    this.r6o_1 = MutableStateFlow(emptyMap());
    this.s6o_1 = MutableStateFlow(emptyMap());
    this.t6o_1 = MutableStateFlow(emptyMap());
    this.u6o_1 = MutableStateFlow(emptyMap());
    this.v6o_1 = MutableStateFlow(false);
    this.f6o_1.uv(AgentRuntime$lambda(this));
  }
  u70() {
    return asSharedFlow(this.k6o_1);
  }
  v70() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.q6o_1.n1().j3();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = item.w6q();
      destination.l(tmp$ret$0);
    }
    return destination;
  }
  w70(id) {
    var tmp0_safe_receiver = this.q6o_1.n1().h3(new RunId(id));
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.w6q();
  }
  x70(id, $completion) {
    return this.j6o_1.y70(id);
  }
  z70() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.q6o_1.n1().j3();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = item.w6q();
      destination.l(tmp$ret$0);
    }
    var snaps = destination;
    var tmp = snaps.b1();
    var tmp_0 = metrics$count(snaps, LifecycleState_CREATED_getInstance());
    var tmp_1 = metrics$count(snaps, LifecycleState_THREAD_QUEUED_getInstance());
    var tmp_2 = metrics$count(snaps, LifecycleState_READY_getInstance());
    var tmp_3 = metrics$count(snaps, LifecycleState_RUNNING_getInstance());
    var tmp_4 = metrics$count(snaps, LifecycleState_WAITING_getInstance());
    var tmp_5 = metrics$count(snaps, LifecycleState_SUSPENDED_getInstance());
    var tmp_6 = metrics$count(snaps, LifecycleState_COMMITTING_getInstance());
    var tmp_7 = metrics$count(snaps, LifecycleState_FINISHED_getInstance());
    var tmp_8 = metrics$count(snaps, LifecycleState_FAILED_getInstance());
    var tmp_9 = metrics$count(snaps, LifecycleState_CANCELLED_getInstance());
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var _iterator__ex2g4s_0 = snaps.y();
    while (_iterator__ex2g4s_0.z()) {
      var element = _iterator__ex2g4s_0.a1();
      var tmp_10 = sum;
      sum = tmp_10 + element.i6r_1.p5y_1 | 0;
    }
    var tmp_11 = sum;
    // Inline function 'kotlin.collections.sumOf' call
    var sum_0 = 0;
    var _iterator__ex2g4s_1 = snaps.y();
    while (_iterator__ex2g4s_1.z()) {
      var element_0 = _iterator__ex2g4s_1.a1();
      var tmp_12 = sum_0;
      sum_0 = tmp_12 + element_0.j6r_1 | 0;
    }
    var tmp_13 = sum_0;
    // Inline function 'kotlin.collections.sumOf' call
    var sum_1 = 0;
    var _iterator__ex2g4s_2 = snaps.y();
    while (_iterator__ex2g4s_2.z()) {
      var element_1 = _iterator__ex2g4s_2.a1();
      var tmp_14 = sum_1;
      sum_1 = tmp_14 + element_1.k6r_1 | 0;
    }
    var tmp$ret$8 = sum_1;
    return new RuntimeMetrics(tmp, tmp_0, tmp_1, tmp_2, tmp_3, tmp_4, tmp_5, tmp_6, tmp_7, tmp_8, tmp_9, tmp_11, tmp_13, tmp$ret$8);
  }
  a71(olderThanMillis) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = this.q6o_1.n1();
    // Inline function 'kotlin.collections.filterTo' call
    var destination = LinkedHashMap.hc();
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = tmp0.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component2' call
      var acb = element.n1();
      var snap = acb.w6q();
      if (snap.c6r_1.n6p() && (olderThanMillis.s1(new Long(0, 0)) <= 0 || snap.l6r_1.s1(olderThanMillis) >= 0)) {
        destination.k3(element.m1(), element.n1());
      }
    }
    var victims = destination.i3();
    if (victims.h1())
      return 0;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = victims.y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      var it = element_0.z6w_1;
      this.m6o_1.f6y(it);
    }
    var tmp4 = this.q6o_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp4.n1();
        var nextValue = minus_0(prevValue, victims);
        if (tmp4.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
    var tmp6 = this.r6o_1;
    $l$block_0: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue_0 = tmp6.n1();
        var nextValue_0 = minus_0(prevValue_0, victims);
        if (tmp6.u1e(prevValue_0, nextValue_0)) {
          break $l$block_0;
        }
      }
    }
    var tmp8 = this.s6o_1;
    $l$block_1: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue_1 = tmp8.n1();
        var nextValue_1 = minus_0(prevValue_1, victims);
        if (tmp8.u1e(prevValue_1, nextValue_1)) {
          break $l$block_1;
        }
      }
    }
    return victims.b1();
  }
  b71(agentId) {
    while (true) {
      var current = this.t6o_1.n1();
      var tmp0_elvis_lhs = current.h3(new AgentId(agentId));
      var tmp;
      if (tmp0_elvis_lhs == null) {
        return Unit_instance;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var registered = tmp;
      // Inline function 'kotlin.check' call
      if (!(registered.k6x_1 === 0)) {
        var message = "agent '" + AgentId__toString_impl_gf4an3(agentId) + "' still has active or queued runs";
        throw IllegalStateException.t4(toString(message));
      }
      if (this.t6o_1.u1e(current, minus(current, new AgentId(agentId))))
        return Unit_instance;
    }
  }
  c71(agent) {
    while (true) {
      var current = this.t6o_1.n1();
      var registered = current.h3(new AgentId(agent.i5m_1));
      // Inline function 'kotlin.check' call
      if (!(registered == null || registered.k6x_1 === 0)) {
        var message = "agent '" + AgentId__toString_impl_gf4an3(agent.i5m_1) + "' still has active or queued runs";
        throw IllegalStateException.t4(toString(message));
      }
      var tmp1_elvis_lhs = registered == null ? null : registered.l6x_1;
      var next = plus_1(current, to(new AgentId(agent.i5m_1), new AgentRegistration(agent.z5m_1, agent.j5m_1, 0, (tmp1_elvis_lhs == null ? new Long(0, 0) : tmp1_elvis_lhs).u3(new Long(1, 0)))));
      if (this.t6o_1.u1e(current, next))
        return Unit_instance;
    }
  }
  d71(agent, input, priority, quota, contextRefs, thread, correlationId, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_run__cb7u2f.bind(VOID, this, agent, input, priority, quota, contextRefs, thread, correlationId), $completion);
  }
  u6w(agent, input, priority, quota, contextRefs, thread, correlationId, $completion, $super) {
    priority = priority === VOID ? 0 : priority;
    quota = quota === VOID ? null : quota;
    contextRefs = contextRefs === VOID ? emptyList() : contextRefs;
    thread = thread === VOID ? null : thread;
    correlationId = correlationId === VOID ? null : correlationId;
    var tmp;
    if ($super === VOID) {
      tmp = this.d71(agent, input, priority, quota, contextRefs, thread, correlationId, $completion);
    } else {
      var tmp_0 = $super.d71;
      var tmp_1 = thread;
      tmp = tmp_0.call(this, agent, input, priority, quota, contextRefs, tmp_1 == null ? null : new ThreadId(tmp_1), correlationId, $completion);
    }
    return tmp;
  }
  e71(agent, input, spec, priority, quota, contextRefs, thread, correlationId, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_runStructured__srdzi0_0.bind(VOID, this, agent, input, spec, priority, quota, contextRefs, thread, correlationId), $completion);
  }
  f71(agent, input, priority, quota, contextRefs, thread, correlationId) {
    return flow(AgentRuntime$stream$slambda_0(this, agent, input, priority, quota, contextRefs, thread, correlationId));
  }
  w6o(agent, input, priority, quota, contextRefs, thread, correlationId) {
    return spawnInternal$default(this, agent, input, priority, quota, null, contextRefs, thread, null, VOID, VOID, VOID, correlationId);
  }
  l6w(agent, input, priority, quota, contextRefs, thread, correlationId, $super) {
    priority = priority === VOID ? 0 : priority;
    quota = quota === VOID ? null : quota;
    contextRefs = contextRefs === VOID ? emptyList() : contextRefs;
    thread = thread === VOID ? null : thread;
    correlationId = correlationId === VOID ? null : correlationId;
    var tmp;
    if ($super === VOID) {
      tmp = this.w6o(agent, input, priority, quota, contextRefs, thread, correlationId);
    } else {
      var tmp_0 = $super.w6o;
      var tmp_1 = thread;
      tmp = tmp_0.call(this, agent, input, priority, quota, contextRefs, tmp_1 == null ? null : new ThreadId(tmp_1), correlationId);
    }
    return tmp;
  }
  t6x(agent, input, spec, priority, quota, contextRefs, thread, correlationId) {
    return spawnInternal$default(this, agent, input, priority, quota, null, contextRefs, thread, spec, VOID, VOID, VOID, correlationId);
  }
  x6p(agent, thread, priority, quota, contextRefs, correlationId) {
    return spawnInternal$default(this, agent, '', priority, quota, null, contextRefs, thread, null, VOID, VOID, VOID, correlationId, true);
  }
  g71(agent, thread, priority, quota, contextRefs, correlationId) {
    return flow(AgentRuntime$resume$slambda_0(this, agent, thread, priority, quota, contextRefs, correlationId));
  }
  h71(agent, thread, priority, quota, contextRefs, correlationId, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_resumeRun__lr1b9y.bind(VOID, this, agent, thread, priority, quota, contextRefs, correlationId), $completion);
  }
  i71(agent, input, policy, priority, quota, contextRefs, thread) {
    var latest = MutableStateFlow(null);
    var deferred = async(this.g6o_1, VOID, VOID, AgentRuntime$spawnSupervised$slambda_0(this, agent, input, policy, latest, thread, priority, quota, contextRefs));
    return new SupervisedHandle(deferred, AgentRuntime$spawnSupervised$lambda(latest));
  }
  j71(graph, $completion) {
    return coroutineScope(AgentRuntime$submit$slambda_0(graph, this), $completion);
  }
  a6() {
    if (!this.v6o_1.u1e(false, true))
      return Unit_instance;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.r6o_1.n1().j3().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      element.e6y('agent runtime closed');
    }
    this.f6o_1.bw(CancellationException.nd('agent runtime closed'));
    this.m6o_1.k71();
    this.r6o_1.t1e(emptyMap());
    this.q6o_1.t1e(emptyMap());
    this.s6o_1.t1e(emptyMap());
    this.t6o_1.t1e(emptyMap());
  }
}
class AgentRuntimeConfig {
  constructor() {
    this.p70_1 = 2147483647;
    this.q70_1 = Dispatchers_getInstance().k16_1;
    this.r70_1 = Companion_getInstance_49().l71_1;
    this.s70_1 = new WindowMemoryProvider(40);
    this.t70_1 = 1024;
  }
}
class AgentIdConflictException extends IllegalStateException {
  static s6x(agentId) {
    var $this = this.t4("AgentId '" + _AgentId___get_value__impl__1mym7n(agentId) + "' is already registered to another Agent definition; " + 'call replaceAgent() while it is idle');
    captureStack($this, $this.r6x_1);
    $this.q6x_1 = agentId;
    return $this;
  }
}
class AgentRegistration {
  constructor(definitionUid, agentName, activeRuns, definitionVersion) {
    this.i6x_1 = definitionUid;
    this.j6x_1 = agentName;
    this.k6x_1 = activeRuns;
    this.l6x_1 = definitionVersion;
  }
  d74(definitionUid, agentName, activeRuns, definitionVersion) {
    return new AgentRegistration(definitionUid, agentName, activeRuns, definitionVersion);
  }
  m6x(definitionUid, agentName, activeRuns, definitionVersion, $super) {
    definitionUid = definitionUid === VOID ? this.i6x_1 : definitionUid;
    agentName = agentName === VOID ? this.j6x_1 : agentName;
    activeRuns = activeRuns === VOID ? this.k6x_1 : activeRuns;
    definitionVersion = definitionVersion === VOID ? this.l6x_1 : definitionVersion;
    return $super === VOID ? this.d74(definitionUid, agentName, activeRuns, definitionVersion) : $super.d74.call(this, definitionUid, agentName, activeRuns, definitionVersion);
  }
  toString() {
    return 'AgentRegistration(definitionUid=' + this.i6x_1.toString() + ', agentName=' + this.j6x_1 + ', activeRuns=' + this.k6x_1 + ', definitionVersion=' + this.l6x_1.toString() + ')';
  }
  hashCode() {
    var result = this.i6x_1.hashCode();
    result = imul(result, 31) + getStringHashCode(this.j6x_1) | 0;
    result = imul(result, 31) + this.k6x_1 | 0;
    result = imul(result, 31) + this.l6x_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AgentRegistration))
      return false;
    var tmp0_other_with_cast = other instanceof AgentRegistration ? other : THROW_CCE();
    if (!this.i6x_1.equals(tmp0_other_with_cast.i6x_1))
      return false;
    if (!(this.j6x_1 === tmp0_other_with_cast.j6x_1))
      return false;
    if (!(this.k6x_1 === tmp0_other_with_cast.k6x_1))
      return false;
    if (!this.l6x_1.equals(tmp0_other_with_cast.l6x_1))
      return false;
    return true;
  }
}
class ChildFailure {
  constructor(runId, error) {
    this.x6y_1 = runId;
    this.y6y_1 = error;
  }
  toString() {
    return 'ChildFailure(runId=' + RunId__toString_impl_q8god7(this.x6y_1) + ', error=' + toString(this.y6y_1) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.x6y_1);
    result = imul(result, 31) + hashCode(this.y6y_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChildFailure))
      return false;
    var tmp0_other_with_cast = other instanceof ChildFailure ? other : THROW_CCE();
    if (!equals(this.x6y_1, tmp0_other_with_cast.x6y_1))
      return false;
    if (!equals(this.y6y_1, tmp0_other_with_cast.y6y_1))
      return false;
    return true;
  }
}
class QuotaSignal extends CancellationException {
  static c6w(dimension) {
    var $this = this.nd('quota exceeded: ' + dimension);
    captureStack($this, $this.b6w_1);
    $this.a6w_1 = dimension;
    return $this;
  }
}
class AcbSnapshot {
  constructor(runId, agentId, agentName, threadId, turnId, state, priority, parent, correlationId, children, acceptingChildren, usage, stepsCompleted, toolCalls, elapsedMillis, error) {
    this.x6q_1 = runId;
    this.y6q_1 = agentId;
    this.z6q_1 = agentName;
    this.a6r_1 = threadId;
    this.b6r_1 = turnId;
    this.c6r_1 = state;
    this.d6r_1 = priority;
    this.e6r_1 = parent;
    this.f6r_1 = correlationId;
    this.g6r_1 = children;
    this.h6r_1 = acceptingChildren;
    this.i6r_1 = usage;
    this.j6r_1 = stepsCompleted;
    this.k6r_1 = toolCalls;
    this.l6r_1 = elapsedMillis;
    this.m6r_1 = error;
  }
  e74(runId, agentId, agentName, threadId, turnId, state, priority, parent, correlationId, children, acceptingChildren, usage, stepsCompleted, toolCalls, elapsedMillis, error) {
    return new AcbSnapshot(runId, agentId, agentName, threadId, turnId, state, priority, parent, correlationId, children, acceptingChildren, usage, stepsCompleted, toolCalls, elapsedMillis, error);
  }
  f74(runId, agentId, agentName, threadId, turnId, state, priority, parent, correlationId, children, acceptingChildren, usage, stepsCompleted, toolCalls, elapsedMillis, error, $super) {
    runId = runId === VOID ? this.x6q_1 : runId;
    agentId = agentId === VOID ? this.y6q_1 : agentId;
    agentName = agentName === VOID ? this.z6q_1 : agentName;
    threadId = threadId === VOID ? this.a6r_1 : threadId;
    turnId = turnId === VOID ? this.b6r_1 : turnId;
    state = state === VOID ? this.c6r_1 : state;
    priority = priority === VOID ? this.d6r_1 : priority;
    parent = parent === VOID ? this.e6r_1 : parent;
    correlationId = correlationId === VOID ? this.f6r_1 : correlationId;
    children = children === VOID ? this.g6r_1 : children;
    acceptingChildren = acceptingChildren === VOID ? this.h6r_1 : acceptingChildren;
    usage = usage === VOID ? this.i6r_1 : usage;
    stepsCompleted = stepsCompleted === VOID ? this.j6r_1 : stepsCompleted;
    toolCalls = toolCalls === VOID ? this.k6r_1 : toolCalls;
    elapsedMillis = elapsedMillis === VOID ? this.l6r_1 : elapsedMillis;
    error = error === VOID ? this.m6r_1 : error;
    var tmp;
    if ($super === VOID) {
      tmp = this.e74(runId, agentId, agentName, threadId, turnId, state, priority, parent, correlationId, children, acceptingChildren, usage, stepsCompleted, toolCalls, elapsedMillis, error);
    } else {
      var tmp_0 = $super.e74;
      var tmp_1 = threadId;
      var tmp_2 = tmp_1 == null ? null : new ThreadId(tmp_1);
      var tmp_3 = turnId;
      var tmp_4 = tmp_3 == null ? null : new TurnId(tmp_3);
      var tmp_5 = parent;
      tmp = tmp_0.call(this, new RunId(runId), new AgentId(agentId), agentName, tmp_2, tmp_4, state, priority, tmp_5 == null ? null : new RunId(tmp_5), correlationId, children, acceptingChildren, usage, stepsCompleted, toolCalls, elapsedMillis, error);
    }
    return tmp;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.x6q_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.y6q_1);
    var tmp_1 = this.a6r_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.b6r_1;
    var tmp_4 = toString_0(tmp_3 == null ? null : new TurnId(tmp_3));
    var tmp_5 = this.c6r_1.toString();
    var tmp_6 = this.e6r_1;
    return 'AcbSnapshot(runId=' + tmp + ', agentId=' + tmp_0 + ', agentName=' + this.z6q_1 + ', threadId=' + tmp_2 + ', turnId=' + tmp_4 + ', state=' + tmp_5 + ', priority=' + this.d6r_1 + ', parent=' + toString_0(tmp_6 == null ? null : new RunId(tmp_6)) + ', correlationId=' + this.f6r_1 + ', children=' + toString(this.g6r_1) + ', acceptingChildren=' + this.h6r_1 + ', usage=' + this.i6r_1.toString() + ', stepsCompleted=' + this.j6r_1 + ', toolCalls=' + this.k6r_1 + ', elapsedMillis=' + this.l6r_1.toString() + ', error=' + toString_0(this.m6r_1) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.x6q_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.y6q_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.z6q_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.a6r_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.a6r_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.b6r_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.b6r_1);
    }
    result = tmp_2 + tmp_3 | 0;
    result = imul(result, 31) + this.c6r_1.hashCode() | 0;
    result = imul(result, 31) + this.d6r_1 | 0;
    var tmp_5 = imul(result, 31);
    var tmp_6;
    var tmp_7 = this.e6r_1;
    if ((tmp_7 == null ? null : new RunId(tmp_7)) == null) {
      tmp_6 = 0;
    } else {
      tmp_6 = RunId__hashCode_impl_4harkc(this.e6r_1);
    }
    result = tmp_5 + tmp_6 | 0;
    result = imul(result, 31) + (this.f6r_1 == null ? 0 : getStringHashCode(this.f6r_1)) | 0;
    result = imul(result, 31) + hashCode(this.g6r_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.h6r_1) | 0;
    result = imul(result, 31) + this.i6r_1.hashCode() | 0;
    result = imul(result, 31) + this.j6r_1 | 0;
    result = imul(result, 31) + this.k6r_1 | 0;
    result = imul(result, 31) + this.l6r_1.hashCode() | 0;
    result = imul(result, 31) + (this.m6r_1 == null ? 0 : hashCode(this.m6r_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AcbSnapshot))
      return false;
    var tmp0_other_with_cast = other instanceof AcbSnapshot ? other : THROW_CCE();
    if (!equals(this.x6q_1, tmp0_other_with_cast.x6q_1))
      return false;
    if (!(this.y6q_1 === tmp0_other_with_cast.y6q_1))
      return false;
    if (!(this.z6q_1 === tmp0_other_with_cast.z6q_1))
      return false;
    var tmp = this.a6r_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.a6r_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.b6r_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.b6r_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    if (!this.c6r_1.equals(tmp0_other_with_cast.c6r_1))
      return false;
    if (!(this.d6r_1 === tmp0_other_with_cast.d6r_1))
      return false;
    var tmp_5 = this.e6r_1;
    var tmp_6 = tmp_5 == null ? null : new RunId(tmp_5);
    var tmp_7 = tmp0_other_with_cast.e6r_1;
    if (!equals(tmp_6, tmp_7 == null ? null : new RunId(tmp_7)))
      return false;
    if (!(this.f6r_1 == tmp0_other_with_cast.f6r_1))
      return false;
    if (!equals(this.g6r_1, tmp0_other_with_cast.g6r_1))
      return false;
    if (!(this.h6r_1 === tmp0_other_with_cast.h6r_1))
      return false;
    if (!this.i6r_1.equals(tmp0_other_with_cast.i6r_1))
      return false;
    if (!(this.j6r_1 === tmp0_other_with_cast.j6r_1))
      return false;
    if (!(this.k6r_1 === tmp0_other_with_cast.k6r_1))
      return false;
    if (!this.l6r_1.equals(tmp0_other_with_cast.l6r_1))
      return false;
    if (!equals(this.m6r_1, tmp0_other_with_cast.m6r_1))
      return false;
    return true;
  }
}
class Acb {
  constructor(runId, agentId, agentName, threadId, turnId, priority, parent, correlationId) {
    this.r6q_1 = runId;
    this.s6q_1 = MutableStateFlow(false);
    this.t6q_1 = MutableStateFlow(emptyMap());
    this.u6q_1 = MutableStateFlow(new AcbSnapshot(this.r6q_1, agentId, agentName, threadId, turnId, LifecycleState_CREATED_getInstance(), priority, parent, correlationId, emptyList(), true, Companion_getInstance_43().t5r_1, 0, 0, new Long(0, 0), null));
    this.v6q_1 = Monotonic_instance.fj();
  }
  w6q() {
    return this.u6q_1.n1();
  }
  g74() {
    return asStateFlow(this.u6q_1);
  }
  h74(to) {
    var tmp0 = this.u6q_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp0.n1();
        var tmp;
        if (prevValue.c6r_1.equals(to) || prevValue.c6r_1.i74(to)) {
          tmp = prevValue.f74(VOID, VOID, VOID, VOID, VOID, to, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, elapsed(this));
        } else {
          tmp = prevValue;
        }
        var nextValue = tmp;
        if (tmp0.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
  }
  o6y() {
    return this.h74(LifecycleState_READY_getInstance());
  }
  p6s() {
    this.h74(LifecycleState_RUNNING_getInstance());
  }
  s6v(event) {
    var tmp0 = this.u6q_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp0.n1();
        var tmp;
        if (event instanceof StepCompleted) {
          tmp = prevValue.f74(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, prevValue.j6r_1 + 1 | 0, VOID, elapsed(this));
        } else {
          if (event instanceof ToolCallRequested) {
            tmp = prevValue.f74(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, prevValue.k6r_1 + 1 | 0, elapsed(this));
          } else {
            if (isInterface(event, Terminal)) {
              tmp = prevValue.f74(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, event.k5r(), VOID, VOID, elapsed(this));
            } else {
              if (event instanceof Failed) {
                tmp = prevValue.f74(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, !event.v5r_1.equals(Companion_getInstance_43().t5r_1) ? event.v5r_1 : prevValue.i6r_1, VOID, VOID, elapsed(this));
              } else {
                tmp = prevValue.f74(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, elapsed(this));
              }
            }
          }
        }
        var nextValue = tmp;
        if (tmp0.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
  }
  z6s(usage) {
    var tmp0 = this.u6q_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp0.n1();
        var nextValue = prevValue.f74(VOID, VOID, VOID, VOID, VOID, LifecycleState_FINISHED_getInstance(), VOID, VOID, VOID, VOID, VOID, usage, VOID, VOID, elapsed(this));
        if (tmp0.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
  }
  n6r(error, usage) {
    var tmp0 = this.u6q_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp0.n1();
        var tmp0_state = LifecycleState_FAILED_getInstance();
        var tmp1_usage = !usage.equals(Companion_getInstance_43().t5r_1) ? usage : prevValue.i6r_1;
        var tmp2_elapsedMillis = elapsed(this);
        var nextValue = prevValue.f74(VOID, VOID, VOID, VOID, VOID, tmp0_state, VOID, VOID, VOID, VOID, VOID, tmp1_usage, VOID, VOID, tmp2_elapsedMillis, error);
        if (tmp0.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
  }
  a6z() {
    var tmp0 = this.u6q_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp0.n1();
        var nextValue = prevValue.c6r_1.equals(LifecycleState_CANCELLED_getInstance()) ? prevValue.f74(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, elapsed(this)) : prevValue.c6r_1.equals(LifecycleState_COMMITTING_getInstance()) ? prevValue : prevValue.c6r_1.n6p() ? prevValue : prevValue.f74(VOID, VOID, VOID, VOID, VOID, LifecycleState_CANCELLED_getInstance(), VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, elapsed(this));
        if (tmp0.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
  }
  z6y() {
    while (true) {
      var current = this.u6q_1.n1();
      if (current.c6r_1.n6p())
        return false;
      if (current.c6r_1.equals(LifecycleState_COMMITTING_getInstance()))
        return true;
      var next = current.f74(VOID, VOID, VOID, VOID, VOID, LifecycleState_COMMITTING_getInstance(), VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, elapsed(this));
      if (this.u6q_1.u1e(current, next))
        return true;
    }
  }
  n6v(to) {
    return this.h74(to);
  }
  y6x(child, failurePolicy) {
    while (true) {
      var current = this.u6q_1.n1();
      if (!current.h6r_1 || current.c6r_1.n6p())
        return false;
      if (this.u6q_1.u1e(current, current.f74(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, plus(current.g6r_1, new RunId(child))))) {
        var tmp0 = this.t6q_1;
        $l$block: {
          // Inline function 'kotlinx.coroutines.flow.update' call
          while (true) {
            var prevValue = tmp0.n1();
            var nextValue = plus_1(prevValue, to(new RunId(child), failurePolicy));
            if (tmp0.u1e(prevValue, nextValue)) {
              break $l$block;
            }
          }
        }
        return true;
      }
    }
  }
  c6z(child) {
    var tmp0_elvis_lhs = this.t6q_1.n1().h3(new RunId(child));
    var tmp;
    if (tmp0_elvis_lhs == null) {
      var message = "child run '" + _RunId___get_value__impl__30zeiv(child).toString() + "' is not linked to parent '" + _RunId___get_value__impl__30zeiv(this.r6q_1).toString() + "'";
      throw IllegalStateException.t4(toString(message));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  b6z() {
    return this.s6q_1.u1e(false, true);
  }
  g6y(child) {
    var tmp0 = this.u6q_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp0.n1();
        var nextValue = prevValue.f74(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, minus_1(prevValue.g6r_1, new RunId(child)));
        if (tmp0.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
    var tmp2 = this.t6q_1;
    $l$block_0: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue_0 = tmp2.n1();
        var nextValue_0 = minus(prevValue_0, new RunId(child));
        if (tmp2.u1e(prevValue_0, nextValue_0)) {
          break $l$block_0;
        }
      }
    }
  }
  w6y() {
    var tmp0 = this.u6q_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp0.n1();
        var nextValue = prevValue.f74(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, false);
        if (tmp0.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
  }
}
class AgentHandle$awaitInternal$slambda {
  constructor(this$0) {
    this.k74_1 = this$0;
  }
  vd($completion) {
    return this.k74_1.e6p_1.vw($completion);
  }
}
class AgentHandle$join$slambda {
  constructor(this$0) {
    this.j74_1 = this$0;
  }
  vd($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_39.bind(VOID, this), $completion);
  }
}
class AgentHandle {
  constructor(runId, agentId, threadId, turnId, correlationId, acb, control, deferred, failurePolicy, eventJournal) {
    this.x6o_1 = runId;
    this.y6o_1 = agentId;
    this.z6o_1 = threadId;
    this.a6p_1 = turnId;
    this.b6p_1 = correlationId;
    this.c6p_1 = acb;
    this.d6p_1 = control;
    this.e6p_1 = deferred;
    this.f6p_1 = failurePolicy;
    this.g6p_1 = eventJournal;
    this.h6p_1 = MutableStateFlow(false);
    this.i6p_1 = MutableStateFlow(false);
  }
  w6q() {
    return this.c6p_1.w6q();
  }
  g74() {
    return this.c6p_1.g74();
  }
  l74(afterSequence) {
    return this.g6p_1.l74(afterSequence);
  }
  j6p(afterSequence, $super) {
    afterSequence = afterSequence === VOID ? null : afterSequence;
    return $super === VOID ? this.l74(afterSequence) : $super.l74.call(this, afterSequence);
  }
  k6p() {
    return this.c6p_1.w6q().c6r_1;
  }
  su() {
    return this.e6p_1.su();
  }
  vw($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_await__mos7q6_0.bind(VOID, this), $completion);
  }
  d6z($completion) {
    return awaitInternal(this, $completion);
  }
  e6z() {
    return this.h6p_1.n1();
  }
  f6z() {
    return this.i6p_1.u1e(false, true);
  }
  yv($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_join__qmovdu.bind(VOID, this), $completion);
  }
  e6y(reason) {
    this.c6p_1.a6z();
    this.e6p_1.bw(CancellationException.nd(reason == null ? 'cancelled by operator' : reason));
  }
  m74() {
    this.d6p_1.m74();
  }
  s1o() {
    this.d6p_1.s1o();
  }
}
class JournalEventSink {
  constructor(journal) {
    this.o6z_1 = journal;
  }
  r6v(event, $completion) {
    this.o6z_1.h6x(new Agent_0(event));
  }
  p6z(cause) {
    this.o6z_1.p6z(cause);
  }
}
class InstanceControl$awaitResumed$slambda {
  n74(it, $completion) {
    return !it;
  }
  td(p1, $completion) {
    return this.n74((!(p1 == null) ? typeof p1 === 'boolean' : false) ? p1 : THROW_CCE(), $completion);
  }
}
class InstanceControl {
  constructor() {
    this.o6v_1 = MutableStateFlow(false);
  }
  q6v() {
    return this.o6v_1.n1();
  }
  m74() {
    this.o6v_1.t1e(true);
  }
  s1o() {
    this.o6v_1.t1e(false);
  }
  p6v($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_awaitResumed__rl7ddl.bind(VOID, this), $completion);
  }
}
class LifecycleState extends Enum {
  n6p() {
    return this.equals(LifecycleState_FAILED_getInstance()) || this.equals(LifecycleState_FINISHED_getInstance()) || this.equals(LifecycleState_CANCELLED_getInstance());
  }
  i74(target) {
    var tmp;
    switch (this.o3_1) {
      case 0:
        tmp = target.equals(LifecycleState_THREAD_QUEUED_getInstance()) || target.equals(LifecycleState_READY_getInstance()) || target.equals(LifecycleState_CANCELLED_getInstance());
        break;
      case 1:
        tmp = target.equals(LifecycleState_READY_getInstance()) || target.equals(LifecycleState_CANCELLED_getInstance());
        break;
      case 2:
        tmp = target.equals(LifecycleState_RUNNING_getInstance()) || target.equals(LifecycleState_CANCELLED_getInstance());
        break;
      case 3:
        tmp = (!target.equals(LifecycleState_CREATED_getInstance()) && !target.equals(LifecycleState_THREAD_QUEUED_getInstance()) && !target.equals(LifecycleState_READY_getInstance()));
        break;
      case 4:
        tmp = target.equals(LifecycleState_RUNNING_getInstance()) || target.equals(LifecycleState_COMMITTING_getInstance()) || target.equals(LifecycleState_CANCELLED_getInstance()) || target.equals(LifecycleState_FAILED_getInstance()) || target.equals(LifecycleState_FINISHED_getInstance());
        break;
      case 5:
        tmp = target.equals(LifecycleState_RUNNING_getInstance()) || target.equals(LifecycleState_CANCELLED_getInstance());
        break;
      case 6:
        tmp = target.equals(LifecycleState_FINISHED_getInstance()) || target.equals(LifecycleState_FAILED_getInstance());
        break;
      case 7:
      case 8:
      case 9:
        tmp = false;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
}
class RunEventEnvelope {
  constructor(runId, agentId, threadId, turnId, correlationId, sequence, timestampEpochMillis, payload) {
    this.b6n_1 = runId;
    this.c6n_1 = agentId;
    this.d6n_1 = threadId;
    this.e6n_1 = turnId;
    this.f6n_1 = correlationId;
    this.g6n_1 = sequence;
    this.h6n_1 = timestampEpochMillis;
    this.i6n_1 = payload;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.b6n_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.c6n_1);
    var tmp_1 = this.d6n_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.e6n_1;
    return 'RunEventEnvelope(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ', correlationId=' + this.f6n_1 + ', sequence=' + this.g6n_1.toString() + ', timestampEpochMillis=' + this.h6n_1.toString() + ', payload=' + toString(this.i6n_1) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.b6n_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.c6n_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.d6n_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.d6n_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.e6n_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.e6n_1);
    }
    result = tmp_2 + tmp_3 | 0;
    result = imul(result, 31) + (this.f6n_1 == null ? 0 : getStringHashCode(this.f6n_1)) | 0;
    result = imul(result, 31) + this.g6n_1.hashCode() | 0;
    result = imul(result, 31) + this.h6n_1.hashCode() | 0;
    result = imul(result, 31) + hashCode(this.i6n_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RunEventEnvelope))
      return false;
    var tmp0_other_with_cast = other instanceof RunEventEnvelope ? other : THROW_CCE();
    if (!equals(this.b6n_1, tmp0_other_with_cast.b6n_1))
      return false;
    if (!(this.c6n_1 === tmp0_other_with_cast.c6n_1))
      return false;
    var tmp = this.d6n_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.d6n_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.e6n_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.e6n_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    if (!(this.f6n_1 == tmp0_other_with_cast.f6n_1))
      return false;
    if (!this.g6n_1.equals(tmp0_other_with_cast.g6n_1))
      return false;
    if (!this.h6n_1.equals(tmp0_other_with_cast.h6n_1))
      return false;
    if (!equals(this.i6n_1, tmp0_other_with_cast.i6n_1))
      return false;
    return true;
  }
}
class Agent_0 {
  constructor(event) {
    this.t6n_1 = event;
  }
  toString() {
    return 'Agent(event=' + toString(this.t6n_1) + ')';
  }
  hashCode() {
    return hashCode(this.t6n_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Agent_0))
      return false;
    var tmp0_other_with_cast = other instanceof Agent_0 ? other : THROW_CCE();
    if (!equals(this.t6n_1, tmp0_other_with_cast.t6n_1))
      return false;
    return true;
  }
}
class Lifecycle {
  constructor(event) {
    this.o74_1 = event;
  }
  toString() {
    return 'Lifecycle(event=' + toString(this.o74_1) + ')';
  }
  hashCode() {
    return hashCode(this.o74_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Lifecycle))
      return false;
    var tmp0_other_with_cast = other instanceof Lifecycle ? other : THROW_CCE();
    if (!equals(this.o74_1, tmp0_other_with_cast.o74_1))
      return false;
    return true;
  }
}
class HistoryGap {
  constructor(requestedAfter, oldestAvailable) {
    this.j6n_1 = requestedAfter;
    this.k6n_1 = oldestAvailable;
  }
  toString() {
    return 'HistoryGap(requestedAfter=' + this.j6n_1.toString() + ', oldestAvailable=' + this.k6n_1.toString() + ')';
  }
  hashCode() {
    var result = this.j6n_1.hashCode();
    result = imul(result, 31) + this.k6n_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof HistoryGap))
      return false;
    var tmp0_other_with_cast = other instanceof HistoryGap ? other : THROW_CCE();
    if (!this.j6n_1.equals(tmp0_other_with_cast.j6n_1))
      return false;
    if (!this.k6n_1.equals(tmp0_other_with_cast.k6n_1))
      return false;
    return true;
  }
}
class RunEventJournal$events$slambda$slambda {
  constructor($cursor) {
    this.v74_1 = $cursor;
  }
  w74(it, $completion) {
    var tmp;
    // Inline function 'kotlin.Long.minus' call
    if (it.r74_1.v3(toLong(1)).s1(this.v74_1._v) > 0) {
      tmp = true;
    } else {
      tmp = it.t74_1;
    }
    return tmp;
  }
  td(p1, $completion) {
    return this.w74(p1 instanceof State ? p1 : THROW_CCE(), $completion);
  }
}
class State {
  constructor(nextSequence, events, closed, closeCause) {
    nextSequence = nextSequence === VOID ? new Long(1, 0) : nextSequence;
    events = events === VOID ? emptyList() : events;
    closed = closed === VOID ? false : closed;
    closeCause = closeCause === VOID ? null : closeCause;
    this.r74_1 = nextSequence;
    this.s74_1 = events;
    this.t74_1 = closed;
    this.u74_1 = closeCause;
  }
  x74(nextSequence, events, closed, closeCause) {
    return new State(nextSequence, events, closed, closeCause);
  }
  y74(nextSequence, events, closed, closeCause, $super) {
    nextSequence = nextSequence === VOID ? this.r74_1 : nextSequence;
    events = events === VOID ? this.s74_1 : events;
    closed = closed === VOID ? this.t74_1 : closed;
    closeCause = closeCause === VOID ? this.u74_1 : closeCause;
    return $super === VOID ? this.x74(nextSequence, events, closed, closeCause) : $super.x74.call(this, nextSequence, events, closed, closeCause);
  }
  toString() {
    return 'State(nextSequence=' + this.r74_1.toString() + ', events=' + toString(this.s74_1) + ', closed=' + this.t74_1 + ', closeCause=' + toString_0(this.u74_1) + ')';
  }
  hashCode() {
    var result = this.r74_1.hashCode();
    result = imul(result, 31) + hashCode(this.s74_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.t74_1) | 0;
    result = imul(result, 31) + (this.u74_1 == null ? 0 : hashCode(this.u74_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof State))
      return false;
    var tmp0_other_with_cast = other instanceof State ? other : THROW_CCE();
    if (!this.r74_1.equals(tmp0_other_with_cast.r74_1))
      return false;
    if (!equals(this.s74_1, tmp0_other_with_cast.s74_1))
      return false;
    if (!(this.t74_1 === tmp0_other_with_cast.t74_1))
      return false;
    if (!equals(this.u74_1, tmp0_other_with_cast.u74_1))
      return false;
    return true;
  }
}
class RunEventJournal$events$slambda {
  constructor($afterSequence, this$0) {
    this.p74_1 = $afterSequence;
    this.q74_1 = this$0;
  }
  z74($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_40.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.z74((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class RunEventJournal {
  constructor(runId, agentId, threadId, turnId, correlationId, capacity) {
    this.a6x_1 = runId;
    this.b6x_1 = agentId;
    this.c6x_1 = threadId;
    this.d6x_1 = turnId;
    this.e6x_1 = correlationId;
    this.f6x_1 = capacity;
    // Inline function 'kotlin.require' call
    if (!(this.f6x_1 > 0)) {
      var message = 'run event buffer capacity must be positive';
      throw IllegalArgumentException.t(toString(message));
    }
    this.g6x_1 = MutableStateFlow(new State());
  }
  h6x(payload) {
    while (true) {
      var current = this.g6x_1.n1();
      if (current.t74_1)
        return Unit_instance;
      var event = envelope(this, current.r74_1, payload);
      var tmp;
      if (current.s74_1.b1() < this.f6x_1) {
        tmp = plus(current.s74_1, event);
      } else {
        tmp = plus(drop(current.s74_1, 1), event);
      }
      var retained = tmp;
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$0 = current.r74_1.u3(toLong(1));
      var next = current.y74(tmp$ret$0, retained);
      if (this.g6x_1.u1e(current, next))
        return Unit_instance;
    }
  }
  p6z(cause) {
    while (true) {
      var current = this.g6x_1.n1();
      if (current.t74_1)
        return Unit_instance;
      if (this.g6x_1.u1e(current, current.y74(VOID, VOID, true, cause)))
        return Unit_instance;
    }
  }
  l74(afterSequence) {
    return flow(RunEventJournal$events$slambda_0(afterSequence, this));
  }
}
class RunEventHistoryGapException extends IllegalStateException {
  static r6n(requestedAfter, oldestAvailable) {
    var $this = this.t4('run event history after ' + requestedAfter.toString() + ' is no longer available; oldest retained sequence is ' + oldestAvailable.toString());
    captureStack($this, $this.q6n_1);
    $this.o6n_1 = requestedAfter;
    $this.p6n_1 = oldestAvailable;
    return $this;
  }
}
class RunId {
  constructor(value) {
    this.z6w_1 = value;
  }
  toString() {
    return RunId__toString_impl_q8god7(this.z6w_1);
  }
  hashCode() {
    return RunId__hashCode_impl_4harkc(this.z6w_1);
  }
  equals(other) {
    return RunId__equals_impl_gwlu3c(this.z6w_1, other);
  }
}
class TurnId {
  constructor(value) {
    this.x6u_1 = value;
  }
  toString() {
    return TurnId__toString_impl_gyl6zb(this.x6u_1);
  }
  hashCode() {
    return TurnId__hashCode_impl_wbcy6y(this.x6u_1);
  }
  equals(other) {
    return TurnId__equals_impl_cgt3p2(this.x6u_1, other);
  }
}
class ContextRef {
  constructor(id) {
    this.g6z_1 = id;
  }
  toString() {
    return ContextRef__toString_impl_l0p4oz(this.g6z_1);
  }
  hashCode() {
    return ContextRef__hashCode_impl_s990ha(this.g6z_1);
  }
  equals(other) {
    return ContextRef__equals_impl_dumauu(this.g6z_1, other);
  }
}
class ContextScope extends Enum {}
class ContextStore {
  constructor() {
    this.h6z_1 = MutableStateFlow(emptyMap());
  }
  k75(messages, scope, owner) {
    var ref = _ContextRef___init__impl__laq00z(address(this, scope, owner, null, messages));
    var tmp0 = this.h6z_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp0.n1();
        var tmp;
        // Inline function 'kotlin.collections.contains' call
        // Inline function 'kotlin.collections.containsKey' call
        var key = _ContextRef___get_id__impl__uspq4f(ref);
        if ((isInterface(prevValue, KtMap) ? prevValue : THROW_CCE()).f3(key)) {
          tmp = prevValue;
        } else {
          tmp = plus_1(prevValue, to(_ContextRef___get_id__impl__uspq4f(ref), new ContextBlock(ref, scope, owner, null, messages)));
        }
        var nextValue = tmp;
        if (tmp0.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
    return ref;
  }
  l75(parent, added, scope, owner) {
    var tmp0 = this.h6z_1.n1();
    // Inline function 'kotlin.collections.contains' call
    // Inline function 'kotlin.collections.containsKey' call
    var key = _ContextRef___get_id__impl__uspq4f(parent);
    // Inline function 'kotlin.require' call
    if (!(isInterface(tmp0, KtMap) ? tmp0 : THROW_CCE()).f3(key)) {
      var message = 'unknown parent context ref: ' + _ContextRef___get_id__impl__uspq4f(parent);
      throw IllegalArgumentException.t(toString(message));
    }
    var ref = _ContextRef___init__impl__laq00z(address(this, scope, owner, parent, added));
    var tmp3 = this.h6z_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp3.n1();
        var tmp;
        // Inline function 'kotlin.collections.contains' call
        // Inline function 'kotlin.collections.containsKey' call
        var key_0 = _ContextRef___get_id__impl__uspq4f(ref);
        if ((isInterface(prevValue, KtMap) ? prevValue : THROW_CCE()).f3(key_0)) {
          tmp = prevValue;
        } else {
          tmp = plus_1(prevValue, to(_ContextRef___get_id__impl__uspq4f(ref), new ContextBlock(ref, scope, owner, parent, added)));
        }
        var nextValue = tmp;
        if (tmp3.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
    return ref;
  }
  i6z(ref, requester) {
    var chain = ArrayList.k();
    var cur = ref;
    $l$loop: while (true) {
      var tmp = cur;
      if (!!((tmp == null ? null : new ContextRef(tmp)) == null)) {
        break $l$loop;
      }
      var tmp0_elvis_lhs = this.h6z_1.n1().h3(_ContextRef___get_id__impl__uspq4f(cur));
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        var message = 'unknown context ref: ' + _ContextRef___get_id__impl__uspq4f(cur);
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      var block = tmp_0;
      checkAccess(this, block, requester);
      chain.l(block);
      cur = block.d75_1;
    }
    reverse(chain);
    // Inline function 'kotlin.collections.flatMap' call
    // Inline function 'kotlin.collections.flatMapTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = chain.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var list = element.e75_1;
      addAll(destination, list);
    }
    return destination;
  }
}
class ContextAccessException extends Exception {
  static j75(ref, requester) {
    var tmp = requester;
    var $this = this.l5('agent ' + toString_0(tmp == null ? null : new RunId(tmp)) + ' may not read ' + ContextRef__toString_impl_l0p4oz(ref));
    captureStack($this, $this.i75_1);
    $this.g75_1 = ref;
    $this.h75_1 = requester;
    return $this;
  }
}
class ContextBlock {
  constructor(ref, scope, owner, parent, messages) {
    this.a75_1 = ref;
    this.b75_1 = scope;
    this.c75_1 = owner;
    this.d75_1 = parent;
    this.e75_1 = messages;
  }
}
class SupervisedHandle {
  constructor(deferred, onCancel) {
    this.m75_1 = deferred;
    this.n75_1 = onCancel;
  }
  vw($completion) {
    return this.m75_1.vw($completion);
  }
  e6y(reason) {
    this.n75_1(reason);
    this.m75_1.bw(CancellationException.nd(reason == null ? 'supervised run cancelled' : reason));
  }
}
class SupervisionPolicy {
  constructor(maxRetries, initialBackoffMillis, backoffFactor, maxBackoffMillis, circuitBreaker, retryOn, recover) {
    maxRetries = maxRetries === VOID ? 2 : maxRetries;
    initialBackoffMillis = initialBackoffMillis === VOID ? new Long(100, 0) : initialBackoffMillis;
    backoffFactor = backoffFactor === VOID ? 2.0 : backoffFactor;
    maxBackoffMillis = maxBackoffMillis === VOID ? new Long(5000, 0) : maxBackoffMillis;
    circuitBreaker = circuitBreaker === VOID ? null : circuitBreaker;
    var tmp;
    if (retryOn === VOID) {
      tmp = SupervisionPolicy$_init_$lambda_4mgt92;
    } else {
      tmp = retryOn;
    }
    retryOn = tmp;
    recover = recover === VOID ? null : recover;
    this.o75_1 = maxRetries;
    this.p75_1 = initialBackoffMillis;
    this.q75_1 = backoffFactor;
    this.r75_1 = maxBackoffMillis;
    this.s75_1 = circuitBreaker;
    this.t75_1 = retryOn;
    this.u75_1 = recover;
  }
  toString() {
    return 'SupervisionPolicy(maxRetries=' + this.o75_1 + ', initialBackoffMillis=' + this.p75_1.toString() + ', backoffFactor=' + this.q75_1 + ', maxBackoffMillis=' + this.r75_1.toString() + ', circuitBreaker=' + toString_0(this.s75_1) + ', retryOn=' + toString(this.t75_1) + ', recover=' + toString_0(this.u75_1) + ')';
  }
  hashCode() {
    var result = this.o75_1;
    result = imul(result, 31) + this.p75_1.hashCode() | 0;
    result = imul(result, 31) + getNumberHashCode(this.q75_1) | 0;
    result = imul(result, 31) + this.r75_1.hashCode() | 0;
    result = imul(result, 31) + (this.s75_1 == null ? 0 : this.s75_1.hashCode()) | 0;
    result = imul(result, 31) + hashCode(this.t75_1) | 0;
    result = imul(result, 31) + (this.u75_1 == null ? 0 : hashCode(this.u75_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SupervisionPolicy))
      return false;
    var tmp0_other_with_cast = other instanceof SupervisionPolicy ? other : THROW_CCE();
    if (!(this.o75_1 === tmp0_other_with_cast.o75_1))
      return false;
    if (!this.p75_1.equals(tmp0_other_with_cast.p75_1))
      return false;
    if (!equals(this.q75_1, tmp0_other_with_cast.q75_1))
      return false;
    if (!this.r75_1.equals(tmp0_other_with_cast.r75_1))
      return false;
    if (!equals(this.s75_1, tmp0_other_with_cast.s75_1))
      return false;
    if (!equals(this.t75_1, tmp0_other_with_cast.t75_1))
      return false;
    if (!equals(this.u75_1, tmp0_other_with_cast.u75_1))
      return false;
    return true;
  }
}
class CircuitBreakerPolicy {
  constructor(failureThreshold, resetTimeoutMillis) {
    failureThreshold = failureThreshold === VOID ? 5 : failureThreshold;
    resetTimeoutMillis = resetTimeoutMillis === VOID ? new Long(30000, 0) : resetTimeoutMillis;
    this.v75_1 = failureThreshold;
    this.w75_1 = resetTimeoutMillis;
  }
  toString() {
    return 'CircuitBreakerPolicy(failureThreshold=' + this.v75_1 + ', resetTimeoutMillis=' + this.w75_1.toString() + ')';
  }
  hashCode() {
    var result = this.v75_1;
    result = imul(result, 31) + this.w75_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CircuitBreakerPolicy))
      return false;
    var tmp0_other_with_cast = other instanceof CircuitBreakerPolicy ? other : THROW_CCE();
    if (!(this.v75_1 === tmp0_other_with_cast.v75_1))
      return false;
    if (!this.w75_1.equals(tmp0_other_with_cast.w75_1))
      return false;
    return true;
  }
}
class Supervisor {
  constructor() {
    this.l70_1 = Mutex();
    this.m70_1 = HashMap.l8();
    this.n70_1 = HashMap.l8();
  }
  o70(agentName, initialInput, policy, onRetrying, onCircuitOpen, attempt, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_run__cb7u2f_0.bind(VOID, this, agentName, initialInput, policy, onRetrying, onCircuitOpen, attempt), $completion);
  }
}
class EventBus$subscribe$o$collect$slambda {
  constructor($$this$unsafeFlow, $topic) {
    this.x75_1 = $$this$unsafeFlow;
    this.y75_1 = $topic;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_41.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class EventBus$subscribe$o$collect$slambda_0 {
  constructor($$this$unsafeFlow) {
    this.b76_1 = $$this$unsafeFlow;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_42.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_7 {
  constructor(function_0) {
    this.e76_1 = function_0;
  }
  t1c(value, $completion) {
    return this.e76_1(value, $completion);
  }
  n4() {
    return this.e76_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class EventBus$subscribe$$inlined$filter$1 {
  constructor($this, $topic) {
    this.z75_1 = $this;
    this.a76_1 = $topic;
  }
  o6d(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_0.bind(VOID, this, collector), $completion);
  }
  g1c(collector, $completion) {
    return this.o6d(collector, $completion);
  }
}
class EventBus$subscribe$$inlined$map$1 {
  constructor($this) {
    this.c76_1 = $this;
  }
  o6d(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_1.bind(VOID, this, collector), $completion);
  }
  g1c(collector, $completion) {
    return this.o6d(collector, $completion);
  }
}
class EventBus {
  constructor() {
    this.d76_1 = MutableSharedFlow(VOID, 256);
  }
  f76(topic, message, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_publish__pkz857.bind(VOID, this, topic, message), $completion);
  }
  g76(topic) {
    // Inline function 'kotlinx.coroutines.flow.filter' call
    // Inline function 'kotlinx.coroutines.flow.unsafeTransform' call
    var this_0 = this.d76_1;
    // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call
    // Inline function 'kotlinx.coroutines.flow.map' call
    // Inline function 'kotlinx.coroutines.flow.unsafeTransform' call
    var this_1 = new EventBus$subscribe$$inlined$filter$1(this_0, topic);
    // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call
    return new EventBus$subscribe$$inlined$map$1(this_1);
  }
}
class IpcHub {
  constructor() {
    this.z6x_1 = MutableStateFlow(new Long(0, 0));
    this.a6y_1 = MutableStateFlow(emptyMap());
    this.b6y_1 = MutableStateFlow(emptyMap());
    this.c6y_1 = new EventBus();
  }
  t76() {
    var tmp0 = this.z6x_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.getAndUpdate' call
      while (true) {
        var prevValue = tmp0.n1();
        // Inline function 'kotlin.Long.plus' call
        var nextValue = prevValue.u3(toLong(1));
        if (tmp0.u1e(prevValue, nextValue)) {
          tmp$ret$2 = prevValue;
          break $l$block;
        }
      }
    }
    return tmp$ret$2;
  }
  d6y(id) {
    var tmp0_safe_receiver = this.a6y_1.n1().h3(new RunId(id));
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var created = new Mailbox(id);
    var result = created;
    var tmp2 = this.a6y_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp2.n1();
        var existing = prevValue.h3(new RunId(id));
        var tmp;
        if (!(existing == null)) {
          result = existing;
          tmp = prevValue;
        } else {
          tmp = plus_1(prevValue, to(new RunId(id), created));
        }
        var nextValue = tmp;
        if (tmp2.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
    return result;
  }
  v76(message, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_send__qhx0g0.bind(VOID, this, message), $completion);
  }
  w76(message, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_request__hjt9xh_0.bind(VOID, this, message), $completion);
  }
  x76(to, payload, contextRefs, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_reply__ugx4wa.bind(VOID, this, to, payload, contextRefs), $completion);
  }
  f76(topic, message, $completion) {
    return this.c6y_1.f76(topic, message, $completion);
  }
  g76(topic) {
    return this.c6y_1.g76(topic);
  }
  f6y(id) {
    var tmp0_safe_receiver = this.a6y_1.n1().h3(new RunId(id));
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.y76();
    }
    var tmp0 = this.a6y_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp0.n1();
        var nextValue = minus(prevValue, new RunId(id));
        if (tmp0.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
  }
  k71() {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.a6y_1.n1().j3().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      element.y76();
    }
    this.a6y_1.t1e(emptyMap());
  }
}
class Mailbox {
  constructor(owner) {
    this.q76_1 = owner;
    this.r76_1 = Channel(-2);
  }
  s76(message, $completion) {
    return this.r76_1.j1a(message, $completion);
  }
  n1a($completion) {
    return this.r76_1.n1a($completion);
  }
  y76() {
    this.r76_1.w1a();
  }
}
class RuntimeMessage {
  constructor(id, sender, receiver, type, payload, contextRefs, priority, deadlineMillis, correlationId) {
    payload = payload === VOID ? '' : payload;
    contextRefs = contextRefs === VOID ? emptyList() : contextRefs;
    priority = priority === VOID ? 0 : priority;
    deadlineMillis = deadlineMillis === VOID ? null : deadlineMillis;
    correlationId = correlationId === VOID ? null : correlationId;
    this.h76_1 = id;
    this.i76_1 = sender;
    this.j76_1 = receiver;
    this.k76_1 = type;
    this.l76_1 = payload;
    this.m76_1 = contextRefs;
    this.n76_1 = priority;
    this.o76_1 = deadlineMillis;
    this.p76_1 = correlationId;
  }
  z76(id, sender, receiver, type, payload, contextRefs, priority, deadlineMillis, correlationId) {
    return new RuntimeMessage(id, sender, receiver, type, payload, contextRefs, priority, deadlineMillis, correlationId);
  }
  u76(id, sender, receiver, type, payload, contextRefs, priority, deadlineMillis, correlationId, $super) {
    id = id === VOID ? this.h76_1 : id;
    sender = sender === VOID ? this.i76_1 : sender;
    receiver = receiver === VOID ? this.j76_1 : receiver;
    type = type === VOID ? this.k76_1 : type;
    payload = payload === VOID ? this.l76_1 : payload;
    contextRefs = contextRefs === VOID ? this.m76_1 : contextRefs;
    priority = priority === VOID ? this.n76_1 : priority;
    deadlineMillis = deadlineMillis === VOID ? this.o76_1 : deadlineMillis;
    correlationId = correlationId === VOID ? this.p76_1 : correlationId;
    var tmp;
    if ($super === VOID) {
      tmp = this.z76(id, sender, receiver, type, payload, contextRefs, priority, deadlineMillis, correlationId);
    } else {
      var tmp_0 = $super.z76;
      var tmp_1 = sender;
      var tmp_2 = tmp_1 == null ? null : new RunId(tmp_1);
      var tmp_3 = receiver;
      tmp = tmp_0.call(this, id, tmp_2, tmp_3 == null ? null : new RunId(tmp_3), type, payload, contextRefs, priority, deadlineMillis, correlationId);
    }
    return tmp;
  }
  toString() {
    var tmp = this.h76_1.toString();
    var tmp_0 = this.i76_1;
    var tmp_1 = toString_0(tmp_0 == null ? null : new RunId(tmp_0));
    var tmp_2 = this.j76_1;
    return 'RuntimeMessage(id=' + tmp + ', sender=' + tmp_1 + ', receiver=' + toString_0(tmp_2 == null ? null : new RunId(tmp_2)) + ', type=' + this.k76_1 + ', payload=' + this.l76_1 + ', contextRefs=' + toString(this.m76_1) + ', priority=' + this.n76_1 + ', deadlineMillis=' + toString_0(this.o76_1) + ', correlationId=' + toString_0(this.p76_1) + ')';
  }
  hashCode() {
    var result = this.h76_1.hashCode();
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.i76_1;
    if ((tmp_1 == null ? null : new RunId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = RunId__hashCode_impl_4harkc(this.i76_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.j76_1;
    if ((tmp_4 == null ? null : new RunId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = RunId__hashCode_impl_4harkc(this.j76_1);
    }
    result = tmp_2 + tmp_3 | 0;
    result = imul(result, 31) + getStringHashCode(this.k76_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.l76_1) | 0;
    result = imul(result, 31) + hashCode(this.m76_1) | 0;
    result = imul(result, 31) + this.n76_1 | 0;
    result = imul(result, 31) + (this.o76_1 == null ? 0 : this.o76_1.hashCode()) | 0;
    result = imul(result, 31) + (this.p76_1 == null ? 0 : this.p76_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RuntimeMessage))
      return false;
    var tmp0_other_with_cast = other instanceof RuntimeMessage ? other : THROW_CCE();
    if (!this.h76_1.equals(tmp0_other_with_cast.h76_1))
      return false;
    var tmp = this.i76_1;
    var tmp_0 = tmp == null ? null : new RunId(tmp);
    var tmp_1 = tmp0_other_with_cast.i76_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new RunId(tmp_1)))
      return false;
    var tmp_2 = this.j76_1;
    var tmp_3 = tmp_2 == null ? null : new RunId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.j76_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new RunId(tmp_4)))
      return false;
    if (!(this.k76_1 === tmp0_other_with_cast.k76_1))
      return false;
    if (!(this.l76_1 === tmp0_other_with_cast.l76_1))
      return false;
    if (!equals(this.m76_1, tmp0_other_with_cast.m76_1))
      return false;
    if (!(this.n76_1 === tmp0_other_with_cast.n76_1))
      return false;
    if (!equals(this.o76_1, tmp0_other_with_cast.o76_1))
      return false;
    if (!equals(this.p76_1, tmp0_other_with_cast.p76_1))
      return false;
    return true;
  }
}
class Spawned {
  constructor(runId, agentId, agentName, threadId, turnId, priority, parent) {
    this.w73_1 = runId;
    this.x73_1 = agentId;
    this.y73_1 = agentName;
    this.z73_1 = threadId;
    this.a74_1 = turnId;
    this.b74_1 = priority;
    this.c74_1 = parent;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.w73_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.x73_1);
    var tmp_1 = this.z73_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.a74_1;
    var tmp_4 = toString_0(tmp_3 == null ? null : new TurnId(tmp_3));
    var tmp_5 = this.c74_1;
    return 'Spawned(runId=' + tmp + ', agentId=' + tmp_0 + ', agentName=' + this.y73_1 + ', threadId=' + tmp_2 + ', turnId=' + tmp_4 + ', priority=' + this.b74_1 + ', parent=' + toString_0(tmp_5 == null ? null : new RunId(tmp_5)) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.w73_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.x73_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.y73_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.z73_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.z73_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.a74_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.a74_1);
    }
    result = tmp_2 + tmp_3 | 0;
    result = imul(result, 31) + this.b74_1 | 0;
    var tmp_5 = imul(result, 31);
    var tmp_6;
    var tmp_7 = this.c74_1;
    if ((tmp_7 == null ? null : new RunId(tmp_7)) == null) {
      tmp_6 = 0;
    } else {
      tmp_6 = RunId__hashCode_impl_4harkc(this.c74_1);
    }
    result = tmp_5 + tmp_6 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Spawned))
      return false;
    var tmp0_other_with_cast = other instanceof Spawned ? other : THROW_CCE();
    if (!equals(this.w73_1, tmp0_other_with_cast.w73_1))
      return false;
    if (!(this.x73_1 === tmp0_other_with_cast.x73_1))
      return false;
    if (!(this.y73_1 === tmp0_other_with_cast.y73_1))
      return false;
    var tmp = this.z73_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.z73_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.a74_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.a74_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    if (!(this.b74_1 === tmp0_other_with_cast.b74_1))
      return false;
    var tmp_5 = this.c74_1;
    var tmp_6 = tmp_5 == null ? null : new RunId(tmp_5);
    var tmp_7 = tmp0_other_with_cast.c74_1;
    if (!equals(tmp_6, tmp_7 == null ? null : new RunId(tmp_7)))
      return false;
    return true;
  }
}
class Running {
  constructor(runId, agentId, threadId, turnId, agentName) {
    this.r73_1 = runId;
    this.s73_1 = agentId;
    this.t73_1 = threadId;
    this.u73_1 = turnId;
    this.v73_1 = agentName;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.r73_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.s73_1);
    var tmp_1 = this.t73_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.u73_1;
    return 'Running(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ', agentName=' + this.v73_1 + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.r73_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.s73_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.t73_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.t73_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.u73_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.u73_1);
    }
    result = tmp_2 + tmp_3 | 0;
    result = imul(result, 31) + getStringHashCode(this.v73_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Running))
      return false;
    var tmp0_other_with_cast = other instanceof Running ? other : THROW_CCE();
    if (!equals(this.r73_1, tmp0_other_with_cast.r73_1))
      return false;
    if (!(this.s73_1 === tmp0_other_with_cast.s73_1))
      return false;
    var tmp = this.t73_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.t73_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.u73_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.u73_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    if (!(this.v73_1 === tmp0_other_with_cast.v73_1))
      return false;
    return true;
  }
}
class Waiting {
  constructor(runId, agentId, threadId, turnId) {
    this.n73_1 = runId;
    this.o73_1 = agentId;
    this.p73_1 = threadId;
    this.q73_1 = turnId;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.n73_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.o73_1);
    var tmp_1 = this.p73_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.q73_1;
    return 'Waiting(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.n73_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.o73_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.p73_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.p73_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.q73_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.q73_1);
    }
    result = tmp_2 + tmp_3 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Waiting))
      return false;
    var tmp0_other_with_cast = other instanceof Waiting ? other : THROW_CCE();
    if (!equals(this.n73_1, tmp0_other_with_cast.n73_1))
      return false;
    if (!(this.o73_1 === tmp0_other_with_cast.o73_1))
      return false;
    var tmp = this.p73_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.p73_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.q73_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.q73_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    return true;
  }
}
class Suspended {
  constructor(runId, agentId, threadId, turnId) {
    this.j73_1 = runId;
    this.k73_1 = agentId;
    this.l73_1 = threadId;
    this.m73_1 = turnId;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.j73_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.k73_1);
    var tmp_1 = this.l73_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.m73_1;
    return 'Suspended(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.j73_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.k73_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.l73_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.l73_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.m73_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.m73_1);
    }
    result = tmp_2 + tmp_3 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Suspended))
      return false;
    var tmp0_other_with_cast = other instanceof Suspended ? other : THROW_CCE();
    if (!equals(this.j73_1, tmp0_other_with_cast.j73_1))
      return false;
    if (!(this.k73_1 === tmp0_other_with_cast.k73_1))
      return false;
    var tmp = this.l73_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.l73_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.m73_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.m73_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    return true;
  }
}
class Resumed {
  constructor(runId, agentId, threadId, turnId) {
    this.f73_1 = runId;
    this.g73_1 = agentId;
    this.h73_1 = threadId;
    this.i73_1 = turnId;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.f73_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.g73_1);
    var tmp_1 = this.h73_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.i73_1;
    return 'Resumed(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.f73_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.g73_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.h73_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.h73_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.i73_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.i73_1);
    }
    result = tmp_2 + tmp_3 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Resumed))
      return false;
    var tmp0_other_with_cast = other instanceof Resumed ? other : THROW_CCE();
    if (!equals(this.f73_1, tmp0_other_with_cast.f73_1))
      return false;
    if (!(this.g73_1 === tmp0_other_with_cast.g73_1))
      return false;
    var tmp = this.h73_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.h73_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.i73_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.i73_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    return true;
  }
}
class Finished_0 {
  constructor(runId, agentId, threadId, turnId, usage) {
    this.a73_1 = runId;
    this.b73_1 = agentId;
    this.c73_1 = threadId;
    this.d73_1 = turnId;
    this.e73_1 = usage;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.a73_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.b73_1);
    var tmp_1 = this.c73_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.d73_1;
    return 'Finished(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ', usage=' + this.e73_1.toString() + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.a73_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.b73_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.c73_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.c73_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.d73_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.d73_1);
    }
    result = tmp_2 + tmp_3 | 0;
    result = imul(result, 31) + this.e73_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Finished_0))
      return false;
    var tmp0_other_with_cast = other instanceof Finished_0 ? other : THROW_CCE();
    if (!equals(this.a73_1, tmp0_other_with_cast.a73_1))
      return false;
    if (!(this.b73_1 === tmp0_other_with_cast.b73_1))
      return false;
    var tmp = this.c73_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.c73_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.d73_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.d73_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    if (!this.e73_1.equals(tmp0_other_with_cast.e73_1))
      return false;
    return true;
  }
}
class Incomplete_3 {
  constructor(runId, agentId, threadId, turnId, reason, usage) {
    this.u72_1 = runId;
    this.v72_1 = agentId;
    this.w72_1 = threadId;
    this.x72_1 = turnId;
    this.y72_1 = reason;
    this.z72_1 = usage;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.u72_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.v72_1);
    var tmp_1 = this.w72_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.x72_1;
    return 'Incomplete(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ', reason=' + toString(this.y72_1) + ', usage=' + this.z72_1.toString() + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.u72_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.v72_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.w72_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.w72_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.x72_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.x72_1);
    }
    result = tmp_2 + tmp_3 | 0;
    result = imul(result, 31) + hashCode(this.y72_1) | 0;
    result = imul(result, 31) + this.z72_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Incomplete_3))
      return false;
    var tmp0_other_with_cast = other instanceof Incomplete_3 ? other : THROW_CCE();
    if (!equals(this.u72_1, tmp0_other_with_cast.u72_1))
      return false;
    if (!(this.v72_1 === tmp0_other_with_cast.v72_1))
      return false;
    var tmp = this.w72_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.w72_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.x72_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.x72_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    if (!equals(this.y72_1, tmp0_other_with_cast.y72_1))
      return false;
    if (!this.z72_1.equals(tmp0_other_with_cast.z72_1))
      return false;
    return true;
  }
}
class Terminated_1 {
  constructor(runId, agentId, threadId, turnId, reason) {
    this.p72_1 = runId;
    this.q72_1 = agentId;
    this.r72_1 = threadId;
    this.s72_1 = turnId;
    this.t72_1 = reason;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.p72_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.q72_1);
    var tmp_1 = this.r72_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.s72_1;
    return 'Terminated(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ', reason=' + toString(this.t72_1) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.p72_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.q72_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.r72_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.r72_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.s72_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.s72_1);
    }
    result = tmp_2 + tmp_3 | 0;
    result = imul(result, 31) + hashCode(this.t72_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Terminated_1))
      return false;
    var tmp0_other_with_cast = other instanceof Terminated_1 ? other : THROW_CCE();
    if (!equals(this.p72_1, tmp0_other_with_cast.p72_1))
      return false;
    if (!(this.q72_1 === tmp0_other_with_cast.q72_1))
      return false;
    var tmp = this.r72_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.r72_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.s72_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.s72_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    if (!equals(this.t72_1, tmp0_other_with_cast.t72_1))
      return false;
    return true;
  }
}
class Failed_4 {
  constructor(runId, agentId, threadId, turnId, error) {
    this.k72_1 = runId;
    this.l72_1 = agentId;
    this.m72_1 = threadId;
    this.n72_1 = turnId;
    this.o72_1 = error;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.k72_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.l72_1);
    var tmp_1 = this.m72_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.n72_1;
    return 'Failed(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ', error=' + toString(this.o72_1) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.k72_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.l72_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.m72_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.m72_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.n72_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.n72_1);
    }
    result = tmp_2 + tmp_3 | 0;
    result = imul(result, 31) + hashCode(this.o72_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Failed_4))
      return false;
    var tmp0_other_with_cast = other instanceof Failed_4 ? other : THROW_CCE();
    if (!equals(this.k72_1, tmp0_other_with_cast.k72_1))
      return false;
    if (!(this.l72_1 === tmp0_other_with_cast.l72_1))
      return false;
    var tmp = this.m72_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.m72_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.n72_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.n72_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    if (!equals(this.o72_1, tmp0_other_with_cast.o72_1))
      return false;
    return true;
  }
}
class Cancelled_1 {
  constructor(runId, agentId, threadId, turnId) {
    this.g72_1 = runId;
    this.h72_1 = agentId;
    this.i72_1 = threadId;
    this.j72_1 = turnId;
  }
  toString() {
    var tmp = RunId__toString_impl_q8god7(this.g72_1);
    var tmp_0 = AgentId__toString_impl_gf4an3(this.h72_1);
    var tmp_1 = this.i72_1;
    var tmp_2 = toString_0(tmp_1 == null ? null : new ThreadId(tmp_1));
    var tmp_3 = this.j72_1;
    return 'Cancelled(runId=' + tmp + ', agentId=' + tmp_0 + ', threadId=' + tmp_2 + ', turnId=' + toString_0(tmp_3 == null ? null : new TurnId(tmp_3)) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.g72_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.h72_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.i72_1;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = ThreadId__hashCode_impl_80c5yl(this.i72_1);
    }
    result = tmp + tmp_0 | 0;
    var tmp_2 = imul(result, 31);
    var tmp_3;
    var tmp_4 = this.j72_1;
    if ((tmp_4 == null ? null : new TurnId(tmp_4)) == null) {
      tmp_3 = 0;
    } else {
      tmp_3 = TurnId__hashCode_impl_wbcy6y(this.j72_1);
    }
    result = tmp_2 + tmp_3 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Cancelled_1))
      return false;
    var tmp0_other_with_cast = other instanceof Cancelled_1 ? other : THROW_CCE();
    if (!equals(this.g72_1, tmp0_other_with_cast.g72_1))
      return false;
    if (!(this.h72_1 === tmp0_other_with_cast.h72_1))
      return false;
    var tmp = this.i72_1;
    var tmp_0 = tmp == null ? null : new ThreadId(tmp);
    var tmp_1 = tmp0_other_with_cast.i72_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new ThreadId(tmp_1)))
      return false;
    var tmp_2 = this.j72_1;
    var tmp_3 = tmp_2 == null ? null : new TurnId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.j72_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new TurnId(tmp_4)))
      return false;
    return true;
  }
}
class UnhandledChildFailure {
  constructor(parentRunId, childRunId, childAgentId, error) {
    this.c72_1 = parentRunId;
    this.d72_1 = childRunId;
    this.e72_1 = childAgentId;
    this.f72_1 = error;
  }
  toString() {
    return 'UnhandledChildFailure(parentRunId=' + RunId__toString_impl_q8god7(this.c72_1) + ', childRunId=' + RunId__toString_impl_q8god7(this.d72_1) + ', childAgentId=' + AgentId__toString_impl_gf4an3(this.e72_1) + ', error=' + toString(this.f72_1) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.c72_1);
    result = imul(result, 31) + RunId__hashCode_impl_4harkc(this.d72_1) | 0;
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.e72_1) | 0;
    result = imul(result, 31) + hashCode(this.f72_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof UnhandledChildFailure))
      return false;
    var tmp0_other_with_cast = other instanceof UnhandledChildFailure ? other : THROW_CCE();
    if (!equals(this.c72_1, tmp0_other_with_cast.c72_1))
      return false;
    if (!equals(this.d72_1, tmp0_other_with_cast.d72_1))
      return false;
    if (!(this.e72_1 === tmp0_other_with_cast.e72_1))
      return false;
    if (!equals(this.f72_1, tmp0_other_with_cast.f72_1))
      return false;
    return true;
  }
}
class SideEffectRollback {
  constructor(runId, agentId, threadId, turnId) {
    this.y71_1 = runId;
    this.z71_1 = agentId;
    this.a72_1 = threadId;
    this.b72_1 = turnId;
  }
  toString() {
    return 'SideEffectRollback(runId=' + RunId__toString_impl_q8god7(this.y71_1) + ', agentId=' + AgentId__toString_impl_gf4an3(this.z71_1) + ', threadId=' + ThreadId__toString_impl_tri2rg(this.a72_1) + ', turnId=' + TurnId__toString_impl_gyl6zb(this.b72_1) + ')';
  }
  hashCode() {
    var result = RunId__hashCode_impl_4harkc(this.y71_1);
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.z71_1) | 0;
    result = imul(result, 31) + ThreadId__hashCode_impl_80c5yl(this.a72_1) | 0;
    result = imul(result, 31) + TurnId__hashCode_impl_wbcy6y(this.b72_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SideEffectRollback))
      return false;
    var tmp0_other_with_cast = other instanceof SideEffectRollback ? other : THROW_CCE();
    if (!equals(this.y71_1, tmp0_other_with_cast.y71_1))
      return false;
    if (!(this.z71_1 === tmp0_other_with_cast.z71_1))
      return false;
    if (!(this.a72_1 === tmp0_other_with_cast.a72_1))
      return false;
    if (!equals(this.b72_1, tmp0_other_with_cast.b72_1))
      return false;
    return true;
  }
}
class Retrying {
  constructor(runId, agentId, agentName, threadId, turnId, attempt, delayMillis) {
    this.r71_1 = runId;
    this.s71_1 = agentId;
    this.t71_1 = agentName;
    this.u71_1 = threadId;
    this.v71_1 = turnId;
    this.w71_1 = attempt;
    this.x71_1 = delayMillis;
  }
  toString() {
    var tmp = this.r71_1;
    var tmp_0 = toString_0(tmp == null ? null : new RunId(tmp));
    var tmp_1 = AgentId__toString_impl_gf4an3(this.s71_1);
    var tmp_2 = this.u71_1;
    var tmp_3 = toString_0(tmp_2 == null ? null : new ThreadId(tmp_2));
    var tmp_4 = this.v71_1;
    return 'Retrying(runId=' + tmp_0 + ', agentId=' + tmp_1 + ', agentName=' + this.t71_1 + ', threadId=' + tmp_3 + ', turnId=' + toString_0(tmp_4 == null ? null : new TurnId(tmp_4)) + ', attempt=' + this.w71_1 + ', delayMillis=' + this.x71_1.toString() + ')';
  }
  hashCode() {
    var tmp;
    var tmp_0 = this.r71_1;
    if ((tmp_0 == null ? null : new RunId(tmp_0)) == null) {
      tmp = 0;
    } else {
      tmp = RunId__hashCode_impl_4harkc(this.r71_1);
    }
    var result = tmp;
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.s71_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.t71_1) | 0;
    var tmp_1 = imul(result, 31);
    var tmp_2;
    var tmp_3 = this.u71_1;
    if ((tmp_3 == null ? null : new ThreadId(tmp_3)) == null) {
      tmp_2 = 0;
    } else {
      tmp_2 = ThreadId__hashCode_impl_80c5yl(this.u71_1);
    }
    result = tmp_1 + tmp_2 | 0;
    var tmp_4 = imul(result, 31);
    var tmp_5;
    var tmp_6 = this.v71_1;
    if ((tmp_6 == null ? null : new TurnId(tmp_6)) == null) {
      tmp_5 = 0;
    } else {
      tmp_5 = TurnId__hashCode_impl_wbcy6y(this.v71_1);
    }
    result = tmp_4 + tmp_5 | 0;
    result = imul(result, 31) + this.w71_1 | 0;
    result = imul(result, 31) + this.x71_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Retrying))
      return false;
    var tmp0_other_with_cast = other instanceof Retrying ? other : THROW_CCE();
    var tmp = this.r71_1;
    var tmp_0 = tmp == null ? null : new RunId(tmp);
    var tmp_1 = tmp0_other_with_cast.r71_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new RunId(tmp_1)))
      return false;
    if (!(this.s71_1 === tmp0_other_with_cast.s71_1))
      return false;
    if (!(this.t71_1 === tmp0_other_with_cast.t71_1))
      return false;
    var tmp_2 = this.u71_1;
    var tmp_3 = tmp_2 == null ? null : new ThreadId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.u71_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new ThreadId(tmp_4)))
      return false;
    var tmp_5 = this.v71_1;
    var tmp_6 = tmp_5 == null ? null : new TurnId(tmp_5);
    var tmp_7 = tmp0_other_with_cast.v71_1;
    if (!equals(tmp_6, tmp_7 == null ? null : new TurnId(tmp_7)))
      return false;
    if (!(this.w71_1 === tmp0_other_with_cast.w71_1))
      return false;
    if (!this.x71_1.equals(tmp0_other_with_cast.x71_1))
      return false;
    return true;
  }
}
class CircuitOpen {
  constructor(runId, agentId, agentName, threadId, turnId) {
    this.m71_1 = runId;
    this.n71_1 = agentId;
    this.o71_1 = agentName;
    this.p71_1 = threadId;
    this.q71_1 = turnId;
  }
  toString() {
    var tmp = this.m71_1;
    var tmp_0 = toString_0(tmp == null ? null : new RunId(tmp));
    var tmp_1 = AgentId__toString_impl_gf4an3(this.n71_1);
    var tmp_2 = this.p71_1;
    var tmp_3 = toString_0(tmp_2 == null ? null : new ThreadId(tmp_2));
    var tmp_4 = this.q71_1;
    return 'CircuitOpen(runId=' + tmp_0 + ', agentId=' + tmp_1 + ', agentName=' + this.o71_1 + ', threadId=' + tmp_3 + ', turnId=' + toString_0(tmp_4 == null ? null : new TurnId(tmp_4)) + ')';
  }
  hashCode() {
    var tmp;
    var tmp_0 = this.m71_1;
    if ((tmp_0 == null ? null : new RunId(tmp_0)) == null) {
      tmp = 0;
    } else {
      tmp = RunId__hashCode_impl_4harkc(this.m71_1);
    }
    var result = tmp;
    result = imul(result, 31) + AgentId__hashCode_impl_wutuj6(this.n71_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.o71_1) | 0;
    var tmp_1 = imul(result, 31);
    var tmp_2;
    var tmp_3 = this.p71_1;
    if ((tmp_3 == null ? null : new ThreadId(tmp_3)) == null) {
      tmp_2 = 0;
    } else {
      tmp_2 = ThreadId__hashCode_impl_80c5yl(this.p71_1);
    }
    result = tmp_1 + tmp_2 | 0;
    var tmp_4 = imul(result, 31);
    var tmp_5;
    var tmp_6 = this.q71_1;
    if ((tmp_6 == null ? null : new TurnId(tmp_6)) == null) {
      tmp_5 = 0;
    } else {
      tmp_5 = TurnId__hashCode_impl_wbcy6y(this.q71_1);
    }
    result = tmp_4 + tmp_5 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CircuitOpen))
      return false;
    var tmp0_other_with_cast = other instanceof CircuitOpen ? other : THROW_CCE();
    var tmp = this.m71_1;
    var tmp_0 = tmp == null ? null : new RunId(tmp);
    var tmp_1 = tmp0_other_with_cast.m71_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new RunId(tmp_1)))
      return false;
    if (!(this.n71_1 === tmp0_other_with_cast.n71_1))
      return false;
    if (!(this.o71_1 === tmp0_other_with_cast.o71_1))
      return false;
    var tmp_2 = this.p71_1;
    var tmp_3 = tmp_2 == null ? null : new ThreadId(tmp_2);
    var tmp_4 = tmp0_other_with_cast.p71_1;
    if (!equals(tmp_3, tmp_4 == null ? null : new ThreadId(tmp_4)))
      return false;
    var tmp_5 = this.q71_1;
    var tmp_6 = tmp_5 == null ? null : new TurnId(tmp_5);
    var tmp_7 = tmp0_other_with_cast.q71_1;
    if (!equals(tmp_6, tmp_7 == null ? null : new TurnId(tmp_7)))
      return false;
    return true;
  }
}
class RuntimeMetrics {
  constructor(total, created, threadQueued, ready, running, waiting, suspended, committing, finished, failed, cancelled, totalTokens, totalSteps, totalToolCalls) {
    this.a77_1 = total;
    this.b77_1 = created;
    this.c77_1 = threadQueued;
    this.d77_1 = ready;
    this.e77_1 = running;
    this.f77_1 = waiting;
    this.g77_1 = suspended;
    this.h77_1 = committing;
    this.i77_1 = finished;
    this.j77_1 = failed;
    this.k77_1 = cancelled;
    this.l77_1 = totalTokens;
    this.m77_1 = totalSteps;
    this.n77_1 = totalToolCalls;
  }
  toString() {
    return 'RuntimeMetrics(total=' + this.a77_1 + ', created=' + this.b77_1 + ', threadQueued=' + this.c77_1 + ', ready=' + this.d77_1 + ', running=' + this.e77_1 + ', waiting=' + this.f77_1 + ', suspended=' + this.g77_1 + ', committing=' + this.h77_1 + ', finished=' + this.i77_1 + ', failed=' + this.j77_1 + ', cancelled=' + this.k77_1 + ', totalTokens=' + this.l77_1 + ', totalSteps=' + this.m77_1 + ', totalToolCalls=' + this.n77_1 + ')';
  }
  hashCode() {
    var result = this.a77_1;
    result = imul(result, 31) + this.b77_1 | 0;
    result = imul(result, 31) + this.c77_1 | 0;
    result = imul(result, 31) + this.d77_1 | 0;
    result = imul(result, 31) + this.e77_1 | 0;
    result = imul(result, 31) + this.f77_1 | 0;
    result = imul(result, 31) + this.g77_1 | 0;
    result = imul(result, 31) + this.h77_1 | 0;
    result = imul(result, 31) + this.i77_1 | 0;
    result = imul(result, 31) + this.j77_1 | 0;
    result = imul(result, 31) + this.k77_1 | 0;
    result = imul(result, 31) + this.l77_1 | 0;
    result = imul(result, 31) + this.m77_1 | 0;
    result = imul(result, 31) + this.n77_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RuntimeMetrics))
      return false;
    var tmp0_other_with_cast = other instanceof RuntimeMetrics ? other : THROW_CCE();
    if (!(this.a77_1 === tmp0_other_with_cast.a77_1))
      return false;
    if (!(this.b77_1 === tmp0_other_with_cast.b77_1))
      return false;
    if (!(this.c77_1 === tmp0_other_with_cast.c77_1))
      return false;
    if (!(this.d77_1 === tmp0_other_with_cast.d77_1))
      return false;
    if (!(this.e77_1 === tmp0_other_with_cast.e77_1))
      return false;
    if (!(this.f77_1 === tmp0_other_with_cast.f77_1))
      return false;
    if (!(this.g77_1 === tmp0_other_with_cast.g77_1))
      return false;
    if (!(this.h77_1 === tmp0_other_with_cast.h77_1))
      return false;
    if (!(this.i77_1 === tmp0_other_with_cast.i77_1))
      return false;
    if (!(this.j77_1 === tmp0_other_with_cast.j77_1))
      return false;
    if (!(this.k77_1 === tmp0_other_with_cast.k77_1))
      return false;
    if (!(this.l77_1 === tmp0_other_with_cast.l77_1))
      return false;
    if (!(this.m77_1 === tmp0_other_with_cast.m77_1))
      return false;
    if (!(this.n77_1 === tmp0_other_with_cast.n77_1))
      return false;
    return true;
  }
}
class Inherit {
  toString() {
    return 'Inherit';
  }
  hashCode() {
    return -2083693771;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Inherit))
      return false;
    other instanceof Inherit || THROW_CCE();
    return true;
  }
}
class Ephemeral {
  toString() {
    return 'Ephemeral';
  }
  hashCode() {
    return 1145814359;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Ephemeral))
      return false;
    other instanceof Ephemeral || THROW_CCE();
    return true;
  }
}
class Thread {
  constructor(id) {
    this.u6x_1 = id;
  }
  toString() {
    return 'Thread(id=' + ThreadId__toString_impl_tri2rg(this.u6x_1) + ')';
  }
  hashCode() {
    return ThreadId__hashCode_impl_80c5yl(this.u6x_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Thread))
      return false;
    var tmp0_other_with_cast = other instanceof Thread ? other : THROW_CCE();
    if (!(this.u6x_1 === tmp0_other_with_cast.u6x_1))
      return false;
    return true;
  }
}
class ChildFailurePolicy extends Enum {}
class InstanceActivityGate$Branch$run$slambda$slambda {
  constructor(this$0, this$1) {
    this.o77_1 = this$0;
    this.p77_1 = this$1;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_43.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class InstanceActivityGate$Branch$run$slambda {
  constructor($block, this$0, this$1) {
    this.s77_1 = $block;
    this.t77_1 = this$0;
    this.u77_1 = this$1;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_44.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class Key_0 {}
class BranchState extends Enum {}
class BranchRecord {
  constructor(state, waitDepth) {
    waitDepth = waitDepth === VOID ? 0 : waitDepth;
    this.x77_1 = state;
    this.y77_1 = waitDepth;
  }
  toString() {
    return 'BranchRecord(state=' + this.x77_1.toString() + ', waitDepth=' + this.y77_1 + ')';
  }
  hashCode() {
    var result = this.x77_1.hashCode();
    result = imul(result, 31) + this.y77_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof BranchRecord))
      return false;
    var tmp0_other_with_cast = other instanceof BranchRecord ? other : THROW_CCE();
    if (!this.x77_1.equals(tmp0_other_with_cast.x77_1))
      return false;
    if (!(this.y77_1 === tmp0_other_with_cast.y77_1))
      return false;
    return true;
  }
}
class Branch {
  constructor($outer, id) {
    this.r77_1 = $outer;
    this.q77_1 = id;
  }
  l5w(block, $completion) {
    var tmp = new BranchTag(this.q77_1);
    return withContext(tmp, InstanceActivityGate$Branch$run$slambda_0(block, this.r77_1, this), $completion);
  }
}
class BranchTag extends AbstractCoroutineContextElement {
  constructor(id) {
    super(Key_instance_0);
    this.a78_1 = id;
  }
}
class SlotLease {}
class NoopLease {
  b78($completion) {
  }
  c78($completion) {
  }
}
class InstanceActivityGate$waiting$slambda {
  constructor(this$0, $id) {
    this.v77_1 = this$0;
    this.w77_1 = $id;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_45.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class InstanceActivityGate extends AgentExecutionContext {
  constructor(runId, acb, emit, onSideEffect) {
    var tmp;
    if (onSideEffect === VOID) {
      tmp = InstanceActivityGate$_init_$lambda_k8xejg;
    } else {
      tmp = onSideEffect;
    }
    onSideEffect = tmp;
    super();
    this.e6s_1 = runId;
    this.f6s_1 = acb;
    this.g6s_1 = emit;
    this.h6s_1 = onSideEffect;
    var tmp_0 = this;
    // Inline function 'kotlin.let' call
    var snapshot = this.f6s_1.w6q();
    var tmp_1 = _RunId___get_value__impl__30zeiv(this.e6s_1).toString();
    var tmp_2 = _AgentId___get_value__impl__1mym7n(snapshot.y6q_1);
    var tmp0_safe_receiver = snapshot.a6r_1;
    var tmp_3;
    var tmp_4 = tmp0_safe_receiver;
    if ((tmp_4 == null ? null : new ThreadId(tmp_4)) == null) {
      tmp_3 = null;
    } else {
      tmp_3 = _ThreadId___get_value__impl__tytyxc(tmp0_safe_receiver);
    }
    var tmp_5 = tmp_3;
    var tmp1_safe_receiver = snapshot.b6r_1;
    var tmp_6;
    var tmp_7 = tmp1_safe_receiver;
    if ((tmp_7 == null ? null : new TurnId(tmp_7)) == null) {
      tmp_6 = null;
    } else {
      tmp_6 = _TurnId___get_value__impl__w6r3h9(tmp1_safe_receiver);
    }
    var tmp2_safe_receiver = tmp_6;
    tmp_0.i6s_1 = new ExecutionIdentity(tmp_1, tmp_2, tmp_5, tmp2_safe_receiver == null ? null : tmp2_safe_receiver.toString(), snapshot.f6r_1);
    this.j6s_1 = Mutex();
    this.k6s_1 = HashMap.l8();
    this.l6s_1 = new Long(0, 0);
    this.m6s_1 = 0;
    this.n6s_1 = NoopLease_instance;
    var tmp0 = this.k6s_1;
    var _unary__edvuaz = this.l6s_1;
    this.l6s_1 = _unary__edvuaz.z3();
    // Inline function 'kotlin.collections.set' call
    var value = new BranchRecord(BranchState_RUNNABLE_getInstance());
    tmp0.k3(_unary__edvuaz, value);
    this.m6s_1 = 1;
  }
  c5s() {
    return this.i6s_1;
  }
  o6s(l, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_attachLease__qxpozj.bind(VOID, this, l), $completion);
  }
  a5s($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_enterWaiting__jsjsyb.bind(VOID, this), $completion);
  }
  b5s($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_leaveWaiting__c8ig4y.bind(VOID, this), $completion);
  }
  d5s(block, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_waiting__s4e4jr_0.bind(VOID, this, block), $completion);
  }
  e5s($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_forkBranch__qr9t6k.bind(VOID, this), $completion);
  }
  f5s() {
    return this.h6s_1();
  }
}
class Companion_43 {
  constructor() {
    Companion_instance_45 = this;
    this.l71_1 = new Quota();
  }
}
class Quota {
  constructor(maxSteps, maxToolCalls, wallClockMillis) {
    Companion_getInstance_49();
    maxSteps = maxSteps === VOID ? null : maxSteps;
    maxToolCalls = maxToolCalls === VOID ? null : maxToolCalls;
    wallClockMillis = wallClockMillis === VOID ? null : wallClockMillis;
    this.t6v_1 = maxSteps;
    this.u6v_1 = maxToolCalls;
    this.v6v_1 = wallClockMillis;
  }
}
class AccessMode extends Enum {}
class ResourceRegistry {
  constructor() {
    this.d78_1 = Mutex();
    this.e78_1 = HashMap.l8();
  }
  f78(id, mode, block, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_withResource__nj2v70.bind(VOID, this, id, mode, block), $completion);
  }
}
class Key_1 {}
class RuntimeContext extends AbstractCoroutineContextElement {
  constructor(resources, runId, agentId, threadId, turnId, correlationId, ipc, context, spawner) {
    super(Key_instance_1);
    this.h78_1 = resources;
    this.i78_1 = runId;
    this.j78_1 = agentId;
    this.k78_1 = threadId;
    this.l78_1 = turnId;
    this.m78_1 = correlationId;
    this.n78_1 = ipc;
    this.o78_1 = context;
    this.p78_1 = spawner;
  }
  m6z(agent, input, priority, quota, contextRefs, failurePolicy, conversation) {
    return this.p78_1.m6z(agent, input, priority, quota, contextRefs, failurePolicy, conversation);
  }
}
class withRuntimeResource$slambda {
  constructor($exec, $block) {
    this.q78_1 = $exec;
    this.r78_1 = $block;
  }
  vd($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_46.bind(VOID, this), $completion);
  }
}
class Scheduler$Lease$park$slambda {
  constructor(this$0) {
    this.s78_1 = this$0;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_47.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class Scheduler$Lease$close$slambda {
  constructor(this$0, this$1) {
    this.x78_1 = this$0;
    this.y78_1 = this$1;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_48.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class Waiter {
  constructor(priority, seq, resume) {
    this.b79_1 = priority;
    this.c79_1 = seq;
    this.d79_1 = resume;
    this.e79_1 = CompletableDeferred();
  }
}
class LeaseState extends Enum {}
class Lease {
  constructor($outer, priority) {
    this.w78_1 = $outer;
    this.t78_1 = priority;
    this.u78_1 = Mutex();
    this.v78_1 = LeaseState_HELD_getInstance();
  }
  b78($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_park__qjmv1e.bind(VOID, this), $completion);
  }
  c78($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_unpark__1kn8kb.bind(VOID, this), $completion);
  }
  f79($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_close__nh2uv0.bind(VOID, this), $completion);
  }
}
class sam$kotlin_Comparator$0_0 {
  constructor(function_0) {
    this.g79_1 = function_0;
  }
  vi(a, b) {
    return this.g79_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.g79_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class Scheduler$acquire$slambda {
  constructor(this$0, $waiter) {
    this.z78_1 = this$0;
    this.a79_1 = $waiter;
  }
  r1f($this$withContext, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_49.bind(VOID, this, $this$withContext), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class Scheduler {
  constructor(maxConcurrency) {
    this.p6y_1 = maxConcurrency;
    this.q6y_1 = this.p6y_1 === 2147483647;
    this.r6y_1 = Mutex();
    this.s6y_1 = 0;
    this.t6y_1 = new Long(0, 0);
    this.u6y_1 = ArrayList.k();
  }
  v6y(priority, block, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_withSlot__kr663g.bind(VOID, this, priority, block), $completion);
  }
}
class TaskGraph {
  constructor(nodes) {
    this.v6w_1 = nodes;
  }
}
class TaskGraphBuilder$task$slambda {
  constructor($input) {
    this.i79_1 = $input;
  }
  j79(it, $completion) {
    return this.i79_1;
  }
  td(p1, $completion) {
    return this.j79((!(p1 == null) ? isInterface(p1, KtMap) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class TaskGraphBuilder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.h79_1 = ArrayList.k();
  }
  k79(id, agent, input, priority, dependsOn) {
    return this.l79(id, agent, priority, dependsOn, TaskGraphBuilder$task$slambda_0(input));
  }
  l79(id, agent, priority, dependsOn, input) {
    var tmp0 = this.h79_1;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.none' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.h1();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (element.m6w_1 === id) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    // Inline function 'kotlin.require' call
    if (!tmp$ret$0) {
      var message = 'duplicate task id: ' + id;
      throw IllegalArgumentException.t(toString(message));
    }
    var tmp3 = this.h79_1;
    // Inline function 'kotlin.collections.plusAssign' call
    var element_0 = new TaskNode(id, agent, priority, dependsOn, input);
    tmp3.l(element_0);
  }
  h2o() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.h79_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = item.m6w_1;
      destination.l(tmp$ret$0);
    }
    var ids = toSet(destination);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = this.h79_1.y();
    while (_iterator__ex2g4s_0.z()) {
      var element = _iterator__ex2g4s_0.a1();
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_1 = element.p6w_1.y();
      while (_iterator__ex2g4s_1.z()) {
        var element_0 = _iterator__ex2g4s_1.a1();
        // Inline function 'kotlin.require' call
        if (!ids.v2(element_0)) {
          var message = "task '" + element.m6w_1 + "' depends on unknown task '" + element_0 + "'";
          throw IllegalArgumentException.t(toString(message));
        }
        // Inline function 'kotlin.require' call
        if (!!(element_0 === element.m6w_1)) {
          var message_0 = "task '" + element.m6w_1 + "' cannot depend on itself";
          throw IllegalArgumentException.t(toString(message_0));
        }
      }
    }
    detectCycle(this, this.h79_1);
    return new TaskGraph(toList(this.h79_1));
  }
}
class TaskNode {
  constructor(id, agent, priority, dependsOn, input) {
    this.m6w_1 = id;
    this.n6w_1 = agent;
    this.o6w_1 = priority;
    this.p6w_1 = dependsOn;
    this.q6w_1 = input;
  }
}
class ThreadSnapshot {
  constructor(id, memoryProviderId, participants, activeTurn, queuedTurns) {
    this.m79_1 = id;
    this.n79_1 = memoryProviderId;
    this.o79_1 = participants;
    this.p79_1 = activeTurn;
    this.q79_1 = queuedTurns;
  }
  toString() {
    var tmp = ThreadId__toString_impl_tri2rg(this.m79_1);
    var tmp_0 = MemoryProviderId__toString_impl_kuplzg(this.n79_1);
    var tmp_1 = toString(this.o79_1);
    var tmp_2 = this.p79_1;
    return 'ThreadSnapshot(id=' + tmp + ', memoryProviderId=' + tmp_0 + ', participants=' + tmp_1 + ', activeTurn=' + toString_0(tmp_2 == null ? null : new TurnId(tmp_2)) + ', queuedTurns=' + toString(this.q79_1) + ')';
  }
  hashCode() {
    var result = ThreadId__hashCode_impl_80c5yl(this.m79_1);
    result = imul(result, 31) + MemoryProviderId__hashCode_impl_sf8j6t(this.n79_1) | 0;
    result = imul(result, 31) + hashCode(this.o79_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.p79_1;
    if ((tmp_1 == null ? null : new TurnId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = TurnId__hashCode_impl_wbcy6y(this.p79_1);
    }
    result = tmp + tmp_0 | 0;
    result = imul(result, 31) + hashCode(this.q79_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ThreadSnapshot))
      return false;
    var tmp0_other_with_cast = other instanceof ThreadSnapshot ? other : THROW_CCE();
    if (!(this.m79_1 === tmp0_other_with_cast.m79_1))
      return false;
    if (!(this.n79_1 === tmp0_other_with_cast.n79_1))
      return false;
    if (!equals(this.o79_1, tmp0_other_with_cast.o79_1))
      return false;
    var tmp = this.p79_1;
    var tmp_0 = tmp == null ? null : new TurnId(tmp);
    var tmp_1 = tmp0_other_with_cast.p79_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new TurnId(tmp_1)))
      return false;
    if (!equals(this.q79_1, tmp0_other_with_cast.q79_1))
      return false;
    return true;
  }
}
class ThreadBinding {
  constructor(threadId, provider, initialParticipant, participants, gate) {
    participants = participants === VOID ? MutableStateFlow(setOf_0(new AgentId(initialParticipant))) : participants;
    gate = gate === VOID ? new FifoTurnGate() : gate;
    this.r79_1 = threadId;
    this.s79_1 = provider;
    this.t79_1 = participants;
    this.u79_1 = gate;
    this.v79_1 = Mutex();
    this.w79_1 = MutableStateFlow(null);
  }
  m6y($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_memory__irlkfb.bind(VOID, this), $completion);
  }
  a6() {
    var tmp0_safe_receiver = this.w79_1.n1();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.a6();
    }
    this.w79_1.t1e(null);
  }
}
class TurnReservation {
  constructor(binding, reservation) {
    this.h6y_1 = binding;
    this.i6y_1 = reservation;
  }
  vw($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_await__mos7q6_1.bind(VOID, this), $completion);
  }
  j6y() {
    return this.i6y_1.g2j();
  }
}
class ThreadLease {
  constructor(binding, reservation) {
    this.u6u_1 = binding;
    this.v6u_1 = reservation;
  }
  w6u() {
    return this.u6u_1.r79_1;
  }
  m6y($completion) {
    return this.u6u_1.m6y($completion);
  }
  y6u($completion) {
    this.v6u_1.g2j();
  }
}
class ThreadRegistry {
  constructor(defaultMemoryProvider) {
    this.v6x_1 = defaultMemoryProvider;
    this.w6x_1 = MutableStateFlow(emptyMap());
  }
  x6x(threadId, turnId, agent) {
    var binding = bind(this, threadId, agent);
    return new TurnReservation(binding, binding.u79_1.i7a(turnId));
  }
  k6y(threadId, turnId, agent) {
    var tmp0_elvis_lhs = this.w6x_1.n1().h3(new ThreadId(threadId));
    var tmp;
    if (tmp0_elvis_lhs == null) {
      var message = "thread '" + _ThreadId___get_value__impl__tytyxc(threadId) + "' has no active binding for inherited turn " + _TurnId___get_value__impl__w6r3h9(turnId).toString();
      throw IllegalStateException.t4(toString(message));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var binding = tmp;
    validateProvider(this, threadId, binding.s79_1, agent.v5m_1);
    var tmp_0 = binding.u79_1.j7a();
    // Inline function 'kotlin.check' call
    if (!equals(tmp_0 == null ? null : new TurnId(tmp_0), new TurnId(turnId))) {
      var message_0 = "turn '" + _TurnId___get_value__impl__w6r3h9(turnId).toString() + "' is not active for thread '" + _ThreadId___get_value__impl__tytyxc(threadId) + "'";
      throw IllegalStateException.t4(toString(message_0));
    }
    var tmp2 = binding.t79_1;
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp2.n1();
        var nextValue = plus_2(prevValue, new AgentId(agent.i5m_1));
        if (tmp2.u1e(prevValue, nextValue)) {
          break $l$block;
        }
      }
    }
  }
  a6() {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.w6x_1.n1().j3().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      element.a6();
    }
    this.w6x_1.t1e(emptyMap());
  }
  y70(threadId) {
    var tmp0_safe_receiver = this.w6x_1.n1().h3(new ThreadId(threadId));
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = new ThreadSnapshot(tmp0_safe_receiver.r79_1, tmp0_safe_receiver.s79_1.a5r(), tmp0_safe_receiver.t79_1.n1(), tmp0_safe_receiver.u79_1.j7a(), tmp0_safe_receiver.u79_1.k7a());
    }
    return tmp;
  }
}
class Waiter_0 {
  constructor(turnId, ready) {
    this.l7a_1 = turnId;
    this.m7a_1 = ready;
  }
  toString() {
    return 'Waiter(turnId=' + TurnId__toString_impl_gyl6zb(this.l7a_1) + ', ready=' + toString(this.m7a_1) + ')';
  }
  hashCode() {
    var result = TurnId__hashCode_impl_wbcy6y(this.l7a_1);
    result = imul(result, 31) + hashCode(this.m7a_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Waiter_0))
      return false;
    var tmp0_other_with_cast = other instanceof Waiter_0 ? other : THROW_CCE();
    if (!equals(this.l7a_1, tmp0_other_with_cast.l7a_1))
      return false;
    if (!equals(this.m7a_1, tmp0_other_with_cast.m7a_1))
      return false;
    return true;
  }
}
class GateState {
  constructor(active, queue) {
    active = active === VOID ? null : active;
    queue = queue === VOID ? emptyList() : queue;
    this.n7a_1 = active;
    this.o7a_1 = queue;
  }
  p7a(active, queue) {
    return new GateState(active, queue);
  }
  q7a(active, queue, $super) {
    active = active === VOID ? this.n7a_1 : active;
    queue = queue === VOID ? this.o7a_1 : queue;
    return $super === VOID ? this.p7a(active, queue) : $super.p7a.call(this, active, queue);
  }
  toString() {
    return 'GateState(active=' + toString_0(this.n7a_1) + ', queue=' + toString(this.o7a_1) + ')';
  }
  hashCode() {
    var result = this.n7a_1 == null ? 0 : this.n7a_1.hashCode();
    result = imul(result, 31) + hashCode(this.o7a_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof GateState))
      return false;
    var tmp0_other_with_cast = other instanceof GateState ? other : THROW_CCE();
    if (!equals(this.n7a_1, tmp0_other_with_cast.n7a_1))
      return false;
    if (!equals(this.o7a_1, tmp0_other_with_cast.o7a_1))
      return false;
    return true;
  }
}
class Reservation {
  constructor($outer, waiter) {
    this.y79_1 = $outer;
    this.x79_1 = waiter;
  }
  vw($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_await__mos7q6_2.bind(VOID, this), $completion);
  }
  g2j() {
    while (true) {
      var current = this.y79_1.h7a_1.n1();
      var nextWaiter;
      var tmp;
      if (current.n7a_1 === this.x79_1) {
        nextWaiter = firstOrNull(current.o7a_1);
        tmp = new GateState(nextWaiter, drop(current.o7a_1, 1));
      } else {
        var tmp0 = current.o7a_1;
        var tmp$ret$0;
        $l$block_0: {
          // Inline function 'kotlin.collections.any' call
          var tmp_0;
          if (isInterface(tmp0, Collection)) {
            tmp_0 = tmp0.h1();
          } else {
            tmp_0 = false;
          }
          if (tmp_0) {
            tmp$ret$0 = false;
            break $l$block_0;
          }
          var _iterator__ex2g4s = tmp0.y();
          while (_iterator__ex2g4s.z()) {
            var element = _iterator__ex2g4s.a1();
            if (element === this.x79_1) {
              tmp$ret$0 = true;
              break $l$block_0;
            }
          }
          tmp$ret$0 = false;
        }
        if (tmp$ret$0) {
          nextWaiter = null;
          // Inline function 'kotlin.collections.filterNot' call
          var tmp0_0 = current.o7a_1;
          // Inline function 'kotlin.collections.filterNotTo' call
          var destination = ArrayList.k();
          var _iterator__ex2g4s_0 = tmp0_0.y();
          while (_iterator__ex2g4s_0.z()) {
            var element_0 = _iterator__ex2g4s_0.a1();
            if (!(element_0 === this.x79_1)) {
              destination.l(element_0);
            }
          }
          tmp = current.q7a(VOID, destination);
        } else {
          return Unit_instance;
        }
      }
      var next = tmp;
      if (this.y79_1.h7a_1.u1e(current, next)) {
        var tmp0_safe_receiver = nextWaiter;
        var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m7a_1;
        if (tmp1_safe_receiver == null)
          null;
        else
          tmp1_safe_receiver.z11(Unit_instance);
        return Unit_instance;
      }
    }
  }
}
class FifoTurnGate {
  constructor() {
    this.h7a_1 = MutableStateFlow(new GateState());
  }
  i7a(turnId) {
    var waiter = new Waiter_0(turnId, CompletableDeferred());
    while (true) {
      var current = this.h7a_1.n1();
      var immediate = current.n7a_1 == null;
      var tmp;
      if (immediate) {
        tmp = current.q7a(waiter);
      } else {
        tmp = current.q7a(VOID, plus(current.o7a_1, waiter));
      }
      var next = tmp;
      if (this.h7a_1.u1e(current, next)) {
        if (immediate) {
          waiter.m7a_1.z11(Unit_instance);
        }
        return new Reservation(this, waiter);
      }
    }
  }
  j7a() {
    var tmp0_safe_receiver = this.h7a_1.n1().n7a_1;
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.l7a_1;
  }
  k7a() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.h7a_1.n1().o7a_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = new TurnId(item.l7a_1);
      destination.l(tmp$ret$0);
    }
    return destination;
  }
}
class ThreadMemoryPolicyConflictException extends IllegalStateException {
  static g7a(threadId, existingProviderId, requestedProviderId) {
    var $this = this.t4("thread '" + _ThreadId___get_value__impl__tytyxc(threadId) + "' is bound to memory provider '" + existingProviderId + "', " + ("but '" + requestedProviderId + "' was requested"));
    captureStack($this, $this.f7a_1);
    $this.c7a_1 = threadId;
    $this.d7a_1 = existingProviderId;
    $this.e7a_1 = requestedProviderId;
    return $this;
  }
}
class TurnContext {
  constructor(threadId, turnId, seed) {
    this.c6u_1 = threadId;
    this.d6u_1 = turnId;
    this.e6u_1 = new TurnBuilder(_TurnId___get_value__impl__w6r3h9(this.d6u_1).toString(), seed);
    this.f6u_1 = CompletableDeferred();
    this.g6u_1 = MutableStateFlow(false);
    this.h6u_1 = null;
  }
  n6y(snapshot) {
    // Inline function 'kotlin.check' call
    if (!this.f6u_1.z11(toList(snapshot))) {
      var message = 'history was already published for ' + TurnId__toString_impl_gyl6zb(this.d6u_1);
      throw IllegalStateException.t4(toString(message));
    }
  }
  l6y($completion) {
    return this.f6u_1.vw($completion);
  }
  f5s() {
    this.g6u_1.t1e(true);
  }
  z61() {
    return this.g6u_1.n1();
  }
}
class Param {}
class Companion_44 {
  r7a($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_create__k2snpo.bind(VOID, this), $completion);
  }
}
class NodeSkillFileSystem {
  constructor(fs) {
    this.s7a_1 = fs;
  }
  h6i(path) {
    var tmp = Companion_getInstance_1();
    var tmp_0 = this.s7a_1.realpathSync(path.toString());
    return tmp.a44((!(tmp_0 == null) ? typeof tmp_0 === 'string' : false) ? tmp_0 : THROW_CCE());
  }
  j6i(path) {
    var tmp;
    try {
      var stat = this.s7a_1.lstatSync(path.toString());
      var tmp_0 = stat.isDirectory();
      var tmp_1 = (!(tmp_0 == null) ? typeof tmp_0 === 'boolean' : false) ? tmp_0 : THROW_CCE();
      var tmp_2 = stat.isFile();
      var tmp_3 = (!(tmp_2 == null) ? typeof tmp_2 === 'boolean' : false) ? tmp_2 : THROW_CCE();
      var tmp_4 = stat.size;
      var tmp_5 = numberToLong(isNumber(tmp_4) ? tmp_4 : THROW_CCE());
      var tmp_6 = stat.isSymbolicLink();
      tmp = new SkillFileMetadata(tmp_1, tmp_3, tmp_5, (!(tmp_6 == null) ? typeof tmp_6 === 'boolean' : false) ? tmp_6 : THROW_CCE());
    } catch ($p) {
      var tmp_7;
      if ($p instanceof Error) {
        var failure = $p;
        var tmp_8;
        // Inline function 'kotlin.js.asDynamic' call
        if (failure.code == 'ENOENT') {
          tmp_8 = null;
        } else {
          throw failure;
        }
        tmp_7 = tmp_8;
      } else {
        throw $p;
      }
      tmp = tmp_7;
    }
    return tmp;
  }
  i6i(path) {
    var tmp = this.s7a_1.readdirSync(path.toString());
    var names = (!(tmp == null) ? isArray(tmp) : false) ? tmp : THROW_CCE();
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(names.length);
    var inductionVariable = 0;
    var last = names.length;
    while (inductionVariable < last) {
      var item = names[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      var tmp$ret$0 = path.f44(item);
      destination.l(tmp$ret$0);
    }
    return destination;
  }
  b6i(path) {
    var tmp = this.s7a_1.readFileSync(path.toString(), 'utf8');
    return (!(tmp == null) ? typeof tmp === 'string' : false) ? tmp : THROW_CCE();
  }
}
//endregion
function get_resolvedDescription(_this__u8e3s4) {
  return _this__u8e3s4.g5m_1;
}
function *_generator_invoke__zhh2q8($this, $this$flow, $completion) {
  var tmp = $this.b5n_1.u5m_1.vw($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var prepared = tmp;
  var tmp_0 = initialItems($this.b5n_1, $this.c5n_1, $this.d5n_1);
  var tmp_1 = prepared.l5n_1.o5n($completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  var tmp_2 = emitAll($this$flow, $this.b5n_1.a5n_1.r5n(tmp_0, tmp_1, $this.e5n_1, $this.f5n_1), $completion);
  if (tmp_2 === get_COROUTINE_SUSPENDED())
    tmp_2 = yield tmp_2;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_0($this, $this$flow, $completion) {
  var tmp = $this.s5n_1.u5m_1.vw($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var prepared = tmp;
  var tmp_0 = initialItems($this.s5n_1, $this.t5n_1, $this.u5n_1);
  var tmp_1 = prepared.l5n_1.o5n($completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  var tmp_2 = emitAll($this$flow, $this.s5n_1.a5n_1.y5n(tmp_0, tmp_1, $this.v5n_1, $this.w5n_1, $this.x5n_1), $completion);
  if (tmp_2 === get_COROUTINE_SUSPENDED())
    tmp_2 = yield tmp_2;
  return Unit_instance;
}
function *_generator_prepare__2w4w0d($this, $completion) {
  var tmp = $this.u5m_1.vw($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function initialItems($this, input, context) {
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList.k();
  this_0.c1(context);
  // Inline function 'kotlin.text.isNullOrEmpty' call
  if (!(input == null || charSequenceLength(input) === 0)) {
    this_0.l(Companion_instance_36.z5n(input));
  }
  var items = this_0.w7();
  return applyPrefill($this, items);
}
function applyPrefill($this, items) {
  var tmp = lastOrNull(items);
  var tmp0_elvis_lhs = tmp instanceof Message ? tmp : null;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return items;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var last = tmp_0;
  if (!last.c5o_1.equals(Role_ASSISTANT_getInstance()))
    return items;
  if ($this.l5m_1.l5o().k5o_1.equals(Support_Supported_getInstance()))
    return items;
  return plus(items, Companion_instance_36.z5n('Continue the interrupted assistant reply. Do not repeat text already written.'));
}
function Agent$executeStream$slambda_0(this$0, $input, $context, $turn, $checkpoint) {
  var i = new Agent$executeStream$slambda(this$0, $input, $context, $turn, $checkpoint);
  var l = ($this$flow, $completion) => i.m5o($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function Agent$executeStructuredStream$slambda_0(this$0, $input, $context, $spec, $turn, $checkpoint) {
  var i = new Agent$executeStructuredStream$slambda(this$0, $input, $context, $spec, $turn, $checkpoint);
  var l = ($this$flow, $completion) => i.m5o($this$flow, $completion);
  l.$arity = 1;
  return l;
}
var AgentDefinitionIds_instance;
function AgentDefinitionIds_getInstance() {
  if (AgentDefinitionIds_instance === VOID)
    new AgentDefinitionIds();
  return AgentDefinitionIds_instance;
}
function agent(block) {
  // Inline function 'kotlin.apply' call
  var this_0 = new AgentBuilder();
  block(this_0);
  return this_0.v5p();
}
function toEvent(_this__u8e3s4, callId) {
  var tmp;
  if (_this__u8e3s4 instanceof Success) {
    tmp = new ToolResult(callId, _this__u8e3s4.x5r_1, false);
  } else {
    if (_this__u8e3s4 instanceof Failure) {
      tmp = new ToolResult(callId, _this__u8e3s4.w5r_1.h2(), true);
    } else {
      noWhenBranchMatchedException();
    }
  }
  return tmp;
}
var Key_instance;
function Key_getInstance() {
  return Key_instance;
}
function *_generator_waiting__s4e4jr($this, block, $completion) {
  var tmp = $this.a5s($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    var tmp_0 = block($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    return tmp_0;
  }finally {
    var tmp_1 = $this.b5s($completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
  }
}
function _AgentId___init__impl__m6udbt(value) {
  // Inline function 'kotlin.text.isNotBlank' call
  var this_0 = _AgentId___get_value__impl__1mym7n(value);
  // Inline function 'kotlin.require' call
  if (!!isBlank(this_0)) {
    var message = 'AgentId must not be blank';
    throw IllegalArgumentException.t(toString(message));
  }
  return value;
}
function _AgentId___get_value__impl__1mym7n($this) {
  return $this;
}
function AgentId__toString_impl_gf4an3($this) {
  return _AgentId___get_value__impl__1mym7n($this);
}
function AgentId__hashCode_impl_wutuj6($this) {
  return getStringHashCode($this);
}
function AgentId__equals_impl_gtr9u($this, other) {
  if (!(other instanceof AgentId))
    return false;
  if (!($this === (other instanceof AgentId ? other.l5s_1 : THROW_CCE())))
    return false;
  return true;
}
var Pending_instance;
function Pending_getInstance() {
  return Pending_instance;
}
function *_generator_await__mos7q6($this, $completion) {
  var current = $this.k5n_1.n1();
  if (current instanceof Ready)
    return current.m5s_1;
  else {
    if (current instanceof Failed_0)
      throw current.n5s_1;
    else {
      if (!equals(current, Pending_instance)) {
        noWhenBranchMatchedException();
      }
    }
  }
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.j5n_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    var current_0 = $this.k5n_1.n1();
    var tmp_1;
    if (current_0 instanceof Ready) {
      tmp_1 = current_0.m5s_1;
    } else {
      if (current_0 instanceof Failed_0) {
        throw current_0.n5s_1;
      } else {
        if (equals(current_0, Pending_instance)) {
          var tmp_2 = prepareDefinition($this, $completion);
          if (tmp_2 === get_COROUTINE_SUSPENDED())
            tmp_2 = yield tmp_2;
          tmp_1 = tmp_2;
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
    tmp_0 = tmp_1;
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function *_generator_prepareDefinition__lywl6i($this, $completion) {
  var tmp;
  try {
    var tmp0_safe_receiver = $this.i5n_1;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      var tmp_1 = tmp0_safe_receiver.o5o($completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      tmp_0 = tmp_1;
    }
    var tmp1_elvis_lhs = tmp_0;
    var preparedSkills = tmp1_elvis_lhs == null ? new PreparedSkills(emptyList()) : tmp1_elvis_lhs;
    var tmp_2 = $this.h5n_1.q5s(additionalTools($this, preparedSkills), $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    var definition = new PreparedAgentDefinition($this.g5n_1.u5s(preparedSkills.t5s()), preparedSkills.v5s());
    $this.k5n_1.t1e(new Ready(definition));
    tmp = definition;
  } catch ($p) {
    var tmp_3;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      throw cancelled;
    } else {
      if ($p instanceof AgentFrameworkException) {
        var failure = $p;
        $this.k5n_1.t1e(new Failed_0(failure));
        throw failure;
      } else {
        if ($p instanceof Error) {
          var failure_0 = $p;
          var tmp2_elvis_lhs = failure_0.message;
          var frameworkFailure = AgentFrameworkException.b5t(new PreparationError('agent', 'agent preparation failed: ' + (tmp2_elvis_lhs == null ? 'unknown error' : tmp2_elvis_lhs), failure_0));
          $this.k5n_1.t1e(new Failed_0(frameworkFailure));
          throw frameworkFailure;
        } else {
          throw $p;
        }
      }
    }
  }
  return tmp;
}
function prepareDefinition($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_prepareDefinition__lywl6i.bind(VOID, $this), $completion);
}
function additionalTools($this, _this__u8e3s4) {
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList.k();
  this_0.c1(_this__u8e3s4.c5t());
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!_this__u8e3s4.s5s_1.h1()) {
    this_0.l(new SkillResourceTool(_this__u8e3s4.s5s_1));
  }
  return this_0.w7();
}
function get_CLIENT_ACTION_KINDS() {
  _init_properties_AgentRunner_kt__2nc677();
  return CLIENT_ACTION_KINDS;
}
var CLIENT_ACTION_KINDS;
function *_generator_invoke__zhh2q8_1($this, it, $completion) {
  var tmp = $this.q5t_1.j1a(it, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_2($this, $this$channelFlow, $completion) {
  var tmp = runLoop($this.r5t_1, $this.s5t_1, $this.t5t_1, $this.u5t_1, $this.v5t_1, AgentRunner$stream$slambda$slambda_0($this$channelFlow), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function AgentRunner$stream$slambda$slambda_0($this_channelFlow) {
  var i = new AgentRunner$stream$slambda$slambda($this_channelFlow);
  var l = (it, $completion) => i.w5t(it, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_3($this, event, $completion) {
  $this.x5t_1.o5u(event);
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = $this.y5t_1.p5n_1.o5m_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    element.p5u(event);
  }
  if (event instanceof TextDelta_0) {
    $this.z5t_1._v = true;
    var tmp = runLoop$out($this.c5u_1, $this.y5t_1, $this.d5u_1, new TextDelta(event.g5v_1), $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  } else {
    if (event instanceof ReasoningDelta_0) {
      var tmp_0 = runLoop$out($this.c5u_1, $this.y5t_1, $this.d5u_1, new ReasoningDelta(event.e5v_1), $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
    } else {
      if (event instanceof ToolCallCompleted) {
        var tmp_1 = runLoop$out($this.c5u_1, $this.y5t_1, $this.d5u_1, new ToolCallRequested(event.d5v_1), $completion);
        if (tmp_1 === get_COROUTINE_SUSPENDED())
          tmp_1 = yield tmp_1;
      } else {
        if (event instanceof Finished) {
          var response = event.q5u_1;
          $this.a5u_1._v = response;
          $this.b5u_1._v = $this.b5u_1._v.r5u(response.k5r()).t5u(response.s5u());
          if (response instanceof Failed_3) {
            throw ModelFailure.c5v(response.u5u_1);
          }
        } else {
          $this.y5t_1.q5n_1.z5k(AgentRunner$runLoop$slambda$lambda(event));
        }
      }
    }
  }
  return Unit_instance;
}
function AgentRunner$runLoop$slambda$lambda($event) {
  return () => 'AgentRunner: ignoring model event: ' + toString($event);
}
function *_generator_invoke__zhh2q8_4($this, progress, $completion) {
  var tmp = runLoop$out($this.j5v_1, $this.k5v_1, $this.l5v_1, new ToolProgress($this.i5v_1._v.m5v_1, progress), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_5($this, $completion) {
  var current = {_v: $this.r5v_1};
  var denied = null;
  var entered = 0;
  var tmp;
  try {
    var _iterator__ex2g4s = $this.s5v_1.p5n_1.n5m_1.y();
    hookLoop: while (_iterator__ex2g4s.z()) {
      var hook = _iterator__ex2g4s.a1();
      entered = entered + 1 | 0;
      var tmp_0 = current._v;
      var tmp_1 = $this.t5v_1._v;
      var tmp0_safe_receiver = $this.u5v_1;
      var tmp_2 = hook.x5v(new ToolContext(tmp_0, tmp_1, tmp0_safe_receiver == null ? null : tmp0_safe_receiver.c5s()), $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      var decision = tmp_2;
      if (!equals(decision, Proceed_instance)) {
        if (decision instanceof ProceedWith) {
          current._v = decision.z5v_1.a5w($this.r5v_1.m5v_1);
        } else {
          if (decision instanceof Deny) {
            denied = new Failure(new ToolError(current._v.n5v_1, decision.y5v_1, false));
            break hookLoop;
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
    var tmp1_elvis_lhs = denied;
    var tmp_3;
    if (tmp1_elvis_lhs == null) {
      var tmp_4 = current._v;
      var tmp2_safe_receiver = $this.u5v_1;
      var tmp_5 = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.c5s();
      var tmp_6 = AgentRunner$runLoop$slambda$slambda$slambda$slambda_0(current, $this.v5v_1, $this.s5v_1, $this.w5v_1);
      var tmp_7 = $this.s5v_1.p5n_1.m5m_1.b5w(tmp_4, tmp_5, tmp_6, AgentRunner$runLoop$slambda$slambda$slambda$lambda($this.u5v_1), $completion);
      if (tmp_7 === get_COROUTINE_SUSPENDED())
        tmp_7 = yield tmp_7;
      tmp_3 = tmp_7;
    } else {
      tmp_3 = tmp1_elvis_lhs;
    }
    var outcome = tmp_3;
    var _iterator__ex2g4s_0 = asReversed(take($this.s5v_1.p5n_1.n5m_1, entered)).y();
    while (_iterator__ex2g4s_0.z()) {
      var hook_0 = _iterator__ex2g4s_0.a1();
      var tmp_8 = current._v;
      var tmp_9 = $this.t5v_1._v;
      var tmp3_safe_receiver = $this.u5v_1;
      var tmp_10 = hook_0.c5w(new ToolContext(tmp_8, tmp_9, tmp3_safe_receiver == null ? null : tmp3_safe_receiver.c5s()), outcome, $completion);
      if (tmp_10 === get_COROUTINE_SUSPENDED())
        tmp_10 = yield tmp_10;
      outcome = tmp_10;
    }
    tmp = outcome;
  } catch ($p) {
    var tmp_11;
    if ($p instanceof CancellationException) {
      var c = $p;
      throw c;
    } else {
      if ($p instanceof Error) {
        var t = $p;
        var tmp_12 = current._v.n5v_1;
        var tmp4_elvis_lhs = t.message;
        tmp_11 = new Failure(new ToolError(tmp_12, tmp4_elvis_lhs == null ? 'tool hook failed' : tmp4_elvis_lhs, false, t));
      } else {
        throw $p;
      }
    }
    tmp = tmp_11;
  }
  return tmp;
}
function AgentRunner$runLoop$slambda$slambda$slambda$slambda_0($current, $outputMutex, this$0, $emit) {
  var i = new AgentRunner$runLoop$slambda$slambda$slambda$slambda($current, $outputMutex, this$0, $emit);
  var l = (progress, $completion) => i.d5w(progress, $completion);
  l.$arity = 1;
  return l;
}
function AgentRunner$runLoop$slambda$slambda$slambda$lambda($exec) {
  return () => {
    var tmp0_safe_receiver = $exec;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.f5s();
    }
    return Unit_instance;
  };
}
function *_generator_invoke__zhh2q8_6($this, $this$async, $completion) {
  var body = AgentRunner$runLoop$slambda$slambda$slambda_1($this.f5w_1, $this.g5w_1, $this.h5w_1, $this.i5w_1, $this.j5w_1, $this.k5w_1);
  var tmp;
  if (!($this.e5w_1 == null)) {
    var tmp_0 = $this.e5w_1.l5w(AgentRunner$runLoop$slambda$slambda$slambda_2(body), $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } else {
    var tmp_1 = body($completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    tmp = tmp_1;
  }
  return tmp;
}
function AgentRunner$runLoop$slambda$slambda$slambda_1($call, this$0, $state, $exec, $outputMutex, $emit) {
  var i = new AgentRunner$runLoop$slambda$slambda$slambda($call, this$0, $state, $exec, $outputMutex, $emit);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function AgentRunner$runLoop$slambda$slambda$slambda_2($body) {
  var i = new AgentRunner$runLoop$slambda$slambda$slambda_0($body);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function *_generator_invoke__zhh2q8_7($this, $this$coroutineScope, $completion) {
  var tmp;
  if (!($this.n5w_1 == null)) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = $this.o5w_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp_0 = $this.n5w_1.e5s($completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      var tmp$ret$0 = tmp_0;
      destination.l(tmp$ret$0);
    }
    tmp = destination;
  } else {
    tmp = null;
  }
  var branches = tmp;
  // Inline function 'kotlin.collections.mapIndexed' call
  var this_1 = $this.o5w_1;
  // Inline function 'kotlin.collections.mapIndexedTo' call
  var destination_0 = ArrayList.x(collectionSizeOrDefault(this_1, 10));
  var index = 0;
  var _iterator__ex2g4s_0 = this_1.y();
  while (_iterator__ex2g4s_0.z()) {
    var item_0 = _iterator__ex2g4s_0.a1();
    var _unary__edvuaz = index;
    index = _unary__edvuaz + 1 | 0;
    var i = checkIndexOverflow(_unary__edvuaz);
    var branch = branches == null ? null : branches.f1(i);
    var tmp$ret$3 = async($this$coroutineScope, VOID, VOID, AgentRunner$runLoop$slambda$slambda_1(branch, item_0, $this.p5w_1, $this.q5w_1, $this.n5w_1, $this.r5w_1, $this.s5w_1));
    destination_0.l(tmp$ret$3);
  }
  var deferreds = destination_0;
  var tmp_1;
  if (!($this.n5w_1 == null)) {
    var tmp_2 = $this.n5w_1.d5s(AgentRunner$runLoop$slambda$slambda_2(deferreds), $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    tmp_1 = tmp_2;
  } else {
    var tmp_3 = awaitAll(deferreds, $completion);
    if (tmp_3 === get_COROUTINE_SUSPENDED())
      tmp_3 = yield tmp_3;
    tmp_1 = tmp_3;
  }
  return tmp_1;
}
function AgentRunner$runLoop$slambda$slambda_1($branch, $call, this$0, $state, $exec, $outputMutex, $emit) {
  var i = new AgentRunner$runLoop$slambda$slambda($branch, $call, this$0, $state, $exec, $outputMutex, $emit);
  var l = ($this$async, $completion) => i.r1f($this$async, $completion);
  l.$arity = 1;
  return l;
}
function AgentRunner$runLoop$slambda$slambda_2($deferreds) {
  var i = new AgentRunner$runLoop$slambda$slambda_0($deferreds);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function *_generator_invoke__zhh2q8_8($this, it, $completion) {
  var tmp = $this.u5w_1.t1c(it, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_9($this, $this$flow, $completion) {
  var tmp = runStructured($this.v5w_1, $this.w5w_1, $this.x5w_1, $this.y5w_1, $this.z5w_1, $this.a5x_1, AgentRunner$streamStructured$slambda$slambda_0($this$flow), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function AgentRunner$streamStructured$slambda$slambda_0($this_flow) {
  var i = new AgentRunner$streamStructured$slambda$slambda($this_flow);
  var l = (it, $completion) => i.w5t(it, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_10($this, event, $completion) {
  // Inline function 'kotlin.collections.plusAssign' call
  $this.b5x_1.l(event);
  var tmp;
  var tmp_0;
  if (event instanceof TextDelta) {
    tmp_0 = true;
  } else {
    tmp_0 = event instanceof ReasoningDelta;
  }
  if (tmp_0) {
    tmp = true;
  } else {
    var tmp_1;
    if (event instanceof Completed) {
      tmp_1 = true;
    } else {
      tmp_1 = event instanceof Incomplete;
    }
    tmp = tmp_1;
  }
  if (!tmp) {
    var tmp_2 = $this.c5x_1(event, $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
  }
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_11($this, event, $completion) {
  $this.d5x_1.o5u(event);
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = $this.e5x_1.p5n_1.o5m_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    element.p5u(event);
  }
  if (event instanceof TextDelta_0) {
    var tmp = emitStructuredEvent($this.e5x_1, new TextDelta(event.g5v_1), $this.f5x_1, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  } else {
    if (event instanceof ReasoningDelta_0) {
      var tmp_0 = emitStructuredEvent($this.e5x_1, new ReasoningDelta(event.e5v_1), $this.f5x_1, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
    } else {
      if (event instanceof Finished) {
        $this.g5x_1._v = event.q5u_1;
        var tmp_1 = event.q5u_1;
        if (tmp_1 instanceof Failed_3) {
          throw ModelFailure.c5v(event.q5u_1.u5u_1);
        }
      }
    }
  }
  return Unit_instance;
}
function *_generator_runLoop__xrsj3v($this, initial, instructions, turn, checkpoint, emit, $completion) {
  var outputMutex = Mutex();
  var state = {_v: new AgentState(initial, instructions, checkpoint, VOID, VOID, VOID, $this.p5n_1.j5m_1)};
  var retries = 0;
  var stepKey = newIdempotencyKey();
  $l$loop_1: while (true) {
    var tmp = terminationDecision($this.p5n_1, state._v, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var decision = tmp;
    if (!equals(decision, Continue_instance)) {
      if (decision instanceof Stop) {
        var tmp_0 = runLoop$out(outputMutex, $this, emit, new Terminated(state._v.i5x(), state._v.x5o_1, decision.j5x_1), $completion);
        if (tmp_0 === get_COROUTINE_SUSPENDED())
          tmp_0 = yield tmp_0;
        return new LoopRun(state._v);
      } else {
        noWhenBranchMatchedException();
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $this.p5n_1.o5m_1.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      element.k5x(state._v);
    }
    var emittedText = {_v: false};
    var terminalResponse = {_v: null};
    try {
      var tmp_1 = modelSource($this, state._v, $this.p5n_1.r5o(state._v, stepKey, Text_instance), ModelCallPhase_Normal_getInstance(), $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      var source = tmp_1;
      var tmp_2 = AgentRunner$runLoop$slambda_1(turn, $this, emittedText, terminalResponse, state, outputMutex, emit);
      var tmp_3 = source.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0(tmp_2), $completion);
      if (tmp_3 === get_COROUTINE_SUSPENDED())
        tmp_3 = yield tmp_3;
    } catch ($p) {
      if ($p instanceof Error) {
        var t = $p;
        var tmp_4;
        if (t instanceof ModelFailure) {
          tmp_4 = t.a5v_1;
        } else {
          if (t instanceof CancellationException) {
            throw t;
          } else {
            tmp_4 = toAgentError(t);
          }
        }
        var error = tmp_4;
        var tmp1_safe_receiver = $this.p5n_1.s5m_1;
        var tmp_5;
        if (tmp1_safe_receiver == null) {
          tmp_5 = null;
        } else {
          var tmp_6 = tmp1_safe_receiver.l5x(error, state._v, $completion);
          if (tmp_6 === get_COROUTINE_SUSPENDED())
            tmp_6 = yield tmp_6;
          tmp_5 = tmp_6;
        }
        var tmp2_elvis_lhs = tmp_5;
        var recovery = tmp2_elvis_lhs == null ? $this.p5n_1.r5m_1.m5x(error, state._v) : tmp2_elvis_lhs;
        var r = recovery;
        if (r instanceof Retry) {
          if (!emittedText._v && retries < r.r5x_1) {
            retries = retries + 1 | 0;
            Companion_getInstance();
            // Inline function 'kotlin.time.Companion.milliseconds' call
            var this_0 = r.q5x_1;
            var tmp$ret$2 = toDuration(this_0, DurationUnit_MILLISECONDS_getInstance());
            var tmp_7 = delay(tmp$ret$2, $completion);
            if (tmp_7 === get_COROUTINE_SUSPENDED())
              tmp_7 = yield tmp_7;
            continue $l$loop_1;
          }
          var tmp_8 = runLoop$out(outputMutex, $this, emit, new Failed(error, state._v.x5o_1), $completion);
          if (tmp_8 === get_COROUTINE_SUSPENDED())
            tmp_8 = yield tmp_8;
          return new LoopRun(state._v);
        } else {
          if (r instanceof Substitute) {
            state._v = state._v.o5x(r.n5x_1);
            turn.p5x(r.n5x_1);
            continue $l$loop_1;
          } else {
            if (r instanceof Propagate) {
              var tmp_9 = runLoop$out(outputMutex, $this, emit, new Failed(error, state._v.x5o_1), $completion);
              if (tmp_9 === get_COROUTINE_SUSPENDED())
                tmp_9 = yield tmp_9;
              return new LoopRun(state._v);
            } else {
              noWhenBranchMatchedException();
            }
          }
        }
      } else {
        throw $p;
      }
    }
    retries = 0;
    stepKey = newIdempotencyKey();
    var tmp4 = terminalResponse._v;
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (tmp4 == null) {
        var message = 'model stream ended without a terminal response';
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp$ret$4 = tmp4;
        break $l$block;
      }
    }
    var response = tmp$ret$4;
    var modelOutput = turn.s5x(response);
    state._v = state._v.t5x(modelOutput);
    // Inline function 'kotlin.collections.filterIsInstance' call
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s_0 = modelOutput.y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      if (element_0 instanceof Message) {
        destination.l(element_0);
      }
    }
    var tmp$ret$8;
    $l$block_0: {
      // Inline function 'kotlin.collections.lastOrNull' call
      var iterator = destination.i1(destination.b1());
      while (iterator.p6()) {
        var element_1 = iterator.r6();
        if (element_1.c5o_1.equals(Role_ASSISTANT_getInstance())) {
          tmp$ret$8 = element_1;
          break $l$block_0;
        }
      }
      tmp$ret$8 = null;
    }
    var tmp3_elvis_lhs = tmp$ret$8;
    var assistant = tmp3_elvis_lhs == null ? turn.u5x() : tmp3_elvis_lhs;
    var tmp_10 = runLoop$out(outputMutex, $this, emit, new StepCompleted(state._v.v5x()), $completion);
    if (tmp_10 === get_COROUTINE_SUSPENDED())
      tmp_10 = yield tmp_10;
    if (response instanceof Incomplete_2) {
      var tmp_11 = runLoop$out(outputMutex, $this, emit, new Incomplete(assistant, state._v.x5o_1, response.x5x_1), $completion);
      if (tmp_11 === get_COROUTINE_SUSPENDED())
        tmp_11 = yield tmp_11;
      return new LoopRun(state._v);
    }
    // Inline function 'kotlin.collections.filterIsInstance' call
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination_0 = ArrayList.k();
    var _iterator__ex2g4s_1 = modelOutput.y();
    while (_iterator__ex2g4s_1.z()) {
      var element_2 = _iterator__ex2g4s_1.a1();
      if (element_2 instanceof ToolCall) {
        destination_0.l(element_2);
      }
    }
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_1 = ArrayList.x(collectionSizeOrDefault(destination_0, 10));
    var _iterator__ex2g4s_2 = destination_0.y();
    while (_iterator__ex2g4s_2.z()) {
      var item = _iterator__ex2g4s_2.a1();
      var tmp$ret$11 = toDispatchCall(item);
      destination_1.l(tmp$ret$11);
    }
    var calls = destination_1;
    var tmp_12 = dispatchClientActions($this, modelOutput, $completion);
    if (tmp_12 === get_COROUTINE_SUSPENDED())
      tmp_12 = yield tmp_12;
    var actionResults = tmp_12;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!actionResults.h1()) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_3 = actionResults.y();
      while (_iterator__ex2g4s_3.z()) {
        var element_3 = _iterator__ex2g4s_3.a1();
        turn.p5x(element_3);
      }
      state._v = state._v.b5y(actionResults);
    }
    if (calls.h1() && actionResults.h1()) {
      var tmp_13 = runLoop$out(outputMutex, $this, emit, new Completed(assistant, state._v.x5o_1), $completion);
      if (tmp_13 === get_COROUTINE_SUSPENDED())
        tmp_13 = yield tmp_13;
      return new LoopRun(state._v);
    }
    if (calls.h1()) {
      continue $l$loop_1;
    }
    // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
    // Inline function 'kotlin.js.getCoroutineContext' call
    var exec = $completion.lc().yc(Key_instance);
    var tmp_14 = coroutineScope(AgentRunner$runLoop$slambda_2(exec, calls, $this, state, outputMutex, emit), $completion);
    if (tmp_14 === get_COROUTINE_SUSPENDED())
      tmp_14 = yield tmp_14;
    var outcomes = tmp_14;
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var _iterator__ex2g4s_4 = outcomes.y();
    while (_iterator__ex2g4s_4.z()) {
      var item_0 = _iterator__ex2g4s_4.a1();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var i = checkIndexOverflow(_unary__edvuaz);
      var ev = toEvent(item_0, calls.f1(i).m5v_1);
      var tmp_15 = runLoop$out(outputMutex, $this, emit, ev, $completion);
      if (tmp_15 === get_COROUTINE_SUSPENDED())
        tmp_15 = yield tmp_15;
      if (item_0 instanceof Failure) {
        var tmp_16 = runLoop$out(outputMutex, $this, emit, new Failed(item_0.w5r_1, state._v.x5o_1), $completion);
        if (tmp_16 === get_COROUTINE_SUSPENDED())
          tmp_16 = yield tmp_16;
      }
    }
    state._v = state._v.c5y(calls, outcomes);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_5 = takeLast(state._v.s5o_1, calls.b1()).y();
    while (_iterator__ex2g4s_5.z()) {
      var element_4 = _iterator__ex2g4s_5.a1();
      turn.p5x(element_4);
    }
    var tmp$ret$24;
    $l$block_1: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s_6 = outcomes.y();
      while (_iterator__ex2g4s_6.z()) {
        var element_5 = _iterator__ex2g4s_6.a1();
        var tmp_17;
        if (element_5 instanceof Success) {
          tmp_17 = element_5.y5r_1;
        } else {
          tmp_17 = false;
        }
        if (tmp_17) {
          tmp$ret$24 = element_5;
          break $l$block_1;
        }
      }
      tmp$ret$24 = null;
    }
    var tmp4_safe_receiver = tmp$ret$24;
    if (tmp4_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var output = (tmp4_safe_receiver instanceof Success ? tmp4_safe_receiver : THROW_CCE()).x5r_1;
      var message_0 = Companion_instance_36.m5t(output);
      state._v = state._v.o5x(message_0);
      turn.p5x(message_0);
      var tmp_18 = runLoop$out(outputMutex, $this, emit, new Completed(message_0, state._v.x5o_1), $completion);
      if (tmp_18 === get_COROUTINE_SUSPENDED())
        tmp_18 = yield tmp_18;
      return new LoopRun(state._v);
    }
  }
}
function runLoop($this, initial, instructions, turn, checkpoint, emit, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_runLoop__xrsj3v.bind(VOID, $this, initial, instructions, turn, checkpoint, emit), $completion);
}
function resultFrom($this, events) {
  // Inline function 'kotlin.collections.filterIsInstance' call
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = events.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (!(element == null) ? isInterface(element, Terminal) : false) {
      destination.l(element);
    }
  }
  var terminal = lastOrNull(destination);
  if (terminal instanceof Completed)
    return new Completed_0(terminal.l5r_1, terminal.m5r_1);
  else {
    if (terminal instanceof Incomplete)
      return new Incomplete_0(terminal.n5r_1, terminal.o5r_1, terminal.p5r_1);
    else {
      if (terminal instanceof Terminated)
        return new Terminated_0(terminal.q5r_1, terminal.r5r_1, terminal.s5r_1);
      else {
        if (terminal != null) {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  // Inline function 'kotlin.collections.filterIsInstance' call
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination_0 = ArrayList.k();
  var _iterator__ex2g4s_0 = events.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    if (element_0 instanceof Failed) {
      destination_0.l(element_0);
    }
  }
  var failed = lastOrNull(destination_0);
  var tmp1_elvis_lhs = failed == null ? null : failed.u5r_1;
  var tmp = tmp1_elvis_lhs == null ? new ModelError('agent run ended without a terminal event', false) : tmp1_elvis_lhs;
  var tmp3_elvis_lhs = failed == null ? null : failed.v5r_1;
  return new Failed_1(tmp, tmp3_elvis_lhs == null ? Companion_getInstance_43().t5r_1 : tmp3_elvis_lhs);
}
function *_generator_runStructured__srdzi0($this, initial, instructions, spec, turn, checkpoint, emit, $completion) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var events = ArrayList.k();
  var tmp = runLoop($this, initial, instructions, turn, checkpoint, AgentRunner$runStructured$slambda_1(events, emit), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var loop = tmp;
  var base = resultFrom($this, events);
  if (!(base instanceof Completed_0))
    return base;
  var format = structuredFormat($this, spec);
  var tmp_0;
  if (format instanceof JsonSchema) {
    tmp_0 = null;
  } else {
    tmp_0 = Companion_instance_36.z5n("Return ONLY a JSON value matching this schema for '" + spec.e5y_1 + "', with no prose or code fences:\n" + spec.d5y_1.toString());
  }
  var formatInstruction = tmp_0;
  var convo = plus_0(loop.h5x_1.s5o_1, listOfNotNull(formatInstruction));
  if (formatInstruction == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    turn.p5x(formatInstruction);
  }
  var finalizationState = loop.h5x_1.f5y(convo);
  var request = $this.p5n_1.r5o(finalizationState, newIdempotencyKey(), format).m5y(VOID, VOID, emptyList());
  var finalizationResponse = {_v: null};
  try {
    var tmp_1 = modelSource($this, finalizationState, request, ModelCallPhase_StructuredFinalization_getInstance(), $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    var tmp_2 = AgentRunner$runStructured$slambda_2(turn, $this, emit, finalizationResponse);
    var tmp_3 = tmp_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_0(tmp_2), $completion);
    if (tmp_3 === get_COROUTINE_SUSPENDED())
      tmp_3 = yield tmp_3;
  } catch ($p) {
    if ($p instanceof CancellationException) {
      var c = $p;
      throw c;
    } else {
      if ($p instanceof Error) {
        var t = $p;
        var tmp_4;
        if (t instanceof ModelFailure) {
          tmp_4 = t.a5v_1;
        } else {
          tmp_4 = toAgentError(t);
        }
        var error = tmp_4;
        var tmp1_safe_receiver = finalizationResponse._v;
        var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.k5r();
        var usage = base.e5t_1.s5y(tmp2_elvis_lhs == null ? Companion_getInstance_43().t5r_1 : tmp2_elvis_lhs);
        var tmp_5 = emitStructuredEvent($this, new Failed(error, usage), emit, $completion);
        if (tmp_5 === get_COROUTINE_SUSPENDED())
          tmp_5 = yield tmp_5;
        return new Failed_1(error, usage);
      } else {
        throw $p;
      }
    }
  }
  var tmp2 = finalizationResponse._v;
  var tmp$ret$4;
  $l$block: {
    // Inline function 'kotlin.checkNotNull' call
    if (tmp2 == null) {
      var message = 'structured model stream ended without a terminal response';
      throw IllegalStateException.t4(toString(message));
    } else {
      tmp$ret$4 = tmp2;
      break $l$block;
    }
  }
  var finalResponse = tmp$ret$4;
  // Inline function 'kotlin.collections.filterIsInstance' call
  var tmp0 = turn.s5x(finalResponse);
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = tmp0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element instanceof Message) {
      destination.l(element);
    }
  }
  var tmp$ret$8;
  $l$block_0: {
    // Inline function 'kotlin.collections.lastOrNull' call
    var iterator = destination.i1(destination.b1());
    while (iterator.p6()) {
      var element_0 = iterator.r6();
      if (element_0.c5o_1.equals(Role_ASSISTANT_getInstance())) {
        tmp$ret$8 = element_0;
        break $l$block_0;
      }
    }
    tmp$ret$8 = null;
  }
  var tmp3_elvis_lhs = tmp$ret$8;
  var finalAssistant = tmp3_elvis_lhs == null ? turn.u5x() : tmp3_elvis_lhs;
  var usage_0 = base.e5t_1.s5y(finalResponse.k5r());
  var tmp_6 = emitStructuredEvent($this, new StepCompleted(loop.h5x_1.v5x() + 1 | 0), emit, $completion);
  if (tmp_6 === get_COROUTINE_SUSPENDED())
    tmp_6 = yield tmp_6;
  if (finalResponse instanceof Incomplete_2) {
    var tmp_7 = emitStructuredEvent($this, new Incomplete(finalAssistant, usage_0, finalResponse.x5x_1), emit, $completion);
    if (tmp_7 === get_COROUTINE_SUSPENDED())
      tmp_7 = yield tmp_7;
    return new Incomplete_0(finalAssistant, usage_0, finalResponse.x5x_1);
  }
  var message_0 = Companion_instance_36.m5t(finalAssistant.f5t());
  var tmp_8 = formatInstruction == null ? null : formatInstruction.a5o_1;
  turn.t5y(message_0, setOfNotNull(tmp_8 == null ? null : new ItemRef(tmp_8)));
  var tmp_9 = emitStructuredEvent($this, new Completed(message_0, usage_0), emit, $completion);
  if (tmp_9 === get_COROUTINE_SUSPENDED())
    tmp_9 = yield tmp_9;
  return new Completed_0(message_0, usage_0);
}
function runStructured($this, initial, instructions, spec, turn, checkpoint, emit, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_runStructured__srdzi0.bind(VOID, $this, initial, instructions, spec, turn, checkpoint, emit), $completion);
}
function structuredFormat($this, spec) {
  var caps = $this.p5n_1.l5m_1.l5o();
  return !caps.j5o_1.equals(Support_Unsupported_getInstance()) ? new JsonSchema(spec.e5y_1, spec.d5y_1) : !caps.i5o_1.equals(Support_Unsupported_getInstance()) ? JsonObject_instance : Text_instance;
}
function *_generator_emitStructuredEvent__gl89du($this, event, emit, $completion) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = $this.p5n_1.o5m_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    element.u5y(event);
  }
  var tmp = emit(event, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function emitStructuredEvent($this, event, emit, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_emitStructuredEvent__gl89du.bind(VOID, $this, event, emit), $completion);
}
function *_generator_modelSource__ujm4nk($this, state, request, phase, $completion) {
  var currentRequest = request;
  var _iterator__ex2g4s = $this.p5n_1.n5m_1.y();
  while (_iterator__ex2g4s.z()) {
    var hook = _iterator__ex2g4s.a1();
    var tmp = hook.v5y(new StepContext(state, currentRequest, phase), $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    currentRequest = tmp;
  }
  var ctx = new StepContext(state, currentRequest, phase);
  var source = $this.p5n_1.l5m_1.w5y(currentRequest);
  var _iterator__ex2g4s_0 = asReversed($this.p5n_1.n5m_1).y();
  while (_iterator__ex2g4s_0.z()) {
    var hook_0 = _iterator__ex2g4s_0.a1();
    source = hook_0.x5y(ctx, source);
  }
  return source;
}
function modelSource($this, state, request, phase, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_modelSource__ujm4nk.bind(VOID, $this, state, request, phase), $completion);
}
function *_generator_dispatchClientActions__uln0ik($this, output, $completion) {
  if ($this.p5n_1.w5m_1.h1())
    return emptyList();
  // Inline function 'kotlin.collections.filterIsInstance' call
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = output.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element instanceof ProviderItem) {
      destination.l(element);
    }
  }
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination_0 = ArrayList.k();
  var _iterator__ex2g4s_0 = destination.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    if (get_CLIENT_ACTION_KINDS().v2(element_0.b5z_1)) {
      destination_0.l(element_0);
    }
  }
  var pending = destination_0;
  if (pending.h1())
    return emptyList();
  // Inline function 'kotlin.collections.mutableListOf' call
  var results = ArrayList.k();
  var _iterator__ex2g4s_1 = pending.y();
  while (_iterator__ex2g4s_1.z()) {
    var item = _iterator__ex2g4s_1.a1();
    var _iterator__ex2g4s_2 = $this.p5n_1.w5m_1.y();
    $l$loop: while (_iterator__ex2g4s_2.z()) {
      var handler = _iterator__ex2g4s_2.a1();
      var tmp = handler.f5z(item, $completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
      var tmp0_elvis_lhs = tmp;
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        continue $l$loop;
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      var handled = tmp_0;
      // Inline function 'kotlin.collections.plusAssign' call
      results.l(handled);
      break $l$loop;
    }
  }
  return results;
}
function dispatchClientActions($this, output, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_dispatchClientActions__uln0ik.bind(VOID, $this, output), $completion);
}
function *_generator_runLoop$out__8xacez(outputMutex, this$0, $emit, event, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var tmp = outputMutex.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this$0.p5n_1.o5m_1.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      element.u5y(event);
    }
    var tmp_0 = $emit(event, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
  }finally {
    outputMutex.n1h(null);
  }
  return Unit_instance;
}
function runLoop$out(outputMutex, this$0, $emit, event, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_runLoop$out__8xacez.bind(VOID, outputMutex, this$0, $emit, event), $completion);
}
function AgentRunner$logger$lambda() {
  return Unit_instance;
}
function AgentRunner$stream$slambda_0(this$0, $initial, $instructions, $turn, $checkpoint) {
  var i = new AgentRunner$stream$slambda(this$0, $initial, $instructions, $turn, $checkpoint);
  var l = ($this$channelFlow, $completion) => i.i5z($this$channelFlow, $completion);
  l.$arity = 1;
  return l;
}
function AgentRunner$runLoop$slambda_1($turn, this$0, $emittedText, $terminalResponse, $state, $outputMutex, $emit) {
  var i = new AgentRunner$runLoop$slambda($turn, this$0, $emittedText, $terminalResponse, $state, $outputMutex, $emit);
  var l = (event, $completion) => i.j5z(event, $completion);
  l.$arity = 1;
  return l;
}
function AgentRunner$runLoop$slambda_2($exec, $calls, this$0, $state, $outputMutex, $emit) {
  var i = new AgentRunner$runLoop$slambda_0($exec, $calls, this$0, $state, $outputMutex, $emit);
  var l = ($this$coroutineScope, $completion) => i.r1f($this$coroutineScope, $completion);
  l.$arity = 1;
  return l;
}
function AgentRunner$streamStructured$slambda_0(this$0, $initial, $instructions, $spec, $turn, $checkpoint) {
  var i = new AgentRunner$streamStructured$slambda(this$0, $initial, $instructions, $spec, $turn, $checkpoint);
  var l = ($this$flow, $completion) => i.m5o($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function AgentRunner$runStructured$slambda_1($events, $emit) {
  var i = new AgentRunner$runStructured$slambda($events, $emit);
  var l = (event, $completion) => i.w5t(event, $completion);
  l.$arity = 1;
  return l;
}
function AgentRunner$runStructured$slambda_2($turn, this$0, $emit, $finalizationResponse) {
  var i = new AgentRunner$runStructured$slambda_0($turn, this$0, $emit, $finalizationResponse);
  var l = (event, $completion) => i.j5z(event, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_terminationDecision__3o5498(_this__u8e3s4, state, $completion) {
  var budgetDecision = _this__u8e3s4.t5m_1.m5z(state);
  var tmp;
  if (equals(budgetDecision, Continue_instance)) {
    var tmp0_safe_receiver = _this__u8e3s4.q5m_1;
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      var tmp_1 = tmp0_safe_receiver.n5z(state, $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      tmp_0 = tmp_1;
    }
    var tmp1_elvis_lhs = tmp_0;
    tmp = tmp1_elvis_lhs == null ? _this__u8e3s4.p5m_1.m5z(state) : tmp1_elvis_lhs;
  } else {
    if (budgetDecision instanceof Stop) {
      tmp = budgetDecision;
    } else {
      noWhenBranchMatchedException();
    }
  }
  return tmp;
}
function terminationDecision(_this__u8e3s4, state, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_terminationDecision__3o5498.bind(VOID, _this__u8e3s4, state), $completion);
}
function toAgentError(_this__u8e3s4) {
  _init_properties_AgentRunner_kt__2nc677();
  var tmp;
  if (_this__u8e3s4 instanceof AgentFrameworkException) {
    tmp = _this__u8e3s4.z5s_1;
  } else {
    if (_this__u8e3s4 instanceof StreamIdleTimeoutException) {
      tmp = new Timeout('model response stream idle', _this__u8e3s4.q5z_1);
    } else {
      var tmp1_elvis_lhs = _this__u8e3s4.message;
      tmp = new ModelError(tmp1_elvis_lhs == null ? 'model call failed' : tmp1_elvis_lhs, false, _this__u8e3s4);
    }
  }
  return tmp;
}
var properties_initialized_AgentRunner_kt_jcfx3v;
function _init_properties_AgentRunner_kt__2nc677() {
  if (!properties_initialized_AgentRunner_kt_jcfx3v) {
    properties_initialized_AgentRunner_kt_jcfx3v = true;
    CLIENT_ACTION_KINDS = setOf(['computer_call', 'mcp_approval_request', 'local_shell_call', 'custom_tool_call']);
  }
}
function *_generator_resolve__ieq9xk($this, $completion) {
  if ($this.n5n_1.h1())
    return null;
  // Inline function 'kotlin.collections.mapNotNull' call
  var tmp0 = $this.n5n_1;
  // Inline function 'kotlin.collections.mapNotNullTo' call
  var destination = ArrayList.k();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = tmp0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp;
    if (element instanceof Static) {
      tmp = element.x5z_1;
    } else {
      if (element instanceof Dynamic) {
        var tmp_0 = element.w5z_1($completion);
        if (tmp_0 === get_COROUTINE_SUSPENDED())
          tmp_0 = yield tmp_0;
        tmp = tmp_0;
      } else {
        noWhenBranchMatchedException();
      }
    }
    var tmp1_safe_receiver = tmp;
    var tmp_1;
    if (tmp1_safe_receiver == null) {
      tmp_1 = null;
    } else {
      // Inline function 'kotlin.takeIf' call
      var tmp_2;
      // Inline function 'kotlin.text.isNotBlank' call
      if (!isBlank(tmp1_safe_receiver)) {
        tmp_2 = tmp1_safe_receiver;
      } else {
        tmp_2 = null;
      }
      tmp_1 = tmp_2;
    }
    var tmp0_safe_receiver = tmp_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      destination.l(tmp0_safe_receiver);
    }
  }
  var parts = destination;
  // Inline function 'kotlin.text.ifBlank' call
  var this_0 = joinToString(parts, '\n\n');
  var tmp_3;
  if (isBlank(this_0)) {
    tmp_3 = null;
  } else {
    tmp_3 = this_0;
  }
  return tmp_3;
}
var Companion_instance_1;
function Companion_getInstance_5() {
  if (Companion_instance_1 === VOID)
    new Companion();
  return Companion_instance_1;
}
function toLanguageModel(_this__u8e3s4) {
  return _this__u8e3s4.r5q();
}
function flushPartialText($this) {
  // Inline function 'kotlin.text.isEmpty' call
  var this_0 = $this.g5u_1;
  if (charSequenceLength(this_0) === 0)
    return Unit_instance;
  var tmp = Companion_instance_36;
  var tmp_0 = $this.g5u_1.toString();
  var tmp0_elvis_lhs = $this.h5u_1;
  var tmp_1;
  var tmp_2 = tmp0_elvis_lhs;
  if ((tmp_2 == null ? null : new ItemRef(tmp_2)) == null) {
    tmp_1 = Companion_instance_32.q60('msg');
  } else {
    tmp_1 = tmp0_elvis_lhs;
  }
  upsert($this, tmp.m5t(tmp_0, tmp_1));
  $this.g5u_1.jh();
  $this.h5u_1 = null;
}
function mergeResponseOutput($this, response) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = response.r60().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    upsert($this, element);
  }
}
function upsert($this, item) {
  var tmp0 = $this.f5u_1;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.indexOfFirst' call
    var index = 0;
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var item_0 = _iterator__ex2g4s.a1();
      if (item_0.s5z() === item.s5z()) {
        tmp$ret$1 = index;
        break $l$block;
      }
      index = index + 1 | 0;
    }
    tmp$ret$1 = -1;
  }
  var index_0 = tmp$ret$1;
  if (index_0 < 0) {
    // Inline function 'kotlin.collections.plusAssign' call
    $this.f5u_1.l(item);
    return Unit_instance;
  }
  var existing = $this.f5u_1.f1(index_0);
  var tmp;
  var tmp_0;
  var tmp_1;
  if (item instanceof Message) {
    tmp_1 = existing instanceof Message;
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = $this.i5u_1.v2(new ItemRef(item.a5o_1));
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = item.s60(VOID, VOID, VOID, existing.d5o_1);
  } else {
    tmp = item;
  }
  $this.f5u_1.c3(index_0, tmp);
}
function TurnBuilder$collapseToFinalAssistant$lambda($dropRefs) {
  return (it) => $dropRefs.v2(new ItemRef(it.s5z()));
}
function *_generator_discover__xd3vwf($this, $completion) {
  var tmp = $this.i61_1.j61($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$0 = new McpToolAdapter(item, $this.i61_1);
    destination.l(tmp$ret$0);
  }
  return destination;
}
function *_generator_ensureInitialized__u31nzy($this, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.h62_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    $l$block: {
      // Inline function 'kotlin.check' call
      if (!!$this.i62_1.n1()) {
        var message = 'MCP client is closed';
        throw IllegalStateException.t4(toString(message));
      }
      if ($this.j62_1) {
        break $l$block;
      }
      var tmp_0 = $this.l62(new InitRequest(VOID, $this.b62_1.k62_1), $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      var initResponse = tmp_0;
      var initError = initResponse.p62_1;
      // Inline function 'kotlin.check' call
      if (!(initError == null)) {
        var tmp1_elvis_lhs = initError == null ? null : initError.r62_1;
        var message_0 = 'MCP client initialization failed: ' + (tmp1_elvis_lhs == null ? 'unknown error' : tmp1_elvis_lhs);
        throw IllegalStateException.t4(toString(message_0));
      }
      var tmp_1 = $this.t62(new InitializedRequest(), $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      $this.j62_1 = true;
      $this.d62_1.b5l(DefaultMcpClient$ensureInitialized$lambda($this));
    }
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function ensureInitialized($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_ensureInitialized__u31nzy.bind(VOID, $this), $completion);
}
function *_generator_initialize__e44cg8($this, request, $completion) {
  var typeAdapter = new TypeAdapter(Companion_instance_8.c3o(), Companion_instance_16.c3o());
  var tmp = $this.f62_1.x62(request, typeAdapter, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  // Inline function 'kotlin.fold' call
  var this_0 = tmp.zr_1;
  var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
  var tmp_0;
  if (exception == null) {
    var tmp_1 = _Result___get_value__impl__bjfvqg(this_0);
    var it = (tmp_1 == null ? true : !(tmp_1 == null)) ? tmp_1 : THROW_CCE();
    if (it.p62_1 == null) {
      $this.d62_1.b5l(DefaultMcpClient$initialize$lambda);
    } else {
      $this.d62_1.d5l(DefaultMcpClient$initialize$lambda_0($this, it));
    }
    tmp_0 = it;
  } else {
    $this.d62_1.d5l(DefaultMcpClient$initialize$lambda_1($this, exception));
    throw exception;
  }
  return tmp_0;
}
function *_generator_initialized__bd2d5s($this, request, $completion) {
  var tmp = $this.f62_1.y62(request, Companion_instance_17.c3o(), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  // Inline function 'kotlin.fold' call
  var this_0 = tmp.zr_1;
  var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
  if (exception == null) {
    var tmp_0 = _Result___get_value__impl__bjfvqg(this_0);
    (tmp_0 == null ? true : !(tmp_0 == null)) || THROW_CCE();
    $this.d62_1.z5k(DefaultMcpClient$initialized$lambda);
  } else {
    $this.d62_1.d5l(DefaultMcpClient$initialized$lambda_0($this, exception));
  }
  return Unit_instance;
}
function *_generator_listTools__xmth8p($this, $completion) {
  var tmp = ensureInitialized($this, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0 = $this.g62_1.e63('tools/list', null, Companion_instance_0.c3o(), Companion_getInstance_25().c3o(), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return tmp_0.f63_1;
}
function *_generator_callTool__hwc8fm($this, name, arguments_0, $completion) {
  var tmp = ensureInitialized($this, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp0_elvis_lhs = arguments_0 instanceof JsonObject ? arguments_0 : null;
  var args = tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  var tmp_0 = $this.g62_1.e63('tools/call', new CallToolParams(name, args), Companion_instance_2.c3o(), Companion_instance_22.c3o(), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return tmp_0;
}
function *_generator_callTool__hwc8fm_0($this, name, argumentsJson, $completion) {
  var tmp;
  if (isBlank(argumentsJson)) {
    tmp = new JsonObject(emptyMap());
  } else {
    var tmp_0 = $this.e62_1.b3m(argumentsJson);
    var tmp0_elvis_lhs = tmp_0 instanceof JsonObject ? tmp_0 : null;
    tmp = tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  }
  var args = tmp;
  var tmp_1 = $this.g63(name, args, $completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  return toString(tmp_1.h63_1);
}
function DefaultMcpClient$logger$lambda() {
  return Unit_instance;
}
function DefaultMcpClient$json$lambda($this$Json) {
  $this$Json.s3m_1 = true;
  $this$Json.t3m_1 = true;
  return Unit_instance;
}
function DefaultMcpClient$ensureInitialized$lambda(this$0) {
  return () => 'MCP client initialized successfully, @' + this$0.a62_1;
}
function DefaultMcpClient$initialize$lambda() {
  return 'mcp server initialized successfully';
}
function DefaultMcpClient$initialize$lambda_0(this$0, $it) {
  return () => '[server internal error] failed to initialize mcp server, url: ' + this$0.a62_1 + ', error:' + toString_0($it.p62_1);
}
function DefaultMcpClient$initialize$lambda_1(this$0, $it) {
  return () => 'failed to initialize mcp server, url: ' + this$0.a62_1 + ', error:' + $it.message;
}
function DefaultMcpClient$initialized$lambda() {
  return 'mcp client initialized successfully';
}
function DefaultMcpClient$initialized$lambda_0(this$0, $it) {
  return () => 'failed to initialized mcp client, url: ' + this$0.a62_1 + ', error:' + $it.message;
}
var Companion_instance_2;
function Companion_getInstance_6() {
  return Companion_instance_2;
}
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance === VOID)
    new $serializer();
  return $serializer_instance;
}
function nextId($this) {
  var tmp0 = $this.d63_1;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.coroutines.flow.getAndUpdate' call
    while (true) {
      var prevValue = tmp0.n1();
      var nextValue = prevValue + 1 | 0;
      if (tmp0.u1e(prevValue, nextValue)) {
        tmp$ret$1 = prevValue;
        break $l$block;
      }
    }
  }
  return tmp$ret$1 + 1 | 0;
}
function *_generator_request__hjt9xh($this, method, params, requestSerializer, responseSerializer, $completion) {
  var tmp = nextId($this);
  var tmp_0;
  if (params == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp_1;
    if (requestSerializer == null) {
      tmp_1 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_1 = $this.c63_1.a3m(requestSerializer, params);
    }
    tmp_0 = tmp_1;
  }
  var req = new RpcEnvelope(VOID, tmp, method, tmp_0);
  var adapter = new TypeAdapter(Companion_instance_23.c3o(), Companion_getInstance_28().o63(responseSerializer));
  var tmp_2 = $this.a63_1.x62(req, adapter, $completion);
  if (tmp_2 === get_COROUTINE_SUSPENDED())
    tmp_2 = yield tmp_2;
  // Inline function 'kotlin.getOrElse' call
  var this_0 = tmp_2.zr_1;
  var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
  var tmp_3;
  if (exception == null) {
    var tmp_4 = _Result___get_value__impl__bjfvqg(this_0);
    tmp_3 = (tmp_4 == null ? true : !(tmp_4 == null)) ? tmp_4 : THROW_CCE();
  } else {
    $this.b63_1.e5l(exception, HttpMcpTransport$request$lambda(method));
    throw exception;
  }
  var response = tmp_3;
  if (!(response.v63_1 == null)) {
    throw RuntimeException.ra('RPC error ' + response.v63_1.p63_1 + ': ' + response.v63_1.q63_1);
  }
  var tmp1_elvis_lhs = response.u63_1;
  var tmp_5;
  if (tmp1_elvis_lhs == null) {
    throw RuntimeException.ra('Empty result for ' + method);
  } else {
    tmp_5 = tmp1_elvis_lhs;
  }
  return tmp_5;
}
function HttpMcpTransport$logger$lambda() {
  return Unit_instance;
}
function HttpMcpTransport$json$lambda($this$Json) {
  $this$Json.s3m_1 = true;
  $this$Json.q3m_1 = true;
  return Unit_instance;
}
function HttpMcpTransport$request$lambda($method) {
  return () => 'request failed: ' + $method;
}
var Companion_instance_3;
function Companion_getInstance_7() {
  return Companion_instance_3;
}
var $serializer_instance_0;
function $serializer_getInstance_0() {
  if ($serializer_instance_0 === VOID)
    new $serializer_0();
  return $serializer_instance_0;
}
var Companion_instance_4;
function Companion_getInstance_8() {
  return Companion_instance_4;
}
var $serializer_instance_1;
function $serializer_getInstance_1() {
  if ($serializer_instance_1 === VOID)
    new $serializer_1();
  return $serializer_instance_1;
}
var Companion_instance_5;
function Companion_getInstance_9() {
  return Companion_instance_5;
}
var $serializer_instance_2;
function $serializer_getInstance_2() {
  if ($serializer_instance_2 === VOID)
    new $serializer_2();
  return $serializer_instance_2;
}
var Companion_instance_6;
function Companion_getInstance_10() {
  return Companion_instance_6;
}
var $serializer_instance_3;
function $serializer_getInstance_3() {
  if ($serializer_instance_3 === VOID)
    new $serializer_3();
  return $serializer_instance_3;
}
var Companion_instance_7;
function Companion_getInstance_11() {
  return Companion_instance_7;
}
var $serializer_instance_4;
function $serializer_getInstance_4() {
  if ($serializer_instance_4 === VOID)
    new $serializer_4();
  return $serializer_instance_4;
}
var Companion_instance_8;
function Companion_getInstance_12() {
  return Companion_instance_8;
}
var $serializer_instance_5;
function $serializer_getInstance_5() {
  if ($serializer_instance_5 === VOID)
    new $serializer_5();
  return $serializer_instance_5;
}
var Companion_instance_9;
function Companion_getInstance_13() {
  return Companion_instance_9;
}
var $serializer_instance_6;
function $serializer_getInstance_6() {
  if ($serializer_instance_6 === VOID)
    new $serializer_6();
  return $serializer_instance_6;
}
var Companion_instance_10;
function Companion_getInstance_14() {
  return Companion_instance_10;
}
var $serializer_instance_7;
function $serializer_getInstance_7() {
  if ($serializer_instance_7 === VOID)
    new $serializer_7();
  return $serializer_instance_7;
}
var Companion_instance_11;
function Companion_getInstance_15() {
  return Companion_instance_11;
}
var $serializer_instance_8;
function $serializer_getInstance_8() {
  if ($serializer_instance_8 === VOID)
    new $serializer_8();
  return $serializer_instance_8;
}
var Companion_instance_12;
function Companion_getInstance_16() {
  return Companion_instance_12;
}
var $serializer_instance_9;
function $serializer_getInstance_9() {
  if ($serializer_instance_9 === VOID)
    new $serializer_9();
  return $serializer_instance_9;
}
var Companion_instance_13;
function Companion_getInstance_17() {
  return Companion_instance_13;
}
var $serializer_instance_10;
function $serializer_getInstance_10() {
  if ($serializer_instance_10 === VOID)
    new $serializer_10();
  return $serializer_instance_10;
}
var Companion_instance_14;
function Companion_getInstance_18() {
  return Companion_instance_14;
}
var $serializer_instance_11;
function $serializer_getInstance_11() {
  if ($serializer_instance_11 === VOID)
    new $serializer_11();
  return $serializer_instance_11;
}
var Companion_instance_15;
function Companion_getInstance_19() {
  return Companion_instance_15;
}
var $serializer_instance_12;
function $serializer_getInstance_12() {
  if ($serializer_instance_12 === VOID)
    new $serializer_12();
  return $serializer_instance_12;
}
var Companion_instance_16;
function Companion_getInstance_20() {
  return Companion_instance_16;
}
var $serializer_instance_13;
function $serializer_getInstance_13() {
  if ($serializer_instance_13 === VOID)
    new $serializer_13();
  return $serializer_instance_13;
}
var Companion_instance_17;
function Companion_getInstance_21() {
  return Companion_instance_17;
}
var $serializer_instance_14;
function $serializer_getInstance_14() {
  if ($serializer_instance_14 === VOID)
    new $serializer_14();
  return $serializer_instance_14;
}
function McpError$Data$Companion$$childSerializers$_anonymous__pzfn0q() {
  return new ArrayListSerializer(StringSerializer_getInstance());
}
var Companion_instance_18;
function Companion_getInstance_22() {
  if (Companion_instance_18 === VOID)
    new Companion_16();
  return Companion_instance_18;
}
var $serializer_instance_15;
function $serializer_getInstance_15() {
  if ($serializer_instance_15 === VOID)
    new $serializer_15();
  return $serializer_instance_15;
}
var Companion_instance_19;
function Companion_getInstance_23() {
  return Companion_instance_19;
}
var $serializer_instance_16;
function $serializer_getInstance_16() {
  if ($serializer_instance_16 === VOID)
    new $serializer_16();
  return $serializer_instance_16;
}
var Companion_instance_20;
function Companion_getInstance_24() {
  return Companion_instance_20;
}
var $serializer_instance_17;
function $serializer_getInstance_17() {
  if ($serializer_instance_17 === VOID)
    new $serializer_17();
  return $serializer_instance_17;
}
function ListToolsResult$Companion$$childSerializers$_anonymous__opdre8() {
  return new ArrayListSerializer($serializer_getInstance_17());
}
var Companion_instance_21;
function Companion_getInstance_25() {
  if (Companion_instance_21 === VOID)
    new Companion_19();
  return Companion_instance_21;
}
var $serializer_instance_18;
function $serializer_getInstance_18() {
  if ($serializer_instance_18 === VOID)
    new $serializer_18();
  return $serializer_instance_18;
}
var Companion_instance_22;
function Companion_getInstance_26() {
  return Companion_instance_22;
}
var $serializer_instance_19;
function $serializer_getInstance_19() {
  if ($serializer_instance_19 === VOID)
    new $serializer_19();
  return $serializer_instance_19;
}
var Companion_instance_23;
function Companion_getInstance_27() {
  return Companion_instance_23;
}
var $serializer_instance_20;
function $serializer_getInstance_20() {
  if ($serializer_instance_20 === VOID)
    new $serializer_20();
  return $serializer_instance_20;
}
var Companion_instance_24;
function Companion_getInstance_28() {
  if (Companion_instance_24 === VOID)
    new Companion_22();
  return Companion_instance_24;
}
var Companion_instance_25;
function Companion_getInstance_29() {
  return Companion_instance_25;
}
var $serializer_instance_21;
function $serializer_getInstance_21() {
  if ($serializer_instance_21 === VOID)
    new $serializer_22();
  return $serializer_instance_21;
}
var TurnRetention_CompletedOnly_instance;
var TurnRetention_Interrupted_instance;
var TurnRetention_InterruptedIfSideEffects_instance;
var TurnRetention_entriesInitialized;
function TurnRetention_initEntries() {
  if (TurnRetention_entriesInitialized)
    return Unit_instance;
  TurnRetention_entriesInitialized = true;
  TurnRetention_CompletedOnly_instance = new TurnRetention('CompletedOnly', 0);
  TurnRetention_Interrupted_instance = new TurnRetention('Interrupted', 1);
  TurnRetention_InterruptedIfSideEffects_instance = new TurnRetention('InterruptedIfSideEffects', 2);
}
var Completed_instance;
function Completed_getInstance() {
  return Completed_instance;
}
var Cancelled_instance;
function Cancelled_getInstance() {
  return Cancelled_instance;
}
var Failed_instance;
function Failed_getInstance() {
  return Failed_instance;
}
function TurnRetention_CompletedOnly_getInstance() {
  TurnRetention_initEntries();
  return TurnRetention_CompletedOnly_instance;
}
function TurnRetention_Interrupted_getInstance() {
  TurnRetention_initEntries();
  return TurnRetention_Interrupted_instance;
}
function TurnRetention_InterruptedIfSideEffects_getInstance() {
  TurnRetention_initEntries();
  return TurnRetention_InterruptedIfSideEffects_instance;
}
function _ThreadId___init__impl__wwh4n0(value) {
  // Inline function 'kotlin.text.isNotBlank' call
  var this_0 = _ThreadId___get_value__impl__tytyxc(value);
  // Inline function 'kotlin.require' call
  if (!!isBlank(this_0)) {
    var message = 'ThreadId must not be blank';
    throw IllegalArgumentException.t(toString(message));
  }
  return value;
}
function _ThreadId___get_value__impl__tytyxc($this) {
  return $this;
}
function ThreadId__toString_impl_tri2rg($this) {
  return 'ThreadId(value=' + $this + ')';
}
function ThreadId__hashCode_impl_80c5yl($this) {
  return getStringHashCode($this);
}
function ThreadId__equals_impl_437u15($this, other) {
  if (!(other instanceof ThreadId))
    return false;
  if (!($this === (other instanceof ThreadId ? other.n68_1 : THROW_CCE())))
    return false;
  return true;
}
function _MemoryProviderId___init__impl__vkxuto(value) {
  // Inline function 'kotlin.text.isNotBlank' call
  var this_0 = _MemoryProviderId___get_value__impl__90yl20(value);
  // Inline function 'kotlin.require' call
  if (!!isBlank(this_0)) {
    var message = 'MemoryProviderId must not be blank';
    throw IllegalArgumentException.t(toString(message));
  }
  return value;
}
function _MemoryProviderId___get_value__impl__90yl20($this) {
  return $this;
}
function MemoryProviderId__toString_impl_kuplzg($this) {
  return 'MemoryProviderId(value=' + $this + ')';
}
function MemoryProviderId__hashCode_impl_sf8j6t($this) {
  return getStringHashCode($this);
}
var NoMemoryProvider_instance;
function NoMemoryProvider_getInstance() {
  if (NoMemoryProvider_instance === VOID)
    new NoMemoryProvider();
  return NoMemoryProvider_instance;
}
function forOnlineUse(_this__u8e3s4, nowEpochMs) {
  nowEpochMs = nowEpochMs === VOID ? System_instance.p53().k5k() : nowEpochMs;
  var repaired = repairTranscript(_this__u8e3s4.v68_1);
  return new MemoryView(repaired, takeIfValidFor(_this__u8e3s4.w68_1, repaired, nowEpochMs));
}
function shouldRetain(turn, retention, sideEffects) {
  var tmp;
  switch (retention.o3_1) {
    case 1:
      tmp = true;
      break;
    case 2:
      var tmp_0;
      var tmp_1 = turn.a68_1;
      if (tmp_1 instanceof Completed_1) {
        tmp_0 = true;
      } else {
        tmp_0 = sideEffects;
      }

      tmp = tmp_0;
      break;
    case 0:
      var tmp_2 = turn.a68_1;
      tmp = tmp_2 instanceof Completed_1;
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
var NoMemory_instance;
function NoMemory_getInstance() {
  return NoMemory_instance;
}
function turnHasSideEffects(turn) {
  var tmp0 = turn.b68_1;
  var tmp$ret$0;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp;
    if (isInterface(tmp0, Collection)) {
      tmp = tmp0.h1();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$0 = false;
      break $l$block_0;
    }
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp_0;
      if (element instanceof ToolResult_0) {
        tmp_0 = !element.c69_1;
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
    }
    tmp$ret$0 = false;
  }
  return tmp$ret$0;
}
var Companion_instance_26;
function Companion_getInstance_30() {
  if (Companion_instance_26 === VOID)
    new Companion_24();
  return Companion_instance_26;
}
function repairTranscript(items) {
  var pending = LinkedHashMap.hc();
  var repaired = null;
  var iterator = items.y();
  var index = 0;
  while (iterator.z()) {
    var index_0 = index;
    index = index + 1 | 0;
    var item = iterator.a1();
    var tmp;
    if (item instanceof Message) {
      // Inline function 'kotlin.collections.isNotEmpty' call
      tmp = !pending.h1();
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp0_elvis_lhs = repaired;
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        // Inline function 'kotlin.also' call
        var this_0 = toMutableList(take(items, index_0));
        repaired = this_0;
        tmp_0 = this_0;
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      var target = tmp_0;
      repairTranscript$flushPending(pending, target);
    }
    if (item instanceof ToolCall) {
      // Inline function 'kotlin.collections.set' call
      var key = new ItemRef(item.d69_1);
      pending.k3(key, item);
    } else {
      if (item instanceof ToolResult_0)
        pending.l3(new ItemRef(item.a69_1));
    }
    var tmp2_safe_receiver = repaired;
    if (tmp2_safe_receiver == null)
      null;
    else
      tmp2_safe_receiver.l(item);
  }
  if (pending.h1()) {
    var tmp3_elvis_lhs = repaired;
    return tmp3_elvis_lhs == null ? items : tmp3_elvis_lhs;
  }
  var tmp4_elvis_lhs = repaired;
  var tmp_1;
  if (tmp4_elvis_lhs == null) {
    // Inline function 'kotlin.also' call
    var this_1 = toMutableList(items);
    repaired = this_1;
    tmp_1 = this_1;
  } else {
    tmp_1 = tmp4_elvis_lhs;
  }
  var target_0 = tmp_1;
  repairTranscript$flushPending(pending, target_0);
  return target_0;
}
function unresolvedCallRefs(items) {
  // Inline function 'kotlin.collections.filterIsInstance' call
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = items.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element instanceof ToolResult_0) {
      destination.l(element);
    }
  }
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList.x(collectionSizeOrDefault(destination, 10));
  var _iterator__ex2g4s_0 = destination.y();
  while (_iterator__ex2g4s_0.z()) {
    var item = _iterator__ex2g4s_0.a1();
    var tmp$ret$2 = new ItemRef(item.a69_1);
    destination_0.l(tmp$ret$2);
  }
  var resolved = toHashSet(destination_0);
  // Inline function 'kotlin.collections.filterIsInstance' call
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination_1 = ArrayList.k();
  var _iterator__ex2g4s_1 = items.y();
  while (_iterator__ex2g4s_1.z()) {
    var element_0 = _iterator__ex2g4s_1.a1();
    if (element_0 instanceof ToolCall) {
      destination_1.l(element_0);
    }
  }
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_2 = ArrayList.x(collectionSizeOrDefault(destination_1, 10));
  var _iterator__ex2g4s_2 = destination_1.y();
  while (_iterator__ex2g4s_2.z()) {
    var item_0 = _iterator__ex2g4s_2.a1();
    var tmp$ret$7 = new ItemRef(item_0.d69_1);
    destination_2.l(tmp$ret$7);
  }
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination_3 = ArrayList.k();
  var _iterator__ex2g4s_3 = destination_2.y();
  while (_iterator__ex2g4s_3.z()) {
    var element_1 = _iterator__ex2g4s_3.a1();
    var it = element_1.b61_1;
    if (!resolved.v2(new ItemRef(it))) {
      destination_3.l(element_1);
    }
  }
  return destination_3;
}
function repairTranscript$flushPending(pending, target) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = pending.j3().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.plusAssign' call
    var element_0 = new ToolResult_0(_ItemRef___init__impl__ipmeex('repair_' + _ItemRef___get_value__impl__fpjuyb(element.d69_1)), VOID, element.d69_1, '<interrupted: not executed>', true);
    target.l(element_0);
  }
  pending.b3();
}
function rejectDroppedRequired($this, original, kept) {
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(kept, 10));
  var _iterator__ex2g4s = kept.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$0 = new ItemRef(item.s5z());
    destination.l(tmp$ret$0);
  }
  var keptRefs = toHashSet(destination);
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination_0 = ArrayList.k();
  var _iterator__ex2g4s_0 = original.y();
  while (_iterator__ex2g4s_0.z()) {
    var element = _iterator__ex2g4s_0.a1();
    var tmp;
    var tmp_0;
    if (!keptRefs.v2(new ItemRef(element.s5z()))) {
      tmp_0 = element instanceof ProviderItem;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = element.d5z_1.equals(ReplayPolicy_Required_getInstance());
    } else {
      tmp = false;
    }
    if (tmp) {
      destination_0.l(element);
    }
  }
  var dropped = destination_0;
  if (dropped.h1())
    return Unit_instance;
  var kinds = joinToString(dropped, VOID, VOID, VOID, VOID, VOID, WindowMemory$Companion$rejectDroppedRequired$lambda);
  throw AgentFrameworkException.b5t(new PreparationError('memory', 'window dropped ReplayPolicy.Required item(s): ' + kinds));
}
function groupIntoTurns($this, items) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var turns = ArrayList.k();
  var _iterator__ex2g4s = items.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    if (isUserTurnBoundary(item) || turns.h1()) {
      // Inline function 'kotlin.collections.plusAssign' call
      var element = mutableListOf([item]);
      turns.l(element);
    } else {
      // Inline function 'kotlin.collections.plusAssign' call
      last(turns).l(item);
    }
  }
  return turns;
}
function WindowMemory$Companion$rejectDroppedRequired$lambda(it) {
  return (it instanceof ProviderItem ? it : THROW_CCE()).b5z_1;
}
function *_generator_load__qllgda($this, query, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.n69_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    tmp_0 = new MemoryView(Companion_instance_27.q69($this.o69_1, $this.l69_1), $this.p69_1);
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function *_generator_commit__is9lbl($this, turn, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.n69_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    if (!shouldRetain(turn, $this.m69_1, turnHasSideEffects(turn)))
      return Unit_instance;
    $this.o69_1.c1(turn.b68_1);
    $this.p69_1 = turn.c68_1;
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
var Companion_instance_27;
function Companion_getInstance_31() {
  return Companion_instance_27;
}
var ModelCallPhase_Normal_instance;
var ModelCallPhase_StructuredFinalization_instance;
var ModelCallPhase_entriesInitialized;
function ModelCallPhase_initEntries() {
  if (ModelCallPhase_entriesInitialized)
    return Unit_instance;
  ModelCallPhase_entriesInitialized = true;
  ModelCallPhase_Normal_instance = new ModelCallPhase('Normal', 0);
  ModelCallPhase_StructuredFinalization_instance = new ModelCallPhase('StructuredFinalization', 1);
}
function ModelCallPhase_Normal_getInstance() {
  ModelCallPhase_initEntries();
  return ModelCallPhase_Normal_instance;
}
function ModelCallPhase_StructuredFinalization_getInstance() {
  ModelCallPhase_initEntries();
  return ModelCallPhase_StructuredFinalization_instance;
}
var Proceed_instance;
function Proceed_getInstance() {
  return Proceed_instance;
}
var Companion_instance_28;
function Companion_getInstance_32() {
  return Companion_instance_28;
}
var CheckpointScope_InRun_instance;
var CheckpointScope_CrossTurn_instance;
var CheckpointScope_entriesInitialized;
function CheckpointScope_initEntries() {
  if (CheckpointScope_entriesInitialized)
    return Unit_instance;
  CheckpointScope_entriesInitialized = true;
  CheckpointScope_InRun_instance = new CheckpointScope('InRun', 0);
  CheckpointScope_CrossTurn_instance = new CheckpointScope('CrossTurn', 1);
}
function takeIfValidFor(_this__u8e3s4, items, nowEpochMs) {
  nowEpochMs = nowEpochMs === VOID ? null : nowEpochMs;
  var tmp;
  if (_this__u8e3s4 == null) {
    return null;
  } else {
    tmp = _this__u8e3s4;
  }
  var checkpoint = tmp;
  var expires = checkpoint.j6b_1;
  if (!(nowEpochMs == null) && !(expires == null) && expires.s1(nowEpochMs) <= 0)
    return null;
  // Inline function 'kotlin.takeIf' call
  var tmp_0;
  if (checkpoint.k6b(items)) {
    tmp_0 = checkpoint;
  } else {
    tmp_0 = null;
  }
  return tmp_0;
}
function writeItem(_this__u8e3s4, item) {
  writeString(_this__u8e3s4, _ItemRef___get_value__impl__fpjuyb(item.s5z()));
  writeNativeId(_this__u8e3s4, item.l6b());
  if (item instanceof Message) {
    writeString(_this__u8e3s4, 'message');
    writeString(_this__u8e3s4, item.c5o_1.n3_1);
    _this__u8e3s4.n43(item.d5o_1.b1());
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = item.d5o_1.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      writeContentPart(_this__u8e3s4, element);
    }
    writeString(_this__u8e3s4, item.e5o_1);
    _this__u8e3s4.n43(item.f5o_1.b1());
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = item.f5o_1.y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      writeAnnotation(_this__u8e3s4, element_0);
    }
  } else {
    if (item instanceof ToolCall) {
      writeString(_this__u8e3s4, 'tool_call');
      writeString(_this__u8e3s4, item.f69_1);
      writeString(_this__u8e3s4, item.g69_1);
      writeNativeId(_this__u8e3s4, item.h69_1);
    } else {
      if (item instanceof ToolResult_0) {
        writeString(_this__u8e3s4, 'tool_result');
        writeString(_this__u8e3s4, _ItemRef___get_value__impl__fpjuyb(item.a69_1));
        writeString(_this__u8e3s4, item.b69_1);
        _this__u8e3s4.m43(item.c69_1 ? 1 : 0);
      } else {
        if (item instanceof ReasoningSummary) {
          writeString(_this__u8e3s4, 'reasoning_summary');
          writeString(_this__u8e3s4, item.o6b_1);
        } else {
          if (item instanceof ProviderItem) {
            writeString(_this__u8e3s4, 'provider_item');
            writeString(_this__u8e3s4, _ProviderId___get_value__impl__xo1tux(item.a5z_1));
            writeString(_this__u8e3s4, item.b5z_1);
            writeString(_this__u8e3s4, item.c5z_1);
            writeString(_this__u8e3s4, item.d5z_1.n3_1);
            writeBytes(_this__u8e3s4, item.e5z_1);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
  }
}
function writeString(_this__u8e3s4, value) {
  if (value == null) {
    _this__u8e3s4.n43(-1);
    return Unit_instance;
  }
  writeBytes(_this__u8e3s4, Companion_getInstance_0().o3z(value));
}
function writeNativeId(_this__u8e3s4, id) {
  var tmp1_safe_receiver = id == null ? null : id.p6b_1;
  var tmp;
  var tmp_0 = tmp1_safe_receiver;
  if ((tmp_0 == null ? null : new ProviderId(tmp_0)) == null) {
    tmp = null;
  } else {
    tmp = _ProviderId___get_value__impl__xo1tux(tmp1_safe_receiver);
  }
  writeString(_this__u8e3s4, tmp);
  writeString(_this__u8e3s4, id == null ? null : id.q6b_1);
}
function writeContentPart(_this__u8e3s4, part) {
  if (part instanceof Text) {
    writeString(_this__u8e3s4, 'text');
    writeString(_this__u8e3s4, part.w6b_1);
  } else {
    if (part instanceof Image) {
      writeString(_this__u8e3s4, 'image');
      writeString(_this__u8e3s4, part.u6b_1);
      writeString(_this__u8e3s4, part.v6b_1);
    } else {
      if (part instanceof Audio) {
        writeString(_this__u8e3s4, 'audio');
        writeString(_this__u8e3s4, part.r6b_1);
        writeString(_this__u8e3s4, part.s6b_1);
        writeString(_this__u8e3s4, part.t6b_1);
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
}
function writeAnnotation(_this__u8e3s4, annotation) {
  if (annotation instanceof UrlCitation) {
    writeString(_this__u8e3s4, 'url_citation');
    writeString(_this__u8e3s4, annotation.r6a_1);
    writeString(_this__u8e3s4, annotation.s6a_1);
    writeNullableInt(_this__u8e3s4, annotation.t6a_1);
    writeNullableInt(_this__u8e3s4, annotation.u6a_1);
  } else {
    if (annotation instanceof FileCitation) {
      writeString(_this__u8e3s4, 'file_citation');
      writeString(_this__u8e3s4, annotation.v6a_1);
      writeString(_this__u8e3s4, annotation.w6a_1);
      writeNullableInt(_this__u8e3s4, annotation.x6a_1);
      writeNullableInt(_this__u8e3s4, annotation.y6a_1);
    } else {
      if (annotation instanceof Generic) {
        writeString(_this__u8e3s4, 'generic');
        writeString(_this__u8e3s4, annotation.z6a_1);
        writeString(_this__u8e3s4, annotation.a6b_1);
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
}
function writeBytes(_this__u8e3s4, value) {
  _this__u8e3s4.n43(value.b1());
  _this__u8e3s4.w40(value);
}
function writeNullableInt(_this__u8e3s4, value) {
  if (value == null) {
    _this__u8e3s4.m43(0);
  } else {
    _this__u8e3s4.m43(1);
    _this__u8e3s4.n43(value);
  }
}
function CheckpointScope_InRun_getInstance() {
  CheckpointScope_initEntries();
  return CheckpointScope_InRun_instance;
}
function CheckpointScope_CrossTurn_getInstance() {
  CheckpointScope_initEntries();
  return CheckpointScope_CrossTurn_instance;
}
var Companion_instance_29;
function Companion_getInstance_33() {
  return Companion_instance_29;
}
var $serializer_instance_22;
function $serializer_getInstance_22() {
  if ($serializer_instance_22 === VOID)
    new $serializer_23();
  return $serializer_instance_22;
}
var Companion_instance_30;
function Companion_getInstance_34() {
  return Companion_instance_30;
}
var $serializer_instance_23;
function $serializer_getInstance_23() {
  if ($serializer_instance_23 === VOID)
    new $serializer_24();
  return $serializer_instance_23;
}
var Companion_instance_31;
function Companion_getInstance_35() {
  return Companion_instance_31;
}
var $serializer_instance_24;
function $serializer_getInstance_24() {
  if ($serializer_instance_24 === VOID)
    new $serializer_25();
  return $serializer_instance_24;
}
function *_generator_invoke__zhh2q8_12($this, event, $completion) {
  var tmp;
  var tmp_0;
  var tmp_1;
  if (event instanceof Finished) {
    var tmp_2 = event.q5u_1;
    tmp_1 = tmp_2 instanceof Failed_3;
  } else {
    tmp_1 = false;
  }
  if (tmp_1) {
    tmp_0 = !$this.g6c_1._v;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = !$this.h6c_1;
  } else {
    tmp = false;
  }
  if (tmp) {
    $this.i6c_1._v = event.q5u_1.u5u_1;
    throw FallbackSignal_getInstance();
  }
  $this.g6c_1._v = true;
  var tmp_3 = $this.j6c_1.t1c(event, $completion);
  if (tmp_3 === get_COROUTINE_SUSPENDED())
    tmp_3 = yield tmp_3;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_13($this, $this$flow, $completion) {
  var lastError = {_v: null};
  var iterator = $this.m6c_1.k6c_1.y();
  var index = 0;
  $l$loop: while (iterator.z()) {
    var index_0 = index;
    index = index + 1 | 0;
    var model = iterator.a1();
    var isLast = index_0 === get_lastIndex($this.m6c_1.k6c_1);
    var emitted = {_v: false};
    var scoped = index_0 === 0 ? $this.n6c_1 : withoutForeignNativeIds($this.n6c_1);
    try {
      var tmp = model.w5y(scoped);
      var tmp_0 = FallbackModel$stream$slambda$slambda_0(emitted, isLast, lastError, $this$flow);
      var tmp_1 = tmp.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_1(tmp_0), $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      return Unit_instance;
    } catch ($p) {
      if ($p instanceof FallbackSignal) {
        var signal = $p;
        continue $l$loop;
      } else {
        if ($p instanceof CancellationException) {
          var ce = $p;
          throw ce;
        } else {
          if ($p instanceof AgentFrameworkException) {
            var afe = $p;
            var tmp_2 = afe.z5s_1;
            var tmp0_elvis_lhs = tmp_2 instanceof ModelError ? tmp_2 : null;
            var error = tmp0_elvis_lhs == null ? new ModelError(afe.z5s_1.h2(), false, afe) : tmp0_elvis_lhs;
            var tmp_3 = $this$flow.t1c(new Finished(new Failed_3(error)), $completion);
            if (tmp_3 === get_COROUTINE_SUSPENDED())
              tmp_3 = yield tmp_3;
            return Unit_instance;
          } else {
            if ($p instanceof Error) {
              var t = $p;
              if (emitted._v || isLast)
                throw t;
              var tmp1_elvis_lhs = t.message;
              lastError._v = new ModelError(tmp1_elvis_lhs == null ? 'model failed before producing output' : tmp1_elvis_lhs, true, t);
            } else {
              throw $p;
            }
          }
        }
      }
    }
  }
  var tmp2_safe_receiver = lastError._v;
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    var tmp_4 = $this$flow.t1c(new Finished(new Failed_3(tmp2_safe_receiver)), $completion);
    if (tmp_4 === get_COROUTINE_SUSPENDED())
      tmp_4 = yield tmp_4;
  }
  return Unit_instance;
}
function FallbackModel$stream$slambda$slambda_0($emitted, $isLast, $lastError, $this_flow) {
  var i = new FallbackModel$stream$slambda$slambda($emitted, $isLast, $lastError, $this_flow);
  var l = (event, $completion) => i.j5z(event, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_abandon__qxshi9($this, responseId, $completion) {
  var tmp = first($this.k6c_1).o6c(responseId, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
var FallbackSignal_instance;
function FallbackSignal_getInstance() {
  if (FallbackSignal_instance === VOID)
    FallbackSignal.q6c();
  return FallbackSignal_instance;
}
function FallbackModel$stream$slambda_0(this$0, $request) {
  var i = new FallbackModel$stream$slambda(this$0, $request);
  var l = ($this$flow, $completion) => i.s6c($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function withoutForeignNativeIds(_this__u8e3s4) {
  // Inline function 'kotlin.collections.filterIsInstance' call
  var tmp0 = _this__u8e3s4.h5y_1;
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = tmp0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element instanceof ProviderItem) {
      destination.l(element);
    }
  }
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination_0 = ArrayList.k();
  var _iterator__ex2g4s_0 = destination.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    if (element_0.d5z_1.equals(ReplayPolicy_Required_getInstance())) {
      destination_0.l(element_0);
    }
  }
  // Inline function 'kotlin.takeIf' call
  var tmp;
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!destination_0.h1()) {
    tmp = destination_0;
  } else {
    tmp = null;
  }
  var tmp0_safe_receiver = tmp;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    throw AgentFrameworkException.b5t(new PreparationError('fallback', 'cannot fall back: ReplayPolicy.Required item(s) ' + joinToString(tmp0_safe_receiver, VOID, VOID, VOID, VOID, VOID, withoutForeignNativeIds$lambda) + ' cannot leave their native provider'));
  }
  // Inline function 'kotlin.collections.mapNotNull' call
  var tmp0_0 = _this__u8e3s4.h5y_1;
  // Inline function 'kotlin.collections.mapNotNullTo' call
  var destination_1 = ArrayList.k();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_1 = tmp0_0.y();
  while (_iterator__ex2g4s_1.z()) {
    var element_1 = _iterator__ex2g4s_1.a1();
    var tmp_0;
    if (element_1 instanceof ProviderItem) {
      tmp_0 = null;
    } else {
      tmp_0 = stripNativeId(element_1);
    }
    var tmp0_safe_receiver_0 = tmp_0;
    if (tmp0_safe_receiver_0 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      destination_1.l(tmp0_safe_receiver_0);
    }
  }
  return _this__u8e3s4.m5y(VOID, destination_1, VOID, VOID, null);
}
function stripNativeId(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof Message) {
    tmp = _this__u8e3s4.s60(VOID, null);
  } else {
    if (_this__u8e3s4 instanceof ToolCall) {
      tmp = _this__u8e3s4.v6c(VOID, null, VOID, VOID, null);
    } else {
      if (_this__u8e3s4 instanceof ToolResult_0) {
        tmp = _this__u8e3s4.u6c(VOID, null);
      } else {
        if (_this__u8e3s4 instanceof ReasoningSummary) {
          tmp = _this__u8e3s4.t6c(VOID, null);
        } else {
          if (_this__u8e3s4 instanceof ProviderItem) {
            tmp = _this__u8e3s4;
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
  }
  return tmp;
}
function withoutForeignNativeIds$lambda(it) {
  return it.b5z_1;
}
function _ItemRef___init__impl__ipmeex(value) {
  // Inline function 'kotlin.text.isNotBlank' call
  var this_0 = _ItemRef___get_value__impl__fpjuyb(value);
  // Inline function 'kotlin.require' call
  if (!!isBlank(this_0)) {
    var message = 'ItemRef must not be blank';
    throw IllegalArgumentException.t(toString(message));
  }
  return value;
}
function _ItemRef___get_value__impl__fpjuyb($this) {
  return $this;
}
var Companion_instance_32;
function Companion_getInstance_36() {
  return Companion_instance_32;
}
function ItemRef__toString_impl_kdmppd($this) {
  return 'ItemRef(value=' + $this + ')';
}
function ItemRef__hashCode_impl_1dj73i($this) {
  return getStringHashCode($this);
}
function ItemRef__equals_impl_csc7m($this, other) {
  if (!(other instanceof ItemRef))
    return false;
  if (!($this === (other instanceof ItemRef ? other.b61_1 : THROW_CCE())))
    return false;
  return true;
}
function _ProviderId___init__impl__nor0vf(value) {
  // Inline function 'kotlin.text.isNotBlank' call
  var this_0 = _ProviderId___get_value__impl__xo1tux(value);
  // Inline function 'kotlin.require' call
  if (!!isBlank(this_0)) {
    var message = 'ProviderId must not be blank';
    throw IllegalArgumentException.t(toString(message));
  }
  return value;
}
function _ProviderId___get_value__impl__xo1tux($this) {
  return $this;
}
var Companion_instance_33;
function Companion_getInstance_37() {
  if (Companion_instance_33 === VOID)
    new Companion_31();
  return Companion_instance_33;
}
var $serializer_instance_25;
function $serializer_getInstance_25() {
  if ($serializer_instance_25 === VOID)
    new $serializer_26();
  return $serializer_instance_25;
}
function ProviderId__toString_impl_hyxggb($this) {
  return 'ProviderId(value=' + $this + ')';
}
function ProviderId__hashCode_impl_vb0opy($this) {
  return getStringHashCode($this);
}
function ProviderId__equals_impl_icthxa($this, other) {
  if (!(other instanceof ProviderId))
    return false;
  if (!($this === (other instanceof ProviderId ? other.f6d_1 : THROW_CCE())))
    return false;
  return true;
}
var Companion_instance_34;
function Companion_getInstance_38() {
  return Companion_instance_34;
}
var $serializer_instance_26;
function $serializer_getInstance_26() {
  if ($serializer_instance_26 === VOID)
    new $serializer_27();
  return $serializer_instance_26;
}
function randomToken() {
  // Inline function 'kotlin.toULong' call
  var this_0 = Default_getInstance().wl();
  var tmp$ret$0 = _ULong___init__impl__c78o9k(this_0);
  var n = toString_1(tmp$ret$0, 16);
  // Inline function 'kotlin.toULong' call
  var this_1 = Default_getInstance().wl();
  var tmp$ret$1 = _ULong___init__impl__c78o9k(this_1);
  var m = toString_1(tmp$ret$1, 16);
  return n + m;
}
function newIdempotencyKey() {
  return 'koaks_' + randomToken();
}
function rawFor(_this__u8e3s4, providerId) {
  var tmp;
  if (_this__u8e3s4 == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.takeIf' call
    var tmp_0;
    if (_this__u8e3s4.p6b_1 === providerId) {
      tmp_0 = _this__u8e3s4;
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  var tmp1_safe_receiver = tmp;
  return tmp1_safe_receiver == null ? null : tmp1_safe_receiver.q6b_1;
}
function *_generator_generate__uwzt8t(_this__u8e3s4, request, $completion) {
  // Inline function 'kotlinx.coroutines.flow.filterIsInstance' call
  // Inline function 'kotlinx.coroutines.flow.filter' call
  // Inline function 'kotlinx.coroutines.flow.unsafeTransform' call
  var this_0 = _this__u8e3s4.w5y(request);
  // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call
  var tmp = new generate$$inlined$filterIsInstance$1(this_0);
  var tmp$ret$3 = isInterface(tmp, Flow) ? tmp : THROW_CCE();
  var tmp_0 = first_0(tmp$ret$3, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return tmp_0.q5u_1;
}
function generate(_this__u8e3s4, request, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_generate__uwzt8t.bind(VOID, _this__u8e3s4, request), $completion);
}
function *_generator_invoke__zhh2q8_14($this, value, $completion) {
  var tmp1 = $this.k6d_1;
  $l$block: {
    if (value instanceof Finished) {
      var tmp = tmp1.t1c(value, $completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
      break $l$block;
    }
  }
  return Unit_instance;
}
function *_generator_collect__dlomyy($this, collector, $completion) {
  var tmp = generate$o$collect$slambda_0(collector);
  var tmp_0 = $this.l6d_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_2(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function generate$o$collect$slambda_0($$this$unsafeFlow) {
  var i = new generate$o$collect$slambda($$this$unsafeFlow);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
var Companion_instance_35;
function Companion_getInstance_39() {
  if (Companion_instance_35 === VOID)
    new Companion_33();
  return Companion_instance_35;
}
function rejectIfUnsupported(_this__u8e3s4, feature, support, path) {
  if (support.s6d()) {
    throw AgentFrameworkException.b5t(new PreparationError('capabilities', feature + ' is not supported by this model (path: ' + path + ')'));
  }
}
function ModelItem$Message$_get_text_$lambda_5ch3ig(it) {
  return it.w6b_1;
}
var Companion_instance_36;
function Companion_getInstance_40() {
  return Companion_instance_36;
}
function isSystem(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof Message) {
    tmp = _this__u8e3s4.c5o_1.equals(Role_SYSTEM_getInstance());
  } else {
    tmp = false;
  }
  return tmp;
}
function isUserTurnBoundary(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof Message) {
    tmp = _this__u8e3s4.c5o_1.equals(Role_USER_getInstance());
  } else {
    tmp = false;
  }
  return tmp;
}
function displayText(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof Message) {
    tmp = _this__u8e3s4.f5t();
  } else {
    if (_this__u8e3s4 instanceof ToolCall) {
      tmp = 'tool call ' + _this__u8e3s4.f69_1 + '(' + _this__u8e3s4.g69_1 + ')';
    } else {
      if (_this__u8e3s4 instanceof ToolResult_0) {
        tmp = _this__u8e3s4.b69_1;
      } else {
        if (_this__u8e3s4 instanceof ReasoningSummary) {
          tmp = _this__u8e3s4.o6b_1;
        } else {
          if (_this__u8e3s4 instanceof ProviderItem) {
            tmp = _this__u8e3s4.c5z_1;
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
  }
  return tmp;
}
var MaxOutputTokens_instance;
function MaxOutputTokens_getInstance() {
  return MaxOutputTokens_instance;
}
var ContentFilter_instance;
function ContentFilter_getInstance() {
  return ContentFilter_instance;
}
var Cancelled_instance_0;
function Cancelled_getInstance_0() {
  return Cancelled_instance_0;
}
var Text_instance;
function Text_getInstance() {
  return Text_instance;
}
var JsonObject_instance;
function JsonObject_getInstance() {
  return JsonObject_instance;
}
var ReplayPolicy_Required_instance;
var ReplayPolicy_Preferred_instance;
var ReplayPolicy_Optional_instance;
function valueOf(value) {
  switch (value) {
    case 'Required':
      return ReplayPolicy_Required_getInstance();
    case 'Preferred':
      return ReplayPolicy_Preferred_getInstance();
    case 'Optional':
      return ReplayPolicy_Optional_getInstance();
    default:
      ReplayPolicy_initEntries();
      THROW_IAE('No enum constant value.');
      break;
  }
}
var ReplayPolicy_entriesInitialized;
function ReplayPolicy_initEntries() {
  if (ReplayPolicy_entriesInitialized)
    return Unit_instance;
  ReplayPolicy_entriesInitialized = true;
  ReplayPolicy_Required_instance = new ReplayPolicy('Required', 0);
  ReplayPolicy_Preferred_instance = new ReplayPolicy('Preferred', 1);
  ReplayPolicy_Optional_instance = new ReplayPolicy('Optional', 2);
}
function ensureDroppable(_this__u8e3s4, target) {
  if (!_this__u8e3s4.d5z_1.equals(ReplayPolicy_Required_getInstance()))
    return Unit_instance;
  throw AgentFrameworkException.b5t(new PreparationError('provider', "cannot translate ReplayPolicy.Required item '" + _this__u8e3s4.b5z_1 + "' onto " + target));
}
function ReplayPolicy_Required_getInstance() {
  ReplayPolicy_initEntries();
  return ReplayPolicy_Required_instance;
}
function ReplayPolicy_Preferred_getInstance() {
  ReplayPolicy_initEntries();
  return ReplayPolicy_Preferred_instance;
}
function ReplayPolicy_Optional_getInstance() {
  ReplayPolicy_initEntries();
  return ReplayPolicy_Optional_instance;
}
function _get_$cachedSerializer__te6jhj($this) {
  return $this.n6e_1.n1();
}
function Role$Companion$_anonymous__n893s7() {
  return createSimpleEnumSerializer('org.koaks.framework.model.Role', values());
}
var Role_SYSTEM_instance;
var Role_USER_instance;
var Role_ASSISTANT_instance;
var Role_TOOL_instance;
function values() {
  return [Role_SYSTEM_getInstance(), Role_USER_getInstance(), Role_ASSISTANT_getInstance(), Role_TOOL_getInstance()];
}
function valueOf_0(value) {
  switch (value) {
    case 'SYSTEM':
      return Role_SYSTEM_getInstance();
    case 'USER':
      return Role_USER_getInstance();
    case 'ASSISTANT':
      return Role_ASSISTANT_getInstance();
    case 'TOOL':
      return Role_TOOL_getInstance();
    default:
      Role_initEntries();
      THROW_IAE('No enum constant value.');
      break;
  }
}
var Companion_instance_37;
function Companion_getInstance_41() {
  Role_initEntries();
  if (Companion_instance_37 === VOID)
    new Companion_35();
  return Companion_instance_37;
}
var Role_entriesInitialized;
function Role_initEntries() {
  if (Role_entriesInitialized)
    return Unit_instance;
  Role_entriesInitialized = true;
  Role_SYSTEM_instance = new Role('SYSTEM', 0);
  Role_USER_instance = new Role('USER', 1);
  Role_ASSISTANT_instance = new Role('ASSISTANT', 2);
  Role_TOOL_instance = new Role('TOOL', 3);
  Companion_getInstance_41();
}
function Role_SYSTEM_getInstance() {
  Role_initEntries();
  return Role_SYSTEM_instance;
}
function Role_USER_getInstance() {
  Role_initEntries();
  return Role_USER_instance;
}
function Role_ASSISTANT_getInstance() {
  Role_initEntries();
  return Role_ASSISTANT_instance;
}
function Role_TOOL_getInstance() {
  Role_initEntries();
  return Role_TOOL_instance;
}
var Support_Supported_instance;
var Support_Unsupported_instance;
var Support_Unknown_instance;
var Support_entriesInitialized;
function Support_initEntries() {
  if (Support_entriesInitialized)
    return Unit_instance;
  Support_entriesInitialized = true;
  Support_Supported_instance = new Support('Supported', 0);
  Support_Unsupported_instance = new Support('Unsupported', 1);
  Support_Unknown_instance = new Support('Unknown', 2);
}
function Support_Supported_getInstance() {
  Support_initEntries();
  return Support_Supported_instance;
}
function Support_Unsupported_getInstance() {
  Support_initEntries();
  return Support_Unsupported_instance;
}
function Support_Unknown_getInstance() {
  Support_initEntries();
  return Support_Unknown_instance;
}
var Companion_instance_38;
function Companion_getInstance_42() {
  return Companion_instance_38;
}
var $serializer_instance_27;
function $serializer_getInstance_27() {
  if ($serializer_instance_27 === VOID)
    new $serializer_28();
  return $serializer_instance_27;
}
function toDispatchCall(_this__u8e3s4) {
  return new ToolCall_0(_ItemRef___get_value__impl__fpjuyb(_this__u8e3s4.d69_1), _this__u8e3s4.f69_1, _this__u8e3s4.g69_1, _this__u8e3s4.e69_1, _this__u8e3s4.h69_1);
}
var Companion_instance_39;
function Companion_getInstance_43() {
  if (Companion_instance_39 === VOID)
    new Companion_37();
  return Companion_instance_39;
}
var $serializer_instance_28;
function $serializer_getInstance_28() {
  if ($serializer_instance_28 === VOID)
    new $serializer_29();
  return $serializer_instance_28;
}
function *_generator_postAsString__w3dwat($this, request, serializer, $completion) {
  // Inline function 'kotlin.runCatching' call
  var tmp;
  try {
    $this.v62_1.z5k(KtorHttpClient$postAsString$lambda($this));
    // Inline function 'io.ktor.client.request.post' call
    var this_0 = $this.w62_1;
    var builder = new HttpRequestBuilder();
    builder.c35_1 = Companion_getInstance_2().c2t_1;
    // Inline function 'io.ktor.client.request.setBody' call
    var body = JsonUtil_getInstance().k6f(request, serializer);
    if (body == null) {
      builder.e35_1 = NullBody_instance;
      // Inline function 'io.ktor.util.reflect.typeInfo' call
      var tmp_0 = PrimitiveClasses_getInstance().ng();
      // Inline function 'io.ktor.util.reflect.typeOfOrNull' call
      var tmp_1;
      try {
        tmp_1 = createKType(PrimitiveClasses_getInstance().ng(), arrayOf([]), false);
      } catch ($p) {
        var tmp_2;
        if ($p instanceof Error) {
          var _unused_var__etf5q3 = $p;
          tmp_2 = null;
        } else {
          throw $p;
        }
        tmp_1 = tmp_2;
      }
      var tmp$ret$0 = tmp_1;
      var tmp$ret$1 = new TypeInfo(tmp_0, tmp$ret$0);
      builder.p39(tmp$ret$1);
    } else {
      if (body instanceof OutgoingContent) {
        builder.e35_1 = body;
        builder.p39(null);
      } else {
        builder.e35_1 = body;
        // Inline function 'io.ktor.util.reflect.typeInfo' call
        var tmp_3 = PrimitiveClasses_getInstance().ng();
        // Inline function 'io.ktor.util.reflect.typeOfOrNull' call
        var tmp_4;
        try {
          tmp_4 = createKType(PrimitiveClasses_getInstance().ng(), arrayOf([]), false);
        } catch ($p) {
          var tmp_5;
          if ($p instanceof Error) {
            var _unused_var__etf5q3_0 = $p;
            tmp_5 = null;
          } else {
            throw $p;
          }
          tmp_4 = tmp_5;
        }
        var tmp$ret$2 = tmp_4;
        var tmp$ret$3 = new TypeInfo(tmp_3, tmp$ret$2);
        builder.p39(tmp$ret$3);
      }
    }
    builder.c35_1 = Companion_getInstance_2().c2t_1;
    // Inline function 'io.ktor.client.request.request' call
    var tmp_6 = (new HttpStatement(builder, this_0)).h3k($completion);
    if (tmp_6 === get_COROUTINE_SUSPENDED())
      tmp_6 = yield tmp_6;
    var response = tmp_6;
    var tmp_7 = bodyAsText(response, VOID, $completion);
    if (tmp_7 === get_COROUTINE_SUSPENDED())
      tmp_7 = yield tmp_7;
    // Inline function 'kotlin.Companion.success' call
    var value = tmp_7;
    tmp = _Result___init__impl__xyqfz8(value);
  } catch ($p) {
    var tmp_8;
    if ($p instanceof Error) {
      var e = $p;
      // Inline function 'kotlin.Companion.failure' call
      tmp_8 = _Result___init__impl__xyqfz8(createFailure(e));
    } else {
      throw $p;
    }
    tmp = tmp_8;
  }
  // Inline function 'kotlin.recoverCatching' call
  var this_1 = tmp;
  var exception = Result__exceptionOrNull_impl_p6xea9(this_1);
  var tmp_9;
  if (exception == null) {
    tmp_9 = this_1;
  } else {
    // Inline function 'kotlin.runCatching' call
    var this_2 = new Result(this_1);
    var tmp_10;
    try {
      this_2.zr_1;
      $this.v62_1.d5l(KtorHttpClient$postAsString$lambda_0(exception));
      throw mapToHttpClientException($this, exception);
    } catch ($p) {
      var tmp_11;
      if ($p instanceof Error) {
        var e_0 = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_11 = _Result___init__impl__xyqfz8(createFailure(e_0));
      } else {
        throw $p;
      }
      tmp_10 = tmp_11;
    }
    tmp_9 = tmp_10;
  }
  var tmp$ret$16 = tmp_9;
  return new Result(tmp$ret$16);
}
function *_generator_postAsObject__z9hk89($this, request, adapter, $completion) {
  var tmp = $this.y62(request, adapter.s6e_1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  // Inline function 'kotlin.mapCatching' call
  var this_0 = tmp.zr_1;
  var tmp_0;
  if (_Result___get_isSuccess__impl__sndoy8(this_0)) {
    // Inline function 'kotlin.runCatching' call
    var this_1 = new Result(this_0);
    var tmp_1;
    try {
      var $this$runCatching = this_1.zr_1;
      var tmp_2 = _Result___get_value__impl__bjfvqg($this$runCatching);
      var jsonString = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
      $this.v62_1.z5k(KtorHttpClient$postAsObject$lambda($this));
      $this.v62_1.z5k(KtorHttpClient$postAsObject$lambda_0(jsonString));
      // Inline function 'kotlin.Companion.success' call
      var value = JsonUtil_getInstance().l6f(jsonString, adapter.t6e_1);
      tmp_1 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_3;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_3 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_1 = tmp_3;
    }
    tmp_0 = tmp_1;
  } else {
    tmp_0 = _Result___init__impl__xyqfz8(_Result___get_value__impl__bjfvqg(this_0));
  }
  var tmp$ret$5 = tmp_0;
  return new Result(tmp$ret$5);
}
function mapToHttpClientException($this, exception) {
  var tmp;
  if (exception instanceof HttpClientException) {
    tmp = exception;
  } else {
    if (exception instanceof JsonParseException) {
      tmp = HttpClientException.i6f('response parsing failed.', exception);
    } else {
      if (exception instanceof SocketTimeoutException) {
        tmp = HttpClientException.i6f('socket timeout.', exception);
      } else {
        if (exception instanceof TimeoutCancellationException) {
          tmp = HttpClientException.i6f('request exceeded callTimeout=' + $this.u62_1.c6f_1.toString() + 's.', exception);
        } else {
          if (exception instanceof IOException) {
            tmp = HttpClientException.i6f('network error.', exception);
          } else {
            tmp = HttpClientException.i6f('unexpected error: ' + exception.message, exception);
          }
        }
      }
    }
  }
  return tmp;
}
function KtorHttpClient$logger$lambda() {
  return Unit_instance;
}
function KtorHttpClient$ktorClient$lambda$lambda$lambda($this_install) {
  return () => 'HttpClient timeout: ' + toString_0($this_install.p3g()) + 'ms,' + ('connectTimeout: ' + toString_0($this_install.w3g()) + 'ms,') + ('readTimeout: ' + toString_0($this_install.x3g()) + 'ms. ');
}
function KtorHttpClient$ktorClient$lambda$lambda(this$0) {
  return ($this$install) => {
    $this$install.t3g(this$0.u62_1.c6f_1.w3(new Long(1000, 0)));
    $this$install.u3g(this$0.u62_1.z6e_1.w3(new Long(1000, 0)));
    $this$install.v3g(this$0.u62_1.b6f_1.w3(new Long(1000, 0)));
    this$0.v62_1.z5k(KtorHttpClient$ktorClient$lambda$lambda$lambda($this$install));
    return Unit_instance;
  };
}
function KtorHttpClient$ktorClient$lambda$lambda_0(this$0) {
  return ($this$defaultRequest) => {
    $this$defaultRequest.x3b(this$0.u62_1.x6e_1);
    contentType($this$defaultRequest, Application_getInstance().k2m_1);
    accept($this$defaultRequest, Application_getInstance().k2m_1);
    var tmp;
    // Inline function 'kotlin.text.isNullOrBlank' call
    var this_0 = this$0.u62_1.y6e_1;
    if (!(this_0 == null || isBlank(this_0))) {
      header($this$defaultRequest, HttpHeaders_getInstance().r2o_1, 'Bearer ' + this$0.u62_1.y6e_1);
      tmp = Unit_instance;
    }
    var tmp_0;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!!this$0.u62_1.e6f_1.h1()) {
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s = this$0.u62_1.e6f_1.l1().y();
      while (_iterator__ex2g4s.z()) {
        var _destruct__k2r9zo = _iterator__ex2g4s.a1();
        // Inline function 'kotlin.collections.component1' call
        var key = _destruct__k2r9zo.m1();
        // Inline function 'kotlin.collections.component2' call
        var value = _destruct__k2r9zo.n1();
        header($this$defaultRequest, key, value);
      }
      tmp_0 = Unit_instance;
    }
    return Unit_instance;
  };
}
function KtorHttpClient$ktorClient$lambda(this$0) {
  return ($this$HttpClient) => {
    var tmp = get_HttpTimeout();
    $this$HttpClient.m36(tmp, KtorHttpClient$ktorClient$lambda$lambda(this$0));
    defaultRequest($this$HttpClient, KtorHttpClient$ktorClient$lambda$lambda_0(this$0));
    return Unit_instance;
  };
}
function KtorHttpClient$postAsString$lambda($$this$runCatching) {
  return () => 'postAsString: ' + $$this$runCatching.u62_1.x6e_1;
}
function KtorHttpClient$postAsString$lambda_0($e) {
  return () => 'postAsString failed: ' + $e.toString();
}
function KtorHttpClient$postAsObject$lambda(this$0) {
  return () => 'postAsObject: ' + this$0.u62_1.x6e_1;
}
function KtorHttpClient$postAsObject$lambda_0($jsonString) {
  return () => 'rawJson: ' + $jsonString;
}
function isRetriable($this, _this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof ModelError) {
    tmp = _this__u8e3s4.y69_1;
  } else {
    if (_this__u8e3s4 instanceof ToolError) {
      tmp = _this__u8e3s4.c6a_1;
    } else {
      if (_this__u8e3s4 instanceof Timeout) {
        tmp = true;
      } else {
        if (_this__u8e3s4 instanceof ParseError) {
          tmp = false;
        } else {
          if (_this__u8e3s4 instanceof ToolNotFound) {
            tmp = false;
          } else {
            if (_this__u8e3s4 instanceof SkillError) {
              tmp = false;
            } else {
              if (_this__u8e3s4 instanceof PreparationError) {
                tmp = false;
              } else {
                tmp = false;
              }
            }
          }
        }
      }
    }
  }
  return tmp;
}
function ErrorPolicy$Companion$PROPAGATE$lambda(_unused_var__etf5q3, _unused_var__etf5q3_0) {
  return Propagate_instance;
}
function ErrorPolicy$Companion$retryRetriable$lambda($delayMs, $maxRetries) {
  return (error, _unused_var__etf5q3) => isRetriable(Companion_getInstance_44(), error) ? new Retry($delayMs, $maxRetries) : Propagate_instance;
}
function ErrorPolicy$Companion$substituteOnError$lambda($fallbackMessage) {
  return (_unused_var__etf5q3, _unused_var__etf5q3_0) => new Substitute($fallbackMessage);
}
var Companion_instance_40;
function Companion_getInstance_44() {
  if (Companion_instance_40 === VOID)
    new Companion_38();
  return Companion_instance_40;
}
var Propagate_instance;
function Propagate_getInstance() {
  return Propagate_instance;
}
var Companion_instance_41;
function Companion_getInstance_45() {
  if (Companion_instance_41 === VOID)
    new Companion_39();
  return Companion_instance_41;
}
function TerminationPolicy$Companion$maxSteps$lambda($n) {
  return (it) => {
    var tmp;
    if (it.v5o_1 >= $n) {
      tmp = new Stop(new MaxSteps($n));
    } else {
      tmp = Continue_instance;
    }
    return tmp;
  };
}
function TerminationPolicy$Companion$maxTokens$lambda($n) {
  return (it) => {
    var tmp;
    if (it.x5o_1.p5y_1 >= $n) {
      tmp = new Stop(new MaxTokens($n));
    } else {
      tmp = Continue_instance;
    }
    return tmp;
  };
}
function TerminationPolicy$Companion$anyOf$lambda($policies) {
  return (state) => {
    var tmp0 = $policies;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.firstNotNullOfOrNull' call
      var inductionVariable = 0;
      var last = tmp0.length;
      while (inductionVariable < last) {
        var element = tmp0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        var decision = element.m5z(state);
        var tmp;
        if (equals(decision, Continue_instance)) {
          tmp = null;
        } else {
          if (decision instanceof Stop) {
            tmp = decision;
          } else {
            noWhenBranchMatchedException();
          }
        }
        var result = tmp;
        if (!(result == null)) {
          tmp$ret$1 = result;
          break $l$block;
        }
      }
      tmp$ret$1 = null;
    }
    var tmp0_elvis_lhs = tmp$ret$1;
    return tmp0_elvis_lhs == null ? Continue_instance : tmp0_elvis_lhs;
  };
}
var Companion_instance_42;
function Companion_getInstance_46() {
  return Companion_instance_42;
}
var Continue_instance;
function Continue_getInstance() {
  return Continue_instance;
}
var Bearer_instance;
function Bearer_getInstance() {
  return Bearer_instance;
}
function *_generator_invoke__zhh2q8_15($this, frame, $completion) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = $this.d6g_1.g6g(frame).y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element instanceof Finished) {
      $this.e6g_1._v = true;
    }
    var tmp = $this.f6g_1.t1c(element, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_16($this, $this$flow, $completion) {
  var decoder = $this.h6g_1.l6g($this.i6g_1);
  var finished = {_v: false};
  try {
    var tmp = $this.h6g_1.m6g($this.i6g_1);
    var tmp_0 = ChatModel$stream$slambda$slambda_0(decoder, finished, $this$flow);
    var tmp_1 = tmp.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_3(tmp_0), $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = decoder.n6g().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element instanceof Finished) {
        finished._v = true;
      }
      var tmp_2 = $this$flow.t1c(element, $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
    }
  } catch ($p) {
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      throw cancelled;
    } else {
      if ($p instanceof Error) {
        var failure = $p;
        if (!finished._v) {
          var tmp_3 = $this$flow.t1c(new Finished(new Failed_3(toModelError(failure))), $completion);
          if (tmp_3 === get_COROUTINE_SUSPENDED())
            tmp_3 = yield tmp_3;
          finished._v = true;
        } else {
          throw failure;
        }
      } else {
        throw $p;
      }
    }
  }
  if (!finished._v) {
    var tmp_4 = $this$flow.t1c(new Finished(new Failed_3(new ModelError('model stream ended without a terminal response', false))), $completion);
    if (tmp_4 === get_COROUTINE_SUSPENDED())
      tmp_4 = yield tmp_4;
  }
  return Unit_instance;
}
function ChatModel$stream$slambda$slambda_0($decoder, $finished, $this_flow) {
  var i = new ChatModel$stream$slambda$slambda($decoder, $finished, $this_flow);
  var l = (frame, $completion) => i.o6g(frame, $completion);
  l.$arity = 1;
  return l;
}
function ChatModel$stream$slambda_0(this$0, $request) {
  var i = new ChatModel$stream$slambda(this$0, $request);
  var l = ($this$flow, $completion) => i.s6c($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function toModelError(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof AgentFrameworkException) {
    var tmp_0 = _this__u8e3s4.z5s_1;
    var tmp1_elvis_lhs = tmp_0 instanceof ModelError ? tmp_0 : null;
    tmp = tmp1_elvis_lhs == null ? new ModelError(_this__u8e3s4.z5s_1.h2(), false, _this__u8e3s4) : tmp1_elvis_lhs;
  } else {
    var tmp2_elvis_lhs = _this__u8e3s4.message;
    tmp = new ModelError(tmp2_elvis_lhs == null ? 'model call failed' : tmp2_elvis_lhs, false, _this__u8e3s4);
  }
  return tmp;
}
function authHeaders(_this__u8e3s4) {
  // Inline function 'kotlin.collections.buildMap' call
  // Inline function 'kotlin.collections.buildMapInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = LinkedHashMap.hc();
  var _iterator__ex2g4s = _this__u8e3s4.x6g_1.b6g(_this__u8e3s4.v6g_1).y();
  while (_iterator__ex2g4s.z()) {
    var _destruct__k2r9zo = _iterator__ex2g4s.a1();
    var k = _destruct__k2r9zo.tl();
    var v = _destruct__k2r9zo.ul();
    this_0.k3(k, v);
  }
  this_0.m3(_this__u8e3s4.y6g_1);
  return this_0.w7();
}
function timeouts(_this__u8e3s4) {
  return new Timeouts(_this__u8e3s4.z6g_1, _this__u8e3s4.a6h_1, _this__u8e3s4.b6h_1, _this__u8e3s4.c6h_1);
}
function *_generator_requireFileSystem__z634is($this, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.g6h_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    if (!$this.i6h_1) {
      var tmp_1 = $this;
      var tmp_2 = defaultSkillFileSystem($completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      tmp_1.h6h_1 = tmp_2;
      $this.i6h_1 = true;
    }
    var tmp0_elvis_lhs = $this.h6h_1;
    var tmp_3;
    if (tmp0_elvis_lhs == null) {
      throw SkillException.t6h(SkillStage_DISCOVER_getInstance(), VOID, 'Markdown directory Skill sources are unavailable on this platform; use source(loader) with a custom SkillLoader');
    } else {
      tmp_3 = tmp0_elvis_lhs;
    }
    tmp_0 = tmp_3;
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function requireFileSystem($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_requireFileSystem__z634is.bind(VOID, $this), $completion);
}
function *_generator_discover__xd3vwf_0($this, $completion) {
  var tmp = index($this, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp.j3();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$0 = item.w6h_1;
    destination.l(tmp$ret$0);
  }
  return destination;
}
function *_generator_load__qllgda_0($this, id, $completion) {
  var tmp = index($this, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp0_elvis_lhs = tmp.h3(new SkillId(id));
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    throw SkillException.t6h(SkillStage_LOAD_getInstance(), id, "skill '" + _SkillId___get_value__impl__n6yl35(id) + "' was not found under '" + $this.f6h_1 + "'");
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var indexed = tmp_0;
  var tmp_1 = requireFileSystem($this, $completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  var fileSystem = tmp_1;
  var tmp_2;
  try {
    var metadata_0 = metadata(fileSystem, indexed.v6h_1);
    var size = metadata_0.z6h_1;
    if (!metadata_0.y6h_1 || size == null || size.s1(new Long(1000000, 0)) > 0) {
      throw SkillException.t6h(SkillStage_LOAD_getInstance(), id, indexed.v6h_1.toString() + ' must be a UTF-8 file no larger than 1000000 bytes');
    }
    var document = fileSystem.b6i(indexed.v6h_1);
    var parsed = parseDocument(document, indexed.v6h_1.toString(), true);
    if (!(parsed.f6i_1.c6i_1 === id)) {
      throw SkillException.t6h(SkillStage_VALIDATE_getInstance(), id, "SKILL.md name '" + _SkillId___get_value__impl__n6yl35(parsed.f6i_1.c6i_1) + "' does not match directory '" + _SkillId___get_value__impl__n6yl35(id) + "'");
    }
    tmp_2 = new SkillDefinition(parsed.f6i_1, parsed.g6i_1, new DirectorySkillResourceProvider(id, indexed.u6h_1, fileSystem));
  } catch ($p) {
    var tmp_3;
    if ($p instanceof SkillException) {
      var skill = $p;
      throw skill;
    } else {
      if ($p instanceof Error) {
        var failure = $p;
        var tmp_4 = SkillStage_LOAD_getInstance();
        var tmp_5 = "failed to load skill '" + _SkillId___get_value__impl__n6yl35(id) + "' from " + indexed.v6h_1.toString() + ': ';
        var tmp1_elvis_lhs = failure.message;
        throw SkillException.t6h(tmp_4, id, tmp_5 + (tmp1_elvis_lhs == null ? 'unknown error' : tmp1_elvis_lhs), failure);
      } else {
        throw $p;
      }
    }
  }
  return tmp_2;
}
function *_generator_index__qc8vmq($this, $completion) {
  var tmp0_safe_receiver = $this.k6h_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    return tmp0_safe_receiver;
  }
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.j6h_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    var tmp$ret$1;
    $l$block: {
      var tmp0_safe_receiver_0 = $this.k6h_1;
      if (tmp0_safe_receiver_0 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        tmp$ret$1 = tmp0_safe_receiver_0;
        break $l$block;
      }
      var tmp_1 = scanDirectory($this, $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      var scanned = tmp_1;
      $this.k6h_1 = scanned;
      tmp$ret$1 = scanned;
    }
    tmp_0 = tmp$ret$1;
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function index($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_index__qc8vmq.bind(VOID, $this), $completion);
}
function *_generator_scanDirectory__7ego1o($this, $completion) {
  var tmp = requireFileSystem($this, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var fileSystem = tmp;
  try {
    var canonicalRoot = fileSystem.h6i(Companion_getInstance_1().a44($this.f6h_1));
    var rootMetadata = metadata(fileSystem, canonicalRoot);
    if (!rootMetadata.x6h_1) {
      throw SkillException.t6h(SkillStage_DISCOVER_getInstance(), VOID, "skill source '" + $this.f6h_1 + "' is not a directory");
    }
    var result = LinkedHashMap.hc();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = fileSystem.i6i(canonicalRoot).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      $l$block: {
        var childMetadata = metadata(fileSystem, element);
        if (childMetadata.a6i_1) {
          throw SkillException.t6h(SkillStage_DISCOVER_getInstance(), VOID, "symbolic links are not allowed directly under skill source '" + $this.f6h_1 + "': " + element.toString());
        }
        if (!childMetadata.x6h_1) {
          break $l$block;
        }
        var tmp_0;
        try {
          tmp_0 = _SkillId___init__impl__ou80gj(element.e44());
        } catch ($p) {
          var tmp_1;
          if ($p instanceof IllegalArgumentException) {
            var invalid = $p;
            throw SkillException.t6h(SkillStage_DISCOVER_getInstance(), VOID, "invalid skill directory name '" + element.e44() + "' under '" + $this.f6h_1 + "'", invalid);
          } else {
            throw $p;
          }
        }
        var directoryId = tmp_0;
        var skillFile = element.f44('SKILL.md');
        var tmp0_elvis_lhs = fileSystem.j6i(skillFile);
        var tmp_2;
        if (tmp0_elvis_lhs == null) {
          throw SkillException.t6h(SkillStage_DISCOVER_getInstance(), directoryId, "skill directory '" + element.toString() + "' does not contain SKILL.md");
        } else {
          tmp_2 = tmp0_elvis_lhs;
        }
        var skillMetadata = tmp_2;
        if (!skillMetadata.y6h_1 || skillMetadata.a6i_1) {
          throw SkillException.t6h(SkillStage_DISCOVER_getInstance(), directoryId, skillFile.toString() + ' must be a regular file and not a symbolic link');
        }
        var frontMatter = readFrontMatter($this, fileSystem, skillFile, directoryId);
        var descriptor = parseFrontMatter(frontMatter, skillFile.toString());
        if (!(descriptor.c6i_1 === directoryId)) {
          throw SkillException.t6h(SkillStage_VALIDATE_getInstance(), directoryId, "SKILL.md name '" + _SkillId___get_value__impl__n6yl35(descriptor.c6i_1) + "' does not match directory '" + _SkillId___get_value__impl__n6yl35(directoryId) + "'");
        }
        var tmp1 = new SkillId(directoryId);
        // Inline function 'kotlin.collections.set' call
        var value = new IndexedSkill(element, skillFile, descriptor);
        result.k3(tmp1, value);
      }
    }
    return result;
  } catch ($p) {
    if ($p instanceof SkillException) {
      var skill = $p;
      throw skill;
    } else {
      if ($p instanceof Error) {
        var failure = $p;
        var tmp_3 = SkillStage_DISCOVER_getInstance();
        var tmp0_elvis_lhs_0 = failure.message;
        throw SkillException.t6h(tmp_3, VOID, "failed to discover skills under '" + $this.f6h_1 + "': " + (tmp0_elvis_lhs_0 == null ? 'unknown error' : tmp0_elvis_lhs_0), failure);
      } else {
        throw $p;
      }
    }
  }
}
function scanDirectory($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_scanDirectory__7ego1o.bind(VOID, $this), $completion);
}
function readFrontMatter($this, fileSystem, file, id) {
  var lines = lineSequence(fileSystem.b6i(file)).y();
  var tmp0_safe_receiver = nextOrNull(lines);
  var first = tmp0_safe_receiver == null ? null : removePrefix(tmp0_safe_receiver, '\uFEFF');
  var tmp;
  if (first == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.text.trim' call
    tmp = toString(trim(isCharSequence(first) ? first : THROW_CCE()));
  }
  if (!(tmp === '---')) {
    throw SkillException.t6h(SkillStage_DISCOVER_getInstance(), id, file.toString() + ' must start with YAML front matter');
  }
  var yaml = StringBuilder.v();
  while (lines.z()) {
    var line = lines.a1();
    // Inline function 'kotlin.text.trim' call
    if (toString(trim(isCharSequence(line) ? line : THROW_CCE())) === '---')
      return yaml.toString();
    // Inline function 'kotlin.text.appendLine' call
    // Inline function 'kotlin.text.appendLine' call
    yaml.tb(line).ub(_Char___init__impl__6a9atx(10));
    if (yaml.a() > 65536) {
      throw SkillException.t6h(SkillStage_DISCOVER_getInstance(), id, file.toString() + ' front matter exceeds 65536 characters');
    }
  }
  throw SkillException.t6h(SkillStage_DISCOVER_getInstance(), id, file.toString() + ' has unclosed YAML front matter');
}
function parseDocument(text, source, includeBody) {
  var firstStart = startsWith(text, _Char___init__impl__6a9atx(65279)) ? 1 : 0;
  // Inline function 'kotlin.let' call
  var it = indexOf(text, _Char___init__impl__6a9atx(10), firstStart);
  var firstEnd = it < 0 ? text.length : it;
  // Inline function 'kotlin.text.substring' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$3 = text.substring(firstStart, firstEnd);
  // Inline function 'kotlin.text.trim' call
  var this_0 = trimEnd(tmp$ret$3, charArrayOf([_Char___init__impl__6a9atx(13)]));
  var firstLine = toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
  if (!(firstLine === '---')) {
    throw SkillException.t6h(SkillStage_LOAD_getInstance(), VOID, source + ' must start with YAML front matter');
  }
  var yamlStart = firstEnd < text.length ? firstEnd + 1 | 0 : text.length;
  var lineStart = yamlStart;
  $l$loop: while (lineStart <= text.length) {
    // Inline function 'kotlin.let' call
    var it_0 = indexOf(text, _Char___init__impl__6a9atx(10), lineStart);
    var lineEnd = it_0 < 0 ? text.length : it_0;
    // Inline function 'kotlin.text.substring' call
    var startIndex = lineStart;
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$8 = text.substring(startIndex, lineEnd);
    var line = trimEnd(tmp$ret$8, charArrayOf([_Char___init__impl__6a9atx(13)]));
    // Inline function 'kotlin.text.trim' call
    if (toString(trim(isCharSequence(line) ? line : THROW_CCE())) === '---') {
      // Inline function 'kotlin.text.substring' call
      var endIndex = lineStart;
      // Inline function 'kotlin.js.asDynamic' call
      var yamlText = text.substring(yamlStart, endIndex);
      var bodyStart = lineEnd < text.length ? lineEnd + 1 | 0 : text.length;
      var tmp = parseFrontMatter(yamlText, source);
      var tmp_0;
      if (includeBody) {
        // Inline function 'kotlin.text.substring' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp_0 = text.substring(bodyStart);
      } else {
        tmp_0 = '';
      }
      return new ParsedSkillDocument(tmp, tmp_0);
    }
    if (lineEnd === text.length)
      break $l$loop;
    lineStart = lineEnd + 1 | 0;
  }
  throw SkillException.t6h(SkillStage_LOAD_getInstance(), VOID, source + ' has unclosed YAML front matter');
}
function resourceError($this, message, cause) {
  return SkillException.t6h(SkillStage_RESOURCE_getInstance(), $this.n6i_1, message, cause);
}
function resourceError$default($this, message, cause, $super) {
  cause = cause === VOID ? null : cause;
  return resourceError($this, message, cause);
}
function pageResource($this, text, request) {
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(text) === 0) {
    if (!request.r6i_1.equals(new SkillResourceCursor(1, 1))) {
      throw resourceError$default($this, 'resource cursor is outside the empty resource');
    }
    return new SkillResource(request.q6i_1, '', 1, 0, 0);
  }
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList.k();
  this_0.l(0);
  // Inline function 'kotlin.text.forEachIndexed' call
  var index = 0;
  var inductionVariable = 0;
  while (inductionVariable < charSequenceLength(text)) {
    var item = charSequenceGet(text, inductionVariable);
    inductionVariable = inductionVariable + 1 | 0;
    var _unary__edvuaz = index;
    index = _unary__edvuaz + 1 | 0;
    if (item === _Char___init__impl__6a9atx(10)) {
      this_0.l(_unary__edvuaz + 1 | 0);
    }
  }
  var lineStarts = this_0.w7();
  var lineIndex = request.r6i_1.u6i_1 - 1 | 0;
  if (!(0 <= lineIndex ? lineIndex <= (lineStarts.b1() - 1 | 0) : false)) {
    throw resourceError$default($this, 'line ' + request.r6i_1.u6i_1 + ' exceeds ' + lineStarts.b1() + ' total lines');
  }
  var lineStart = lineStarts.f1(lineIndex);
  var lineEnd = (lineIndex + 1 | 0) < lineStarts.b1() ? lineStarts.f1(lineIndex + 1 | 0) - 1 | 0 : text.length;
  var maxColumn = (lineEnd - lineStart | 0) + 1 | 0;
  var containsArg = request.r6i_1.v6i_1;
  if (!(1 <= containsArg ? containsArg <= maxColumn : false)) {
    throw resourceError$default($this, 'column ' + request.r6i_1.v6i_1 + ' exceeds line ' + request.r6i_1.u6i_1 + ' length ' + (maxColumn - 1 | 0));
  }
  var absoluteStart = (lineStart + request.r6i_1.v6i_1 | 0) - 1 | 0;
  var tmp0_elvis_lhs = getOrNull(lineStarts, lineIndex + request.s6i_1 | 0);
  var lineBoundary = tmp0_elvis_lhs == null ? text.length : tmp0_elvis_lhs;
  var tmp2 = text.length;
  // Inline function 'kotlin.comparisons.minOf' call
  var c = absoluteStart + request.t6i_1 | 0;
  var absoluteEnd = Math.min(tmp2, lineBoundary, c);
  if (absoluteEnd < text.length && absoluteEnd > absoluteStart && isLowSurrogate(charSequenceGet(text, absoluteEnd)) && isHighSurrogate(charSequenceGet(text, absoluteEnd - 1 | 0))) {
    absoluteEnd = absoluteEnd - 1 | 0;
  }
  if (absoluteEnd === absoluteStart && absoluteStart < text.length) {
    var tmp5 = text.length;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = absoluteStart + 1 | 0;
    absoluteEnd = Math.min(tmp5, b);
  }
  // Inline function 'kotlin.text.substring' call
  var endIndex = absoluteEnd;
  // Inline function 'kotlin.js.asDynamic' call
  var content = text.substring(absoluteStart, endIndex);
  // Inline function 'kotlin.takeIf' call
  var this_1 = absoluteEnd;
  var tmp;
  if (this_1 < text.length) {
    tmp = this_1;
  } else {
    tmp = null;
  }
  var tmp1_safe_receiver = tmp;
  var tmp_0;
  if (tmp1_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = offsetToCursor($this, tmp1_safe_receiver, lineStarts);
  }
  var nextCursor = tmp_0;
  var tmp_1;
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(content) === 0) {
    tmp_1 = request.r6i_1.u6i_1 - 1 | 0;
  } else {
    tmp_1 = offsetToCursor($this, absoluteEnd - 1 | 0, lineStarts).u6i_1;
  }
  var lastLine = tmp_1;
  return new SkillResource(request.q6i_1, content, request.r6i_1.u6i_1, lastLine, lineStarts.b1(), nextCursor);
}
function offsetToCursor($this, offset, lineStarts) {
  var low = 0;
  var high = get_lastIndex(lineStarts);
  while (low <= high) {
    var middle = (low + high | 0) >>> 1 | 0;
    if (lineStarts.f1(middle) <= offset)
      low = middle + 1 | 0;
    else
      high = middle - 1 | 0;
  }
  var lineIndex = coerceAtLeast(high, 0);
  return new SkillResourceCursor(lineIndex + 1 | 0, (offset - lineStarts.f1(lineIndex) | 0) + 1 | 0);
}
function parseFrontMatter(text, source) {
  var tmp;
  try {
    var tmp_0 = Companion_getInstance_4().l4n_1.o4n(text);
    var tmp0_elvis_lhs = tmp_0 instanceof YamlMap ? tmp_0 : null;
    var tmp_1;
    if (tmp0_elvis_lhs == null) {
      throw SkillException.t6h(SkillStage_VALIDATE_getInstance(), VOID, source + ' front matter must be a YAML map');
    } else {
      tmp_1 = tmp0_elvis_lhs;
    }
    tmp = tmp_1;
  } catch ($p) {
    var tmp_2;
    if ($p instanceof SkillException) {
      var skill = $p;
      throw skill;
    } else {
      if ($p instanceof Error) {
        var failure = $p;
        var tmp_3 = SkillStage_VALIDATE_getInstance();
        var tmp1_elvis_lhs = failure.message;
        throw SkillException.t6h(tmp_3, VOID, 'invalid YAML front matter in ' + source + ': ' + (tmp1_elvis_lhs == null ? 'unknown error' : tmp1_elvis_lhs), failure);
      } else {
        throw $p;
      }
    }
  }
  var map = tmp;
  var name = requiredScalar(map, 'name', source);
  var description = requiredScalar(map, 'description', source);
  // Inline function 'kotlin.collections.mapNotNull' call
  var tmp0 = map.z4x_1;
  // Inline function 'kotlin.collections.mapNotNullTo' call
  var destination = ArrayList.k();
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = tmp0.l1().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var key = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var value = element.n1();
    var tmp0_safe_receiver = key.u4x_1 === 'name' || key.u4x_1 === 'description' ? null : to(key.u4x_1, metadataString(value));
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      destination.l(tmp0_safe_receiver);
    }
  }
  var metadata = toMap(destination);
  var tmp_4;
  try {
    tmp_4 = new SkillDescriptor(_SkillId___init__impl__ou80gj(name), description, metadata);
  } catch ($p) {
    var tmp_5;
    if ($p instanceof IllegalArgumentException) {
      var failure_0 = $p;
      throw SkillException.t6h(SkillStage_VALIDATE_getInstance(), VOID, 'invalid front matter in ' + source + ': ' + failure_0.message, failure_0);
    } else {
      throw $p;
    }
  }
  return tmp_4;
}
function nextOrNull(_this__u8e3s4) {
  return _this__u8e3s4.z() ? _this__u8e3s4.a1() : null;
}
function isInside(_this__u8e3s4, root) {
  return equals(_this__u8e3s4.b44(), root.b44()) && _this__u8e3s4.c44().b1() >= root.c44().b1() && equals(take(_this__u8e3s4.c44(), root.c44().b1()), root.c44());
}
function requiredScalar(map, key, source) {
  var tmp;
  try {
    var tmp0_safe_receiver = map.o4z(key);
    tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.u4x_1;
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var failure = $p;
      throw SkillException.t6h(SkillStage_VALIDATE_getInstance(), VOID, source + " field '" + key + "' must be a scalar", failure);
    } else {
      throw $p;
    }
  }
  var tmp_1;
  if (tmp == null) {
    tmp_1 = null;
  } else {
    // Inline function 'kotlin.text.trim' call
    tmp_1 = toString(trim(isCharSequence(tmp) ? tmp : THROW_CCE()));
  }
  var value = tmp_1;
  // Inline function 'kotlin.text.isNullOrBlank' call
  if (value == null || isBlank(value)) {
    throw SkillException.t6h(SkillStage_VALIDATE_getInstance(), VOID, source + " requires non-blank '" + key + "' front matter");
  }
  return value;
}
function metadataString(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof YamlScalar) {
    tmp = _this__u8e3s4.u4x_1;
  } else {
    tmp = _this__u8e3s4.n4z();
  }
  return tmp;
}
function get_SKILL_ID_REGEX() {
  _init_properties_Skill_kt__6awtk1();
  return SKILL_ID_REGEX;
}
var SKILL_ID_REGEX;
function _SkillId___init__impl__ou80gj(value) {
  // Inline function 'kotlin.require' call
  if (!get_SKILL_ID_REGEX().yh(_SkillId___get_value__impl__n6yl35(value))) {
    var message = 'SkillId must match ' + get_SKILL_ID_REGEX().mh_1 + ": '" + _SkillId___get_value__impl__n6yl35(value) + "'";
    throw IllegalArgumentException.t(toString(message));
  }
  return value;
}
function _SkillId___get_value__impl__n6yl35($this) {
  return $this;
}
function SkillId__toString_impl_kvoh91($this) {
  return _SkillId___get_value__impl__n6yl35($this);
}
function SkillId__hashCode_impl_vhfju($this) {
  return getStringHashCode($this);
}
function SkillId__equals_impl_845tem($this, other) {
  if (!(other instanceof SkillId))
    return false;
  if (!($this === (other instanceof SkillId ? other.b6j_1 : THROW_CCE())))
    return false;
  return true;
}
var SkillStage_DISCOVER_instance;
var SkillStage_LOAD_instance;
var SkillStage_VALIDATE_instance;
var SkillStage_RESOURCE_instance;
var SkillStage_entriesInitialized;
function SkillStage_initEntries() {
  if (SkillStage_entriesInitialized)
    return Unit_instance;
  SkillStage_entriesInitialized = true;
  SkillStage_DISCOVER_instance = new SkillStage('DISCOVER', 0);
  SkillStage_LOAD_instance = new SkillStage('LOAD', 1);
  SkillStage_VALIDATE_instance = new SkillStage('VALIDATE', 2);
  SkillStage_RESOURCE_instance = new SkillStage('RESOURCE', 3);
}
function SkillStage_DISCOVER_getInstance() {
  SkillStage_initEntries();
  return SkillStage_DISCOVER_instance;
}
function SkillStage_LOAD_getInstance() {
  SkillStage_initEntries();
  return SkillStage_LOAD_instance;
}
function SkillStage_VALIDATE_getInstance() {
  SkillStage_initEntries();
  return SkillStage_VALIDATE_instance;
}
function SkillStage_RESOURCE_getInstance() {
  SkillStage_initEntries();
  return SkillStage_RESOURCE_instance;
}
var properties_initialized_Skill_kt_dt7mzl;
function _init_properties_Skill_kt__6awtk1() {
  if (!properties_initialized_Skill_kt_dt7mzl) {
    properties_initialized_Skill_kt_dt7mzl = true;
    SKILL_ID_REGEX = Regex.xh('[A-Za-z0-9][A-Za-z0-9._-]*');
  }
}
function metadata(_this__u8e3s4, path) {
  var tmp0_elvis_lhs = _this__u8e3s4.j6i(path);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException.t4('file does not exist: ' + path.toString());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function SkillPlan$prepare$slambda$slambda_0(this$0, $index, $loader) {
  var i = new SkillPlan$prepare$slambda$slambda(this$0, $index, $loader);
  var l = ($this$async, $completion) => i.r1f($this$async, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_prepare__2w4w0d_0($this, $completion) {
  var tmp = coroutineScope(SkillPlan$prepare$slambda_0($this), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var discoveries = tmp;
  var byId = LinkedHashMap.hc();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = flatten(discoveries).y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.getOrPut' call
    var key = new SkillId(element.q6j_1.c6i_1);
    var value = byId.h3(key);
    var tmp_0;
    if (value == null) {
      // Inline function 'kotlin.collections.mutableListOf' call
      var answer = ArrayList.k();
      byId.k3(key, answer);
      tmp_0 = answer;
    } else {
      tmp_0 = value;
    }
    // Inline function 'kotlin.collections.plusAssign' call
    tmp_0.l(element);
  }
  var tmp_1;
  if ($this.p5s_1.h1()) {
    var tmp2 = byId.j3();
    var tmp$ret$7;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s_0 = tmp2.y();
      while (_iterator__ex2g4s_0.z()) {
        var element_0 = _iterator__ex2g4s_0.a1();
        if (element_0.b1() > 1) {
          tmp$ret$7 = element_0;
          break $l$block;
        }
      }
      tmp$ret$7 = null;
    }
    var tmp0_safe_receiver = tmp$ret$7;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      throwAmbiguousSkill($this, tmp0_safe_receiver);
    }
    // Inline function 'kotlin.collections.flatMap' call
    // Inline function 'kotlin.collections.flatMapTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s_1 = discoveries.y();
    while (_iterator__ex2g4s_1.z()) {
      var element_1 = _iterator__ex2g4s_1.a1();
      // Inline function 'kotlin.collections.sortedBy' call
      // Inline function 'kotlin.comparisons.compareBy' call
      var tmp_2 = SkillPlan$prepare$lambda;
      var tmp$ret$9 = new sam$kotlin_Comparator$0(tmp_2);
      var list = sortedWith(element_1, tmp$ret$9);
      addAll(destination, list);
    }
    tmp_1 = destination;
  } else {
    // Inline function 'kotlin.collections.map' call
    var this_0 = $this.p5s_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s_2 = this_0.y();
    while (_iterator__ex2g4s_2.z()) {
      var item = _iterator__ex2g4s_2.a1();
      var id = item.b6j_1;
      // Inline function 'kotlin.collections.orEmpty' call
      var tmp0_elvis_lhs = byId.h3(new SkillId(id));
      var candidates = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
      var tmp_3;
      switch (candidates.b1()) {
        case 0:
          throw SkillException.t6h(SkillStage_VALIDATE_getInstance(), id, "selected skill '" + _SkillId___get_value__impl__n6yl35(id) + "' was not discovered by any source");
        case 1:
          tmp_3 = single(candidates);
          break;
        default:
          throwAmbiguousSkill($this, candidates);
          break;
      }
      var tmp$ret$15 = tmp_3;
      destination_0.l(tmp$ret$15);
    }
    tmp_1 = destination_0;
  }
  var toLoad = tmp_1;
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_1 = ArrayList.x(collectionSizeOrDefault(toLoad, 10));
  var _iterator__ex2g4s_3 = toLoad.y();
  while (_iterator__ex2g4s_3.z()) {
    var item_0 = _iterator__ex2g4s_3.a1();
    var tmp_4 = load($this, item_0, $completion);
    if (tmp_4 === get_COROUTINE_SUSPENDED())
      tmp_4 = yield tmp_4;
    var tmp$ret$18 = tmp_4;
    destination_1.l(tmp$ret$18);
  }
  var definitions = destination_1;
  return new PreparedSkills(definitions);
}
function *_generator_discover__xd3vwf_1($this, index, loader, $completion) {
  var tmp;
  try {
    var tmp_0 = loader.k61($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      throw cancelled;
    } else {
      if ($p instanceof SkillException) {
        var skill = $p;
        throw skill;
      } else {
        if ($p instanceof Error) {
          var failure = $p;
          var tmp_2 = SkillStage_DISCOVER_getInstance();
          var tmp_3 = index + 1 | 0;
          var tmp0_elvis_lhs = failure.message;
          throw SkillException.t6h(tmp_2, VOID, 'skill source ' + tmp_3 + ' discovery failed: ' + (tmp0_elvis_lhs == null ? 'unknown error' : tmp0_elvis_lhs), failure);
        } else {
          throw $p;
        }
      }
    }
  }
  var descriptors = tmp;
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(descriptors, 10));
  var _iterator__ex2g4s = descriptors.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$0 = new LocatedSkill(index, loader, item);
    destination.l(tmp$ret$0);
  }
  return destination;
}
function discover($this, index, loader, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_discover__xd3vwf_1.bind(VOID, $this, index, loader), $completion);
}
function *_generator_load__qllgda_1($this, located, $completion) {
  var tmp;
  try {
    var tmp_0 = located.p6j_1.m6i(located.q6j_1.c6i_1, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      throw cancelled;
    } else {
      if ($p instanceof SkillException) {
        var skill = $p;
        throw skill;
      } else {
        if ($p instanceof Error) {
          var failure = $p;
          var tmp_2 = SkillStage_LOAD_getInstance();
          var tmp_3 = _SkillId___get_value__impl__n6yl35(located.q6j_1.c6i_1);
          var tmp0_elvis_lhs = failure.message;
          throw SkillException.t6h(tmp_2, located.q6j_1.c6i_1, "skill '" + tmp_3 + "' load failed: " + (tmp0_elvis_lhs == null ? 'unknown error' : tmp0_elvis_lhs), failure);
        } else {
          throw $p;
        }
      }
    }
  }
  var definition = tmp;
  if (!definition.x6i_1.equals(located.q6j_1)) {
    throw SkillException.t6h(SkillStage_VALIDATE_getInstance(), located.q6j_1.c6i_1, "skill '" + _SkillId___get_value__impl__n6yl35(located.q6j_1.c6i_1) + "' descriptor changed between discovery and load");
  }
  return definition;
}
function load($this, located, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda_1.bind(VOID, $this, located), $completion);
}
function throwAmbiguousSkill($this, candidates) {
  var id = first(candidates).q6j_1.c6i_1;
  var tmp = SkillStage_VALIDATE_getInstance();
  var tmp_0 = "skill '" + _SkillId___get_value__impl__n6yl35(id) + "' is ambiguous across sources ";
  throw SkillException.t6h(tmp, id, tmp_0 + joinToString(candidates, ', ', VOID, VOID, VOID, VOID, SkillPlan$throwAmbiguousSkill$lambda));
}
function SkillPlan$prepare$slambda_0(this$0) {
  var i = new SkillPlan$prepare$slambda(this$0);
  var l = ($this$coroutineScope, $completion) => i.r1f($this$coroutineScope, $completion);
  l.$arity = 1;
  return l;
}
function SkillPlan$prepare$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = _SkillId___get_value__impl__n6yl35(a.q6j_1.c6i_1);
  var tmp$ret$1 = _SkillId___get_value__impl__n6yl35(b.q6j_1.c6i_1);
  return compareValues(tmp, tmp$ret$1);
}
function SkillPlan$throwAmbiguousSkill$lambda(it) {
  return (it.o6j_1 + 1 | 0).toString();
}
function *_generator_execute__d6syw1($this, input, $completion) {
  var tmp;
  try {
    tmp = _SkillId___init__impl__ou80gj(input.t6j_1);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof IllegalArgumentException) {
      var failure = $p;
      throw SkillException.t6h(SkillStage_RESOURCE_getInstance(), VOID, "invalid Skill id '" + input.t6j_1 + "'", failure);
    } else {
      throw $p;
    }
  }
  var id = tmp;
  var tmp0_elvis_lhs = $this.y6j_1.h3(new SkillId(id));
  var tmp_1;
  if (tmp0_elvis_lhs == null) {
    throw SkillException.t6h(SkillStage_RESOURCE_getInstance(), id, "Skill '" + _SkillId___get_value__impl__n6yl35(id) + "' is not enabled or has no resources");
  } else {
    tmp_1 = tmp0_elvis_lhs;
  }
  var provider = tmp_1;
  var tmp_2;
  try {
    var tmp1_elvis_lhs = input.v6j_1;
    var tmp_3 = tmp1_elvis_lhs == null ? 1 : tmp1_elvis_lhs;
    var tmp2_elvis_lhs = input.w6j_1;
    var tmp_4 = new SkillResourceCursor(tmp_3, tmp2_elvis_lhs == null ? 1 : tmp2_elvis_lhs);
    var tmp3_elvis_lhs = input.x6j_1;
    tmp_2 = new SkillResourceRequest(input.u6j_1, tmp_4, tmp3_elvis_lhs == null ? 200 : tmp3_elvis_lhs, 30000);
  } catch ($p) {
    var tmp_5;
    if ($p instanceof IllegalArgumentException) {
      var failure_0 = $p;
      var tmp_6 = SkillStage_RESOURCE_getInstance();
      var tmp4_elvis_lhs = failure_0.message;
      throw SkillException.t6h(tmp_6, id, tmp4_elvis_lhs == null ? 'invalid Skill resource request' : tmp4_elvis_lhs, failure_0);
    } else {
      throw $p;
    }
  }
  var request = tmp_2;
  var tmp_7 = provider.w6i(request, $completion);
  if (tmp_7 === get_COROUTINE_SUSPENDED())
    tmp_7 = yield tmp_7;
  var resource = tmp_7;
  validateResourcePage($this, id, request, resource);
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  this_0.tb(resource.c6j_1);
  this_0.tb('  lines ');
  this_0.fh(resource.e6j_1);
  this_0.ub(_Char___init__impl__6a9atx(45));
  this_0.fh(resource.f6j_1);
  this_0.tb(' of ');
  // Inline function 'kotlin.text.appendLine' call
  var value = resource.g6j_1;
  // Inline function 'kotlin.text.appendLine' call
  this_0.fh(value).ub(_Char___init__impl__6a9atx(10));
  this_0.tb(resource.d6j_1);
  var tmp0_safe_receiver = resource.h6j_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    this_0.tb('\n[next cursor: line=');
    this_0.fh(tmp0_safe_receiver.u6i_1);
    this_0.tb(', column=');
    this_0.fh(tmp0_safe_receiver.v6i_1);
    this_0.ub(_Char___init__impl__6a9atx(93));
  }
  // Inline function 'kotlin.text.trimEnd' call
  var this_1 = this_0.toString();
  return toString(trimEnd_0(isCharSequence(this_1) ? this_1 : THROW_CCE()));
}
function validateResourcePage($this, id, request, resource) {
  if (!(resource.c6j_1 === request.q6i_1)) {
    validateResourcePage$invalid(id, request, "provider returned path '" + resource.c6j_1 + "'");
  }
  if (resource.d6j_1.length > request.t6i_1) {
    validateResourcePage$invalid(id, request, 'content exceeds ' + request.t6i_1 + ' characters');
  }
  if (resource.g6j_1 < 0) {
    validateResourcePage$invalid(id, request, 'totalLines must not be negative');
  }
  if (!(resource.e6j_1 === request.r6i_1.u6i_1)) {
    validateResourcePage$invalid(id, request, 'firstLine ' + resource.e6j_1 + ' does not match requested line ' + request.r6i_1.u6i_1);
  }
  // Inline function 'kotlin.text.isEmpty' call
  var this_0 = resource.d6j_1;
  if (charSequenceLength(this_0) === 0) {
    if (!(resource.f6j_1 === (resource.e6j_1 - 1 | 0))) {
      validateResourcePage$invalid(id, request, 'an empty page must end immediately before firstLine');
    }
  } else {
    if (resource.f6j_1 < resource.e6j_1) {
      validateResourcePage$invalid(id, request, 'lastLine precedes firstLine');
    }
    if (resource.g6j_1 === 0 || resource.f6j_1 > resource.g6j_1) {
      validateResourcePage$invalid(id, request, 'lastLine exceeds totalLines');
    }
    if (((resource.f6j_1 - resource.e6j_1 | 0) + 1 | 0) > request.s6i_1) {
      validateResourcePage$invalid(id, request, 'page exceeds ' + request.s6i_1 + ' requested lines');
    }
  }
  var tmp0_safe_receiver = resource.h6j_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    var current = request.r6i_1;
    if (tmp0_safe_receiver.u6i_1 < current.u6i_1 || (tmp0_safe_receiver.u6i_1 === current.u6i_1 && tmp0_safe_receiver.v6i_1 <= current.v6i_1)) {
      validateResourcePage$invalid(id, request, 'next cursor does not advance');
    }
    if (resource.g6j_1 === 0 || tmp0_safe_receiver.u6i_1 > resource.g6j_1) {
      validateResourcePage$invalid(id, request, 'next cursor exceeds totalLines');
    }
  }
}
function validateResourcePage$invalid($id, $request, message) {
  throw SkillException.t6h(SkillStage_RESOURCE_getInstance(), $id, "invalid resource page for '" + $request.q6i_1 + "': " + message);
}
function SkillResourceTool$description$lambda(it) {
  return _SkillId___get_value__impl__n6yl35(it.b6j_1);
}
var Companion_instance_43;
function Companion_getInstance_47() {
  return Companion_instance_43;
}
var $serializer_instance_29;
function $serializer_getInstance_29() {
  if ($serializer_instance_29 === VOID)
    new $serializer_30();
  return $serializer_instance_29;
}
var ToolOutputStream_Stdout_instance;
var ToolOutputStream_Stderr_instance;
var ToolOutputStream_entriesInitialized;
function ToolOutputStream_initEntries() {
  if (ToolOutputStream_entriesInitialized)
    return Unit_instance;
  ToolOutputStream_entriesInitialized = true;
  ToolOutputStream_Stdout_instance = new ToolOutputStream('Stdout', 0);
  ToolOutputStream_Stderr_instance = new ToolOutputStream('Stderr', 1);
}
function ToolOutputStream_Stdout_getInstance() {
  ToolOutputStream_initEntries();
  return ToolOutputStream_Stdout_instance;
}
function ToolOutputStream_Stderr_getInstance() {
  ToolOutputStream_initEntries();
  return ToolOutputStream_Stderr_instance;
}
function *_generator_prepare__2w4w0d_1($this, additionalTools, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.b5p_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    $l$block: {
      if ($this.c5p_1) {
        break $l$block;
      }
      // Inline function 'kotlin.collections.buildList' call
      // Inline function 'kotlin.collections.buildListInternal' call
      // Inline function 'kotlin.apply' call
      var this_1 = ArrayList.k();
      var tmp_0 = discoverLazyToolsForPreparation($this, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      this_1.c1(tmp_0);
      addAll(this_1, additionalTools);
      var additions = this_1.w7();
      validatePreparationAdditions($this, additions);
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = additions.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        var tmp0 = $this.z5o_1;
        // Inline function 'kotlin.collections.set' call
        var key = element.e44();
        tmp0.k3(key, element);
      }
      $this.c5p_1 = true;
    }
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_discoverLazyTools__a6pkly($this, $completion) {
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList.k();
  var _iterator__ex2g4s = $this.a5p_1.y();
  while (_iterator__ex2g4s.z()) {
    var source = _iterator__ex2g4s.a1();
    var tmp = source.k61($completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    this_0.c1(tmp);
  }
  return this_0.w7();
}
function discoverLazyTools($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_discoverLazyTools__a6pkly.bind(VOID, $this), $completion);
}
function *_generator_discoverLazyToolsForPreparation__ch3zko($this, $completion) {
  var tmp;
  try {
    var tmp_0 = discoverLazyTools($this, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      throw cancelled;
    } else {
      if ($p instanceof AgentFrameworkException) {
        var failure = $p;
        throw failure;
      } else {
        if ($p instanceof Error) {
          var failure_0 = $p;
          var tmp0_elvis_lhs = failure_0.message;
          throw preparationFailure($this, 'lazy tool discovery failed: ' + (tmp0_elvis_lhs == null ? 'unknown error' : tmp0_elvis_lhs), failure_0);
        } else {
          throw $p;
        }
      }
    }
  }
  return tmp;
}
function discoverLazyToolsForPreparation($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_discoverLazyToolsForPreparation__ch3zko.bind(VOID, $this), $completion);
}
function validatePreparationAdditions($this, additions) {
  try {
    validateAdditions($this, additions);
  } catch ($p) {
    if ($p instanceof IllegalArgumentException) {
      var failure = $p;
      var tmp0_elvis_lhs = failure.message;
      throw preparationFailure($this, tmp0_elvis_lhs == null ? 'tool validation failed' : tmp0_elvis_lhs, failure);
    } else {
      throw $p;
    }
  }
}
function preparationFailure($this, message, cause) {
  return AgentFrameworkException.b5t(new PreparationError('tools', message, cause));
}
function validateAdditions($this, additions) {
  var names = toMutableSet($this.z5o_1.i3());
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = additions.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.text.isNotBlank' call
    var this_0 = element.e44();
    // Inline function 'kotlin.require' call
    if (!!isBlank(this_0)) {
      var message = 'tool name must not be blank';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!names.l(element.e44())) {
      var message_0 = 'duplicate tool: ' + element.e44();
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
}
function *_generator_invoke__zhh2q8_17($this, tool, argsJson, onSideEffect, context, $completion) {
  if (tool.t61()) {
    var tmp;
    try {
      if (tool.z61())
        onSideEffect();
      var tmp_0 = execute($this, isInterface(tool, Tool) ? tool : THROW_CCE(), argsJson, context, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      tmp = new Success(tmp_0, tool.y61());
    } catch ($p) {
      var tmp_1;
      if ($p instanceof CancellationException) {
        var e = $p;
        throw e;
      } else {
        if ($p instanceof AgentFrameworkException) {
          var e_0 = $p;
          tmp_1 = new Failure(e_0.z5s_1);
        } else {
          if ($p instanceof Exception) {
            var e_1 = $p;
            var tmp_2 = tool.e44();
            var tmp0_elvis_lhs = e_1.message;
            tmp_1 = new Failure(new ToolError(tmp_2, tmp0_elvis_lhs == null ? "tool '" + tool.e44() + "' execution failed" : tmp0_elvis_lhs, false, e_1));
          } else {
            throw $p;
          }
        }
      }
      tmp = tmp_1;
    }
    return tmp;
  }
  var tmp_3;
  try {
    var raw = isBlank(argsJson) ? '{}' : argsJson;
    tmp_3 = JsonUtil_getInstance().l6f(raw, tool.s61());
  } catch ($p) {
    var tmp_4;
    if ($p instanceof Exception) {
      var e_2 = $p;
      return new Failure(new ParseError("failed to decode arguments for tool '" + tool.e44() + "': " + e_2.message, argsJson, e_2));
    } else {
      throw $p;
    }
  }
  var input = tmp_3;
  var tmp_5;
  try {
    if (tool.z61())
      onSideEffect();
    var tmp_6 = execute($this, tool, input, context, $completion);
    if (tmp_6 === get_COROUTINE_SUSPENDED())
      tmp_6 = yield tmp_6;
    tmp_5 = new Success(tmp_6, tool.y61());
  } catch ($p) {
    var tmp_7;
    if ($p instanceof CancellationException) {
      var e_3 = $p;
      throw e_3;
    } else {
      if ($p instanceof AgentFrameworkException) {
        var e_4 = $p;
        tmp_7 = new Failure(e_4.z5s_1);
      } else {
        if ($p instanceof Exception) {
          var e_5 = $p;
          var tmp_8 = tool.e44();
          var tmp1_elvis_lhs = e_5.message;
          tmp_7 = new Failure(new ToolError(tmp_8, tmp1_elvis_lhs == null ? "tool '" + tool.e44() + "' execution failed" : tmp1_elvis_lhs, false, e_5));
        } else {
          throw $p;
        }
      }
    }
    tmp_5 = tmp_7;
  }
  return tmp_5;
}
function invoke($this, tool, argsJson, onSideEffect, context, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_17.bind(VOID, $this, tool, argsJson, onSideEffect, context), $completion);
}
function *_generator_execute__d6syw1_0($this, tool, input, context, $completion) {
  var tmp;
  var tmp_0;
  if (!(context == null)) {
    tmp_0 = isInterface(tool, ContextualTool);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    var tmp_1 = (isInterface(tool, ContextualTool) ? tool : THROW_CCE()).q6k(input, context, $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    tmp = tmp_1;
  } else {
    var tmp_2 = tool.x61(input, $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    tmp = tmp_2;
  }
  return tmp;
}
function execute($this, tool, input, context, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_execute__d6syw1_0.bind(VOID, $this, tool, input, context), $completion);
}
function refForNamed($this, descriptor, build) {
  var name = defName(SerialDescriptorToJsonSchema_instance, descriptor);
  var tmp;
  // Inline function 'kotlin.collections.contains' call
  // Inline function 'kotlin.collections.containsKey' call
  var this_0 = $this.x6k_1;
  if (!(isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).f3(name)) {
    tmp = !$this.y6k_1.v2(name);
  } else {
    tmp = false;
  }
  if (tmp) {
    // Inline function 'kotlin.collections.plusAssign' call
    $this.y6k_1.l(name);
    var tmp4 = $this.x6k_1;
    // Inline function 'kotlin.collections.set' call
    var value = build(descriptor);
    tmp4.k3(name, value);
    // Inline function 'kotlin.collections.minusAssign' call
    $this.y6k_1.z2(name);
  }
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('$ref', JsonPrimitive('#/$defs/' + name));
  return builder.i3n();
}
function objectSchema($this, descriptor) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('type', JsonPrimitive('object'));
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder_0 = new JsonObjectBuilder();
  var inductionVariable = 0;
  var last = descriptor.w1v();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var annotations = descriptor.a1w(i);
      var tmp = descriptor.y1v(i);
      var tmp_0 = SerialDescriptorToJsonSchema_instance;
      var tmp_1 = $this.z6k(descriptor.b1w(i));
      var tmp0_safe_receiver = param(SerialDescriptorToJsonSchema_instance, annotations);
      builder_0.r3o(tmp, withDescription(tmp_0, tmp_1, tmp0_safe_receiver == null ? null : get_resolvedDescription(tmp0_safe_receiver)));
    }
     while (inductionVariable < last);
  var tmp$ret$1 = builder_0.i3n();
  builder.r3o('properties', tmp$ret$1);
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_1 = new JsonArrayBuilder();
  var inductionVariable_0 = 0;
  var last_0 = descriptor.w1v();
  if (inductionVariable_0 < last_0)
    do {
      var i_0 = inductionVariable_0;
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      var elem = descriptor.b1w(i_0);
      var tmp0_safe_receiver_0 = param(SerialDescriptorToJsonSchema_instance, descriptor.a1w(i_0));
      var explicitlyOptional = (tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.h5m_1) === false;
      if (!explicitlyOptional && !elem.q1v() && !descriptor.c1w(i_0)) {
        builder_1.p3o(JsonPrimitive(descriptor.y1v(i_0)));
      }
    }
     while (inductionVariable_0 < last_0);
  var required = builder_1.i3n();
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!required.h1()) {
    builder.r3o('required', required);
  }
  return builder.i3n();
}
function sealedSchema($this, descriptor) {
  var valueDescriptor = descriptor.b1w(1);
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  var inductionVariable = 0;
  var last = valueDescriptor.w1v();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var sub = valueDescriptor.b1w(i);
      var discriminator = valueDescriptor.y1v(i);
      builder_0.p3o(subtypeSchema($this, sub, discriminator));
    }
     while (inductionVariable < last);
  var tmp$ret$1 = builder_0.i3n();
  builder.r3o('oneOf', tmp$ret$1);
  return builder.i3n();
}
function subtypeSchema($this, descriptor, discriminator) {
  var body = objectSchema($this, descriptor);
  var tmp = body.w2f('properties');
  var tmp0_elvis_lhs = tmp instanceof JsonObject ? tmp : null;
  var props = tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('type', JsonPrimitive('object'));
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder_0 = new JsonObjectBuilder();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder_1 = new JsonObjectBuilder();
  builder_1.r3o('const', JsonPrimitive(discriminator));
  var tmp$ret$1 = builder_1.i3n();
  builder_0.r3o('type', tmp$ret$1);
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = props.l1().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var k = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var v = element.n1();
    builder_0.r3o(k, v);
  }
  var tmp$ret$8 = builder_0.i3n();
  builder.r3o('properties', tmp$ret$8);
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_2 = new JsonArrayBuilder();
  builder_2.p3o(JsonPrimitive('type'));
  var tmp_0 = body.w2f('required');
  var tmp0_safe_receiver = tmp_0 instanceof JsonArray ? tmp_0 : null;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = tmp0_safe_receiver.y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      builder_2.p3o(element_0);
    }
  }
  var required = builder_2.i3n();
  builder.r3o('required', required);
  return builder.i3n();
}
function listSchema($this, descriptor) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('type', JsonPrimitive('array'));
  builder.r3o('items', $this.z6k(descriptor.b1w(0)));
  return builder.i3n();
}
function mapSchema($this, descriptor) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('type', JsonPrimitive('object'));
  builder.r3o('additionalProperties', $this.z6k(descriptor.b1w(1)));
  return builder.i3n();
}
function SerialDescriptorToJsonSchema$Ctx$schemaFor$lambda(this$0) {
  return (it) => objectSchema(this$0, it);
}
function SerialDescriptorToJsonSchema$Ctx$schemaFor$lambda_0(this$0) {
  return (it) => sealedSchema(this$0, it);
}
function enumSchema($this, descriptor) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('type', JsonPrimitive('string'));
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  var inductionVariable = 0;
  var last = descriptor.w1v();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      builder_0.p3o(JsonPrimitive(descriptor.y1v(i)));
    }
     while (inductionVariable < last);
  var tmp$ret$1 = builder_0.i3n();
  builder.r3o('enum', tmp$ret$1);
  return builder.i3n();
}
function primitiveSchema($this, kind) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('type', JsonPrimitive(jsonType(SerialDescriptorToJsonSchema_instance, kind)));
  return builder.i3n();
}
function jsonType($this, kind) {
  var tmp;
  if (equals(kind, STRING_getInstance()) || equals(kind, CHAR_getInstance())) {
    tmp = 'string';
  } else if (equals(kind, BOOLEAN_getInstance())) {
    tmp = 'boolean';
  } else if (equals(kind, BYTE_getInstance()) || equals(kind, SHORT_getInstance()) || (equals(kind, INT_getInstance()) || equals(kind, LONG_getInstance()))) {
    tmp = 'integer';
  } else if (equals(kind, FLOAT_getInstance()) || equals(kind, DOUBLE_getInstance())) {
    tmp = 'number';
  } else {
    noWhenBranchMatchedException();
  }
  return tmp;
}
function withNull($this, base) {
  var type = base.w2f('type');
  var tmp;
  if (type instanceof JsonPrimitive_0) {
    tmp = equals(base.i3(), setOf_0('type'));
  } else {
    tmp = false;
  }
  if (tmp) {
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    // Inline function 'kotlinx.serialization.json.buildJsonArray' call
    var builder_0 = new JsonArrayBuilder();
    builder_0.p3o(type);
    builder_0.p3o(JsonPrimitive('null'));
    var tmp$ret$1 = builder_0.i3n();
    builder.r3o('type', tmp$ret$1);
    return builder.i3n();
  }
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder_1 = new JsonObjectBuilder();
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_2 = new JsonArrayBuilder();
  builder_2.p3o(base);
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder_3 = new JsonObjectBuilder();
  builder_3.r3o('type', JsonPrimitive('null'));
  var tmp$ret$5 = builder_3.i3n();
  builder_2.p3o(tmp$ret$5);
  var tmp$ret$7 = builder_2.i3n();
  builder_1.r3o('oneOf', tmp$ret$7);
  return builder_1.i3n();
}
function withDescription($this, base, description) {
  // Inline function 'kotlin.text.isNullOrBlank' call
  if (description == null || isBlank(description))
    return base;
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = base.l1().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var key = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var value = element.n1();
    builder.r3o(key, value);
  }
  builder.r3o('description', JsonPrimitive(description));
  return builder.i3n();
}
function param($this, _this__u8e3s4) {
  // Inline function 'kotlin.collections.filterIsInstance' call
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = _this__u8e3s4.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element instanceof Param) {
      destination.l(element);
    }
  }
  return firstOrNull(destination);
}
function defName($this, descriptor) {
  // Inline function 'kotlin.text.ifEmpty' call
  var this_0 = substringBefore(substringAfterLast(descriptor.k1u(), _Char___init__impl__6a9atx(46)), _Char___init__impl__6a9atx(63));
  var tmp;
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(this_0) === 0) {
    tmp = descriptor.k1u();
  } else {
    tmp = this_0;
  }
  return tmp;
}
var SerialDescriptorToJsonSchema_instance;
function SerialDescriptorToJsonSchema_getInstance() {
  return SerialDescriptorToJsonSchema_instance;
}
function *_generator_invoke__zhh2q8_18($this, frame, $completion) {
  $this.c6l_1._v = true;
  var tmp = $this.d6l_1.t1c(frame, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_19($this, $this$flow, $completion) {
  var attempt = {_v: 0};
  $l$loop: while (true) {
    var tmp0_safe_receiver = $this.n6l_1.m6l_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var tmp = limiterFor($this.o6l_1, tmp0_safe_receiver, $completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
      var tmp_0 = tmp.v6l($completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
    }
    var emittedAny = {_v: false};
    try {
      var tmp_1 = execute_0($this.o6l_1, $this.n6l_1, KtorTransport$call$slambda$slambda_0(emittedAny, $this$flow), $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      var httpError = tmp_1;
      if (!(httpError == null)) {
        if (attempt._v < $this.n6l_1.l6l_1.s6g_1 && isRetriableStatus(httpError.a6m_1)) {
          var backoff = $this.n6l_1.l6l_1.t6g_1.w3((new Long(1, 0)).e4(attempt._v));
          $this.o6l_1.x6l_1.c5l(KtorTransport$call$slambda$lambda(attempt, $this.n6l_1, backoff, httpError));
          attempt._v = attempt._v + 1 | 0;
          // Inline function 'kotlin.time.Companion.milliseconds' call
          Companion_getInstance();
          var tmp$ret$2 = toDuration(backoff, DurationUnit_MILLISECONDS_getInstance());
          var tmp_2 = delay(tmp$ret$2, $completion);
          if (tmp_2 === get_COROUTINE_SUSPENDED())
            tmp_2 = yield tmp_2;
          continue $l$loop;
        }
        var tmp_3 = $this$flow.t1c(httpError, $completion);
        if (tmp_3 === get_COROUTINE_SUSPENDED())
          tmp_3 = yield tmp_3;
      }
      return Unit_instance;
    } catch ($p) {
      if ($p instanceof CancellationException) {
        var e = $p;
        throw e;
      } else {
        if ($p instanceof Error) {
          var e_0 = $p;
          if (!emittedAny._v && attempt._v < $this.n6l_1.l6l_1.s6g_1 && isRetriableTransportFailure(e_0)) {
            var backoff_0 = $this.n6l_1.l6l_1.t6g_1.w3((new Long(1, 0)).e4(attempt._v));
            $this.o6l_1.x6l_1.c5l(KtorTransport$call$slambda$lambda_0(attempt, $this.n6l_1, backoff_0, e_0));
            attempt._v = attempt._v + 1 | 0;
            // Inline function 'kotlin.time.Companion.milliseconds' call
            Companion_getInstance();
            var tmp$ret$3 = toDuration(backoff_0, DurationUnit_MILLISECONDS_getInstance());
            var tmp_4 = delay(tmp$ret$3, $completion);
            if (tmp_4 === get_COROUTINE_SUSPENDED())
              tmp_4 = yield tmp_4;
          } else {
            throw e_0;
          }
        } else {
          throw $p;
        }
      }
    }
  }
  return Unit_instance;
}
function KtorTransport$call$slambda$slambda_0($emittedAny, $this_flow) {
  var i = new KtorTransport$call$slambda$slambda($emittedAny, $this_flow);
  var l = (frame, $completion) => i.o6g(frame, $completion);
  l.$arity = 1;
  return l;
}
function KtorTransport$call$slambda$lambda($attempt, $call, $backoff, $httpError) {
  return () => 'transport retry ' + ($attempt._v + 1 | 0) + '/' + $call.l6l_1.s6g_1 + ' ' + ('after ' + $backoff.toString() + 'ms: HTTP ' + $httpError.a6m_1);
}
function KtorTransport$call$slambda$lambda_0($attempt, $call, $backoff, $e) {
  return () => 'transport retry ' + ($attempt._v + 1 | 0) + '/' + $call.l6l_1.s6g_1 + ' after ' + $backoff.toString() + 'ms: ' + $e.message;
}
function *_generator_invoke__zhh2q8_20($this, response, $completion) {
  if (!isSuccess(response.k37())) {
    var tmp = bodyAsText(response, VOID, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var err = tmp;
    var tmp_0 = response.k37().v2v_1;
    var tmp0_safe_receiver = contentType_0(response);
    $this.d6m_1._v = new HttpError(tmp_0, tmp0_safe_receiver == null ? null : tmp0_safe_receiver.toString(), err);
    return Unit_instance;
  }
  switch ($this.e6m_1.i6l_1.o3_1) {
    case 1:
      var tmp2_safe_receiver = contentType_0(response);
      var tmp_1 = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.toString();
      var tmp_2 = bodyAsText(response, VOID, $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      var tmp_3 = $this.f6m_1(new Body(tmp_1, tmp_2), $completion);
      if (tmp_3 === get_COROUTINE_SUSPENDED())
        tmp_3 = yield tmp_3;
      break;
    case 0:
      var tmp_4 = bodyAsChannel(response, $completion);
      if (tmp_4 === get_COROUTINE_SUSPENDED())
        tmp_4 = yield tmp_4;
      var tmp_5 = readSse(tmp_4, $this.e6m_1.k6l_1.j6m_1, $this.f6m_1, $completion);
      if (tmp_5 === get_COROUTINE_SUSPENDED())
        tmp_5 = yield tmp_5;
      break;
    case 2:
      var tmp_6 = bodyAsChannel(response, $completion);
      if (tmp_6 === get_COROUTINE_SUSPENDED())
        tmp_6 = yield tmp_6;
      var tmp_7 = readNdjson(tmp_6, $this.e6m_1.k6l_1.j6m_1, $this.f6m_1, $completion);
      if (tmp_7 === get_COROUTINE_SUSPENDED())
        tmp_7 = yield tmp_7;
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return Unit_instance;
}
function *_generator_limiterFor__528fvd($this, limit, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.z6l_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    // Inline function 'kotlin.collections.getOrPut' call
    var this_1 = $this.y6l_1;
    var value = this_1.h3(limit);
    var tmp_1;
    if (value == null) {
      var answer = new RateLimiter(limit);
      this_1.k3(limit, answer);
      tmp_1 = answer;
    } else {
      tmp_1 = value;
    }
    tmp_0 = tmp_1;
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function limiterFor($this, limit, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_limiterFor__528fvd.bind(VOID, $this, limit), $completion);
}
function *_generator_execute__d6syw1_1($this, call, onFrame, $completion) {
  var httpError = {_v: null};
  var tmp0 = $this.w6l_1;
  // Inline function 'io.ktor.client.request.prepareRequest' call
  var urlString = call.f6l_1;
  // Inline function 'io.ktor.client.request.prepareRequest' call
  // Inline function 'kotlin.apply' call
  var this_0 = new HttpRequestBuilder();
  url(this_0, urlString);
  this_0.c35_1 = toKtor(call.e6l_1);
  contentType(this_0, Application_getInstance().k2m_1);
  switch (call.i6l_1.o3_1) {
    case 0:
      accept(this_0, Companion_getInstance_3().ds('text/event-stream'));
      break;
    case 1:
    case 2:
      accept(this_0, Application_getInstance().k2m_1);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = call.g6l_1.l1().y();
  while (_iterator__ex2g4s.z()) {
    var _destruct__k2r9zo = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var k = _destruct__k2r9zo.m1();
    // Inline function 'kotlin.collections.component2' call
    var v = _destruct__k2r9zo.n1();
    header(this_0, k, v);
  }
  var tmp1_safe_receiver = call.j6l_1;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    header(this_0, 'Idempotency-Key', tmp1_safe_receiver);
  }
  var tmp2_safe_receiver = call.h6l_1;
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'io.ktor.client.request.setBody' call
    if (tmp2_safe_receiver == null) {
      this_0.e35_1 = NullBody_instance;
      // Inline function 'io.ktor.util.reflect.typeInfo' call
      var tmp = PrimitiveClasses_getInstance().ng();
      // Inline function 'io.ktor.util.reflect.typeOfOrNull' call
      var tmp_0;
      try {
        tmp_0 = createKType(PrimitiveClasses_getInstance().ng(), arrayOf([]), false);
      } catch ($p) {
        var tmp_1;
        if ($p instanceof Error) {
          var _unused_var__etf5q3 = $p;
          tmp_1 = null;
        } else {
          throw $p;
        }
        tmp_0 = tmp_1;
      }
      var tmp$ret$5 = tmp_0;
      var tmp$ret$6 = new TypeInfo(tmp, tmp$ret$5);
      this_0.p39(tmp$ret$6);
    } else {
      if (tmp2_safe_receiver instanceof OutgoingContent) {
        this_0.e35_1 = tmp2_safe_receiver;
        this_0.p39(null);
      } else {
        this_0.e35_1 = tmp2_safe_receiver;
        // Inline function 'io.ktor.util.reflect.typeInfo' call
        var tmp_2 = PrimitiveClasses_getInstance().ng();
        // Inline function 'io.ktor.util.reflect.typeOfOrNull' call
        var tmp_3;
        try {
          tmp_3 = createKType(PrimitiveClasses_getInstance().ng(), arrayOf([]), false);
        } catch ($p) {
          var tmp_4;
          if ($p instanceof Error) {
            var _unused_var__etf5q3_0 = $p;
            tmp_4 = null;
          } else {
            throw $p;
          }
          tmp_3 = tmp_4;
        }
        var tmp$ret$7 = tmp_3;
        var tmp$ret$8 = new TypeInfo(tmp_2, tmp$ret$7);
        this_0.p39(tmp$ret$8);
      }
    }
  }
  timeout(this_0, KtorTransport$execute$lambda(call));
  // Inline function 'io.ktor.client.request.prepareRequest' call
  var stmt = new HttpStatement(this_0, tmp0);
  var tmp_5 = stmt.g3k(KtorTransport$execute$slambda_0(httpError, call, onFrame), $completion);
  if (tmp_5 === get_COROUTINE_SUSPENDED())
    tmp_5 = yield tmp_5;
  return httpError._v;
}
function execute_0($this, call, onFrame, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_execute__d6syw1_1.bind(VOID, $this, call, onFrame), $completion);
}
function KtorTransport$_init_$lambda_gsh77y($this$HttpClient) {
  $this$HttpClient.z35(get_HttpTimeout());
  return Unit_instance;
}
function KtorTransport$logger$lambda() {
  return Unit_instance;
}
function KtorTransport$call$slambda_0($call, this$0) {
  var i = new KtorTransport$call$slambda($call, this$0);
  var l = ($this$flow, $completion) => i.k6m($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function KtorTransport$execute$lambda($call) {
  return ($this$timeout) => {
    $this$timeout.t3g($call.k6l_1.h6m_1);
    $this$timeout.u3g($call.k6l_1.g6m_1);
    $this$timeout.v3g($call.k6l_1.i6m_1);
    return Unit_instance;
  };
}
function KtorTransport$execute$slambda_0($httpError, $call, $onFrame) {
  var i = new KtorTransport$execute$slambda($httpError, $call, $onFrame);
  var l = (response, $completion) => i.o3b(response, $completion);
  l.$arity = 1;
  return l;
}
function isRetriableStatus(_this__u8e3s4) {
  switch (_this__u8e3s4) {
    case 408:
    case 429:
      return true;
    default:
      return _this__u8e3s4 >= 500;
  }
}
function isRetriableTransportFailure(_this__u8e3s4) {
  var tmp;
  var tmp_0;
  if (!(_this__u8e3s4 instanceof TransportException)) {
    tmp_0 = true;
  } else {
    tmp_0 = _this__u8e3s4.n6m_1 == null;
  }
  if (tmp_0) {
    tmp = true;
  } else {
    tmp = isRetriableStatus(_this__u8e3s4.n6m_1);
  }
  return tmp;
}
function toKtor(_this__u8e3s4) {
  var tmp;
  switch (_this__u8e3s4.o3_1) {
    case 0:
      tmp = Companion_getInstance_2().b2t_1;
      break;
    case 1:
      tmp = Companion_getInstance_2().c2t_1;
      break;
    case 2:
      tmp = Companion_getInstance_2().d2t_1;
      break;
    case 3:
      tmp = Companion_getInstance_2().e2t_1;
      break;
    case 4:
      tmp = Companion_getInstance_2().f2t_1;
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function *_generator_readSse__9pfbet(channel, idleTimeoutMs, onFrame, $completion) {
  var event = {_v: null};
  var id = {_v: null};
  var data = StringBuilder.v();
  var hasData = {_v: false};
  $l$loop: while (!channel.e1q()) {
    var tmp = readStreamLine(channel, idleTimeoutMs, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var tmp0_elvis_lhs = tmp;
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      break $l$loop;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var line = tmp_0;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(line) === 0) {
      var tmp_1 = readSse$flush(hasData, event, id, onFrame, data, $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
    } else {
      if (!startsWith_0(line, ':')) {
        if (startsWith_0(line, 'event:')) {
          // Inline function 'kotlin.text.trim' call
          var this_0 = removePrefix(line, 'event:');
          event._v = toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
        } else {
          if (startsWith_0(line, 'id:')) {
            // Inline function 'kotlin.text.trim' call
            var this_1 = removePrefix(line, 'id:');
            id._v = toString(trim(isCharSequence(this_1) ? this_1 : THROW_CCE()));
          } else {
            if (startsWith_0(line, 'data:')) {
              if (hasData._v) {
                data.ub(_Char___init__impl__6a9atx(10));
              }
              // Inline function 'kotlin.text.trimStart' call
              var this_2 = removePrefix(line, 'data:');
              var tmp$ret$3 = toString(trimStart(isCharSequence(this_2) ? this_2 : THROW_CCE()));
              data.tb(tmp$ret$3);
              hasData._v = true;
            }
          }
        }
      }
    }
  }
  var tmp_2 = readSse$flush(hasData, event, id, onFrame, data, $completion);
  if (tmp_2 === get_COROUTINE_SUSPENDED())
    tmp_2 = yield tmp_2;
  return Unit_instance;
}
function readSse(channel, idleTimeoutMs, onFrame, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readSse__9pfbet.bind(VOID, channel, idleTimeoutMs, onFrame), $completion);
}
function *_generator_readNdjson__gw3r9o(channel, idleTimeoutMs, onFrame, $completion) {
  $l$loop: while (!channel.e1q()) {
    var tmp = readStreamLine(channel, idleTimeoutMs, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var tmp0_elvis_lhs = tmp;
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      break $l$loop;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var line = tmp_0;
    // Inline function 'kotlin.text.isNotBlank' call
    if (!isBlank(line)) {
      var tmp_1 = onFrame(new Ndjson(line), $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
    }
  }
  return Unit_instance;
}
function readNdjson(channel, idleTimeoutMs, onFrame, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readNdjson__gw3r9o.bind(VOID, channel, idleTimeoutMs, onFrame), $completion);
}
function *_generator_readStreamLine__pukooy(channel, idleTimeoutMs, $completion) {
  // Inline function 'kotlin.require' call
  if (!(idleTimeoutMs.s1(new Long(0, 0)) > 0)) {
    var message = 'idleTimeoutMs must be positive';
    throw IllegalArgumentException.t(toString(message));
  }
  var tmp = withTimeoutOrNull(idleTimeoutMs, readStreamLine$slambda_0(channel), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp0_elvis_lhs = tmp;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    throw StreamIdleTimeoutException.q6m(idleTimeoutMs);
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var result = tmp_0;
  return result.r6m_1;
}
function readStreamLine(channel, idleTimeoutMs, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readStreamLine__pukooy.bind(VOID, channel, idleTimeoutMs), $completion);
}
function *_generator_readSse$flush__xxu2n9(hasData, event, id, $onFrame, data, $completion) {
  if (!hasData._v && event._v == null && id._v == null)
    return Unit_instance;
  var tmp = $onFrame(new Sse(event._v, data.toString(), id._v), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  event._v = null;
  id._v = null;
  data.jh();
  hasData._v = false;
  return Unit_instance;
}
function readSse$flush(hasData, event, id, $onFrame, data, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readSse$flush__xxu2n9.bind(VOID, hasData, event, id, $onFrame, data), $completion);
}
function *_generator_invoke__zhh2q8_21($this, $this$withTimeoutOrNull, $completion) {
  var tmp = readUTF8Line($this.s6m_1, VOID, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return new StreamLine(tmp);
}
function readStreamLine$slambda_0($channel) {
  var i = new readStreamLine$slambda($channel);
  var l = ($this$withTimeoutOrNull, $completion) => i.r1f($this$withTimeoutOrNull, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_acquire__4kqfvm($this, $completion) {
  while (true) {
    // Inline function 'kotlinx.coroutines.sync.withLock' call
    var this_0 = $this.q6l_1;
    var tmp = this_0.c1i(null, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var tmp_0;
    try {
      refill($this);
      var tmp_1;
      if ($this.s6l_1 >= 1.0) {
        $this.s6l_1 = $this.s6l_1 - 1.0;
        tmp_1 = new Long(0, 0);
      } else {
        tmp_1 = coerceAtLeast_0(numberToLong((1.0 - $this.s6l_1) / $this.u6l_1), new Long(1, 0));
      }
      tmp_0 = tmp_1;
    }finally {
      this_0.n1h(null);
    }
    var waitMs = tmp_0;
    if (waitMs.equals(new Long(0, 0)))
      return Unit_instance;
    // Inline function 'kotlin.time.Companion.milliseconds' call
    Companion_getInstance();
    var tmp$ret$2 = toDuration(waitMs, DurationUnit_MILLISECONDS_getInstance());
    var tmp_2 = delay(tmp$ret$2, $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
  }
  return Unit_instance;
}
function refill($this) {
  var nowMs = _Duration___get_inWholeMilliseconds__impl__msfiry(ValueTimeMark__elapsedNow_impl_eonqvs($this.r6l_1));
  var elapsed = nowMs.v3($this.t6l_1);
  if (elapsed.s1(new Long(0, 0)) > 0) {
    var tmp = $this;
    var tmp_0 = $this.s6l_1;
    // Inline function 'kotlin.Long.times' call
    var other = $this.u6l_1;
    var tmp$ret$0 = elapsed.m4() * other;
    tmp.s6l_1 = coerceAtMost(tmp_0 + tmp$ret$0, $this.p6l_1.t6m_1);
    $this.t6l_1 = nowMs;
  }
}
var HttpMethod_GET_instance;
var HttpMethod_POST_instance;
var HttpMethod_PUT_instance;
var HttpMethod_PATCH_instance;
var HttpMethod_DELETE_instance;
var HttpMethod_entriesInitialized;
function HttpMethod_initEntries() {
  if (HttpMethod_entriesInitialized)
    return Unit_instance;
  HttpMethod_entriesInitialized = true;
  HttpMethod_GET_instance = new HttpMethod('GET', 0);
  HttpMethod_POST_instance = new HttpMethod('POST', 1);
  HttpMethod_PUT_instance = new HttpMethod('PUT', 2);
  HttpMethod_PATCH_instance = new HttpMethod('PATCH', 3);
  HttpMethod_DELETE_instance = new HttpMethod('DELETE', 4);
}
var Framing_Sse_instance;
var Framing_Json_instance;
var Framing_Ndjson_instance;
var Framing_entriesInitialized;
function Framing_initEntries() {
  if (Framing_entriesInitialized)
    return Unit_instance;
  Framing_entriesInitialized = true;
  Framing_Sse_instance = new Framing('Sse', 0);
  Framing_Json_instance = new Framing('Json', 1);
  Framing_Ndjson_instance = new Framing('Ndjson', 2);
}
function HttpMethod_GET_getInstance() {
  HttpMethod_initEntries();
  return HttpMethod_GET_instance;
}
function HttpMethod_POST_getInstance() {
  HttpMethod_initEntries();
  return HttpMethod_POST_instance;
}
function Framing_Sse_getInstance() {
  Framing_initEntries();
  return Framing_Sse_instance;
}
function Framing_Json_getInstance() {
  Framing_initEntries();
  return Framing_Json_instance;
}
function Framing_Ndjson_getInstance() {
  Framing_initEntries();
  return Framing_Ndjson_instance;
}
function JsonUtil$json$lambda($this$Json) {
  $this$Json.s3m_1 = true;
  $this$Json.q3m_1 = true;
  $this$Json.t3m_1 = true;
  $this$Json.u3m_1 = false;
  $this$Json.r3m_1 = false;
  return Unit_instance;
}
var JsonUtil_instance;
function JsonUtil_getInstance() {
  if (JsonUtil_instance === VOID)
    new JsonUtil();
  return JsonUtil_instance;
}
function get_logger() {
  _init_properties_AgentRuntime_kt__s2akoj();
  return logger;
}
var logger;
function *_generator_invoke__zhh2q8_22($this, envelope, $completion) {
  var payload = envelope.i6n_1;
  if (payload instanceof Agent_0) {
    var tmp = $this.s6n_1.t1c(payload.t6n_1, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  } else {
    if (payload instanceof HistoryGap)
      throw RunEventHistoryGapException.r6n(payload.j6n_1, payload.k6n_1);
    else {
      if (!(payload instanceof Lifecycle)) {
        noWhenBranchMatchedException();
      }
    }
  }
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_23($this, $this$flow, $completion) {
  var handle = $this.u6n_1.w6o($this.v6n_1, $this.w6n_1, $this.x6n_1, $this.y6n_1, $this.z6n_1, $this.a6o_1, $this.b6o_1);
  try {
    var tmp = handle.j6p();
    var tmp_0 = AgentRuntime$stream$slambda$slambda_0($this$flow);
    var tmp_1 = tmp.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_4(tmp_0), $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
  }finally {
    if (handle.su() || !handle.k6p().n6p()) {
      var tmp_2 = cancelAndJoin($this.u6n_1, handle, 'runtime stream collection stopped', $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
    }
  }
  return Unit_instance;
}
function AgentRuntime$stream$slambda$slambda_0($this_flow) {
  var i = new AgentRuntime$stream$slambda$slambda($this_flow);
  var l = (envelope, $completion) => i.o6p(envelope, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_24($this, envelope, $completion) {
  var payload = envelope.i6n_1;
  if (payload instanceof Agent_0) {
    var tmp = $this.p6p_1.t1c(payload.t6n_1, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  } else {
    if (payload instanceof HistoryGap)
      throw RunEventHistoryGapException.r6n(payload.j6n_1, payload.k6n_1);
    else {
      if (!(payload instanceof Lifecycle)) {
        noWhenBranchMatchedException();
      }
    }
  }
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_25($this, $this$flow, $completion) {
  var handle = $this.q6p_1.x6p($this.r6p_1, $this.s6p_1, $this.t6p_1, $this.u6p_1, $this.v6p_1, $this.w6p_1);
  try {
    var tmp = handle.j6p();
    var tmp_0 = AgentRuntime$resume$slambda$slambda_0($this$flow);
    var tmp_1 = tmp.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_5(tmp_0), $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
  }finally {
    if (handle.su() || !handle.k6p().n6p()) {
      var tmp_2 = cancelAndJoin($this.q6p_1, handle, 'runtime resume collection stopped', $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
    }
  }
  return Unit_instance;
}
function AgentRuntime$resume$slambda$slambda_0($this_flow) {
  var i = new AgentRuntime$resume$slambda$slambda($this_flow);
  var l = (envelope, $completion) => i.o6p(envelope, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_26($this, $this$async, $completion) {
  var tmp;
  try {
    var tmp0_elvis_lhs = $this.a6q_1;
    var tmp_0;
    var tmp_1 = tmp0_elvis_lhs;
    if ((tmp_1 == null ? null : new RunId(tmp_1)) == null) {
      tmp_0 = $this.b6q_1;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var refs = resolveContextPrefix($this.y6p_1, $this.z6p_1, tmp_0);
    var tmp_2 = runInstance($this.y6p_1, $this.c6q_1, $this.d6q_1, $this.e6q_1, refs, $this.f6q_1, $this.g6q_1, $this.h6q_1, $this.i6q_1, $this.j6q_1, $this.k6q_1, $this.l6q_1, $this.m6q_1, $this.n6q_1, $this.o6q_1._v, $this.p6q_1, $this.q6q_1, $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    tmp = tmp_2;
  } catch ($p) {
    var tmp_3;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      throw cancelled;
    } else {
      if ($p instanceof Error) {
        var failure = $p;
        var snapshot = $this.f6q_1.w6q();
        if (!snapshot.c6r_1.n6p()) {
          var tmp1_elvis_lhs = failure.message;
          var error = new ModelError(tmp1_elvis_lhs == null ? 'runtime instance failed unexpectedly' : tmp1_elvis_lhs, false, failure);
          $this.f6q_1.n6r(error, snapshot.i6r_1);
          emit($this.y6p_1, new Failed_4($this.b6q_1, $this.d6q_1.i5m_1, $this.k6q_1, $this.l6q_1, error));
          cancelDescendants($this.y6p_1, $this.b6q_1, 'parent ' + RunId__toString_impl_q8god7($this.b6q_1) + ' failed');
        }
        throw failure;
      } else {
        throw $p;
      }
    }
  }
  return tmp;
}
function *_generator_invoke__zhh2q8_27($this, lease, $completion) {
  var tmp = $this.o6r_1.o6s(lease, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  $this.p6r_1.p6s();
  emit($this.q6r_1, new Running($this.p6r_1.r6q_1, $this.r6r_1.i5m_1, $this.s6r_1, $this.t6r_1, $this.r6r_1.j5m_1));
  // Inline function 'kotlin.takeUnless' call
  var this_0 = $this.u6r_1;
  var tmp_0;
  if (!$this.v6r_1) {
    tmp_0 = this_0;
  } else {
    tmp_0 = null;
  }
  var tmp_1 = tmp_0;
  var tmp_2 = runWithQuota($this.q6r_1, $this.r6r_1, tmp_1, $this.w6r_1, $this.p6r_1, $this.x6r_1, $this.y6r_1, $this.z6r_1, $this.a6s_1, $this.b6s_1, AgentRuntime$runInstance$slambda$lambda($this.c6s_1), $completion);
  if (tmp_2 === get_COROUTINE_SUSPENDED())
    tmp_2 = yield tmp_2;
  return tmp_2;
}
function AgentRuntime$runInstance$slambda$lambda($terminalUsage) {
  return (usage) => {
    $terminalUsage._v = usage;
    return Unit_instance;
  };
}
function *_generator_invoke__zhh2q8_28($this, $this$withContext, $completion) {
  var tmp = commitTurn$default($this.r6s_1, $this.s6s_1._v, $this.t6s_1, true, VOID, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  $this.q6s_1._v = tmp;
  $this.u6s_1.z6s($this.v6s_1.e5t_1);
  emit($this.r6s_1, new Finished_0($this.u6s_1.r6q_1, $this.w6s_1.i5m_1, $this.x6s_1, $this.y6s_1, $this.v6s_1.e5t_1));
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_29($this, $this$withContext, $completion) {
  var tmp = commitTurn($this.b6t_1, $this.c6t_1._v, $this.d6t_1, false, new Incomplete_1($this.e6t_1.i5t_1), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  $this.a6t_1._v = tmp;
  $this.f6t_1.z6s($this.e6t_1.h5t_1);
  emit($this.b6t_1, new Incomplete_3($this.f6t_1.r6q_1, $this.g6t_1.i5m_1, $this.h6t_1, $this.i6t_1, $this.e6t_1.i5t_1, $this.e6t_1.h5t_1));
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_30($this, $this$withContext, $completion) {
  var tmp = commitTurn($this.k6t_1, $this.l6t_1._v, $this.m6t_1, false, new Policy(toString($this.n6t_1.l5t_1)), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  $this.j6t_1._v = tmp;
  $this.o6t_1.z6s($this.n6t_1.k5t_1);
  emit($this.k6t_1, new Terminated_1($this.o6t_1.r6q_1, $this.p6t_1.i5m_1, $this.q6t_1, $this.r6t_1, $this.n6t_1.l5t_1));
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_31($this, $this$withContext, $completion) {
  var tmp = commitTurn($this.t6t_1, $this.u6t_1._v, $this.v6t_1, false, Failed_instance, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  $this.s6t_1._v = tmp;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_32($this, $this$withContext, $completion) {
  var tmp0_safe_receiver = $this.w6t_1;
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e6u_1;
  var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.e61();
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.runCatching' call
    var tmp;
    try {
      var tmp_0 = $this.x6t_1.l5m_1.o6c(tmp2_safe_receiver, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      // Inline function 'kotlin.Companion.success' call
      tmp = _Result___init__impl__xyqfz8(Unit_instance);
    } catch ($p) {
      var tmp_1;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp = tmp_1;
    }
    var tmp$ret$5 = tmp;
    new Result(tmp$ret$5);
  }
  var tmp_2 = commitTurn($this.z6t_1, $this.a6u_1._v, $this.w6t_1, false, Cancelled_instance, $completion);
  if (tmp_2 === get_COROUTINE_SUSPENDED())
    tmp_2 = yield tmp_2;
  $this.y6t_1._v = tmp_2;
  var tmp_3 = awaitChildren($this.z6t_1, $this.b6u_1.r6q_1, false, false, $completion);
  if (tmp_3 === get_COROUTINE_SUSPENDED())
    tmp_3 = yield tmp_3;
  return tmp_3;
}
function *_generator_invoke__zhh2q8_33($this, $this$withContext, $completion) {
  var tmp = commitTurn($this.j6u_1, $this.k6u_1._v, $this.l6u_1, false, Failed_instance, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  $this.i6u_1._v = tmp;
  var tmp_0 = awaitChildren($this.j6u_1, $this.m6u_1.r6q_1, false, false, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return tmp_0;
}
function *_generator_invoke__zhh2q8_34($this, $this$withContext, $completion) {
  var lease = $this.n6u_1._v;
  if (!(lease == null)) {
    var tmp;
    if (!$this.o6u_1._v) {
      var tmp0_safe_receiver = $this.p6u_1;
      tmp = (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.z61()) === true;
    } else {
      tmp = false;
    }
    if (tmp) {
      var tmp_0 = get_logger();
      tmp_0.c5l(AgentRuntime$runInstance$slambda$lambda_0(lease));
      var tmp_1 = lease.w6u();
      var tmp_2 = $this.t6u_1;
      // Inline function 'kotlin.requireNotNull' call
      var tmp0 = tmp_2 == null ? null : new TurnId(tmp_2);
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.requireNotNull' call
        if (tmp0 == null) {
          var message = 'Required value was null.';
          throw IllegalArgumentException.t(toString(message));
        } else {
          tmp$ret$1 = tmp0;
          break $l$block;
        }
      }
      var tmp$ret$2 = tmp$ret$1.x6u_1;
      emit($this.q6u_1, new SideEffectRollback($this.r6u_1.r6q_1, $this.s6u_1.i5m_1, tmp_1, tmp$ret$2));
    }
    var tmp_3 = lease.y6u($completion);
    if (tmp_3 === get_COROUTINE_SUSPENDED())
      tmp_3 = yield tmp_3;
  }
  return Unit_instance;
}
function AgentRuntime$runInstance$slambda$lambda_0($lease) {
  return () => 'thread ' + _ThreadId___get_value__impl__tytyxc($lease.w6u()) + ': side-effecting turn was rolled back';
}
function *_generator_invoke__zhh2q8_35($this, event, $completion) {
  if ($this.z6u_1.q6v()) {
    $this.a6v_1.n6v(LifecycleState_SUSPENDED_getInstance());
    emit($this.b6v_1, new Suspended($this.a6v_1.r6q_1, $this.c6v_1.i5m_1, $this.a6v_1.w6q().a6r_1, $this.a6v_1.w6q().b6r_1));
    var tmp = $this.z6u_1.p6v($completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    $this.a6v_1.p6s();
    emit($this.b6v_1, new Resumed($this.a6v_1.r6q_1, $this.c6v_1.i5m_1, $this.a6v_1.w6q().a6r_1, $this.a6v_1.w6q().b6r_1));
  }
  var tmp_0 = $this.d6v_1.r6v(event, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  $this.a6v_1.s6v(event);
  if (event instanceof TextDelta)
    $this.e6v_1.tb(event.b5r_1);
  else {
    if (event instanceof ToolCallRequested) {
      var _unary__edvuaz = $this.f6v_1._v;
      $this.f6v_1._v = _unary__edvuaz + 1 | 0;
      if (!($this.g6v_1.u6v_1 == null) && $this.f6v_1._v > $this.g6v_1.u6v_1) {
        throw QuotaSignal.c6w('maxToolCalls=' + $this.g6v_1.u6v_1);
      }
    } else {
      if (event instanceof StepCompleted) {
        var _unary__edvuaz_0 = $this.h6v_1._v;
        $this.h6v_1._v = _unary__edvuaz_0 + 1 | 0;
        $this.i6v_1._v = $this.e6v_1.toString();
        $this.e6v_1.jh();
        if (!($this.g6v_1.t6v_1 == null) && $this.h6v_1._v >= $this.g6v_1.t6v_1) {
          throw QuotaSignal.c6w('maxSteps=' + $this.g6v_1.t6v_1);
        }
      } else {
        if (isInterface(event, Terminal)) {
          $this.j6v_1._v = event;
          $this.k6v_1._v = event.k5r();
          $this.l6v_1($this.k6v_1._v);
        } else {
          if (event instanceof Failed) {
            $this.m6v_1._v = event.u5r_1;
            if (!event.v5r_1.equals(Companion_getInstance_43().t5r_1)) {
              $this.k6v_1._v = event.v5r_1;
            }
          }
        }
      }
    }
  }
  return Unit_instance;
}
function AgentRuntime$spawnSupervised$slambda$lambda($latest, this$0, $agent, $thread) {
  return (attempt, delayMillis) => {
    var current = $latest.n1();
    var tmp = current == null ? null : current.x6o_1;
    var tmp2_elvis_lhs = current == null ? null : current.z6o_1;
    var tmp_0;
    var tmp_1 = tmp2_elvis_lhs;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = $thread;
    } else {
      tmp_0 = tmp2_elvis_lhs;
    }
    var tmp_2 = tmp_0;
    emit(this$0, new Retrying(tmp, $agent.i5m_1, $agent.j5m_1, tmp_2, current == null ? null : current.a6p_1, attempt, delayMillis));
    return Unit_instance;
  };
}
function AgentRuntime$spawnSupervised$slambda$lambda_0($latest, this$0, $agent, $thread) {
  return () => {
    var current = $latest.n1();
    var tmp = current == null ? null : current.x6o_1;
    var tmp2_elvis_lhs = current == null ? null : current.z6o_1;
    var tmp_0;
    var tmp_1 = tmp2_elvis_lhs;
    if ((tmp_1 == null ? null : new ThreadId(tmp_1)) == null) {
      tmp_0 = $thread;
    } else {
      tmp_0 = tmp2_elvis_lhs;
    }
    var tmp_2 = tmp_0;
    emit(this$0, new CircuitOpen(tmp, $agent.i5m_1, $agent.j5m_1, tmp_2, current == null ? null : current.a6p_1));
    return Unit_instance;
  };
}
function AgentRuntime$spawnSupervised$slambda$slambda_0(this$0, $agent, $priority, $quota, $contextRefs, $thread, $latest) {
  var i = new AgentRuntime$spawnSupervised$slambda$slambda(this$0, $agent, $priority, $quota, $contextRefs, $thread, $latest);
  var l = (attemptInput, $completion) => i.k6w(attemptInput, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_36($this, $this$launch, $completion) {
  try {
    // Inline function 'kotlin.collections.associateWith' call
    var this_0 = $this.r6w_1.p6w_1;
    var result = LinkedHashMap.ic(coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16));
    // Inline function 'kotlin.collections.associateWithTo' call
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp = getValue($this.s6w_1, element).vw($completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
      var tmp$ret$0 = tmp;
      result.k3(element, tmp$ret$0);
    }
    var deps = result;
    var tmp_0 = $this.r6w_1.q6w_1(deps, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    var tmp_1 = $this.t6w_1.u6w($this.r6w_1.n6w_1, tmp_0, $this.r6w_1.o6w_1, VOID, VOID, VOID, VOID, $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    var result_0 = tmp_1;
    getValue($this.s6w_1, $this.r6w_1.m6w_1).z11(result_0);
  } catch ($p) {
    if ($p instanceof Error) {
      var failure = $p;
      getValue($this.s6w_1, $this.r6w_1.m6w_1).a12(failure);
      throw failure;
    } else {
      throw $p;
    }
  }
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_37($this, $this$coroutineScope, $completion) {
  // Inline function 'kotlin.collections.associate' call
  var this_0 = $this.w6w_1.v6w_1;
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
  // Inline function 'kotlin.collections.associateTo' call
  var destination = LinkedHashMap.ic(capacity);
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.plusAssign' call
    var pair = to(element.m6w_1, CompletableDeferred());
    destination.k3(pair.rl_1, pair.sl_1);
  }
  var results = destination;
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_0 = $this.w6w_1.v6w_1.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    launch($this$coroutineScope, VOID, VOID, AgentRuntime$submit$slambda$slambda_0(element_0, results, $this.x6w_1));
  }
  // Inline function 'kotlin.collections.mapValues' call
  // Inline function 'kotlin.collections.mapValuesTo' call
  var destination_0 = LinkedHashMap.ic(mapCapacity(results.b1()));
  // Inline function 'kotlin.collections.associateByTo' call
  var _iterator__ex2g4s_1 = results.l1().y();
  while (_iterator__ex2g4s_1.z()) {
    var element_1 = _iterator__ex2g4s_1.a1();
    var tmp = element_1.m1();
    var tmp_0 = element_1.n1().vw($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    var tmp$ret$7 = tmp_0;
    destination_0.k3(tmp, tmp$ret$7);
  }
  return destination_0;
}
function AgentRuntime$submit$slambda$slambda_0($node, $results, this$0) {
  var i = new AgentRuntime$submit$slambda$slambda($node, $results, this$0);
  var l = ($this$launch, $completion) => i.r1f($this$launch, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_38($this, $this$withContext, $completion) {
  var tmp = $this.y6w_1.yv($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
var Companion_instance_44;
function Companion_getInstance_48() {
  return Companion_instance_44;
}
function emit($this, event) {
  var tmp0_safe_receiver = runIdOrNull(event);
  var tmp = tmp0_safe_receiver;
  if ((tmp == null ? null : new RunId(tmp)) == null)
    null;
  else {
    var tmp_0 = tmp0_safe_receiver;
    // Inline function 'kotlin.let' call
    var id = (tmp_0 == null ? null : new RunId(tmp_0)).z6w_1;
    var tmp0_safe_receiver_0 = $this.s6o_1.n1().h3(new RunId(id));
    var tmp_1;
    if (tmp0_safe_receiver_0 == null) {
      tmp_1 = null;
    } else {
      tmp0_safe_receiver_0.h6x(new Lifecycle(event));
      tmp_1 = Unit_instance;
    }
  }
  $this.k6o_1.t1d(event);
}
function acquireRegistration($this, agent) {
  while (true) {
    var current = $this.t6o_1.n1();
    var registered = current.h3(new AgentId(agent.i5m_1));
    if (registered == null) {
      var next = plus_1(current, to(new AgentId(agent.i5m_1), new AgentRegistration(agent.z5m_1, agent.j5m_1, 1, new Long(1, 0))));
      if ($this.t6o_1.u1e(current, next))
        return Unit_instance;
    } else if (!registered.i6x_1.equals(agent.z5m_1))
      throw AgentIdConflictException.s6x(agent.i5m_1);
    else {
      var next_0 = plus_1(current, to(new AgentId(agent.i5m_1), registered.m6x(VOID, VOID, registered.k6x_1 + 1 | 0)));
      if ($this.t6o_1.u1e(current, next_0))
        return Unit_instance;
    }
  }
}
function releaseRegistration($this, agent) {
  while (true) {
    var current = $this.t6o_1.n1();
    var tmp0_elvis_lhs = current.h3(new AgentId(agent.i5m_1));
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return Unit_instance;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var registered = tmp;
    if (!registered.i6x_1.equals(agent.z5m_1) || registered.k6x_1 === 0)
      return Unit_instance;
    var next = plus_1(current, to(new AgentId(agent.i5m_1), registered.m6x(VOID, VOID, registered.k6x_1 - 1 | 0)));
    if ($this.t6o_1.u1e(current, next))
      return Unit_instance;
  }
}
function *_generator_run__cb7u2f($this, agent, input, priority, quota, contextRefs, thread, correlationId, $completion) {
  var handle = $this.w6o(agent, input, priority, quota, contextRefs, thread, correlationId);
  var tmp;
  try {
    var tmp_0 = handle.vw($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      var tmp0_elvis_lhs = cancelled.message;
      var tmp_2 = cancelAndJoin($this, handle, tmp0_elvis_lhs == null ? 'runtime run cancelled' : tmp0_elvis_lhs, $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      throw cancelled;
    } else {
      throw $p;
    }
  }
  return tmp;
}
function *_generator_runStructured__srdzi0_0($this, agent, input, spec, priority, quota, contextRefs, thread, correlationId, $completion) {
  var handle = $this.t6x(agent, input, spec, priority, quota, contextRefs, thread, correlationId);
  var tmp;
  try {
    var tmp_0 = handle.vw($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      var tmp0_elvis_lhs = cancelled.message;
      var tmp_2 = cancelAndJoin($this, handle, tmp0_elvis_lhs == null ? 'runtime structured run cancelled' : tmp0_elvis_lhs, $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      throw cancelled;
    } else {
      throw $p;
    }
  }
  return tmp;
}
function *_generator_resumeRun__lr1b9y($this, agent, thread, priority, quota, contextRefs, correlationId, $completion) {
  var handle = $this.x6p(agent, thread, priority, quota, contextRefs, correlationId);
  var tmp;
  try {
    var tmp_0 = handle.vw($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      var tmp0_elvis_lhs = cancelled.message;
      var tmp_2 = cancelAndJoin($this, handle, tmp0_elvis_lhs == null ? 'runtime resume cancelled' : tmp0_elvis_lhs, $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      throw cancelled;
    } else {
      throw $p;
    }
  }
  return tmp;
}
function spawnInternal($this, agent, input, priority, quota, parent, contextRefs, thread, structuredSpec, inheritedTurnContext, childConversation, failurePolicy, correlationId, resume) {
  // Inline function 'kotlin.check' call
  if (!!$this.v6o_1.n1()) {
    var message = 'AgentRuntime is closed';
    throw IllegalStateException.t4(toString(message));
  }
  var tmp;
  if (correlationId == null) {
    tmp = true;
  } else {
    // Inline function 'kotlin.text.isNotBlank' call
    tmp = !isBlank(correlationId);
  }
  // Inline function 'kotlin.require' call
  if (!tmp) {
    var message_0 = 'correlationId must not be blank';
    throw IllegalArgumentException.t(toString(message_0));
  }
  var tmp_0;
  var tmp_1 = parent;
  if ((tmp_1 == null ? null : new RunId(tmp_1)) == null) {
    tmp_0 = null;
  } else {
    var tmp_2 = parent;
    // Inline function 'kotlin.let' call
    var parentId = (tmp_2 == null ? null : new RunId(tmp_2)).z6w_1;
    var tmp0_elvis_lhs = $this.q6o_1.n1().h3(new RunId(parentId));
    var tmp_3;
    if (tmp0_elvis_lhs == null) {
      var message_1 = "parent run '" + _RunId___get_value__impl__30zeiv(parentId).toString() + "' does not exist in this runtime";
      throw IllegalStateException.t4(toString(message_1));
    } else {
      tmp_3 = tmp0_elvis_lhs;
    }
    tmp_0 = tmp_3;
  }
  var parentAcb = tmp_0;
  var parentSnapshot = parentAcb == null ? null : parentAcb.w6q();
  if (!(parentSnapshot == null)) {
    // Inline function 'kotlin.check' call
    if (!!parentSnapshot.c6r_1.n6p()) {
      var message_2 = "cannot spawn a child from terminal parent run '" + _RunId___get_value__impl__30zeiv(parentSnapshot.x6q_1).toString() + "'";
      throw IllegalStateException.t4(toString(message_2));
    }
  }
  var tmp_4;
  if (parentSnapshot == null) {
    tmp_4 = thread;
  } else {
    if (equals(childConversation, Inherit_instance)) {
      tmp_4 = parentSnapshot.a6r_1;
    } else {
      if (equals(childConversation, Ephemeral_instance)) {
        tmp_4 = null;
      } else {
        if (childConversation instanceof Thread) {
          var tmp_5 = parentSnapshot.a6r_1;
          // Inline function 'kotlin.require' call
          if (!!equals(new ThreadId(childConversation.u6x_1), tmp_5 == null ? null : new ThreadId(tmp_5))) {
            var message_3 = "child conversation thread '" + _ThreadId___get_value__impl__tytyxc(childConversation.u6x_1) + "' is the parent's active thread; " + 'use ChildConversation.Inherit';
            throw IllegalArgumentException.t(toString(message_3));
          }
          tmp_4 = childConversation.u6x_1;
        } else {
          var message_4 = 'child spawn requires an explicit ChildConversation';
          throw IllegalStateException.t4(toString(message_4));
        }
      }
    }
  }
  var effectiveThread = tmp_4;
  var tmp_6;
  var tmp_7;
  var tmp_8;
  if (!(parentSnapshot == null) && equals(childConversation, Inherit_instance)) {
    var tmp_9 = effectiveThread;
    tmp_8 = !((tmp_9 == null ? null : new ThreadId(tmp_9)) == null);
  } else {
    tmp_8 = false;
  }
  if (tmp_8) {
    var tmp_10 = effectiveThread;
    var tmp_11 = tmp_10 == null ? null : new ThreadId(tmp_10);
    var tmp_12 = parentSnapshot.a6r_1;
    tmp_7 = equals(tmp_11, tmp_12 == null ? null : new ThreadId(tmp_12));
  } else {
    tmp_7 = false;
  }
  if (tmp_7) {
    var tmp_13 = parentSnapshot.b6r_1;
    tmp_6 = !((tmp_13 == null ? null : new TurnId(tmp_13)) == null);
  } else {
    tmp_6 = false;
  }
  var inheritsParentTurn = tmp_6;
  var tmp_14;
  var tmp_15 = effectiveThread;
  if (!((tmp_15 == null ? null : new ThreadId(tmp_15)) == null)) {
    tmp_14 = !inheritsParentTurn;
  } else {
    tmp_14 = false;
  }
  var turnOwner = tmp_14;
  var tmp8 = $this.o6o_1;
  var tmp$ret$13;
  $l$block: {
    // Inline function 'kotlinx.coroutines.flow.getAndUpdate' call
    while (true) {
      var prevValue = tmp8.n1();
      // Inline function 'kotlin.Long.plus' call
      var nextValue = prevValue.u3(toLong(1));
      if (tmp8.u1e(prevValue, nextValue)) {
        tmp$ret$13 = prevValue;
        break $l$block;
      }
    }
  }
  var runId = _RunId___init__impl__jfg80d(tmp$ret$13);
  var tmp_16;
  if (inheritsParentTurn) {
    tmp_16 = ensureNotNull(parentSnapshot).b6r_1;
  } else {
    var tmp_17;
    var tmp_18 = effectiveThread;
    if ((tmp_18 == null ? null : new ThreadId(tmp_18)) == null) {
      tmp_17 = null;
    } else {
      var tmp_19 = effectiveThread;
      // Inline function 'kotlin.let' call
      (tmp_19 == null ? null : new ThreadId(tmp_19)).n68_1;
      var tmp0 = $this.p6o_1;
      var tmp$ret$16;
      $l$block_0: {
        // Inline function 'kotlinx.coroutines.flow.getAndUpdate' call
        while (true) {
          var prevValue_0 = tmp0.n1();
          // Inline function 'kotlin.Long.plus' call
          var nextValue_0 = prevValue_0.u3(toLong(1));
          if (tmp0.u1e(prevValue_0, nextValue_0)) {
            tmp$ret$16 = prevValue_0;
            break $l$block_0;
          }
        }
      }
      tmp_17 = _TurnId___init__impl__hazk21(tmp$ret$16);
    }
    tmp_16 = tmp_17;
  }
  var turnId = tmp_16;
  var tmp_20;
  var tmp_21 = turnId;
  if ((tmp_21 == null ? null : new TurnId(tmp_21)) == null) {
    tmp_20 = null;
  } else {
    if (inheritsParentTurn) {
      var tmp_22;
      if (inheritedTurnContext == null) {
        var tmp_23 = $this.u6o_1.n1();
        var tmp_24 = turnId;
        tmp_22 = tmp_23.h3(tmp_24 == null ? null : new TurnId(tmp_24));
      } else {
        tmp_22 = inheritedTurnContext;
      }
      var tmp4_elvis_lhs = tmp_22;
      var tmp_25;
      if (tmp4_elvis_lhs == null) {
        var message_5 = "turn '" + _TurnId___get_value__impl__w6r3h9(turnId).toString() + "' has no active context";
        throw IllegalStateException.t4(toString(message_5));
      } else {
        tmp_25 = tmp4_elvis_lhs;
      }
      tmp_20 = tmp_25;
    } else {
      var tmp_26 = effectiveThread;
      tmp_20 = new TurnContext(ensureNotNull(tmp_26 == null ? null : new ThreadId(tmp_26)).n68_1, turnId, seedItems($this, input, resume));
    }
  }
  var turnContext = tmp_20;
  acquireRegistration($this, agent);
  var completionOwnsRegistration = false;
  var turnReservation = {_v: null};
  var turnContextRegistered = false;
  var childLinked = false;
  try {
    var tmp_27;
    if (turnOwner) {
      var tmp_28 = effectiveThread;
      var tmp_29 = ensureNotNull(tmp_28 == null ? null : new ThreadId(tmp_28));
      var tmp_30 = turnId;
      tmp_27 = $this.j6o_1.x6x(tmp_29.n68_1, ensureNotNull(tmp_30 == null ? null : new TurnId(tmp_30)).x6u_1, agent);
    } else {
      tmp_27 = null;
    }
    turnReservation._v = tmp_27;
    if (turnOwner && !(turnContext == null)) {
      var tmp13 = $this.u6o_1;
      $l$block_1: {
        // Inline function 'kotlinx.coroutines.flow.update' call
        while (true) {
          var prevValue_1 = tmp13.n1();
          var tmp_31 = turnId;
          // Inline function 'kotlin.collections.contains' call
          // Inline function 'kotlin.collections.containsKey' call
          var key = tmp_31 == null ? null : new TurnId(tmp_31);
          // Inline function 'kotlin.check' call
          if (!!(isInterface(prevValue_1, KtMap) ? prevValue_1 : THROW_CCE()).f3(key)) {
            var tmp_32 = turnId;
            var message_6 = "turn '" + _TurnId___get_value__impl__w6r3h9(ensureNotNull(tmp_32 == null ? null : new TurnId(tmp_32)).x6u_1).toString() + "' is already registered";
            throw IllegalStateException.t4(toString(message_6));
          }
          var tmp_33 = turnId;
          var nextValue_1 = plus_1(prevValue_1, to(ensureNotNull(tmp_33 == null ? null : new TurnId(tmp_33)), turnContext));
          if (tmp13.u1e(prevValue_1, nextValue_1)) {
            break $l$block_1;
          }
        }
      }
      turnContextRegistered = true;
    }
    if (!(parentAcb == null)) {
      // Inline function 'kotlin.check' call
      if (!parentAcb.y6x(runId, failurePolicy)) {
        var message_7 = "parent run '" + _RunId___get_value__impl__30zeiv(parentAcb.r6q_1).toString() + "' is no longer accepting children";
        throw IllegalStateException.t4(toString(message_7));
      }
      childLinked = true;
    }
    var tmp_34;
    if (correlationId == null) {
      tmp_34 = parentSnapshot == null ? null : parentSnapshot.f6r_1;
    } else {
      tmp_34 = correlationId;
    }
    var effectiveCorrelationId = tmp_34;
    var acb = new Acb(runId, agent.i5m_1, agent.j5m_1, effectiveThread, turnId, priority, parent, effectiveCorrelationId);
    if (!(turnReservation._v == null)) {
      acb.n6v(LifecycleState_THREAD_QUEUED_getInstance());
    }
    var tmp16 = $this.q6o_1;
    $l$block_2: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue_2 = tmp16.n1();
        var nextValue_2 = plus_1(prevValue_2, to(new RunId(runId), acb));
        if (tmp16.u1e(prevValue_2, nextValue_2)) {
          break $l$block_2;
        }
      }
    }
    var eventJournal = new RunEventJournal(runId, agent.i5m_1, effectiveThread, turnId, effectiveCorrelationId, $this.e6o_1);
    var tmp18 = $this.s6o_1;
    $l$block_3: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue_3 = tmp18.n1();
        var nextValue_3 = plus_1(prevValue_3, to(new RunId(runId), eventJournal));
        if (tmp18.u1e(prevValue_3, nextValue_3)) {
          break $l$block_3;
        }
      }
    }
    var sink = new JournalEventSink(eventJournal);
    emit($this, new Spawned(runId, agent.i5m_1, agent.j5m_1, effectiveThread, turnId, priority, parent));
    var effectiveQuota = quota == null ? $this.d6o_1 : quota;
    var control = new InstanceControl();
    $this.m6o_1.d6y(runId);
    var tmp_35 = AgentRuntime$spawnInternal$lambda($this, runId, turnContext, effectiveCorrelationId);
    var childSpawner = new sam$org_koaks_runtime_resource_AgentSpawner$0(tmp_35);
    var runtimeContext = new RuntimeContext($this.l6o_1, runId, agent.i5m_1, effectiveThread, turnId, effectiveCorrelationId, $this.m6o_1, $this.n6o_1, childSpawner);
    var tmp_36 = AgentRuntime$emit$ref($this);
    var gate = new InstanceActivityGate(runId, acb, tmp_36, AgentRuntime$spawnInternal$lambda_0(turnContext));
    var tmp_37 = runtimeContext.kn(gate);
    var deferred = async($this.g6o_1, tmp_37, VOID, AgentRuntime$spawnInternal$slambda_0($this, contextRefs, parent, runId, gate, agent, input, acb, control, priority, effectiveQuota, sink, effectiveThread, turnId, turnContext, turnOwner, turnReservation, structuredSpec, resume));
    deferred.uv(AgentRuntime$spawnInternal$lambda_1(turnReservation, turnOwner, turnId, $this, agent, acb, runId, effectiveThread, sink));
    completionOwnsRegistration = true;
    var handle = new AgentHandle(runId, agent.i5m_1, effectiveThread, turnId, effectiveCorrelationId, acb, control, deferred, failurePolicy, eventJournal);
    var tmp20 = $this.r6o_1;
    $l$block_4: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue_4 = tmp20.n1();
        var nextValue_4 = plus_1(prevValue_4, to(new RunId(runId), handle));
        if (tmp20.u1e(prevValue_4, nextValue_4)) {
          break $l$block_4;
        }
      }
    }
    if ($this.v6o_1.n1()) {
      handle.e6y('agent runtime closed');
      var tmp22 = $this.r6o_1;
      $l$block_5: {
        // Inline function 'kotlinx.coroutines.flow.update' call
        while (true) {
          var prevValue_5 = tmp22.n1();
          var nextValue_5 = minus(prevValue_5, new RunId(runId));
          if (tmp22.u1e(prevValue_5, nextValue_5)) {
            break $l$block_5;
          }
        }
      }
      var tmp24 = $this.q6o_1;
      $l$block_6: {
        // Inline function 'kotlinx.coroutines.flow.update' call
        while (true) {
          var prevValue_6 = tmp24.n1();
          var nextValue_6 = minus(prevValue_6, new RunId(runId));
          if (tmp24.u1e(prevValue_6, nextValue_6)) {
            break $l$block_6;
          }
        }
      }
      var tmp26 = $this.s6o_1;
      $l$block_7: {
        // Inline function 'kotlinx.coroutines.flow.update' call
        while (true) {
          var prevValue_7 = tmp26.n1();
          var nextValue_7 = minus(prevValue_7, new RunId(runId));
          if (tmp26.u1e(prevValue_7, nextValue_7)) {
            break $l$block_7;
          }
        }
      }
      $this.m6o_1.f6y(runId);
      // Inline function 'kotlin.error' call
      var message_8 = 'AgentRuntime is closed';
      throw IllegalStateException.t4(toString(message_8));
    }
    return handle;
  }finally {
    if (!completionOwnsRegistration) {
      if (childLinked) {
        if (parentAcb == null)
          null;
        else {
          parentAcb.g6y(runId);
        }
      }
      var tmp9_safe_receiver = turnReservation._v;
      if (tmp9_safe_receiver == null)
        null;
      else {
        tmp9_safe_receiver.j6y();
      }
      var tmp_38;
      if (turnContextRegistered) {
        var tmp_39 = turnId;
        tmp_38 = !((tmp_39 == null ? null : new TurnId(tmp_39)) == null);
      } else {
        tmp_38 = false;
      }
      if (tmp_38) {
        var tmp29 = $this.u6o_1;
        $l$block_8: {
          // Inline function 'kotlinx.coroutines.flow.update' call
          while (true) {
            var prevValue_8 = tmp29.n1();
            var tmp_40 = turnId;
            var nextValue_8 = minus(prevValue_8, tmp_40 == null ? null : new TurnId(tmp_40));
            if (tmp29.u1e(prevValue_8, nextValue_8)) {
              break $l$block_8;
            }
          }
        }
      }
      var tmp31 = $this.s6o_1;
      $l$block_9: {
        // Inline function 'kotlinx.coroutines.flow.update' call
        while (true) {
          var prevValue_9 = tmp31.n1();
          var nextValue_9 = minus(prevValue_9, new RunId(runId));
          if (tmp31.u1e(prevValue_9, nextValue_9)) {
            break $l$block_9;
          }
        }
      }
      releaseRegistration($this, agent);
    }
  }
}
function spawnInternal$default($this, agent, input, priority, quota, parent, contextRefs, thread, structuredSpec, inheritedTurnContext, childConversation, failurePolicy, correlationId, resume, $super) {
  inheritedTurnContext = inheritedTurnContext === VOID ? null : inheritedTurnContext;
  childConversation = childConversation === VOID ? null : childConversation;
  failurePolicy = failurePolicy === VOID ? ChildFailurePolicy_PROPAGATE_getInstance() : failurePolicy;
  correlationId = correlationId === VOID ? null : correlationId;
  resume = resume === VOID ? false : resume;
  return spawnInternal($this, agent, input, priority, quota, parent, contextRefs, thread, structuredSpec, inheritedTurnContext, childConversation, failurePolicy, correlationId, resume);
}
function *_generator_runInstance__aqy498($this, gate, agent, input, contextPrefix, acb, control, priority, quota, sink, thread, turnId, turnContext, turnOwner, turnReservation, structuredSpec, resume, $completion) {
  var threadLease = {_v: null};
  var threadMemory = {_v: null};
  var terminalUsage = {_v: Companion_getInstance_43().t5r_1};
  var turnCommitted = {_v: false};
  try {
    var tmp;
    var tmp_0;
    var tmp_1;
    var tmp_2 = thread;
    if (!((tmp_2 == null ? null : new ThreadId(tmp_2)) == null)) {
      var tmp_3 = turnId;
      tmp_1 = !((tmp_3 == null ? null : new TurnId(tmp_3)) == null);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = !(turnContext == null);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      var tmp_4;
      if (turnOwner) {
        // Inline function 'kotlin.requireNotNull' call
        var tmp$ret$1;
        $l$block: {
          // Inline function 'kotlin.requireNotNull' call
          if (turnReservation == null) {
            var message = 'Required value was null.';
            throw IllegalArgumentException.t(toString(message));
          } else {
            tmp$ret$1 = turnReservation;
            break $l$block;
          }
        }
        var tmp_5 = tmp$ret$1.vw($completion);
        if (tmp_5 === get_COROUTINE_SUSPENDED())
          tmp_5 = yield tmp_5;
        // Inline function 'kotlin.also' call
        var this_0 = tmp_5;
        threadLease._v = this_0;
        var lease = this_0;
        var tmp_6 = lease.m6y($completion);
        if (tmp_6 === get_COROUTINE_SUSPENDED())
          tmp_6 = yield tmp_6;
        // Inline function 'kotlin.also' call
        var this_1 = tmp_6;
        threadMemory._v = this_1;
        var memory = this_1;
        var tmp_7 = memory.t68(seedItems($this, input, resume), $completion);
        if (tmp_7 === get_COROUTINE_SUSPENDED())
          tmp_7 = yield tmp_7;
        var view = forOnlineUse(tmp_7);
        turnContext.h6u_1 = view.w68_1;
        // Inline function 'kotlin.also' call
        var this_2 = view.v68_1;
        turnContext.n6y(this_2);
        tmp_4 = this_2;
      } else {
        $this.j6o_1.k6y(thread, turnId, agent);
        var tmp_8 = turnContext.l6y($completion);
        if (tmp_8 === get_COROUTINE_SUSPENDED())
          tmp_8 = yield tmp_8;
        tmp_4 = tmp_8;
      }
      var history = tmp_4;
      tmp = plus_0(history, contextPrefix);
    } else {
      tmp = contextPrefix;
    }
    var effectiveContext = tmp;
    acb.o6y();
    var tmp_9 = $this.h6o_1.v6y(priority, AgentRuntime$runInstance$slambda_7(gate, acb, $this, agent, thread, turnId, input, resume, effectiveContext, control, quota, sink, turnContext, structuredSpec, terminalUsage), $completion);
    if (tmp_9 === get_COROUTINE_SUSPENDED())
      tmp_9 = yield tmp_9;
    var result = tmp_9;
    acb.w6y();
    if (!acb.w6q().c6r_1.n6p() && hasActiveChildren($this, acb.r6q_1)) {
      acb.n6v(LifecycleState_WAITING_getInstance());
      emit($this, new Waiting(acb.r6q_1, agent.i5m_1, thread, turnId));
    }
    var tmp_10 = awaitChildren($this, acb.r6q_1, true, result instanceof Completed_0, $completion);
    if (tmp_10 === get_COROUTINE_SUSPENDED())
      tmp_10 = yield tmp_10;
    var childFailure = tmp_10;
    var tmp_11;
    if (!(result instanceof Failed_1)) {
      tmp_11 = !(childFailure == null);
    } else {
      tmp_11 = false;
    }
    if (tmp_11) {
      var error = new ModelError("child run '" + _RunId___get_value__impl__30zeiv(childFailure.x6y_1).toString() + "' failed: " + childFailure.y6y_1.h2(), false, childFailure.y6y_1.i2());
      acb.n6r(error, result.k5r());
      emit($this, new Failed_4(acb.r6q_1, agent.i5m_1, thread, turnId, error));
      var tmp_12 = sink.r6v(new Failed(error, result.k5r()), $completion);
      if (tmp_12 === get_COROUTINE_SUSPENDED())
        tmp_12 = yield tmp_12;
      return new Failed_1(error, result.k5r());
    }
    if (result instanceof Completed_0) {
      if (acb.z6y()) {
        var tmp_13 = NonCancellable_getInstance();
        var tmp_14 = withContext(tmp_13, AgentRuntime$runInstance$slambda_8(turnCommitted, $this, threadMemory, turnContext, acb, result, agent, thread, turnId), $completion);
        if (tmp_14 === get_COROUTINE_SUSPENDED())
          tmp_14 = yield tmp_14;
      }
    } else {
      if (result instanceof Incomplete_0) {
        if (acb.z6y()) {
          var tmp_15 = NonCancellable_getInstance();
          var tmp_16 = withContext(tmp_15, AgentRuntime$runInstance$slambda_9(turnCommitted, $this, threadMemory, turnContext, result, acb, agent, thread, turnId), $completion);
          if (tmp_16 === get_COROUTINE_SUSPENDED())
            tmp_16 = yield tmp_16;
        }
      } else {
        if (result instanceof Terminated_0) {
          if (acb.z6y()) {
            var tmp_17 = NonCancellable_getInstance();
            var tmp_18 = withContext(tmp_17, AgentRuntime$runInstance$slambda_10(turnCommitted, $this, threadMemory, turnContext, result, acb, agent, thread, turnId), $completion);
            if (tmp_18 === get_COROUTINE_SUSPENDED())
              tmp_18 = yield tmp_18;
          }
        } else {
          if (result instanceof Failed_1) {
            var tmp_19 = NonCancellable_getInstance();
            var tmp_20 = withContext(tmp_19, AgentRuntime$runInstance$slambda_11(turnCommitted, $this, threadMemory, turnContext), $completion);
            if (tmp_20 === get_COROUTINE_SUSPENDED())
              tmp_20 = yield tmp_20;
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
    return result;
  } catch ($p) {
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      acb.w6y();
      acb.a6z();
      if (acb.w6q().c6r_1.equals(LifecycleState_CANCELLED_getInstance()) && acb.b6z()) {
        emit($this, new Cancelled_1(acb.r6q_1, agent.i5m_1, thread, turnId));
      }
      cancelDescendants($this, acb.r6q_1, 'parent ' + RunId__toString_impl_q8god7(acb.r6q_1) + ' cancelled');
      var tmp_21 = NonCancellable_getInstance();
      var tmp_22 = withContext(tmp_21, AgentRuntime$runInstance$slambda_12(turnContext, agent, turnCommitted, $this, threadMemory, acb), $completion);
      if (tmp_22 === get_COROUTINE_SUSPENDED())
        tmp_22 = yield tmp_22;
      throw cancelled;
    } else {
      if ($p instanceof Error) {
        var failure = $p;
        acb.w6y();
        cancelDescendants($this, acb.r6q_1, 'parent ' + RunId__toString_impl_q8god7(acb.r6q_1) + ' failed');
        var tmp_23 = NonCancellable_getInstance();
        var tmp_24 = withContext(tmp_23, AgentRuntime$runInstance$slambda_13(turnCommitted, $this, threadMemory, turnContext, acb), $completion);
        if (tmp_24 === get_COROUTINE_SUSPENDED())
          tmp_24 = yield tmp_24;
        throw failure;
      } else {
        throw $p;
      }
    }
  }
  finally {
    var tmp_25 = NonCancellable_getInstance();
    var tmp_26 = withContext(tmp_25, AgentRuntime$runInstance$slambda_14(threadLease, turnCommitted, turnContext, $this, acb, agent, turnId), $completion);
    if (tmp_26 === get_COROUTINE_SUSPENDED())
      tmp_26 = yield tmp_26;
  }
}
function runInstance($this, gate, agent, input, contextPrefix, acb, control, priority, quota, sink, thread, turnId, turnContext, turnOwner, turnReservation, structuredSpec, resume, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_runInstance__aqy498.bind(VOID, $this, gate, agent, input, contextPrefix, acb, control, priority, quota, sink, thread, turnId, turnContext, turnOwner, turnReservation, structuredSpec, resume), $completion);
}
function *_generator_runWithQuota__sv153z($this, agent, input, contextPrefix, acb, control, quota, sink, turnContext, structuredSpec, terminalUsage, $completion) {
  var tmp0_elvis_lhs = quota.v6v_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var tmp_0 = collectStream($this, agent, input, contextPrefix, acb, control, quota, sink, turnContext, structuredSpec, terminalUsage, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    return tmp_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var wall = tmp;
  var tmp_1;
  try {
    // Inline function 'kotlin.time.Companion.milliseconds' call
    Companion_getInstance();
    var tmp_2 = toDuration(wall, DurationUnit_MILLISECONDS_getInstance());
    var tmp_3 = withTimeout(tmp_2, AgentRuntime$runWithQuota$slambda_0($this, agent, input, contextPrefix, acb, control, quota, sink, turnContext, structuredSpec, terminalUsage), $completion);
    if (tmp_3 === get_COROUTINE_SUSPENDED())
      tmp_3 = yield tmp_3;
    tmp_1 = tmp_3;
  } catch ($p) {
    var tmp_4;
    if ($p instanceof TimeoutCancellationException) {
      var _unused_var__etf5q3 = $p;
      var error = new Timeout('agent wall-clock', wall);
      var usage = acb.w6q().i6r_1;
      acb.n6r(error, usage);
      emit($this, new Failed_4(acb.r6q_1, acb.w6q().y6q_1, acb.w6q().a6r_1, acb.w6q().b6r_1, error));
      cancelDescendants($this, acb.r6q_1, 'parent ' + RunId__toString_impl_q8god7(acb.r6q_1) + ' timed out');
      var tmp_5 = sink.r6v(new Failed(error, usage), $completion);
      if (tmp_5 === get_COROUTINE_SUSPENDED())
        tmp_5 = yield tmp_5;
      tmp_4 = new Failed_1(error, usage);
    } else {
      throw $p;
    }
    tmp_1 = tmp_4;
  }
  return tmp_1;
}
function runWithQuota($this, agent, input, contextPrefix, acb, control, quota, sink, turnContext, structuredSpec, terminalUsage, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_runWithQuota__sv153z.bind(VOID, $this, agent, input, contextPrefix, acb, control, quota, sink, turnContext, structuredSpec, terminalUsage), $completion);
}
function *_generator_collectStream__omnc16($this, agent, input, contextPrefix, acb, control, quota, sink, turnContext, structuredSpec, terminalUsage, $completion) {
  var terminal = {_v: null};
  var lastFailure = {_v: null};
  var usage = {_v: Companion_getInstance_43().t5r_1};
  var steps = {_v: 0};
  var toolCalls = {_v: 0};
  var stepText = StringBuilder.v();
  var lastAssistant = {_v: ''};
  var tmp1_elvis_lhs = turnContext == null ? null : turnContext.e6u_1;
  var turn = tmp1_elvis_lhs == null ? new TurnBuilder('ephemeral') : tmp1_elvis_lhs;
  try {
    var tmp;
    if (structuredSpec == null) {
      tmp = agent.p5o(input, contextPrefix, turn, turnContext == null ? null : turnContext.h6u_1);
    } else {
      tmp = agent.q5o(input, contextPrefix, structuredSpec, turn, turnContext == null ? null : turnContext.h6u_1);
    }
    var events = tmp;
    var tmp_0 = AgentRuntime$collectStream$slambda_0(control, acb, $this, agent, sink, stepText, toolCalls, quota, steps, lastAssistant, terminal, usage, terminalUsage, lastFailure);
    var tmp_1 = events.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_6(tmp_0), $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
  } catch ($p) {
    if ($p instanceof QuotaSignal) {
      var quotaSignal = $p;
      var currentUsage = acb.w6q().i6r_1;
      acb.a6z();
      if (acb.w6q().c6r_1.equals(LifecycleState_CANCELLED_getInstance()) && acb.b6z()) {
        emit($this, new Cancelled_1(acb.r6q_1, agent.i5m_1, acb.w6q().a6r_1, acb.w6q().b6r_1));
      }
      cancelDescendants($this, acb.r6q_1, 'parent ' + RunId__toString_impl_q8god7(acb.r6q_1) + ' quota exceeded');
      var reason = new Custom('quota exceeded: ' + quotaSignal.a6w_1);
      var tmp_2 = Companion_instance_36;
      // Inline function 'kotlin.text.ifEmpty' call
      var this_0 = stepText.toString();
      var tmp_3;
      // Inline function 'kotlin.text.isEmpty' call
      if (charSequenceLength(this_0) === 0) {
        tmp_3 = lastAssistant._v;
      } else {
        tmp_3 = this_0;
      }
      var tmp$ret$2 = tmp_3;
      var message = tmp_2.m5t(tmp$ret$2);
      var tmp_4 = sink.r6v(new Terminated(message, currentUsage, reason), $completion);
      if (tmp_4 === get_COROUTINE_SUSPENDED())
        tmp_4 = yield tmp_4;
      return new Terminated_0(message, currentUsage, reason);
    } else {
      if ($p instanceof AgentFrameworkException) {
        var failure = $p;
        var currentUsage_0 = acb.w6q().i6r_1;
        var error = failure.z5s_1;
        var event = new Failed(error, currentUsage_0);
        acb.n6r(error, currentUsage_0);
        emit($this, new Failed_4(acb.r6q_1, agent.i5m_1, acb.w6q().a6r_1, acb.w6q().b6r_1, error));
        cancelDescendants($this, acb.r6q_1, 'parent ' + RunId__toString_impl_q8god7(acb.r6q_1) + ' failed');
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s = agent.o5m_1.y();
        while (_iterator__ex2g4s.z()) {
          var element = _iterator__ex2g4s.a1();
          element.u5y(event);
        }
        var tmp_5 = sink.r6v(event, $completion);
        if (tmp_5 === get_COROUTINE_SUSPENDED())
          tmp_5 = yield tmp_5;
        return new Failed_1(error, currentUsage_0);
      } else {
        throw $p;
      }
    }
  }
  var term = terminal._v;
  var tmp_6;
  if (term instanceof Completed) {
    tmp_6 = new Completed_0(term.l5r_1, usage._v);
  } else {
    if (term instanceof Incomplete) {
      tmp_6 = new Incomplete_0(term.n5r_1, usage._v, term.p5r_1);
    } else {
      if (term instanceof Terminated) {
        tmp_6 = new Terminated_0(term.q5r_1, usage._v, term.s5r_1);
      } else {
        if (term == null) {
          var tmp4_elvis_lhs = lastFailure._v;
          var error_0 = tmp4_elvis_lhs == null ? new ModelError('agent produced no terminal event', false) : tmp4_elvis_lhs;
          acb.n6r(error_0, usage._v);
          emit($this, new Failed_4(acb.r6q_1, agent.i5m_1, acb.w6q().a6r_1, acb.w6q().b6r_1, error_0));
          cancelDescendants($this, acb.r6q_1, 'parent ' + RunId__toString_impl_q8god7(acb.r6q_1) + ' failed');
          tmp_6 = new Failed_1(error_0, usage._v);
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  return tmp_6;
}
function collectStream($this, agent, input, contextPrefix, acb, control, quota, sink, turnContext, structuredSpec, terminalUsage, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_collectStream__omnc16.bind(VOID, $this, agent, input, contextPrefix, acb, control, quota, sink, turnContext, structuredSpec, terminalUsage), $completion);
}
function cancelDescendants($this, id, reason) {
  var tmp0_elvis_lhs = $this.q6o_1.n1().h3(new RunId(id));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var acb = tmp;
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = acb.w6q().g6r_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var child = element.z6w_1;
    var tmp0_safe_receiver = $this.r6o_1.n1().h3(new RunId(child));
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.e6y(reason);
    }
    cancelDescendants($this, child, reason);
  }
}
function *_generator_awaitChildren__pmwdsv($this, id, reportCapturedFailures, reportCapturedCancellations, $completion) {
  var tmp0_elvis_lhs = $this.q6o_1.n1().h3(new RunId(id));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var parentAcb = tmp;
  var children = parentAcb.w6q().g6r_1;
  var firstFailure = {_v: null};
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = children.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp1 = element.z6w_1;
    $l$block: {
      var tmp0_elvis_lhs_0 = $this.r6o_1.n1().h3(new RunId(tmp1));
      var tmp_0;
      if (tmp0_elvis_lhs_0 == null) {
        break $l$block;
      } else {
        tmp_0 = tmp0_elvis_lhs_0;
      }
      var handle = tmp_0;
      var failurePolicy = parentAcb.c6z(tmp1);
      try {
        var tmp_1 = handle.d6z($completion);
        if (tmp_1 === get_COROUTINE_SUSPENDED())
          tmp_1 = yield tmp_1;
        var result = tmp_1;
        if (result instanceof Failed_1) {
          awaitChildren$_anonymous_$recordFailure$default_9xloxc(failurePolicy, firstFailure, tmp1, reportCapturedFailures, reportCapturedCancellations, $this, id, handle, result.n5t_1);
        }
      } catch ($p) {
        if ($p instanceof CancellationException) {
          var cancelled = $p;
          // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
          // Inline function 'kotlin.js.getCoroutineContext' call
          var tmp$ret$2 = $completion.lc();
          ensureActive(tmp$ret$2);
          var tmp1_elvis_lhs = cancelled.message;
          awaitChildren$_anonymous_$recordFailure_4wgclv(failurePolicy, firstFailure, tmp1, reportCapturedFailures, reportCapturedCancellations, $this, id, handle, new ModelError(tmp1_elvis_lhs == null ? 'child run was cancelled' : tmp1_elvis_lhs, false, cancelled), true);
        } else {
          if ($p instanceof Error) {
            var failure = $p;
            var tmp2_elvis_lhs = handle.w6q().m6r_1;
            var tmp_2;
            if (tmp2_elvis_lhs == null) {
              var tmp3_elvis_lhs = failure.message;
              tmp_2 = new ModelError(tmp3_elvis_lhs == null ? 'child run failed unexpectedly' : tmp3_elvis_lhs, false, failure);
            } else {
              tmp_2 = tmp2_elvis_lhs;
            }
            awaitChildren$_anonymous_$recordFailure$default_9xloxc(failurePolicy, firstFailure, tmp1, reportCapturedFailures, reportCapturedCancellations, $this, id, handle, tmp_2);
          } else {
            throw $p;
          }
        }
      }
    }
  }
  return firstFailure._v;
}
function awaitChildren($this, id, reportCapturedFailures, reportCapturedCancellations, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_awaitChildren__pmwdsv.bind(VOID, $this, id, reportCapturedFailures, reportCapturedCancellations), $completion);
}
function reportUnhandledChildFailure($this, parent, handle, error) {
  if (handle.e6z() || !handle.f6z())
    return Unit_instance;
  var tmp = get_logger();
  tmp.c5l(AgentRuntime$reportUnhandledChildFailure$lambda(handle, error));
  emit($this, new UnhandledChildFailure(parent, handle.x6o_1, handle.y6o_1, error));
}
function hasActiveChildren($this, id) {
  var tmp0_safe_receiver = $this.q6o_1.n1().h3(new RunId(id));
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.w6q();
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.g6r_1;
  var tmp1 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  var tmp$ret$1;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp;
    if (isInterface(tmp1, Collection)) {
      tmp = tmp1.h1();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$1 = false;
      break $l$block_0;
    }
    var _iterator__ex2g4s = tmp1.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var child = element.z6w_1;
      var tmp0_safe_receiver_0 = $this.r6o_1.n1().h3(new RunId(child));
      if ((tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.su()) === true) {
        tmp$ret$1 = true;
        break $l$block_0;
      }
    }
    tmp$ret$1 = false;
  }
  return tmp$ret$1;
}
function *_generator_cancelAndJoin__7ukrt9($this, handle, reason, $completion) {
  handle.e6y(reason);
  var tmp = NonCancellable_getInstance();
  var tmp_0 = withContext(tmp, AgentRuntime$cancelAndJoin$slambda_0(handle), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function cancelAndJoin($this, handle, reason, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_cancelAndJoin__7ukrt9.bind(VOID, $this, handle, reason), $completion);
}
function resolveContextPrefix($this, refs, requester) {
  // Inline function 'kotlin.collections.flatMap' call
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = refs.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var it = element.g6z_1;
    var list = $this.n6o_1.i6z(it, requester);
    addAll(destination, list);
  }
  return destination;
}
function seedItems($this, input, resume) {
  var tmp;
  var tmp_0;
  if (resume) {
    tmp_0 = true;
  } else {
    // Inline function 'kotlin.text.isEmpty' call
    tmp_0 = charSequenceLength(input) === 0;
  }
  if (tmp_0) {
    tmp = emptyList();
  } else {
    tmp = listOf(Companion_instance_36.z5n(input));
  }
  return tmp;
}
function *_generator_commitTurn__9oox8s($this, memory, turnContext, completed, reason, $completion) {
  if (memory == null || turnContext == null)
    return false;
  var builder = turnContext.e6u_1;
  var tmp;
  if (completed) {
    tmp = builder.g61();
  } else {
    tmp = builder.h61(reason == null ? Cancelled_instance : reason);
  }
  var raw = tmp;
  var tmp1_safe_receiver = raw.c68_1;
  var tmp_0;
  if (tmp1_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.takeIf' call
    var tmp_1;
    if (tmp1_safe_receiver.h6b_1.equals(CheckpointScope_CrossTurn_getInstance())) {
      tmp_1 = tmp1_safe_receiver;
    } else {
      tmp_1 = null;
    }
    tmp_0 = tmp_1;
  }
  var turn = raw.f68(VOID, VOID, VOID, tmp_0);
  if (!shouldRetain(turn, memory.s68(), turnContext.z61()))
    return false;
  var tmp_2 = memory.u68(turn, $completion);
  if (tmp_2 === get_COROUTINE_SUSPENDED())
    tmp_2 = yield tmp_2;
  return true;
}
function commitTurn($this, memory, turnContext, completed, reason, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_commitTurn__9oox8s.bind(VOID, $this, memory, turnContext, completed, reason), $completion);
}
function commitTurn$default($this, memory, turnContext, completed, reason, $completion, $super) {
  reason = reason === VOID ? null : reason;
  return commitTurn($this, memory, turnContext, completed, reason, $completion);
}
function metrics$count(snaps, state) {
  var tmp$ret$0;
  $l$block: {
    // Inline function 'kotlin.collections.count' call
    var tmp;
    if (isInterface(snaps, Collection)) {
      tmp = snaps.h1();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$0 = 0;
      break $l$block;
    }
    var count = 0;
    var _iterator__ex2g4s = snaps.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element.c6r_1.equals(state)) {
        count = count + 1 | 0;
        checkCountOverflow(count);
      }
    }
    tmp$ret$0 = count;
  }
  return tmp$ret$0;
}
function awaitChildren$_anonymous_$recordFailure_4wgclv(failurePolicy, firstFailure, $child, $reportCapturedFailures, $reportCapturedCancellations, this$0, $id, handle, error, cancellation) {
  switch (failurePolicy.o3_1) {
    case 0:
      if (firstFailure._v == null) {
        firstFailure._v = new ChildFailure($child, error);
      }

      break;
    case 1:
      if ($reportCapturedFailures && (!cancellation || $reportCapturedCancellations)) {
        reportUnhandledChildFailure(this$0, $id, handle, error);
      }

      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
}
function awaitChildren$_anonymous_$recordFailure$default_9xloxc(failurePolicy, firstFailure, $child, $reportCapturedFailures, $reportCapturedCancellations, this$0, $id, handle, error, cancellation, $super) {
  cancellation = cancellation === VOID ? false : cancellation;
  return awaitChildren$_anonymous_$recordFailure_4wgclv(failurePolicy, firstFailure, $child, $reportCapturedFailures, $reportCapturedCancellations, this$0, $id, handle, error, cancellation);
}
function AgentRuntime$lambda(this$0) {
  return (it) => {
    this$0.j6o_1.a6();
    this$0.u6o_1.t1e(emptyMap());
    return Unit_instance;
  };
}
function AgentRuntime$stream$slambda_0(this$0, $agent, $input, $priority, $quota, $contextRefs, $thread, $correlationId) {
  var i = new AgentRuntime$stream$slambda(this$0, $agent, $input, $priority, $quota, $contextRefs, $thread, $correlationId);
  var l = ($this$flow, $completion) => i.m5o($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$resume$slambda_0(this$0, $agent, $thread, $priority, $quota, $contextRefs, $correlationId) {
  var i = new AgentRuntime$resume$slambda(this$0, $agent, $thread, $priority, $quota, $contextRefs, $correlationId);
  var l = ($this$flow, $completion) => i.m5o($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$spawnInternal$lambda(this$0, $runId, $turnContext, $effectiveCorrelationId) {
  return (childAgent, childInput, childPriority, childQuota, childRefs, childFailurePolicy, conversation) => spawnInternal$default(this$0, childAgent, childInput, childPriority, childQuota, $runId, childRefs, null, null, $turnContext, conversation, childFailurePolicy, $effectiveCorrelationId);
}
function AgentRuntime$emit$ref($boundThis) {
  var l = (p0) => {
    emit($boundThis, p0);
    return Unit_instance;
  };
  l.callableName = 'emit';
  return l;
}
function AgentRuntime$spawnInternal$lambda_0($turnContext) {
  return () => {
    var tmp0_safe_receiver = $turnContext;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.f5s();
    }
    return Unit_instance;
  };
}
function AgentRuntime$spawnInternal$slambda_0(this$0, $contextRefs, $parent, $runId, $gate, $agent, $input, $acb, $control, $priority, $effectiveQuota, $sink, $effectiveThread, $turnId, $turnContext, $turnOwner, $turnReservation, $structuredSpec, $resume) {
  var i = new AgentRuntime$spawnInternal$slambda(this$0, $contextRefs, $parent, $runId, $gate, $agent, $input, $acb, $control, $priority, $effectiveQuota, $sink, $effectiveThread, $turnId, $turnContext, $turnOwner, $turnReservation, $structuredSpec, $resume);
  var l = ($this$async, $completion) => i.r1f($this$async, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$spawnInternal$lambda_1($turnReservation, $turnOwner, $turnId, this$0, $agent, $acb, $runId, $effectiveThread, $sink) {
  return (cause) => {
    var tmp0_safe_receiver = $turnReservation._v;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.j6y();
    }
    var tmp;
    var tmp_0;
    if ($turnOwner) {
      var tmp_1 = $turnId;
      tmp_0 = !((tmp_1 == null ? null : new TurnId(tmp_1)) == null);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      var tmp0 = this$0.u6o_1;
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlinx.coroutines.flow.update' call
        while (true) {
          var prevValue = tmp0.n1();
          var tmp_2 = $turnId;
          var nextValue = minus(prevValue, tmp_2 == null ? null : new TurnId(tmp_2));
          if (tmp0.u1e(prevValue, nextValue)) {
            tmp$ret$1 = Unit_instance;
            break $l$block;
          }
        }
        tmp$ret$1 = Unit_instance;
      }
      tmp = tmp$ret$1;
    }
    releaseRegistration(this$0, $agent);
    var tmp_3;
    if (cause instanceof CancellationException) {
      $acb.a6z();
      var tmp_4;
      if ($acb.w6q().c6r_1.equals(LifecycleState_CANCELLED_getInstance()) && $acb.b6z()) {
        emit(this$0, new Cancelled_1($runId, $agent.i5m_1, $effectiveThread, $turnId));
        tmp_4 = Unit_instance;
      }
      tmp_3 = tmp_4;
    }
    $sink.p6z(cause);
    return Unit_instance;
  };
}
function AgentRuntime$runInstance$slambda_7($gate, $acb, this$0, $agent, $thread, $turnId, $input, $resume, $effectiveContext, $control, $quota, $sink, $turnContext, $structuredSpec, $terminalUsage) {
  var i = new AgentRuntime$runInstance$slambda($gate, $acb, this$0, $agent, $thread, $turnId, $input, $resume, $effectiveContext, $control, $quota, $sink, $turnContext, $structuredSpec, $terminalUsage);
  var l = (lease, $completion) => i.q6z(lease, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$runInstance$slambda_8($turnCommitted, this$0, $threadMemory, $turnContext, $acb, $result, $agent, $thread, $turnId) {
  var i = new AgentRuntime$runInstance$slambda_0($turnCommitted, this$0, $threadMemory, $turnContext, $acb, $result, $agent, $thread, $turnId);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$runInstance$slambda_9($turnCommitted, this$0, $threadMemory, $turnContext, $result, $acb, $agent, $thread, $turnId) {
  var i = new AgentRuntime$runInstance$slambda_1($turnCommitted, this$0, $threadMemory, $turnContext, $result, $acb, $agent, $thread, $turnId);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$runInstance$slambda_10($turnCommitted, this$0, $threadMemory, $turnContext, $result, $acb, $agent, $thread, $turnId) {
  var i = new AgentRuntime$runInstance$slambda_2($turnCommitted, this$0, $threadMemory, $turnContext, $result, $acb, $agent, $thread, $turnId);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$runInstance$slambda_11($turnCommitted, this$0, $threadMemory, $turnContext) {
  var i = new AgentRuntime$runInstance$slambda_3($turnCommitted, this$0, $threadMemory, $turnContext);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$runInstance$slambda_12($turnContext, $agent, $turnCommitted, this$0, $threadMemory, $acb) {
  var i = new AgentRuntime$runInstance$slambda_4($turnContext, $agent, $turnCommitted, this$0, $threadMemory, $acb);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$runInstance$slambda_13($turnCommitted, this$0, $threadMemory, $turnContext, $acb) {
  var i = new AgentRuntime$runInstance$slambda_5($turnCommitted, this$0, $threadMemory, $turnContext, $acb);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$runInstance$slambda_14($threadLease, $turnCommitted, $turnContext, this$0, $acb, $agent, $turnId) {
  var i = new AgentRuntime$runInstance$slambda_6($threadLease, $turnCommitted, $turnContext, this$0, $acb, $agent, $turnId);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$runWithQuota$slambda_0(this$0, $agent, $input, $contextPrefix, $acb, $control, $quota, $sink, $turnContext, $structuredSpec, $terminalUsage) {
  var i = new AgentRuntime$runWithQuota$slambda(this$0, $agent, $input, $contextPrefix, $acb, $control, $quota, $sink, $turnContext, $structuredSpec, $terminalUsage);
  var l = ($this$withTimeout, $completion) => i.r1f($this$withTimeout, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$collectStream$slambda_0($control, $acb, this$0, $agent, $sink, $stepText, $toolCalls, $quota, $steps, $lastAssistant, $terminal, $usage, $terminalUsage, $lastFailure) {
  var i = new AgentRuntime$collectStream$slambda($control, $acb, this$0, $agent, $sink, $stepText, $toolCalls, $quota, $steps, $lastAssistant, $terminal, $usage, $terminalUsage, $lastFailure);
  var l = (event, $completion) => i.w5t(event, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$spawnSupervised$slambda_0(this$0, $agent, $input, $policy, $latest, $thread, $priority, $quota, $contextRefs) {
  var i = new AgentRuntime$spawnSupervised$slambda(this$0, $agent, $input, $policy, $latest, $thread, $priority, $quota, $contextRefs);
  var l = ($this$async, $completion) => i.r1f($this$async, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$spawnSupervised$lambda($latest) {
  return (reason) => {
    var tmp0_safe_receiver = $latest.n1();
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.e6y(reason);
    }
    return Unit_instance;
  };
}
function AgentRuntime$submit$slambda_0($graph, this$0) {
  var i = new AgentRuntime$submit$slambda($graph, this$0);
  var l = ($this$coroutineScope, $completion) => i.r1f($this$coroutineScope, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime$reportUnhandledChildFailure$lambda($handle, $error) {
  return () => "captured child run '" + _RunId___get_value__impl__30zeiv($handle.x6o_1).toString() + "' failed without its result being consumed: " + $error.h2();
}
function AgentRuntime$cancelAndJoin$slambda_0($handle) {
  var i = new AgentRuntime$cancelAndJoin$slambda($handle);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function AgentRuntime_0(configure) {
  var tmp;
  if (configure === VOID) {
    tmp = AgentRuntime$lambda_0;
  } else {
    tmp = configure;
  }
  configure = tmp;
  _init_properties_AgentRuntime_kt__s2akoj();
  // Inline function 'kotlin.apply' call
  var this_0 = new AgentRuntimeConfig();
  configure(this_0);
  return new AgentRuntime(this_0);
}
function runIdOrNull(_this__u8e3s4) {
  _init_properties_AgentRuntime_kt__s2akoj();
  var tmp;
  if (_this__u8e3s4 instanceof Spawned) {
    tmp = _this__u8e3s4.w73_1;
  } else {
    if (_this__u8e3s4 instanceof Running) {
      tmp = _this__u8e3s4.r73_1;
    } else {
      if (_this__u8e3s4 instanceof Waiting) {
        tmp = _this__u8e3s4.n73_1;
      } else {
        if (_this__u8e3s4 instanceof Suspended) {
          tmp = _this__u8e3s4.j73_1;
        } else {
          if (_this__u8e3s4 instanceof Resumed) {
            tmp = _this__u8e3s4.f73_1;
          } else {
            if (_this__u8e3s4 instanceof Finished_0) {
              tmp = _this__u8e3s4.a73_1;
            } else {
              if (_this__u8e3s4 instanceof Incomplete_3) {
                tmp = _this__u8e3s4.u72_1;
              } else {
                if (_this__u8e3s4 instanceof Terminated_1) {
                  tmp = _this__u8e3s4.p72_1;
                } else {
                  if (_this__u8e3s4 instanceof Failed_4) {
                    tmp = _this__u8e3s4.k72_1;
                  } else {
                    if (_this__u8e3s4 instanceof Cancelled_1) {
                      tmp = _this__u8e3s4.g72_1;
                    } else {
                      if (_this__u8e3s4 instanceof UnhandledChildFailure) {
                        tmp = _this__u8e3s4.d72_1;
                      } else {
                        if (_this__u8e3s4 instanceof SideEffectRollback) {
                          tmp = _this__u8e3s4.y71_1;
                        } else {
                          if (_this__u8e3s4 instanceof Retrying) {
                            tmp = _this__u8e3s4.r71_1;
                          } else {
                            if (_this__u8e3s4 instanceof CircuitOpen) {
                              tmp = _this__u8e3s4.m71_1;
                            } else {
                              noWhenBranchMatchedException();
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return tmp;
}
function logger$lambda() {
  _init_properties_AgentRuntime_kt__s2akoj();
  return Unit_instance;
}
function AgentRuntime$lambda_0(_this__u8e3s4) {
  _init_properties_AgentRuntime_kt__s2akoj();
  return Unit_instance;
}
var properties_initialized_AgentRuntime_kt_konyk5;
function _init_properties_AgentRuntime_kt__s2akoj() {
  if (!properties_initialized_AgentRuntime_kt_konyk5) {
    properties_initialized_AgentRuntime_kt_konyk5 = true;
    var tmp = KotlinLogging_instance;
    logger = tmp.g5l(logger$lambda);
  }
}
function elapsed($this) {
  return _Duration___get_inWholeMilliseconds__impl__msfiry(ValueTimeMark__elapsedNow_impl_eonqvs($this.v6q_1));
}
function *_generator_invoke__zhh2q8_39($this, $completion) {
  var tmp = $this.j74_1.e6p_1.yv($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_await__mos7q6_0($this, $completion) {
  var tmp;
  try {
    var tmp_0 = awaitInternal($this, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    // Inline function 'kotlin.also' call
    var this_0 = tmp_0;
    if (this_0 instanceof Failed_1) {
      $this.h6p_1.t1e(true);
    }
    tmp = this_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
      // Inline function 'kotlin.js.getCoroutineContext' call
      var tmp$ret$3 = $completion.lc();
      ensureActive(tmp$ret$3);
      $this.h6p_1.t1e(true);
      var tmp_2;
      if ($this.f6p_1.equals(ChildFailurePolicy_CAPTURE_getInstance())) {
        var tmp0_elvis_lhs = cancelled.message;
        tmp_2 = new Failed_1(new ModelError(tmp0_elvis_lhs == null ? 'child run was cancelled' : tmp0_elvis_lhs, false, cancelled), $this.w6q().i6r_1);
      } else {
        throw cancelled;
      }
      tmp_1 = tmp_2;
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  return tmp;
}
function *_generator_awaitInternal__zif8ip($this, $completion) {
  if ($this.e6p_1.nv()) {
    var tmp = $this.e6p_1.vw($completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    return tmp;
  }
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var exec = $completion.lc().yc(Key_instance);
  var tmp_0;
  if (!(exec == null)) {
    var tmp_1 = exec.d5s(AgentHandle$awaitInternal$slambda_0($this), $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    tmp_0 = tmp_1;
  } else {
    var tmp_2 = $this.e6p_1.vw($completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    tmp_0 = tmp_2;
  }
  return tmp_0;
}
function awaitInternal($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_awaitInternal__zif8ip.bind(VOID, $this), $completion);
}
function *_generator_join__qmovdu($this, $completion) {
  if ($this.e6p_1.nv())
    return Unit_instance;
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var exec = $completion.lc().yc(Key_instance);
  if (!(exec == null)) {
    var tmp = exec.d5s(AgentHandle$join$slambda_0($this), $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  } else {
    var tmp_0 = $this.e6p_1.yv($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
  }
  return Unit_instance;
}
function AgentHandle$awaitInternal$slambda_0(this$0) {
  var i = new AgentHandle$awaitInternal$slambda(this$0);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function AgentHandle$join$slambda_0(this$0) {
  var i = new AgentHandle$join$slambda(this$0);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function *_generator_awaitResumed__rl7ddl($this, $completion) {
  var tmp = first_1($this.o6v_1, InstanceControl$awaitResumed$slambda_0(), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function InstanceControl$awaitResumed$slambda_0() {
  var i = new InstanceControl$awaitResumed$slambda();
  var l = (it, $completion) => i.n74(it, $completion);
  l.$arity = 1;
  return l;
}
var LifecycleState_CREATED_instance;
var LifecycleState_THREAD_QUEUED_instance;
var LifecycleState_READY_instance;
var LifecycleState_RUNNING_instance;
var LifecycleState_WAITING_instance;
var LifecycleState_SUSPENDED_instance;
var LifecycleState_COMMITTING_instance;
var LifecycleState_FAILED_instance;
var LifecycleState_FINISHED_instance;
var LifecycleState_CANCELLED_instance;
var LifecycleState_entriesInitialized;
function LifecycleState_initEntries() {
  if (LifecycleState_entriesInitialized)
    return Unit_instance;
  LifecycleState_entriesInitialized = true;
  LifecycleState_CREATED_instance = new LifecycleState('CREATED', 0);
  LifecycleState_THREAD_QUEUED_instance = new LifecycleState('THREAD_QUEUED', 1);
  LifecycleState_READY_instance = new LifecycleState('READY', 2);
  LifecycleState_RUNNING_instance = new LifecycleState('RUNNING', 3);
  LifecycleState_WAITING_instance = new LifecycleState('WAITING', 4);
  LifecycleState_SUSPENDED_instance = new LifecycleState('SUSPENDED', 5);
  LifecycleState_COMMITTING_instance = new LifecycleState('COMMITTING', 6);
  LifecycleState_FAILED_instance = new LifecycleState('FAILED', 7);
  LifecycleState_FINISHED_instance = new LifecycleState('FINISHED', 8);
  LifecycleState_CANCELLED_instance = new LifecycleState('CANCELLED', 9);
}
function LifecycleState_CREATED_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_CREATED_instance;
}
function LifecycleState_THREAD_QUEUED_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_THREAD_QUEUED_instance;
}
function LifecycleState_READY_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_READY_instance;
}
function LifecycleState_RUNNING_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_RUNNING_instance;
}
function LifecycleState_WAITING_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_WAITING_instance;
}
function LifecycleState_SUSPENDED_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_SUSPENDED_instance;
}
function LifecycleState_COMMITTING_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_COMMITTING_instance;
}
function LifecycleState_FAILED_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_FAILED_instance;
}
function LifecycleState_FINISHED_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_FINISHED_instance;
}
function LifecycleState_CANCELLED_getInstance() {
  LifecycleState_initEntries();
  return LifecycleState_CANCELLED_instance;
}
function *_generator_invoke__zhh2q8_40($this, $this$flow, $completion) {
  // Inline function 'kotlin.require' call
  if (!($this.p74_1 == null || $this.p74_1.s1(new Long(0, 0)) >= 0)) {
    var message = 'afterSequence must not be negative';
    throw IllegalArgumentException.t(toString(message));
  }
  var tmp0_elvis_lhs = $this.p74_1;
  var cursor = {_v: tmp0_elvis_lhs == null ? new Long(0, 0) : tmp0_elvis_lhs};
  var gapReportedThrough = new Long(-1, -1);
  while (true) {
    var current = $this.q74_1.g6x_1.n1();
    var tmp1_safe_receiver = firstOrNull(current.s74_1);
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.g6n_1;
    var oldest = tmp2_elvis_lhs == null ? current.r74_1 : tmp2_elvis_lhs;
    var tmp;
    var tmp_0 = cursor._v;
    // Inline function 'kotlin.Long.minus' call
    var tmp$ret$2 = oldest.v3(toLong(1));
    if (tmp_0.s1(tmp$ret$2) < 0) {
      var tmp_1 = gapReportedThrough;
      // Inline function 'kotlin.Long.minus' call
      var tmp$ret$3 = oldest.v3(toLong(1));
      tmp = tmp_1.s1(tmp$ret$3) < 0;
    } else {
      tmp = false;
    }
    if (tmp) {
      // Inline function 'kotlin.Long.minus' call
      var tmp$ret$4 = oldest.v3(toLong(1));
      var tmp_2 = $this$flow.t1c(envelope($this.q74_1, tmp$ret$4, new HistoryGap(cursor._v, oldest)), $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      // Inline function 'kotlin.Long.minus' call
      cursor._v = oldest.v3(toLong(1));
      gapReportedThrough = cursor._v;
    }
    var tmp_3 = asSequence(current.s74_1);
    // Inline function 'kotlin.sequences.forEach' call
    var _iterator__ex2g4s = filter(tmp_3, RunEventJournal$events$slambda$lambda(cursor)).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp_4 = $this$flow.t1c(element, $completion);
      if (tmp_4 === get_COROUTINE_SUSPENDED())
        tmp_4 = yield tmp_4;
      cursor._v = element.g6n_1;
    }
    if (current.t74_1) {
      var tmp3_safe_receiver = current.u74_1;
      if (tmp3_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        throw tmp3_safe_receiver;
      }
      return Unit_instance;
    }
    var tmp_5 = first_1($this.q74_1.g6x_1, RunEventJournal$events$slambda$slambda_0(cursor), $completion);
    if (tmp_5 === get_COROUTINE_SUSPENDED())
      tmp_5 = yield tmp_5;
  }
  return Unit_instance;
}
function RunEventJournal$events$slambda$lambda($cursor) {
  return (it) => it.g6n_1.s1($cursor._v) > 0;
}
function RunEventJournal$events$slambda$slambda_0($cursor) {
  var i = new RunEventJournal$events$slambda$slambda($cursor);
  var l = (it, $completion) => i.w74(it, $completion);
  l.$arity = 1;
  return l;
}
function envelope($this, sequence, payload) {
  return new RunEventEnvelope($this.a6x_1, $this.b6x_1, $this.c6x_1, $this.d6x_1, $this.e6x_1, sequence, System_instance.p53().k5k(), payload);
}
function RunEventJournal$events$slambda_0($afterSequence, this$0) {
  var i = new RunEventJournal$events$slambda($afterSequence, this$0);
  var l = ($this$flow, $completion) => i.z74($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function _RunId___init__impl__jfg80d(value) {
  return value;
}
function _RunId___get_value__impl__30zeiv($this) {
  return $this;
}
function RunId__toString_impl_q8god7($this) {
  return 'run#' + _RunId___get_value__impl__30zeiv($this).toString();
}
function RunId__hashCode_impl_4harkc($this) {
  return $this.hashCode();
}
function RunId__equals_impl_gwlu3c($this, other) {
  if (!(other instanceof RunId))
    return false;
  var tmp0_other_with_cast = other instanceof RunId ? other.z6w_1 : THROW_CCE();
  if (!$this.equals(tmp0_other_with_cast))
    return false;
  return true;
}
function _TurnId___init__impl__hazk21(value) {
  return value;
}
function _TurnId___get_value__impl__w6r3h9($this) {
  return $this;
}
function TurnId__toString_impl_gyl6zb($this) {
  return 'turn#' + _TurnId___get_value__impl__w6r3h9($this).toString();
}
function TurnId__hashCode_impl_wbcy6y($this) {
  return $this.hashCode();
}
function TurnId__equals_impl_cgt3p2($this, other) {
  if (!(other instanceof TurnId))
    return false;
  var tmp0_other_with_cast = other instanceof TurnId ? other.x6u_1 : THROW_CCE();
  if (!$this.equals(tmp0_other_with_cast))
    return false;
  return true;
}
function _ContextRef___init__impl__laq00z(id) {
  return id;
}
function _ContextRef___get_id__impl__uspq4f($this) {
  return $this;
}
function ContextRef__toString_impl_l0p4oz($this) {
  return 'ContextRef(id=' + $this + ')';
}
function ContextRef__hashCode_impl_s990ha($this) {
  return getStringHashCode($this);
}
function ContextRef__equals_impl_dumauu($this, other) {
  if (!(other instanceof ContextRef))
    return false;
  if (!($this === (other instanceof ContextRef ? other.g6z_1 : THROW_CCE())))
    return false;
  return true;
}
var ContextScope_GLOBAL_instance;
var ContextScope_PRIVATE_instance;
var ContextScope_TASK_instance;
var ContextScope_entriesInitialized;
function ContextScope_initEntries() {
  if (ContextScope_entriesInitialized)
    return Unit_instance;
  ContextScope_entriesInitialized = true;
  ContextScope_GLOBAL_instance = new ContextScope('GLOBAL', 0);
  ContextScope_PRIVATE_instance = new ContextScope('PRIVATE', 1);
  ContextScope_TASK_instance = new ContextScope('TASK', 2);
}
function checkAccess($this, block, requester) {
  var tmp;
  switch (block.b75_1.o3_1) {
    case 0:
    case 2:
      tmp = true;
      break;
    case 1:
      var tmp_0;
      var tmp_1 = requester;
      if (!((tmp_1 == null ? null : new RunId(tmp_1)) == null)) {
        var tmp_2 = requester;
        var tmp_3 = tmp_2 == null ? null : new RunId(tmp_2);
        var tmp_4 = block.c75_1;
        tmp_0 = equals(tmp_3, tmp_4 == null ? null : new RunId(tmp_4));
      } else {
        tmp_0 = false;
      }

      tmp = tmp_0;
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  var allowed = tmp;
  if (!allowed)
    throw ContextAccessException.j75(block.a75_1, requester);
}
function address($this, scope, owner, parent, messages) {
  var sb = StringBuilder.v();
  var tmp = sb.tb(scope.n3_1).ub(_Char___init__impl__6a9atx(124));
  var tmp_0;
  var tmp_1 = owner;
  if ((tmp_1 == null ? null : new RunId(tmp_1)) == null) {
    tmp_0 = null;
  } else {
    tmp_0 = _RunId___get_value__impl__30zeiv(owner);
  }
  var tmp1_elvis_lhs = tmp_0;
  var tmp_2 = tmp.gh(tmp1_elvis_lhs == null ? new Long(-1, -1) : tmp1_elvis_lhs).ub(_Char___init__impl__6a9atx(124));
  var tmp_3;
  var tmp_4 = parent;
  if ((tmp_4 == null ? null : new ContextRef(tmp_4)) == null) {
    tmp_3 = null;
  } else {
    tmp_3 = _ContextRef___get_id__impl__uspq4f(parent);
  }
  var tmp3_elvis_lhs = tmp_3;
  tmp_2.tb(tmp3_elvis_lhs == null ? '' : tmp3_elvis_lhs).ub(_Char___init__impl__6a9atx(124));
  var _iterator__ex2g4s = messages.y();
  while (_iterator__ex2g4s.z()) {
    var m = _iterator__ex2g4s.a1();
    if (m instanceof Message)
      sb.tb(m.c5o_1.n3_1).ub(_Char___init__impl__6a9atx(58)).tb(m.f5t());
    else {
      if (m instanceof ToolCall)
        sb.tb('call:').tb(m.f69_1).ub(_Char___init__impl__6a9atx(58)).tb(m.g69_1);
      else {
        if (m instanceof ToolResult_0)
          sb.tb('result:').tb(_ItemRef___get_value__impl__fpjuyb(m.a69_1)).ub(_Char___init__impl__6a9atx(58)).tb(m.b69_1);
        else {
          if (m instanceof ReasoningSummary)
            sb.tb('reason:').tb(m.o6b_1);
          else {
            if (m instanceof ProviderItem)
              sb.tb('ext:').tb(_ProviderId___get_value__impl__xo1tux(m.a5z_1)).ub(_Char___init__impl__6a9atx(58)).tb(m.b5z_1).ub(_Char___init__impl__6a9atx(58)).tb(m.c5z_1);
            else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
    sb.ub(_Char___init__impl__6a9atx(10));
  }
  return 'blk-' + fnv1a($this, sb.toString());
}
function fnv1a($this, s) {
  var hash = new Long(-2078137563, -873292572);
  var prime = new Long(435, 256);
  var inductionVariable = 0;
  var last = s.length;
  while (inductionVariable < last) {
    var c = charSequenceGet(s, inductionVariable);
    inductionVariable = inductionVariable + 1 | 0;
    var tmp = hash;
    // Inline function 'kotlin.code' call
    var tmp$ret$0 = Char__toInt_impl_vasixd(c);
    hash = tmp.j4(toLong(tmp$ret$0));
    hash = hash.w3(prime);
  }
  // Inline function 'kotlin.toULong' call
  var this_0 = hash;
  var tmp$ret$1 = _ULong___init__impl__c78o9k(this_0);
  return toString_1(tmp$ret$1, 16) + '-' + s.length;
}
function ContextScope_GLOBAL_getInstance() {
  ContextScope_initEntries();
  return ContextScope_GLOBAL_instance;
}
function ContextScope_PRIVATE_getInstance() {
  ContextScope_initEntries();
  return ContextScope_PRIVATE_instance;
}
function ContextScope_TASK_getInstance() {
  ContextScope_initEntries();
  return ContextScope_TASK_instance;
}
function SupervisionPolicy$_init_$lambda_4mgt92(it) {
  return it instanceof Failed_1;
}
function *_generator_allow__mixmkr($this, agentName, policy, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.l70_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    var tmp$ret$0;
    $l$block_0: {
      var tmp0_elvis_lhs = policy.s75_1;
      var tmp_1;
      if (tmp0_elvis_lhs == null) {
        tmp$ret$0 = true;
        break $l$block_0;
      } else {
        tmp_1 = tmp0_elvis_lhs;
      }
      var cb = tmp_1;
      var tmp_2 = $this.n70_1.h3(agentName);
      var tmp1_elvis_lhs = tmp_2 == null ? null : tmp_2.lr_1;
      var tmp_3;
      var tmp_4 = tmp1_elvis_lhs;
      if ((tmp_4 == null ? null : new ValueTimeMark(tmp_4)) == null) {
        tmp$ret$0 = true;
        break $l$block_0;
      } else {
        tmp_3 = tmp1_elvis_lhs;
      }
      var mark = tmp_3;
      var tmp_5;
      if (_Duration___get_inWholeMilliseconds__impl__msfiry(ValueTimeMark__elapsedNow_impl_eonqvs(mark)).s1(cb.w75_1) >= 0) {
        $this.n70_1.l3(agentName);
        // Inline function 'kotlin.collections.set' call
        $this.m70_1.k3(agentName, 0);
        tmp_5 = true;
      } else {
        tmp_5 = false;
      }
      tmp$ret$0 = tmp_5;
    }
    tmp_0 = tmp$ret$0;
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function allow($this, agentName, policy, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_allow__mixmkr.bind(VOID, $this, agentName, policy), $completion);
}
function *_generator_record__kyyz4n($this, agentName, success, policy, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.l70_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    var cb = policy.s75_1;
    if (success) {
      // Inline function 'kotlin.collections.set' call
      $this.m70_1.k3(agentName, 0);
      var tmp_1 = $this.n70_1.l3(agentName);
      if (tmp_1 == null)
        null;
      else
        tmp_1.lr_1;
    } else if (!(cb == null)) {
      var tmp0_elvis_lhs = $this.m70_1.h3(agentName);
      var failures = (tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs) + 1 | 0;
      // Inline function 'kotlin.collections.set' call
      $this.m70_1.k3(agentName, failures);
      if (failures >= cb.v75_1) {
        var tmp6 = $this.n70_1;
        // Inline function 'kotlin.collections.set' call
        var value = new ValueTimeMark(Monotonic_instance.fj());
        tmp6.k3(agentName, value);
      }
    }
    tmp_0 = Unit_instance;
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function record($this, agentName, success, policy, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_record__kyyz4n.bind(VOID, $this, agentName, success, policy), $completion);
}
function backoffFor($this, attempt, policy) {
  var tmp2 = policy.p75_1;
  var tmp0 = policy.q75_1;
  // Inline function 'kotlin.math.pow' call
  var n = attempt - 1 | 0;
  // Inline function 'kotlin.Long.times' call
  var other = Math.pow(tmp0, n);
  var raw = tmp2.m4() * other;
  var tmp4 = numberToLong(raw);
  // Inline function 'kotlin.math.min' call
  var b = policy.r75_1;
  return tmp4.s1(b) <= 0 ? tmp4 : b;
}
function *_generator_run__cb7u2f_0($this, agentName, initialInput, policy, onRetrying, onCircuitOpen, attempt, $completion) {
  var tmp = allow($this, agentName, policy, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  if (!tmp) {
    onCircuitOpen();
    return new Failed_1(new ModelError("circuit open for agent '" + agentName + "'", false));
  }
  var tries = 0;
  var input = initialInput;
  while (true) {
    var tmp_0 = attempt(input, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    var result = tmp_0;
    if (!policy.t75_1(result)) {
      var tmp_1 = record($this, agentName, true, policy, $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      return result;
    }
    var tmp_2 = record($this, agentName, false, policy, $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    if (tries >= policy.o75_1)
      return result;
    var tmp_3 = allow($this, agentName, policy, $completion);
    if (tmp_3 === get_COROUTINE_SUSPENDED())
      tmp_3 = yield tmp_3;
    if (!tmp_3) {
      onCircuitOpen();
      return result;
    }
    tries = tries + 1 | 0;
    var backoff = backoffFor($this, tries, policy);
    onRetrying(tries, backoff);
    var tmp_4 = delay_0(backoff, $completion);
    if (tmp_4 === get_COROUTINE_SUSPENDED())
      tmp_4 = yield tmp_4;
    var tmp0_safe_receiver = policy.u75_1;
    var tmp_5;
    if (tmp0_safe_receiver == null) {
      tmp_5 = null;
    } else {
      var tmp_6 = tmp0_safe_receiver(tries, result, $completion);
      if (tmp_6 === get_COROUTINE_SUSPENDED())
        tmp_6 = yield tmp_6;
      tmp_5 = tmp_6;
    }
    var tmp1_elvis_lhs = tmp_5;
    input = tmp1_elvis_lhs == null ? input : tmp1_elvis_lhs;
  }
}
function *_generator_invoke__zhh2q8_41($this, value, $completion) {
  var tmp1 = $this.x75_1;
  $l$block: {
    if (value.rl_1 === $this.y75_1) {
      var tmp = tmp1.t1c(value, $completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
      break $l$block;
    }
  }
  return Unit_instance;
}
function *_generator_collect__dlomyy_0($this, collector, $completion) {
  var tmp = EventBus$subscribe$o$collect$slambda_1(collector, $this.a76_1);
  var tmp_0 = $this.z75_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_7(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function EventBus$subscribe$o$collect$slambda_1($$this$unsafeFlow, $topic) {
  var i = new EventBus$subscribe$o$collect$slambda($$this$unsafeFlow, $topic);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_42($this, value, $completion) {
  var $this$transform = $this.b76_1;
  var tmp$ret$0 = value.sl_1;
  var tmp = $this$transform.t1c(tmp$ret$0, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_collect__dlomyy_1($this, collector, $completion) {
  var tmp = EventBus$subscribe$o$collect$slambda_2(collector);
  var tmp_0 = $this.c76_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_7(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function EventBus$subscribe$o$collect$slambda_2($$this$unsafeFlow) {
  var i = new EventBus$subscribe$o$collect$slambda_0($$this$unsafeFlow);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_publish__pkz857($this, topic, message, $completion) {
  var tmp = $this.d76_1.t1c(to(topic, message), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_send__qhx0g0($this, message, $completion) {
  var tmp = message.j76_1;
  var tmp0 = tmp == null ? null : new RunId(tmp);
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.requireNotNull' call
    if (tmp0 == null) {
      var message_0 = 'send requires a receiver';
      throw IllegalArgumentException.t(toString(message_0));
    } else {
      tmp$ret$1 = tmp0.z6w_1;
      break $l$block;
    }
  }
  var target = tmp$ret$1;
  var tmp_0 = $this.d6y(target).s76(message, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function *_generator_request__hjt9xh_0($this, message, $completion) {
  var correlation = $this.t76();
  var deferred = CompletableDeferred();
  var tmp0 = $this.b6y_1;
  $l$block: {
    // Inline function 'kotlinx.coroutines.flow.update' call
    while (true) {
      var prevValue = tmp0.n1();
      var nextValue = plus_1(prevValue, to(correlation, deferred));
      if (tmp0.u1e(prevValue, nextValue)) {
        break $l$block;
      }
    }
  }
  try {
    var tmp = $this.v76(message.u76(VOID, VOID, VOID, VOID, VOID, VOID, VOID, VOID, correlation), $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var tmp_0 = deferred.vw($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    return tmp_0;
  }finally {
    var tmp2 = $this.b6y_1;
    $l$block_0: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue_0 = tmp2.n1();
        var nextValue_0 = minus(prevValue_0, correlation);
        if (tmp2.u1e(prevValue_0, nextValue_0)) {
          break $l$block_0;
        }
      }
    }
  }
}
function *_generator_reply__ugx4wa($this, to, payload, contextRefs, $completion) {
  var tmp0 = to.p76_1;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.requireNotNull' call
    if (tmp0 == null) {
      var message = 'message is not a request';
      throw IllegalArgumentException.t(toString(message));
    } else {
      tmp$ret$1 = tmp0;
      break $l$block;
    }
  }
  var correlation = tmp$ret$1;
  var response = new RuntimeMessage($this.t76(), to.j76_1, to.i76_1, to.k76_1 + '.reply', payload, contextRefs, VOID, VOID, correlation);
  var deferred = $this.b6y_1.n1().h3(correlation);
  if (!(deferred == null) && deferred.z11(response)) {
    var tmp1 = $this.b6y_1;
    $l$block_0: {
      // Inline function 'kotlinx.coroutines.flow.update' call
      while (true) {
        var prevValue = tmp1.n1();
        var nextValue = minus(prevValue, correlation);
        if (tmp1.u1e(prevValue, nextValue)) {
          break $l$block_0;
        }
      }
    }
  } else {
    var tmp0_safe_receiver = to.i76_1;
    var tmp = tmp0_safe_receiver;
    if ((tmp == null ? null : new RunId(tmp)) == null)
      null;
    else {
      var tmp_0 = tmp0_safe_receiver;
      // Inline function 'kotlin.let' call
      var it = (tmp_0 == null ? null : new RunId(tmp_0)).z6w_1;
      var tmp_1 = $this.d6y(it).s76(response, $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
    }
  }
  return Unit_instance;
}
var Inherit_instance;
function Inherit_getInstance() {
  return Inherit_instance;
}
var Ephemeral_instance;
function Ephemeral_getInstance() {
  return Ephemeral_instance;
}
var ChildFailurePolicy_PROPAGATE_instance;
var ChildFailurePolicy_CAPTURE_instance;
var ChildFailurePolicy_entriesInitialized;
function ChildFailurePolicy_initEntries() {
  if (ChildFailurePolicy_entriesInitialized)
    return Unit_instance;
  ChildFailurePolicy_entriesInitialized = true;
  ChildFailurePolicy_PROPAGATE_instance = new ChildFailurePolicy('PROPAGATE', 0);
  ChildFailurePolicy_CAPTURE_instance = new ChildFailurePolicy('CAPTURE', 1);
}
function ChildFailurePolicy_PROPAGATE_getInstance() {
  ChildFailurePolicy_initEntries();
  return ChildFailurePolicy_PROPAGATE_instance;
}
function ChildFailurePolicy_CAPTURE_getInstance() {
  ChildFailurePolicy_initEntries();
  return ChildFailurePolicy_CAPTURE_instance;
}
var BranchState_RUNNABLE_instance;
var BranchState_WAITING_instance;
var BranchState_entriesInitialized;
function BranchState_initEntries() {
  if (BranchState_entriesInitialized)
    return Unit_instance;
  BranchState_entriesInitialized = true;
  BranchState_RUNNABLE_instance = new BranchState('RUNNABLE', 0);
  BranchState_WAITING_instance = new BranchState('WAITING', 1);
}
function *_generator_invoke__zhh2q8_43($this, $this$withContext, $completion) {
  var tmp = complete($this.o77_1, $this.p77_1.q77_1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_44($this, $this$withContext, $completion) {
  var tmp;
  try {
    var tmp_0 = $this.s77_1($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  }finally {
    var tmp_1 = NonCancellable_getInstance();
    var tmp_2 = withContext(tmp_1, InstanceActivityGate$Branch$run$slambda$slambda_0($this.t77_1, $this.u77_1), $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
  }
  return tmp;
}
function InstanceActivityGate$Branch$run$slambda$slambda_0(this$0, this$1) {
  var i = new InstanceActivityGate$Branch$run$slambda$slambda(this$0, this$1);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function InstanceActivityGate$Branch$run$slambda_0($block, this$0, this$1) {
  var i = new InstanceActivityGate$Branch$run$slambda($block, this$0, this$1);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
var Key_instance_0;
function Key_getInstance_0() {
  return Key_instance_0;
}
function *_generator_invoke__zhh2q8_45($this, $this$withContext, $completion) {
  var tmp = complete($this.v77_1, $this.w77_1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_attachLease__qxpozj($this, l, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.j6s_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    $this.n6s_1 = l;
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function currentBranchId($this, $completion) {
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var tmp0_safe_receiver = $completion.lc().yc(Key_instance_0);
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.a78_1;
  return tmp1_elvis_lhs == null ? new Long(0, 0) : tmp1_elvis_lhs;
}
function *_generator_enterWaiting__jsjsyb($this, $completion) {
  var tmp = currentBranchId($this, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var id = tmp;
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.j6s_1;
  var tmp_0 = this_0.c1i(null, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  try {
    var tmp0_elvis_lhs = $this.k6s_1.h3(id);
    var tmp_1;
    if (tmp0_elvis_lhs == null) {
      return Unit_instance;
    } else {
      tmp_1 = tmp0_elvis_lhs;
    }
    var branch = tmp_1;
    branch.y77_1 = branch.y77_1 + 1 | 0;
    if (branch.y77_1 > 1)
      return Unit_instance;
    // Inline function 'kotlin.check' call
    if (!branch.x77_1.equals(BranchState_RUNNABLE_getInstance())) {
      var message = 'branch ' + id.toString() + ' is not runnable';
      throw IllegalStateException.t4(toString(message));
    }
    branch.x77_1 = BranchState_WAITING_getInstance();
    $this.m6s_1 = $this.m6s_1 - 1 | 0;
    if ($this.m6s_1 === 0) {
      var tmp_2 = parkAndMarkWaiting($this, $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
    }
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_leaveWaiting__c8ig4y($this, $completion) {
  var tmp = currentBranchId($this, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var id = tmp;
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.j6s_1;
  var tmp_0 = this_0.c1i(null, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  try {
    var tmp0_elvis_lhs = $this.k6s_1.h3(id);
    var tmp_1;
    if (tmp0_elvis_lhs == null) {
      return Unit_instance;
    } else {
      tmp_1 = tmp0_elvis_lhs;
    }
    var branch = tmp_1;
    if (branch.y77_1 === 0)
      return Unit_instance;
    branch.y77_1 = branch.y77_1 - 1 | 0;
    if (branch.y77_1 > 0)
      return Unit_instance;
    // Inline function 'kotlin.check' call
    if (!branch.x77_1.equals(BranchState_WAITING_getInstance())) {
      var message = 'branch ' + id.toString() + ' is not waiting';
      throw IllegalStateException.t4(toString(message));
    }
    branch.x77_1 = BranchState_RUNNABLE_getInstance();
    var _unary__edvuaz = $this.m6s_1;
    $this.m6s_1 = _unary__edvuaz + 1 | 0;
    if (_unary__edvuaz === 0) {
      var tmp_2 = unparkAndMarkRunning($this, $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
    }
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_waiting__s4e4jr_0($this, block, $completion) {
  var tmp = currentBranchId($this, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var id = tmp;
  var tmp_0 = $this.a5s($completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  try {
    var tmp_1 = block($completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    return tmp_1;
  }finally {
    // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
    // Inline function 'kotlin.js.getCoroutineContext' call
    var tmp$ret$1 = $completion.lc();
    if (get_isActive(tmp$ret$1)) {
      var tmp_2 = $this.b5s($completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
    } else {
      var tmp_3 = NonCancellable_getInstance();
      var tmp_4 = withContext(tmp_3, InstanceActivityGate$waiting$slambda_0($this, id), $completion);
      if (tmp_4 === get_COROUTINE_SUSPENDED())
        tmp_4 = yield tmp_4;
    }
  }
}
function *_generator_forkBranch__qr9t6k($this, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.j6s_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    var _unary__edvuaz = $this.l6s_1;
    $this.l6s_1 = _unary__edvuaz.z3();
    var newId = _unary__edvuaz;
    var tmp0 = $this.k6s_1;
    // Inline function 'kotlin.collections.set' call
    var value = new BranchRecord(BranchState_RUNNABLE_getInstance());
    tmp0.k3(newId, value);
    var _unary__edvuaz_0 = $this.m6s_1;
    $this.m6s_1 = _unary__edvuaz_0 + 1 | 0;
    if (_unary__edvuaz_0 === 0) {
      var tmp_1 = unparkAndMarkRunning($this, $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
    }
    tmp_0 = newId;
  }finally {
    this_0.n1h(null);
  }
  var id = tmp_0;
  return new Branch($this, id);
}
function *_generator_complete__c6035b($this, id, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.j6s_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    var tmp0_safe_receiver = $this.k6s_1.l3(id);
    var tmp1_subject = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.x77_1;
    switch (tmp1_subject == null ? -1 : tmp1_subject.o3_1) {
      case 0:
        $this.m6s_1 = $this.m6s_1 - 1 | 0;
        if ($this.m6s_1 === 0) {
          var tmp_0 = parkAndMarkWaiting($this, $completion);
          if (tmp_0 === get_COROUTINE_SUSPENDED())
            tmp_0 = yield tmp_0;
        }

        break;
      case 1:
      case -1:
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function complete($this, id, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_complete__c6035b.bind(VOID, $this, id), $completion);
}
function *_generator_parkAndMarkWaiting__20zyt1($this, $completion) {
  if ($this.f6s_1.w6q().c6r_1.equals(LifecycleState_RUNNING_getInstance())) {
    $this.f6s_1.n6v(LifecycleState_WAITING_getInstance());
    var snapshot = $this.f6s_1.w6q();
    $this.g6s_1(new Waiting($this.e6s_1, snapshot.y6q_1, snapshot.a6r_1, snapshot.b6r_1));
  }
  var tmp = $this.n6s_1.b78($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function parkAndMarkWaiting($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_parkAndMarkWaiting__20zyt1.bind(VOID, $this), $completion);
}
function *_generator_unparkAndMarkRunning__848w0a($this, $completion) {
  var tmp = $this.n6s_1.c78($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  if ($this.f6s_1.w6q().c6r_1.equals(LifecycleState_WAITING_getInstance())) {
    $this.f6s_1.p6s();
    $this.g6s_1(new Running($this.e6s_1, $this.f6s_1.w6q().y6q_1, $this.f6s_1.w6q().a6r_1, $this.f6s_1.w6q().b6r_1, $this.f6s_1.w6q().z6q_1));
  }
  return Unit_instance;
}
function unparkAndMarkRunning($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_unparkAndMarkRunning__848w0a.bind(VOID, $this), $completion);
}
var NoopLease_instance;
function NoopLease_getInstance() {
  return NoopLease_instance;
}
function InstanceActivityGate$_init_$lambda_k8xejg() {
  return Unit_instance;
}
function InstanceActivityGate$waiting$slambda_0(this$0, $id) {
  var i = new InstanceActivityGate$waiting$slambda(this$0, $id);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function BranchState_RUNNABLE_getInstance() {
  BranchState_initEntries();
  return BranchState_RUNNABLE_instance;
}
function BranchState_WAITING_getInstance() {
  BranchState_initEntries();
  return BranchState_WAITING_instance;
}
var Companion_instance_45;
function Companion_getInstance_49() {
  if (Companion_instance_45 === VOID)
    new Companion_43();
  return Companion_instance_45;
}
var AccessMode_READ_instance;
var AccessMode_WRITE_instance;
var AccessMode_entriesInitialized;
function AccessMode_initEntries() {
  if (AccessMode_entriesInitialized)
    return Unit_instance;
  AccessMode_entriesInitialized = true;
  AccessMode_READ_instance = new AccessMode('READ', 0);
  AccessMode_WRITE_instance = new AccessMode('WRITE', 1);
}
function *_generator_mutexFor__g41i0y($this, id, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.d78_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    // Inline function 'kotlin.collections.getOrPut' call
    var this_1 = $this.e78_1;
    var value = this_1.h3(id);
    var tmp_1;
    if (value == null) {
      var answer = Mutex();
      this_1.k3(id, answer);
      tmp_1 = answer;
    } else {
      tmp_1 = value;
    }
    tmp_0 = tmp_1;
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function mutexFor($this, id, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_mutexFor__g41i0y.bind(VOID, $this, id), $completion);
}
function *_generator_withResource__nj2v70($this, id, mode, block, $completion) {
  var tmp = mutexFor($this, id, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var lock = tmp;
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var tmp_0 = lock.c1i(null, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var tmp_1;
  try {
    var tmp_2 = block($completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    tmp_1 = tmp_2;
  }finally {
    lock.n1h(null);
  }
  return tmp_1;
}
function AccessMode_READ_getInstance() {
  AccessMode_initEntries();
  return AccessMode_READ_instance;
}
function AccessMode_WRITE_getInstance() {
  AccessMode_initEntries();
  return AccessMode_WRITE_instance;
}
function *_generator_withRuntimeResource__e9s1jo(id, mode, block, $completion) {
  mode = mode === VOID ? AccessMode_WRITE_getInstance() : mode;
  var tmp = currentRuntimeContext($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp0_elvis_lhs = tmp;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    var tmp_1 = block($completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    return tmp_1;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var ctx = tmp_0;
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var tmp1_elvis_lhs = $completion.lc().yc(Key_instance);
  var tmp_2;
  if (tmp1_elvis_lhs == null) {
    var tmp_3 = ctx.h78_1.f78(id, mode, block, $completion);
    if (tmp_3 === get_COROUTINE_SUSPENDED())
      tmp_3 = yield tmp_3;
    return tmp_3;
  } else {
    tmp_2 = tmp1_elvis_lhs;
  }
  var exec = tmp_2;
  var tmp_4 = exec.a5s($completion);
  if (tmp_4 === get_COROUTINE_SUSPENDED())
    tmp_4 = yield tmp_4;
  try {
    var tmp_5 = ctx.h78_1.f78(id, mode, withRuntimeResource$slambda_0(exec, block), $completion);
    if (tmp_5 === get_COROUTINE_SUSPENDED())
      tmp_5 = yield tmp_5;
    return tmp_5;
  }finally {
    var tmp_6 = exec.b5s($completion);
    if (tmp_6 === get_COROUTINE_SUSPENDED())
      tmp_6 = yield tmp_6;
  }
}
function withRuntimeResource(id, mode, block, $completion) {
  mode = mode === VOID ? AccessMode_WRITE_getInstance() : mode;
  return suspendOrReturn(/*#__NOINLINE__*/_generator_withRuntimeResource__e9s1jo.bind(VOID, id, mode, block), $completion);
}
var Key_instance_1;
function Key_getInstance_1() {
  return Key_instance_1;
}
function currentRuntimeContext($completion) {
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  return $completion.lc().yc(Key_instance_1);
}
function *_generator_invoke__zhh2q8_46($this, $completion) {
  var tmp = $this.q78_1.b5s($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0 = $this.r78_1($completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return tmp_0;
}
function withRuntimeResource$slambda_0($exec, $block) {
  var i = new withRuntimeResource$slambda($exec, $block);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
var LeaseState_HELD_instance;
var LeaseState_PARKED_instance;
var LeaseState_CLOSED_instance;
var LeaseState_entriesInitialized;
function LeaseState_initEntries() {
  if (LeaseState_entriesInitialized)
    return Unit_instance;
  LeaseState_entriesInitialized = true;
  LeaseState_HELD_instance = new LeaseState('HELD', 0);
  LeaseState_PARKED_instance = new LeaseState('PARKED', 1);
  LeaseState_CLOSED_instance = new LeaseState('CLOSED', 2);
}
function *_generator_invoke__zhh2q8_47($this, $this$withContext, $completion) {
  var tmp = release($this.s78_1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_48($this, $this$withContext, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.x78_1.u78_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    if ($this.x78_1.v78_1.equals(LeaseState_HELD_getInstance())) {
      var tmp_0 = release($this.y78_1, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
    }
    $this.x78_1.v78_1 = LeaseState_CLOSED_getInstance();
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_park__qjmv1e($this, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.u78_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    if (!$this.v78_1.equals(LeaseState_HELD_getInstance()))
      return Unit_instance;
    var tmp_0 = NonCancellable_getInstance();
    var tmp_1 = withContext(tmp_0, Scheduler$Lease$park$slambda_0($this.w78_1), $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    $this.v78_1 = LeaseState_PARKED_getInstance();
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_unpark__1kn8kb($this, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.u78_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    if (!$this.v78_1.equals(LeaseState_PARKED_getInstance()))
      return Unit_instance;
    var tmp_0 = acquire($this.w78_1, $this.t78_1, true, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    $this.v78_1 = LeaseState_HELD_getInstance();
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_close__nh2uv0($this, $completion) {
  var tmp = NonCancellable_getInstance();
  var tmp_0 = withContext(tmp, Scheduler$Lease$close$slambda_0($this, $this.w78_1), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function Scheduler$Lease$park$slambda_0(this$0) {
  var i = new Scheduler$Lease$park$slambda(this$0);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function Scheduler$Lease$close$slambda_0(this$0, this$1) {
  var i = new Scheduler$Lease$close$slambda(this$0, this$1);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_49($this, $this$withContext, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.z78_1.r6y_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    var stillWaiting = $this.z78_1.u6y_1.z2($this.a79_1);
    if (!stillWaiting) {
      handOffOrDecrement($this.z78_1);
    }
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_withSlot__kr663g($this, priority, block, $completion) {
  var tmp = acquire($this, priority, false, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var lease = new Lease($this, priority);
  try {
    var tmp_0 = block(lease, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    return tmp_0;
  }finally {
    var tmp_1 = lease.f79($completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
  }
}
function *_generator_acquire__4kqfvm_0($this, priority, resume, $completion) {
  if ($this.q6y_1)
    return Unit_instance;
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.r6y_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    if ($this.s6y_1 < $this.p6y_1) {
      $this.s6y_1 = $this.s6y_1 + 1 | 0;
      return Unit_instance;
    }
    var _unary__edvuaz = $this.t6y_1;
    $this.t6y_1 = _unary__edvuaz.z3();
    // Inline function 'kotlin.also' call
    var this_1 = new Waiter(priority, _unary__edvuaz, resume);
    // Inline function 'kotlin.collections.plusAssign' call
    $this.u6y_1.l(this_1);
    tmp_0 = this_1;
  }finally {
    this_0.n1h(null);
  }
  var waiter = tmp_0;
  try {
    var tmp_1 = waiter.e79_1.vw($completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
  } catch ($p) {
    if ($p instanceof CancellationException) {
      var c = $p;
      var tmp_2 = NonCancellable_getInstance();
      var tmp_3 = withContext(tmp_2, Scheduler$acquire$slambda_0($this, waiter), $completion);
      if (tmp_3 === get_COROUTINE_SUSPENDED())
        tmp_3 = yield tmp_3;
      throw c;
    } else {
      throw $p;
    }
  }
  return Unit_instance;
}
function acquire($this, priority, resume, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_acquire__4kqfvm_0.bind(VOID, $this, priority, resume), $completion);
}
function *_generator_release__expw5p($this, $completion) {
  if ($this.q6y_1)
    return Unit_instance;
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.r6y_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    handOffOrDecrement($this);
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function release($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_release__expw5p.bind(VOID, $this), $completion);
}
function handOffOrDecrement($this) {
  // Inline function 'kotlin.comparisons.compareByDescending' call
  var tmp = Scheduler$handOffOrDecrement$lambda;
  // Inline function 'kotlin.comparisons.thenByDescending' call
  var this_0 = new sam$kotlin_Comparator$0_0(tmp);
  var tmp_0 = Scheduler$handOffOrDecrement$lambda_0(this_0);
  // Inline function 'kotlin.comparisons.thenBy' call
  var this_1 = new sam$kotlin_Comparator$0_0(tmp_0);
  var tmp_1 = Scheduler$handOffOrDecrement$lambda_1(this_1);
  var tmp$ret$2 = new sam$kotlin_Comparator$0_0(tmp_1);
  var next = minWithOrNull($this.u6y_1, tmp$ret$2);
  if (!(next == null)) {
    $this.u6y_1.z2(next);
    next.e79_1.z11(Unit_instance);
  } else {
    $this.s6y_1 = $this.s6y_1 - 1 | 0;
  }
}
function Scheduler$acquire$slambda_0(this$0, $waiter) {
  var i = new Scheduler$acquire$slambda(this$0, $waiter);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
function Scheduler$handOffOrDecrement$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = b.b79_1;
  var tmp$ret$1 = a.b79_1;
  return compareValues(tmp, tmp$ret$1);
}
function Scheduler$handOffOrDecrement$lambda_0($this) {
  return (a, b) => {
    var previousCompare = $this.compare(a, b);
    var tmp;
    if (!(previousCompare === 0)) {
      tmp = previousCompare;
    } else {
      // Inline function 'kotlin.comparisons.compareValuesBy' call
      var tmp_0 = b.d79_1;
      var tmp$ret$1 = a.d79_1;
      tmp = compareValues(tmp_0, tmp$ret$1);
    }
    return tmp;
  };
}
function Scheduler$handOffOrDecrement$lambda_1($this) {
  return (a, b) => {
    var previousCompare = $this.compare(a, b);
    var tmp;
    if (!(previousCompare === 0)) {
      tmp = previousCompare;
    } else {
      // Inline function 'kotlin.comparisons.compareValuesBy' call
      var tmp_0 = a.c79_1;
      var tmp$ret$1 = b.c79_1;
      tmp = compareValues(tmp_0, tmp$ret$1);
    }
    return tmp;
  };
}
function LeaseState_HELD_getInstance() {
  LeaseState_initEntries();
  return LeaseState_HELD_instance;
}
function LeaseState_PARKED_getInstance() {
  LeaseState_initEntries();
  return LeaseState_PARKED_instance;
}
function LeaseState_CLOSED_getInstance() {
  LeaseState_initEntries();
  return LeaseState_CLOSED_instance;
}
function taskGraph(block) {
  // Inline function 'kotlin.apply' call
  var this_0 = new TaskGraphBuilder();
  block(this_0);
  return this_0.h2o();
}
function detectCycle($this, nodes) {
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(nodes, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination = LinkedHashMap.ic(capacity);
  var _iterator__ex2g4s = nodes.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp$ret$0 = element.m6w_1;
    destination.k3(tmp$ret$0, element);
  }
  var byId = destination;
  var visiting = HashSet.ga();
  var done = HashSet.ga();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_0 = nodes.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    detectCycle$dfs(done, visiting, byId, element_0.m6w_1);
  }
}
function detectCycle$dfs(done, visiting, byId, id) {
  if (done.v2(id))
    return Unit_instance;
  // Inline function 'kotlin.require' call
  if (!!visiting.v2(id)) {
    var message = "task graph has a cycle involving '" + id + "'";
    throw IllegalArgumentException.t(toString(message));
  }
  // Inline function 'kotlin.collections.plusAssign' call
  visiting.l(id);
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = getValue(byId, id).p6w_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    detectCycle$dfs(done, visiting, byId, element);
  }
  // Inline function 'kotlin.collections.minusAssign' call
  visiting.z2(id);
  // Inline function 'kotlin.collections.plusAssign' call
  done.l(id);
}
function TaskGraphBuilder$task$slambda_0($input) {
  var i = new TaskGraphBuilder$task$slambda($input);
  var l = (it, $completion) => i.j79(it, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_memory__irlkfb($this, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.v79_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    var tmp0_elvis_lhs = $this.w79_1.n1();
    var tmp_1;
    if (tmp0_elvis_lhs == null) {
      var tmp_2 = $this.s79_1.p68($this.r79_1, $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      // Inline function 'kotlin.also' call
      var this_1 = tmp_2;
      $this.w79_1.t1e(this_1);
      tmp_1 = this_1;
    } else {
      tmp_1 = tmp0_elvis_lhs;
    }
    tmp_0 = tmp_1;
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function *_generator_await__mos7q6_1($this, $completion) {
  var tmp = $this.i6y_1.vw($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return new ThreadLease($this.h6y_1, $this.i6y_1);
}
function bind($this, threadId, agent) {
  while (true) {
    var current = $this.w6x_1.n1();
    var existing = current.h3(new ThreadId(threadId));
    if (!(existing == null)) {
      validateProvider($this, threadId, existing.s79_1, agent.v5m_1);
      var tmp0 = existing.t79_1;
      $l$block: {
        // Inline function 'kotlinx.coroutines.flow.update' call
        while (true) {
          var prevValue = tmp0.n1();
          var nextValue = plus_2(prevValue, new AgentId(agent.i5m_1));
          if (tmp0.u1e(prevValue, nextValue)) {
            break $l$block;
          }
        }
      }
      return existing;
    }
    var tmp0_elvis_lhs = agent.v5m_1;
    var created = new ThreadBinding(threadId, tmp0_elvis_lhs == null ? $this.v6x_1 : tmp0_elvis_lhs, agent.i5m_1);
    if ($this.w6x_1.u1e(current, plus_1(current, to(new ThreadId(threadId), created))))
      return created;
  }
}
function validateProvider($this, threadId, existing, requested) {
  if (!(requested == null) && !(requested.a5r() === existing.a5r())) {
    throw ThreadMemoryPolicyConflictException.g7a(threadId, _MemoryProviderId___get_value__impl__90yl20(existing.a5r()), _MemoryProviderId___get_value__impl__90yl20(requested.a5r()));
  }
}
function *_generator_await__mos7q6_2($this, $completion) {
  try {
    var tmp = $this.x79_1.m7a_1.vw($completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  } catch ($p) {
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      $this.g2j();
      throw cancelled;
    } else {
      throw $p;
    }
  }
  return Unit_instance;
}
function provideEngine() {
  return Js_instance;
}
function *_generator_defaultSkillFileSystem__wqa8a5($completion) {
  var tmp;
  if (isNodeRuntime()) {
    var tmp_0 = Companion_instance_46.r7a($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } else {
    tmp = null;
  }
  return tmp;
}
function defaultSkillFileSystem($completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_defaultSkillFileSystem__wqa8a5.bind(VOID), $completion);
}
function isNodeRuntime() {
  var tmp = typeof process !== 'undefined' && process.versions != null && process.versions.node != null;
  return (!(tmp == null) ? typeof tmp === 'boolean' : false) ? tmp : THROW_CCE();
}
function *_generator_create__k2snpo($this, $completion) {
  var importer = new Function('specifier', 'return import(specifier)');
  var tmp = importer('node:fs');
  var tmp_0 = await_0(tmp instanceof Promise ? tmp : THROW_CCE(), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var fs = tmp_0;
  return new NodeSkillFileSystem(fs);
}
var Companion_instance_46;
function Companion_getInstance_50() {
  return Companion_instance_46;
}
//region block: post-declaration
initMetadataForLambda(Agent$executeStream$slambda, VOID, VOID, [1]);
initMetadataForLambda(Agent$executeStructuredStream$slambda, VOID, VOID, [1]);
initMetadataForClass(Agent, 'Agent', VOID, VOID, [AutoCloseable], [0, 2, 1, 3]);
initMetadataForObject(AgentDefinitionIds, 'AgentDefinitionIds');
initMetadataForClass(AgentBuilder, 'AgentBuilder', AgentBuilder);
initMetadataForClass(MemoryScope, 'MemoryScope', MemoryScope);
initMetadataForInterface(AgentEvent, 'AgentEvent');
initMetadataForClass(TextDelta, 'TextDelta', VOID, VOID, [AgentEvent]);
initMetadataForClass(ReasoningDelta, 'ReasoningDelta', VOID, VOID, [AgentEvent]);
initMetadataForClass(ToolCallRequested, 'ToolCallRequested', VOID, VOID, [AgentEvent]);
initMetadataForClass(ToolResult, 'ToolResult', VOID, VOID, [AgentEvent]);
initMetadataForClass(ToolProgress, 'ToolProgress', VOID, VOID, [AgentEvent]);
initMetadataForClass(StepCompleted, 'StepCompleted', VOID, VOID, [AgentEvent]);
initMetadataForInterface(Terminal, 'Terminal', VOID, VOID, [AgentEvent]);
initMetadataForClass(Completed, 'Completed', VOID, VOID, [Terminal]);
initMetadataForClass(Incomplete, 'Incomplete', VOID, VOID, [Terminal]);
initMetadataForClass(Terminated, 'Terminated', VOID, VOID, [Terminal]);
initMetadataForClass(Failed, 'Failed', VOID, VOID, [AgentEvent]);
initMetadataForObject(Key, 'Key');
initMetadataForClass(AgentExecutionContext, 'AgentExecutionContext', VOID, VOID, VOID, [0, 1]);
initMetadataForClass(ExecutionIdentity, 'ExecutionIdentity');
initMetadataForClass(AgentId, 'AgentId');
initMetadataForObject(Pending, 'Pending');
initMetadataForClass(Ready, 'Ready');
initMetadataForClass(Failed_0, 'Failed');
initMetadataForClass(AgentPreparation, 'AgentPreparation', VOID, VOID, VOID, [0]);
initMetadataForClass(PreparedAgentDefinition, 'PreparedAgentDefinition');
initMetadataForInterface(AgentResult, 'AgentResult');
protoOf(Completed_0).f5t = get_text;
initMetadataForClass(Completed_0, 'Completed', VOID, VOID, [AgentResult]);
protoOf(Incomplete_0).f5t = get_text;
initMetadataForClass(Incomplete_0, 'Incomplete', VOID, VOID, [AgentResult]);
protoOf(Terminated_0).f5t = get_text;
initMetadataForClass(Terminated_0, 'Terminated', VOID, VOID, [AgentResult]);
protoOf(Failed_1).f5t = get_text;
initMetadataForClass(Failed_1, 'Failed', VOID, VOID, [AgentResult]);
initMetadataForLambda(AgentRunner$stream$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRunner$runLoop$slambda$slambda$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRunner$runLoop$slambda$slambda$slambda, VOID, VOID, [0]);
initMetadataForLambda(AgentRunner$runLoop$slambda$slambda$slambda_0, VOID, VOID, [0]);
initMetadataForLambda(AgentRunner$runLoop$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRunner$runLoop$slambda$slambda_0, VOID, VOID, [0]);
initMetadataForLambda(AgentRunner$streamStructured$slambda$slambda, VOID, VOID, [1]);
initMetadataForClass(LoopRun, 'LoopRun');
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_0, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForLambda(AgentRunner$stream$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRunner$runLoop$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRunner$runLoop$slambda_0, VOID, VOID, [1]);
initMetadataForLambda(AgentRunner$streamStructured$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRunner$runStructured$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRunner$runStructured$slambda_0, VOID, VOID, [1]);
initMetadataForClass(AgentRunner, 'AgentRunner', VOID, VOID, VOID, [5, 4, 6, 2, 3, 1]);
initMetadataForClass(AgentState, 'AgentState');
initMetadataForClass(InstructionsScope, 'InstructionsScope', InstructionsScope);
initMetadataForCompanion(Companion);
initMetadataForClass(Instructions, 'Instructions', VOID, VOID, VOID, [0]);
initMetadataForClass(Static, 'Static');
initMetadataForClass(Dynamic, 'Dynamic');
initMetadataForClass(ModelFailure, 'ModelFailure');
initMetadataForClass(ModelScope, 'ModelScope', ModelScope);
initMetadataForClass(ModelSelection, 'ModelSelection');
initMetadataForClass(TransportInfo, 'TransportInfo');
initMetadataForClass(OutputSpec, 'OutputSpec');
initMetadataForClass(ToolCallBuilder, 'ToolCallBuilder', ToolCallBuilder);
initMetadataForClass(ToolScope, 'ToolScope');
initMetadataForClass(TurnBuilder, 'TurnBuilder');
initMetadataForClass(McpToolSource, 'McpToolSource', VOID, VOID, VOID, [0]);
initMetadataForInterface(Tool, 'Tool', VOID, VOID, VOID, [1]);
protoOf(McpToolAdapter).y61 = get_returnDirectly;
protoOf(McpToolAdapter).z61 = get_hasSideEffects;
initMetadataForClass(McpToolAdapter, 'McpToolAdapter', VOID, VOID, [Tool], [1]);
initMetadataForClass(DefaultMcpClient, 'DefaultMcpClient', VOID, VOID, [AutoCloseable], [0, 1, 2]);
initMetadataForCompanion(Companion_0);
protoOf($serializer).v25 = typeParametersSerializers;
initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(CallToolParams, 'CallToolParams', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
initMetadataForClass(HttpMcpTransport, 'HttpMcpTransport', VOID, VOID, VOID, [4, 3]);
initMetadataForCompanion(Companion_1);
protoOf($serializer_0).v25 = typeParametersSerializers;
initMetadataForObject($serializer_0, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_2);
protoOf($serializer_1).v25 = typeParametersSerializers;
initMetadataForObject($serializer_1, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_3);
protoOf($serializer_2).v25 = typeParametersSerializers;
initMetadataForObject($serializer_2, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_4);
protoOf($serializer_3).v25 = typeParametersSerializers;
initMetadataForObject($serializer_3, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_5);
protoOf($serializer_4).v25 = typeParametersSerializers;
initMetadataForObject($serializer_4, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(Params, 'Params', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
initMetadataForClass(Capabilities, 'Capabilities', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_1});
initMetadataForClass(Roots, 'Roots', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_2});
initMetadataForClass(Sampling, 'Sampling', Sampling, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_3});
initMetadataForClass(ClientInfo, 'ClientInfo', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_4});
initMetadataForCompanion(Companion_6);
protoOf($serializer_5).v25 = typeParametersSerializers;
initMetadataForObject($serializer_5, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(InitRequest, 'InitRequest', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_5});
initMetadataForCompanion(Companion_7);
protoOf($serializer_6).v25 = typeParametersSerializers;
initMetadataForObject($serializer_6, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_8);
protoOf($serializer_7).v25 = typeParametersSerializers;
initMetadataForObject($serializer_7, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_9);
protoOf($serializer_8).v25 = typeParametersSerializers;
initMetadataForObject($serializer_8, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_10);
protoOf($serializer_9).v25 = typeParametersSerializers;
initMetadataForObject($serializer_9, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_11);
protoOf($serializer_10).v25 = typeParametersSerializers;
initMetadataForObject($serializer_10, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_12);
protoOf($serializer_11).v25 = typeParametersSerializers;
initMetadataForObject($serializer_11, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_13);
protoOf($serializer_12).v25 = typeParametersSerializers;
initMetadataForObject($serializer_12, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(Result_0, 'Result', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_6});
initMetadataForClass(Capabilities_0, 'Capabilities', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_7});
initMetadataForClass(Logging, 'Logging', Logging, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_8});
initMetadataForClass(Prompts, 'Prompts', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_9});
initMetadataForClass(Resources, 'Resources', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_10});
initMetadataForClass(Tools, 'Tools', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_11});
initMetadataForClass(ServerInfo, 'ServerInfo', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_12});
initMetadataForCompanion(Companion_14);
protoOf($serializer_13).v25 = typeParametersSerializers;
initMetadataForObject($serializer_13, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(InitResponse, 'InitResponse', InitResponse, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_13});
initMetadataForCompanion(Companion_15);
protoOf($serializer_14).v25 = typeParametersSerializers;
initMetadataForObject($serializer_14, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(InitializedRequest, 'InitializedRequest', InitializedRequest, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_14});
initMetadataForClass(McpClientConfig, 'McpClientConfig');
initMetadataForCompanion(Companion_16);
protoOf($serializer_15).v25 = typeParametersSerializers;
initMetadataForObject($serializer_15, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(Data, 'Data', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_15});
initMetadataForCompanion(Companion_17);
protoOf($serializer_16).v25 = typeParametersSerializers;
initMetadataForObject($serializer_16, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(McpError, 'McpError', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_16});
initMetadataForCompanion(Companion_18);
protoOf($serializer_17).v25 = typeParametersSerializers;
initMetadataForObject($serializer_17, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(McpTool, 'McpTool', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_17});
initMetadataForCompanion(Companion_19);
protoOf($serializer_18).v25 = typeParametersSerializers;
initMetadataForObject($serializer_18, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ListToolsResult, 'ListToolsResult', ListToolsResult, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_18});
initMetadataForCompanion(Companion_20);
protoOf($serializer_19).v25 = typeParametersSerializers;
initMetadataForObject($serializer_19, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ToolResponse, 'ToolResponse', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_19});
initMetadataForCompanion(Companion_21);
protoOf($serializer_20).v25 = typeParametersSerializers;
initMetadataForObject($serializer_20, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(RpcEnvelope, 'RpcEnvelope', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_20});
initMetadataForCompanion(Companion_22, VOID, [SerializerFactory]);
initMetadataForClass($serializer_21, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(RpcResponse, 'RpcResponse', RpcResponse, VOID, VOID, VOID, VOID, {0: Companion_getInstance_28});
initMetadataForCompanion(Companion_23);
protoOf($serializer_22).v25 = typeParametersSerializers;
initMetadataForObject($serializer_22, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(RpcError, 'RpcError', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_21});
initMetadataForClass(TurnRetention, 'TurnRetention');
initMetadataForClass(ConversationTurn, 'ConversationTurn');
initMetadataForObject(Completed_1, 'Completed');
initMetadataForClass(Interrupted, 'Interrupted');
initMetadataForObject(Cancelled, 'Cancelled');
initMetadataForObject(Failed_2, 'Failed');
initMetadataForClass(Incomplete_1, 'Incomplete');
initMetadataForClass(Policy, 'Policy');
initMetadataForClass(PendingWork, 'PendingWork', PendingWork);
initMetadataForClass(ThreadId, 'ThreadId');
initMetadataForObject(NoMemoryProvider, 'NoMemoryProvider', VOID, VOID, VOID, [1]);
initMetadataForClass(FixedMemoryProvider, 'FixedMemoryProvider', VOID, VOID, VOID, [1]);
initMetadataForInterface(ThreadMemory, 'ThreadMemory', VOID, VOID, [AutoCloseable], [1]);
protoOf(NoMemory).s68 = get_retention;
protoOf(NoMemory).a6 = close;
initMetadataForObject(NoMemory, 'NoMemory', VOID, VOID, [ThreadMemory], [1]);
initMetadataForCompanion(Companion_24);
initMetadataForClass(MemoryView, 'MemoryView');
initMetadataForClass(WindowMemoryProvider, 'WindowMemoryProvider', VOID, VOID, VOID, [1]);
initMetadataForCompanion(Companion_25);
protoOf(WindowMemory).a6 = close;
initMetadataForClass(WindowMemory, 'WindowMemory', VOID, VOID, [ThreadMemory], [1]);
initMetadataForInterface(AgentListener, 'AgentListener');
initMetadataForInterface(Hook, 'Hook', VOID, VOID, VOID, [1, 2]);
initMetadataForClass(StepContext, 'StepContext');
initMetadataForClass(ToolContext, 'ToolContext');
initMetadataForClass(ModelCallPhase, 'ModelCallPhase');
initMetadataForObject(Proceed, 'Proceed');
initMetadataForClass(ProceedWith, 'ProceedWith');
initMetadataForClass(Deny, 'Deny');
initMetadataForInterface(AgentError, 'AgentError');
initMetadataForClass(ModelError, 'ModelError', VOID, VOID, [AgentError]);
initMetadataForClass(ToolError, 'ToolError', VOID, VOID, [AgentError]);
initMetadataForClass(ParseError, 'ParseError', VOID, VOID, [AgentError]);
initMetadataForClass(ToolNotFound, 'ToolNotFound', VOID, VOID, [AgentError]);
initMetadataForClass(SkillError, 'SkillError', VOID, VOID, [AgentError]);
initMetadataForClass(PreparationError, 'PreparationError', VOID, VOID, [AgentError]);
initMetadataForClass(Timeout, 'Timeout', VOID, VOID, [AgentError]);
initMetadataForClass(AgentFrameworkException, 'AgentFrameworkException');
initMetadataForClass(UrlCitation, 'UrlCitation');
initMetadataForClass(FileCitation, 'FileCitation');
initMetadataForClass(Generic, 'Generic');
initMetadataForCompanion(Companion_26);
initMetadataForClass(TranscriptBasis, 'TranscriptBasis');
initMetadataForClass(ProviderCheckpoint, 'ProviderCheckpoint');
initMetadataForClass(CheckpointScope, 'CheckpointScope');
initMetadataForCompanion(Companion_27);
protoOf($serializer_23).v25 = typeParametersSerializers;
initMetadataForObject($serializer_23, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_28);
protoOf($serializer_24).v25 = typeParametersSerializers;
initMetadataForObject($serializer_24, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_29);
protoOf($serializer_25).v25 = typeParametersSerializers;
initMetadataForObject($serializer_25, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(Text, 'Text', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_22});
initMetadataForClass(Image, 'Image', Image, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_23});
initMetadataForClass(Audio, 'Audio', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_24});
initMetadataForLambda(FallbackModel$stream$slambda$slambda, VOID, VOID, [1]);
initMetadataForObject(FallbackSignal, 'FallbackSignal');
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_1, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForLambda(FallbackModel$stream$slambda, VOID, VOID, [1]);
initMetadataForInterface(LanguageModel, 'LanguageModel', VOID, VOID, VOID, [1]);
initMetadataForClass(FallbackModel, 'FallbackModel', VOID, VOID, [LanguageModel], [1]);
initMetadataForCompanion(Companion_30);
initMetadataForClass(ItemRef, 'ItemRef');
initMetadataForCompanion(Companion_31);
protoOf($serializer_26).v25 = typeParametersSerializers;
initMetadataForObject($serializer_26, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ProviderId, 'ProviderId', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_25});
initMetadataForCompanion(Companion_32);
protoOf($serializer_27).v25 = typeParametersSerializers;
initMetadataForObject($serializer_27, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ProviderScopedId, 'ProviderScopedId', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_26});
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_2, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForLambda(generate$o$collect$slambda, VOID, VOID, [1]);
initMetadataForClass(generate$$inlined$filterIsInstance$1, VOID, VOID, VOID, [Flow], [1]);
initMetadataForCompanion(Companion_33);
initMetadataForClass(ModelCapabilities, 'ModelCapabilities', ModelCapabilities);
initMetadataForInterface(ModelEvent, 'ModelEvent');
initMetadataForClass(Started, 'Started', VOID, VOID, [ModelEvent]);
initMetadataForClass(CheckpointUpdated, 'CheckpointUpdated', VOID, VOID, [ModelEvent]);
initMetadataForClass(TextDelta_0, 'TextDelta', VOID, VOID, [ModelEvent]);
initMetadataForClass(ReasoningDelta_0, 'ReasoningDelta', VOID, VOID, [ModelEvent]);
initMetadataForClass(ItemAdded, 'ItemAdded', VOID, VOID, [ModelEvent]);
initMetadataForClass(ToolCallDelta, 'ToolCallDelta', VOID, VOID, [ModelEvent]);
initMetadataForClass(ToolCallCompleted, 'ToolCallCompleted', VOID, VOID, [ModelEvent]);
initMetadataForClass(ProviderEvent, 'ProviderEvent', VOID, VOID, [ModelEvent]);
initMetadataForClass(Finished, 'Finished', VOID, VOID, [ModelEvent]);
initMetadataForClass(Message, 'Message');
initMetadataForClass(ToolCall, 'ToolCall');
initMetadataForClass(ToolResult_0, 'ToolResult');
initMetadataForClass(ReasoningSummary, 'ReasoningSummary');
initMetadataForClass(ProviderItem, 'ProviderItem');
initMetadataForCompanion(Companion_34);
initMetadataForClass(ModelRequest, 'ModelRequest');
initMetadataForClass(Completed_2, 'Completed', Completed_2);
initMetadataForClass(Incomplete_2, 'Incomplete');
initMetadataForClass(Failed_3, 'Failed');
initMetadataForObject(MaxOutputTokens, 'MaxOutputTokens');
initMetadataForObject(ContentFilter, 'ContentFilter');
initMetadataForObject(Cancelled_0, 'Cancelled');
initMetadataForClass(Other, 'Other');
initMetadataForObject(Text_0, 'Text');
initMetadataForObject(JsonObject_0, 'JsonObject');
initMetadataForClass(JsonSchema, 'JsonSchema');
initMetadataForClass(ReplayPolicy, 'ReplayPolicy');
initMetadataForCompanion(Companion_35, VOID, [SerializerFactory]);
initMetadataForClass(Role, 'Role', VOID, VOID, VOID, VOID, VOID, {0: Companion_getInstance_41});
initMetadataForClass(Support, 'Support');
initMetadataForCompanion(Companion_36);
protoOf($serializer_28).v25 = typeParametersSerializers;
initMetadataForObject($serializer_28, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ToolCall_0, 'ToolCall', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_27});
initMetadataForClass(TypeAdapter, 'TypeAdapter');
initMetadataForCompanion(Companion_37);
protoOf($serializer_29).v25 = typeParametersSerializers;
initMetadataForObject($serializer_29, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(Usage, 'Usage', Usage, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_28});
initMetadataForClass(HttpClientConfig, 'HttpClientConfig');
initMetadataForClass(HttpClientException, 'HttpClientException');
initMetadataForClass(JsonParseException, 'JsonParseException');
initMetadataForClass(KtorHttpClient, 'KtorHttpClient', VOID, VOID, [AutoCloseable], [2, 1]);
initMetadataForInterface(SuspendErrorPolicy, 'SuspendErrorPolicy', VOID, VOID, VOID, [2]);
initMetadataForInterface(ErrorPolicy, 'ErrorPolicy');
initMetadataForClass(sam$org_koaks_framework_policy_ErrorPolicy$0, 'sam$org_koaks_framework_policy_ErrorPolicy$0', VOID, VOID, [ErrorPolicy, FunctionAdapter]);
initMetadataForClass(sam$org_koaks_framework_policy_ErrorPolicy$0_0, 'sam$org_koaks_framework_policy_ErrorPolicy$0', VOID, VOID, [ErrorPolicy, FunctionAdapter]);
initMetadataForClass(sam$org_koaks_framework_policy_ErrorPolicy$0_1, 'sam$org_koaks_framework_policy_ErrorPolicy$0', VOID, VOID, [ErrorPolicy, FunctionAdapter]);
initMetadataForCompanion(Companion_38);
initMetadataForObject(Propagate, 'Propagate');
initMetadataForClass(Retry, 'Retry');
initMetadataForClass(Substitute, 'Substitute');
initMetadataForCompanion(Companion_39);
initMetadataForClass(RunBudget, 'RunBudget', RunBudget);
initMetadataForInterface(TerminationPolicy, 'TerminationPolicy');
initMetadataForClass(sam$org_koaks_framework_policy_TerminationPolicy$0, 'sam$org_koaks_framework_policy_TerminationPolicy$0', VOID, VOID, [TerminationPolicy, FunctionAdapter]);
initMetadataForClass(sam$org_koaks_framework_policy_TerminationPolicy$0_0, 'sam$org_koaks_framework_policy_TerminationPolicy$0', VOID, VOID, [TerminationPolicy, FunctionAdapter]);
initMetadataForClass(sam$org_koaks_framework_policy_TerminationPolicy$0_1, 'sam$org_koaks_framework_policy_TerminationPolicy$0', VOID, VOID, [TerminationPolicy, FunctionAdapter]);
initMetadataForCompanion(Companion_40);
initMetadataForInterface(SuspendTerminationPolicy, 'SuspendTerminationPolicy', VOID, VOID, VOID, [1]);
initMetadataForObject(Continue, 'Continue');
initMetadataForClass(Stop, 'Stop');
initMetadataForClass(MaxSteps, 'MaxSteps');
initMetadataForClass(MaxTokens, 'MaxTokens');
initMetadataForClass(RunBudgetSteps, 'RunBudgetSteps');
initMetadataForClass(RunBudgetTokens, 'RunBudgetTokens');
initMetadataForClass(Custom, 'Custom');
initMetadataForObject(Bearer, 'Bearer');
initMetadataForClass(Header, 'Header');
initMetadataForLambda(ChatModel$stream$slambda$slambda, VOID, VOID, [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_3, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForLambda(ChatModel$stream$slambda, VOID, VOID, [1]);
protoOf(ChatModel).o6c = abandon;
initMetadataForClass(ChatModel, 'ChatModel', VOID, VOID, [LanguageModel], [1]);
initMetadataForClass(RetryBudget, 'RetryBudget', RetryBudget);
initMetadataForClass(ModelConfig, 'ModelConfig');
initMetadataForClass(MarkdownDirectorySkillLoader, 'MarkdownDirectorySkillLoader', VOID, VOID, VOID, [0, 1]);
initMetadataForClass(IndexedSkill, 'IndexedSkill');
initMetadataForClass(ParsedSkillDocument, 'ParsedSkillDocument');
initMetadataForClass(DirectorySkillResourceProvider, 'DirectorySkillResourceProvider', VOID, VOID, VOID, [1]);
initMetadataForClass(SkillDescriptor, 'SkillDescriptor');
initMetadataForClass(SkillDefinition, 'SkillDefinition');
initMetadataForClass(SkillId, 'SkillId');
initMetadataForClass(SkillResource, 'SkillResource');
initMetadataForClass(SkillResourceRequest, 'SkillResourceRequest');
initMetadataForClass(SkillResourceCursor, 'SkillResourceCursor');
initMetadataForClass(SkillStage, 'SkillStage');
initMetadataForClass(SkillException, 'SkillException');
initMetadataForClass(SkillFileMetadata, 'SkillFileMetadata');
initMetadataForClass(SkillsScope, 'SkillsScope', SkillsScope);
initMetadataForLambda(SkillPlan$prepare$slambda$slambda, VOID, VOID, [1]);
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForLambda(SkillPlan$prepare$slambda, VOID, VOID, [1]);
initMetadataForClass(SkillPlan, 'SkillPlan', VOID, VOID, VOID, [0, 2, 1]);
initMetadataForClass(PreparedSkills, 'PreparedSkills');
initMetadataForClass(LocatedSkill, 'LocatedSkill');
protoOf(SkillResourceTool).y61 = get_returnDirectly;
protoOf(SkillResourceTool).z61 = get_hasSideEffects;
protoOf(SkillResourceTool).u61 = get_parametersOverride;
protoOf(SkillResourceTool).t61 = get_acceptsRawJson;
initMetadataForClass(SkillResourceTool, 'SkillResourceTool', VOID, VOID, [Tool], [1]);
initMetadataForCompanion(Companion_41);
protoOf($serializer_30).v25 = typeParametersSerializers;
initMetadataForObject($serializer_30, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(SkillResourceInput, 'SkillResourceInput', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_29});
initMetadataForClass(ToolInvocationContext, 'ToolInvocationContext', VOID, VOID, VOID, [1]);
initMetadataForInterface(ToolProgress_0, 'ToolProgress');
initMetadataForClass(Output, 'Output', VOID, VOID, [ToolProgress_0]);
initMetadataForClass(Status, 'Status', VOID, VOID, [ToolProgress_0]);
initMetadataForClass(Custom_0, 'Custom', VOID, VOID, [ToolProgress_0]);
initMetadataForClass(ToolOutputStream, 'ToolOutputStream');
initMetadataForInterface(ContextualTool, 'ContextualTool', VOID, VOID, [Tool], [2, 1]);
initMetadataForClass(Success, 'Success');
initMetadataForClass(Failure, 'Failure');
initMetadataForClass(ToolRegistry, 'ToolRegistry', ToolRegistry, VOID, VOID, [1, 3, 4, 0]);
initMetadataForClass(ToolSchema, 'ToolSchema');
initMetadataForClass(Ctx, 'Ctx', Ctx);
initMetadataForObject(SerialDescriptorToJsonSchema, 'SerialDescriptorToJsonSchema');
initMetadataForLambda(KtorTransport$call$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(KtorTransport$call$slambda, VOID, VOID, [1]);
initMetadataForLambda(KtorTransport$execute$slambda, VOID, VOID, [1]);
initMetadataForClass(KtorTransport, 'KtorTransport', KtorTransport, VOID, [AutoCloseable], [1, 2]);
initMetadataForClass(TransportException, 'TransportException');
initMetadataForClass(StreamLine, 'StreamLine');
initMetadataForClass(StreamIdleTimeoutException, 'StreamIdleTimeoutException');
initMetadataForLambda(readStreamLine$slambda, VOID, VOID, [1]);
initMetadataForClass(RateLimiter, 'RateLimiter', VOID, VOID, VOID, [0]);
initMetadataForInterface(WireFrame, 'WireFrame');
initMetadataForClass(Sse, 'Sse', VOID, VOID, [WireFrame]);
initMetadataForClass(Body, 'Body', VOID, VOID, [WireFrame]);
initMetadataForClass(Ndjson, 'Ndjson', VOID, VOID, [WireFrame]);
initMetadataForClass(HttpError, 'HttpError', VOID, VOID, [WireFrame]);
initMetadataForClass(WireCall, 'WireCall');
initMetadataForClass(HttpMethod, 'HttpMethod');
initMetadataForClass(Framing, 'Framing');
initMetadataForClass(Timeouts, 'Timeouts', Timeouts);
initMetadataForObject(JsonUtil, 'JsonUtil');
initMetadataForLambda(AgentRuntime$stream$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$resume$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$spawnSupervised$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$submit$slambda$slambda, VOID, VOID, [1]);
initMetadataForCompanion(Companion_42);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_4, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_5, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForInterface(AgentSpawner, 'AgentSpawner');
initMetadataForClass(sam$org_koaks_runtime_resource_AgentSpawner$0, 'sam$org_koaks_runtime_resource_AgentSpawner$0', VOID, VOID, [AgentSpawner, FunctionAdapter]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_6, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForLambda(AgentRuntime$stream$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$resume$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$spawnInternal$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$runInstance$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$runInstance$slambda_0, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$runInstance$slambda_1, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$runInstance$slambda_2, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$runInstance$slambda_3, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$runInstance$slambda_4, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$runInstance$slambda_5, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$runInstance$slambda_6, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$runWithQuota$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$collectStream$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$spawnSupervised$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$submit$slambda, VOID, VOID, [1]);
initMetadataForLambda(AgentRuntime$cancelAndJoin$slambda, VOID, VOID, [1]);
initMetadataForClass(AgentRuntime, 'AgentRuntime', VOID, VOID, [AutoCloseable], [1, 7, 3, 8, 4, 6, 16, 10, 2]);
initMetadataForClass(AgentRuntimeConfig, 'AgentRuntimeConfig', AgentRuntimeConfig);
initMetadataForClass(AgentIdConflictException, 'AgentIdConflictException');
initMetadataForClass(AgentRegistration, 'AgentRegistration');
initMetadataForClass(ChildFailure, 'ChildFailure');
initMetadataForClass(QuotaSignal, 'QuotaSignal');
initMetadataForClass(AcbSnapshot, 'AcbSnapshot');
initMetadataForClass(Acb, 'Acb');
initMetadataForLambda(AgentHandle$awaitInternal$slambda, VOID, VOID, [0]);
initMetadataForLambda(AgentHandle$join$slambda, VOID, VOID, [0]);
initMetadataForClass(AgentHandle, 'AgentHandle', VOID, VOID, VOID, [0]);
initMetadataForClass(JournalEventSink, 'JournalEventSink', VOID, VOID, VOID, [1]);
initMetadataForLambda(InstanceControl$awaitResumed$slambda, VOID, VOID, [1]);
initMetadataForClass(InstanceControl, 'InstanceControl', InstanceControl, VOID, VOID, [0]);
initMetadataForClass(LifecycleState, 'LifecycleState');
initMetadataForClass(RunEventEnvelope, 'RunEventEnvelope');
initMetadataForClass(Agent_0, 'Agent');
initMetadataForClass(Lifecycle, 'Lifecycle');
initMetadataForClass(HistoryGap, 'HistoryGap');
initMetadataForLambda(RunEventJournal$events$slambda$slambda, VOID, VOID, [1]);
initMetadataForClass(State, 'State', State);
initMetadataForLambda(RunEventJournal$events$slambda, VOID, VOID, [1]);
initMetadataForClass(RunEventJournal, 'RunEventJournal');
initMetadataForClass(RunEventHistoryGapException, 'RunEventHistoryGapException');
initMetadataForClass(RunId, 'RunId');
initMetadataForClass(TurnId, 'TurnId');
initMetadataForClass(ContextRef, 'ContextRef');
initMetadataForClass(ContextScope, 'ContextScope');
initMetadataForClass(ContextStore, 'ContextStore', ContextStore);
initMetadataForClass(ContextAccessException, 'ContextAccessException');
initMetadataForClass(ContextBlock, 'ContextBlock');
initMetadataForClass(SupervisedHandle, 'SupervisedHandle', VOID, VOID, VOID, [0]);
initMetadataForClass(SupervisionPolicy, 'SupervisionPolicy', SupervisionPolicy);
initMetadataForClass(CircuitBreakerPolicy, 'CircuitBreakerPolicy', CircuitBreakerPolicy);
initMetadataForClass(Supervisor, 'Supervisor', Supervisor, VOID, VOID, [2, 3, 6]);
initMetadataForLambda(EventBus$subscribe$o$collect$slambda, VOID, VOID, [1]);
initMetadataForLambda(EventBus$subscribe$o$collect$slambda_0, VOID, VOID, [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_7, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForClass(EventBus$subscribe$$inlined$filter$1, VOID, VOID, VOID, [Flow], [1]);
initMetadataForClass(EventBus$subscribe$$inlined$map$1, VOID, VOID, VOID, [Flow], [1]);
initMetadataForClass(EventBus, 'EventBus', EventBus, VOID, VOID, [2]);
initMetadataForClass(IpcHub, 'IpcHub', VOID, VOID, VOID, [1, 3, 2]);
initMetadataForClass(Mailbox, 'Mailbox', VOID, VOID, VOID, [1, 0]);
initMetadataForClass(RuntimeMessage, 'RuntimeMessage');
initMetadataForClass(Spawned, 'Spawned');
initMetadataForClass(Running, 'Running');
initMetadataForClass(Waiting, 'Waiting');
initMetadataForClass(Suspended, 'Suspended');
initMetadataForClass(Resumed, 'Resumed');
initMetadataForClass(Finished_0, 'Finished');
initMetadataForClass(Incomplete_3, 'Incomplete');
initMetadataForClass(Terminated_1, 'Terminated');
initMetadataForClass(Failed_4, 'Failed');
initMetadataForClass(Cancelled_1, 'Cancelled');
initMetadataForClass(UnhandledChildFailure, 'UnhandledChildFailure');
initMetadataForClass(SideEffectRollback, 'SideEffectRollback');
initMetadataForClass(Retrying, 'Retrying');
initMetadataForClass(CircuitOpen, 'CircuitOpen');
initMetadataForClass(RuntimeMetrics, 'RuntimeMetrics');
initMetadataForObject(Inherit, 'Inherit');
initMetadataForObject(Ephemeral, 'Ephemeral');
initMetadataForClass(Thread, 'Thread');
initMetadataForClass(ChildFailurePolicy, 'ChildFailurePolicy');
initMetadataForLambda(InstanceActivityGate$Branch$run$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(InstanceActivityGate$Branch$run$slambda, VOID, VOID, [1]);
initMetadataForObject(Key_0, 'Key');
initMetadataForClass(BranchState, 'BranchState');
initMetadataForClass(BranchRecord, 'BranchRecord');
initMetadataForClass(Branch, 'Branch', VOID, VOID, VOID, [1]);
initMetadataForClass(BranchTag, 'BranchTag');
initMetadataForInterface(SlotLease, 'SlotLease', VOID, VOID, VOID, [0]);
initMetadataForObject(NoopLease, 'NoopLease', VOID, VOID, [SlotLease], [0]);
initMetadataForLambda(InstanceActivityGate$waiting$slambda, VOID, VOID, [1]);
initMetadataForClass(InstanceActivityGate, 'InstanceActivityGate', VOID, VOID, VOID, [1, 0]);
initMetadataForCompanion(Companion_43);
initMetadataForClass(Quota, 'Quota', Quota);
initMetadataForClass(AccessMode, 'AccessMode');
initMetadataForClass(ResourceRegistry, 'ResourceRegistry', ResourceRegistry, VOID, VOID, [1, 3]);
initMetadataForObject(Key_1, 'Key');
initMetadataForClass(RuntimeContext, 'RuntimeContext');
initMetadataForLambda(withRuntimeResource$slambda, VOID, VOID, [0]);
initMetadataForLambda(Scheduler$Lease$park$slambda, VOID, VOID, [1]);
initMetadataForLambda(Scheduler$Lease$close$slambda, VOID, VOID, [1]);
initMetadataForClass(Waiter, 'Waiter');
initMetadataForClass(LeaseState, 'LeaseState');
initMetadataForClass(Lease, 'Lease', VOID, VOID, [SlotLease], [0]);
initMetadataForClass(sam$kotlin_Comparator$0_0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForLambda(Scheduler$acquire$slambda, VOID, VOID, [1]);
initMetadataForClass(Scheduler, 'Scheduler', VOID, VOID, VOID, [2, 0]);
initMetadataForClass(TaskGraph, 'TaskGraph');
initMetadataForLambda(TaskGraphBuilder$task$slambda, VOID, VOID, [1]);
initMetadataForClass(TaskGraphBuilder, 'TaskGraphBuilder', TaskGraphBuilder);
initMetadataForClass(TaskNode, 'TaskNode');
initMetadataForClass(ThreadSnapshot, 'ThreadSnapshot');
initMetadataForClass(ThreadBinding, 'ThreadBinding', VOID, VOID, VOID, [0]);
initMetadataForClass(TurnReservation, 'TurnReservation', VOID, VOID, VOID, [0]);
initMetadataForClass(ThreadLease, 'ThreadLease', VOID, VOID, VOID, [0]);
initMetadataForClass(ThreadRegistry, 'ThreadRegistry');
initMetadataForClass(Waiter_0, 'Waiter');
initMetadataForClass(GateState, 'GateState', GateState);
initMetadataForClass(Reservation, 'Reservation', VOID, VOID, VOID, [0]);
initMetadataForClass(FifoTurnGate, 'FifoTurnGate', FifoTurnGate);
initMetadataForClass(ThreadMemoryPolicyConflictException, 'ThreadMemoryPolicyConflictException');
initMetadataForClass(TurnContext, 'TurnContext', VOID, VOID, VOID, [0]);
initMetadataForClass(Param, 'Param');
initMetadataForCompanion(Companion_44, VOID, VOID, [0]);
initMetadataForClass(NodeSkillFileSystem, 'NodeSkillFileSystem');
//endregion
//region block: init
Key_instance = new Key();
Pending_instance = new Pending();
Companion_instance_2 = new Companion_0();
Companion_instance_3 = new Companion_1();
Companion_instance_4 = new Companion_2();
Companion_instance_5 = new Companion_3();
Companion_instance_6 = new Companion_4();
Companion_instance_7 = new Companion_5();
Companion_instance_8 = new Companion_6();
Companion_instance_9 = new Companion_7();
Companion_instance_10 = new Companion_8();
Companion_instance_11 = new Companion_9();
Companion_instance_12 = new Companion_10();
Companion_instance_13 = new Companion_11();
Companion_instance_14 = new Companion_12();
Companion_instance_15 = new Companion_13();
Companion_instance_16 = new Companion_14();
Companion_instance_17 = new Companion_15();
Companion_instance_19 = new Companion_17();
Companion_instance_20 = new Companion_18();
Companion_instance_22 = new Companion_20();
Companion_instance_23 = new Companion_21();
Companion_instance_25 = new Companion_23();
Completed_instance = new Completed_1();
Cancelled_instance = new Cancelled();
Failed_instance = new Failed_2();
NoMemory_instance = new NoMemory();
Companion_instance_27 = new Companion_25();
Proceed_instance = new Proceed();
Companion_instance_28 = new Companion_26();
Companion_instance_29 = new Companion_27();
Companion_instance_30 = new Companion_28();
Companion_instance_31 = new Companion_29();
Companion_instance_32 = new Companion_30();
Companion_instance_34 = new Companion_32();
Companion_instance_36 = new Companion_34();
MaxOutputTokens_instance = new MaxOutputTokens();
ContentFilter_instance = new ContentFilter();
Cancelled_instance_0 = new Cancelled_0();
Text_instance = new Text_0();
JsonObject_instance = new JsonObject_0();
Companion_instance_38 = new Companion_36();
Propagate_instance = new Propagate();
Companion_instance_42 = new Companion_40();
Continue_instance = new Continue();
Bearer_instance = new Bearer();
Companion_instance_43 = new Companion_41();
SerialDescriptorToJsonSchema_instance = new SerialDescriptorToJsonSchema();
Companion_instance_44 = new Companion_42();
Inherit_instance = new Inherit();
Ephemeral_instance = new Ephemeral();
Key_instance_0 = new Key_0();
NoopLease_instance = new NoopLease();
Key_instance_1 = new Key_1();
Companion_instance_46 = new Companion_44();
//endregion
//region block: exports
export {
  TurnRetention_CompletedOnly_getInstance as TurnRetention_CompletedOnly_getInstance3gs3fb1a6idq7,
  TurnRetention_InterruptedIfSideEffects_getInstance as TurnRetention_InterruptedIfSideEffects_getInstance1zzkb2uwwx4m9,
  TurnRetention_Interrupted_getInstance as TurnRetention_Interrupted_getInstance1clj3n1yfuiga,
  ModelCallPhase_Normal_getInstance as ModelCallPhase_Normal_getInstance1007ql54uck2h,
  CheckpointScope_CrossTurn_getInstance as CheckpointScope_CrossTurn_getInstance3flwfeb5t4aet,
  CheckpointScope_InRun_getInstance as CheckpointScope_InRun_getInstancehlz4h897r3cf,
  ReplayPolicy_Preferred_getInstance as ReplayPolicy_Preferred_getInstance2bbct696f4twy,
  ReplayPolicy_Required_getInstance as ReplayPolicy_Required_getInstance1o7kby0tmyj43,
  Role_ASSISTANT_getInstance as Role_ASSISTANT_getInstance3m8z8upy020dy,
  Role_SYSTEM_getInstance as Role_SYSTEM_getInstance3m9lasmspf7k5,
  Role_USER_getInstance as Role_USER_getInstance1gsro7tt6a7i2,
  Support_Supported_getInstance as Support_Supported_getInstance2iy50h3ebt6qe,
  Support_Unknown_getInstance as Support_Unknown_getInstance3blv79i14mlk4,
  Support_Unsupported_getInstance as Support_Unsupported_getInstance2l560r5zg87nd,
  ToolOutputStream_Stderr_getInstance as ToolOutputStream_Stderr_getInstance3dchan4ksqfap,
  ToolOutputStream_Stdout_getInstance as ToolOutputStream_Stdout_getInstance3kl2teq0u5jv9,
  Framing_Json_getInstance as Framing_Json_getInstance1qaq7vxhw69ba,
  Framing_Ndjson_getInstance as Framing_Ndjson_getInstance2grbeiiobprd,
  Framing_Sse_getInstance as Framing_Sse_getInstance1id84wnv2jikt,
  HttpMethod_GET_getInstance as HttpMethod_GET_getInstancemtw2do2vtbsa,
  HttpMethod_POST_getInstance as HttpMethod_POST_getInstance2vunzl2e30rwd,
  ContextScope_GLOBAL_getInstance as ContextScope_GLOBAL_getInstance282km2iut510a,
  ContextScope_PRIVATE_getInstance as ContextScope_PRIVATE_getInstancevzkuuvh6xefg,
  ContextScope_TASK_getInstance as ContextScope_TASK_getInstance3v34m6yykq14s,
  AccessMode_READ_getInstance as AccessMode_READ_getInstance1ntzu2czr0xsh,
  AccessMode_WRITE_getInstance as AccessMode_WRITE_getInstance2kgbqe100xyz0,
  ChildFailurePolicy_CAPTURE_getInstance as ChildFailurePolicy_CAPTURE_getInstancexk3kgeds970j,
  ChildFailurePolicy_PROPAGATE_getInstance as ChildFailurePolicy_PROPAGATE_getInstance2j6u9t2rbs646,
  generate as generate290swdgdwvcq1,
  withRuntimeResource as withRuntimeResource367q7asqscsa1,
  _AgentId___init__impl__m6udbt as _AgentId___init__impl__m6udbt1v24axsjntasa,
  _AgentId___get_value__impl__1mym7n as _AgentId___get_value__impl__1mym7n37pn4brtfygwu,
  _MemoryProviderId___init__impl__vkxuto as _MemoryProviderId___init__impl__vkxutoeycvcgh355zg,
  _MemoryProviderId___get_value__impl__90yl20 as _MemoryProviderId___get_value__impl__90yl2011zkzf5x46sgz,
  _ThreadId___init__impl__wwh4n0 as _ThreadId___init__impl__wwh4n0awn1y460sfsm,
  ThreadId__hashCode_impl_80c5yl as ThreadId__hashCode_impl_80c5yl3g51hyor3y6mh,
  ThreadId__toString_impl_tri2rg as ThreadId__toString_impl_tri2rgo3ztqbcb7oi1,
  _ThreadId___get_value__impl__tytyxc as _ThreadId___get_value__impl__tytyxcp6hybs6mx9vr,
  _ItemRef___init__impl__ipmeex as _ItemRef___init__impl__ipmeexzal33vlj7m90,
  _ItemRef___get_value__impl__fpjuyb as _ItemRef___get_value__impl__fpjuyb3vqbahagzpip9,
  _ProviderId___init__impl__nor0vf as _ProviderId___init__impl__nor0vf25jyftll92y3b,
  _ProviderId___get_value__impl__xo1tux as _ProviderId___get_value__impl__xo1tux1l8qcslmantkx,
  _SkillId___init__impl__ou80gj as _SkillId___init__impl__ou80gj2bgk3xbf1xti2,
  _SkillId___get_value__impl__n6yl35 as _SkillId___get_value__impl__n6yl352zpgzt8cenesl,
  _RunId___init__impl__jfg80d as _RunId___init__impl__jfg80d39gh05ipyy9q9,
  RunId__hashCode_impl_4harkc as RunId__hashCode_impl_4harkc3izogbyeztm7f,
  _RunId___get_value__impl__30zeiv as _RunId___get_value__impl__30zeivp33yqnh572zv,
  _TurnId___get_value__impl__w6r3h9 as _TurnId___get_value__impl__w6r3h917udioonb9tb4,
  _ContextRef___init__impl__laq00z as _ContextRef___init__impl__laq00z36p4flhrwnis6,
  _ContextRef___get_id__impl__uspq4f as _ContextRef___get_id__impl__uspq4f1d5eefgn28dbn,
  Key_instance as Key_instance284ivmzop7sd9,
  Cancelled_instance as Cancelled_instance1xvdu9qggy3e5,
  Failed_instance as Failed_instance170krqyyzqjb6,
  NoMemoryProvider_getInstance as NoMemoryProvider_getInstance3r3q0ztr99x5e,
  Completed_instance as Completed_instancex7pny2bbjcdr,
  Proceed_instance as Proceed_instance2giofcc080wt1,
  Cancelled_instance_0 as Cancelled_instance1itykyif0mdkk,
  ContentFilter_instance as ContentFilter_instance10ein6t2i9053,
  MaxOutputTokens_instance as MaxOutputTokens_instance2tn5unomigxz7,
  Companion_instance_32 as Companion_instance13097inxmcdi,
  Companion_instance_36 as Companion_instancelgypg95btxw8,
  JsonObject_instance as JsonObject_instance30hvkp8z8mfx9,
  Text_instance as Text_instance936fuxqirkv3,
  Companion_getInstance_37 as Companion_getInstance3ot1bqjky10hu,
  Companion_instance_28 as Companion_instance3119tbznr6ao7,
  Companion_getInstance_43 as Companion_getInstance2m4xts4fuklfa,
  Companion_getInstance_44 as Companion_getInstancextwtaoaved2h,
  Propagate_instance as Propagate_instance296jix3pc87l6,
  Continue_instance as Continue_instance2wm3hyifqn3li,
  Companion_instance_42 as Companion_instance2khz9mlqwxdw1,
  JsonUtil_getInstance as JsonUtil_getInstance3itlrleq4m1cs,
  Ephemeral_instance as Ephemeral_instanceg3x5ygrswisy,
  Inherit_instance as Inherit_instance3eojkg6b8g884,
  Companion_getInstance_49 as Companion_getInstance176qkrnolkas,
  Key_instance_1 as Key_instance3rikaljb0525l,
  Completed as Completed39qr5embh95o2,
  Failed as Failed19uwo7uuwioir,
  Incomplete as Incomplete22h0otjfc9qo,
  ReasoningDelta as ReasoningDelta2dbne4w7qnc6h,
  StepCompleted as StepCompleted1ne9eg3zpjqsd,
  Terminated as Terminated1yey6zz984p1a,
  TextDelta as TextDeltaykhe546olrru,
  ToolCallRequested as ToolCallRequested3isqene1jrpyi,
  ToolProgress as ToolProgressi5m8ak0r1j7m,
  ToolResult as ToolResult2ovl89m0pb3ia,
  AgentId as AgentId36zdhs0111bpe,
  Completed_0 as Completed3p9issjhh04x2,
  Failed_1 as Failed3jeye2l9srbvp,
  Incomplete_0 as Incomplete3m6d5sq06dgkj,
  Terminated_0 as Terminatedk6xeqdaa3bel,
  AgentResult as AgentResultnrtvmxr4wdzg,
  AgentState as AgentStateq0h4yihlrppz,
  ModelScope as ModelScopeydnzgbv5k1rk,
  OutputSpec as OutputSpecdv8gu1h59g62,
  agent as agent3roqjtkgj4v5n,
  toLanguageModel as toLanguageModel1yppatg5qyvic,
  DefaultMcpClient as DefaultMcpClient2ix95c54p0pzm,
  McpClientConfig as McpClientConfig1y0d1kdip2fi2,
  McpTool as McpTooltkaeo5pntkj4,
  FixedMemoryProvider as FixedMemoryProvider3niknr1e3f1m2,
  Incomplete_1 as Incomplete2f3jgrqbbwtg7,
  Policy as Policy1tfroprjy15wd,
  MemoryView as MemoryView36zuxzo826bia,
  ThreadId as ThreadId21scpc0nj57qc,
  close as closeca18uc43m2gy,
  ThreadMemory as ThreadMemory1dswgl9efn3yf,
  Interrupted as Interrupted28j48dsr3pw62,
  WindowMemoryProvider as WindowMemoryProviderzvoz1awvz4m1,
  shouldRetain as shouldRetain150nlxe0gzy8j,
  turnHasSideEffects as turnHasSideEffects1mpwjsroa3ywe,
  AgentListener as AgentListener30c3usj4bnd9e,
  Hook as Hook1u2wzh55ycpu8,
  Deny as Deny3597ostucic39,
  ProceedWith as ProceedWith2cht2h4fqey0y,
  ModelError as ModelErrori9ofbqyilwwf,
  ParseError as ParseError1n78h8ml9fvik,
  PreparationError as PreparationError1mrn3vyzs5xe4,
  SkillError as SkillError383wa1og498ng,
  Timeout as Timeoutz57w70r5trqc,
  ToolError as ToolError3d4h05fyqa7n2,
  ToolNotFound as ToolNotFound1yo0rzmynl0ge,
  AgentError as AgentErrorv0js0hohaolw,
  AgentFrameworkException as AgentFrameworkException23juzeg1t595u,
  FileCitation as FileCitationygaccnkkyy7b,
  Generic as Genericlzofu41340v,
  UrlCitation as UrlCitation1viudi8jaexgt,
  Audio as Audio23kgaookuy0z2,
  Image as Image2x6strlw6vlny,
  Text as Texttoggh19xftus,
  Other as Other3cy8r7ld3h1ux,
  ItemRef as ItemRef3v4f9mi7oyrky,
  ModelCapabilities as ModelCapabilities1z2n3zkdibnvb,
  CheckpointUpdated as CheckpointUpdated1ph6xqbn4fzwh,
  Finished as Finished4z9e5g7v1wyk,
  ItemAdded as ItemAddede8lfykdsw28t,
  ProviderEvent as ProviderEvent1t0ljokdqil6g,
  ReasoningDelta_0 as ReasoningDeltaytmmln995w27,
  Started as Started1sf5a44qjgp0u,
  TextDelta_0 as TextDeltaq9h7728thclc,
  ToolCallCompleted as ToolCallCompleted225u0jsfjmco7,
  ToolCallDelta as ToolCallDelta1owom9vbem28s,
  Message as Message1x6kaj8ypdoee,
  ProviderItem as ProviderItem17hp0vuxmlwze,
  ReasoningSummary as ReasoningSummary2dl0lxzty5z0,
  ToolCall as ToolCall27jatgdodcelb,
  ToolResult_0 as ToolResult2fndzcq38kgpy,
  ModelRequest as ModelRequest2fvlnwc92shgb,
  Completed_2 as Completedf7bahq5rqxjz,
  Failed_3 as Failed2mkg32d93x5tt,
  Incomplete_2 as Incompletel3n48a644js,
  JsonSchema as JsonSchema1bzd59uqo2uv,
  ProviderCheckpoint as ProviderCheckpoint1ql47nh16mrq3,
  ProviderScopedId as ProviderScopedId2kn7so5x8kdlf,
  valueOf as valueOf311z7t4cy802c,
  valueOf_0 as valueOf27dlu7ag21wc7,
  ToolCall_0 as ToolCallsfyoaxshhyk,
  TranscriptBasis as TranscriptBasisi4fgd064euay,
  Usage as Usage3sdv1daz6y20z,
  displayText as displayText2pp0s33rxlm2,
  ensureDroppable as ensureDroppable3mu5lhcnsp146,
  isSystem as isSystem5q4g7p85h8y2,
  isUserTurnBoundary as isUserTurnBoundary3tbzs28fwfq04,
  newIdempotencyKey as newIdempotencyKey3adur2bjpedyg,
  rawFor as rawFor3526oyw9fazp7,
  toDispatchCall as toDispatchCall2p600t0sjcswe,
  Retry as Retry178h6bplcsekg,
  Substitute as Substitute2awks4hhz3ray,
  SuspendErrorPolicy as SuspendErrorPolicy11qpiip1gm60s,
  SuspendTerminationPolicy as SuspendTerminationPolicy2ikqiyuycj12h,
  Stop as Stop1npjwdgx12etk,
  Custom as Custom12bedglhf154j,
  MaxSteps as MaxSteps2zextkr4xhmlx,
  MaxTokens as MaxTokenss3xql3j4ut43,
  RunBudgetSteps as RunBudgetSteps280y2j9i34mbs,
  RunBudgetTokens as RunBudgetTokens2ht23ihfgefv0,
  Header as Header291p2k6if4y3m,
  ChatModel as ChatModel1ekuxcd3gk3yy,
  ModelConfig as ModelConfig4o28u6uqe7xk,
  RetryBudget as RetryBudget5rxtg4kf2dwq,
  authHeaders as authHeaders3pbiyo76b6dd9,
  timeouts as timeoutsvuf8aepeqg28,
  SkillDefinition as SkillDefinition2wt50z036xune,
  SkillDescriptor as SkillDescriptor3nmkeg8c0c71s,
  SkillId as SkillId2fmfj122nhxl,
  SkillResourceCursor as SkillResourceCursor23b789okxwrx4,
  SkillResource as SkillResourceuo2pwlwaztap,
  ContextualTool as ContextualTool2pa89d93ed3rs,
  Failure as Failurekyf28q0z9hiq,
  Success as Success3mq33eta8bi8i,
  Custom_0 as Custom2x7k1rxqer1y1,
  Output as Output3d618xddl0jua,
  Status as Status1jc5xgqdyrntu,
  ToolSchema as ToolSchema2ufbizf6sucuk,
  KtorTransport as KtorTransport1p3ssurzs5o3g,
  TransportException as TransportException31a3s676rkip3,
  WireCall as WireCall3namx761k5vmg,
  Body as Body2ccosqk3y8ycb,
  HttpError as HttpError1wj82nej166el,
  Ndjson as Ndjson1kkk3x9modr28,
  Sse as Sset7uvtqde4kyu,
  Agent_0 as Agent1la3ofrca8ngj,
  HistoryGap as HistoryGap1nlmsgc807ffz,
  Lifecycle as Lifecycle3kshxq8hzkipw,
  RunId as RunId2h3r3ph0106mg,
  TurnId as TurnIdo7of7ptpmk5l,
  ContextAccessException as ContextAccessExceptionzmtupk6xwihp,
  ContextRef as ContextRef1cmaoz2m0ivax,
  CircuitBreakerPolicy as CircuitBreakerPolicy29egv8iqr7wfb,
  SupervisionPolicy as SupervisionPolicyzw6zkdv2xerw,
  RuntimeMessage as RuntimeMessage1673boi5j0x1r,
  Cancelled_1 as Cancelled26l1r8k2esjma,
  CircuitOpen as CircuitOpenjbljw57iigzs,
  Failed_4 as Failed3jso9l848cuqa,
  Finished_0 as Finished2tky25kkkpuz9,
  Incomplete_3 as Incomplete1pu1upcmhhf6b,
  Resumed as Resumed2u5yxlh7njkw8,
  Retrying as Retrying24x66k5422sl1,
  Running as Running3t0jfgt4diep8,
  SideEffectRollback as SideEffectRollback14xwdx2gvwcoa,
  Spawned as Spawned3htspwmgjbg6d,
  Suspended as Suspended1nd4z7dmshla8,
  Terminated_1 as Terminated1k84iml5dt6u5,
  UnhandledChildFailure as UnhandledChildFailure3ktvfarkcohqb,
  Waiting as Waiting10r2pml3uv9hn,
  Thread as Threadwi21kgd5izpm,
  Quota as Quota3940mann21mmz,
  taskGraph as taskGrapht7fjnnbp3lyv,
  AgentIdConflictException as AgentIdConflictException3kleahgvhdh5k,
  AgentRuntime_0 as AgentRuntime22n2er2c2jtiy,
};
//endregion

//# sourceMappingURL=koaks-core.mjs.map
