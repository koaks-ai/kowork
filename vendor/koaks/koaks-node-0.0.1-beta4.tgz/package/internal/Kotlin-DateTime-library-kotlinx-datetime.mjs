import {
  Instant as Instant,
  Clock as Clock,
  LocalDate as LocalDate,
  LocalTime as LocalTime,
  ZoneOffset as ZoneOffset,
  ChronoField as ChronoField,
  DateTimeFormatterBuilder as DateTimeFormatterBuilder,
  ResolverStyle as ResolverStyle,
} from '@js-joda/core';
import {
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  Long2qws0ah9gnpki as Long,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString,
  Unit_instance104q5opgivhr8 as Unit_instance,
  toLongw1zpgk99d84b as toLong,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  VOID7hggqo3abtya as VOID,
  captureStack1fzi4aczwc4hg as captureStack,
  RuntimeException1r3t0zl97011n as RuntimeException,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  ArithmeticException18dajwq7kbp38 as ArithmeticException,
  protoOf180f3jzyo7rfj as protoOf,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  KMutableProperty11e8g1gb0ecb9j as KMutableProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  KMutableProperty025txtn5b59pq1 as KMutableProperty0,
  Enum3alwj03lh1n41 as Enum,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  toString35i91qxh73cps as toString_0,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  isInterface3d6p8outrmvmk as isInterface,
  isArray1hxjqtqy632bc as isArray,
  ArrayList3it5z8td81qkl as ArrayList,
  hashCodeq5arwsb9dgti as hashCode,
  listOf1jh22dvmctj1r as listOf,
  get_indices3txodfl5wuu5j as get_indices,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  joinToString1cxrrlmo0chqs as joinToString,
  equals2au1ep9vhcato as equals,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  KProperty02ce7r476m8633 as KProperty0,
  lazy2hsh8ze7j6ikd as lazy,
  padStart36w1507hs626a as padStart,
  getOrNull1go7ef9ldk0df as getOrNull,
  listOfvhqybd2zx248 as listOf_0,
  emptyList1g2z5xcrvp2zy as emptyList,
  toString30pk9tzaqopn as toString_1,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  get_lastIndexld83bqhfgcdd as get_lastIndex,
  toSet2orjxp16sotqu as toSet,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  distinct10qe1scfdvu5k as distinct,
  to2cs3ny02qtbcb as to,
  singleo93pzdgfc557 as single,
  Collection1k04j3hzsbod0 as Collection,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  numberRangeToNumber25vse2rgp6rs8 as numberRangeToNumber,
  mutableListOf6oorvk2mtdmp as mutableListOf,
  removeLastOrNull3odnlbetbttd4 as removeLastOrNull,
  sortWith4fnm6b3vw03s as sortWith,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  Comparator2b3maoeh98xtg as Comparator,
  compareValues1n2ayl87ihzfk as compareValues,
  Exceptiondt2hlxn7j7vw as Exception,
  StringBuildermazzzhj6kkai as StringBuilder,
  joinTo3lkanfaxbzac2 as joinTo,
  plus310ted5e4i90h as plus,
  toMutableList20rdgwi7d3cwi as toMutableList,
  addAll1k27qatfgp3k5 as addAll,
  firstOrNull1982767dljvdy as firstOrNull,
  drop3na99dw9feawf as drop,
  repeat2w4c6j8zoq09o as repeat,
  sortedWith2csnbbb21k0lg as sortedWith,
  binarySearchyyczvdessj07 as binarySearch,
  startsWith641pyr7vf687 as startsWith,
  checkCountOverflow1ro2fe1r4xvgf as checkCountOverflow,
  compareTo3ankvs086tmwq as compareTo,
  removePrefix279df90bhrqqg as removePrefix,
  UnsupportedOperationException2tkumpmhredt3 as UnsupportedOperationException,
  Comparable198qfk8pnblz0 as Comparable,
  Char__minus_impl_a2frrhem8aw2sny2of as Char__minus_impl_a2frrh,
  contains2el4s70rdq4ld as contains,
  indexOf1xbs558u7wr52 as indexOf,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  removeRange2614yh20qvds6 as removeRange,
  getKClass1s3j9wy1cofik as getKClass,
  arrayOf1akklvh2at202 as arrayOf,
  createKType1lgox3mzhchp5 as createKType,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy_0,
  PrimitiveClasses_getInstance28ukyr6i8fs0q as PrimitiveClasses_getInstance,
  KProperty1ca4yb4wlo496 as KProperty1,
  enumEntries20mr21zbe3az4 as enumEntries,
  numberToLong1a4cndvg6c52s as numberToLong,
  numberToInt1ygmcfwhs2fkq as numberToInt,
  createThis2j2avj17cvnv2 as createThis,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  numberToDouble210hrknaofnhf as numberToDouble,
} from './kotlin-kotlin-stdlib.mjs';
import {
  buildClassSerialDescriptors2a6xdp6mrtw as buildClassSerialDescriptor,
  serializer1hwzc6m64v1op as serializer,
  KSerializerzf77vz1967fq as KSerializer,
  MissingFieldException24tqif29emcmi as MissingFieldException,
  SealedClassSerializeriwipiibk55zc as SealedClassSerializer,
  AbstractPolymorphicSerializer1ccxwp48nfy58 as AbstractPolymorphicSerializer,
  SerializationExceptioneqrdve3ts2n9 as SerializationException,
  STRING_getInstance2gbamclnmtzqa as STRING_getInstance,
  PrimitiveSerialDescriptor3egfp53lutxj2 as PrimitiveSerialDescriptor,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class System {
  p53() {
    return Companion_getInstance_13().p53();
  }
}
class Companion {}
class Companion_0 {}
class Companion_1 {}
class Companion_2 {}
class DateTimeUnit {
  constructor() {
    Companion_getInstance_3();
  }
  z53(value, unit) {
    return value === 1 ? unit : '' + value + '-' + unit;
  }
  y53(value, unit) {
    return value.equals(new Long(1, 0)) ? unit : value.toString() + '-' + unit;
  }
}
class TimeBased extends DateTimeUnit {
  constructor(nanoseconds) {
    super();
    this.u53_1 = nanoseconds;
    // Inline function 'kotlin.require' call
    if (!(this.u53_1.s1(new Long(0, 0)) > 0)) {
      var message = 'Unit duration must be positive, but was ' + this.u53_1.toString() + ' ns.';
      throw IllegalArgumentException.t(toString(message));
    }
    if (this.u53_1.y3(new Long(817405952, 838)).equals(new Long(0, 0))) {
      this.v53_1 = 'HOUR';
      this.w53_1 = this.u53_1.x3(new Long(817405952, 838));
    } else {
      if (this.u53_1.y3(new Long(-129542144, 13)).equals(new Long(0, 0))) {
        this.v53_1 = 'MINUTE';
        this.w53_1 = this.u53_1.x3(new Long(-129542144, 13));
      } else {
        var tmp1 = this.u53_1;
        // Inline function 'kotlin.Long.rem' call
        var other = 1000000000;
        if (tmp1.y3(toLong(other)).equals(new Long(0, 0))) {
          this.v53_1 = 'SECOND';
          var tmp = this;
          var tmp3 = this.u53_1;
          // Inline function 'kotlin.Long.div' call
          var other_0 = 1000000000;
          tmp.w53_1 = tmp3.x3(toLong(other_0));
        } else {
          // Inline function 'kotlin.Long.rem' call
          if (this.u53_1.y3(toLong(1000000)).equals(new Long(0, 0))) {
            this.v53_1 = 'MILLISECOND';
            var tmp_0 = this;
            // Inline function 'kotlin.Long.div' call
            tmp_0.w53_1 = this.u53_1.x3(toLong(1000000));
          } else {
            // Inline function 'kotlin.Long.rem' call
            if (this.u53_1.y3(toLong(1000)).equals(new Long(0, 0))) {
              this.v53_1 = 'MICROSECOND';
              var tmp_1 = this;
              // Inline function 'kotlin.Long.div' call
              tmp_1.w53_1 = this.u53_1.x3(toLong(1000));
            } else {
              this.v53_1 = 'NANOSECOND';
              this.w53_1 = this.u53_1;
            }
          }
        }
      }
    }
  }
  x53(scalar) {
    return new TimeBased(safeMultiply(this.u53_1, toLong(scalar)));
  }
  equals(other) {
    var tmp;
    if (this === other) {
      tmp = true;
    } else {
      var tmp_0;
      if (other instanceof TimeBased) {
        tmp_0 = this.u53_1.equals(other.u53_1);
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  hashCode() {
    return this.u53_1.x1() ^ this.u53_1.f4(32).x1();
  }
  toString() {
    return this.y53(this.w53_1, this.v53_1);
  }
}
class DateBased extends DateTimeUnit {}
class DayBased extends DateBased {
  constructor(days) {
    super();
    this.a54_1 = days;
    // Inline function 'kotlin.require' call
    if (!(this.a54_1 > 0)) {
      var message = 'Unit duration must be positive, but was ' + this.a54_1 + ' days.';
      throw IllegalArgumentException.t(toString(message));
    }
  }
  x53(scalar) {
    return new DayBased(safeMultiply_0(this.a54_1, scalar));
  }
  equals(other) {
    var tmp;
    if (this === other) {
      tmp = true;
    } else {
      var tmp_0;
      if (other instanceof DayBased) {
        tmp_0 = this.a54_1 === other.a54_1;
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  hashCode() {
    return this.a54_1 ^ 65536;
  }
  toString() {
    return (this.a54_1 % 7 | 0) === 0 ? this.z53(this.a54_1 / 7 | 0, 'WEEK') : this.z53(this.a54_1, 'DAY');
  }
}
class MonthBased extends DateBased {
  constructor(months) {
    super();
    this.b54_1 = months;
    // Inline function 'kotlin.require' call
    if (!(this.b54_1 > 0)) {
      var message = 'Unit duration must be positive, but was ' + this.b54_1 + ' months.';
      throw IllegalArgumentException.t(toString(message));
    }
  }
  x53(scalar) {
    return new MonthBased(safeMultiply_0(this.b54_1, scalar));
  }
  equals(other) {
    var tmp;
    if (this === other) {
      tmp = true;
    } else {
      var tmp_0;
      if (other instanceof MonthBased) {
        tmp_0 = this.b54_1 === other.b54_1;
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  hashCode() {
    return this.b54_1 ^ 131072;
  }
  toString() {
    return (this.b54_1 % 1200 | 0) === 0 ? this.z53(this.b54_1 / 1200 | 0, 'CENTURY') : (this.b54_1 % 12 | 0) === 0 ? this.z53(this.b54_1 / 12 | 0, 'YEAR') : (this.b54_1 % 3 | 0) === 0 ? this.z53(this.b54_1 / 3 | 0, 'QUARTER') : this.z53(this.b54_1, 'MONTH');
  }
}
class Companion_3 {
  constructor() {
    Companion_instance_3 = this;
    this.c54_1 = new TimeBased(new Long(1, 0));
    this.d54_1 = this.c54_1.x53(1000);
    this.e54_1 = this.d54_1.x53(1000);
    this.f54_1 = this.e54_1.x53(1000);
    this.g54_1 = this.f54_1.x53(60);
    this.h54_1 = this.g54_1.x53(60);
    this.i54_1 = new DayBased(1);
    this.j54_1 = this.i54_1.x53(7);
    this.k54_1 = new MonthBased(1);
    this.l54_1 = this.k54_1.x53(3);
    this.m54_1 = this.k54_1.x53(12);
    this.n54_1 = this.m54_1.x53(100);
  }
}
class DateTimeFormatException extends IllegalArgumentException {
  static s54() {
    var $this = this.zd();
    init_kotlinx_datetime_DateTimeFormatException($this);
    return $this;
  }
  static t54(message) {
    var $this = this.t(message);
    init_kotlinx_datetime_DateTimeFormatException($this);
    return $this;
  }
  static u54(cause) {
    var $this = this.ce(cause);
    init_kotlinx_datetime_DateTimeFormatException($this);
    return $this;
  }
  static v54(message, cause) {
    var $this = this.ae(message, cause);
    init_kotlinx_datetime_DateTimeFormatException($this);
    return $this;
  }
}
class DateTimeArithmeticException extends RuntimeException {
  static z54() {
    var $this = this.g2();
    init_kotlinx_datetime_DateTimeArithmeticException($this);
    return $this;
  }
  static a55(message, cause) {
    var $this = this.be(message, cause);
    init_kotlinx_datetime_DateTimeArithmeticException($this);
    return $this;
  }
}
class TimeFieldContainer {}
function set_fractionOfSecond(value) {
  this.m56(value == null ? null : value.m5c(9));
}
function get_fractionOfSecond() {
  var tmp0_safe_receiver = this.n56();
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = new DecimalFraction(tmp0_safe_receiver, 9);
  }
  return tmp;
}
class UtcOffsetFieldContainer {}
class DateTimeComponentsContents {
  constructor(date, time, offset, timeZoneId) {
    date = date === VOID ? new IncompleteLocalDate() : date;
    time = time === VOID ? new IncompleteLocalTime() : time;
    offset = offset === VOID ? new IncompleteUtcOffset() : offset;
    timeZoneId = timeZoneId === VOID ? null : timeZoneId;
    this.d55_1 = date;
    this.e55_1 = time;
    this.f55_1 = offset;
    this.g55_1 = timeZoneId;
  }
  h55(_set____db54di) {
    this.d55_1.k55_1 = _set____db54di;
  }
  n55() {
    return this.d55_1.k55_1;
  }
  o55(_set____db54di) {
    this.d55_1.m55_1 = _set____db54di;
  }
  p55() {
    return this.d55_1.m55_1;
  }
  q55(_set____db54di) {
    this.d55_1.l55_1 = _set____db54di;
  }
  r55() {
    return this.d55_1.l55_1;
  }
  s55(_set____db54di) {
    this.d55_1.j55_1 = _set____db54di;
  }
  t55() {
    return this.d55_1.j55_1;
  }
  u55(_set____db54di) {
    this.d55_1.i55_1 = _set____db54di;
  }
  v55() {
    return this.d55_1.i55_1;
  }
  w55(_set____db54di) {
    this.e55_1.z55_1 = _set____db54di;
  }
  d56() {
    return this.e55_1.z55_1;
  }
  e56(value) {
    this.e55_1.e56(value);
  }
  f56() {
    return this.e55_1.f56();
  }
  g56(_set____db54di) {
    this.e55_1.x55_1 = _set____db54di;
  }
  h56() {
    return this.e55_1.x55_1;
  }
  i56(_set____db54di) {
    this.e55_1.y55_1 = _set____db54di;
  }
  j56() {
    return this.e55_1.y55_1;
  }
  k56(_set____db54di) {
    this.e55_1.a56_1 = _set____db54di;
  }
  l56() {
    return this.e55_1.a56_1;
  }
  m56(_set____db54di) {
    this.e55_1.c56_1 = _set____db54di;
  }
  n56() {
    return this.e55_1.c56_1;
  }
  o56(_set____db54di) {
    this.e55_1.b56_1 = _set____db54di;
  }
  p56() {
    return this.e55_1.b56_1;
  }
  q56(_set____db54di) {
    this.f55_1.r56_1 = _set____db54di;
  }
  v56() {
    return this.f55_1.r56_1;
  }
  w56(_set____db54di) {
    this.f55_1.t56_1 = _set____db54di;
  }
  x56() {
    return this.f55_1.t56_1;
  }
  y56(_set____db54di) {
    this.f55_1.u56_1 = _set____db54di;
  }
  z56() {
    return this.f55_1.u56_1;
  }
  a57(_set____db54di) {
    this.f55_1.s56_1 = _set____db54di;
  }
  b57() {
    return this.f55_1.s56_1;
  }
  c57() {
    return new DateTimeComponentsContents(this.d55_1.c57(), this.e55_1.c57(), this.f55_1.c57(), this.g55_1);
  }
  equals(other) {
    var tmp;
    var tmp_0;
    var tmp_1;
    var tmp_2;
    if (other instanceof DateTimeComponentsContents) {
      tmp_2 = other.d55_1.equals(this.d55_1);
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      tmp_1 = other.e55_1.equals(this.e55_1);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = other.f55_1.equals(this.f55_1);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = other.g55_1 == this.g55_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    var tmp = this.d55_1.hashCode() ^ this.e55_1.hashCode() ^ this.f55_1.hashCode();
    var tmp0_safe_receiver = this.g55_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : getStringHashCode(tmp0_safe_receiver);
    return tmp ^ (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs);
  }
}
class Companion_4 {
  u57(block) {
    var builder = new Builder(new AppendableFormatStructure());
    block(builder);
    return new DateTimeComponentsFormat(builder.h2o());
  }
}
class Formats {
  constructor() {
    Formats_instance = this;
    var tmp = this;
    var tmp_0 = Companion_instance_4;
    tmp.v57_1 = tmp_0.u57(DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda);
    var tmp_1 = this;
    var tmp_2 = Companion_instance_4;
    tmp_1.w57_1 = tmp_2.u57(DateTimeComponents$Formats$RFC_1123$lambda);
  }
}
class DateTimeComponents {
  constructor(contents) {
    contents = contents === VOID ? new DateTimeComponentsContents() : contents;
    this.x57_1 = contents;
    this.y57_1 = year$factory(this.x57_1.d55_1);
    this.z57_1 = new TwoDigitNumber(monthNumber$factory(this.x57_1.d55_1));
    this.a58_1 = new TwoDigitNumber(dayOfMonth$factory(this.x57_1.d55_1));
    this.b58_1 = new ThreeDigitNumber(dayOfYear$factory(this.x57_1.d55_1));
    this.c58_1 = new TwoDigitNumber(hour$factory(this.x57_1.e55_1));
    this.d58_1 = new TwoDigitNumber(hourOfAmPm$factory(this.x57_1.e55_1));
    this.e58_1 = amPm$factory(this.x57_1.e55_1);
    this.f58_1 = new TwoDigitNumber(minute$factory(this.x57_1.e55_1));
    this.g58_1 = new TwoDigitNumber(second$factory(this.x57_1.e55_1));
    this.h58_1 = isNegative$factory(this.x57_1.f55_1);
    this.i58_1 = new TwoDigitNumber(totalHoursAbs$factory(this.x57_1.f55_1));
    this.j58_1 = new TwoDigitNumber(minutesOfHour$factory(this.x57_1.f55_1));
    this.k58_1 = new TwoDigitNumber(secondsOfMinute$factory(this.x57_1.f55_1));
    this.l58_1 = timeZoneId$factory_0(this.x57_1);
  }
  u55(_set____db54di) {
    var tmp0 = this.y57_1;
    // Inline function 'kotlin.setValue' call
    year$factory_0();
    tmp0.set(_set____db54di);
    return Unit_instance;
  }
  v55() {
    var tmp0 = this.y57_1;
    // Inline function 'kotlin.getValue' call
    year$factory_1();
    return tmp0.get();
  }
  n56() {
    return this.x57_1.e55_1.c56_1;
  }
  m58() {
    return this.x57_1.f55_1.m58();
  }
  n58() {
    return this.x57_1.e55_1.n58();
  }
  o58() {
    var offset = this.m58();
    var time = this.n58();
    var truncatedDate = this.x57_1.d55_1.c57();
    truncatedDate.i55_1 = requireParsedField(truncatedDate.i55_1, 'year') % 10000 | 0;
    var tmp;
    try {
      var secDelta = safeMultiply(toLong(ensureNotNull(this.v55()) / 10000 | 0), new Long(2036907392, 73));
      var epochDays = toLong(truncatedDate.p58().r58());
      // Inline function 'kotlin.Long.times' call
      var tmp2 = epochDays.w3(toLong(86400));
      // Inline function 'kotlin.Long.plus' call
      var other = time.t58();
      var tmp4 = tmp2.u3(toLong(other));
      // Inline function 'kotlin.Long.minus' call
      var other_0 = offset.v58();
      var tmp$ret$2 = tmp4.v3(toLong(other_0));
      tmp = safeAdd(secDelta, tmp$ret$2);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ArithmeticException) {
        var e = $p;
        throw DateTimeFormatException.v54('The parsed date is outside the range representable by Instant', e);
      } else {
        throw $p;
      }
    }
    var totalSeconds = tmp;
    if (totalSeconds.s1(Companion_getInstance_13().s53_1.x58()) < 0 || totalSeconds.s1(Companion_getInstance_13().t53_1.x58()) > 0)
      throw DateTimeFormatException.t54('The parsed date is outside the range representable by Instant');
    var tmp_1 = Companion_getInstance_13();
    var tmp0_elvis_lhs = this.n56();
    return tmp_1.y58(totalSeconds, tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs);
  }
}
class AbstractDateTimeFormatBuilder {}
function appendAlternativeParsingImpl(otherFormats, mainFormat) {
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(otherFormats.length);
  var inductionVariable = 0;
  var last = otherFormats.length;
  while (inductionVariable < last) {
    var item = otherFormats[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    // Inline function 'kotlin.also' call
    var this_0 = this.f59();
    item(this_0);
    var tmp$ret$2 = this_0.a59().h2o();
    destination.l(tmp$ret$2);
  }
  var others = destination;
  // Inline function 'kotlin.also' call
  var this_1 = this.f59();
  mainFormat(this_1);
  var main = this_1.a59().h2o();
  this.a59().d59(new AlternativesParsingFormatStructure(main, others));
}
function appendOptionalImpl(onZero, format) {
  var tmp = this.a59();
  // Inline function 'kotlin.also' call
  var this_0 = this.f59();
  format(this_0);
  tmp.d59(new OptionalFormatStructure(onZero, this_0.a59().h2o()));
}
function chars(value) {
  return this.a59().d59(new ConstantFormatStructure(value));
}
function build() {
  return new CachedFormatStructure(this.a59().h2o().i5a_1);
}
class WithDate {}
function year$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.k59(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.k59.call(this, padding);
  }
  return tmp;
}
function monthNumber$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.l59(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.l59.call(this, padding);
  }
  return tmp;
}
function dayOfMonth$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.k57(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.k57.call(this, padding);
  }
  return tmp;
}
class AbstractWithDateBuilder {}
function year(padding) {
  return this.i59(new BasicFormatStructure(new YearDirective(padding)));
}
function monthNumber(padding) {
  return this.i59(new BasicFormatStructure(new MonthDirective(padding)));
}
function monthName(names) {
  return this.i59(new BasicFormatStructure(new MonthNameDirective(names)));
}
function dayOfMonth(padding) {
  return this.i59(new BasicFormatStructure(new DayDirective(padding)));
}
function dayOfWeek(names) {
  return this.i59(new BasicFormatStructure(new DayOfWeekDirective(names)));
}
function date(format) {
  var tmp;
  if (format instanceof LocalDateFormat) {
    this.i59(format.q5a_1);
    tmp = Unit_instance;
  }
  return tmp;
}
class WithTime {}
function hour$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.o59(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.o59.call(this, padding);
  }
  return tmp;
}
function minute$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.p59(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.p59.call(this, padding);
  }
  return tmp;
}
function second$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.q59(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.q59.call(this, padding);
  }
  return tmp;
}
class AbstractWithTimeBuilder {}
function hour(padding) {
  return this.j59(new BasicFormatStructure(new HourDirective(padding)));
}
function minute(padding) {
  return this.j59(new BasicFormatStructure(new MinuteDirective(padding)));
}
function second(padding) {
  return this.j59(new BasicFormatStructure(new SecondDirective(padding)));
}
function secondFraction(minLength, maxLength) {
  return this.j59(new BasicFormatStructure(new FractionalSecondDirective(minLength, maxLength)));
}
class AbstractWithDateTimeBuilder {}
function addFormatStructureForDate(structure) {
  this.b59(structure);
}
function addFormatStructureForTime(structure) {
  this.b59(structure);
}
class WithUtcOffset {}
function offsetHours$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.r59(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.r59.call(this, padding);
  }
  return tmp;
}
function offsetMinutesOfHour$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.s59(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.s59.call(this, padding);
  }
  return tmp;
}
function offsetSecondsOfMinute$default(padding, $super) {
  padding = padding === VOID ? Padding_ZERO_getInstance() : padding;
  var tmp;
  if ($super === VOID) {
    this.u59(padding);
    tmp = Unit_instance;
  } else {
    tmp = $super.u59.call(this, padding);
  }
  return tmp;
}
class AbstractWithOffsetBuilder {}
function offsetHours(padding) {
  return this.e59(new SignedFormatStructure(new BasicFormatStructure(new UtcOffsetWholeHoursDirective(padding)), true));
}
function offsetMinutesOfHour(padding) {
  return this.e59(new BasicFormatStructure(new UtcOffsetMinuteOfHourDirective(padding)));
}
function offsetSecondsOfMinute(padding) {
  return this.e59(new BasicFormatStructure(new UtcOffsetSecondOfMinuteDirective(padding)));
}
function offset(format) {
  var tmp;
  if (format instanceof UtcOffsetFormat) {
    this.e59(format.k5e_1);
    tmp = Unit_instance;
  }
  return tmp;
}
class Builder {
  constructor(actualBuilder) {
    this.z58_1 = actualBuilder;
  }
  a59() {
    return this.z58_1;
  }
  b59(structure) {
    this.z58_1.d59(structure);
  }
  e59(structure) {
    this.z58_1.d59(structure);
  }
  f59() {
    return new Builder(new AppendableFormatStructure());
  }
}
class AbstractDateTimeFormat {
  b5a(input) {
    var tmp;
    try {
      tmp = Parser__match$default_impl_x2xlti(_Parser___init__impl__gdyfby(this.x59().h5a()), input, this.a5a());
    } catch ($p) {
      var tmp_0;
      if ($p instanceof ParseException) {
        var e = $p;
        throw DateTimeFormatException.v54("Failed to parse value from '" + toString(input) + "'", e);
      } else {
        throw $p;
      }
    }
    var matched = tmp;
    try {
      return this.z59(matched);
    } catch ($p) {
      if ($p instanceof IllegalArgumentException) {
        var e_0 = $p;
        var message = e_0.message;
        throw DateTimeFormatException.v54(message == null ? "The value parsed from '" + toString(input) + "' is invalid" : '' + message + " (when parsing '" + toString(input) + "')", e_0);
      } else {
        throw $p;
      }
    }
  }
}
class DateTimeComponentsFormat extends AbstractDateTimeFormat {
  constructor(actualFormat) {
    super();
    this.w59_1 = actualFormat;
  }
  x59() {
    return this.w59_1;
  }
  y59(intermediate) {
    return new DateTimeComponents(intermediate);
  }
  z59(intermediate) {
    return this.y59(intermediate instanceof DateTimeComponentsContents ? intermediate : THROW_CCE());
  }
  a5a() {
    return get_emptyDateTimeComponentsContents();
  }
}
class TwoDigitNumber {
  constructor(reference) {
    this.c5a_1 = reference;
  }
}
class ThreeDigitNumber {
  constructor(reference) {
    this.d5a_1 = reference;
  }
}
class Padding extends Enum {}
class IncompleteLocalDate {
  constructor(year, monthNumber, dayOfMonth, isoDayOfWeek, dayOfYear) {
    year = year === VOID ? null : year;
    monthNumber = monthNumber === VOID ? null : monthNumber;
    dayOfMonth = dayOfMonth === VOID ? null : dayOfMonth;
    isoDayOfWeek = isoDayOfWeek === VOID ? null : isoDayOfWeek;
    dayOfYear = dayOfYear === VOID ? null : dayOfYear;
    this.i55_1 = year;
    this.j55_1 = monthNumber;
    this.k55_1 = dayOfMonth;
    this.l55_1 = isoDayOfWeek;
    this.m55_1 = dayOfYear;
  }
  u55(_set____db54di) {
    this.i55_1 = _set____db54di;
  }
  v55() {
    return this.i55_1;
  }
  s55(_set____db54di) {
    this.j55_1 = _set____db54di;
  }
  t55() {
    return this.j55_1;
  }
  h55(_set____db54di) {
    this.k55_1 = _set____db54di;
  }
  n55() {
    return this.k55_1;
  }
  q55(_set____db54di) {
    this.l55_1 = _set____db54di;
  }
  r55() {
    return this.l55_1;
  }
  o55(_set____db54di) {
    this.m55_1 = _set____db54di;
  }
  p55() {
    return this.m55_1;
  }
  p58() {
    var year = requireParsedField(this.i55_1, 'year');
    var dayOfYear = this.m55_1;
    var tmp;
    if (dayOfYear == null) {
      tmp = LocalDate_0.j5a(year, requireParsedField(this.j55_1, 'monthNumber'), requireParsedField(this.k55_1, 'dayOfMonth'));
    } else {
      // Inline function 'kotlin.also' call
      var this_0 = plus_0(LocalDate_0.j5a(year, 1, 1), dayOfYear - 1 | 0, Companion_getInstance_3().i54_1);
      if (!(this_0.v55() === year)) {
        throw DateTimeFormatException.t54('Can not create a LocalDate from the given input: ' + ('the day of year is ' + dayOfYear + ', which is not a valid day of year for the year ' + year));
      }
      if (!(this.j55_1 == null) && !(this_0.t55() === this.j55_1)) {
        throw DateTimeFormatException.t54('Can not create a LocalDate from the given input: ' + ('the day of year is ' + dayOfYear + ', which is ' + this_0.k5a().toString() + ', ') + ('but ' + this.j55_1 + ' was specified as the month number'));
      }
      if (!(this.k55_1 == null) && !(this_0.n55() === this.k55_1)) {
        throw DateTimeFormatException.t54('Can not create a LocalDate from the given input: ' + ('the day of year is ' + dayOfYear + ', which is the day ' + this_0.n55() + ' of ' + this_0.k5a().toString() + ', ') + ('but ' + this.k55_1 + ' was specified as the day of month'));
      }
      tmp = this_0;
    }
    var date = tmp;
    var tmp0_safe_receiver = this.l55_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      if (!(tmp0_safe_receiver === get_isoDayNumber(date.l5a()))) {
        throw DateTimeFormatException.t54('Can not create a LocalDate from the given input: ' + ('the day of week is ' + DayOfWeek_0(tmp0_safe_receiver).toString() + ' but the date is ' + date.toString() + ', which is a ' + date.l5a().toString()));
      }
    }
    return date;
  }
  c57() {
    return new IncompleteLocalDate(this.i55_1, this.j55_1, this.k55_1, this.l55_1, this.m55_1);
  }
  equals(other) {
    var tmp;
    var tmp_0;
    var tmp_1;
    var tmp_2;
    var tmp_3;
    if (other instanceof IncompleteLocalDate) {
      tmp_3 = this.i55_1 == other.i55_1;
    } else {
      tmp_3 = false;
    }
    if (tmp_3) {
      tmp_2 = this.j55_1 == other.j55_1;
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      tmp_1 = this.k55_1 == other.k55_1;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = this.l55_1 == other.l55_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.m55_1 == other.m55_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver = this.i55_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
    var tmp$ret$0 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    var tmp = imul(tmp$ret$0, 923521);
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver_0 = this.j55_1;
    var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
    var tmp$ret$1 = tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0;
    var tmp_0 = tmp + imul(tmp$ret$1, 29791) | 0;
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver_1 = this.k55_1;
    var tmp1_elvis_lhs_1 = tmp0_safe_receiver_1 == null ? null : hashCode(tmp0_safe_receiver_1);
    var tmp$ret$2 = tmp1_elvis_lhs_1 == null ? 0 : tmp1_elvis_lhs_1;
    var tmp_1 = tmp_0 + imul(tmp$ret$2, 961) | 0;
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver_2 = this.l55_1;
    var tmp1_elvis_lhs_2 = tmp0_safe_receiver_2 == null ? null : hashCode(tmp0_safe_receiver_2);
    var tmp$ret$3 = tmp1_elvis_lhs_2 == null ? 0 : tmp1_elvis_lhs_2;
    var tmp_2 = tmp_1 + imul(tmp$ret$3, 31) | 0;
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver_3 = this.m55_1;
    var tmp1_elvis_lhs_3 = tmp0_safe_receiver_3 == null ? null : hashCode(tmp0_safe_receiver_3);
    return tmp_2 + (tmp1_elvis_lhs_3 == null ? 0 : tmp1_elvis_lhs_3) | 0;
  }
  toString() {
    var tmp0_elvis_lhs = this.i55_1;
    var tmp = toString(tmp0_elvis_lhs == null ? '??' : tmp0_elvis_lhs);
    var tmp1_elvis_lhs = this.j55_1;
    var tmp_0 = toString(tmp1_elvis_lhs == null ? '??' : tmp1_elvis_lhs);
    var tmp2_elvis_lhs = this.k55_1;
    var tmp_1 = toString(tmp2_elvis_lhs == null ? '??' : tmp2_elvis_lhs);
    var tmp3_elvis_lhs = this.l55_1;
    return tmp + '-' + tmp_0 + '-' + tmp_1 + ' (day of week is ' + toString(tmp3_elvis_lhs == null ? '??' : tmp3_elvis_lhs) + ')';
  }
}
class Companion_5 {
  constructor() {
    Companion_instance_5 = this;
    this.l57_1 = new MonthNames(listOf(['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']));
    this.m57_1 = new MonthNames(listOf(['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']));
  }
}
class MonthNames {
  constructor(names) {
    Companion_getInstance_5();
    this.m5a_1 = names;
    // Inline function 'kotlin.require' call
    if (!(this.m5a_1.b1() === 12)) {
      var message = 'Month names must contain exactly 12 elements';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.collections.forEach' call
    var progression = get_indices(this.m5a_1);
    var inductionVariable = progression.t1_1;
    var last = progression.u1_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var ix = element;
        // Inline function 'kotlin.text.isNotEmpty' call
        var this_0 = this.m5a_1.f1(ix);
        // Inline function 'kotlin.require' call
        if (!(charSequenceLength(this_0) > 0)) {
          var message_0 = 'A month name can not be empty';
          throw IllegalArgumentException.t(toString(message_0));
        }
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < ix)
          do {
            var ix2 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            // Inline function 'kotlin.require' call
            if (!!(this.m5a_1.f1(ix) === this.m5a_1.f1(ix2))) {
              var message_1 = "Month names must be unique, but '" + this.m5a_1.f1(ix) + "' was repeated";
              throw IllegalArgumentException.t(toString(message_1));
            }
          }
           while (inductionVariable_0 < ix);
      }
       while (!(element === last));
  }
  toString() {
    return joinToString(this.m5a_1, ', ', 'MonthNames(', ')', VOID, VOID, String$toString$ref());
  }
  equals(other) {
    var tmp;
    if (other instanceof MonthNames) {
      tmp = equals(this.m5a_1, other.m5a_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.m5a_1);
  }
}
class Companion_6 {
  constructor() {
    Companion_instance_6 = this;
    this.q57_1 = new DayOfWeekNames(listOf(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']));
    this.r57_1 = new DayOfWeekNames(listOf(['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']));
  }
}
class DayOfWeekNames {
  constructor(names) {
    Companion_getInstance_6();
    this.n5a_1 = names;
    // Inline function 'kotlin.require' call
    if (!(this.n5a_1.b1() === 7)) {
      var message = 'Day of week names must contain exactly 7 elements';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.collections.forEach' call
    var progression = get_indices(this.n5a_1);
    var inductionVariable = progression.t1_1;
    var last = progression.u1_1;
    if (inductionVariable <= last)
      do {
        var element = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var ix = element;
        // Inline function 'kotlin.text.isNotEmpty' call
        var this_0 = this.n5a_1.f1(ix);
        // Inline function 'kotlin.require' call
        if (!(charSequenceLength(this_0) > 0)) {
          var message_0 = 'A day-of-week name can not be empty';
          throw IllegalArgumentException.t(toString(message_0));
        }
        var inductionVariable_0 = 0;
        if (inductionVariable_0 < ix)
          do {
            var ix2 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + 1 | 0;
            // Inline function 'kotlin.require' call
            if (!!(this.n5a_1.f1(ix) === this.n5a_1.f1(ix2))) {
              var message_1 = "Day-of-week names must be unique, but '" + this.n5a_1.f1(ix) + "' was repeated";
              throw IllegalArgumentException.t(toString(message_1));
            }
          }
           while (inductionVariable_0 < ix);
      }
       while (!(element === last));
  }
  toString() {
    return joinToString(this.n5a_1, ', ', 'DayOfWeekNames(', ')', VOID, VOID, String$toString$ref_0());
  }
  equals(other) {
    var tmp;
    if (other instanceof DayOfWeekNames) {
      tmp = equals(this.n5a_1, other.n5a_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n5a_1);
  }
}
class Companion_7 {
  o5a(block) {
    var builder = new Builder_0(new AppendableFormatStructure());
    block(builder);
    return new LocalDateFormat(builder.h2o());
  }
}
class Builder_0 {
  constructor(actualBuilder) {
    this.p5a_1 = actualBuilder;
  }
  a59() {
    return this.p5a_1;
  }
  i59(structure) {
    return this.p5a_1.d59(structure);
  }
  f59() {
    return new Builder_0(new AppendableFormatStructure());
  }
}
class LocalDateFormat extends AbstractDateTimeFormat {
  constructor(actualFormat) {
    super();
    this.q5a_1 = actualFormat;
  }
  x59() {
    return this.q5a_1;
  }
  r5a(intermediate) {
    return intermediate.p58();
  }
  z59(intermediate) {
    return this.r5a(intermediate instanceof IncompleteLocalDate ? intermediate : THROW_CCE());
  }
  a5a() {
    return get_emptyIncompleteLocalDate();
  }
}
class SignedIntFieldFormatDirective {
  constructor(field, minDigits, maxDigits, spacePadding, outputPlusOnExceededWidth) {
    this.e5b_1 = field;
    this.f5b_1 = minDigits;
    this.g5b_1 = maxDigits;
    this.h5b_1 = spacePadding;
    this.i5b_1 = outputPlusOnExceededWidth;
    // Inline function 'kotlin.require' call
    if (!(this.f5b_1 == null || this.f5b_1 >= 0)) {
      var message = 'The minimum number of digits (' + this.f5b_1 + ') is negative';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.g5b_1 == null || this.f5b_1 == null || this.g5b_1 >= this.f5b_1)) {
      var message_0 = 'The maximum number of digits (' + this.g5b_1 + ') is less than the minimum number of digits (' + this.f5b_1 + ')';
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
  j5b() {
    return this.e5b_1;
  }
  k5b() {
    var tmp = Accessor$getterNotNull$ref(this.e5b_1.a5f());
    var tmp0_elvis_lhs = this.f5b_1;
    var formatter = new SignedIntFormatterStructure(tmp, tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs, this.i5b_1);
    return !(this.h5b_1 == null) ? new SpacePaddedFormatter(formatter, this.h5b_1) : formatter;
  }
  h5a() {
    return SignedIntParser(this.f5b_1, this.g5b_1, this.h5b_1, this.e5b_1.a5f(), this.e5b_1.e44(), this.i5b_1);
  }
}
class YearDirective extends SignedIntFieldFormatDirective {
  constructor(padding, isYearOfEra) {
    isYearOfEra = isYearOfEra === VOID ? false : isYearOfEra;
    var tmp = DateFields_getInstance().s5a_1;
    // Inline function 'kotlinx.datetime.format.minDigits' call
    var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 4 : 1;
    // Inline function 'kotlinx.datetime.format.spaces' call
    super(tmp, tmp_0, null, padding.equals(Padding_SPACE_getInstance()) ? 4 : null, 4);
    this.c5b_1 = padding;
    this.d5b_1 = isYearOfEra;
  }
  equals(other) {
    var tmp;
    var tmp_0;
    if (other instanceof YearDirective) {
      tmp_0 = this.c5b_1.equals(other.c5b_1);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.d5b_1 === other.d5b_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return imul(this.c5b_1.hashCode(), 31) + getBooleanHashCode(this.d5b_1) | 0;
  }
}
class UnsignedIntFieldFormatDirective {
  constructor(field, minDigits, spacePadding) {
    this.q5b_1 = field;
    this.r5b_1 = minDigits;
    this.s5b_1 = spacePadding;
    this.t5b_1 = this.q5b_1.h5f_1;
    // Inline function 'kotlin.require' call
    if (!(this.r5b_1 >= 0)) {
      var message = 'The minimum number of digits (' + this.r5b_1 + ') is negative';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.t5b_1 >= this.r5b_1)) {
      var message_0 = 'The maximum number of digits (' + this.t5b_1 + ') is less than the minimum number of digits (' + this.r5b_1 + ')';
      throw IllegalArgumentException.t(toString(message_0));
    }
    if (!(this.s5b_1 == null)) {
      // Inline function 'kotlin.require' call
      if (!(this.s5b_1 > this.r5b_1)) {
        var message_1 = 'The space padding (' + this.s5b_1 + ') should be more than the minimum number of digits (' + this.r5b_1 + ')';
        throw IllegalArgumentException.t(toString(message_1));
      }
    }
  }
  j5b() {
    return this.q5b_1;
  }
  k5b() {
    var formatter = new UnsignedIntFormatterStructure(Accessor$getterNotNull$ref_0(this.q5b_1.b5f_1), this.r5b_1);
    return !(this.s5b_1 == null) ? new SpacePaddedFormatter(formatter, this.s5b_1) : formatter;
  }
  h5a() {
    return spaceAndZeroPaddedUnsignedInt(this.r5b_1, this.t5b_1, this.s5b_1, this.q5b_1.b5f_1, this.q5b_1.e5f_1);
  }
}
class MonthDirective extends UnsignedIntFieldFormatDirective {
  constructor(padding) {
    var tmp = DateFields_getInstance().t5a_1;
    // Inline function 'kotlinx.datetime.format.minDigits' call
    var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
    // Inline function 'kotlinx.datetime.format.spaces' call
    super(tmp, tmp_0, padding.equals(Padding_SPACE_getInstance()) ? 2 : null);
    this.p5b_1 = padding;
  }
  equals(other) {
    var tmp;
    if (other instanceof MonthDirective) {
      tmp = this.p5b_1.equals(other.p5b_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return this.p5b_1.hashCode();
  }
}
class NamedUnsignedIntFieldFormatDirective {
  constructor(field, values, name) {
    this.y5b_1 = field;
    this.z5b_1 = values;
    this.a5c_1 = name;
    // Inline function 'kotlin.require' call
    if (!(this.z5b_1.b1() === ((this.y5b_1.d5f_1 - this.y5b_1.c5f_1 | 0) + 1 | 0))) {
      var message = 'The number of values (' + this.z5b_1.b1() + ') in ' + toString(this.z5b_1) + ' does not match the range of the field (' + ((this.y5b_1.d5f_1 - this.y5b_1.c5f_1 | 0) + 1 | 0) + ')';
      throw IllegalArgumentException.t(toString(message));
    }
  }
  j5b() {
    return this.y5b_1;
  }
  k5b() {
    return new StringFormatterStructure(NamedUnsignedIntFieldFormatDirective$getStringValue$ref(this));
  }
  h5a() {
    return new ParserStructure(listOf_0(new StringSetParserOperation(this.z5b_1, new AssignableString(this), 'one of ' + toString(this.z5b_1) + ' for ' + this.a5c_1)), emptyList());
  }
}
class MonthNameDirective extends NamedUnsignedIntFieldFormatDirective {
  constructor(names) {
    super(DateFields_getInstance().t5a_1, names.m5a_1, 'monthName');
    this.x5b_1 = names;
  }
  equals(other) {
    var tmp;
    if (other instanceof MonthNameDirective) {
      tmp = equals(this.x5b_1.m5a_1, other.x5b_1.m5a_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.x5b_1.m5a_1);
  }
}
class DayDirective extends UnsignedIntFieldFormatDirective {
  constructor(padding) {
    var tmp = DateFields_getInstance().u5a_1;
    // Inline function 'kotlinx.datetime.format.minDigits' call
    var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
    // Inline function 'kotlinx.datetime.format.spaces' call
    super(tmp, tmp_0, padding.equals(Padding_SPACE_getInstance()) ? 2 : null);
    this.f5c_1 = padding;
  }
  equals(other) {
    var tmp;
    if (other instanceof DayDirective) {
      tmp = this.f5c_1.equals(other.f5c_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return this.f5c_1.hashCode();
  }
}
class DayOfWeekDirective extends NamedUnsignedIntFieldFormatDirective {
  constructor(names) {
    super(DateFields_getInstance().v5a_1, names.n5a_1, 'dayOfWeekName');
    this.j5c_1 = names;
  }
  equals(other) {
    var tmp;
    if (other instanceof DayOfWeekDirective) {
      tmp = equals(this.j5c_1.n5a_1, other.j5c_1.n5a_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.j5c_1.n5a_1);
  }
}
class DateFields {
  constructor() {
    DateFields_instance = this;
    this.s5a_1 = new GenericFieldSpec(new PropertyAccessor(year$factory_2()));
    this.t5a_1 = new UnsignedFieldSpec(new PropertyAccessor(monthNumber$factory_0()), 1, 12);
    this.u5a_1 = new UnsignedFieldSpec(new PropertyAccessor(dayOfMonth$factory_0()), 1, 31);
    this.v5a_1 = new UnsignedFieldSpec(new PropertyAccessor(isoDayOfWeek$factory()), 1, 7);
    this.w5a_1 = new UnsignedFieldSpec(new PropertyAccessor(dayOfYear$factory_0()), 1, 366);
  }
}
class IncompleteLocalTime {
  constructor(hour, hourOfAmPm, amPm, minute, second, nanosecond) {
    hour = hour === VOID ? null : hour;
    hourOfAmPm = hourOfAmPm === VOID ? null : hourOfAmPm;
    amPm = amPm === VOID ? null : amPm;
    minute = minute === VOID ? null : minute;
    second = second === VOID ? null : second;
    nanosecond = nanosecond === VOID ? null : nanosecond;
    this.x55_1 = hour;
    this.y55_1 = hourOfAmPm;
    this.z55_1 = amPm;
    this.a56_1 = minute;
    this.b56_1 = second;
    this.c56_1 = nanosecond;
  }
  g56(_set____db54di) {
    this.x55_1 = _set____db54di;
  }
  h56() {
    return this.x55_1;
  }
  i56(_set____db54di) {
    this.y55_1 = _set____db54di;
  }
  j56() {
    return this.y55_1;
  }
  w55(_set____db54di) {
    this.z55_1 = _set____db54di;
  }
  d56() {
    return this.z55_1;
  }
  k56(_set____db54di) {
    this.a56_1 = _set____db54di;
  }
  l56() {
    return this.a56_1;
  }
  o56(_set____db54di) {
    this.b56_1 = _set____db54di;
  }
  p56() {
    return this.b56_1;
  }
  m56(_set____db54di) {
    this.c56_1 = _set____db54di;
  }
  n56() {
    return this.c56_1;
  }
  n58() {
    var tmp0_safe_receiver = this.x55_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      var tmp0_safe_receiver_0 = this.y55_1;
      if (tmp0_safe_receiver_0 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        // Inline function 'kotlin.require' call
        if (!((((tmp0_safe_receiver + 11 | 0) % 12 | 0) + 1 | 0) === tmp0_safe_receiver_0)) {
          var message = 'Inconsistent hour and hour-of-am-pm: hour is ' + tmp0_safe_receiver + ', but hour-of-am-pm is ' + tmp0_safe_receiver_0;
          throw IllegalArgumentException.t(toString(message));
        }
      }
      var tmp1_safe_receiver = this.z55_1;
      if (tmp1_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        // Inline function 'kotlin.require' call
        if (!(tmp1_safe_receiver.equals(AmPmMarker_PM_getInstance()) === tmp0_safe_receiver >= 12)) {
          var message_0 = 'Inconsistent hour and the AM/PM marker: hour is ' + tmp0_safe_receiver + ', but the AM/PM marker is ' + tmp1_safe_receiver.toString();
          throw IllegalArgumentException.t(toString(message_0));
        }
      }
      tmp = tmp0_safe_receiver;
    }
    var tmp2_elvis_lhs = tmp;
    var tmp_0;
    if (tmp2_elvis_lhs == null) {
      var tmp1_safe_receiver_0 = this.y55_1;
      var tmp_1;
      if (tmp1_safe_receiver_0 == null) {
        tmp_1 = null;
      } else {
        // Inline function 'kotlin.let' call
        var tmp0_safe_receiver_1 = this.z55_1;
        var tmp_2;
        if (tmp0_safe_receiver_1 == null) {
          tmp_2 = null;
        } else {
          // Inline function 'kotlin.let' call
          // Inline function 'kotlin.let' call
          tmp_2 = (tmp1_safe_receiver_0 === 12 ? 0 : tmp1_safe_receiver_0) + (tmp0_safe_receiver_1.equals(AmPmMarker_PM_getInstance()) ? 12 : 0) | 0;
        }
        tmp_1 = tmp_2;
      }
      tmp_0 = tmp_1;
    } else {
      tmp_0 = tmp2_elvis_lhs;
    }
    var tmp3_elvis_lhs = tmp_0;
    var tmp_3;
    if (tmp3_elvis_lhs == null) {
      throw DateTimeFormatException.t54('Incomplete time: missing hour');
    } else {
      tmp_3 = tmp3_elvis_lhs;
    }
    var hour = tmp_3;
    var tmp_4 = requireParsedField(this.a56_1, 'minute');
    var tmp4_elvis_lhs = this.b56_1;
    var tmp_5 = tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs;
    var tmp5_elvis_lhs = this.c56_1;
    return LocalTime_0.n5c(hour, tmp_4, tmp_5, tmp5_elvis_lhs == null ? 0 : tmp5_elvis_lhs);
  }
  c57() {
    return new IncompleteLocalTime(this.x55_1, this.y55_1, this.z55_1, this.a56_1, this.b56_1, this.c56_1);
  }
  equals(other) {
    var tmp;
    var tmp_0;
    var tmp_1;
    var tmp_2;
    var tmp_3;
    var tmp_4;
    if (other instanceof IncompleteLocalTime) {
      tmp_4 = this.x55_1 == other.x55_1;
    } else {
      tmp_4 = false;
    }
    if (tmp_4) {
      tmp_3 = this.y55_1 == other.y55_1;
    } else {
      tmp_3 = false;
    }
    if (tmp_3) {
      tmp_2 = equals(this.z55_1, other.z55_1);
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      tmp_1 = this.a56_1 == other.a56_1;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = this.b56_1 == other.b56_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.c56_1 == other.c56_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    var tmp6_elvis_lhs = this.x55_1;
    var tmp = imul(tmp6_elvis_lhs == null ? 0 : tmp6_elvis_lhs, 31);
    var tmp5_elvis_lhs = this.y55_1;
    var tmp_0 = tmp + imul(tmp5_elvis_lhs == null ? 0 : tmp5_elvis_lhs, 31) | 0;
    var tmp3_safe_receiver = this.z55_1;
    var tmp4_elvis_lhs = tmp3_safe_receiver == null ? null : tmp3_safe_receiver.hashCode();
    var tmp_1 = tmp_0 + imul(tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs, 31) | 0;
    var tmp2_elvis_lhs = this.a56_1;
    var tmp_2 = tmp_1 + imul(tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs, 31) | 0;
    var tmp1_elvis_lhs = this.b56_1;
    var tmp_3 = tmp_2 + imul(tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs, 31) | 0;
    var tmp0_elvis_lhs = this.c56_1;
    return tmp_3 + (tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs) | 0;
  }
  toString() {
    var tmp0_elvis_lhs = this.x55_1;
    var tmp = toString(tmp0_elvis_lhs == null ? '??' : tmp0_elvis_lhs);
    var tmp1_elvis_lhs = this.a56_1;
    var tmp_0 = toString(tmp1_elvis_lhs == null ? '??' : tmp1_elvis_lhs);
    var tmp2_elvis_lhs = this.b56_1;
    var tmp_1 = toString(tmp2_elvis_lhs == null ? '??' : tmp2_elvis_lhs);
    var tmp3_safe_receiver = this.c56_1;
    var tmp_2;
    if (tmp3_safe_receiver == null) {
      tmp_2 = null;
    } else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.let' call
      var it = tmp3_safe_receiver.toString();
      tmp_2 = padStart(it, 9 - it.length | 0, _Char___init__impl__6a9atx(48));
    }
    var tmp4_elvis_lhs = tmp_2;
    return tmp + ':' + tmp_0 + ':' + tmp_1 + '.' + (tmp4_elvis_lhs == null ? '???' : tmp4_elvis_lhs);
  }
}
class AmPmMarker extends Enum {}
class Companion_8 {
  o5c(block) {
    var builder = new Builder_1(new AppendableFormatStructure());
    block(builder);
    return new LocalTimeFormat(builder.h2o());
  }
}
class Builder_1 {
  constructor(actualBuilder) {
    this.p5c_1 = actualBuilder;
  }
  a59() {
    return this.p5c_1;
  }
  j59(structure) {
    this.p5c_1.d59(structure);
  }
  f59() {
    return new Builder_1(new AppendableFormatStructure());
  }
}
class LocalTimeFormat extends AbstractDateTimeFormat {
  constructor(actualFormat) {
    super();
    this.q5c_1 = actualFormat;
  }
  x59() {
    return this.q5c_1;
  }
  r5c(intermediate) {
    return intermediate.n58();
  }
  z59(intermediate) {
    return this.r5c(intermediate instanceof IncompleteLocalTime ? intermediate : THROW_CCE());
  }
  a5a() {
    return get_emptyIncompleteLocalTime();
  }
}
class HourDirective extends UnsignedIntFieldFormatDirective {
  constructor(padding) {
    var tmp = TimeFields_getInstance().s5c_1;
    // Inline function 'kotlinx.datetime.format.minDigits' call
    var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
    // Inline function 'kotlinx.datetime.format.spaces' call
    super(tmp, tmp_0, padding.equals(Padding_SPACE_getInstance()) ? 2 : null);
    this.c5d_1 = padding;
  }
  equals(other) {
    var tmp;
    if (other instanceof HourDirective) {
      tmp = this.c5d_1.equals(other.c5d_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return this.c5d_1.hashCode();
  }
}
class MinuteDirective extends UnsignedIntFieldFormatDirective {
  constructor(padding) {
    var tmp = TimeFields_getInstance().t5c_1;
    // Inline function 'kotlinx.datetime.format.minDigits' call
    var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
    // Inline function 'kotlinx.datetime.format.spaces' call
    super(tmp, tmp_0, padding.equals(Padding_SPACE_getInstance()) ? 2 : null);
    this.h5d_1 = padding;
  }
  equals(other) {
    var tmp;
    if (other instanceof MinuteDirective) {
      tmp = this.h5d_1.equals(other.h5d_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return this.h5d_1.hashCode();
  }
}
class SecondDirective extends UnsignedIntFieldFormatDirective {
  constructor(padding) {
    var tmp = TimeFields_getInstance().u5c_1;
    // Inline function 'kotlinx.datetime.format.minDigits' call
    var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
    // Inline function 'kotlinx.datetime.format.spaces' call
    super(tmp, tmp_0, padding.equals(Padding_SPACE_getInstance()) ? 2 : null);
    this.m5d_1 = padding;
  }
  equals(other) {
    var tmp;
    if (other instanceof SecondDirective) {
      tmp = this.m5d_1.equals(other.m5d_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return this.m5d_1.hashCode();
  }
}
class Companion_9 {
  constructor() {
    Companion_instance_9 = this;
    this.n5d_1 = listOf([0, 0, 0, 0, 0, 0, 0, 0, 0]);
    this.o5d_1 = listOf([2, 1, 0, 2, 1, 0, 2, 1, 0]);
  }
}
class DecimalFractionFieldFormatDirective {
  constructor(field, minDigits, maxDigits, zerosToAdd) {
    this.v5d_1 = field;
    this.w5d_1 = minDigits;
    this.x5d_1 = maxDigits;
    this.y5d_1 = zerosToAdd;
  }
  j5b() {
    return this.v5d_1;
  }
  k5b() {
    return new DecimalFractionFormatterStructure(Accessor$getterNotNull$ref_1(this.v5d_1.a5f()), this.w5d_1, this.x5d_1, this.y5d_1);
  }
  h5a() {
    return new ParserStructure(listOf_0(new NumberSpanParserOperation(listOf_0(new FractionPartConsumer(this.w5d_1, this.x5d_1, this.v5d_1.a5f(), this.v5d_1.e44())))), emptyList());
  }
}
class FractionalSecondDirective extends DecimalFractionFieldFormatDirective {
  constructor(minDigits, maxDigits, zerosToAdd) {
    Companion_getInstance_9();
    zerosToAdd = zerosToAdd === VOID ? Companion_getInstance_9().n5d_1 : zerosToAdd;
    super(TimeFields_getInstance().v5c_1, minDigits, maxDigits, zerosToAdd);
    this.t5d_1 = minDigits;
    this.u5d_1 = maxDigits;
  }
  equals(other) {
    var tmp;
    var tmp_0;
    if (other instanceof FractionalSecondDirective) {
      tmp_0 = this.t5d_1 === other.t5d_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.u5d_1 === other.u5d_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return imul(31, this.t5d_1) + this.u5d_1 | 0;
  }
}
class TimeFields {
  constructor() {
    TimeFields_instance = this;
    this.s5c_1 = new UnsignedFieldSpec(new PropertyAccessor(hour$factory_0()), 0, 23);
    this.t5c_1 = new UnsignedFieldSpec(new PropertyAccessor(minute$factory_0()), 0, 59);
    this.u5c_1 = new UnsignedFieldSpec(new PropertyAccessor(second$factory_0()), 0, 59, VOID, 0);
    this.v5c_1 = new GenericFieldSpec(new PropertyAccessor(fractionOfSecond$factory()), VOID, new DecimalFraction(0, 9));
    this.w5c_1 = new GenericFieldSpec(new PropertyAccessor(amPm$factory_0()));
    this.x5c_1 = new UnsignedFieldSpec(new PropertyAccessor(hourOfAmPm$factory_0()), 1, 12);
  }
}
class IncompleteUtcOffset {
  constructor(isNegative, totalHoursAbs, minutesOfHour, secondsOfMinute) {
    isNegative = isNegative === VOID ? null : isNegative;
    totalHoursAbs = totalHoursAbs === VOID ? null : totalHoursAbs;
    minutesOfHour = minutesOfHour === VOID ? null : minutesOfHour;
    secondsOfMinute = secondsOfMinute === VOID ? null : secondsOfMinute;
    this.r56_1 = isNegative;
    this.s56_1 = totalHoursAbs;
    this.t56_1 = minutesOfHour;
    this.u56_1 = secondsOfMinute;
  }
  q56(_set____db54di) {
    this.r56_1 = _set____db54di;
  }
  v56() {
    return this.r56_1;
  }
  a57(_set____db54di) {
    this.s56_1 = _set____db54di;
  }
  b57() {
    return this.s56_1;
  }
  w56(_set____db54di) {
    this.t56_1 = _set____db54di;
  }
  x56() {
    return this.t56_1;
  }
  y56(_set____db54di) {
    this.u56_1 = _set____db54di;
  }
  z56() {
    return this.u56_1;
  }
  m58() {
    var sign = this.r56_1 === true ? -1 : 1;
    var tmp0_safe_receiver = this.s56_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = imul(tmp0_safe_receiver, sign);
    }
    var tmp_0 = tmp;
    var tmp1_safe_receiver = this.t56_1;
    var tmp_1;
    if (tmp1_safe_receiver == null) {
      tmp_1 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_1 = imul(tmp1_safe_receiver, sign);
    }
    var tmp_2 = tmp_1;
    var tmp2_safe_receiver = this.u56_1;
    var tmp_3;
    if (tmp2_safe_receiver == null) {
      tmp_3 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_3 = imul(tmp2_safe_receiver, sign);
    }
    return UtcOffset_0(tmp_0, tmp_2, tmp_3);
  }
  equals(other) {
    var tmp;
    var tmp_0;
    var tmp_1;
    var tmp_2;
    if (other instanceof IncompleteUtcOffset) {
      tmp_2 = this.r56_1 == other.r56_1;
    } else {
      tmp_2 = false;
    }
    if (tmp_2) {
      tmp_1 = this.s56_1 == other.s56_1;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = this.t56_1 == other.t56_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.u56_1 == other.u56_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver = this.r56_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
    var tmp = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver_0 = this.s56_1;
    var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
    var tmp_0 = tmp + (tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0) | 0;
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver_1 = this.t56_1;
    var tmp1_elvis_lhs_1 = tmp0_safe_receiver_1 == null ? null : hashCode(tmp0_safe_receiver_1);
    var tmp_1 = tmp_0 + (tmp1_elvis_lhs_1 == null ? 0 : tmp1_elvis_lhs_1) | 0;
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver_2 = this.u56_1;
    var tmp1_elvis_lhs_2 = tmp0_safe_receiver_2 == null ? null : hashCode(tmp0_safe_receiver_2);
    return tmp_1 + (tmp1_elvis_lhs_2 == null ? 0 : tmp1_elvis_lhs_2) | 0;
  }
  c57() {
    return new IncompleteUtcOffset(this.r56_1, this.s56_1, this.t56_1, this.u56_1);
  }
  toString() {
    var tmp0_safe_receiver = this.r56_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = tmp0_safe_receiver ? '-' : '+';
    }
    var tmp1_elvis_lhs = tmp;
    var tmp_0 = tmp1_elvis_lhs == null ? ' ' : tmp1_elvis_lhs;
    var tmp2_elvis_lhs = this.s56_1;
    var tmp_1 = toString(tmp2_elvis_lhs == null ? '??' : tmp2_elvis_lhs);
    var tmp3_elvis_lhs = this.t56_1;
    var tmp_2 = toString(tmp3_elvis_lhs == null ? '??' : tmp3_elvis_lhs);
    var tmp4_elvis_lhs = this.u56_1;
    return tmp_0 + tmp_1 + ':' + tmp_2 + ':' + toString(tmp4_elvis_lhs == null ? '??' : tmp4_elvis_lhs);
  }
}
class UtcOffsetWholeHoursDirective extends UnsignedIntFieldFormatDirective {
  constructor(padding) {
    var tmp = OffsetFields_getInstance().a5e_1;
    // Inline function 'kotlinx.datetime.format.minDigits' call
    var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
    // Inline function 'kotlinx.datetime.format.spaces' call
    super(tmp, tmp_0, padding.equals(Padding_SPACE_getInstance()) ? 2 : null);
    this.h5e_1 = padding;
  }
  equals(other) {
    var tmp;
    if (other instanceof UtcOffsetWholeHoursDirective) {
      tmp = this.h5e_1.equals(other.h5e_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return this.h5e_1.hashCode();
  }
}
class Companion_10 {
  i5e(block) {
    var builder = new Builder_2(new AppendableFormatStructure());
    block(builder);
    return new UtcOffsetFormat(builder.h2o());
  }
}
class Builder_2 {
  constructor(actualBuilder) {
    this.j5e_1 = actualBuilder;
  }
  a59() {
    return this.j5e_1;
  }
  e59(structure) {
    this.j5e_1.d59(structure);
  }
  f59() {
    return new Builder_2(new AppendableFormatStructure());
  }
}
class UtcOffsetFormat extends AbstractDateTimeFormat {
  constructor(actualFormat) {
    super();
    this.k5e_1 = actualFormat;
  }
  x59() {
    return this.k5e_1;
  }
  l5e(intermediate) {
    return intermediate.m58();
  }
  z59(intermediate) {
    return this.l5e(intermediate instanceof IncompleteUtcOffset ? intermediate : THROW_CCE());
  }
  a5a() {
    return get_emptyIncompleteUtcOffset();
  }
}
class OffsetFields$sign$1 {
  constructor() {
    this.m5e_1 = new PropertyAccessor(isNegative$factory_0());
  }
  v56() {
    return this.m5e_1;
  }
  n5e(obj) {
    var tmp;
    var tmp_0;
    var tmp0_elvis_lhs = obj.b57();
    if ((tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs) === 0) {
      var tmp1_elvis_lhs = obj.x56();
      tmp_0 = (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) === 0;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      var tmp2_elvis_lhs = obj.z56();
      tmp = (tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs) === 0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  o5e(obj) {
    return this.n5e((!(obj == null) ? isInterface(obj, UtcOffsetFieldContainer) : false) ? obj : THROW_CCE());
  }
}
class OffsetFields {
  constructor() {
    OffsetFields_instance = this;
    var tmp = this;
    tmp.z5d_1 = new OffsetFields$sign$1();
    var tmp_0 = this;
    var tmp0_accessor = new PropertyAccessor(totalHoursAbs$factory_0());
    var tmp1_sign = this.z5d_1;
    tmp_0.a5e_1 = new UnsignedFieldSpec(tmp0_accessor, 0, 18, VOID, 0, tmp1_sign);
    var tmp_1 = this;
    var tmp0_accessor_0 = new PropertyAccessor(minutesOfHour$factory_0());
    var tmp1_sign_0 = this.z5d_1;
    tmp_1.b5e_1 = new UnsignedFieldSpec(tmp0_accessor_0, 0, 59, VOID, 0, tmp1_sign_0);
    var tmp_2 = this;
    var tmp0_accessor_1 = new PropertyAccessor(secondsOfMinute$factory_0());
    var tmp1_sign_1 = this.z5d_1;
    tmp_2.c5e_1 = new UnsignedFieldSpec(tmp0_accessor_1, 0, 59, VOID, 0, tmp1_sign_1);
  }
}
class UtcOffsetMinuteOfHourDirective extends UnsignedIntFieldFormatDirective {
  constructor(padding) {
    var tmp = OffsetFields_getInstance().b5e_1;
    // Inline function 'kotlinx.datetime.format.minDigits' call
    var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
    // Inline function 'kotlinx.datetime.format.spaces' call
    super(tmp, tmp_0, padding.equals(Padding_SPACE_getInstance()) ? 2 : null);
    this.t5e_1 = padding;
  }
  equals(other) {
    var tmp;
    if (other instanceof UtcOffsetMinuteOfHourDirective) {
      tmp = this.t5e_1.equals(other.t5e_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return this.t5e_1.hashCode();
  }
}
class UtcOffsetSecondOfMinuteDirective extends UnsignedIntFieldFormatDirective {
  constructor(padding) {
    var tmp = OffsetFields_getInstance().c5e_1;
    // Inline function 'kotlinx.datetime.format.minDigits' call
    var tmp_0 = padding.equals(Padding_ZERO_getInstance()) ? 2 : 1;
    // Inline function 'kotlinx.datetime.format.spaces' call
    super(tmp, tmp_0, padding.equals(Padding_SPACE_getInstance()) ? 2 : null);
    this.y5e_1 = padding;
  }
  equals(other) {
    var tmp;
    if (other instanceof UtcOffsetSecondOfMinuteDirective) {
      tmp = this.y5e_1.equals(other.y5e_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return this.y5e_1.hashCode();
  }
}
class AppendableFormatStructure {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.c59_1 = ArrayList.k();
  }
  h2o() {
    return new ConcatenatedFormatStructure(this.c59_1);
  }
  d59(format) {
    if (isInterface(format, NonConcatenatedFormatStructure)) {
      this.c59_1.l(format);
    } else {
      if (format instanceof ConcatenatedFormatStructure) {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s = format.i5a_1.y();
        while (_iterator__ex2g4s.z()) {
          var element = _iterator__ex2g4s.a1();
          this.c59_1.l(element);
        }
      }
    }
  }
}
class AssignableString {
  constructor($outer) {
    this.i5f_1 = $outer;
  }
  j5f(container, newValue) {
    var tmp0_safe_receiver = this.i5f_1.y5b_1.b5f_1.k5f(container, this.i5f_1.z5b_1.x2(newValue) + this.i5f_1.y5b_1.c5f_1 | 0);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = this.i5f_1.z5b_1.f1(tmp0_safe_receiver - this.i5f_1.y5b_1.c5f_1 | 0);
    }
    return tmp;
  }
  k5f(container, newValue) {
    var tmp = (container == null ? true : !(container == null)) ? container : THROW_CCE();
    return this.j5f(tmp, (!(newValue == null) ? typeof newValue === 'string' : false) ? newValue : THROW_CCE());
  }
  e44() {
    return this.i5f_1.a5c_1;
  }
}
class AbstractFieldSpec {
  toString() {
    return 'The field ' + this.e44() + ' (default value is ' + toString_1(this.p5f()) + ')';
  }
}
class GenericFieldSpec extends AbstractFieldSpec {
  constructor(accessor, name, defaultValue, sign) {
    name = name === VOID ? accessor.e44() : name;
    defaultValue = defaultValue === VOID ? null : defaultValue;
    sign = sign === VOID ? null : sign;
    super();
    this.l5f_1 = accessor;
    this.m5f_1 = name;
    this.n5f_1 = defaultValue;
    this.o5f_1 = sign;
  }
  a5f() {
    return this.l5f_1;
  }
  e44() {
    return this.m5f_1;
  }
  p5f() {
    return this.n5f_1;
  }
  q5f() {
    return this.o5f_1;
  }
}
class Accessor {}
function getterNotNull(container) {
  var tmp0_elvis_lhs = this.t5f(container);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException.t4('Field ' + this.e44() + ' is not set');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
class PropertyAccessor {
  constructor(property) {
    this.r5f_1 = property;
  }
  e44() {
    return this.r5f_1.callableName;
  }
  s5f(container, newValue) {
    var oldValue = this.r5f_1.get(container);
    var tmp;
    if (oldValue === null) {
      this.r5f_1.set(container, newValue);
      tmp = null;
    } else if (equals(oldValue, newValue)) {
      tmp = null;
    } else {
      tmp = oldValue;
    }
    return tmp;
  }
  k5f(container, newValue) {
    var tmp = (container == null ? true : !(container == null)) ? container : THROW_CCE();
    return this.s5f(tmp, (newValue == null ? true : !(newValue == null)) ? newValue : THROW_CCE());
  }
  t5f(container) {
    return this.r5f_1.get(container);
  }
}
class UnsignedFieldSpec extends AbstractFieldSpec {
  constructor(accessor, minValue, maxValue, name, defaultValue, sign) {
    name = name === VOID ? accessor.e44() : name;
    defaultValue = defaultValue === VOID ? null : defaultValue;
    sign = sign === VOID ? null : sign;
    super();
    this.b5f_1 = accessor;
    this.c5f_1 = minValue;
    this.d5f_1 = maxValue;
    this.e5f_1 = name;
    this.f5f_1 = defaultValue;
    this.g5f_1 = sign;
    var tmp = this;
    var tmp_0;
    if (this.d5f_1 < 10) {
      tmp_0 = 1;
    } else if (this.d5f_1 < 100) {
      tmp_0 = 2;
    } else if (this.d5f_1 < 1000) {
      tmp_0 = 3;
    } else {
      throw IllegalArgumentException.t('Max value ' + this.d5f_1 + ' is too large');
    }
    tmp.h5f_1 = tmp_0;
  }
  a5f() {
    return this.b5f_1;
  }
  e44() {
    return this.e5f_1;
  }
  p5f() {
    return this.f5f_1;
  }
  q5f() {
    return this.g5f_1;
  }
}
class ConcatenatedFormatStructure {
  constructor(formats) {
    this.i5a_1 = formats;
  }
  toString() {
    return 'ConcatenatedFormatStructure(' + joinToString(this.i5a_1, ', ') + ')';
  }
  equals(other) {
    var tmp;
    if (other instanceof ConcatenatedFormatStructure) {
      tmp = equals(this.i5a_1, other.i5a_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.i5a_1);
  }
  h5a() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.i5a_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = item.h5a();
      destination.l(tmp$ret$0);
    }
    return concat(destination);
  }
  k5b() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.i5a_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = item.k5b();
      destination.l(tmp$ret$0);
    }
    var formatters = destination;
    var tmp;
    if (formatters.b1() === 1) {
      tmp = single(formatters);
    } else {
      tmp = new ConcatenatedFormatter(formatters);
    }
    return tmp;
  }
}
class CachedFormatStructure extends ConcatenatedFormatStructure {
  constructor(formats) {
    super(formats);
    this.f5a_1 = super.k5b();
    this.g5a_1 = super.h5a();
  }
  k5b() {
    return this.f5a_1;
  }
  h5a() {
    return this.g5a_1;
  }
}
class NonConcatenatedFormatStructure {}
class BasicFormatStructure {
  constructor(directive) {
    this.u5f_1 = directive;
  }
  toString() {
    return 'BasicFormatStructure(' + toString(this.u5f_1) + ')';
  }
  equals(other) {
    var tmp;
    if (other instanceof BasicFormatStructure) {
      tmp = equals(this.u5f_1, other.u5f_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.u5f_1);
  }
  h5a() {
    return this.u5f_1.h5a();
  }
  k5b() {
    return this.u5f_1.k5b();
  }
}
class ConstantFormatStructure {
  constructor(string) {
    this.v5f_1 = string;
  }
  toString() {
    return 'ConstantFormatStructure(' + this.v5f_1 + ')';
  }
  equals(other) {
    var tmp;
    if (other instanceof ConstantFormatStructure) {
      tmp = this.v5f_1 === other.v5f_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return getStringHashCode(this.v5f_1);
  }
  h5a() {
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = this.v5f_1;
    if (charSequenceLength(this_0) === 0) {
      tmp = emptyList();
    } else {
      // Inline function 'kotlin.collections.buildList' call
      // Inline function 'kotlin.collections.buildListInternal' call
      // Inline function 'kotlin.apply' call
      var this_1 = ArrayList.k();
      var tmp_0;
      if (isAsciiDigit(charSequenceGet(this.v5f_1, 0))) {
        var tmp0 = this.v5f_1;
        var tmp$ret$4;
        $l$block: {
          // Inline function 'kotlin.text.takeWhile' call
          var inductionVariable = 0;
          var last = tmp0.length;
          if (inductionVariable < last)
            do {
              var index = inductionVariable;
              inductionVariable = inductionVariable + 1 | 0;
              var it = charSequenceGet(tmp0, index);
              if (!isAsciiDigit(it)) {
                // Inline function 'kotlin.text.substring' call
                // Inline function 'kotlin.js.asDynamic' call
                tmp$ret$4 = tmp0.substring(0, index);
                break $l$block;
              }
            }
             while (inductionVariable < last);
          tmp$ret$4 = tmp0;
        }
        this_1.l(new NumberSpanParserOperation(listOf_0(new ConstantNumberConsumer(tmp$ret$4))));
        var tmp2 = this.v5f_1;
        var tmp$ret$8;
        $l$block_0: {
          // Inline function 'kotlin.text.dropWhile' call
          var inductionVariable_0 = 0;
          var last_0 = charSequenceLength(tmp2) - 1 | 0;
          if (inductionVariable_0 <= last_0)
            do {
              var index_0 = inductionVariable_0;
              inductionVariable_0 = inductionVariable_0 + 1 | 0;
              var it_0 = charSequenceGet(tmp2, index_0);
              if (!isAsciiDigit(it_0)) {
                // Inline function 'kotlin.text.substring' call
                // Inline function 'kotlin.js.asDynamic' call
                tmp$ret$8 = tmp2.substring(index_0);
                break $l$block_0;
              }
            }
             while (inductionVariable_0 <= last_0);
          tmp$ret$8 = '';
        }
        tmp_0 = tmp$ret$8;
      } else {
        tmp_0 = this.v5f_1;
      }
      var suffix = tmp_0;
      // Inline function 'kotlin.text.isNotEmpty' call
      if (charSequenceLength(suffix) > 0) {
        if (isAsciiDigit(charSequenceGet(suffix, suffix.length - 1 | 0))) {
          var tmp$ret$13;
          $l$block_1: {
            // Inline function 'kotlin.text.dropLastWhile' call
            var inductionVariable_1 = get_lastIndex(suffix);
            if (0 <= inductionVariable_1)
              do {
                var index_1 = inductionVariable_1;
                inductionVariable_1 = inductionVariable_1 + -1 | 0;
                var it_1 = charSequenceGet(suffix, index_1);
                if (!isAsciiDigit(it_1)) {
                  // Inline function 'kotlin.text.substring' call
                  var endIndex = index_1 + 1 | 0;
                  // Inline function 'kotlin.js.asDynamic' call
                  tmp$ret$13 = suffix.substring(0, endIndex);
                  break $l$block_1;
                }
              }
               while (0 <= inductionVariable_1);
            tmp$ret$13 = '';
          }
          this_1.l(new PlainStringParserOperation(tmp$ret$13));
          var tmp$ret$17;
          $l$block_2: {
            // Inline function 'kotlin.text.takeLastWhile' call
            var inductionVariable_2 = get_lastIndex(suffix);
            if (0 <= inductionVariable_2)
              do {
                var index_2 = inductionVariable_2;
                inductionVariable_2 = inductionVariable_2 + -1 | 0;
                var it_2 = charSequenceGet(suffix, index_2);
                if (!isAsciiDigit(it_2)) {
                  // Inline function 'kotlin.text.substring' call
                  var startIndex = index_2 + 1 | 0;
                  // Inline function 'kotlin.js.asDynamic' call
                  tmp$ret$17 = suffix.substring(startIndex);
                  break $l$block_2;
                }
              }
               while (0 <= inductionVariable_2);
            tmp$ret$17 = suffix;
          }
          this_1.l(new NumberSpanParserOperation(listOf_0(new ConstantNumberConsumer(tmp$ret$17))));
        } else {
          this_1.l(new PlainStringParserOperation(suffix));
        }
      }
      tmp = this_1.w7();
    }
    return new ParserStructure(tmp, emptyList());
  }
  k5b() {
    return new ConstantStringFormatterStructure(this.v5f_1);
  }
}
class SignedFormatStructure {
  constructor(format, withPlusSign) {
    this.w5f_1 = format;
    this.x5f_1 = withPlusSign;
    var tmp = this;
    // Inline function 'kotlin.collections.mapNotNull' call
    var tmp0 = basicFormats(this.w5f_1);
    // Inline function 'kotlin.collections.mapNotNullTo' call
    var destination = ArrayList.k();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp0_safe_receiver = element.j5b().q5f();
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        destination.l(tmp0_safe_receiver);
      }
    }
    tmp.y5f_1 = toSet(destination);
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.require' call
    if (!!this.y5f_1.h1()) {
      var message = 'Signed format must contain at least one field with a sign';
      throw IllegalArgumentException.t(toString(message));
    }
  }
  toString() {
    return 'SignedFormatStructure(' + toString(this.w5f_1) + ')';
  }
  equals(other) {
    var tmp;
    var tmp_0;
    if (other instanceof SignedFormatStructure) {
      tmp_0 = equals(this.w5f_1, other.w5f_1);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = this.x5f_1 === other.x5f_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return imul(31, hashCode(this.w5f_1)) + getBooleanHashCode(this.x5f_1) | 0;
  }
  h5a() {
    return concat(listOf([new ParserStructure(listOf_0(new SignParser(SignedFormatStructure$parser$lambda(this), this.x5f_1, 'sign for ' + toString(this.y5f_1))), emptyList()), this.w5f_1.h5a()]));
  }
  k5b() {
    var innerFormat = this.w5f_1.k5b();
    return new SignedFormatter(innerFormat, SignedFormatStructure$formatter$checkIfAllNegative$ref(this), this.x5f_1);
  }
}
class Companion_11 {
  z5f(field) {
    var default_0 = field.p5f();
    // Inline function 'kotlin.require' call
    if (!!(default_0 == null)) {
      var message = "The field '" + field.e44() + "' does not define a default value";
      throw IllegalArgumentException.t(toString(message));
    }
    return new PropertyWithDefault(field.a5f(), default_0);
  }
}
class PropertyWithDefault {
  constructor(accessor, defaultValue) {
    this.a5g_1 = accessor;
    this.b5g_1 = defaultValue;
  }
}
class OptionalFormatStructure {
  constructor(onZero, format) {
    this.c5g_1 = onZero;
    this.d5g_1 = format;
    var tmp = this;
    // Inline function 'kotlin.collections.map' call
    var this_0 = basicFormats(this.d5g_1);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = item.j5b();
      destination.l(tmp$ret$0);
    }
    // Inline function 'kotlin.collections.map' call
    var this_1 = distinct(destination);
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(this_1, 10));
    var _iterator__ex2g4s_0 = this_1.y();
    while (_iterator__ex2g4s_0.z()) {
      var item_0 = _iterator__ex2g4s_0.a1();
      var tmp$ret$3 = Companion_instance_11.z5f(item_0);
      destination_0.l(tmp$ret$3);
    }
    tmp.e5g_1 = destination_0;
  }
  toString() {
    return 'Optional(' + this.c5g_1 + ', ' + toString(this.d5g_1) + ')';
  }
  equals(other) {
    var tmp;
    var tmp_0;
    if (other instanceof OptionalFormatStructure) {
      tmp_0 = this.c5g_1 === other.c5g_1;
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = equals(this.d5g_1, other.d5g_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return imul(31, getStringHashCode(this.c5g_1)) + hashCode(this.d5g_1) | 0;
  }
  h5a() {
    var tmp = emptyList();
    var tmp_0 = this.d5g_1.h5a();
    var tmp_1 = (new ConstantFormatStructure(this.c5g_1)).h5a();
    var tmp_2;
    if (this.e5g_1.h1()) {
      tmp_2 = emptyList();
    } else {
      tmp_2 = listOf_0(new UnconditionalModification(OptionalFormatStructure$parser$lambda(this)));
    }
    return new ParserStructure(tmp, listOf([tmp_0, concat(listOf([tmp_1, new ParserStructure(tmp_2, emptyList())]))]));
  }
  k5b() {
    var formatter = this.d5g_1.k5b();
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.e5g_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      // Inline function 'kotlinx.datetime.internal.format.PropertyWithDefault.isDefaultComparisonPredicate' call
      var tmp = access$_get_defaultValue__8tt04b(item);
      var tmp$ret$1 = new ComparisonPredicate(tmp, Accessor$getter$ref(access$_get_accessor__yxxs4k(item)));
      destination.l(tmp$ret$1);
    }
    var predicate = conjunctionPredicate(destination);
    var tmp_0;
    if (predicate instanceof Truth) {
      tmp_0 = new ConstantStringFormatterStructure(this.c5g_1);
    } else {
      var tmp_1 = to(Predicate$test$ref(predicate), new ConstantStringFormatterStructure(this.c5g_1));
      tmp_0 = new ConditionalFormatter(listOf([tmp_1, to(Truth$test$ref(Truth_instance), formatter)]));
    }
    return tmp_0;
  }
}
class AlternativesParsingFormatStructure {
  constructor(mainFormat, formats) {
    this.h5g_1 = mainFormat;
    this.i5g_1 = formats;
  }
  toString() {
    return 'AlternativesParsing(' + toString(this.i5g_1) + ')';
  }
  equals(other) {
    var tmp;
    var tmp_0;
    if (other instanceof AlternativesParsingFormatStructure) {
      tmp_0 = equals(this.h5g_1, other.h5g_1);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = equals(this.i5g_1, other.i5g_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return imul(31, hashCode(this.h5g_1)) + hashCode(this.i5g_1) | 0;
  }
  h5a() {
    var tmp = emptyList();
    // Inline function 'kotlin.collections.buildList' call
    // Inline function 'kotlin.collections.buildListInternal' call
    // Inline function 'kotlin.apply' call
    var this_0 = ArrayList.k();
    this_0.l(this.h5g_1.h5a());
    var tmp0_iterator = this.i5g_1.y();
    while (tmp0_iterator.z()) {
      var format = tmp0_iterator.a1();
      this_0.l(format.h5a());
    }
    var tmp$ret$3 = this_0.w7();
    return new ParserStructure(tmp, tmp$ret$3);
  }
  k5b() {
    return this.h5g_1.k5b();
  }
}
class ComparisonPredicate {
  constructor(expectedValue, getter) {
    this.j5g_1 = expectedValue;
    this.k5g_1 = getter;
  }
  f5g(value) {
    return equals(this.k5g_1(value), this.j5g_1);
  }
}
class Truth {
  g5g(value) {
    return true;
  }
  f5g(value) {
    return this.g5g((value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
}
class ConjunctionPredicate {
  constructor(predicates) {
    this.l5g_1 = predicates;
  }
  f5g(value) {
    var tmp0 = this.l5g_1;
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.all' call
      var tmp;
      if (isInterface(tmp0, Collection)) {
        tmp = tmp0.h1();
      } else {
        tmp = false;
      }
      if (tmp) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (!element.f5g(value)) {
          tmp$ret$0 = false;
          break $l$block_0;
        }
      }
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  }
}
class SpacePaddedFormatter {
  constructor(formatter, padding) {
    this.m5g_1 = formatter;
    this.n5g_1 = padding;
  }
}
class SignedFormatter {
  constructor(formatter, allSubFormatsNegative, alwaysOutputSign) {
    this.o5g_1 = formatter;
    this.p5g_1 = allSubFormatsNegative;
    this.q5g_1 = alwaysOutputSign;
  }
}
class ConditionalFormatter {
  constructor(formatters) {
    this.r5g_1 = formatters;
  }
}
class ConcatenatedFormatter {
  constructor(formatters) {
    this.s5g_1 = formatters;
  }
}
class SignedIntFormatterStructure {
  constructor(number, zeroPadding, outputPlusOnExceededWidth) {
    this.t5g_1 = number;
    this.u5g_1 = zeroPadding;
    this.v5g_1 = outputPlusOnExceededWidth;
    // Inline function 'kotlin.require' call
    if (!(this.u5g_1 >= 0)) {
      var message = 'The minimum number of digits (' + this.u5g_1 + ') is negative';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.u5g_1 <= 9)) {
      var message_0 = 'The minimum number of digits (' + this.u5g_1 + ') exceeds the length of an Int';
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
}
class UnsignedIntFormatterStructure {
  constructor(number, zeroPadding) {
    this.w5g_1 = number;
    this.x5g_1 = zeroPadding;
    // Inline function 'kotlin.require' call
    if (!(this.x5g_1 >= 0)) {
      var message = 'The minimum number of digits (' + this.x5g_1 + ') is negative';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.x5g_1 <= 9)) {
      var message_0 = 'The minimum number of digits (' + this.x5g_1 + ') exceeds the length of an Int';
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
}
class StringFormatterStructure {
  constructor(string) {
    this.y5g_1 = string;
  }
}
class DecimalFractionFormatterStructure {
  constructor(number, minDigits, maxDigits, zerosToAdd) {
    this.z5g_1 = number;
    this.a5h_1 = minDigits;
    this.b5h_1 = maxDigits;
    this.c5h_1 = zerosToAdd;
    var containsArg = this.a5h_1;
    // Inline function 'kotlin.require' call
    if (!(1 <= containsArg ? containsArg <= 9 : false)) {
      var message = 'The minimum number of digits (' + this.a5h_1 + ') is not in range 1..9';
      throw IllegalArgumentException.t(toString(message));
    }
    var containsLower = this.a5h_1;
    var containsArg_0 = this.b5h_1;
    // Inline function 'kotlin.require' call
    if (!(containsLower <= containsArg_0 ? containsArg_0 <= 9 : false)) {
      var message_0 = 'The maximum number of digits (' + this.b5h_1 + ') is not in range ' + this.a5h_1 + '..9';
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
}
class ConstantStringFormatterStructure {
  constructor(string) {
    this.d5h_1 = string;
  }
}
class NumberConsumer {
  constructor(length, whatThisExpects) {
    this.j5h_1 = length;
    this.k5h_1 = whatThisExpects;
  }
  a() {
    return this.j5h_1;
  }
}
class FractionPartConsumer extends NumberConsumer {
  constructor(minLength, maxLength, setter, name) {
    super(minLength === maxLength ? minLength : null, name);
    this.g5h_1 = minLength;
    this.h5h_1 = maxLength;
    this.i5h_1 = setter;
    var containsArg = this.g5h_1;
    // Inline function 'kotlin.require' call
    if (!(1 <= containsArg ? containsArg <= 9 : false)) {
      var message = 'Invalid minimum length ' + this.g5h_1 + ' for field ' + this.k5h_1 + ': expected 1..9';
      throw IllegalArgumentException.t(toString(message));
    }
    var containsLower = this.g5h_1;
    var containsArg_0 = this.h5h_1;
    // Inline function 'kotlin.require' call
    if (!(containsLower <= containsArg_0 ? containsArg_0 <= 9 : false)) {
      var message_0 = 'Invalid maximum length ' + this.h5h_1 + ' for field ' + this.k5h_1 + ': expected ' + this.g5h_1 + '..9';
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
  l5h(storage, input, start, end) {
    return (end - start | 0) < this.g5h_1 ? new TooFewDigits(this.g5h_1) : (end - start | 0) > this.h5h_1 ? new TooManyDigits(this.h5h_1) : setWithoutReassigning(this.i5h_1, storage, new DecimalFraction(parseAsciiInt(input, start, end), end - start | 0));
  }
}
class ConstantNumberConsumer extends NumberConsumer {
  constructor(expected) {
    super(expected.length, 'the predefined string ' + expected);
    this.o5h_1 = expected;
  }
  l5h(storage, input, start, end) {
    var tmp;
    // Inline function 'kotlin.text.substring' call
    if (toString(charSequenceSubSequence(input, start, end)) === this.o5h_1) {
      tmp = null;
    } else {
      tmp = new WrongConstant(this.o5h_1);
    }
    return tmp;
  }
}
class ExpectedInt {
  p5h() {
    return 'expected an Int value';
  }
}
class TooManyDigits {
  constructor(maxDigits) {
    this.q5h_1 = maxDigits;
  }
  p5h() {
    return 'expected at most ' + this.q5h_1 + ' digits';
  }
}
class TooFewDigits {
  constructor(minDigits) {
    this.r5h_1 = minDigits;
  }
  p5h() {
    return 'expected at least ' + this.r5h_1 + ' digits';
  }
}
class WrongConstant {
  constructor(expected) {
    this.s5h_1 = expected;
  }
  p5h() {
    return "expected '" + this.s5h_1 + "'";
  }
}
class Conflicting {
  constructor(conflicting) {
    this.t5h_1 = conflicting;
  }
  p5h() {
    return "attempted to overwrite the existing value '" + toString(this.t5h_1) + "'";
  }
}
class UnsignedIntConsumer extends NumberConsumer {
  constructor(minLength, maxLength, setter, name, multiplyByMinus1) {
    multiplyByMinus1 = multiplyByMinus1 === VOID ? false : multiplyByMinus1;
    super(minLength == maxLength ? minLength : null, name);
    this.w5h_1 = minLength;
    this.x5h_1 = maxLength;
    this.y5h_1 = setter;
    this.z5h_1 = multiplyByMinus1;
    // Inline function 'kotlin.require' call
    if (!(this.a() == null || numberRangeToNumber(1, 9).lo(this.a()))) {
      var message = 'Invalid length for field ' + this.k5h_1 + ': ' + this.a();
      throw IllegalArgumentException.t(toString(message));
    }
  }
  l5h(storage, input, start, end) {
    var tmp;
    if (!(this.x5h_1 == null) && (end - start | 0) > this.x5h_1) {
      tmp = new TooManyDigits(this.x5h_1);
    } else if (!(this.w5h_1 == null) && (end - start | 0) < this.w5h_1) {
      tmp = new TooFewDigits(this.w5h_1);
    } else {
      var result = parseAsciiIntOrNull(input, start, end);
      tmp = result == null ? ExpectedInt_instance : setWithoutReassigning(this.y5h_1, storage, this.z5h_1 ? -result | 0 : result);
    }
    return tmp;
  }
}
class ParseError {
  constructor(position, message) {
    this.a5i_1 = position;
    this.b5i_1 = message;
  }
}
class Companion_12 {
  c5i(indexOfNextUnparsed) {
    return _ParseResult___init__impl__gvz3cn(indexOfNextUnparsed);
  }
  d5i(position, message) {
    return _ParseResult___init__impl__gvz3cn(new ParseError(position, message));
  }
}
class ParserState {
  constructor(output, parserStructure, inputPosition) {
    this.e5i_1 = output;
    this.f5i_1 = parserStructure;
    this.g5i_1 = inputPosition;
  }
}
class sam$kotlin_Comparator$0 {
  constructor(function_0) {
    this.p5i_1 = function_0;
  }
  vi(a, b) {
    return this.p5i_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.p5i_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class Parser {
  constructor(commands) {
    this.h5i_1 = commands;
  }
  toString() {
    return Parser__toString_impl_x33iea(this.h5i_1);
  }
  hashCode() {
    return Parser__hashCode_impl_bbxllf(this.h5i_1);
  }
  equals(other) {
    return Parser__equals_impl_djxokv(this.h5i_1, other);
  }
}
class ParserStructure {
  constructor(operations, followedBy) {
    this.i5i_1 = operations;
    this.j5i_1 = followedBy;
  }
  toString() {
    return joinToString(this.i5i_1, ', ') + '(' + joinToString(this.j5i_1, ';') + ')';
  }
}
class ParseException extends Exception {
  static n5i(errors) {
    var $this = this.l5(formatError(errors));
    captureStack($this, $this.m5i_1);
    return $this;
  }
}
class TrieNode {
  constructor(children, isTerminal) {
    var tmp;
    if (children === VOID) {
      // Inline function 'kotlin.collections.mutableListOf' call
      tmp = ArrayList.k();
    } else {
      tmp = children;
    }
    children = tmp;
    isTerminal = isTerminal === VOID ? false : isTerminal;
    this.t5i_1 = children;
    this.u5i_1 = isTerminal;
  }
}
class sam$kotlin_Comparator$0_0 {
  constructor(function_0) {
    this.v5i_1 = function_0;
  }
  vi(a, b) {
    return this.v5i_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.v5i_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class StringSetParserOperation {
  constructor(strings, setter, whatThisExpects) {
    this.w5i_1 = setter;
    this.x5i_1 = whatThisExpects;
    this.y5i_1 = new TrieNode();
    var tmp0_iterator = strings.y();
    while (tmp0_iterator.z()) {
      var string = tmp0_iterator.a1();
      // Inline function 'kotlin.text.isNotEmpty' call
      // Inline function 'kotlin.require' call
      if (!(charSequenceLength(string) > 0)) {
        var message = 'Found an empty string in ' + this.x5i_1;
        throw IllegalArgumentException.t(toString(message));
      }
      var node = this.y5i_1;
      var inductionVariable = 0;
      var last = string.length;
      while (inductionVariable < last) {
        var char = charSequenceGet(string, inductionVariable);
        inductionVariable = inductionVariable + 1 | 0;
        var tmp2 = node.t5i_1;
        // Inline function 'kotlin.collections.binarySearchBy' call
        var key = toString_0(char);
        var toIndex = tmp2.b1();
        var searchResult = binarySearch(tmp2, 0, toIndex, StringSetParserOperation$lambda(key));
        var tmp;
        if (searchResult < 0) {
          // Inline function 'kotlin.also' call
          var this_0 = new TrieNode();
          node.t5i_1.d3((-searchResult | 0) - 1 | 0, to(toString_0(char), this_0));
          tmp = this_0;
        } else {
          tmp = node.t5i_1.f1(searchResult).sl_1;
        }
        node = tmp;
      }
      // Inline function 'kotlin.require' call
      if (!!node.u5i_1) {
        var message_0 = "The string '" + string + "' was passed several times";
        throw IllegalArgumentException.t(toString(message_0));
      }
      node.u5i_1 = true;
    }
    _init_$reduceTrie(this.y5i_1);
  }
  k5i(storage, input, startIndex) {
    var node = this.y5i_1;
    var index = {_v: startIndex};
    var lastMatch = null;
    loop: while (index._v <= charSequenceLength(input)) {
      if (node.u5i_1)
        lastMatch = index._v;
      var tmp0_iterator = node.t5i_1.y();
      while (tmp0_iterator.z()) {
        var tmp1_loop_parameter = tmp0_iterator.a1();
        var key = tmp1_loop_parameter.tl();
        var child = tmp1_loop_parameter.ul();
        if (startsWith(input, key, index._v)) {
          node = child;
          index._v = index._v + key.length | 0;
          continue loop;
        }
      }
      break loop;
    }
    var tmp;
    if (!(lastMatch == null)) {
      // Inline function 'kotlin.text.substring' call
      var endIndex = lastMatch;
      var tmp$ret$0 = toString(charSequenceSubSequence(input, startIndex, endIndex));
      tmp = setWithoutReassigning_0(this.w5i_1, storage, tmp$ret$0, startIndex, lastMatch);
    } else {
      var tmp_0 = Companion_instance_12;
      tmp = tmp_0.d5i(startIndex, StringSetParserOperation$consume$lambda(this, input, startIndex, index));
    }
    return tmp;
  }
}
class NumberSpanParserOperation {
  constructor(consumers) {
    this.q5i_1 = consumers;
    var tmp = this;
    // Inline function 'kotlin.collections.sumOf' call
    var sum = 0;
    var _iterator__ex2g4s = this.q5i_1.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp_0 = sum;
      var tmp0_elvis_lhs = element.a();
      sum = tmp_0 + (tmp0_elvis_lhs == null ? 1 : tmp0_elvis_lhs) | 0;
    }
    tmp.r5i_1 = sum;
    var tmp_1 = this;
    var tmp0 = this.q5i_1;
    var tmp$ret$2;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp_2;
      if (isInterface(tmp0, Collection)) {
        tmp_2 = tmp0.h1();
      } else {
        tmp_2 = false;
      }
      if (tmp_2) {
        tmp$ret$2 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s_0 = tmp0.y();
      while (_iterator__ex2g4s_0.z()) {
        var element_0 = _iterator__ex2g4s_0.a1();
        if (element_0.a() == null) {
          tmp$ret$2 = true;
          break $l$block_0;
        }
      }
      tmp$ret$2 = false;
    }
    tmp_1.s5i_1 = tmp$ret$2;
    var tmp0_0 = this.q5i_1;
    var tmp$ret$4;
    $l$block_2: {
      // Inline function 'kotlin.collections.all' call
      var tmp_3;
      if (isInterface(tmp0_0, Collection)) {
        tmp_3 = tmp0_0.h1();
      } else {
        tmp_3 = false;
      }
      if (tmp_3) {
        tmp$ret$4 = true;
        break $l$block_2;
      }
      var _iterator__ex2g4s_1 = tmp0_0.y();
      while (_iterator__ex2g4s_1.z()) {
        var element_1 = _iterator__ex2g4s_1.a1();
        var tmp0_elvis_lhs_0 = element_1.a();
        if (!((tmp0_elvis_lhs_0 == null ? 2147483647 : tmp0_elvis_lhs_0) > 0)) {
          tmp$ret$4 = false;
          break $l$block_2;
        }
      }
      tmp$ret$4 = true;
    }
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!tmp$ret$4) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException.t(toString(message));
    }
    var tmp3 = this.q5i_1;
    var tmp$ret$9;
    $l$block_3: {
      // Inline function 'kotlin.collections.count' call
      var tmp_4;
      if (isInterface(tmp3, Collection)) {
        tmp_4 = tmp3.h1();
      } else {
        tmp_4 = false;
      }
      if (tmp_4) {
        tmp$ret$9 = 0;
        break $l$block_3;
      }
      var count = 0;
      var _iterator__ex2g4s_2 = tmp3.y();
      while (_iterator__ex2g4s_2.z()) {
        var element_2 = _iterator__ex2g4s_2.a1();
        if (element_2.a() == null) {
          count = count + 1 | 0;
          checkCountOverflow(count);
        }
      }
      tmp$ret$9 = count;
    }
    // Inline function 'kotlin.require' call
    if (!(tmp$ret$9 <= 1)) {
      // Inline function 'kotlin.collections.filter' call
      var tmp0_1 = this.q5i_1;
      // Inline function 'kotlin.collections.filterTo' call
      var destination = ArrayList.k();
      var _iterator__ex2g4s_3 = tmp0_1.y();
      while (_iterator__ex2g4s_3.z()) {
        var element_3 = _iterator__ex2g4s_3.a1();
        if (element_3.a() == null) {
          destination.l(element_3);
        }
      }
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination_0 = ArrayList.x(collectionSizeOrDefault(destination, 10));
      var _iterator__ex2g4s_4 = destination.y();
      while (_iterator__ex2g4s_4.z()) {
        var item = _iterator__ex2g4s_4.a1();
        var tmp$ret$14 = item.k5h_1;
        destination_0.l(tmp$ret$14);
      }
      var fieldNames = destination_0;
      var message_0 = 'At most one variable-length numeric field in a row is allowed, but got several: ' + toString(fieldNames) + '. ' + 'Parsing is undefined: for example, with variable-length month number ' + "and variable-length day of month, '111' can be parsed as Jan 11th or Nov 1st.";
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
  k5i(storage, input, startIndex) {
    if ((startIndex + this.r5i_1 | 0) > charSequenceLength(input)) {
      var tmp = Companion_instance_12;
      return tmp.d5i(startIndex, NumberSpanParserOperation$consume$lambda(this));
    }
    var digitsInRow = {_v: 0};
    while ((startIndex + digitsInRow._v | 0) < charSequenceLength(input) && isAsciiDigit(charSequenceGet(input, startIndex + digitsInRow._v | 0))) {
      digitsInRow._v = digitsInRow._v + 1 | 0;
      digitsInRow._v;
    }
    if (digitsInRow._v < this.r5i_1) {
      var tmp_0 = Companion_instance_12;
      return tmp_0.d5i(startIndex, NumberSpanParserOperation$consume$lambda_0(digitsInRow, this));
    }
    var index = startIndex;
    var inductionVariable = 0;
    var last = this.q5i_1.b1() - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp1_elvis_lhs = this.q5i_1.f1(i).a();
        var length = tmp1_elvis_lhs == null ? (digitsInRow._v - this.r5i_1 | 0) + 1 | 0 : tmp1_elvis_lhs;
        var error = this.q5i_1.f1(i).l5h(storage, input, index, index + length | 0);
        if (!(error == null)) {
          var tmp1 = index;
          // Inline function 'kotlin.text.substring' call
          var endIndex = index + length | 0;
          var numberString = toString(charSequenceSubSequence(input, tmp1, endIndex));
          var tmp_1 = Companion_instance_12;
          var tmp_2 = index;
          return tmp_1.d5i(tmp_2, NumberSpanParserOperation$consume$lambda_1(numberString, this, i, error));
        }
        index = index + length | 0;
      }
       while (inductionVariable <= last);
    return Companion_instance_12.c5i(index);
  }
  toString() {
    return _get_whatThisExpects__4pg11j(this);
  }
}
class PlainStringParserOperation {
  constructor(string) {
    this.z5i_1 = string;
    // Inline function 'kotlin.text.isNotEmpty' call
    var this_0 = this.z5i_1;
    // Inline function 'kotlin.require' call
    if (!(charSequenceLength(this_0) > 0)) {
      var message = 'Empty string is not allowed';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!!isAsciiDigit(charSequenceGet(this.z5i_1, 0))) {
      var message_0 = "String '" + this.z5i_1 + "' starts with a digit";
      throw IllegalArgumentException.t(toString(message_0));
    }
    // Inline function 'kotlin.require' call
    if (!!isAsciiDigit(charSequenceGet(this.z5i_1, this.z5i_1.length - 1 | 0))) {
      var message_1 = "String '" + this.z5i_1 + "' ends with a digit";
      throw IllegalArgumentException.t(toString(message_1));
    }
  }
  k5i(storage, input, startIndex) {
    if ((startIndex + this.z5i_1.length | 0) > charSequenceLength(input)) {
      var tmp = Companion_instance_12;
      return tmp.d5i(startIndex, PlainStringParserOperation$consume$lambda(this));
    }
    var inductionVariable = 0;
    var last = charSequenceLength(this.z5i_1) - 1 | 0;
    if (inductionVariable <= last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(charSequenceGet(input, startIndex + i | 0) === charSequenceGet(this.z5i_1, i))) {
          var tmp_0 = Companion_instance_12;
          return tmp_0.d5i(startIndex, PlainStringParserOperation$consume$lambda_0(this, input, startIndex, i));
        }
      }
       while (inductionVariable <= last);
    return Companion_instance_12.c5i(startIndex + this.z5i_1.length | 0);
  }
  toString() {
    return "'" + this.z5i_1 + "'";
  }
}
class SignParser {
  constructor(isNegativeSetter, withPlusSign, whatThisExpects) {
    this.a5j_1 = isNegativeSetter;
    this.b5j_1 = withPlusSign;
    this.c5j_1 = whatThisExpects;
  }
  k5i(storage, input, startIndex) {
    if (startIndex >= charSequenceLength(input))
      return Companion_instance_12.c5i(startIndex);
    var char = charSequenceGet(input, startIndex);
    if (char === _Char___init__impl__6a9atx(45)) {
      this.a5j_1(storage, true);
      return Companion_instance_12.c5i(startIndex + 1 | 0);
    }
    if (char === _Char___init__impl__6a9atx(43) && this.b5j_1) {
      this.a5j_1(storage, false);
      return Companion_instance_12.c5i(startIndex + 1 | 0);
    }
    var tmp = Companion_instance_12;
    return tmp.d5i(startIndex, SignParser$consume$lambda(this, char));
  }
  toString() {
    return this.c5j_1;
  }
}
class UnconditionalModification {
  constructor(operation) {
    this.d5j_1 = operation;
  }
  k5i(storage, input, startIndex) {
    this.d5j_1(storage);
    return Companion_instance_12.c5i(startIndex);
  }
}
class DecimalFraction {
  constructor(fractionalPart, digits) {
    this.k5c_1 = fractionalPart;
    this.l5c_1 = digits;
    // Inline function 'kotlin.require' call
    if (!(this.l5c_1 >= 0)) {
      var message = 'Digits must be non-negative, but was ' + this.l5c_1;
      throw IllegalArgumentException.t(toString(message));
    }
  }
  m5c(newDigits) {
    return newDigits === this.l5c_1 ? this.k5c_1 : newDigits > this.l5c_1 ? imul(this.k5c_1, get_POWERS_OF_TEN()[newDigits - this.l5c_1 | 0]) : this.k5c_1 / get_POWERS_OF_TEN()[this.l5c_1 - newDigits | 0] | 0;
  }
  e5j(other) {
    var tmp0 = this.l5c_1;
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = other.l5c_1;
    // Inline function 'kotlin.let' call
    var maxPrecision = Math.max(tmp0, b);
    return compareTo(this.m5c(maxPrecision), other.m5c(maxPrecision));
  }
  d(other) {
    return this.e5j(other instanceof DecimalFraction ? other : THROW_CCE());
  }
  equals(other) {
    var tmp;
    if (other instanceof DecimalFraction) {
      tmp = this.e5j(other) === 0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  toString() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    var denominator = get_POWERS_OF_TEN()[this.l5c_1];
    this_0.fh(this.k5c_1 / denominator | 0);
    this_0.ub(_Char___init__impl__6a9atx(46));
    this_0.tb(removePrefix((denominator + (this.k5c_1 % denominator | 0) | 0).toString(), '1'));
    return this_0.toString();
  }
  hashCode() {
    throw UnsupportedOperationException.da('DecimalFraction is not supposed to be used as a hash key');
  }
}
class TimeBasedDateTimeUnitSerializer {
  constructor() {
    TimeBasedDateTimeUnitSerializer_instance = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.f5j_1 = lazy_0(tmp_0, TimeBasedDateTimeUnitSerializer$descriptor$delegate$lambda);
  }
  h1t() {
    var tmp0 = this.f5j_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory();
    return tmp0.n1();
  }
  g5j(encoder, value) {
    // Inline function 'kotlinx.serialization.encoding.encodeStructure' call
    var descriptor = this.h1t();
    var composite = encoder.q1x(descriptor);
    composite.c1z(TimeBasedDateTimeUnitSerializer_getInstance().h1t(), 0, value.u53_1);
    composite.r1x(descriptor);
  }
  i1t(encoder, value) {
    return this.g5j(encoder, value instanceof TimeBased ? value : THROW_CCE());
  }
  j1t(decoder) {
    var seen = {_v: false};
    var nanoseconds = {_v: new Long(0, 0)};
    // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
    var descriptor = this.h1t();
    var composite = decoder.q1x(descriptor);
    if (composite.g1y()) {
      nanoseconds._v = composite.w1x(TimeBasedDateTimeUnitSerializer_getInstance().h1t(), 0);
      seen._v = true;
    } else {
      loop: while (true) {
        var elementIndex = composite.h1y(TimeBasedDateTimeUnitSerializer_getInstance().h1t());
        switch (elementIndex) {
          case 0:
            nanoseconds._v = composite.w1x(TimeBasedDateTimeUnitSerializer_getInstance().h1t(), 0);
            seen._v = true;
            break;
          case -1:
            break loop;
          default:
            throwUnknownIndexException(elementIndex);
            break;
        }
      }
    }
    var result = Unit_instance;
    composite.r1x(descriptor);
    if (!seen._v)
      throw MissingFieldException.d1v('nanoseconds', this.h1t().k1u());
    return new TimeBased(nanoseconds._v);
  }
}
class DateBasedDateTimeUnitSerializer extends AbstractPolymorphicSerializer {
  static i5j() {
    DateBasedDateTimeUnitSerializer_instance = null;
    var $this = this.x1t();
    DateBasedDateTimeUnitSerializer_instance = $this;
    var tmp = $this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.h5j_1 = lazy_0(tmp_0, DateBasedDateTimeUnitSerializer$impl$delegate$lambda);
    return $this;
  }
  a1u(decoder, klassName) {
    return _get_impl__d88w17(this).a1u(decoder, klassName);
  }
  j5j(encoder, value) {
    return _get_impl__d88w17(this).b1u(encoder, value);
  }
  b1u(encoder, value) {
    return this.j5j(encoder, value instanceof DateBased ? value : THROW_CCE());
  }
  y1t() {
    return getKClass(DateBased);
  }
  h1t() {
    return _get_impl__d88w17(this).h1t();
  }
}
class DayBasedDateTimeUnitSerializer {
  constructor() {
    DayBasedDateTimeUnitSerializer_instance = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.k5j_1 = lazy_0(tmp_0, DayBasedDateTimeUnitSerializer$descriptor$delegate$lambda);
  }
  h1t() {
    var tmp0 = this.k5j_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory_0();
    return tmp0.n1();
  }
  l5j(encoder, value) {
    // Inline function 'kotlinx.serialization.encoding.encodeStructure' call
    var descriptor = this.h1t();
    var composite = encoder.q1x(descriptor);
    composite.b1z(DayBasedDateTimeUnitSerializer_getInstance().h1t(), 0, value.a54_1);
    composite.r1x(descriptor);
  }
  i1t(encoder, value) {
    return this.l5j(encoder, value instanceof DayBased ? value : THROW_CCE());
  }
  j1t(decoder) {
    var seen = {_v: false};
    var days = {_v: 0};
    // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
    var descriptor = this.h1t();
    var composite = decoder.q1x(descriptor);
    if (composite.g1y()) {
      days._v = composite.v1x(DayBasedDateTimeUnitSerializer_getInstance().h1t(), 0);
      seen._v = true;
    } else {
      loop: while (true) {
        var elementIndex = composite.h1y(DayBasedDateTimeUnitSerializer_getInstance().h1t());
        switch (elementIndex) {
          case 0:
            days._v = composite.v1x(DayBasedDateTimeUnitSerializer_getInstance().h1t(), 0);
            seen._v = true;
            break;
          case -1:
            break loop;
          default:
            throwUnknownIndexException(elementIndex);
            break;
        }
      }
    }
    var result = Unit_instance;
    composite.r1x(descriptor);
    if (!seen._v)
      throw MissingFieldException.d1v('days', this.h1t().k1u());
    return new DayBased(days._v);
  }
}
class MonthBasedDateTimeUnitSerializer {
  constructor() {
    MonthBasedDateTimeUnitSerializer_instance = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.m5j_1 = lazy_0(tmp_0, MonthBasedDateTimeUnitSerializer$descriptor$delegate$lambda);
  }
  h1t() {
    var tmp0 = this.m5j_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory_1();
    return tmp0.n1();
  }
  n5j(encoder, value) {
    // Inline function 'kotlinx.serialization.encoding.encodeStructure' call
    var descriptor = this.h1t();
    var composite = encoder.q1x(descriptor);
    composite.b1z(MonthBasedDateTimeUnitSerializer_getInstance().h1t(), 0, value.b54_1);
    composite.r1x(descriptor);
  }
  i1t(encoder, value) {
    return this.n5j(encoder, value instanceof MonthBased ? value : THROW_CCE());
  }
  j1t(decoder) {
    var seen = {_v: false};
    var months = {_v: 0};
    // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
    var descriptor = this.h1t();
    var composite = decoder.q1x(descriptor);
    if (composite.g1y()) {
      months._v = composite.v1x(MonthBasedDateTimeUnitSerializer_getInstance().h1t(), 0);
      seen._v = true;
    } else {
      loop: while (true) {
        var elementIndex = composite.h1y(MonthBasedDateTimeUnitSerializer_getInstance().h1t());
        switch (elementIndex) {
          case 0:
            months._v = composite.v1x(MonthBasedDateTimeUnitSerializer_getInstance().h1t(), 0);
            seen._v = true;
            break;
          case -1:
            break loop;
          default:
            throwUnknownIndexException(elementIndex);
            break;
        }
      }
    }
    var result = Unit_instance;
    composite.r1x(descriptor);
    if (!seen._v)
      throw MissingFieldException.d1v('months', this.h1t().k1u());
    return new MonthBased(months._v);
  }
}
class DateTimeUnitSerializer extends AbstractPolymorphicSerializer {
  static p5j() {
    DateTimeUnitSerializer_instance = null;
    var $this = this.x1t();
    DateTimeUnitSerializer_instance = $this;
    var tmp = $this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.o5j_1 = lazy_0(tmp_0, DateTimeUnitSerializer$impl$delegate$lambda);
    return $this;
  }
  a1u(decoder, klassName) {
    return _get_impl__d88w17_0(this).a1u(decoder, klassName);
  }
  q5j(encoder, value) {
    return _get_impl__d88w17_0(this).b1u(encoder, value);
  }
  b1u(encoder, value) {
    return this.q5j(encoder, value instanceof DateTimeUnit ? value : THROW_CCE());
  }
  y1t() {
    return getKClass(DateTimeUnit);
  }
  h1t() {
    return _get_impl__d88w17_0(this).h1t();
  }
}
class InstantIso8601Serializer {
  constructor() {
    InstantIso8601Serializer_instance = this;
    this.r5j_1 = PrimitiveSerialDescriptor('kotlinx.datetime.Instant', STRING_getInstance());
  }
  h1t() {
    return this.r5j_1;
  }
  j1t(decoder) {
    return Companion_getInstance_13().s5j(decoder.l1x());
  }
  t5j(encoder, value) {
    encoder.v1y(value.toString());
  }
  i1t(encoder, value) {
    return this.t5j(encoder, value instanceof Instant_0 ? value : THROW_CCE());
  }
}
class LocalDateIso8601Serializer {
  constructor() {
    LocalDateIso8601Serializer_instance = this;
    this.u5j_1 = PrimitiveSerialDescriptor('kotlinx.datetime.LocalDate', STRING_getInstance());
  }
  h1t() {
    return this.u5j_1;
  }
  j1t(decoder) {
    return Companion_getInstance_14().x5j(decoder.l1x());
  }
  y5j(encoder, value) {
    encoder.v1y(value.toString());
  }
  i1t(encoder, value) {
    return this.y5j(encoder, value instanceof LocalDate_0 ? value : THROW_CCE());
  }
}
class LocalTimeIso8601Serializer {
  constructor() {
    LocalTimeIso8601Serializer_instance = this;
    this.z5j_1 = PrimitiveSerialDescriptor('kotlinx.datetime.LocalTime', STRING_getInstance());
  }
  h1t() {
    return this.z5j_1;
  }
  j1t(decoder) {
    return Companion_getInstance_15().c5k(decoder.l1x());
  }
  d5k(encoder, value) {
    encoder.v1y(value.toString());
  }
  i1t(encoder, value) {
    return this.d5k(encoder, value instanceof LocalTime_0 ? value : THROW_CCE());
  }
}
class UtcOffsetSerializer {
  constructor() {
    UtcOffsetSerializer_instance = this;
    this.e5k_1 = PrimitiveSerialDescriptor('kotlinx.datetime.UtcOffset', STRING_getInstance());
  }
  h1t() {
    return this.e5k_1;
  }
  j1t(decoder) {
    return Companion_getInstance_16().g5k(decoder.l1x());
  }
  h5k(encoder, value) {
    encoder.v1y(value.toString());
  }
  i1t(encoder, value) {
    return this.h5k(encoder, value instanceof UtcOffset ? value : THROW_CCE());
  }
}
class DayOfWeek extends Enum {}
class Companion_13 {
  constructor() {
    Companion_instance_13 = this;
    var tmp = this;
    // Inline function 'kotlinx.datetime.jsTry' call
    var tmp$ret$1 = Instant.ofEpochSecond((new Long(-931914497, -750)).m4(), 999999999);
    tmp.q53_1 = new Instant_0(tmp$ret$1);
    var tmp_0 = this;
    // Inline function 'kotlinx.datetime.jsTry' call
    var tmp$ret$3 = Instant.ofEpochSecond((new Long(1151527680, 720)).m4(), 0);
    tmp_0.r53_1 = new Instant_0(tmp$ret$3);
    this.s53_1 = new Instant_0(Instant.MIN);
    this.t53_1 = new Instant_0(Instant.MAX);
  }
  p53() {
    return new Instant_0(Clock.systemUTC().instant());
  }
  i5k(input, format) {
    var tmp;
    try {
      tmp = format.b5a(input).o58();
    } catch ($p) {
      var tmp_0;
      if ($p instanceof IllegalArgumentException) {
        var e = $p;
        throw DateTimeFormatException.v54("Failed to parse an instant from '" + toString(input) + "'", e);
      } else {
        throw $p;
      }
    }
    return tmp;
  }
  s5j(input, format, $super) {
    format = format === VOID ? Formats_getInstance().v57_1 : format;
    return $super === VOID ? this.i5k(input, format) : $super.i5k.call(this, input, format);
  }
  y58(epochSeconds, nanosecondAdjustment) {
    var tmp;
    try {
      // Inline function 'kotlinx.datetime.jsTry' call
      var tmp$ret$1 = Instant.ofEpochSecond(epochSeconds.m4(), nanosecondAdjustment);
      tmp = new Instant_0(tmp$ret$1);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var e = $p;
        if (!isJodaDateTimeException(e))
          throw e;
        tmp_0 = epochSeconds.s1(new Long(0, 0)) > 0 ? this.t53_1 : this.s53_1;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
}
class Instant_0 {
  constructor(value) {
    Companion_getInstance_13();
    this.w58_1 = value;
  }
  x58() {
    return numberToLong(this.w58_1.epochSecond());
  }
  j5k() {
    return numberToInt(this.w58_1.nano());
  }
  k5k() {
    // Inline function 'kotlin.Long.times' call
    var tmp2 = this.x58().w3(toLong(1000));
    // Inline function 'kotlin.Long.plus' call
    var other = this.j5k() / 1000000 | 0;
    return tmp2.u3(toLong(other));
  }
  l5k(other) {
    return this.w58_1.compareTo(other.w58_1);
  }
  d(other) {
    return this.l5k(other instanceof Instant_0 ? other : THROW_CCE());
  }
  equals(other) {
    var tmp;
    if (this === other) {
      tmp = true;
    } else {
      var tmp_0;
      if (other instanceof Instant_0) {
        tmp_0 = this.w58_1 === other.w58_1 || this.w58_1.equals(other.w58_1);
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  hashCode() {
    return this.w58_1.hashCode();
  }
  toString() {
    return this.w58_1.toString();
  }
}
class Companion_14 {
  constructor() {
    Companion_instance_14 = this;
    this.v5j_1 = LocalDate_0.m5k(LocalDate.MIN);
    this.w5j_1 = LocalDate_0.m5k(LocalDate.MAX);
  }
  n5k(input, format) {
    var tmp;
    if (format === Formats_getInstance_0().c55()) {
      var tmp_0;
      try {
        var sanitizedInput = removeLeadingZerosFromLongYearFormLocalDate(toString(input));
        // Inline function 'kotlinx.datetime.jsTry' call
        // Inline function 'kotlin.let' call
        var p0 = LocalDate.parse(toString(sanitizedInput));
        tmp_0 = LocalDate_0.m5k(p0);
      } catch ($p) {
        var tmp_1;
        if ($p instanceof Error) {
          var e = $p;
          if (isJodaDateTimeParseException(e))
            throw DateTimeFormatException.u54(e);
          throw e;
        } else {
          throw $p;
        }
      }
      tmp = tmp_0;
    } else {
      tmp = format.b5a(input);
    }
    return tmp;
  }
  x5j(input, format, $super) {
    format = format === VOID ? getIsoDateFormat() : format;
    return $super === VOID ? this.n5k(input, format) : $super.n5k.call(this, input, format);
  }
}
class Formats_0 {
  constructor() {
    Formats_instance_0 = this;
    this.b55_1 = get_ISO_DATE_BASIC();
  }
  c55() {
    return get_ISO_DATE();
  }
}
class LocalDate_0 {
  static m5k(value) {
    Companion_getInstance_14();
    var $this = createThis(this);
    $this.q58_1 = value;
    return $this;
  }
  static j5a(year, monthNumber, dayOfMonth) {
    Companion_getInstance_14();
    var tmp;
    try {
      // Inline function 'kotlinx.datetime.jsTry' call
      tmp = LocalDate.of(year, monthNumber, dayOfMonth);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var e = $p;
        if (isJodaDateTimeException(e))
          throw IllegalArgumentException.ce(e);
        throw e;
      } else {
        throw $p;
      }
    }
    return this.m5k(tmp);
  }
  v55() {
    return this.q58_1.year();
  }
  t55() {
    return this.q58_1.monthValue();
  }
  k5a() {
    return toMonth(this.q58_1.month());
  }
  n55() {
    return this.q58_1.dayOfMonth();
  }
  l5a() {
    return toDayOfWeek(this.q58_1.dayOfWeek());
  }
  equals(other) {
    var tmp;
    if (this === other) {
      tmp = true;
    } else {
      var tmp_0;
      if (other instanceof LocalDate_0) {
        tmp_0 = this.q58_1 === other.q58_1 || this.q58_1.equals(other.q58_1);
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  hashCode() {
    return this.q58_1.hashCode();
  }
  toString() {
    return this.q58_1.toString();
  }
  o5k(other) {
    return this.q58_1.compareTo(other.q58_1);
  }
  d(other) {
    return this.o5k(other instanceof LocalDate_0 ? other : THROW_CCE());
  }
  r58() {
    return numberToInt(this.q58_1.toEpochDay());
  }
}
class Companion_15 {
  constructor() {
    Companion_instance_15 = this;
    this.a5k_1 = LocalTime_0.p5k(LocalTime.MIN);
    this.b5k_1 = LocalTime_0.p5k(LocalTime.MAX);
  }
  q5k(input, format) {
    var tmp;
    if (format === Formats_instance_1.c55()) {
      var tmp_0;
      try {
        // Inline function 'kotlinx.datetime.jsTry' call
        // Inline function 'kotlin.let' call
        var p0 = LocalTime.parse(toString(input));
        tmp_0 = LocalTime_0.p5k(p0);
      } catch ($p) {
        var tmp_1;
        if ($p instanceof Error) {
          var e = $p;
          if (isJodaDateTimeParseException(e))
            throw DateTimeFormatException.u54(e);
          throw e;
        } else {
          throw $p;
        }
      }
      tmp = tmp_0;
    } else {
      tmp = format.b5a(input);
    }
    return tmp;
  }
  c5k(input, format, $super) {
    format = format === VOID ? getIsoTimeFormat() : format;
    return $super === VOID ? this.q5k(input, format) : $super.q5k.call(this, input, format);
  }
}
class Formats_1 {
  c55() {
    return get_ISO_TIME();
  }
}
class LocalTime_0 {
  static p5k(value) {
    Companion_getInstance_15();
    var $this = createThis(this);
    $this.s58_1 = value;
    return $this;
  }
  static n5c(hour, minute, second, nanosecond) {
    Companion_getInstance_15();
    second = second === VOID ? 0 : second;
    nanosecond = nanosecond === VOID ? 0 : nanosecond;
    var tmp;
    try {
      // Inline function 'kotlinx.datetime.jsTry' call
      tmp = LocalTime.of(hour, minute, second, nanosecond);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var e = $p;
        if (isJodaDateTimeException(e))
          throw IllegalArgumentException.ce(e);
        throw e;
      } else {
        throw $p;
      }
    }
    return this.p5k(tmp);
  }
  t58() {
    return this.s58_1.toSecondOfDay();
  }
  equals(other) {
    var tmp;
    if (this === other) {
      tmp = true;
    } else {
      var tmp_0;
      if (other instanceof LocalTime_0) {
        tmp_0 = this.s58_1 === other.s58_1 || this.s58_1.equals(other.s58_1);
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  hashCode() {
    return this.s58_1.hashCode();
  }
  toString() {
    return this.s58_1.toString();
  }
  r5k(other) {
    return this.s58_1.compareTo(other.s58_1);
  }
  d(other) {
    return this.r5k(other instanceof LocalTime_0 ? other : THROW_CCE());
  }
}
class Month extends Enum {}
class Companion_16 {
  constructor() {
    Companion_instance_16 = this;
    this.f5k_1 = new UtcOffset(ZoneOffset.UTC);
  }
  s5k(input, format) {
    return format === Formats_instance_2.c55() ? parseWithFormat(input, get_isoFormat()) : format === Formats_instance_2.t5k() ? parseWithFormat(input, get_isoBasicFormat()) : format === Formats_instance_2.t57() ? parseWithFormat(input, get_fourDigitsFormat()) : format.b5a(input);
  }
  g5k(input, format, $super) {
    format = format === VOID ? getIsoUtcOffsetFormat() : format;
    return $super === VOID ? this.s5k(input, format) : $super.s5k.call(this, input, format);
  }
}
class Formats_2 {
  c55() {
    return get_ISO_OFFSET();
  }
  t5k() {
    return get_ISO_OFFSET_BASIC();
  }
  t57() {
    return get_FOUR_DIGIT_OFFSET();
  }
}
class UtcOffset {
  constructor(zoneOffset) {
    Companion_getInstance_16();
    this.u58_1 = zoneOffset;
  }
  v58() {
    return this.u58_1.totalSeconds();
  }
  hashCode() {
    return this.u58_1.hashCode();
  }
  equals(other) {
    var tmp;
    if (other instanceof UtcOffset) {
      tmp = this.u58_1 === other.u58_1 || this.u58_1.equals(other.u58_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  toString() {
    return this.u58_1.toString();
  }
}
//endregion
var System_instance;
function System_getInstance() {
  return System_instance;
}
var Companion_instance;
function Companion_getInstance() {
  return Companion_instance;
}
var Companion_instance_0;
function Companion_getInstance_0() {
  return Companion_instance_0;
}
var Companion_instance_1;
function Companion_getInstance_1() {
  return Companion_instance_1;
}
var Companion_instance_2;
function Companion_getInstance_2() {
  return Companion_instance_2;
}
var Companion_instance_3;
function Companion_getInstance_3() {
  if (Companion_instance_3 === VOID)
    new Companion_3();
  return Companion_instance_3;
}
function get_isoDayNumber(_this__u8e3s4) {
  return _this__u8e3s4.o3_1 + 1 | 0;
}
function DayOfWeek_0(isoDayNumber) {
  // Inline function 'kotlin.require' call
  if (!(1 <= isoDayNumber ? isoDayNumber <= 7 : false)) {
    var message = 'Expected ISO day-of-week number in 1..7, got ' + isoDayNumber;
    throw IllegalArgumentException.t(toString(message));
  }
  return get_entries().f1(isoDayNumber - 1 | 0);
}
function init_kotlinx_datetime_DateTimeFormatException(_this__u8e3s4) {
  captureStack(_this__u8e3s4, _this__u8e3s4.r54_1);
}
function init_kotlinx_datetime_DateTimeArithmeticException(_this__u8e3s4) {
  captureStack(_this__u8e3s4, _this__u8e3s4.y54_1);
}
function getIsoDateFormat() {
  return Formats_getInstance_0().c55();
}
function getIsoTimeFormat() {
  return Formats_instance_1.c55();
}
function Month_0(number) {
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(1 <= number ? number <= 12 : false)) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException.t(toString(message));
  }
  return get_entries_0().f1(number - 1 | 0);
}
function getIsoUtcOffsetFormat() {
  return Formats_instance_2.c55();
}
var timeZoneField;
function get_emptyDateTimeComponentsContents() {
  _init_properties_DateTimeComponents_kt__9iimb5();
  return emptyDateTimeComponentsContents;
}
var emptyDateTimeComponentsContents;
function DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda($this$Format) {
  $this$Format.d57(get_ISO_DATE());
  var tmp = [DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda];
  alternativeParsing($this$Format, tmp, DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda_0);
  $this$Format.e57();
  char($this$Format, _Char___init__impl__6a9atx(58));
  $this$Format.f57();
  char($this$Format, _Char___init__impl__6a9atx(58));
  $this$Format.g57();
  optional($this$Format, VOID, DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda_1);
  var tmp_0 = [DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda_2];
  alternativeParsing($this$Format, tmp_0, DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda_3);
  return Unit_instance;
}
function DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda($this$alternativeParsing) {
  char($this$alternativeParsing, _Char___init__impl__6a9atx(116));
  return Unit_instance;
}
function DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda_0($this$alternativeParsing) {
  char($this$alternativeParsing, _Char___init__impl__6a9atx(84));
  return Unit_instance;
}
function DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda_1($this$optional) {
  char($this$optional, _Char___init__impl__6a9atx(46));
  $this$optional.h57(1, 9);
  return Unit_instance;
}
function DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda_2($this$alternativeParsing) {
  $this$alternativeParsing.i57();
  return Unit_instance;
}
function DateTimeComponents$Formats$ISO_DATE_TIME_OFFSET$lambda$lambda_3($this$alternativeParsing) {
  $this$alternativeParsing.j57(Formats_instance_2.c55());
  return Unit_instance;
}
function DateTimeComponents$Formats$RFC_1123$lambda($this$Format) {
  var tmp = [DateTimeComponents$Formats$RFC_1123$lambda$lambda];
  alternativeParsing($this$Format, tmp, DateTimeComponents$Formats$RFC_1123$lambda$lambda_0);
  $this$Format.k57(Padding_NONE_getInstance());
  char($this$Format, _Char___init__impl__6a9atx(32));
  $this$Format.n57(Companion_getInstance_5().m57_1);
  char($this$Format, _Char___init__impl__6a9atx(32));
  $this$Format.o57();
  char($this$Format, _Char___init__impl__6a9atx(32));
  $this$Format.e57();
  char($this$Format, _Char___init__impl__6a9atx(58));
  $this$Format.f57();
  optional($this$Format, VOID, DateTimeComponents$Formats$RFC_1123$lambda$lambda_1);
  $this$Format.p57(' ');
  var tmp_0 = DateTimeComponents$Formats$RFC_1123$lambda$lambda_2;
  var tmp_1 = [tmp_0, DateTimeComponents$Formats$RFC_1123$lambda$lambda_3];
  alternativeParsing($this$Format, tmp_1, DateTimeComponents$Formats$RFC_1123$lambda$lambda_4);
  return Unit_instance;
}
function DateTimeComponents$Formats$RFC_1123$lambda$lambda($this$alternativeParsing) {
  return Unit_instance;
}
function DateTimeComponents$Formats$RFC_1123$lambda$lambda_0($this$alternativeParsing) {
  $this$alternativeParsing.s57(Companion_getInstance_6().r57_1);
  $this$alternativeParsing.p57(', ');
  return Unit_instance;
}
function DateTimeComponents$Formats$RFC_1123$lambda$lambda_1($this$optional) {
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.g57();
  return Unit_instance;
}
function DateTimeComponents$Formats$RFC_1123$lambda$lambda_2($this$alternativeParsing) {
  $this$alternativeParsing.p57('UT');
  return Unit_instance;
}
function DateTimeComponents$Formats$RFC_1123$lambda$lambda_3($this$alternativeParsing) {
  $this$alternativeParsing.p57('Z');
  return Unit_instance;
}
function DateTimeComponents$Formats$RFC_1123$lambda$lambda_4($this$alternativeParsing) {
  optional($this$alternativeParsing, 'GMT', DateTimeComponents$Formats$RFC_1123$lambda$lambda$lambda);
  return Unit_instance;
}
function DateTimeComponents$Formats$RFC_1123$lambda$lambda$lambda($this$optional) {
  $this$optional.j57(Formats_instance_2.t57());
  return Unit_instance;
}
var Companion_instance_4;
function Companion_getInstance_4() {
  return Companion_instance_4;
}
var Formats_instance;
function Formats_getInstance() {
  if (Formats_instance === VOID)
    new Formats();
  return Formats_instance;
}
function timeZoneId$factory() {
  return getPropertyCallableRef('timeZoneId', 1, KMutableProperty1, (receiver) => receiver.g55_1, (receiver, value) => {
    receiver.g55_1 = value;
    return Unit_instance;
  });
}
function year$factory($b0) {
  return getPropertyCallableRef('year', 0, KMutableProperty0, () => $b0.i55_1, (value) => {
    $b0.i55_1 = value;
    return Unit_instance;
  });
}
function monthNumber$factory($b0) {
  return getPropertyCallableRef('monthNumber', 0, KMutableProperty0, () => $b0.j55_1, (value) => {
    $b0.j55_1 = value;
    return Unit_instance;
  });
}
function dayOfMonth$factory($b0) {
  return getPropertyCallableRef('dayOfMonth', 0, KMutableProperty0, () => $b0.k55_1, (value) => {
    $b0.k55_1 = value;
    return Unit_instance;
  });
}
function dayOfYear$factory($b0) {
  return getPropertyCallableRef('dayOfYear', 0, KMutableProperty0, () => $b0.m55_1, (value) => {
    $b0.m55_1 = value;
    return Unit_instance;
  });
}
function hour$factory($b0) {
  return getPropertyCallableRef('hour', 0, KMutableProperty0, () => $b0.x55_1, (value) => {
    $b0.x55_1 = value;
    return Unit_instance;
  });
}
function hourOfAmPm$factory($b0) {
  return getPropertyCallableRef('hourOfAmPm', 0, KMutableProperty0, () => $b0.y55_1, (value) => {
    $b0.y55_1 = value;
    return Unit_instance;
  });
}
function amPm$factory($b0) {
  return getPropertyCallableRef('amPm', 0, KMutableProperty0, () => $b0.z55_1, (value) => {
    $b0.z55_1 = value;
    return Unit_instance;
  });
}
function minute$factory($b0) {
  return getPropertyCallableRef('minute', 0, KMutableProperty0, () => $b0.a56_1, (value) => {
    $b0.a56_1 = value;
    return Unit_instance;
  });
}
function second$factory($b0) {
  return getPropertyCallableRef('second', 0, KMutableProperty0, () => $b0.b56_1, (value) => {
    $b0.b56_1 = value;
    return Unit_instance;
  });
}
function isNegative$factory($b0) {
  return getPropertyCallableRef('isNegative', 0, KMutableProperty0, () => $b0.r56_1, (value) => {
    $b0.r56_1 = value;
    return Unit_instance;
  });
}
function totalHoursAbs$factory($b0) {
  return getPropertyCallableRef('totalHoursAbs', 0, KMutableProperty0, () => $b0.s56_1, (value) => {
    $b0.s56_1 = value;
    return Unit_instance;
  });
}
function minutesOfHour$factory($b0) {
  return getPropertyCallableRef('minutesOfHour', 0, KMutableProperty0, () => $b0.t56_1, (value) => {
    $b0.t56_1 = value;
    return Unit_instance;
  });
}
function secondsOfMinute$factory($b0) {
  return getPropertyCallableRef('secondsOfMinute', 0, KMutableProperty0, () => $b0.u56_1, (value) => {
    $b0.u56_1 = value;
    return Unit_instance;
  });
}
function timeZoneId$factory_0($b0) {
  return getPropertyCallableRef('timeZoneId', 0, KMutableProperty0, () => $b0.g55_1, (value) => {
    $b0.g55_1 = value;
    return Unit_instance;
  });
}
function year$factory_0() {
  return getPropertyCallableRef('year', 1, KMutableProperty1, (receiver) => receiver.v55(), (receiver, value) => receiver.u55(value));
}
function year$factory_1() {
  return getPropertyCallableRef('year', 1, KMutableProperty1, (receiver) => receiver.v55(), (receiver, value) => receiver.u55(value));
}
var properties_initialized_DateTimeComponents_kt_io5e5;
function _init_properties_DateTimeComponents_kt__9iimb5() {
  if (!properties_initialized_DateTimeComponents_kt_io5e5) {
    properties_initialized_DateTimeComponents_kt_io5e5 = true;
    timeZoneField = new GenericFieldSpec(new PropertyAccessor(timeZoneId$factory()));
    emptyDateTimeComponentsContents = new DateTimeComponentsContents();
  }
}
var Padding_NONE_instance;
var Padding_ZERO_instance;
var Padding_SPACE_instance;
var Padding_entriesInitialized;
function Padding_initEntries() {
  if (Padding_entriesInitialized)
    return Unit_instance;
  Padding_entriesInitialized = true;
  Padding_NONE_instance = new Padding('NONE', 0);
  Padding_ZERO_instance = new Padding('ZERO', 1);
  Padding_SPACE_instance = new Padding('SPACE', 2);
}
function Padding_NONE_getInstance() {
  Padding_initEntries();
  return Padding_NONE_instance;
}
function Padding_ZERO_getInstance() {
  Padding_initEntries();
  return Padding_ZERO_instance;
}
function Padding_SPACE_getInstance() {
  Padding_initEntries();
  return Padding_SPACE_instance;
}
function char(_this__u8e3s4, value) {
  return _this__u8e3s4.p57(toString_0(value));
}
function optional(_this__u8e3s4, ifZero, format) {
  ifZero = ifZero === VOID ? '' : ifZero;
  var tmp;
  if (isInterface(_this__u8e3s4, AbstractDateTimeFormatBuilder)) {
    _this__u8e3s4.h59(ifZero, typeof format === 'function' ? format : THROW_CCE());
    tmp = Unit_instance;
  } else {
    throw IllegalStateException.t4('impossible');
  }
  return tmp;
}
function alternativeParsing(_this__u8e3s4, alternativeFormats, primaryFormat) {
  var tmp;
  if (isInterface(_this__u8e3s4, AbstractDateTimeFormatBuilder)) {
    var tmp_0 = (isArray(alternativeFormats) ? alternativeFormats : THROW_CCE()).slice();
    _this__u8e3s4.g59(tmp_0, typeof primaryFormat === 'function' ? primaryFormat : THROW_CCE());
    tmp = Unit_instance;
  } else {
    throw IllegalStateException.t4('impossible');
  }
  return tmp;
}
function get_ISO_DATE() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp0 = ISO_DATE$delegate;
  // Inline function 'kotlin.getValue' call
  ISO_DATE$factory();
  return tmp0.n1();
}
var ISO_DATE$delegate;
function get_ISO_DATE_BASIC() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp0 = ISO_DATE_BASIC$delegate;
  // Inline function 'kotlin.getValue' call
  ISO_DATE_BASIC$factory();
  return tmp0.n1();
}
var ISO_DATE_BASIC$delegate;
function get_emptyIncompleteLocalDate() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  return emptyIncompleteLocalDate;
}
var emptyIncompleteLocalDate;
var Companion_instance_5;
function Companion_getInstance_5() {
  if (Companion_instance_5 === VOID)
    new Companion_5();
  return Companion_instance_5;
}
function String$toString$ref() {
  var l = (p0) => toString(p0);
  l.callableName = 'toString';
  return l;
}
var Companion_instance_6;
function Companion_getInstance_6() {
  if (Companion_instance_6 === VOID)
    new Companion_6();
  return Companion_instance_6;
}
function String$toString$ref_0() {
  var l = (p0) => toString(p0);
  l.callableName = 'toString';
  return l;
}
var Companion_instance_7;
function Companion_getInstance_7() {
  return Companion_instance_7;
}
function requireParsedField(field, name) {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  if (field == null) {
    throw DateTimeFormatException.t54('Can not create a ' + name + ' from the given input: the field ' + name + ' is missing');
  }
  return field;
}
var DateFields_instance;
function DateFields_getInstance() {
  if (DateFields_instance === VOID)
    new DateFields();
  return DateFields_instance;
}
function ISO_DATE$delegate$lambda() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp = Companion_instance_7;
  return tmp.o5a(ISO_DATE$delegate$lambda$lambda);
}
function ISO_DATE$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  $this$build.o57();
  char($this$build, _Char___init__impl__6a9atx(45));
  $this$build.m59();
  char($this$build, _Char___init__impl__6a9atx(45));
  $this$build.n59();
  return Unit_instance;
}
function ISO_DATE_BASIC$delegate$lambda() {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  var tmp = Companion_instance_7;
  return tmp.o5a(ISO_DATE_BASIC$delegate$lambda$lambda);
}
function ISO_DATE_BASIC$delegate$lambda$lambda($this$build) {
  _init_properties_LocalDateFormat_kt__k1uk9u();
  $this$build.o57();
  $this$build.m59();
  $this$build.n59();
  return Unit_instance;
}
function ISO_DATE$factory() {
  return getPropertyCallableRef('ISO_DATE', 0, KProperty0, () => get_ISO_DATE(), null);
}
function ISO_DATE_BASIC$factory() {
  return getPropertyCallableRef('ISO_DATE_BASIC', 0, KProperty0, () => get_ISO_DATE_BASIC(), null);
}
function year$factory_2() {
  return getPropertyCallableRef('year', 1, KMutableProperty1, (receiver) => receiver.v55(), (receiver, value) => receiver.u55(value));
}
function monthNumber$factory_0() {
  return getPropertyCallableRef('monthNumber', 1, KMutableProperty1, (receiver) => receiver.t55(), (receiver, value) => receiver.s55(value));
}
function dayOfMonth$factory_0() {
  return getPropertyCallableRef('dayOfMonth', 1, KMutableProperty1, (receiver) => receiver.n55(), (receiver, value) => receiver.h55(value));
}
function isoDayOfWeek$factory() {
  return getPropertyCallableRef('isoDayOfWeek', 1, KMutableProperty1, (receiver) => receiver.r55(), (receiver, value) => receiver.q55(value));
}
function dayOfYear$factory_0() {
  return getPropertyCallableRef('dayOfYear', 1, KMutableProperty1, (receiver) => receiver.p55(), (receiver, value) => receiver.o55(value));
}
var properties_initialized_LocalDateFormat_kt_fmnlhc;
function _init_properties_LocalDateFormat_kt__k1uk9u() {
  if (!properties_initialized_LocalDateFormat_kt_fmnlhc) {
    properties_initialized_LocalDateFormat_kt_fmnlhc = true;
    ISO_DATE$delegate = lazy(ISO_DATE$delegate$lambda);
    ISO_DATE_BASIC$delegate = lazy(ISO_DATE_BASIC$delegate$lambda);
    emptyIncompleteLocalDate = new IncompleteLocalDate();
  }
}
function get_ISO_TIME() {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  var tmp0 = ISO_TIME$delegate;
  // Inline function 'kotlin.getValue' call
  ISO_TIME$factory();
  return tmp0.n1();
}
var ISO_TIME$delegate;
function get_emptyIncompleteLocalTime() {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  return emptyIncompleteLocalTime;
}
var emptyIncompleteLocalTime;
var AmPmMarker_AM_instance;
var AmPmMarker_PM_instance;
var AmPmMarker_entriesInitialized;
function AmPmMarker_initEntries() {
  if (AmPmMarker_entriesInitialized)
    return Unit_instance;
  AmPmMarker_entriesInitialized = true;
  AmPmMarker_AM_instance = new AmPmMarker('AM', 0);
  AmPmMarker_PM_instance = new AmPmMarker('PM', 1);
}
var Companion_instance_8;
function Companion_getInstance_8() {
  return Companion_instance_8;
}
var Companion_instance_9;
function Companion_getInstance_9() {
  if (Companion_instance_9 === VOID)
    new Companion_9();
  return Companion_instance_9;
}
var TimeFields_instance;
function TimeFields_getInstance() {
  if (TimeFields_instance === VOID)
    new TimeFields();
  return TimeFields_instance;
}
function ISO_TIME$delegate$lambda() {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  var tmp = Companion_instance_8;
  return tmp.o5c(ISO_TIME$delegate$lambda$lambda);
}
function ISO_TIME$delegate$lambda$lambda($this$build) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  $this$build.e57();
  char($this$build, _Char___init__impl__6a9atx(58));
  $this$build.f57();
  var tmp = [ISO_TIME$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_TIME$delegate$lambda$lambda$lambda_0);
  return Unit_instance;
}
function ISO_TIME$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  return Unit_instance;
}
function ISO_TIME$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  char($this$alternativeParsing, _Char___init__impl__6a9atx(58));
  $this$alternativeParsing.g57();
  optional($this$alternativeParsing, VOID, ISO_TIME$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_TIME$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_LocalTimeFormat_kt__5i3lfh();
  char($this$optional, _Char___init__impl__6a9atx(46));
  $this$optional.h57(1, 9);
  return Unit_instance;
}
function AmPmMarker_PM_getInstance() {
  AmPmMarker_initEntries();
  return AmPmMarker_PM_instance;
}
function ISO_TIME$factory() {
  return getPropertyCallableRef('ISO_TIME', 0, KProperty0, () => get_ISO_TIME(), null);
}
function hour$factory_0() {
  return getPropertyCallableRef('hour', 1, KMutableProperty1, (receiver) => receiver.h56(), (receiver, value) => receiver.g56(value));
}
function minute$factory_0() {
  return getPropertyCallableRef('minute', 1, KMutableProperty1, (receiver) => receiver.l56(), (receiver, value) => receiver.k56(value));
}
function second$factory_0() {
  return getPropertyCallableRef('second', 1, KMutableProperty1, (receiver) => receiver.p56(), (receiver, value) => receiver.o56(value));
}
function fractionOfSecond$factory() {
  return getPropertyCallableRef('fractionOfSecond', 1, KMutableProperty1, (receiver) => receiver.f56(), (receiver, value) => receiver.e56(value));
}
function amPm$factory_0() {
  return getPropertyCallableRef('amPm', 1, KMutableProperty1, (receiver) => receiver.d56(), (receiver, value) => receiver.w55(value));
}
function hourOfAmPm$factory_0() {
  return getPropertyCallableRef('hourOfAmPm', 1, KMutableProperty1, (receiver) => receiver.j56(), (receiver, value) => receiver.i56(value));
}
var properties_initialized_LocalTimeFormat_kt_l1b0w1;
function _init_properties_LocalTimeFormat_kt__5i3lfh() {
  if (!properties_initialized_LocalTimeFormat_kt_l1b0w1) {
    properties_initialized_LocalTimeFormat_kt_l1b0w1 = true;
    ISO_TIME$delegate = lazy(ISO_TIME$delegate$lambda);
    emptyIncompleteLocalTime = new IncompleteLocalTime();
  }
}
function get_ISO_OFFSET() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp0 = ISO_OFFSET$delegate;
  // Inline function 'kotlin.getValue' call
  ISO_OFFSET$factory();
  return tmp0.n1();
}
var ISO_OFFSET$delegate;
function get_ISO_OFFSET_BASIC() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp0 = ISO_OFFSET_BASIC$delegate;
  // Inline function 'kotlin.getValue' call
  ISO_OFFSET_BASIC$factory();
  return tmp0.n1();
}
var ISO_OFFSET_BASIC$delegate;
function get_FOUR_DIGIT_OFFSET() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp0 = FOUR_DIGIT_OFFSET$delegate;
  // Inline function 'kotlin.getValue' call
  FOUR_DIGIT_OFFSET$factory();
  return tmp0.n1();
}
var FOUR_DIGIT_OFFSET$delegate;
function get_emptyIncompleteUtcOffset() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  return emptyIncompleteUtcOffset;
}
var emptyIncompleteUtcOffset;
var Companion_instance_10;
function Companion_getInstance_10() {
  return Companion_instance_10;
}
var OffsetFields_instance;
function OffsetFields_getInstance() {
  if (OffsetFields_instance === VOID)
    new OffsetFields();
  return OffsetFields_instance;
}
function ISO_OFFSET$delegate$lambda() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = Companion_instance_10;
  return tmp.i5e(ISO_OFFSET$delegate$lambda$lambda);
}
function ISO_OFFSET$delegate$lambda$lambda($this$build) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = [ISO_OFFSET$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_OFFSET$delegate$lambda$lambda$lambda_0);
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$alternativeParsing.p57('z');
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  optional($this$alternativeParsing, 'Z', ISO_OFFSET$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.i57();
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.t59();
  optional($this$optional, VOID, ISO_OFFSET$delegate$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET$delegate$lambda$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  char($this$optional, _Char___init__impl__6a9atx(58));
  $this$optional.v59();
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = Companion_instance_10;
  return tmp.i5e(ISO_OFFSET_BASIC$delegate$lambda$lambda);
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda($this$build) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = [ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda];
  alternativeParsing($this$build, tmp, ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda_0);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$alternativeParsing.p57('z');
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda_0($this$alternativeParsing) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  optional($this$alternativeParsing, 'Z', ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.i57();
  optional($this$optional, VOID, ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.t59();
  optional($this$optional, VOID, ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda$lambda);
  return Unit_instance;
}
function ISO_OFFSET_BASIC$delegate$lambda$lambda$lambda$lambda$lambda$lambda($this$optional) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$optional.v59();
  return Unit_instance;
}
function FOUR_DIGIT_OFFSET$delegate$lambda() {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  var tmp = Companion_instance_10;
  return tmp.i5e(FOUR_DIGIT_OFFSET$delegate$lambda$lambda);
}
function FOUR_DIGIT_OFFSET$delegate$lambda$lambda($this$build) {
  _init_properties_UtcOffsetFormat_kt__9r9ddw();
  $this$build.i57();
  $this$build.t59();
  return Unit_instance;
}
function ISO_OFFSET$factory() {
  return getPropertyCallableRef('ISO_OFFSET', 0, KProperty0, () => get_ISO_OFFSET(), null);
}
function ISO_OFFSET_BASIC$factory() {
  return getPropertyCallableRef('ISO_OFFSET_BASIC', 0, KProperty0, () => get_ISO_OFFSET_BASIC(), null);
}
function FOUR_DIGIT_OFFSET$factory() {
  return getPropertyCallableRef('FOUR_DIGIT_OFFSET', 0, KProperty0, () => get_FOUR_DIGIT_OFFSET(), null);
}
function totalHoursAbs$factory_0() {
  return getPropertyCallableRef('totalHoursAbs', 1, KMutableProperty1, (receiver) => receiver.b57(), (receiver, value) => receiver.a57(value));
}
function minutesOfHour$factory_0() {
  return getPropertyCallableRef('minutesOfHour', 1, KMutableProperty1, (receiver) => receiver.x56(), (receiver, value) => receiver.w56(value));
}
function secondsOfMinute$factory_0() {
  return getPropertyCallableRef('secondsOfMinute', 1, KMutableProperty1, (receiver) => receiver.z56(), (receiver, value) => receiver.y56(value));
}
function isNegative$factory_0() {
  return getPropertyCallableRef('isNegative', 1, KMutableProperty1, (receiver) => receiver.v56(), (receiver, value) => receiver.q56(value));
}
var properties_initialized_UtcOffsetFormat_kt_6y9jku;
function _init_properties_UtcOffsetFormat_kt__9r9ddw() {
  if (!properties_initialized_UtcOffsetFormat_kt_6y9jku) {
    properties_initialized_UtcOffsetFormat_kt_6y9jku = true;
    ISO_OFFSET$delegate = lazy(ISO_OFFSET$delegate$lambda);
    ISO_OFFSET_BASIC$delegate = lazy(ISO_OFFSET_BASIC$delegate$lambda);
    FOUR_DIGIT_OFFSET$delegate = lazy(FOUR_DIGIT_OFFSET$delegate$lambda);
    emptyIncompleteUtcOffset = new IncompleteUtcOffset();
  }
}
function Accessor$getterNotNull$ref($boundThis) {
  var l = (p0) => $boundThis.z5e(p0);
  l.callableName = 'getterNotNull';
  return l;
}
function Accessor$getterNotNull$ref_0($boundThis) {
  var l = (p0) => $boundThis.z5e(p0);
  l.callableName = 'getterNotNull';
  return l;
}
function getStringValue($this, target) {
  // Inline function 'kotlin.let' call
  var it = $this.y5b_1.b5f_1.z5e(target);
  var tmp0_elvis_lhs = getOrNull($this.z5b_1, it - $this.y5b_1.c5f_1 | 0);
  return tmp0_elvis_lhs == null ? 'The value ' + it + ' of ' + $this.y5b_1.e5f_1 + ' does not have a corresponding string representation' : tmp0_elvis_lhs;
}
function NamedUnsignedIntFieldFormatDirective$getStringValue$ref($boundThis) {
  var l = (p0) => getStringValue($boundThis, p0);
  l.callableName = 'getStringValue';
  return l;
}
function Accessor$getterNotNull$ref_1($boundThis) {
  var l = (p0) => $boundThis.z5e(p0);
  l.callableName = 'getterNotNull';
  return l;
}
function formatter$checkIfAllNegative(this$0, value) {
  var seenNonZero = false;
  var tmp0_iterator = this$0.y5f_1.y();
  $l$loop: while (tmp0_iterator.z()) {
    var check = tmp0_iterator.a1();
    if (check.v56().t5f(value) === true)
      seenNonZero = true;
    else if (check.o5e(value))
      continue $l$loop;
    else
      return false;
  }
  return seenNonZero;
}
function SignedFormatStructure$parser$lambda(this$0) {
  return (value, isNegative) => {
    var tmp0_iterator = this$0.y5f_1.y();
    while (tmp0_iterator.z()) {
      var field = tmp0_iterator.a1();
      var wasNegative = field.v56().t5f(value) === true;
      field.v56().k5f(value, !(isNegative === wasNegative));
    }
    return Unit_instance;
  };
}
function SignedFormatStructure$formatter$checkIfAllNegative$ref(this$0) {
  var l = (p0) => formatter$checkIfAllNegative(this$0, p0);
  l.callableName = 'checkIfAllNegative';
  return l;
}
var Companion_instance_11;
function Companion_getInstance_11() {
  return Companion_instance_11;
}
function access$_get_accessor__yxxs4k($this) {
  return $this.a5g_1;
}
function access$_get_defaultValue__8tt04b($this) {
  return $this.b5g_1;
}
function OptionalFormatStructure$parser$lambda(this$0) {
  return (it) => {
    var tmp0_iterator = this$0.e5g_1.y();
    while (tmp0_iterator.z()) {
      var field = tmp0_iterator.a1();
      // Inline function 'kotlinx.datetime.internal.format.PropertyWithDefault.assignDefault' call
      access$_get_accessor__yxxs4k(field).k5f(it, access$_get_defaultValue__8tt04b(field));
    }
    return Unit_instance;
  };
}
function Accessor$getter$ref($boundThis) {
  var l = (p0) => $boundThis.t5f(p0);
  l.callableName = 'getter';
  return l;
}
function Predicate$test$ref($boundThis) {
  var l = (p0) => $boundThis.f5g(p0);
  l.callableName = 'test';
  return l;
}
function Truth$test$ref($boundThis) {
  var l = (p0) => $boundThis.g5g(p0);
  l.callableName = 'test';
  return l;
}
function basicFormats(format) {
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList.k();
  basicFormats$_anonymous_$rec_hkf0lf(this_0, format);
  return this_0.w7();
}
function basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format) {
  if (format instanceof BasicFormatStructure) {
    $this_buildList.l(format.u5f_1);
  } else {
    if (format instanceof ConcatenatedFormatStructure) {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = format.i5a_1.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        basicFormats$_anonymous_$rec_hkf0lf($this_buildList, element);
      }
    } else {
      if (!(format instanceof ConstantFormatStructure)) {
        if (format instanceof SignedFormatStructure) {
          basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format.w5f_1);
        } else {
          if (format instanceof AlternativesParsingFormatStructure) {
            basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format.h5g_1);
            // Inline function 'kotlin.collections.forEach' call
            var _iterator__ex2g4s_0 = format.i5g_1.y();
            while (_iterator__ex2g4s_0.z()) {
              var element_0 = _iterator__ex2g4s_0.a1();
              basicFormats$_anonymous_$rec_hkf0lf($this_buildList, element_0);
            }
          } else {
            if (format instanceof OptionalFormatStructure) {
              basicFormats$_anonymous_$rec_hkf0lf($this_buildList, format.d5g_1);
            }
          }
        }
      }
    }
  }
}
function conjunctionPredicate(predicates) {
  return predicates.h1() ? Truth_instance : predicates.b1() === 1 ? single(predicates) : new ConjunctionPredicate(predicates);
}
var Truth_instance;
function Truth_getInstance() {
  return Truth_instance;
}
var ExpectedInt_instance;
function ExpectedInt_getInstance() {
  return ExpectedInt_instance;
}
function setWithoutReassigning(_this__u8e3s4, receiver, value) {
  var tmp0_elvis_lhs = _this__u8e3s4.k5f(receiver, value);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var conflictingValue = tmp;
  return new Conflicting(conflictingValue);
}
function parseAsciiInt(_this__u8e3s4, start, end) {
  var result = 0;
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var digit = charSequenceGet(_this__u8e3s4, i);
      result = imul(result, 10) + asciiDigitToInt(digit) | 0;
    }
     while (inductionVariable < end);
  return result;
}
function parseAsciiIntOrNull(_this__u8e3s4, start, end) {
  var result = 0;
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var digit = charSequenceGet(_this__u8e3s4, i);
      result = imul(result, 10) + asciiDigitToInt(digit) | 0;
      if (result < 0)
        return null;
    }
     while (inductionVariable < end);
  return result;
}
function _ParseResult___init__impl__gvz3cn(value) {
  return value;
}
function _ParseResult___get_value__impl__86mnxf($this) {
  return $this;
}
var Companion_instance_12;
function Companion_getInstance_12() {
  return Companion_instance_12;
}
function _Parser___init__impl__gdyfby(commands) {
  return commands;
}
function _get_commands__a20n1($this) {
  return $this;
}
function Parser__match_impl_nzt83d($this, input, initialContainer, startIndex) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var errors = ArrayList.k();
  // Inline function 'kotlinx.datetime.internal.format.parser.Parser.parse' call
  var parseOptions = mutableListOf([new ParserState(initialContainer, _get_commands__a20n1($this), startIndex)]);
  iterate_over_alternatives: while (true) {
    var tmp0_elvis_lhs = removeLastOrNull(parseOptions);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break iterate_over_alternatives;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var state = tmp;
    var output = state.e5i_1.c57();
    var inputPosition = state.g5i_1;
    var parserStructure = state.f5i_1;
    // Inline function 'kotlin.run' call
    $l$block: {
      var inductionVariable = 0;
      var last = parserStructure.i5i_1.b1() - 1 | 0;
      if (inductionVariable <= last)
        do {
          var ix = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlinx.datetime.internal.format.parser.ParseResult.match' call
          var this_0 = parserStructure.i5i_1.f1(ix).k5i(output, input, inputPosition);
          var tmp0_subject = _ParseResult___get_value__impl__86mnxf(this_0);
          if (typeof tmp0_subject === 'number') {
            inputPosition = _ParseResult___get_value__impl__86mnxf(this_0);
          } else {
            if (tmp0_subject instanceof ParseError) {
              var it = _ParseResult___get_value__impl__86mnxf(this_0);
              errors.l(it);
              break $l$block;
            } else {
              // Inline function 'kotlin.error' call
              var message = 'Unexpected parse result: ' + toString(_ParseResult___get_value__impl__86mnxf(this_0));
              throw IllegalStateException.t4(toString(message));
            }
          }
        }
         while (inductionVariable <= last);
      if (parserStructure.j5i_1.h1()) {
        if (false || inputPosition === charSequenceLength(input)) {
          return output;
        } else {
          var tmp_0 = inputPosition;
          var it_0 = new ParseError(tmp_0, Parser$match$lambda);
          errors.l(it_0);
        }
      } else {
        var inductionVariable_0 = parserStructure.j5i_1.b1() - 1 | 0;
        if (0 <= inductionVariable_0)
          do {
            var ix_0 = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + -1 | 0;
            parseOptions.l(new ParserState(output, parserStructure.j5i_1.f1(ix_0), inputPosition));
          }
           while (0 <= inductionVariable_0);
      }
    }
  }
  // Inline function 'kotlin.collections.sortByDescending' call
  if (errors.b1() > 1) {
    // Inline function 'kotlin.comparisons.compareByDescending' call
    var tmp_1 = Parser$match$lambda_0;
    var tmp$ret$8 = new sam$kotlin_Comparator$0(tmp_1);
    sortWith(errors, tmp$ret$8);
  }
  throw ParseException.n5i(errors);
}
function Parser__match$default_impl_x2xlti($this, input, initialContainer, startIndex, $super) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  var tmp;
  if ($super === VOID) {
    tmp = Parser__match_impl_nzt83d($this, input, initialContainer, startIndex);
  } else {
    var tmp_0 = $super;
    tmp = (tmp_0 == null ? null : new Parser(tmp_0)).o5i.call(new Parser($this), input, initialContainer, startIndex);
  }
  return tmp;
}
function Parser__toString_impl_x33iea($this) {
  return 'Parser(commands=' + $this.toString() + ')';
}
function Parser__hashCode_impl_bbxllf($this) {
  return hashCode($this);
}
function Parser__equals_impl_djxokv($this, other) {
  if (!(other instanceof Parser))
    return false;
  var tmp0_other_with_cast = other instanceof Parser ? other.h5i_1 : THROW_CCE();
  if (!equals($this, tmp0_other_with_cast))
    return false;
  return true;
}
function Parser$match$lambda() {
  return 'There is more input to consume';
}
function Parser$match$lambda_0(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = b.a5i_1;
  var tmp$ret$1 = a.a5i_1;
  return compareValues(tmp, tmp$ret$1);
}
function concat(_this__u8e3s4) {
  // Inline function 'kotlin.collections.foldRight' call
  var accumulator = new ParserStructure(emptyList(), emptyList());
  if (!_this__u8e3s4.h1()) {
    var iterator = _this__u8e3s4.i1(_this__u8e3s4.b1());
    while (iterator.p6()) {
      var tmp2 = iterator.r6();
      var acc = accumulator;
      accumulator = concat$append(tmp2, acc);
    }
  }
  var naiveParser = accumulator;
  return concat$simplify(naiveParser, emptyList());
}
function formatError(errors) {
  if (errors.b1() === 1) {
    return 'Position ' + errors.f1(0).a5i_1 + ': ' + errors.f1(0).b5i_1();
  }
  var averageMessageLength = 33;
  var tmp0_buffer = StringBuilder.xb(imul(averageMessageLength, errors.b1()));
  return joinTo(errors, tmp0_buffer, ', ', 'Errors: ', VOID, VOID, VOID, formatError$lambda).toString();
}
function concat$append(_this__u8e3s4, other) {
  var tmp;
  if (_this__u8e3s4.j5i_1.h1()) {
    tmp = new ParserStructure(plus(_this__u8e3s4.i5i_1, other.i5i_1), other.j5i_1);
  } else {
    // Inline function 'kotlin.collections.map' call
    var this_0 = _this__u8e3s4.j5i_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = concat$append(item, other);
      destination.l(tmp$ret$0);
    }
    tmp = new ParserStructure(_this__u8e3s4.i5i_1, destination);
  }
  return tmp;
}
function concat$simplify(_this__u8e3s4, unconditionalModifications) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var newOperations = ArrayList.k();
  var currentNumberSpan = null;
  var unconditionalModificationsForTails = toMutableList(unconditionalModifications);
  var tmp0_iterator = _this__u8e3s4.i5i_1.y();
  while (tmp0_iterator.z()) {
    var op = tmp0_iterator.a1();
    if (op instanceof NumberSpanParserOperation) {
      if (!(currentNumberSpan == null)) {
        currentNumberSpan.c1(op.q5i_1);
      } else {
        currentNumberSpan = toMutableList(op.q5i_1);
      }
    } else {
      if (op instanceof UnconditionalModification) {
        unconditionalModificationsForTails.l(op);
      } else {
        if (!(currentNumberSpan == null)) {
          newOperations.l(new NumberSpanParserOperation(currentNumberSpan));
          currentNumberSpan = null;
        }
        newOperations.l(op);
      }
    }
  }
  // Inline function 'kotlin.collections.flatMap' call
  var tmp0 = _this__u8e3s4.j5i_1;
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = tmp0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var simplified = concat$simplify(element, unconditionalModificationsForTails);
    var tmp;
    if (simplified.i5i_1.h1()) {
      // Inline function 'kotlin.collections.ifEmpty' call
      var this_0 = simplified.j5i_1;
      var tmp_0;
      if (this_0.h1()) {
        tmp_0 = listOf_0(simplified);
      } else {
        tmp_0 = this_0;
      }
      tmp = tmp_0;
    } else {
      tmp = listOf_0(simplified);
    }
    var list = tmp;
    addAll(destination, list);
  }
  // Inline function 'kotlin.collections.ifEmpty' call
  var tmp_1;
  if (destination.h1()) {
    tmp_1 = listOf_0(new ParserStructure(unconditionalModificationsForTails, emptyList()));
  } else {
    tmp_1 = destination;
  }
  var mergedTails = tmp_1;
  var tmp_2;
  if (currentNumberSpan == null) {
    tmp_2 = new ParserStructure(newOperations, mergedTails);
  } else {
    var tmp$ret$8;
    $l$block_0: {
      // Inline function 'kotlin.collections.none' call
      var tmp_3;
      if (isInterface(mergedTails, Collection)) {
        tmp_3 = mergedTails.h1();
      } else {
        tmp_3 = false;
      }
      if (tmp_3) {
        tmp$ret$8 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s_0 = mergedTails.y();
      while (_iterator__ex2g4s_0.z()) {
        var element_0 = _iterator__ex2g4s_0.a1();
        var tmp0_safe_receiver = firstOrNull(element_0.i5i_1);
        var tmp_4;
        if (tmp0_safe_receiver == null) {
          tmp_4 = null;
        } else {
          // Inline function 'kotlin.let' call
          tmp_4 = tmp0_safe_receiver instanceof NumberSpanParserOperation;
        }
        if (tmp_4 === true) {
          tmp$ret$8 = false;
          break $l$block_0;
        }
      }
      tmp$ret$8 = true;
    }
    if (tmp$ret$8) {
      newOperations.l(new NumberSpanParserOperation(currentNumberSpan));
      tmp_2 = new ParserStructure(newOperations, mergedTails);
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination_0 = ArrayList.x(collectionSizeOrDefault(mergedTails, 10));
      var _iterator__ex2g4s_1 = mergedTails.y();
      while (_iterator__ex2g4s_1.z()) {
        var item = _iterator__ex2g4s_1.a1();
        var firstOperation = firstOrNull(item.i5i_1);
        var tmp_5;
        if (firstOperation instanceof NumberSpanParserOperation) {
          tmp_5 = new ParserStructure(plus(listOf_0(new NumberSpanParserOperation(plus(currentNumberSpan, firstOperation.q5i_1))), drop(item.i5i_1, 1)), item.j5i_1);
        } else {
          if (firstOperation == null) {
            tmp_5 = new ParserStructure(listOf_0(new NumberSpanParserOperation(currentNumberSpan)), item.j5i_1);
          } else {
            tmp_5 = new ParserStructure(plus(listOf_0(new NumberSpanParserOperation(currentNumberSpan)), item.i5i_1), item.j5i_1);
          }
        }
        var tmp$ret$12 = tmp_5;
        destination_0.l(tmp$ret$12);
      }
      var newTails = destination_0;
      tmp_2 = new ParserStructure(newOperations, newTails);
    }
  }
  return tmp_2;
}
function formatError$lambda(it) {
  return 'position ' + it.a5i_1 + ": '" + it.b5i_1() + "'";
}
function SignedIntParser(minDigits, maxDigits, spacePadding, setter, name, plusOnExceedsWidth) {
  var parsers = mutableListOf([spaceAndZeroPaddedUnsignedInt(minDigits, maxDigits, spacePadding, setter, name, true)]);
  if (!(plusOnExceedsWidth == null)) {
    parsers.l(spaceAndZeroPaddedUnsignedInt(minDigits, plusOnExceedsWidth, spacePadding, setter, name));
    parsers.l(new ParserStructure(listOf([new PlainStringParserOperation('+'), new NumberSpanParserOperation(listOf_0(new UnsignedIntConsumer(plusOnExceedsWidth + 1 | 0, maxDigits, setter, name, false)))]), emptyList()));
  } else {
    parsers.l(spaceAndZeroPaddedUnsignedInt(minDigits, maxDigits, spacePadding, setter, name));
  }
  return new ParserStructure(emptyList(), parsers);
}
function spaceAndZeroPaddedUnsignedInt(minDigits, maxDigits, spacePadding, setter, name, withMinus) {
  withMinus = withMinus === VOID ? false : withMinus;
  var minNumberLength = (minDigits == null ? 1 : minDigits) + (withMinus ? 1 : 0) | 0;
  var tmp;
  if (maxDigits == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = withMinus ? maxDigits + 1 | 0 : maxDigits;
  }
  var tmp2_elvis_lhs = tmp;
  var maxNumberLength = tmp2_elvis_lhs == null ? 2147483647 : tmp2_elvis_lhs;
  var spacePadding_0 = spacePadding == null ? 0 : spacePadding;
  // Inline function 'kotlin.comparisons.minOf' call
  var maxPaddedNumberLength = Math.min(maxNumberLength, spacePadding_0);
  if (minNumberLength >= maxPaddedNumberLength)
    return spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, minNumberLength, maxNumberLength);
  var accumulated = spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, minNumberLength, minNumberLength);
  var inductionVariable = minNumberLength;
  if (inductionVariable < maxPaddedNumberLength)
    do {
      var accumulatedWidth = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      accumulated = new ParserStructure(emptyList(), listOf([spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, accumulatedWidth + 1 | 0, accumulatedWidth + 1 | 0), concat(listOf([new ParserStructure(listOf_0(new PlainStringParserOperation(' ')), emptyList()), accumulated]))]));
    }
     while (inductionVariable < maxPaddedNumberLength);
  var tmp_0;
  if (spacePadding_0 > maxNumberLength) {
    var prepadding = new PlainStringParserOperation(repeat(' ', spacePadding_0 - maxNumberLength | 0));
    tmp_0 = concat(listOf([new ParserStructure(listOf_0(prepadding), emptyList()), accumulated]));
  } else if (spacePadding_0 === maxNumberLength) {
    tmp_0 = accumulated;
  } else {
    var r = new ParserStructure(emptyList(), listOf([spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths(withMinus, setter, name, spacePadding_0 + 1 | 0, maxNumberLength), accumulated]));
    tmp_0 = r;
  }
  return tmp_0;
}
function _init_$reduceTrie(trie) {
  var tmp0_iterator = trie.t5i_1.y();
  while (tmp0_iterator.z()) {
    var child = tmp0_iterator.a1().ul();
    _init_$reduceTrie(child);
  }
  // Inline function 'kotlin.collections.mutableListOf' call
  var newChildren = ArrayList.k();
  var tmp2_iterator = trie.t5i_1.y();
  while (tmp2_iterator.z()) {
    var tmp3_loop_parameter = tmp2_iterator.a1();
    var key = tmp3_loop_parameter.tl();
    var child_0 = tmp3_loop_parameter.ul();
    if (!child_0.u5i_1 && child_0.t5i_1.b1() === 1) {
      var tmp4_container = single(child_0.t5i_1);
      var grandChildKey = tmp4_container.tl();
      var grandChild = tmp4_container.ul();
      newChildren.l(to(key + grandChildKey, grandChild));
    } else {
      newChildren.l(to(key, child_0));
    }
  }
  trie.t5i_1.b3();
  // Inline function 'kotlin.collections.sortedBy' call
  // Inline function 'kotlin.comparisons.compareBy' call
  var tmp = StringSetParserOperation$reduceTrie$lambda;
  var tmp$ret$1 = new sam$kotlin_Comparator$0_0(tmp);
  var tmp$ret$2 = sortedWith(newChildren, tmp$ret$1);
  trie.t5i_1.c1(tmp$ret$2);
}
function StringSetParserOperation$lambda($key) {
  return (it) => {
    var tmp$ret$0 = it.rl_1;
    return compareValues(tmp$ret$0, $key);
  };
}
function StringSetParserOperation$consume$lambda(this$0, $input, $startIndex, $index) {
  return () => {
    var tmp0 = $input;
    var tmp1 = $startIndex;
    // Inline function 'kotlin.text.substring' call
    var endIndex = $index._v;
    var tmp$ret$0 = toString(charSequenceSubSequence(tmp0, tmp1, endIndex));
    return 'Expected ' + this$0.x5i_1 + ' but got ' + tmp$ret$0;
  };
}
function StringSetParserOperation$reduceTrie$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = a.rl_1;
  var tmp$ret$1 = b.rl_1;
  return compareValues(tmp, tmp$ret$1);
}
function _get_whatThisExpects__4pg11j($this) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = $this.q5i_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var length = item.a();
    var tmp$ret$0 = (length == null ? 'at least one digit' : '' + length + ' digits') + (' for ' + item.k5h_1);
    destination.l(tmp$ret$0);
  }
  var consumerLengths = destination;
  var tmp;
  if ($this.s5i_1) {
    tmp = 'a number with at least ' + $this.r5i_1 + ' digits: ' + toString(consumerLengths);
  } else {
    tmp = 'a number with exactly ' + $this.r5i_1 + ' digits: ' + toString(consumerLengths);
  }
  return tmp;
}
function NumberSpanParserOperation$consume$lambda(this$0) {
  return () => 'Unexpected end of input: yet to parse ' + _get_whatThisExpects__4pg11j(this$0);
}
function NumberSpanParserOperation$consume$lambda_0($digitsInRow, this$0) {
  return () => 'Only found ' + $digitsInRow._v + ' digits in a row, but need to parse ' + _get_whatThisExpects__4pg11j(this$0);
}
function NumberSpanParserOperation$consume$lambda_1($numberString, this$0, $i, $error) {
  return () => "Can not interpret the string '" + $numberString + "' as " + this$0.q5i_1.f1($i).k5h_1 + ': ' + $error.p5h();
}
function PlainStringParserOperation$consume$lambda(this$0) {
  return () => "Unexpected end of input: yet to parse '" + this$0.z5i_1 + "'";
}
function PlainStringParserOperation$consume$lambda_0(this$0, $input, $startIndex, $i) {
  return () => {
    var tmp0 = $input;
    var tmp1 = $startIndex;
    // Inline function 'kotlin.text.substring' call
    var endIndex = ($startIndex + $i | 0) + 1 | 0;
    var tmp$ret$0 = toString(charSequenceSubSequence(tmp0, tmp1, endIndex));
    return 'Expected ' + this$0.z5i_1 + ' but got ' + tmp$ret$0;
  };
}
function SignParser$consume$lambda(this$0, $char) {
  return () => 'Expected ' + this$0.c5j_1 + ' but got ' + toString_0($char);
}
function setWithoutReassigning_0(_this__u8e3s4, receiver, value, position, nextIndex) {
  var conflictingValue = _this__u8e3s4.k5f(receiver, value);
  var tmp;
  if (conflictingValue === null) {
    tmp = Companion_instance_12.c5i(nextIndex);
  } else {
    var tmp_0 = Companion_instance_12;
    tmp = tmp_0.d5i(position, setWithoutReassigning$lambda(conflictingValue, value, _this__u8e3s4));
  }
  return tmp;
}
function spaceAndZeroPaddedUnsignedInt$numberOfRequiredLengths($withMinus, $setter, $name, minNumberLength, maxNumberLength) {
  // Inline function 'kotlin.check' call
  if (!(maxNumberLength >= (1 + ($withMinus ? 1 : 0) | 0))) {
    throw IllegalStateException.t4('Check failed.');
  }
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList.k();
  if ($withMinus) {
    this_0.l(new PlainStringParserOperation('-'));
  }
  this_0.l(new NumberSpanParserOperation(listOf_0(new UnsignedIntConsumer(minNumberLength - ($withMinus ? 1 : 0) | 0, maxNumberLength - ($withMinus ? 1 : 0) | 0, $setter, $name, $withMinus))));
  var tmp$ret$4 = this_0.w7();
  return new ParserStructure(tmp$ret$4, emptyList());
}
function setWithoutReassigning$lambda($conflictingValue, $value, $this_setWithoutReassigning) {
  return () => "Attempting to assign conflicting values '" + toString_1($conflictingValue) + "' and '" + toString_1($value) + "' to field '" + $this_setWithoutReassigning.e44() + "'";
}
function get_POWERS_OF_TEN() {
  _init_properties_math_kt__tgcmt4();
  return POWERS_OF_TEN;
}
var POWERS_OF_TEN;
var properties_initialized_math_kt_amm9wq;
function _init_properties_math_kt__tgcmt4() {
  if (!properties_initialized_math_kt_amm9wq) {
    properties_initialized_math_kt_amm9wq = true;
    // Inline function 'kotlin.intArrayOf' call
    POWERS_OF_TEN = new Int32Array([1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000]);
  }
}
function isAsciiDigit(_this__u8e3s4) {
  return _Char___init__impl__6a9atx(48) <= _this__u8e3s4 ? _this__u8e3s4 <= _Char___init__impl__6a9atx(57) : false;
}
function asciiDigitToInt(_this__u8e3s4) {
  return Char__minus_impl_a2frrh(_this__u8e3s4, _Char___init__impl__6a9atx(48));
}
function removeLeadingZerosFromLongYearFormLocalDate(input) {
  return removeLeadingZerosFromLongYearForm(toString(input), 6);
}
function removeLeadingZerosFromLongYearForm(input, minStringLengthAfterYear) {
  var failingYearStringLength = 12;
  if (input.length < (failingYearStringLength + minStringLengthAfterYear | 0) || !contains('+-', charSequenceGet(input, 0)))
    return input;
  var yearEnd = indexOf(input, _Char___init__impl__6a9atx(45), 1);
  if (yearEnd < failingYearStringLength)
    return input;
  var leadingZeros = 0;
  while (charSequenceGet(input, 1 + leadingZeros | 0) === _Char___init__impl__6a9atx(48)) {
    leadingZeros = leadingZeros + 1 | 0;
  }
  if ((yearEnd - leadingZeros | 0) >= failingYearStringLength)
    return input;
  // Inline function 'kotlin.text.removeRange' call
  var endIndex = (yearEnd - failingYearStringLength | 0) + 2 | 0;
  return toString(removeRange(isCharSequence(input) ? input : THROW_CCE(), 1, endIndex));
}
function TimeBasedDateTimeUnitSerializer$descriptor$delegate$lambda() {
  return buildClassSerialDescriptor('kotlinx.datetime.TimeBased', [], TimeBasedDateTimeUnitSerializer$descriptor$delegate$lambda$lambda);
}
function TimeBasedDateTimeUnitSerializer$descriptor$delegate$lambda$lambda($this$buildClassSerialDescriptor) {
  // Inline function 'kotlinx.serialization.descriptors.element' call
  var elementName = 'nanoseconds';
  var annotations = emptyList();
  // Inline function 'kotlinx.serialization.serializer' call
  // Inline function 'kotlinx.serialization.internal.cast' call
  var this_0 = serializer(createKType(getKClass(Long), arrayOf([]), false));
  var descriptor = (isInterface(this_0, KSerializer) ? this_0 : THROW_CCE()).h1t();
  $this$buildClassSerialDescriptor.m1w(elementName, descriptor, annotations, false);
  return Unit_instance;
}
var TimeBasedDateTimeUnitSerializer_instance;
function TimeBasedDateTimeUnitSerializer_getInstance() {
  if (TimeBasedDateTimeUnitSerializer_instance === VOID)
    new TimeBasedDateTimeUnitSerializer();
  return TimeBasedDateTimeUnitSerializer_instance;
}
function _get_impl__d88w17($this) {
  var tmp0 = $this.h5j_1;
  // Inline function 'kotlin.getValue' call
  impl$factory();
  return tmp0.n1();
}
function DateBasedDateTimeUnitSerializer$impl$delegate$lambda() {
  var tmp = getKClass(DateBased);
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_0 = [getKClass(DayBased), getKClass(MonthBased)];
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$5 = [DayBasedDateTimeUnitSerializer_getInstance(), MonthBasedDateTimeUnitSerializer_getInstance()];
  return SealedClassSerializer.m1u('kotlinx.datetime.DateTimeUnit.DateBased', tmp, tmp_0, tmp$ret$5);
}
var DateBasedDateTimeUnitSerializer_instance;
function DateBasedDateTimeUnitSerializer_getInstance() {
  if (DateBasedDateTimeUnitSerializer_instance === VOID)
    DateBasedDateTimeUnitSerializer.i5j();
  return DateBasedDateTimeUnitSerializer_instance;
}
function DayBasedDateTimeUnitSerializer$descriptor$delegate$lambda() {
  return buildClassSerialDescriptor('kotlinx.datetime.DayBased', [], DayBasedDateTimeUnitSerializer$descriptor$delegate$lambda$lambda);
}
function DayBasedDateTimeUnitSerializer$descriptor$delegate$lambda$lambda($this$buildClassSerialDescriptor) {
  // Inline function 'kotlinx.serialization.descriptors.element' call
  var annotations = emptyList();
  // Inline function 'kotlinx.serialization.serializer' call
  // Inline function 'kotlinx.serialization.internal.cast' call
  var this_0 = serializer(createKType(PrimitiveClasses_getInstance().jg(), arrayOf([]), false));
  var descriptor = (isInterface(this_0, KSerializer) ? this_0 : THROW_CCE()).h1t();
  $this$buildClassSerialDescriptor.m1w('days', descriptor, annotations, false);
  return Unit_instance;
}
var DayBasedDateTimeUnitSerializer_instance;
function DayBasedDateTimeUnitSerializer_getInstance() {
  if (DayBasedDateTimeUnitSerializer_instance === VOID)
    new DayBasedDateTimeUnitSerializer();
  return DayBasedDateTimeUnitSerializer_instance;
}
function MonthBasedDateTimeUnitSerializer$descriptor$delegate$lambda() {
  return buildClassSerialDescriptor('kotlinx.datetime.MonthBased', [], MonthBasedDateTimeUnitSerializer$descriptor$delegate$lambda$lambda);
}
function MonthBasedDateTimeUnitSerializer$descriptor$delegate$lambda$lambda($this$buildClassSerialDescriptor) {
  // Inline function 'kotlinx.serialization.descriptors.element' call
  var annotations = emptyList();
  // Inline function 'kotlinx.serialization.serializer' call
  // Inline function 'kotlinx.serialization.internal.cast' call
  var this_0 = serializer(createKType(PrimitiveClasses_getInstance().jg(), arrayOf([]), false));
  var descriptor = (isInterface(this_0, KSerializer) ? this_0 : THROW_CCE()).h1t();
  $this$buildClassSerialDescriptor.m1w('months', descriptor, annotations, false);
  return Unit_instance;
}
var MonthBasedDateTimeUnitSerializer_instance;
function MonthBasedDateTimeUnitSerializer_getInstance() {
  if (MonthBasedDateTimeUnitSerializer_instance === VOID)
    new MonthBasedDateTimeUnitSerializer();
  return MonthBasedDateTimeUnitSerializer_instance;
}
function _get_impl__d88w17_0($this) {
  var tmp0 = $this.o5j_1;
  // Inline function 'kotlin.getValue' call
  impl$factory_0();
  return tmp0.n1();
}
function DateTimeUnitSerializer$impl$delegate$lambda() {
  var tmp = getKClass(DateTimeUnit);
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_0 = [getKClass(DayBased), getKClass(MonthBased), getKClass(TimeBased)];
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$5 = [DayBasedDateTimeUnitSerializer_getInstance(), MonthBasedDateTimeUnitSerializer_getInstance(), TimeBasedDateTimeUnitSerializer_getInstance()];
  return SealedClassSerializer.m1u('kotlinx.datetime.DateTimeUnit', tmp, tmp_0, tmp$ret$5);
}
var DateTimeUnitSerializer_instance;
function DateTimeUnitSerializer_getInstance() {
  if (DateTimeUnitSerializer_instance === VOID)
    DateTimeUnitSerializer.p5j();
  return DateTimeUnitSerializer_instance;
}
function throwUnknownIndexException(index) {
  throw SerializationException.t1u('An unknown field for index ' + index);
}
function descriptor$factory() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.h1t(), null);
}
function impl$factory() {
  return getPropertyCallableRef('impl', 1, KProperty1, (receiver) => _get_impl__d88w17(receiver), null);
}
function descriptor$factory_0() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.h1t(), null);
}
function descriptor$factory_1() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.h1t(), null);
}
function impl$factory_0() {
  return getPropertyCallableRef('impl', 1, KProperty1, (receiver) => _get_impl__d88w17_0(receiver), null);
}
var InstantIso8601Serializer_instance;
function InstantIso8601Serializer_getInstance() {
  if (InstantIso8601Serializer_instance === VOID)
    new InstantIso8601Serializer();
  return InstantIso8601Serializer_instance;
}
var LocalDateIso8601Serializer_instance;
function LocalDateIso8601Serializer_getInstance() {
  if (LocalDateIso8601Serializer_instance === VOID)
    new LocalDateIso8601Serializer();
  return LocalDateIso8601Serializer_instance;
}
var LocalTimeIso8601Serializer_instance;
function LocalTimeIso8601Serializer_getInstance() {
  if (LocalTimeIso8601Serializer_instance === VOID)
    new LocalTimeIso8601Serializer();
  return LocalTimeIso8601Serializer_instance;
}
var UtcOffsetSerializer_instance;
function UtcOffsetSerializer_getInstance() {
  if (UtcOffsetSerializer_instance === VOID)
    new UtcOffsetSerializer();
  return UtcOffsetSerializer_instance;
}
var DayOfWeek_MONDAY_instance;
var DayOfWeek_TUESDAY_instance;
var DayOfWeek_WEDNESDAY_instance;
var DayOfWeek_THURSDAY_instance;
var DayOfWeek_FRIDAY_instance;
var DayOfWeek_SATURDAY_instance;
var DayOfWeek_SUNDAY_instance;
function values() {
  return [DayOfWeek_MONDAY_getInstance(), DayOfWeek_TUESDAY_getInstance(), DayOfWeek_WEDNESDAY_getInstance(), DayOfWeek_THURSDAY_getInstance(), DayOfWeek_FRIDAY_getInstance(), DayOfWeek_SATURDAY_getInstance(), DayOfWeek_SUNDAY_getInstance()];
}
function get_entries() {
  if ($ENTRIES == null)
    $ENTRIES = enumEntries(values());
  return $ENTRIES;
}
var DayOfWeek_entriesInitialized;
function DayOfWeek_initEntries() {
  if (DayOfWeek_entriesInitialized)
    return Unit_instance;
  DayOfWeek_entriesInitialized = true;
  DayOfWeek_MONDAY_instance = new DayOfWeek('MONDAY', 0);
  DayOfWeek_TUESDAY_instance = new DayOfWeek('TUESDAY', 1);
  DayOfWeek_WEDNESDAY_instance = new DayOfWeek('WEDNESDAY', 2);
  DayOfWeek_THURSDAY_instance = new DayOfWeek('THURSDAY', 3);
  DayOfWeek_FRIDAY_instance = new DayOfWeek('FRIDAY', 4);
  DayOfWeek_SATURDAY_instance = new DayOfWeek('SATURDAY', 5);
  DayOfWeek_SUNDAY_instance = new DayOfWeek('SUNDAY', 6);
}
var $ENTRIES;
function toDayOfWeek(_this__u8e3s4) {
  return DayOfWeek_0(_this__u8e3s4.value());
}
function DayOfWeek_MONDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_MONDAY_instance;
}
function DayOfWeek_TUESDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_TUESDAY_instance;
}
function DayOfWeek_WEDNESDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_WEDNESDAY_instance;
}
function DayOfWeek_THURSDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_THURSDAY_instance;
}
function DayOfWeek_FRIDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_FRIDAY_instance;
}
function DayOfWeek_SATURDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_SATURDAY_instance;
}
function DayOfWeek_SUNDAY_getInstance() {
  DayOfWeek_initEntries();
  return DayOfWeek_SUNDAY_instance;
}
var Companion_instance_13;
function Companion_getInstance_13() {
  if (Companion_instance_13 === VOID)
    new Companion_13();
  return Companion_instance_13;
}
function isJodaDateTimeParseException(_this__u8e3s4) {
  return hasJsExceptionName(_this__u8e3s4, 'DateTimeParseException');
}
function isJodaDateTimeException(_this__u8e3s4) {
  return hasJsExceptionName(_this__u8e3s4, 'DateTimeException');
}
function isJodaArithmeticException(_this__u8e3s4) {
  return hasJsExceptionName(_this__u8e3s4, 'ArithmeticException');
}
var Companion_instance_14;
function Companion_getInstance_14() {
  if (Companion_instance_14 === VOID)
    new Companion_14();
  return Companion_instance_14;
}
var Formats_instance_0;
function Formats_getInstance_0() {
  if (Formats_instance_0 === VOID)
    new Formats_0();
  return Formats_instance_0;
}
function plus_0(_this__u8e3s4, value, unit) {
  return plusNumber(_this__u8e3s4, value, unit);
}
function plusNumber(_this__u8e3s4, value, unit) {
  var tmp;
  try {
    var tmp_0;
    if (unit instanceof DayBased) {
      // Inline function 'kotlinx.datetime.jsTry' call
      tmp_0 = _this__u8e3s4.q58_1.plusDays(numberToInt(numberToDouble(value) * unit.a54_1));
    } else {
      if (unit instanceof MonthBased) {
        // Inline function 'kotlinx.datetime.jsTry' call
        tmp_0 = _this__u8e3s4.q58_1.plusMonths(numberToInt(numberToDouble(value) * unit.b54_1));
      } else {
        noWhenBranchMatchedException();
      }
    }
    // Inline function 'kotlin.let' call
    var p0 = tmp_0;
    tmp = LocalDate_0.m5k(p0);
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var e = $p;
      if (!isJodaDateTimeException(e) && !isJodaArithmeticException(e))
        throw e;
      throw DateTimeArithmeticException.a55('The result of adding ' + toString(value) + ' of ' + toString(unit) + ' to ' + _this__u8e3s4.toString() + ' is out of LocalDate range.', e);
    } else {
      throw $p;
    }
  }
  return tmp;
}
var Companion_instance_15;
function Companion_getInstance_15() {
  if (Companion_instance_15 === VOID)
    new Companion_15();
  return Companion_instance_15;
}
var Formats_instance_1;
function Formats_getInstance_1() {
  return Formats_instance_1;
}
var Month_JANUARY_instance;
var Month_FEBRUARY_instance;
var Month_MARCH_instance;
var Month_APRIL_instance;
var Month_MAY_instance;
var Month_JUNE_instance;
var Month_JULY_instance;
var Month_AUGUST_instance;
var Month_SEPTEMBER_instance;
var Month_OCTOBER_instance;
var Month_NOVEMBER_instance;
var Month_DECEMBER_instance;
function values_0() {
  return [Month_JANUARY_getInstance(), Month_FEBRUARY_getInstance(), Month_MARCH_getInstance(), Month_APRIL_getInstance(), Month_MAY_getInstance(), Month_JUNE_getInstance(), Month_JULY_getInstance(), Month_AUGUST_getInstance(), Month_SEPTEMBER_getInstance(), Month_OCTOBER_getInstance(), Month_NOVEMBER_getInstance(), Month_DECEMBER_getInstance()];
}
function get_entries_0() {
  if ($ENTRIES_0 == null)
    $ENTRIES_0 = enumEntries(values_0());
  return $ENTRIES_0;
}
var Month_entriesInitialized;
function Month_initEntries() {
  if (Month_entriesInitialized)
    return Unit_instance;
  Month_entriesInitialized = true;
  Month_JANUARY_instance = new Month('JANUARY', 0);
  Month_FEBRUARY_instance = new Month('FEBRUARY', 1);
  Month_MARCH_instance = new Month('MARCH', 2);
  Month_APRIL_instance = new Month('APRIL', 3);
  Month_MAY_instance = new Month('MAY', 4);
  Month_JUNE_instance = new Month('JUNE', 5);
  Month_JULY_instance = new Month('JULY', 6);
  Month_AUGUST_instance = new Month('AUGUST', 7);
  Month_SEPTEMBER_instance = new Month('SEPTEMBER', 8);
  Month_OCTOBER_instance = new Month('OCTOBER', 9);
  Month_NOVEMBER_instance = new Month('NOVEMBER', 10);
  Month_DECEMBER_instance = new Month('DECEMBER', 11);
}
var $ENTRIES_0;
function toMonth(_this__u8e3s4) {
  return Month_0(_this__u8e3s4.value());
}
function Month_JANUARY_getInstance() {
  Month_initEntries();
  return Month_JANUARY_instance;
}
function Month_FEBRUARY_getInstance() {
  Month_initEntries();
  return Month_FEBRUARY_instance;
}
function Month_MARCH_getInstance() {
  Month_initEntries();
  return Month_MARCH_instance;
}
function Month_APRIL_getInstance() {
  Month_initEntries();
  return Month_APRIL_instance;
}
function Month_MAY_getInstance() {
  Month_initEntries();
  return Month_MAY_instance;
}
function Month_JUNE_getInstance() {
  Month_initEntries();
  return Month_JUNE_instance;
}
function Month_JULY_getInstance() {
  Month_initEntries();
  return Month_JULY_instance;
}
function Month_AUGUST_getInstance() {
  Month_initEntries();
  return Month_AUGUST_instance;
}
function Month_SEPTEMBER_getInstance() {
  Month_initEntries();
  return Month_SEPTEMBER_instance;
}
function Month_OCTOBER_getInstance() {
  Month_initEntries();
  return Month_OCTOBER_instance;
}
function Month_NOVEMBER_getInstance() {
  Month_initEntries();
  return Month_NOVEMBER_instance;
}
function Month_DECEMBER_getInstance() {
  Month_initEntries();
  return Month_DECEMBER_instance;
}
function get_isoFormat() {
  _init_properties_UtcOffset_kt__93zod7();
  var tmp0 = isoFormat$delegate;
  // Inline function 'kotlin.getValue' call
  isoFormat$factory();
  return tmp0.n1();
}
var isoFormat$delegate;
function get_isoBasicFormat() {
  _init_properties_UtcOffset_kt__93zod7();
  var tmp0 = isoBasicFormat$delegate;
  // Inline function 'kotlin.getValue' call
  isoBasicFormat$factory();
  return tmp0.n1();
}
var isoBasicFormat$delegate;
function get_fourDigitsFormat() {
  _init_properties_UtcOffset_kt__93zod7();
  var tmp0 = fourDigitsFormat$delegate;
  // Inline function 'kotlin.getValue' call
  fourDigitsFormat$factory();
  return tmp0.n1();
}
var fourDigitsFormat$delegate;
var Companion_instance_16;
function Companion_getInstance_16() {
  if (Companion_instance_16 === VOID)
    new Companion_16();
  return Companion_instance_16;
}
var Formats_instance_2;
function Formats_getInstance_2() {
  return Formats_instance_2;
}
function UtcOffset_0(hours, minutes, seconds) {
  hours = hours === VOID ? null : hours;
  minutes = minutes === VOID ? null : minutes;
  seconds = seconds === VOID ? null : seconds;
  _init_properties_UtcOffset_kt__93zod7();
  var tmp;
  try {
    var tmp_0;
    if (!(hours == null)) {
      // Inline function 'kotlinx.datetime.jsTry' call
      var tmp_1 = ZoneOffset;
      var tmp_2 = minutes == null ? 0 : minutes;
      var tmp$ret$1 = tmp_1.ofHoursMinutesSeconds(hours, tmp_2, seconds == null ? 0 : seconds);
      tmp_0 = new UtcOffset(tmp$ret$1);
    } else if (!(minutes == null)) {
      // Inline function 'kotlinx.datetime.jsTry' call
      var tmp_3 = ZoneOffset;
      var tmp_4 = minutes / 60 | 0;
      var tmp_5 = minutes % 60 | 0;
      var tmp$ret$3 = tmp_3.ofHoursMinutesSeconds(tmp_4, tmp_5, seconds == null ? 0 : seconds);
      tmp_0 = new UtcOffset(tmp$ret$3);
    } else {
      // Inline function 'kotlinx.datetime.jsTry' call
      var tmp_6 = ZoneOffset;
      var tmp$ret$5 = tmp_6.ofTotalSeconds(seconds == null ? 0 : seconds);
      tmp_0 = new UtcOffset(tmp$ret$5);
    }
    tmp = tmp_0;
  } catch ($p) {
    var tmp_7;
    if ($p instanceof Error) {
      var e = $p;
      var tmp_8;
      if (isJodaDateTimeException(e)) {
        throw IllegalArgumentException.ce(e);
      } else {
        throw e;
      }
    } else {
      throw $p;
    }
  }
  return tmp;
}
function parseWithFormat(input, format) {
  _init_properties_UtcOffset_kt__93zod7();
  var tmp;
  try {
    // Inline function 'kotlinx.datetime.jsTry' call
    tmp = format.parse(toString(input)).get(ChronoField.OFFSET_SECONDS);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var e = $p;
      if (isJodaDateTimeParseException(e))
        throw DateTimeFormatException.u54(e);
      if (isJodaDateTimeException(e))
        throw DateTimeFormatException.u54(e);
      throw e;
    } else {
      throw $p;
    }
  }
  return UtcOffset_0(VOID, VOID, tmp);
}
function isoFormat$delegate$lambda() {
  _init_properties_UtcOffset_kt__93zod7();
  return (new DateTimeFormatterBuilder()).parseCaseInsensitive().appendOffsetId().toFormatter(ResolverStyle.STRICT);
}
function isoBasicFormat$delegate$lambda() {
  _init_properties_UtcOffset_kt__93zod7();
  return (new DateTimeFormatterBuilder()).parseCaseInsensitive().appendOffset('+HHmmss', 'Z').toFormatter(ResolverStyle.STRICT);
}
function fourDigitsFormat$delegate$lambda() {
  _init_properties_UtcOffset_kt__93zod7();
  return (new DateTimeFormatterBuilder()).parseCaseInsensitive().appendOffset('+HHMM', '+0000').toFormatter(ResolverStyle.STRICT);
}
function isoFormat$factory() {
  return getPropertyCallableRef('isoFormat', 0, KProperty0, () => get_isoFormat(), null);
}
function isoBasicFormat$factory() {
  return getPropertyCallableRef('isoBasicFormat', 0, KProperty0, () => get_isoBasicFormat(), null);
}
function fourDigitsFormat$factory() {
  return getPropertyCallableRef('fourDigitsFormat', 0, KProperty0, () => get_fourDigitsFormat(), null);
}
var properties_initialized_UtcOffset_kt_4gxffr;
function _init_properties_UtcOffset_kt__93zod7() {
  if (!properties_initialized_UtcOffset_kt_4gxffr) {
    properties_initialized_UtcOffset_kt_4gxffr = true;
    isoFormat$delegate = lazy(isoFormat$delegate$lambda);
    isoBasicFormat$delegate = lazy(isoBasicFormat$delegate$lambda);
    fourDigitsFormat$delegate = lazy(fourDigitsFormat$delegate$lambda);
  }
}
function safeMultiply(a, b) {
  if (b.equals(new Long(-1, -1))) {
    if (a.equals(new Long(0, -2147483648))) {
      throw ArithmeticException.cf('Multiplication overflows a long: ' + a.toString() + ' * ' + b.toString());
    }
    return a.b4();
  } else if (b.equals(new Long(0, 0)))
    return new Long(0, 0);
  else if (b.equals(new Long(1, 0)))
    return a;
  var total = a.w3(b);
  if (!total.x3(b).equals(a)) {
    throw ArithmeticException.cf('Multiplication overflows a long: ' + a.toString() + ' * ' + b.toString());
  }
  return total;
}
function safeAdd(a, b) {
  var sum = a.u3(b);
  if (a.j4(sum).s1(new Long(0, 0)) < 0 && a.j4(b).s1(new Long(0, 0)) >= 0) {
    throw ArithmeticException.cf('Addition overflows a long: ' + a.toString() + ' + ' + b.toString());
  }
  return sum;
}
function safeMultiply_0(a, b) {
  // Inline function 'kotlin.Long.times' call
  var result = toLong(a).w3(toLong(b));
  if (result.s1(new Long(2147483647, 0)) > 0 || result.s1(new Long(-2147483648, -1)) < 0)
    throw ArithmeticException.cf('Multiplication overflows Int range: ' + a + ' * ' + b + '.');
  return result.x1();
}
function hasJsExceptionName(_this__u8e3s4, name) {
  // Inline function 'kotlin.js.asDynamic' call
  return _this__u8e3s4.name == name;
}
//region block: post-declaration
initMetadataForObject(System, 'System');
initMetadataForCompanion(Companion);
initMetadataForCompanion(Companion_0);
initMetadataForCompanion(Companion_1);
initMetadataForCompanion(Companion_2);
initMetadataForClass(DateTimeUnit, 'DateTimeUnit', VOID, VOID, VOID, VOID, VOID, {0: DateTimeUnitSerializer_getInstance});
initMetadataForClass(TimeBased, 'TimeBased', VOID, VOID, VOID, VOID, VOID, {0: TimeBasedDateTimeUnitSerializer_getInstance});
initMetadataForClass(DateBased, 'DateBased', VOID, VOID, VOID, VOID, VOID, {0: DateBasedDateTimeUnitSerializer_getInstance});
initMetadataForClass(DayBased, 'DayBased', VOID, VOID, VOID, VOID, VOID, {0: DayBasedDateTimeUnitSerializer_getInstance});
initMetadataForClass(MonthBased, 'MonthBased', VOID, VOID, VOID, VOID, VOID, {0: MonthBasedDateTimeUnitSerializer_getInstance});
initMetadataForCompanion(Companion_3);
initMetadataForClass(DateTimeFormatException, 'DateTimeFormatException', DateTimeFormatException.s54);
initMetadataForClass(DateTimeArithmeticException, 'DateTimeArithmeticException', DateTimeArithmeticException.z54);
initMetadataForInterface(TimeFieldContainer, 'TimeFieldContainer');
initMetadataForInterface(UtcOffsetFieldContainer, 'UtcOffsetFieldContainer');
initMetadataForClass(DateTimeComponentsContents, 'DateTimeComponentsContents', VOID, VOID, [TimeFieldContainer, UtcOffsetFieldContainer]);
initMetadataForCompanion(Companion_4);
initMetadataForObject(Formats, 'Formats');
initMetadataForClass(DateTimeComponents, 'DateTimeComponents');
initMetadataForInterface(AbstractDateTimeFormatBuilder, 'AbstractDateTimeFormatBuilder');
initMetadataForInterface(WithDate, 'WithDate');
initMetadataForInterface(AbstractWithDateBuilder, 'AbstractWithDateBuilder', VOID, VOID, [WithDate]);
initMetadataForInterface(WithTime, 'WithTime');
initMetadataForInterface(AbstractWithTimeBuilder, 'AbstractWithTimeBuilder', VOID, VOID, [WithTime]);
initMetadataForInterface(AbstractWithDateTimeBuilder, 'AbstractWithDateTimeBuilder', VOID, VOID, [AbstractWithDateBuilder, AbstractWithTimeBuilder, WithDate, WithTime]);
initMetadataForInterface(WithUtcOffset, 'WithUtcOffset');
initMetadataForInterface(AbstractWithOffsetBuilder, 'AbstractWithOffsetBuilder', VOID, VOID, [WithUtcOffset]);
protoOf(Builder).g59 = appendAlternativeParsingImpl;
protoOf(Builder).h59 = appendOptionalImpl;
protoOf(Builder).p57 = chars;
protoOf(Builder).h2o = build;
protoOf(Builder).i59 = addFormatStructureForDate;
protoOf(Builder).j59 = addFormatStructureForTime;
protoOf(Builder).k59 = year;
protoOf(Builder).o57 = year$default;
protoOf(Builder).l59 = monthNumber;
protoOf(Builder).m59 = monthNumber$default;
protoOf(Builder).n57 = monthName;
protoOf(Builder).k57 = dayOfMonth;
protoOf(Builder).n59 = dayOfMonth$default;
protoOf(Builder).s57 = dayOfWeek;
protoOf(Builder).d57 = date;
protoOf(Builder).o59 = hour;
protoOf(Builder).e57 = hour$default;
protoOf(Builder).p59 = minute;
protoOf(Builder).f57 = minute$default;
protoOf(Builder).q59 = second;
protoOf(Builder).g57 = second$default;
protoOf(Builder).h57 = secondFraction;
protoOf(Builder).r59 = offsetHours;
protoOf(Builder).i57 = offsetHours$default;
protoOf(Builder).s59 = offsetMinutesOfHour;
protoOf(Builder).t59 = offsetMinutesOfHour$default;
protoOf(Builder).u59 = offsetSecondsOfMinute;
protoOf(Builder).v59 = offsetSecondsOfMinute$default;
protoOf(Builder).j57 = offset;
initMetadataForClass(Builder, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithDateTimeBuilder, AbstractWithOffsetBuilder, WithTime, WithDate, WithUtcOffset]);
initMetadataForClass(AbstractDateTimeFormat, 'AbstractDateTimeFormat');
initMetadataForClass(DateTimeComponentsFormat, 'DateTimeComponentsFormat');
initMetadataForClass(TwoDigitNumber, 'TwoDigitNumber');
initMetadataForClass(ThreeDigitNumber, 'ThreeDigitNumber');
initMetadataForClass(Padding, 'Padding');
initMetadataForClass(IncompleteLocalDate, 'IncompleteLocalDate', IncompleteLocalDate);
initMetadataForCompanion(Companion_5);
initMetadataForClass(MonthNames, 'MonthNames');
initMetadataForCompanion(Companion_6);
initMetadataForClass(DayOfWeekNames, 'DayOfWeekNames');
initMetadataForCompanion(Companion_7);
protoOf(Builder_0).g59 = appendAlternativeParsingImpl;
protoOf(Builder_0).h59 = appendOptionalImpl;
protoOf(Builder_0).p57 = chars;
protoOf(Builder_0).h2o = build;
protoOf(Builder_0).k59 = year;
protoOf(Builder_0).o57 = year$default;
protoOf(Builder_0).l59 = monthNumber;
protoOf(Builder_0).m59 = monthNumber$default;
protoOf(Builder_0).k57 = dayOfMonth;
protoOf(Builder_0).n59 = dayOfMonth$default;
initMetadataForClass(Builder_0, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithDateBuilder]);
initMetadataForClass(LocalDateFormat, 'LocalDateFormat');
initMetadataForClass(SignedIntFieldFormatDirective, 'SignedIntFieldFormatDirective');
initMetadataForClass(YearDirective, 'YearDirective');
initMetadataForClass(UnsignedIntFieldFormatDirective, 'UnsignedIntFieldFormatDirective');
initMetadataForClass(MonthDirective, 'MonthDirective');
initMetadataForClass(NamedUnsignedIntFieldFormatDirective, 'NamedUnsignedIntFieldFormatDirective');
initMetadataForClass(MonthNameDirective, 'MonthNameDirective');
initMetadataForClass(DayDirective, 'DayDirective');
initMetadataForClass(DayOfWeekDirective, 'DayOfWeekDirective');
initMetadataForObject(DateFields, 'DateFields');
protoOf(IncompleteLocalTime).e56 = set_fractionOfSecond;
protoOf(IncompleteLocalTime).f56 = get_fractionOfSecond;
initMetadataForClass(IncompleteLocalTime, 'IncompleteLocalTime', IncompleteLocalTime, VOID, [TimeFieldContainer]);
initMetadataForClass(AmPmMarker, 'AmPmMarker');
initMetadataForCompanion(Companion_8);
protoOf(Builder_1).g59 = appendAlternativeParsingImpl;
protoOf(Builder_1).h59 = appendOptionalImpl;
protoOf(Builder_1).p57 = chars;
protoOf(Builder_1).h2o = build;
protoOf(Builder_1).o59 = hour;
protoOf(Builder_1).e57 = hour$default;
protoOf(Builder_1).p59 = minute;
protoOf(Builder_1).f57 = minute$default;
protoOf(Builder_1).q59 = second;
protoOf(Builder_1).g57 = second$default;
protoOf(Builder_1).h57 = secondFraction;
initMetadataForClass(Builder_1, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithTimeBuilder]);
initMetadataForClass(LocalTimeFormat, 'LocalTimeFormat');
initMetadataForClass(HourDirective, 'HourDirective');
initMetadataForClass(MinuteDirective, 'MinuteDirective');
initMetadataForClass(SecondDirective, 'SecondDirective');
initMetadataForCompanion(Companion_9);
initMetadataForClass(DecimalFractionFieldFormatDirective, 'DecimalFractionFieldFormatDirective');
initMetadataForClass(FractionalSecondDirective, 'FractionalSecondDirective');
initMetadataForObject(TimeFields, 'TimeFields');
initMetadataForClass(IncompleteUtcOffset, 'IncompleteUtcOffset', IncompleteUtcOffset, VOID, [UtcOffsetFieldContainer]);
initMetadataForClass(UtcOffsetWholeHoursDirective, 'UtcOffsetWholeHoursDirective');
initMetadataForCompanion(Companion_10);
protoOf(Builder_2).g59 = appendAlternativeParsingImpl;
protoOf(Builder_2).h59 = appendOptionalImpl;
protoOf(Builder_2).p57 = chars;
protoOf(Builder_2).h2o = build;
protoOf(Builder_2).r59 = offsetHours;
protoOf(Builder_2).i57 = offsetHours$default;
protoOf(Builder_2).s59 = offsetMinutesOfHour;
protoOf(Builder_2).t59 = offsetMinutesOfHour$default;
protoOf(Builder_2).u59 = offsetSecondsOfMinute;
protoOf(Builder_2).v59 = offsetSecondsOfMinute$default;
initMetadataForClass(Builder_2, 'Builder', VOID, VOID, [AbstractDateTimeFormatBuilder, AbstractWithOffsetBuilder]);
initMetadataForClass(UtcOffsetFormat, 'UtcOffsetFormat');
initMetadataForClass(OffsetFields$sign$1);
initMetadataForObject(OffsetFields, 'OffsetFields');
initMetadataForClass(UtcOffsetMinuteOfHourDirective, 'UtcOffsetMinuteOfHourDirective');
initMetadataForClass(UtcOffsetSecondOfMinuteDirective, 'UtcOffsetSecondOfMinuteDirective');
initMetadataForClass(AppendableFormatStructure, 'AppendableFormatStructure', AppendableFormatStructure);
initMetadataForClass(AssignableString, 'AssignableString');
initMetadataForClass(AbstractFieldSpec, 'AbstractFieldSpec');
initMetadataForClass(GenericFieldSpec, 'GenericFieldSpec');
initMetadataForInterface(Accessor, 'Accessor');
protoOf(PropertyAccessor).z5e = getterNotNull;
initMetadataForClass(PropertyAccessor, 'PropertyAccessor', VOID, VOID, [Accessor]);
initMetadataForClass(UnsignedFieldSpec, 'UnsignedFieldSpec');
initMetadataForClass(ConcatenatedFormatStructure, 'ConcatenatedFormatStructure');
initMetadataForClass(CachedFormatStructure, 'CachedFormatStructure');
initMetadataForInterface(NonConcatenatedFormatStructure, 'NonConcatenatedFormatStructure');
initMetadataForClass(BasicFormatStructure, 'BasicFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(ConstantFormatStructure, 'ConstantFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(SignedFormatStructure, 'SignedFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForCompanion(Companion_11);
initMetadataForClass(PropertyWithDefault, 'PropertyWithDefault');
initMetadataForClass(OptionalFormatStructure, 'OptionalFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(AlternativesParsingFormatStructure, 'AlternativesParsingFormatStructure', VOID, VOID, [NonConcatenatedFormatStructure]);
initMetadataForClass(ComparisonPredicate, 'ComparisonPredicate');
initMetadataForObject(Truth, 'Truth');
initMetadataForClass(ConjunctionPredicate, 'ConjunctionPredicate');
initMetadataForClass(SpacePaddedFormatter, 'SpacePaddedFormatter');
initMetadataForClass(SignedFormatter, 'SignedFormatter');
initMetadataForClass(ConditionalFormatter, 'ConditionalFormatter');
initMetadataForClass(ConcatenatedFormatter, 'ConcatenatedFormatter');
initMetadataForClass(SignedIntFormatterStructure, 'SignedIntFormatterStructure');
initMetadataForClass(UnsignedIntFormatterStructure, 'UnsignedIntFormatterStructure');
initMetadataForClass(StringFormatterStructure, 'StringFormatterStructure');
initMetadataForClass(DecimalFractionFormatterStructure, 'DecimalFractionFormatterStructure');
initMetadataForClass(ConstantStringFormatterStructure, 'ConstantStringFormatterStructure');
initMetadataForClass(NumberConsumer, 'NumberConsumer');
initMetadataForClass(FractionPartConsumer, 'FractionPartConsumer');
initMetadataForClass(ConstantNumberConsumer, 'ConstantNumberConsumer');
initMetadataForObject(ExpectedInt, 'ExpectedInt');
initMetadataForClass(TooManyDigits, 'TooManyDigits');
initMetadataForClass(TooFewDigits, 'TooFewDigits');
initMetadataForClass(WrongConstant, 'WrongConstant');
initMetadataForClass(Conflicting, 'Conflicting');
initMetadataForClass(UnsignedIntConsumer, 'UnsignedIntConsumer');
initMetadataForClass(ParseError, 'ParseError');
initMetadataForCompanion(Companion_12);
initMetadataForClass(ParserState, 'ParserState');
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(Parser, 'Parser');
initMetadataForClass(ParserStructure, 'ParserStructure');
initMetadataForClass(ParseException, 'ParseException');
initMetadataForClass(TrieNode, 'TrieNode', TrieNode);
initMetadataForClass(sam$kotlin_Comparator$0_0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(StringSetParserOperation, 'StringSetParserOperation');
initMetadataForClass(NumberSpanParserOperation, 'NumberSpanParserOperation');
initMetadataForClass(PlainStringParserOperation, 'PlainStringParserOperation');
initMetadataForClass(SignParser, 'SignParser');
initMetadataForClass(UnconditionalModification, 'UnconditionalModification');
initMetadataForClass(DecimalFraction, 'DecimalFraction', VOID, VOID, [Comparable]);
initMetadataForObject(TimeBasedDateTimeUnitSerializer, 'TimeBasedDateTimeUnitSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(DateBasedDateTimeUnitSerializer, 'DateBasedDateTimeUnitSerializer');
initMetadataForObject(DayBasedDateTimeUnitSerializer, 'DayBasedDateTimeUnitSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(MonthBasedDateTimeUnitSerializer, 'MonthBasedDateTimeUnitSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(DateTimeUnitSerializer, 'DateTimeUnitSerializer');
initMetadataForObject(InstantIso8601Serializer, 'InstantIso8601Serializer', VOID, VOID, [KSerializer]);
initMetadataForObject(LocalDateIso8601Serializer, 'LocalDateIso8601Serializer', VOID, VOID, [KSerializer]);
initMetadataForObject(LocalTimeIso8601Serializer, 'LocalTimeIso8601Serializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UtcOffsetSerializer, 'UtcOffsetSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(DayOfWeek, 'DayOfWeek');
initMetadataForCompanion(Companion_13);
initMetadataForClass(Instant_0, 'Instant', VOID, VOID, [Comparable], VOID, VOID, {0: InstantIso8601Serializer_getInstance});
initMetadataForCompanion(Companion_14);
initMetadataForObject(Formats_0, 'Formats');
initMetadataForClass(LocalDate_0, 'LocalDate', VOID, VOID, [Comparable], VOID, VOID, {0: LocalDateIso8601Serializer_getInstance});
initMetadataForCompanion(Companion_15);
initMetadataForObject(Formats_1, 'Formats');
initMetadataForClass(LocalTime_0, 'LocalTime', VOID, VOID, [Comparable], VOID, VOID, {0: LocalTimeIso8601Serializer_getInstance});
initMetadataForClass(Month, 'Month');
initMetadataForCompanion(Companion_16);
initMetadataForObject(Formats_2, 'Formats');
initMetadataForClass(UtcOffset, 'UtcOffset', VOID, VOID, VOID, VOID, VOID, {0: UtcOffsetSerializer_getInstance});
//endregion
//region block: init
System_instance = new System();
Companion_instance = new Companion();
Companion_instance_0 = new Companion_0();
Companion_instance_1 = new Companion_1();
Companion_instance_2 = new Companion_2();
Companion_instance_4 = new Companion_4();
Companion_instance_7 = new Companion_7();
Companion_instance_8 = new Companion_8();
Companion_instance_10 = new Companion_10();
Companion_instance_11 = new Companion_11();
Truth_instance = new Truth();
ExpectedInt_instance = new ExpectedInt();
Companion_instance_12 = new Companion_12();
Formats_instance_1 = new Formats_1();
Formats_instance_2 = new Formats_2();
//endregion
//region block: exports
export {
  System_instance as System_instance3bcuv0kn0rmcj,
};
//endregion

//# sourceMappingURL=Kotlin-DateTime-library-kotlinx-datetime.mjs.map
