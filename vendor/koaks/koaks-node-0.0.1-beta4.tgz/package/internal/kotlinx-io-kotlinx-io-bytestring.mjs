import {
  toCharArray32huqyw9tt7kx as toCharArray,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  VOID7hggqo3abtya as VOID,
  createThis2j2avj17cvnv2 as createThis,
  copyOfRange3alro60z4hhf8 as copyOfRange,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  Unit_instance104q5opgivhr8 as Unit_instance,
  contentEquals1cdp6c846cfdi as contentEquals,
  contentHashCode25jw6rgkgywwr as contentHashCode,
  IndexOutOfBoundsException1qfr429iumro0 as IndexOutOfBoundsException,
  _UByte___init__impl__g9hnc415bxbmye0j11o as _UByte___init__impl__g9hnc4,
  _UByte___get_data__impl__jof9qrfj1ch8mjizvj as _UByte___get_data__impl__jof9qr,
  compareTo3ankvs086tmwq as compareTo,
  StringBuildermazzzhj6kkai as StringBuilder,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  Comparable198qfk8pnblz0 as Comparable,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  decodeToString1x4faah2liw2p as decodeToString,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class Companion {
  constructor() {
    Companion_instance = this;
    this.n1k_1 = ByteString.r1k(new Int8Array(0), null);
    this.o1k_1 = toCharArray('0123456789abcdef');
  }
  s1k(byteArray) {
    return ByteString.r1k(byteArray, null);
  }
}
class ByteString {
  static r1k(data, dummy) {
    Companion_getInstance();
    var $this = createThis(this);
    $this.p1k_1 = data;
    $this.q1k_1 = 0;
    return $this;
  }
  static t1k(data, startIndex, endIndex) {
    Companion_getInstance();
    startIndex = startIndex === VOID ? 0 : startIndex;
    endIndex = endIndex === VOID ? data.length : endIndex;
    return this.r1k(copyOfRange(data, startIndex, endIndex), null);
  }
  b1() {
    return this.p1k_1.length;
  }
  equals(other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof ByteString))
      THROW_CCE();
    if (!(other.p1k_1.length === this.p1k_1.length))
      return false;
    if (!(other.q1k_1 === 0) && !(this.q1k_1 === 0) && !(other.q1k_1 === this.q1k_1))
      return false;
    return contentEquals(this.p1k_1, other.p1k_1);
  }
  hashCode() {
    var hc = this.q1k_1;
    if (hc === 0) {
      hc = contentHashCode(this.p1k_1);
      this.q1k_1 = hc;
    }
    return hc;
  }
  f1(index) {
    if (index < 0 || index >= this.b1())
      throw IndexOutOfBoundsException.me('index (' + index + ') is out of byte string bounds: [0..' + this.b1() + ')');
    return this.p1k_1[index];
  }
  u1k(startIndex, endIndex) {
    var tmp;
    if (startIndex === endIndex) {
      tmp = Companion_getInstance().n1k_1;
    } else {
      tmp = ByteString.t1k(this.p1k_1, startIndex, endIndex);
    }
    return tmp;
  }
  v1k(startIndex, endIndex, $super) {
    endIndex = endIndex === VOID ? this.b1() : endIndex;
    return $super === VOID ? this.u1k(startIndex, endIndex) : $super.u1k.call(this, startIndex, endIndex);
  }
  w1k(other) {
    if (other === this)
      return 0;
    var localData = this.p1k_1;
    var otherData = other.p1k_1;
    var inductionVariable = 0;
    var tmp0 = this.b1();
    // Inline function 'kotlin.math.min' call
    var b = other.b1();
    var last = Math.min(tmp0, b);
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlin.toUByte' call
        var this_0 = localData[i];
        var tmp4 = _UByte___init__impl__g9hnc4(this_0);
        // Inline function 'kotlin.toUByte' call
        var this_1 = otherData[i];
        // Inline function 'kotlin.UByte.compareTo' call
        var other_0 = _UByte___init__impl__g9hnc4(this_1);
        // Inline function 'kotlin.UByte.toInt' call
        var tmp = _UByte___get_data__impl__jof9qr(tmp4) & 255;
        // Inline function 'kotlin.UByte.toInt' call
        var tmp$ret$4 = _UByte___get_data__impl__jof9qr(other_0) & 255;
        var cmp = compareTo(tmp, tmp$ret$4);
        if (!(cmp === 0))
          return cmp;
      }
       while (inductionVariable < last);
    return compareTo(this.b1(), other.b1());
  }
  d(other) {
    return this.w1k(other instanceof ByteString ? other : THROW_CCE());
  }
  toString() {
    if (isEmpty(this)) {
      return 'ByteString(size=0)';
    }
    var sizeStr = this.b1().toString();
    var len = (22 + sizeStr.length | 0) + imul(this.b1(), 2) | 0;
    // Inline function 'kotlin.with' call
    var $this$with = StringBuilder.xb(len);
    $this$with.tb('ByteString(size=');
    $this$with.tb(sizeStr);
    $this$with.tb(' hex=');
    var localData = this.p1k_1;
    var inductionVariable = 0;
    var last = this.b1();
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var b = localData[i];
        $this$with.ub(Companion_getInstance().o1k_1[(b >>> 4 | 0) & 15]);
        $this$with.ub(Companion_getInstance().o1k_1[b & 15]);
      }
       while (inductionVariable < last);
    return $this$with.ub(_Char___init__impl__6a9atx(41)).toString();
  }
  x1k() {
    return this.p1k_1;
  }
}
class UnsafeByteStringOperations {
  y1k(array) {
    return Companion_getInstance().s1k(array);
  }
}
//endregion
var Companion_instance;
function Companion_getInstance() {
  if (Companion_instance === VOID)
    new Companion();
  return Companion_instance;
}
function ByteString_0(bytes) {
  var tmp;
  // Inline function 'kotlin.collections.isEmpty' call
  if (bytes.length === 0) {
    tmp = Companion_getInstance().n1k_1;
  } else {
    tmp = Companion_getInstance().s1k(bytes);
  }
  return tmp;
}
function isEmpty(_this__u8e3s4) {
  return _this__u8e3s4.b1() === 0;
}
function decodeToString_0(_this__u8e3s4) {
  return decodeToString(_this__u8e3s4.x1k());
}
var UnsafeByteStringOperations_instance;
function UnsafeByteStringOperations_getInstance() {
  return UnsafeByteStringOperations_instance;
}
//region block: post-declaration
initMetadataForCompanion(Companion);
initMetadataForClass(ByteString, 'ByteString', VOID, VOID, [Comparable]);
initMetadataForObject(UnsafeByteStringOperations, 'UnsafeByteStringOperations');
//endregion
//region block: init
UnsafeByteStringOperations_instance = new UnsafeByteStringOperations();
//endregion
//region block: exports
export {
  UnsafeByteStringOperations_instance as UnsafeByteStringOperations_instance39s7tll95rf4n,
  ByteString_0 as ByteString3c9fk8lsh3lvs,
  ByteString as ByteString10sanmoo66key,
  decodeToString_0 as decodeToString2ede220pr5xir,
};
//endregion

//# sourceMappingURL=kotlinx-io-kotlinx-io-bytestring.mjs.map
