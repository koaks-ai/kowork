import {
  ChatCompletionsModel2rl4figp5zhty as ChatCompletionsModel,
  ChatCompletionsParams2phuyy1p28jz5 as ChatCompletionsParams,
  normalizeChatCompletionsUrlbu0jml6vp44x as normalizeChatCompletionsUrl,
} from './koaks-model-provider-chat-completions.mjs';
import {
  VOID7hggqo3abtya as VOID,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  toString30pk9tzaqopn as toString,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  equals2au1ep9vhcato as equals,
  Long2qws0ah9gnpki as Long,
  Unit_instance104q5opgivhr8 as Unit_instance,
} from './kotlin-kotlin-stdlib.mjs';
import {
  ModelCapabilities1z2n3zkdibnvb as ModelCapabilities,
  Companion_getInstance3ot1bqjky10hu as Companion_getInstance,
  ModelConfig4o28u6uqe7xk as ModelConfig,
  Support_Supported_getInstance2iy50h3ebt6qe as Support_Supported_getInstance,
  Support_Unsupported_getInstance2l560r5zg87nd as Support_Unsupported_getInstance,
  Support_Unknown_getInstance3blv79i14mlk4 as Support_Unknown_getInstance,
} from './koaks-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class QwenChatModel extends ChatCompletionsModel {
  constructor(config, transport, params, capabilities) {
    params = params === VOID ? new QwenParams() : params;
    capabilities = capabilities === VOID ? new ModelCapabilities() : capabilities;
    super(config, transport, Companion_getInstance().b6d_1, new ChatCompletionsParams(params.l7g_1, params.m7g_1, VOID, params.n7g_1, params.o7g_1, params.p7g_1, params.q7g_1, VOID, params.r7g_1), capabilities);
  }
}
class QwenParams {
  constructor(temperature, maxTokens, topP, stop, presencePenalty, frequencyPenalty, enableThinking) {
    temperature = temperature === VOID ? null : temperature;
    maxTokens = maxTokens === VOID ? null : maxTokens;
    topP = topP === VOID ? null : topP;
    stop = stop === VOID ? null : stop;
    presencePenalty = presencePenalty === VOID ? null : presencePenalty;
    frequencyPenalty = frequencyPenalty === VOID ? null : frequencyPenalty;
    enableThinking = enableThinking === VOID ? null : enableThinking;
    this.l7g_1 = temperature;
    this.m7g_1 = maxTokens;
    this.n7g_1 = topP;
    this.o7g_1 = stop;
    this.p7g_1 = presencePenalty;
    this.q7g_1 = frequencyPenalty;
    this.r7g_1 = enableThinking;
  }
  toString() {
    return 'QwenParams(temperature=' + this.l7g_1 + ', maxTokens=' + this.m7g_1 + ', topP=' + this.n7g_1 + ', stop=' + toString(this.o7g_1) + ', presencePenalty=' + this.p7g_1 + ', frequencyPenalty=' + this.q7g_1 + ', enableThinking=' + this.r7g_1 + ')';
  }
  hashCode() {
    var result = this.l7g_1 == null ? 0 : getNumberHashCode(this.l7g_1);
    result = imul(result, 31) + (this.m7g_1 == null ? 0 : this.m7g_1) | 0;
    result = imul(result, 31) + (this.n7g_1 == null ? 0 : getNumberHashCode(this.n7g_1)) | 0;
    result = imul(result, 31) + (this.o7g_1 == null ? 0 : hashCode(this.o7g_1)) | 0;
    result = imul(result, 31) + (this.p7g_1 == null ? 0 : getNumberHashCode(this.p7g_1)) | 0;
    result = imul(result, 31) + (this.q7g_1 == null ? 0 : getNumberHashCode(this.q7g_1)) | 0;
    result = imul(result, 31) + (this.r7g_1 == null ? 0 : getBooleanHashCode(this.r7g_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof QwenParams))
      return false;
    var tmp0_other_with_cast = other instanceof QwenParams ? other : THROW_CCE();
    if (!equals(this.l7g_1, tmp0_other_with_cast.l7g_1))
      return false;
    if (!(this.m7g_1 == tmp0_other_with_cast.m7g_1))
      return false;
    if (!equals(this.n7g_1, tmp0_other_with_cast.n7g_1))
      return false;
    if (!equals(this.o7g_1, tmp0_other_with_cast.o7g_1))
      return false;
    if (!equals(this.p7g_1, tmp0_other_with_cast.p7g_1))
      return false;
    if (!equals(this.q7g_1, tmp0_other_with_cast.q7g_1))
      return false;
    if (!(this.r7g_1 == tmp0_other_with_cast.r7g_1))
      return false;
    return true;
  }
}
class QwenConfig {
  constructor(baseUrl, apiKey, modelName) {
    this.s7g_1 = baseUrl;
    this.t7g_1 = apiKey;
    this.u7g_1 = modelName;
    this.v7g_1 = null;
    this.w7g_1 = null;
    this.x7g_1 = null;
    this.y7g_1 = null;
    this.z7g_1 = null;
    this.a7h_1 = null;
    this.b7h_1 = null;
    this.c7h_1 = new Long(60000, 0);
    this.d7h_1 = new ModelCapabilities();
  }
  h7h(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new CapabilitiesScope(this.d7h_1);
    block(this_0);
    tmp.d7h_1 = this_0.l7h();
  }
  e7h() {
    return new ModelConfig(normalizeChatCompletionsUrl(this.s7g_1), this.t7g_1, this.u7g_1, VOID, VOID, VOID, VOID, VOID, this.c7h_1);
  }
  f7h() {
    return new QwenParams(this.v7g_1, this.w7g_1, this.x7g_1, this.y7g_1, this.z7g_1, this.a7h_1, this.b7h_1);
  }
  g7h() {
    return this.d7h_1;
  }
}
class CapabilitiesScope {
  constructor(initial) {
    this.i7h_1 = initial.g5o_1.equals(Support_Supported_getInstance());
    this.j7h_1 = initial.h5o_1.equals(Support_Supported_getInstance());
    this.k7h_1 = initial.i5o_1.equals(Support_Supported_getInstance());
  }
  l7h() {
    return new ModelCapabilities(this.i7h_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), this.j7h_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.k7h_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance());
  }
}
//endregion
function qwen(_this__u8e3s4, baseUrl, apiKey, modelName, block) {
  baseUrl = baseUrl === VOID ? 'https://dashscope.aliyuncs.com/compatible-mode' : baseUrl;
  var tmp;
  if (block === VOID) {
    tmp = qwen$lambda;
  } else {
    tmp = block;
  }
  block = tmp;
  // Inline function 'kotlin.apply' call
  var this_0 = new QwenConfig(baseUrl, apiKey, modelName);
  block(this_0);
  var cfg = this_0;
  return _this__u8e3s4.z5z(new QwenChatModel(cfg.e7h(), _this__u8e3s4.b60(), cfg.f7h(), cfg.g7h()));
}
function qwen$lambda(_this__u8e3s4) {
  return Unit_instance;
}
//region block: post-declaration
initMetadataForClass(QwenChatModel, 'QwenChatModel', VOID, VOID, VOID, [1]);
initMetadataForClass(QwenParams, 'QwenParams', QwenParams);
initMetadataForClass(QwenConfig, 'QwenConfig');
initMetadataForClass(CapabilitiesScope, 'CapabilitiesScope');
//endregion
//region block: exports
export {
  qwen as qwen3m5zqusvdcxsm,
};
//endregion

//# sourceMappingURL=koaks-model-provider-qwen.mjs.map
