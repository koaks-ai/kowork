import {
  IndexOutOfBoundsException1qfr429iumro0 as IndexOutOfBoundsException,
  Long2qws0ah9gnpki as Long,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  toString1pkumu07cwy4m as toString,
  Unit_instance104q5opgivhr8 as Unit_instance,
  toShort36kaw0zjdq3ex as toShort,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  toLongw1zpgk99d84b as toLong,
  protoOf180f3jzyo7rfj as protoOf,
  StringBuildermazzzhj6kkai as StringBuilder,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  VOID7hggqo3abtya as VOID,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  AutoCloseable1l5p57f9lp7kv as AutoCloseable,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  createThis2j2avj17cvnv2 as createThis,
  arrayCopytctsywo3h7gj as arrayCopy,
  toByte4i43936u611k as toByte,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  charArray2ujmm1qusno00 as charArray,
  numberToChar93r9buh19yek as numberToChar,
  concatToString3cxf0c1gqonpo as concatToString,
  captureStack1fzi4aczwc4hg as captureStack,
  Exceptiondt2hlxn7j7vw as Exception,
} from './kotlin-kotlin-stdlib.mjs';
import { UnsafeByteStringOperations_instance39s7tll95rf4n as UnsafeByteStringOperations_instance } from './kotlinx-io-kotlinx-io-bytestring.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class Source {}
class Sink {}
function write$default(source, startIndex, endIndex, $super) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  endIndex = endIndex === VOID ? source.length : endIndex;
  var tmp;
  if ($super === VOID) {
    this.q1m(source, startIndex, endIndex);
    tmp = Unit_instance;
  } else {
    tmp = $super.q1m.call(this, source, startIndex, endIndex);
  }
  return tmp;
}
class Buffer {
  constructor() {
    this.z1k_1 = null;
    this.a1l_1 = null;
    this.b1l_1 = new Long(0, 0);
  }
  b1() {
    return this.b1l_1;
  }
  g1l() {
    return this;
  }
  h1l() {
    return this.b1().equals(new Long(0, 0));
  }
  i1l(byteCount) {
    // Inline function 'kotlin.require' call
    if (!(byteCount.s1(new Long(0, 0)) >= 0)) {
      var message = 'byteCount: ' + byteCount.toString();
      throw IllegalArgumentException.t(toString(message));
    }
    if (this.b1().s1(byteCount) < 0) {
      throw EOFException.f1l("Buffer doesn't contain required number of bytes (size: " + this.b1().toString() + ', required: ' + byteCount.toString() + ')');
    }
  }
  j1l(byteCount) {
    // Inline function 'kotlin.require' call
    if (!(byteCount.s1(new Long(0, 0)) >= 0)) {
      var message = 'byteCount: ' + byteCount.toString() + ' < 0';
      throw IllegalArgumentException.t(toString(message));
    }
    return this.b1().s1(byteCount) >= 0;
  }
  k1l() {
    var tmp0_elvis_lhs = this.z1k_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throwEof(this, new Long(1, 0));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var segment = tmp;
    var segmentSize = segment.b1();
    if (segmentSize === 0) {
      this.s1l();
      return this.k1l();
    }
    var v = segment.t1l();
    this.b1l_1 = this.b1l_1.v3(new Long(1, 0));
    if (segmentSize === 1) {
      this.s1l();
    }
    return v;
  }
  u1l() {
    var tmp0_elvis_lhs = this.z1k_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throwEof(this, new Long(2, 0));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var segment = tmp;
    var segmentSize = segment.b1();
    if (segmentSize < 2) {
      this.i1l(new Long(2, 0));
      if (segmentSize === 0) {
        this.s1l();
        return this.u1l();
      }
      // Inline function 'kotlinx.io.and' call
      var tmp_0 = (this.k1l() & 255) << 8;
      // Inline function 'kotlinx.io.and' call
      var tmp$ret$1 = this.k1l() & 255;
      return toShort(tmp_0 | tmp$ret$1);
    }
    var v = segment.v1l();
    this.b1l_1 = this.b1l_1.v3(new Long(2, 0));
    if (segmentSize === 2) {
      this.s1l();
    }
    return v;
  }
  w1l() {
    return Unit_instance;
  }
  x1l(out, startIndex, endIndex) {
    checkBounds(this.b1(), startIndex, endIndex);
    if (startIndex.equals(endIndex))
      return Unit_instance;
    var currentOffset = startIndex;
    var remainingByteCount = endIndex.v3(startIndex);
    out.b1l_1 = out.b1l_1.u3(remainingByteCount);
    var s = this.z1k_1;
    while (currentOffset.s1(toLong(ensureNotNull(s).n1l_1 - s.m1l_1 | 0)) >= 0) {
      currentOffset = currentOffset.v3(toLong(s.n1l_1 - s.m1l_1 | 0));
      s = s.q1l_1;
    }
    while (remainingByteCount.s1(new Long(0, 0)) > 0) {
      var copy = ensureNotNull(s).y1l();
      copy.m1l_1 = copy.m1l_1 + currentOffset.x1() | 0;
      var tmp = copy;
      var tmp0 = copy.m1l_1 + remainingByteCount.x1() | 0;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = copy.n1l_1;
      tmp.n1l_1 = Math.min(tmp0, b);
      // Inline function 'kotlinx.io.Buffer.pushSegment' call
      if (out.z1k_1 == null) {
        out.z1k_1 = copy;
        out.a1l_1 = copy;
      } else if (false) {
        out.a1l_1 = ensureNotNull(out.a1l_1).z1l(copy).a1m();
        if (ensureNotNull(out.a1l_1).r1l_1 == null) {
          out.z1k_1 = out.a1l_1;
        }
      } else {
        out.a1l_1 = ensureNotNull(out.a1l_1).z1l(copy);
      }
      remainingByteCount = remainingByteCount.v3(toLong(copy.n1l_1 - copy.m1l_1 | 0));
      currentOffset = new Long(0, 0);
      s = s.q1l_1;
    }
  }
  b1m() {
    var result = this.b1();
    if (result.equals(new Long(0, 0)))
      return new Long(0, 0);
    var tail = ensureNotNull(this.a1l_1);
    if (tail.n1l_1 < 8192 && tail.p1l_1) {
      result = result.v3(toLong(tail.n1l_1 - tail.m1l_1 | 0));
    }
    return result;
  }
  c1m(position) {
    if (position.s1(new Long(0, 0)) < 0 || position.s1(this.b1()) >= 0) {
      throw IndexOutOfBoundsException.me('position (' + position.toString() + ') is not within the range [0..size(' + this.b1().toString() + '))');
    }
    if (position.equals(new Long(0, 0))) {
      return ensureNotNull(this.z1k_1).d1m(0);
    }
    // Inline function 'kotlinx.io.seek' call
    if (this.z1k_1 == null) {
      var offset = new Long(-1, -1);
      return ensureNotNull(null).d1m(position.v3(offset).x1());
    }
    if (this.b1().v3(position).s1(position) < 0) {
      var s = this.a1l_1;
      var offset_0 = this.b1();
      $l$loop: while (!(s == null) && offset_0.s1(position) > 0) {
        offset_0 = offset_0.v3(toLong(s.n1l_1 - s.m1l_1 | 0));
        if (offset_0.s1(position) <= 0)
          break $l$loop;
        s = s.r1l_1;
      }
      var tmp4 = s;
      var offset_1 = offset_0;
      return ensureNotNull(tmp4).d1m(position.v3(offset_1).x1());
    } else {
      var s_0 = this.z1k_1;
      var offset_2 = new Long(0, 0);
      $l$loop_0: while (!(s_0 == null)) {
        var tmp0 = offset_2;
        // Inline function 'kotlin.Long.plus' call
        var other = s_0.n1l_1 - s_0.m1l_1 | 0;
        var nextOffset = tmp0.u3(toLong(other));
        if (nextOffset.s1(position) > 0)
          break $l$loop_0;
        s_0 = s_0.q1l_1;
        offset_2 = nextOffset;
      }
      var tmp6 = s_0;
      var offset_3 = offset_2;
      return ensureNotNull(tmp6).d1m(position.v3(offset_3).x1());
    }
  }
  b3() {
    return this.e1m(this.b1());
  }
  e1m(byteCount) {
    // Inline function 'kotlinx.io.checkByteCount' call
    // Inline function 'kotlin.require' call
    if (!(byteCount.s1(new Long(0, 0)) >= 0)) {
      var message = 'byteCount (' + byteCount.toString() + ') < 0';
      throw IllegalArgumentException.t(toString(message));
    }
    var remainingByteCount = byteCount;
    while (remainingByteCount.s1(new Long(0, 0)) > 0) {
      var tmp0_elvis_lhs = this.z1k_1;
      var tmp;
      if (tmp0_elvis_lhs == null) {
        throw EOFException.f1l('Buffer exhausted before skipping ' + byteCount.toString() + ' bytes.');
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var head = tmp;
      var tmp1 = remainingByteCount;
      // Inline function 'kotlinx.io.minOf' call
      var b = head.n1l_1 - head.m1l_1 | 0;
      // Inline function 'kotlin.comparisons.minOf' call
      var b_0 = toLong(b);
      var toSkip = (tmp1.s1(b_0) <= 0 ? tmp1 : b_0).x1();
      this.b1l_1 = this.b1l_1.v3(toLong(toSkip));
      remainingByteCount = remainingByteCount.v3(toLong(toSkip));
      head.m1l_1 = head.m1l_1 + toSkip | 0;
      if (head.m1l_1 === head.n1l_1) {
        this.s1l();
      }
    }
  }
  f1m(sink, startIndex, endIndex) {
    // Inline function 'kotlinx.io.checkBounds' call
    var size = sink.length;
    checkBounds(toLong(size), toLong(startIndex), toLong(endIndex));
    var tmp0_elvis_lhs = this.z1k_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return -1;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var s = tmp;
    var tmp3 = endIndex - startIndex | 0;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = s.b1();
    var toCopy = Math.min(tmp3, b);
    s.g1m(sink, startIndex, startIndex + toCopy | 0);
    this.b1l_1 = this.b1l_1.v3(toLong(toCopy));
    if (isEmpty(s)) {
      this.s1l();
    }
    return toCopy;
  }
  h1m(sink, byteCount) {
    // Inline function 'kotlinx.io.checkByteCount' call
    // Inline function 'kotlin.require' call
    if (!(byteCount.s1(new Long(0, 0)) >= 0)) {
      var message = 'byteCount (' + byteCount.toString() + ') < 0';
      throw IllegalArgumentException.t(toString(message));
    }
    if (this.b1().equals(new Long(0, 0)))
      return new Long(-1, -1);
    var bytesWritten = byteCount.s1(this.b1()) > 0 ? this.b1() : byteCount;
    sink.i1m(this, bytesWritten);
    return bytesWritten;
  }
  j1m(sink, byteCount) {
    // Inline function 'kotlinx.io.checkByteCount' call
    // Inline function 'kotlin.require' call
    if (!(byteCount.s1(new Long(0, 0)) >= 0)) {
      var message = 'byteCount (' + byteCount.toString() + ') < 0';
      throw IllegalArgumentException.t(toString(message));
    }
    if (this.b1().s1(byteCount) < 0) {
      sink.i1m(this, this.b1());
      throw EOFException.f1l('Buffer exhausted before writing ' + byteCount.toString() + ' bytes. Only ' + this.b1().toString() + ' bytes were written.');
    }
    sink.i1m(this, byteCount);
  }
  k1m(sink) {
    var byteCount = this.b1();
    if (byteCount.s1(new Long(0, 0)) > 0) {
      sink.i1m(this, byteCount);
    }
    return byteCount;
  }
  l1m() {
    return buffered(new PeekSource(this));
  }
  m1m(minimumCapacity) {
    // Inline function 'kotlin.require' call
    if (!(minimumCapacity >= 1 && minimumCapacity <= 8192)) {
      var message = 'unexpected capacity (' + minimumCapacity + '), should be in range [1, 8192]';
      throw IllegalArgumentException.t(toString(message));
    }
    if (this.a1l_1 == null) {
      var result = SegmentPool_instance.p1m();
      this.z1k_1 = result;
      this.a1l_1 = result;
      return result;
    }
    var t = ensureNotNull(this.a1l_1);
    if ((t.n1l_1 + minimumCapacity | 0) > 8192 || !t.p1l_1) {
      var newTail = t.z1l(SegmentPool_instance.p1m());
      this.a1l_1 = newTail;
      return newTail;
    }
    return t;
  }
  q1m(source, startIndex, endIndex) {
    // Inline function 'kotlinx.io.checkBounds' call
    var size = source.length;
    checkBounds(toLong(size), toLong(startIndex), toLong(endIndex));
    var currentOffset = startIndex;
    while (currentOffset < endIndex) {
      var tail = this.m1m(1);
      var tmp3 = endIndex - currentOffset | 0;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = tail.r1m();
      var toCopy = Math.min(tmp3, b);
      tail.s1m(source, currentOffset, currentOffset + toCopy | 0);
      currentOffset = currentOffset + toCopy | 0;
    }
    var tmp = this;
    var tmp5 = this.b1l_1;
    // Inline function 'kotlin.Long.plus' call
    var other = endIndex - startIndex | 0;
    tmp.b1l_1 = tmp5.u3(toLong(other));
  }
  i1m(source, byteCount) {
    // Inline function 'kotlin.require' call
    if (!!(source === this)) {
      var message = 'source == this';
      throw IllegalArgumentException.t(toString(message));
    }
    checkOffsetAndCount(source.b1l_1, new Long(0, 0), byteCount);
    var remainingByteCount = byteCount;
    while (remainingByteCount.s1(new Long(0, 0)) > 0) {
      if (remainingByteCount.s1(toLong(ensureNotNull(source.z1k_1).b1())) < 0) {
        var tail = this.a1l_1;
        var tmp;
        if (!(tail == null) && tail.p1l_1) {
          var tmp1 = remainingByteCount;
          // Inline function 'kotlin.Long.plus' call
          var other = tail.n1l_1;
          var tmp3 = tmp1.u3(toLong(other));
          // Inline function 'kotlin.Long.minus' call
          var other_0 = tail.u1m() ? 0 : tail.m1l_1;
          tmp = tmp3.v3(toLong(other_0)).s1(new Long(8192, 0)) <= 0;
        } else {
          tmp = false;
        }
        if (tmp) {
          ensureNotNull(source.z1k_1).w1m(tail, remainingByteCount.x1());
          source.b1l_1 = source.b1l_1.v3(remainingByteCount);
          this.b1l_1 = this.b1l_1.u3(remainingByteCount);
          return Unit_instance;
        } else {
          source.z1k_1 = ensureNotNull(source.z1k_1).v1m(remainingByteCount.x1());
        }
      }
      var segmentToMove = ensureNotNull(source.z1k_1);
      var movedByteCount = toLong(segmentToMove.b1());
      source.z1k_1 = segmentToMove.x1m();
      if (source.z1k_1 == null) {
        source.a1l_1 = null;
      }
      // Inline function 'kotlinx.io.Buffer.pushSegment' call
      if (this.z1k_1 == null) {
        this.z1k_1 = segmentToMove;
        this.a1l_1 = segmentToMove;
      } else if (true) {
        this.a1l_1 = ensureNotNull(this.a1l_1).z1l(segmentToMove).a1m();
        if (ensureNotNull(this.a1l_1).r1l_1 == null) {
          this.z1k_1 = this.a1l_1;
        }
      } else {
        this.a1l_1 = ensureNotNull(this.a1l_1).z1l(segmentToMove);
      }
      source.b1l_1 = source.b1l_1.v3(movedByteCount);
      this.b1l_1 = this.b1l_1.u3(movedByteCount);
      remainingByteCount = remainingByteCount.v3(movedByteCount);
    }
  }
  y1m(source) {
    var totalBytesRead = new Long(0, 0);
    $l$loop: while (true) {
      var readCount = source.h1m(this, new Long(8192, 0));
      if (readCount.equals(new Long(-1, -1)))
        break $l$loop;
      totalBytesRead = totalBytesRead.u3(readCount);
    }
    return totalBytesRead;
  }
  z1m(byte) {
    this.m1m(1).a1n(byte);
    this.b1l_1 = this.b1l_1.u3(new Long(1, 0));
  }
  b1n(short) {
    this.m1m(2).c1n(short);
    this.b1l_1 = this.b1l_1.u3(new Long(2, 0));
  }
  a6() {
    return Unit_instance;
  }
  toString() {
    if (this.b1().equals(new Long(0, 0)))
      return 'Buffer(size=0)';
    var maxPrintableBytes = 64;
    // Inline function 'kotlinx.io.minOf' call
    var b = this.b1();
    // Inline function 'kotlin.comparisons.minOf' call
    var a = toLong(maxPrintableBytes);
    var len = (a.s1(b) <= 0 ? a : b).x1();
    var builder = StringBuilder.xb(imul(len, 2) + (this.b1().s1(toLong(maxPrintableBytes)) > 0 ? 1 : 0) | 0);
    var bytesWritten = 0;
    // Inline function 'kotlinx.io.unsafe.UnsafeBufferOperations.forEachSegment' call
    var curr = this.z1k_1;
    while (!(curr == null)) {
      var tmp4 = get_SegmentReadContextImpl();
      var segment = curr;
      var idx = 0;
      while (bytesWritten < len && idx < segment.b1()) {
        var _unary__edvuaz = idx;
        idx = _unary__edvuaz + 1 | 0;
        var b_0 = tmp4.d1n(segment, _unary__edvuaz);
        bytesWritten = bytesWritten + 1 | 0;
        var tmp = get_HEX_DIGIT_CHARS();
        // Inline function 'kotlinx.io.shr' call
        var tmp$ret$2 = b_0 >> 4;
        var tmp_0 = builder.ub(tmp[tmp$ret$2 & 15]);
        var tmp_1 = get_HEX_DIGIT_CHARS();
        // Inline function 'kotlinx.io.and' call
        var tmp$ret$3 = b_0 & 15;
        tmp_0.ub(tmp_1[tmp$ret$3]);
      }
      curr = curr.q1l_1;
    }
    if (this.b1().s1(toLong(maxPrintableBytes)) > 0) {
      builder.ub(_Char___init__impl__6a9atx(8230));
    }
    return 'Buffer(size=' + this.b1().toString() + ' hex=' + builder.toString() + ')';
  }
  s1l() {
    var oldHead = ensureNotNull(this.z1k_1);
    var nextHead = oldHead.q1l_1;
    this.z1k_1 = nextHead;
    if (nextHead == null) {
      this.a1l_1 = null;
    } else {
      nextHead.r1l_1 = null;
    }
    oldHead.q1l_1 = null;
    SegmentPool_instance.e1n(oldHead);
  }
  f1n() {
    var oldTail = ensureNotNull(this.a1l_1);
    var newTail = oldTail.r1l_1;
    this.a1l_1 = newTail;
    if (newTail == null) {
      this.z1k_1 = null;
    } else {
      newTail.q1l_1 = null;
    }
    oldTail.r1l_1 = null;
    SegmentPool_instance.e1n(oldTail);
  }
}
class PeekSource {
  constructor(upstream) {
    this.g1n_1 = upstream;
    this.h1n_1 = this.g1n_1.g1l();
    this.i1n_1 = this.h1n_1.z1k_1;
    var tmp = this;
    var tmp0_safe_receiver = this.h1n_1.z1k_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.m1l_1;
    tmp.j1n_1 = tmp1_elvis_lhs == null ? -1 : tmp1_elvis_lhs;
    this.k1n_1 = false;
    this.l1n_1 = new Long(0, 0);
  }
  h1m(sink, byteCount) {
    // Inline function 'kotlin.check' call
    if (!!this.k1n_1) {
      var message = 'Source is closed.';
      throw IllegalStateException.t4(toString(message));
    }
    // Inline function 'kotlinx.io.checkByteCount' call
    // Inline function 'kotlin.require' call
    if (!(byteCount.s1(new Long(0, 0)) >= 0)) {
      var message_0 = 'byteCount (' + byteCount.toString() + ') < 0';
      throw IllegalArgumentException.t(toString(message_0));
    }
    // Inline function 'kotlin.check' call
    if (!(this.i1n_1 == null || (this.i1n_1 === this.h1n_1.z1k_1 && this.j1n_1 === ensureNotNull(this.h1n_1.z1k_1).m1l_1))) {
      var message_1 = 'Peek source is invalid because upstream source was used';
      throw IllegalStateException.t4(toString(message_1));
    }
    if (byteCount.equals(new Long(0, 0)))
      return new Long(0, 0);
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$7 = this.l1n_1.u3(toLong(1));
    if (!this.g1n_1.j1l(tmp$ret$7))
      return new Long(-1, -1);
    if (this.i1n_1 == null && !(this.h1n_1.z1k_1 == null)) {
      this.i1n_1 = this.h1n_1.z1k_1;
      this.j1n_1 = ensureNotNull(this.h1n_1.z1k_1).m1l_1;
    }
    // Inline function 'kotlin.comparisons.minOf' call
    var b = this.h1n_1.b1().v3(this.l1n_1);
    var toCopy = byteCount.s1(b) <= 0 ? byteCount : b;
    this.h1n_1.x1l(sink, this.l1n_1, this.l1n_1.u3(toCopy));
    this.l1n_1 = this.l1n_1.u3(toCopy);
    return toCopy;
  }
  a6() {
    this.k1n_1 = true;
  }
}
class RealSource {
  constructor(source) {
    this.m1n_1 = source;
    this.n1n_1 = false;
    this.o1n_1 = new Buffer();
  }
  g1l() {
    return this.o1n_1;
  }
  h1m(sink, byteCount) {
    // Inline function 'kotlinx.io.RealSource.checkNotClosed' call
    // Inline function 'kotlin.check' call
    if (!!this.n1n_1) {
      var message = 'Source is closed.';
      throw IllegalStateException.t4(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(byteCount.s1(new Long(0, 0)) >= 0)) {
      var message_0 = 'byteCount: ' + byteCount.toString();
      throw IllegalArgumentException.t(toString(message_0));
    }
    if (this.o1n_1.b1().equals(new Long(0, 0))) {
      var read = this.m1n_1.h1m(this.o1n_1, new Long(8192, 0));
      if (read.equals(new Long(-1, -1)))
        return new Long(-1, -1);
    }
    // Inline function 'kotlin.comparisons.minOf' call
    var b = this.o1n_1.b1();
    var toRead = byteCount.s1(b) <= 0 ? byteCount : b;
    return this.o1n_1.h1m(sink, toRead);
  }
  h1l() {
    // Inline function 'kotlinx.io.RealSource.checkNotClosed' call
    // Inline function 'kotlin.check' call
    if (!!this.n1n_1) {
      var message = 'Source is closed.';
      throw IllegalStateException.t4(toString(message));
    }
    return this.o1n_1.h1l() && this.m1n_1.h1m(this.o1n_1, new Long(8192, 0)).equals(new Long(-1, -1));
  }
  i1l(byteCount) {
    if (!this.j1l(byteCount))
      throw EOFException.f1l("Source doesn't contain required number of bytes (" + byteCount.toString() + ').');
  }
  j1l(byteCount) {
    // Inline function 'kotlinx.io.RealSource.checkNotClosed' call
    // Inline function 'kotlin.check' call
    if (!!this.n1n_1) {
      var message = 'Source is closed.';
      throw IllegalStateException.t4(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(byteCount.s1(new Long(0, 0)) >= 0)) {
      var message_0 = 'byteCount: ' + byteCount.toString();
      throw IllegalArgumentException.t(toString(message_0));
    }
    while (this.o1n_1.b1().s1(byteCount) < 0) {
      if (this.m1n_1.h1m(this.o1n_1, new Long(8192, 0)).equals(new Long(-1, -1)))
        return false;
    }
    return true;
  }
  k1l() {
    this.i1l(new Long(1, 0));
    return this.o1n_1.k1l();
  }
  f1m(sink, startIndex, endIndex) {
    // Inline function 'kotlinx.io.checkBounds' call
    var size = sink.length;
    checkBounds(toLong(size), toLong(startIndex), toLong(endIndex));
    if (this.o1n_1.b1().equals(new Long(0, 0))) {
      var read = this.m1n_1.h1m(this.o1n_1, new Long(8192, 0));
      if (read.equals(new Long(-1, -1)))
        return -1;
    }
    var tmp3 = endIndex - startIndex | 0;
    // Inline function 'kotlinx.io.minOf' call
    var b = this.o1n_1.b1();
    // Inline function 'kotlin.comparisons.minOf' call
    var a = toLong(tmp3);
    var toRead = (a.s1(b) <= 0 ? a : b).x1();
    return this.o1n_1.f1m(sink, startIndex, startIndex + toRead | 0);
  }
  j1m(sink, byteCount) {
    try {
      this.i1l(byteCount);
    } catch ($p) {
      if ($p instanceof EOFException) {
        var e = $p;
        sink.i1m(this.o1n_1, this.o1n_1.b1());
        throw e;
      } else {
        throw $p;
      }
    }
    this.o1n_1.j1m(sink, byteCount);
  }
  k1m(sink) {
    var totalBytesWritten = new Long(0, 0);
    while (!this.m1n_1.h1m(this.o1n_1, new Long(8192, 0)).equals(new Long(-1, -1))) {
      var emitByteCount = this.o1n_1.b1m();
      if (emitByteCount.s1(new Long(0, 0)) > 0) {
        totalBytesWritten = totalBytesWritten.u3(emitByteCount);
        sink.i1m(this.o1n_1, emitByteCount);
      }
    }
    if (this.o1n_1.b1().s1(new Long(0, 0)) > 0) {
      totalBytesWritten = totalBytesWritten.u3(this.o1n_1.b1());
      sink.i1m(this.o1n_1, this.o1n_1.b1());
    }
    return totalBytesWritten;
  }
  u1l() {
    this.i1l(new Long(2, 0));
    return this.o1n_1.u1l();
  }
  l1m() {
    // Inline function 'kotlinx.io.RealSource.checkNotClosed' call
    // Inline function 'kotlin.check' call
    if (!!this.n1n_1) {
      var message = 'Source is closed.';
      throw IllegalStateException.t4(toString(message));
    }
    return buffered(new PeekSource(this));
  }
  a6() {
    if (this.n1n_1)
      return Unit_instance;
    this.n1n_1 = true;
    this.m1n_1.a6();
    this.o1n_1.b3();
  }
  toString() {
    return 'buffered(' + toString(this.m1n_1) + ')';
  }
}
class Companion {
  constructor() {
    this.p1n_1 = 8192;
    this.q1n_1 = 1024;
  }
  r1n() {
    return Segment.s1n();
  }
}
class Segment {
  u1m() {
    var tmp0_safe_receiver = this.o1l_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.t1n();
    return tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs;
  }
  static s1n() {
    var $this = createThis(this);
    init_kotlinx_io_Segment($this);
    $this.l1l_1 = new Int8Array(8192);
    $this.p1l_1 = true;
    $this.o1l_1 = null;
    return $this;
  }
  static u1n(data, pos, limit, shareToken, owner) {
    var $this = createThis(this);
    init_kotlinx_io_Segment($this);
    $this.l1l_1 = data;
    $this.m1l_1 = pos;
    $this.n1l_1 = limit;
    $this.o1l_1 = shareToken;
    $this.p1l_1 = owner;
    return $this;
  }
  y1l() {
    var tmp0_elvis_lhs = this.o1l_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_0 = SegmentPool_instance.v1n();
      this.o1l_1 = this_0;
      tmp = this_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var t = tmp;
    var tmp_0 = this.m1l_1;
    var tmp_1 = this.n1l_1;
    // Inline function 'kotlin.also' call
    t.w1n();
    return Segment.u1n(this.l1l_1, tmp_0, tmp_1, t, false);
  }
  x1m() {
    var result = this.q1l_1;
    if (!(this.r1l_1 == null)) {
      ensureNotNull(this.r1l_1).q1l_1 = this.q1l_1;
    }
    if (!(this.q1l_1 == null)) {
      ensureNotNull(this.q1l_1).r1l_1 = this.r1l_1;
    }
    this.q1l_1 = null;
    this.r1l_1 = null;
    return result;
  }
  z1l(segment) {
    segment.r1l_1 = this;
    segment.q1l_1 = this.q1l_1;
    if (!(this.q1l_1 == null)) {
      ensureNotNull(this.q1l_1).r1l_1 = segment;
    }
    this.q1l_1 = segment;
    return segment;
  }
  v1m(byteCount) {
    // Inline function 'kotlin.require' call
    if (!(byteCount > 0 && byteCount <= (this.n1l_1 - this.m1l_1 | 0))) {
      var message = 'byteCount out of range';
      throw IllegalArgumentException.t(toString(message));
    }
    var prefix;
    if (byteCount >= 1024) {
      prefix = this.y1l();
    } else {
      prefix = SegmentPool_instance.p1m();
      var tmp1 = this.l1l_1;
      var tmp2 = prefix.l1l_1;
      var tmp3 = this.m1l_1;
      // Inline function 'kotlin.collections.copyInto' call
      var endIndex = this.m1l_1 + byteCount | 0;
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp = tmp1;
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      arrayCopy(tmp, tmp2, 0, tmp3, endIndex);
    }
    prefix.n1l_1 = prefix.m1l_1 + byteCount | 0;
    this.m1l_1 = this.m1l_1 + byteCount | 0;
    if (!(this.r1l_1 == null)) {
      ensureNotNull(this.r1l_1).z1l(prefix);
    } else {
      prefix.q1l_1 = this;
      this.r1l_1 = prefix;
    }
    return prefix;
  }
  a1m() {
    // Inline function 'kotlin.check' call
    if (!!(this.r1l_1 == null)) {
      var message = 'cannot compact';
      throw IllegalStateException.t4(toString(message));
    }
    if (!ensureNotNull(this.r1l_1).p1l_1)
      return this;
    var byteCount = this.n1l_1 - this.m1l_1 | 0;
    var availableByteCount = (8192 - ensureNotNull(this.r1l_1).n1l_1 | 0) + (ensureNotNull(this.r1l_1).u1m() ? 0 : ensureNotNull(this.r1l_1).m1l_1) | 0;
    if (byteCount > availableByteCount)
      return this;
    var predecessor = this.r1l_1;
    this.w1m(ensureNotNull(predecessor), byteCount);
    var successor = this.x1m();
    // Inline function 'kotlin.check' call
    if (!(successor == null)) {
      throw IllegalStateException.t4('Check failed.');
    }
    SegmentPool_instance.e1n(this);
    return predecessor;
  }
  a1n(byte) {
    var _unary__edvuaz = this.n1l_1;
    this.n1l_1 = _unary__edvuaz + 1 | 0;
    this.l1l_1[_unary__edvuaz] = byte;
  }
  c1n(short) {
    var data = this.l1l_1;
    var limit = this.n1l_1;
    var _unary__edvuaz = limit;
    limit = _unary__edvuaz + 1 | 0;
    data[_unary__edvuaz] = toByte((short >>> 8 | 0) & 255);
    var _unary__edvuaz_0 = limit;
    limit = _unary__edvuaz_0 + 1 | 0;
    data[_unary__edvuaz_0] = toByte(short & 255);
    this.n1l_1 = limit;
  }
  t1l() {
    var _unary__edvuaz = this.m1l_1;
    this.m1l_1 = _unary__edvuaz + 1 | 0;
    return this.l1l_1[_unary__edvuaz];
  }
  v1l() {
    var data = this.l1l_1;
    var pos = this.m1l_1;
    var _unary__edvuaz = pos;
    pos = _unary__edvuaz + 1 | 0;
    // Inline function 'kotlinx.io.and' call
    var tmp = (data[_unary__edvuaz] & 255) << 8;
    var _unary__edvuaz_0 = pos;
    pos = _unary__edvuaz_0 + 1 | 0;
    // Inline function 'kotlinx.io.and' call
    var tmp$ret$1 = data[_unary__edvuaz_0] & 255;
    var s = toShort(tmp | tmp$ret$1);
    this.m1l_1 = pos;
    return s;
  }
  w1m(sink, byteCount) {
    // Inline function 'kotlin.check' call
    if (!sink.p1l_1) {
      var message = 'only owner can write';
      throw IllegalStateException.t4(toString(message));
    }
    if ((sink.n1l_1 + byteCount | 0) > 8192) {
      if (sink.u1m())
        throw IllegalArgumentException.zd();
      if (((sink.n1l_1 + byteCount | 0) - sink.m1l_1 | 0) > 8192)
        throw IllegalArgumentException.zd();
      var tmp1 = sink.l1l_1;
      var tmp2 = sink.l1l_1;
      var tmp3 = sink.m1l_1;
      // Inline function 'kotlin.collections.copyInto' call
      var endIndex = sink.n1l_1;
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      var tmp = tmp1;
      // Inline function 'kotlin.js.unsafeCast' call
      // Inline function 'kotlin.js.asDynamic' call
      arrayCopy(tmp, tmp2, 0, tmp3, endIndex);
      sink.n1l_1 = sink.n1l_1 - sink.m1l_1 | 0;
      sink.m1l_1 = 0;
    }
    var tmp6 = this.l1l_1;
    var tmp7 = sink.l1l_1;
    var tmp8 = sink.n1l_1;
    var tmp9 = this.m1l_1;
    // Inline function 'kotlin.collections.copyInto' call
    var endIndex_0 = this.m1l_1 + byteCount | 0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = tmp6;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp_0, tmp7, tmp8, tmp9, endIndex_0);
    sink.n1l_1 = sink.n1l_1 + byteCount | 0;
    this.m1l_1 = this.m1l_1 + byteCount | 0;
  }
  g1m(dst, dstStartOffset, dstEndOffset) {
    var len = dstEndOffset - dstStartOffset | 0;
    var tmp0 = this.l1l_1;
    var tmp3 = this.m1l_1;
    // Inline function 'kotlin.collections.copyInto' call
    var endIndex = this.m1l_1 + len | 0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = tmp0;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp, dst, dstStartOffset, tmp3, endIndex);
    this.m1l_1 = this.m1l_1 + len | 0;
  }
  s1m(src, srcStartOffset, srcEndOffset) {
    var tmp1 = this.l1l_1;
    // Inline function 'kotlin.collections.copyInto' call
    var destinationOffset = this.n1l_1;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp = src;
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    arrayCopy(tmp, tmp1, destinationOffset, srcStartOffset, srcEndOffset);
    this.n1l_1 = this.n1l_1 + (srcEndOffset - srcStartOffset | 0) | 0;
  }
  b1() {
    return this.n1l_1 - this.m1l_1 | 0;
  }
  r1m() {
    return this.l1l_1.length - this.n1l_1 | 0;
  }
  x1n(readOnly) {
    return this.l1l_1;
  }
  d1m(index) {
    return this.l1l_1[this.m1l_1 + index | 0];
  }
  y1n(index, value) {
    this.l1l_1[this.n1l_1 + index | 0] = value;
  }
  z1n(index, b0, b1) {
    var d = this.l1l_1;
    var l = this.n1l_1;
    d[l + index | 0] = b0;
    d[(l + index | 0) + 1 | 0] = b1;
  }
  a1o(index, b0, b1, b2) {
    var d = this.l1l_1;
    var l = this.n1l_1;
    d[l + index | 0] = b0;
    d[(l + index | 0) + 1 | 0] = b1;
    d[(l + index | 0) + 2 | 0] = b2;
  }
  b1o(index, b0, b1, b2, b3) {
    var d = this.l1l_1;
    var l = this.n1l_1;
    d[l + index | 0] = b0;
    d[(l + index | 0) + 1 | 0] = b1;
    d[(l + index | 0) + 2 | 0] = b2;
    d[(l + index | 0) + 3 | 0] = b3;
  }
}
class SegmentCopyTracker {}
class AlwaysSharedCopyTracker extends SegmentCopyTracker {
  constructor() {
    AlwaysSharedCopyTracker_instance = null;
    super();
    AlwaysSharedCopyTracker_instance = this;
  }
  t1n() {
    return true;
  }
  w1n() {
    return Unit_instance;
  }
}
class UnsafeBufferOperations {}
class SegmentReadContextImpl$1 {
  d1n(segment, offset) {
    return segment.d1m(offset);
  }
}
class SegmentWriteContextImpl$1 {
  f1o(segment, offset, value) {
    segment.y1n(offset, value);
  }
  e1o(segment, offset, b0, b1) {
    segment.z1n(offset, b0, b1);
  }
  d1o(segment, offset, b0, b1, b2) {
    segment.a1o(offset, b0, b1, b2);
  }
  c1o(segment, offset, b0, b1, b2, b3) {
    segment.b1o(offset, b0, b1, b2, b3);
  }
}
class BufferIterationContextImpl$1 {
  d1n(segment, offset) {
    return get_SegmentReadContextImpl().d1n(segment, offset);
  }
}
class IOException extends Exception {
  static i1o() {
    var $this = this.wd();
    init_kotlinx_io_IOException($this);
    return $this;
  }
  static j1o(message) {
    var $this = this.l5(message);
    init_kotlinx_io_IOException($this);
    return $this;
  }
  static k1o(message, cause) {
    var $this = this.xd(message, cause);
    init_kotlinx_io_IOException($this);
    return $this;
  }
}
class EOFException extends IOException {
  static l1o() {
    var $this = this.i1o();
    init_kotlinx_io_EOFException($this);
    return $this;
  }
  static f1l(message) {
    var $this = this.j1o(message);
    init_kotlinx_io_EOFException($this);
    return $this;
  }
}
class SegmentPool {
  constructor() {
    this.n1m_1 = 0;
    this.o1m_1 = 0;
  }
  p1m() {
    return Companion_instance.r1n();
  }
  e1n(segment) {
  }
  v1n() {
    return AlwaysSharedCopyTracker_getInstance();
  }
}
//endregion
function get_HEX_DIGIT_CHARS() {
  _init_properties__Util_kt__g8tcl9();
  return HEX_DIGIT_CHARS;
}
var HEX_DIGIT_CHARS;
function checkBounds(size, startIndex, endIndex) {
  _init_properties__Util_kt__g8tcl9();
  if (startIndex.s1(new Long(0, 0)) < 0 || endIndex.s1(size) > 0) {
    throw IndexOutOfBoundsException.me('startIndex (' + startIndex.toString() + ') and endIndex (' + endIndex.toString() + ') are not within the range [0..size(' + size.toString() + '))');
  }
  if (startIndex.s1(endIndex) > 0) {
    throw IllegalArgumentException.t('startIndex (' + startIndex.toString() + ') > endIndex (' + endIndex.toString() + ')');
  }
}
function checkOffsetAndCount(size, offset, byteCount) {
  _init_properties__Util_kt__g8tcl9();
  if (offset.s1(new Long(0, 0)) < 0 || offset.s1(size) > 0 || size.v3(offset).s1(byteCount) < 0 || byteCount.s1(new Long(0, 0)) < 0) {
    throw IllegalArgumentException.t('offset (' + offset.toString() + ') and byteCount (' + byteCount.toString() + ') are not within the range [0..size(' + size.toString() + '))');
  }
}
var properties_initialized__Util_kt_67kc5b;
function _init_properties__Util_kt__g8tcl9() {
  if (!properties_initialized__Util_kt_67kc5b) {
    properties_initialized__Util_kt_67kc5b = true;
    // Inline function 'kotlin.charArrayOf' call
    HEX_DIGIT_CHARS = charArrayOf([_Char___init__impl__6a9atx(48), _Char___init__impl__6a9atx(49), _Char___init__impl__6a9atx(50), _Char___init__impl__6a9atx(51), _Char___init__impl__6a9atx(52), _Char___init__impl__6a9atx(53), _Char___init__impl__6a9atx(54), _Char___init__impl__6a9atx(55), _Char___init__impl__6a9atx(56), _Char___init__impl__6a9atx(57), _Char___init__impl__6a9atx(97), _Char___init__impl__6a9atx(98), _Char___init__impl__6a9atx(99), _Char___init__impl__6a9atx(100), _Char___init__impl__6a9atx(101), _Char___init__impl__6a9atx(102)]);
  }
}
function throwEof($this, byteCount) {
  throw EOFException.f1l("Buffer doesn't contain required number of bytes (size: " + $this.b1().toString() + ', required: ' + byteCount.toString() + ')');
}
function indexOf(_this__u8e3s4, byte, startIndex, endIndex) {
  startIndex = startIndex === VOID ? new Long(0, 0) : startIndex;
  endIndex = endIndex === VOID ? _this__u8e3s4.b1() : endIndex;
  // Inline function 'kotlin.comparisons.minOf' call
  var b = _this__u8e3s4.b1();
  var endOffset = endIndex.s1(b) <= 0 ? endIndex : b;
  checkBounds(_this__u8e3s4.b1(), startIndex, endOffset);
  if (startIndex.equals(endOffset))
    return new Long(-1, -1);
  // Inline function 'kotlinx.io.seek' call
  if (_this__u8e3s4.z1k_1 == null) {
    var o = new Long(-1, -1);
    if (o.equals(new Long(-1, -1))) {
      return new Long(-1, -1);
    }
    var segment = null;
    var offset = o;
    do {
      // Inline function 'kotlin.check' call
      if (!(endOffset.s1(offset) > 0)) {
        throw IllegalStateException.t4('Check failed.');
      }
      ensureNotNull(segment);
      var tmp = segment;
      // Inline function 'kotlin.comparisons.maxOf' call
      var a = startIndex.v3(offset).x1();
      var tmp_0 = Math.max(a, 0);
      var tmp3 = segment.b1();
      // Inline function 'kotlin.comparisons.minOf' call
      var b_0 = endOffset.v3(offset).x1();
      var tmp$ret$3 = Math.min(tmp3, b_0);
      var idx = indexOf_0(tmp, byte, tmp_0, tmp$ret$3);
      if (!(idx === -1)) {
        return offset.u3(toLong(idx));
      }
      var tmp5 = offset;
      // Inline function 'kotlin.Long.plus' call
      var other = segment.b1();
      offset = tmp5.u3(toLong(other));
      segment = segment.q1l_1;
    }
     while (!(segment == null) && offset.s1(endOffset) < 0);
    return new Long(-1, -1);
  }
  if (_this__u8e3s4.b1().v3(startIndex).s1(startIndex) < 0) {
    var s = _this__u8e3s4.a1l_1;
    var offset_0 = _this__u8e3s4.b1();
    $l$loop: while (!(s == null) && offset_0.s1(startIndex) > 0) {
      offset_0 = offset_0.v3(toLong(s.n1l_1 - s.m1l_1 | 0));
      if (offset_0.s1(startIndex) <= 0)
        break $l$loop;
      s = s.r1l_1;
    }
    var tmp6 = s;
    var o_0 = offset_0;
    if (o_0.equals(new Long(-1, -1))) {
      return new Long(-1, -1);
    }
    var segment_0 = tmp6;
    var offset_1 = o_0;
    do {
      // Inline function 'kotlin.check' call
      if (!(endOffset.s1(offset_1) > 0)) {
        throw IllegalStateException.t4('Check failed.');
      }
      ensureNotNull(segment_0);
      var tmp_1 = segment_0;
      // Inline function 'kotlin.comparisons.maxOf' call
      var a_0 = startIndex.v3(offset_1).x1();
      var tmp_2 = Math.max(a_0, 0);
      var tmp3_0 = segment_0.b1();
      // Inline function 'kotlin.comparisons.minOf' call
      var b_1 = endOffset.v3(offset_1).x1();
      var tmp$ret$8 = Math.min(tmp3_0, b_1);
      var idx_0 = indexOf_0(tmp_1, byte, tmp_2, tmp$ret$8);
      if (!(idx_0 === -1)) {
        return offset_1.u3(toLong(idx_0));
      }
      var tmp5_0 = offset_1;
      // Inline function 'kotlin.Long.plus' call
      var other_0 = segment_0.b1();
      offset_1 = tmp5_0.u3(toLong(other_0));
      segment_0 = segment_0.q1l_1;
    }
     while (!(segment_0 == null) && offset_1.s1(endOffset) < 0);
    return new Long(-1, -1);
  } else {
    var s_0 = _this__u8e3s4.z1k_1;
    var offset_2 = new Long(0, 0);
    $l$loop_0: while (!(s_0 == null)) {
      var tmp0 = offset_2;
      // Inline function 'kotlin.Long.plus' call
      var other_1 = s_0.n1l_1 - s_0.m1l_1 | 0;
      var nextOffset = tmp0.u3(toLong(other_1));
      if (nextOffset.s1(startIndex) > 0)
        break $l$loop_0;
      s_0 = s_0.q1l_1;
      offset_2 = nextOffset;
    }
    var tmp8 = s_0;
    var o_1 = offset_2;
    if (o_1.equals(new Long(-1, -1))) {
      return new Long(-1, -1);
    }
    var segment_1 = tmp8;
    var offset_3 = o_1;
    do {
      // Inline function 'kotlin.check' call
      if (!(endOffset.s1(offset_3) > 0)) {
        throw IllegalStateException.t4('Check failed.');
      }
      ensureNotNull(segment_1);
      var tmp_3 = segment_1;
      // Inline function 'kotlin.comparisons.maxOf' call
      var a_1 = startIndex.v3(offset_3).x1();
      var tmp_4 = Math.max(a_1, 0);
      var tmp3_1 = segment_1.b1();
      // Inline function 'kotlin.comparisons.minOf' call
      var b_2 = endOffset.v3(offset_3).x1();
      var tmp$ret$13 = Math.min(tmp3_1, b_2);
      var idx_1 = indexOf_0(tmp_3, byte, tmp_4, tmp$ret$13);
      if (!(idx_1 === -1)) {
        return offset_3.u3(toLong(idx_1));
      }
      var tmp5_1 = offset_3;
      // Inline function 'kotlin.Long.plus' call
      var other_2 = segment_1.b1();
      offset_3 = tmp5_1.u3(toLong(other_2));
      segment_1 = segment_1.q1l_1;
    }
     while (!(segment_1 == null) && offset_3.s1(endOffset) < 0);
    return new Long(-1, -1);
  }
}
function readByteString(_this__u8e3s4, byteCount) {
  return UnsafeByteStringOperations_instance.y1k(readByteArray_0(_this__u8e3s4, byteCount));
}
function buffered(_this__u8e3s4) {
  return new RealSource(_this__u8e3s4);
}
var Companion_instance;
function Companion_getInstance() {
  return Companion_instance;
}
function init_kotlinx_io_Segment(_this__u8e3s4) {
  _this__u8e3s4.m1l_1 = 0;
  _this__u8e3s4.n1l_1 = 0;
  _this__u8e3s4.o1l_1 = null;
  _this__u8e3s4.p1l_1 = false;
  _this__u8e3s4.q1l_1 = null;
  _this__u8e3s4.r1l_1 = null;
}
function isEmpty(_this__u8e3s4) {
  return _this__u8e3s4.b1() === 0;
}
var AlwaysSharedCopyTracker_instance;
function AlwaysSharedCopyTracker_getInstance() {
  if (AlwaysSharedCopyTracker_instance === VOID)
    new AlwaysSharedCopyTracker();
  return AlwaysSharedCopyTracker_instance;
}
function indexOf_0(_this__u8e3s4, byte, startOffset, endOffset) {
  // Inline function 'kotlin.require' call
  if (!(0 <= startOffset ? startOffset < _this__u8e3s4.b1() : false)) {
    var message = '' + startOffset;
    throw IllegalArgumentException.t(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(startOffset <= endOffset ? endOffset <= _this__u8e3s4.b1() : false)) {
    var message_0 = '' + endOffset;
    throw IllegalArgumentException.t(toString(message_0));
  }
  var p = _this__u8e3s4.m1l_1;
  var data = _this__u8e3s4.x1n(true);
  var inductionVariable = startOffset;
  if (inductionVariable < endOffset)
    do {
      var idx = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (data[p + idx | 0] === byte) {
        return idx;
      }
    }
     while (inductionVariable < endOffset);
  return -1;
}
function readByteArray(_this__u8e3s4) {
  return readByteArrayImpl(_this__u8e3s4, -1);
}
function readByteArrayImpl(_this__u8e3s4, size) {
  var arraySize = size;
  if (size === -1) {
    var fetchSize = new Long(2147483647, 0);
    while (_this__u8e3s4.g1l().b1().s1(new Long(2147483647, 0)) < 0 && _this__u8e3s4.j1l(fetchSize)) {
      // Inline function 'kotlin.Long.times' call
      fetchSize = fetchSize.w3(toLong(2));
    }
    // Inline function 'kotlin.check' call
    if (!(_this__u8e3s4.g1l().b1().s1(new Long(2147483647, 0)) < 0)) {
      var message = "Can't create an array of size " + _this__u8e3s4.g1l().b1().toString();
      throw IllegalStateException.t4(toString(message));
    }
    arraySize = _this__u8e3s4.g1l().b1().x1();
  } else {
    _this__u8e3s4.i1l(toLong(size));
  }
  var array = new Int8Array(arraySize);
  readTo(_this__u8e3s4.g1l(), array);
  return array;
}
function readTo(_this__u8e3s4, sink, startIndex, endIndex) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  endIndex = endIndex === VOID ? sink.length : endIndex;
  // Inline function 'kotlinx.io.checkBounds' call
  var size = sink.length;
  checkBounds(toLong(size), toLong(startIndex), toLong(endIndex));
  var offset = startIndex;
  while (offset < endIndex) {
    var bytesRead = _this__u8e3s4.f1m(sink, offset, endIndex);
    if (bytesRead === -1) {
      throw EOFException.f1l('Source exhausted before reading ' + (endIndex - startIndex | 0) + ' bytes. ' + ('Only ' + bytesRead + ' bytes were read.'));
    }
    offset = offset + bytesRead | 0;
  }
}
function readByteArray_0(_this__u8e3s4, byteCount) {
  // Inline function 'kotlinx.io.checkByteCount' call
  var byteCount_0 = toLong(byteCount);
  // Inline function 'kotlin.require' call
  if (!(byteCount_0.s1(new Long(0, 0)) >= 0)) {
    var message = 'byteCount (' + byteCount_0.toString() + ') < 0';
    throw IllegalArgumentException.t(toString(message));
  }
  return readByteArrayImpl(_this__u8e3s4, byteCount);
}
function indexOf_1(_this__u8e3s4, byte, startIndex, endIndex) {
  startIndex = startIndex === VOID ? new Long(0, 0) : startIndex;
  endIndex = endIndex === VOID ? new Long(-1, 2147483647) : endIndex;
  // Inline function 'kotlin.require' call
  if (!((new Long(0, 0)).s1(startIndex) <= 0 ? startIndex.s1(endIndex) <= 0 : false)) {
    var tmp;
    if (endIndex.s1(new Long(0, 0)) < 0) {
      tmp = 'startIndex (' + startIndex.toString() + ') and endIndex (' + endIndex.toString() + ') should be non negative';
    } else {
      tmp = 'startIndex (' + startIndex.toString() + ') is not within the range [0..endIndex(' + endIndex.toString() + '))';
    }
    var message = tmp;
    throw IllegalArgumentException.t(toString(message));
  }
  if (startIndex.equals(endIndex))
    return new Long(-1, -1);
  var offset = startIndex;
  $l$loop: while (true) {
    var tmp_0;
    if (offset.s1(endIndex) < 0) {
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$2 = offset.u3(toLong(1));
      tmp_0 = _this__u8e3s4.j1l(tmp$ret$2);
    } else {
      tmp_0 = false;
    }
    if (!tmp_0) {
      break $l$loop;
    }
    var tmp_1 = _this__u8e3s4.g1l();
    var tmp_2 = offset;
    // Inline function 'kotlin.comparisons.minOf' call
    var b = _this__u8e3s4.g1l().b1();
    var tmp$ret$3 = endIndex.s1(b) <= 0 ? endIndex : b;
    var idx = indexOf(tmp_1, byte, tmp_2, tmp$ret$3);
    if (!idx.equals(new Long(-1, -1))) {
      return idx;
    }
    offset = _this__u8e3s4.g1l().b1();
  }
  return new Long(-1, -1);
}
function readString(_this__u8e3s4) {
  _this__u8e3s4.j1l(new Long(-1, 2147483647));
  return commonReadUtf8(_this__u8e3s4.g1l(), _this__u8e3s4.g1l().b1());
}
function readString_0(_this__u8e3s4, byteCount) {
  _this__u8e3s4.i1l(byteCount);
  return commonReadUtf8(_this__u8e3s4.g1l(), byteCount);
}
function readString_1(_this__u8e3s4) {
  return commonReadUtf8(_this__u8e3s4, _this__u8e3s4.b1());
}
function commonReadUtf8(_this__u8e3s4, byteCount) {
  if (byteCount.equals(new Long(0, 0)))
    return '';
  // Inline function 'kotlinx.io.unsafe.UnsafeBufferOperations.forEachSegment' call
  var curr = _this__u8e3s4.z1k_1;
  while (!(curr == null)) {
    get_SegmentReadContextImpl();
    if (toLong(curr.b1()).s1(byteCount) >= 0) {
      var result = '';
      // Inline function 'kotlinx.io.unsafe.withData' call
      var tmp2 = curr.x1n(true);
      var tmp3 = curr.m1l_1;
      var tmp0 = curr.n1l_1;
      // Inline function 'kotlin.math.min' call
      var b = tmp3 + byteCount.x1() | 0;
      var tmp$ret$0 = Math.min(tmp0, b);
      result = commonToUtf8String(tmp2, tmp3, tmp$ret$0);
      _this__u8e3s4.e1m(byteCount);
      return result;
    }
    return commonToUtf8String(readByteArray_0(_this__u8e3s4, byteCount.x1()));
  }
  // Inline function 'kotlin.error' call
  var message = 'Unreacheable';
  throw IllegalStateException.t4(toString(message));
}
function writeString(_this__u8e3s4, string, startIndex, endIndex) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  endIndex = endIndex === VOID ? string.length : endIndex;
  // Inline function 'kotlinx.io.checkBounds' call
  var size = string.length;
  checkBounds(toLong(size), toLong(startIndex), toLong(endIndex));
  // Inline function 'kotlinx.io.writeToInternalBuffer' call
  // Inline function 'kotlinx.io.commonWriteUtf8' call
  var this_0 = _this__u8e3s4.g1l();
  var i = startIndex;
  while (i < endIndex) {
    var p0 = i;
    // Inline function 'kotlin.code' call
    var this_1 = charSequenceGet(string, p0);
    var c = Char__toInt_impl_vasixd(this_1);
    if (c < 128) {
      $l$block_0: {
        // Inline function 'kotlinx.io.unsafe.UnsafeBufferOperations.writeToTail' call
        var tail = this_0.m1m(1);
        var ctx = get_SegmentWriteContextImpl();
        var segmentOffset = -i | 0;
        // Inline function 'kotlin.comparisons.minOf' call
        var b = i + tail.r1m() | 0;
        var runLimit = Math.min(endIndex, b);
        var _unary__edvuaz = i;
        i = _unary__edvuaz + 1 | 0;
        ctx.f1o(tail, segmentOffset + _unary__edvuaz | 0, toByte(c));
        $l$loop: while (i < runLimit) {
          var p0_0 = i;
          // Inline function 'kotlin.code' call
          var this_2 = charSequenceGet(string, p0_0);
          c = Char__toInt_impl_vasixd(this_2);
          if (c >= 128)
            break $l$loop;
          var _unary__edvuaz_0 = i;
          i = _unary__edvuaz_0 + 1 | 0;
          ctx.f1o(tail, segmentOffset + _unary__edvuaz_0 | 0, toByte(c));
        }
        var bytesWritten = i + segmentOffset | 0;
        if (bytesWritten === 1) {
          tail.n1l_1 = tail.n1l_1 + bytesWritten | 0;
          var tmp = this_0;
          // Inline function 'kotlin.Long.plus' call
          tmp.b1l_1 = this_0.b1l_1.u3(toLong(bytesWritten));
          break $l$block_0;
        }
        // Inline function 'kotlin.check' call
        if (!(0 <= bytesWritten ? bytesWritten <= tail.r1m() : false)) {
          var message = 'Invalid number of bytes written: ' + bytesWritten + '. Should be in 0..' + tail.r1m();
          throw IllegalStateException.t4(toString(message));
        }
        if (!(bytesWritten === 0)) {
          tail.n1l_1 = tail.n1l_1 + bytesWritten | 0;
          var tmp_0 = this_0;
          // Inline function 'kotlin.Long.plus' call
          tmp_0.b1l_1 = this_0.b1l_1.u3(toLong(bytesWritten));
          break $l$block_0;
        }
        if (isEmpty(tail)) {
          this_0.f1n();
        }
      }
    } else if (c < 2048) {
      $l$block_2: {
        // Inline function 'kotlinx.io.unsafe.UnsafeBufferOperations.writeToTail' call
        var tail_0 = this_0.m1m(2);
        get_SegmentWriteContextImpl().e1o(tail_0, 0, toByte(c >> 6 | 192), toByte(c & 63 | 128));
        var bytesWritten_0 = 2;
        if (bytesWritten_0 === 2) {
          tail_0.n1l_1 = tail_0.n1l_1 + bytesWritten_0 | 0;
          var tmp_1 = this_0;
          // Inline function 'kotlin.Long.plus' call
          tmp_1.b1l_1 = this_0.b1l_1.u3(toLong(bytesWritten_0));
          break $l$block_2;
        }
        // Inline function 'kotlin.check' call
        if (!(0 <= bytesWritten_0 ? bytesWritten_0 <= tail_0.r1m() : false)) {
          var message_0 = 'Invalid number of bytes written: ' + bytesWritten_0 + '. Should be in 0..' + tail_0.r1m();
          throw IllegalStateException.t4(toString(message_0));
        }
        if (!(bytesWritten_0 === 0)) {
          tail_0.n1l_1 = tail_0.n1l_1 + bytesWritten_0 | 0;
          var tmp_2 = this_0;
          // Inline function 'kotlin.Long.plus' call
          tmp_2.b1l_1 = this_0.b1l_1.u3(toLong(bytesWritten_0));
          break $l$block_2;
        }
        if (isEmpty(tail_0)) {
          this_0.f1n();
        }
      }
      i = i + 1 | 0;
    } else if (c < 55296 || c > 57343) {
      $l$block_4: {
        // Inline function 'kotlinx.io.unsafe.UnsafeBufferOperations.writeToTail' call
        var tail_1 = this_0.m1m(3);
        get_SegmentWriteContextImpl().d1o(tail_1, 0, toByte(c >> 12 | 224), toByte(c >> 6 & 63 | 128), toByte(c & 63 | 128));
        var bytesWritten_1 = 3;
        if (bytesWritten_1 === 3) {
          tail_1.n1l_1 = tail_1.n1l_1 + bytesWritten_1 | 0;
          var tmp_3 = this_0;
          // Inline function 'kotlin.Long.plus' call
          tmp_3.b1l_1 = this_0.b1l_1.u3(toLong(bytesWritten_1));
          break $l$block_4;
        }
        // Inline function 'kotlin.check' call
        if (!(0 <= bytesWritten_1 ? bytesWritten_1 <= tail_1.r1m() : false)) {
          var message_1 = 'Invalid number of bytes written: ' + bytesWritten_1 + '. Should be in 0..' + tail_1.r1m();
          throw IllegalStateException.t4(toString(message_1));
        }
        if (!(bytesWritten_1 === 0)) {
          tail_1.n1l_1 = tail_1.n1l_1 + bytesWritten_1 | 0;
          var tmp_4 = this_0;
          // Inline function 'kotlin.Long.plus' call
          tmp_4.b1l_1 = this_0.b1l_1.u3(toLong(bytesWritten_1));
          break $l$block_4;
        }
        if (isEmpty(tail_1)) {
          this_0.f1n();
        }
      }
      i = i + 1 | 0;
    } else {
      var tmp_5;
      if ((i + 1 | 0) < endIndex) {
        var p0_1 = i + 1 | 0;
        // Inline function 'kotlin.code' call
        var this_3 = charSequenceGet(string, p0_1);
        tmp_5 = Char__toInt_impl_vasixd(this_3);
      } else {
        tmp_5 = 0;
      }
      var low = tmp_5;
      if (c > 56319 || !(56320 <= low ? low <= 57343 : false)) {
        // Inline function 'kotlin.code' call
        var this_4 = _Char___init__impl__6a9atx(63);
        var tmp$ret$26 = Char__toInt_impl_vasixd(this_4);
        this_0.z1m(toByte(tmp$ret$26));
        i = i + 1 | 0;
      } else {
        var codePoint = 65536 + ((c & 1023) << 10 | low & 1023) | 0;
        $l$block_6: {
          // Inline function 'kotlinx.io.unsafe.UnsafeBufferOperations.writeToTail' call
          var tail_2 = this_0.m1m(4);
          get_SegmentWriteContextImpl().c1o(tail_2, 0, toByte(codePoint >> 18 | 240), toByte(codePoint >> 12 & 63 | 128), toByte(codePoint >> 6 & 63 | 128), toByte(codePoint & 63 | 128));
          var bytesWritten_2 = 4;
          if (bytesWritten_2 === 4) {
            tail_2.n1l_1 = tail_2.n1l_1 + bytesWritten_2 | 0;
            var tmp_6 = this_0;
            // Inline function 'kotlin.Long.plus' call
            tmp_6.b1l_1 = this_0.b1l_1.u3(toLong(bytesWritten_2));
            break $l$block_6;
          }
          // Inline function 'kotlin.check' call
          if (!(0 <= bytesWritten_2 ? bytesWritten_2 <= tail_2.r1m() : false)) {
            var message_2 = 'Invalid number of bytes written: ' + bytesWritten_2 + '. Should be in 0..' + tail_2.r1m();
            throw IllegalStateException.t4(toString(message_2));
          }
          if (!(bytesWritten_2 === 0)) {
            tail_2.n1l_1 = tail_2.n1l_1 + bytesWritten_2 | 0;
            var tmp_7 = this_0;
            // Inline function 'kotlin.Long.plus' call
            tmp_7.b1l_1 = this_0.b1l_1.u3(toLong(bytesWritten_2));
            break $l$block_6;
          }
          if (isEmpty(tail_2)) {
            this_0.f1n();
          }
        }
        i = i + 2 | 0;
      }
    }
  }
  _this__u8e3s4.w1l();
}
function commonToUtf8String(_this__u8e3s4, beginIndex, endIndex) {
  beginIndex = beginIndex === VOID ? 0 : beginIndex;
  endIndex = endIndex === VOID ? _this__u8e3s4.length : endIndex;
  if (beginIndex < 0 || endIndex > _this__u8e3s4.length || beginIndex > endIndex) {
    throw IndexOutOfBoundsException.me('size=' + _this__u8e3s4.length + ' beginIndex=' + beginIndex + ' endIndex=' + endIndex);
  }
  var chars = charArray(endIndex - beginIndex | 0);
  var length = 0;
  // Inline function 'kotlinx.io.internal.processUtf16Chars' call
  var index = beginIndex;
  while (index < endIndex) {
    var b0 = _this__u8e3s4[index];
    if (b0 >= 0) {
      var c = numberToChar(b0);
      var _unary__edvuaz = length;
      length = _unary__edvuaz + 1 | 0;
      chars[_unary__edvuaz] = c;
      index = index + 1 | 0;
      while (index < endIndex && _this__u8e3s4[index] >= 0) {
        var _unary__edvuaz_0 = index;
        index = _unary__edvuaz_0 + 1 | 0;
        var c_0 = numberToChar(_this__u8e3s4[_unary__edvuaz_0]);
        var _unary__edvuaz_1 = length;
        length = _unary__edvuaz_1 + 1 | 0;
        chars[_unary__edvuaz_1] = c_0;
      }
    } else {
      // Inline function 'kotlinx.io.shr' call
      if (b0 >> 5 === -2) {
        var tmp = index;
        var tmp3 = index;
        var tmp$ret$5;
        $l$block_0: {
          // Inline function 'kotlinx.io.internal.process2Utf8Bytes' call
          if (endIndex <= (tmp3 + 1 | 0)) {
            var c_1 = numberToChar(65533);
            var _unary__edvuaz_2 = length;
            length = _unary__edvuaz_2 + 1 | 0;
            chars[_unary__edvuaz_2] = c_1;
            tmp$ret$5 = 1;
            break $l$block_0;
          }
          var b0_0 = _this__u8e3s4[tmp3];
          var b1 = _this__u8e3s4[tmp3 + 1 | 0];
          // Inline function 'kotlinx.io.internal.isUtf8Continuation' call
          // Inline function 'kotlinx.io.and' call
          if (!((b1 & 192) === 128)) {
            var c_2 = numberToChar(65533);
            var _unary__edvuaz_3 = length;
            length = _unary__edvuaz_3 + 1 | 0;
            chars[_unary__edvuaz_3] = c_2;
            tmp$ret$5 = 1;
            break $l$block_0;
          }
          var codePoint = 3968 ^ b1 ^ b0_0 << 6;
          if (codePoint < 128) {
            var c_3 = numberToChar(65533);
            var _unary__edvuaz_4 = length;
            length = _unary__edvuaz_4 + 1 | 0;
            chars[_unary__edvuaz_4] = c_3;
          } else {
            var c_4 = numberToChar(codePoint);
            var _unary__edvuaz_5 = length;
            length = _unary__edvuaz_5 + 1 | 0;
            chars[_unary__edvuaz_5] = c_4;
          }
          tmp$ret$5 = 2;
        }
        index = tmp + tmp$ret$5 | 0;
      } else {
        // Inline function 'kotlinx.io.shr' call
        if (b0 >> 4 === -2) {
          var tmp_0 = index;
          var tmp12 = index;
          var tmp$ret$19;
          $l$block_4: {
            // Inline function 'kotlinx.io.internal.process3Utf8Bytes' call
            if (endIndex <= (tmp12 + 2 | 0)) {
              var c_5 = numberToChar(65533);
              var _unary__edvuaz_6 = length;
              length = _unary__edvuaz_6 + 1 | 0;
              chars[_unary__edvuaz_6] = c_5;
              var tmp_1;
              if (endIndex <= (tmp12 + 1 | 0)) {
                tmp_1 = true;
              } else {
                // Inline function 'kotlinx.io.internal.isUtf8Continuation' call
                // Inline function 'kotlinx.io.and' call
                tmp_1 = !((_this__u8e3s4[tmp12 + 1 | 0] & 192) === 128);
              }
              if (tmp_1) {
                tmp$ret$19 = 1;
                break $l$block_4;
              } else {
                tmp$ret$19 = 2;
                break $l$block_4;
              }
            }
            var b0_1 = _this__u8e3s4[tmp12];
            var b1_0 = _this__u8e3s4[tmp12 + 1 | 0];
            // Inline function 'kotlinx.io.internal.isUtf8Continuation' call
            // Inline function 'kotlinx.io.and' call
            if (!((b1_0 & 192) === 128)) {
              var c_6 = numberToChar(65533);
              var _unary__edvuaz_7 = length;
              length = _unary__edvuaz_7 + 1 | 0;
              chars[_unary__edvuaz_7] = c_6;
              tmp$ret$19 = 1;
              break $l$block_4;
            }
            var b2 = _this__u8e3s4[tmp12 + 2 | 0];
            // Inline function 'kotlinx.io.internal.isUtf8Continuation' call
            // Inline function 'kotlinx.io.and' call
            if (!((b2 & 192) === 128)) {
              var c_7 = numberToChar(65533);
              var _unary__edvuaz_8 = length;
              length = _unary__edvuaz_8 + 1 | 0;
              chars[_unary__edvuaz_8] = c_7;
              tmp$ret$19 = 2;
              break $l$block_4;
            }
            var codePoint_0 = -123008 ^ b2 ^ b1_0 << 6 ^ b0_1 << 12;
            if (codePoint_0 < 2048) {
              var c_8 = numberToChar(65533);
              var _unary__edvuaz_9 = length;
              length = _unary__edvuaz_9 + 1 | 0;
              chars[_unary__edvuaz_9] = c_8;
            } else if (55296 <= codePoint_0 ? codePoint_0 <= 57343 : false) {
              var c_9 = numberToChar(65533);
              var _unary__edvuaz_10 = length;
              length = _unary__edvuaz_10 + 1 | 0;
              chars[_unary__edvuaz_10] = c_9;
            } else {
              var c_10 = numberToChar(codePoint_0);
              var _unary__edvuaz_11 = length;
              length = _unary__edvuaz_11 + 1 | 0;
              chars[_unary__edvuaz_11] = c_10;
            }
            tmp$ret$19 = 3;
          }
          index = tmp_0 + tmp$ret$19 | 0;
        } else {
          // Inline function 'kotlinx.io.shr' call
          if (b0 >> 3 === -2) {
            var tmp_2 = index;
            var tmp23 = index;
            var tmp$ret$41;
            $l$block_10: {
              // Inline function 'kotlinx.io.internal.process4Utf8Bytes' call
              if (endIndex <= (tmp23 + 3 | 0)) {
                if (!(65533 === 65533)) {
                  var c_11 = numberToChar((65533 >>> 10 | 0) + 55232 | 0);
                  var _unary__edvuaz_12 = length;
                  length = _unary__edvuaz_12 + 1 | 0;
                  chars[_unary__edvuaz_12] = c_11;
                  var c_12 = numberToChar((65533 & 1023) + 56320 | 0);
                  var _unary__edvuaz_13 = length;
                  length = _unary__edvuaz_13 + 1 | 0;
                  chars[_unary__edvuaz_13] = c_12;
                } else {
                  var c_13 = _Char___init__impl__6a9atx(65533);
                  var _unary__edvuaz_14 = length;
                  length = _unary__edvuaz_14 + 1 | 0;
                  chars[_unary__edvuaz_14] = c_13;
                }
                var tmp_3;
                if (endIndex <= (tmp23 + 1 | 0)) {
                  tmp_3 = true;
                } else {
                  // Inline function 'kotlinx.io.internal.isUtf8Continuation' call
                  // Inline function 'kotlinx.io.and' call
                  tmp_3 = !((_this__u8e3s4[tmp23 + 1 | 0] & 192) === 128);
                }
                if (tmp_3) {
                  tmp$ret$41 = 1;
                  break $l$block_10;
                } else {
                  var tmp_4;
                  if (endIndex <= (tmp23 + 2 | 0)) {
                    tmp_4 = true;
                  } else {
                    // Inline function 'kotlinx.io.internal.isUtf8Continuation' call
                    // Inline function 'kotlinx.io.and' call
                    tmp_4 = !((_this__u8e3s4[tmp23 + 2 | 0] & 192) === 128);
                  }
                  if (tmp_4) {
                    tmp$ret$41 = 2;
                    break $l$block_10;
                  } else {
                    tmp$ret$41 = 3;
                    break $l$block_10;
                  }
                }
              }
              var b0_2 = _this__u8e3s4[tmp23];
              var b1_1 = _this__u8e3s4[tmp23 + 1 | 0];
              // Inline function 'kotlinx.io.internal.isUtf8Continuation' call
              // Inline function 'kotlinx.io.and' call
              if (!((b1_1 & 192) === 128)) {
                if (!(65533 === 65533)) {
                  var c_14 = numberToChar((65533 >>> 10 | 0) + 55232 | 0);
                  var _unary__edvuaz_15 = length;
                  length = _unary__edvuaz_15 + 1 | 0;
                  chars[_unary__edvuaz_15] = c_14;
                  var c_15 = numberToChar((65533 & 1023) + 56320 | 0);
                  var _unary__edvuaz_16 = length;
                  length = _unary__edvuaz_16 + 1 | 0;
                  chars[_unary__edvuaz_16] = c_15;
                } else {
                  var c_16 = _Char___init__impl__6a9atx(65533);
                  var _unary__edvuaz_17 = length;
                  length = _unary__edvuaz_17 + 1 | 0;
                  chars[_unary__edvuaz_17] = c_16;
                }
                tmp$ret$41 = 1;
                break $l$block_10;
              }
              var b2_0 = _this__u8e3s4[tmp23 + 2 | 0];
              // Inline function 'kotlinx.io.internal.isUtf8Continuation' call
              // Inline function 'kotlinx.io.and' call
              if (!((b2_0 & 192) === 128)) {
                if (!(65533 === 65533)) {
                  var c_17 = numberToChar((65533 >>> 10 | 0) + 55232 | 0);
                  var _unary__edvuaz_18 = length;
                  length = _unary__edvuaz_18 + 1 | 0;
                  chars[_unary__edvuaz_18] = c_17;
                  var c_18 = numberToChar((65533 & 1023) + 56320 | 0);
                  var _unary__edvuaz_19 = length;
                  length = _unary__edvuaz_19 + 1 | 0;
                  chars[_unary__edvuaz_19] = c_18;
                } else {
                  var c_19 = _Char___init__impl__6a9atx(65533);
                  var _unary__edvuaz_20 = length;
                  length = _unary__edvuaz_20 + 1 | 0;
                  chars[_unary__edvuaz_20] = c_19;
                }
                tmp$ret$41 = 2;
                break $l$block_10;
              }
              var b3 = _this__u8e3s4[tmp23 + 3 | 0];
              // Inline function 'kotlinx.io.internal.isUtf8Continuation' call
              // Inline function 'kotlinx.io.and' call
              if (!((b3 & 192) === 128)) {
                if (!(65533 === 65533)) {
                  var c_20 = numberToChar((65533 >>> 10 | 0) + 55232 | 0);
                  var _unary__edvuaz_21 = length;
                  length = _unary__edvuaz_21 + 1 | 0;
                  chars[_unary__edvuaz_21] = c_20;
                  var c_21 = numberToChar((65533 & 1023) + 56320 | 0);
                  var _unary__edvuaz_22 = length;
                  length = _unary__edvuaz_22 + 1 | 0;
                  chars[_unary__edvuaz_22] = c_21;
                } else {
                  var c_22 = _Char___init__impl__6a9atx(65533);
                  var _unary__edvuaz_23 = length;
                  length = _unary__edvuaz_23 + 1 | 0;
                  chars[_unary__edvuaz_23] = c_22;
                }
                tmp$ret$41 = 3;
                break $l$block_10;
              }
              var codePoint_1 = 3678080 ^ b3 ^ b2_0 << 6 ^ b1_1 << 12 ^ b0_2 << 18;
              if (codePoint_1 > 1114111) {
                if (!(65533 === 65533)) {
                  var c_23 = numberToChar((65533 >>> 10 | 0) + 55232 | 0);
                  var _unary__edvuaz_24 = length;
                  length = _unary__edvuaz_24 + 1 | 0;
                  chars[_unary__edvuaz_24] = c_23;
                  var c_24 = numberToChar((65533 & 1023) + 56320 | 0);
                  var _unary__edvuaz_25 = length;
                  length = _unary__edvuaz_25 + 1 | 0;
                  chars[_unary__edvuaz_25] = c_24;
                } else {
                  var c_25 = _Char___init__impl__6a9atx(65533);
                  var _unary__edvuaz_26 = length;
                  length = _unary__edvuaz_26 + 1 | 0;
                  chars[_unary__edvuaz_26] = c_25;
                }
              } else if (55296 <= codePoint_1 ? codePoint_1 <= 57343 : false) {
                if (!(65533 === 65533)) {
                  var c_26 = numberToChar((65533 >>> 10 | 0) + 55232 | 0);
                  var _unary__edvuaz_27 = length;
                  length = _unary__edvuaz_27 + 1 | 0;
                  chars[_unary__edvuaz_27] = c_26;
                  var c_27 = numberToChar((65533 & 1023) + 56320 | 0);
                  var _unary__edvuaz_28 = length;
                  length = _unary__edvuaz_28 + 1 | 0;
                  chars[_unary__edvuaz_28] = c_27;
                } else {
                  var c_28 = _Char___init__impl__6a9atx(65533);
                  var _unary__edvuaz_29 = length;
                  length = _unary__edvuaz_29 + 1 | 0;
                  chars[_unary__edvuaz_29] = c_28;
                }
              } else if (codePoint_1 < 65536) {
                if (!(65533 === 65533)) {
                  var c_29 = numberToChar((65533 >>> 10 | 0) + 55232 | 0);
                  var _unary__edvuaz_30 = length;
                  length = _unary__edvuaz_30 + 1 | 0;
                  chars[_unary__edvuaz_30] = c_29;
                  var c_30 = numberToChar((65533 & 1023) + 56320 | 0);
                  var _unary__edvuaz_31 = length;
                  length = _unary__edvuaz_31 + 1 | 0;
                  chars[_unary__edvuaz_31] = c_30;
                } else {
                  var c_31 = _Char___init__impl__6a9atx(65533);
                  var _unary__edvuaz_32 = length;
                  length = _unary__edvuaz_32 + 1 | 0;
                  chars[_unary__edvuaz_32] = c_31;
                }
              } else {
                if (!(codePoint_1 === 65533)) {
                  var c_32 = numberToChar((codePoint_1 >>> 10 | 0) + 55232 | 0);
                  var _unary__edvuaz_33 = length;
                  length = _unary__edvuaz_33 + 1 | 0;
                  chars[_unary__edvuaz_33] = c_32;
                  var c_33 = numberToChar((codePoint_1 & 1023) + 56320 | 0);
                  var _unary__edvuaz_34 = length;
                  length = _unary__edvuaz_34 + 1 | 0;
                  chars[_unary__edvuaz_34] = c_33;
                } else {
                  var c_34 = _Char___init__impl__6a9atx(65533);
                  var _unary__edvuaz_35 = length;
                  length = _unary__edvuaz_35 + 1 | 0;
                  chars[_unary__edvuaz_35] = c_34;
                }
              }
              tmp$ret$41 = 4;
            }
            index = tmp_2 + tmp$ret$41 | 0;
          } else {
            var c_35 = _Char___init__impl__6a9atx(65533);
            var _unary__edvuaz_36 = length;
            length = _unary__edvuaz_36 + 1 | 0;
            chars[_unary__edvuaz_36] = c_35;
            index = index + 1 | 0;
          }
        }
      }
    }
  }
  return concatToString(chars, 0, length);
}
function get_SegmentReadContextImpl() {
  _init_properties_UnsafeBufferOperations_kt__xw75gy();
  return SegmentReadContextImpl;
}
var SegmentReadContextImpl;
function get_SegmentWriteContextImpl() {
  _init_properties_UnsafeBufferOperations_kt__xw75gy();
  return SegmentWriteContextImpl;
}
var SegmentWriteContextImpl;
var BufferIterationContextImpl;
var UnsafeBufferOperations_instance;
function UnsafeBufferOperations_getInstance() {
  return UnsafeBufferOperations_instance;
}
var properties_initialized_UnsafeBufferOperations_kt_2xfgoc;
function _init_properties_UnsafeBufferOperations_kt__xw75gy() {
  if (!properties_initialized_UnsafeBufferOperations_kt_2xfgoc) {
    properties_initialized_UnsafeBufferOperations_kt_2xfgoc = true;
    SegmentReadContextImpl = new SegmentReadContextImpl$1();
    SegmentWriteContextImpl = new SegmentWriteContextImpl$1();
    BufferIterationContextImpl = new BufferIterationContextImpl$1();
  }
}
function init_kotlinx_io_IOException(_this__u8e3s4) {
  captureStack(_this__u8e3s4, _this__u8e3s4.h1o_1);
}
function init_kotlinx_io_EOFException(_this__u8e3s4) {
  captureStack(_this__u8e3s4, _this__u8e3s4.e1l_1);
}
var SegmentPool_instance;
function SegmentPool_getInstance() {
  return SegmentPool_instance;
}
//region block: post-declaration
initMetadataForInterface(Source, 'Source', VOID, VOID, [AutoCloseable]);
initMetadataForInterface(Sink, 'Sink', VOID, VOID, [AutoCloseable]);
protoOf(Buffer).t1m = write$default;
initMetadataForClass(Buffer, 'Buffer', Buffer, VOID, [Source, Sink]);
initMetadataForClass(PeekSource, 'PeekSource', VOID, VOID, [AutoCloseable]);
initMetadataForClass(RealSource, 'RealSource', VOID, VOID, [Source]);
initMetadataForCompanion(Companion);
initMetadataForClass(Segment, 'Segment');
initMetadataForClass(SegmentCopyTracker, 'SegmentCopyTracker');
initMetadataForObject(AlwaysSharedCopyTracker, 'AlwaysSharedCopyTracker');
initMetadataForObject(UnsafeBufferOperations, 'UnsafeBufferOperations');
initMetadataForClass(SegmentReadContextImpl$1);
initMetadataForClass(SegmentWriteContextImpl$1);
initMetadataForClass(BufferIterationContextImpl$1);
initMetadataForClass(IOException, 'IOException', IOException.i1o);
initMetadataForClass(EOFException, 'EOFException', EOFException.l1o);
initMetadataForObject(SegmentPool, 'SegmentPool');
//endregion
//region block: init
Companion_instance = new Companion();
UnsafeBufferOperations_instance = new UnsafeBufferOperations();
SegmentPool_instance = new SegmentPool();
//endregion
//region block: exports
export {
  Buffer as Buffergs925ekssbch,
  EOFException as EOFExceptionh831u25jcq9n,
  IOException as IOException1wyutdmfe71nu,
  Source as Source1shr0ps16u4p4,
  indexOf_1 as indexOf29nspdgx2e3ap,
  readByteArray_0 as readByteArray1fhzfwi2j014k,
  readByteArray as readByteArray1ri21h2rciakw,
  readByteString as readByteString2hnsbql6t4ads,
  readString as readString2nvggcfaijfhd,
  readString_0 as readString3v6duspiz33tv,
  readString_1 as readStringo8i62qxt5m4m,
  writeString as writeString33ca4btrgctw7,
};
//endregion

//# sourceMappingURL=kotlinx-io-kotlinx-io-core.mjs.map
