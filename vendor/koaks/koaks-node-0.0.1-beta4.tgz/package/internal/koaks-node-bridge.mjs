import {
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  Unit_instance104q5opgivhr8 as Unit_instance,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  VOID7hggqo3abtya as VOID,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  emptyMapr06gerzljqtm as emptyMap,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  toString1pkumu07cwy4m as toString,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  equals2au1ep9vhcato as equals,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  Result3t1vadv16kmzk as Result,
  CancellationException3b36o9qz53rgr as CancellationException,
  Long2qws0ah9gnpki as Long,
  removeAll3cm9rh0qak2y6 as removeAll,
  ArrayList3it5z8td81qkl as ArrayList,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  toList3jhuyej2anx2q as toList,
  asReversed2y2qzr7vrqd5 as asReversed,
  asReversed308kw52j6ls1u as asReversed_0,
  addAll1k27qatfgp3k5 as addAll,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  isInterface3d6p8outrmvmk as isInterface,
  hashCodeq5arwsb9dgti as hashCode,
  KtMap140uvy3s5zad8 as KtMap,
  emptyList1g2z5xcrvp2zy as emptyList,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  toString30pk9tzaqopn as toString_0,
  to2cs3ny02qtbcb as to,
  toLongkk4waq8msp1k as toLong,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  isBlank1dvkhjjvox3p0 as isBlank,
  StringCompanionObject_instance2odz3s3zbrixa as StringCompanionObject_instance,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  listOfNotNull2woi2boe01ub4 as listOfNotNull,
  singleo93pzdgfc557 as single,
  copyToArray2j022khrow2yi as copyToArray,
  listOfvhqybd2zx248 as listOf,
  UnsupportedOperationException2tkumpmhredt3 as UnsupportedOperationException,
  stackTraceToString2670q6lbhdojj as stackTraceToString,
  RuntimeException1r3t0zl97011n as RuntimeException,
  captureStack1fzi4aczwc4hg as captureStack,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  toString35i91qxh73cps as toString_1,
  LinkedHashSet2tkztfx86kyx2 as LinkedHashSet,
} from './kotlin-kotlin-stdlib.mjs';
import {
  JsonObjectee06ihoeeiqj as JsonObject,
  JsonObjectBuilder2nl6rv6vdayuk as JsonObjectBuilder,
  get_jsonPrimitivez17tyd5rw1ql as get_jsonPrimitive,
  JsonPrimitive2fp8648nd60dn as JsonPrimitive,
  JsonNull_getInstance1q6cansbfp6ip as JsonNull_getInstance,
  JsonPrimitiveolttw629wj53 as JsonPrimitive_0,
  JsonArrayBuilderu8edol6ui3pj as JsonArrayBuilder,
  get_jsonObject2u4z2ch1uuca9 as get_jsonObject,
  Companion_instance20spzcd6u6icp as Companion_instance_0,
  JsonArray2urf8ey7u44sd as JsonArray,
  JsonPrimitive3ttzjh2ft5dnx as JsonPrimitive_1,
  JsonNull2liwjj96vm0w2 as JsonNull,
  JsonPrimitive1xkjzc5d7ihuv as JsonPrimitive_2,
  get_contentOrNull35s97cgi8z9eo as get_contentOrNull,
  get_intOrNulld29i64b3udf as get_intOrNull,
  get_longOrNull1kg1ha9scz5pa as get_longOrNull,
  get_doubleOrNull2fo14gjg922um as get_doubleOrNull,
  get_booleanOrNull376axlcpdhkmo as get_booleanOrNull,
  Companion_instance2xnbmyqibbp8t as Companion_instance_1,
  Jsonsmkyu9xjl7fv as Json,
} from './kotlinx-serialization-kotlinx-serialization-json.mjs';
import {
  _ThreadId___init__impl__wwh4n0awn1y460sfsm as _ThreadId___init__impl__wwh4n0,
  AccessMode_READ_getInstance1ntzu2czr0xsh as AccessMode_READ_getInstance,
  AccessMode_WRITE_getInstance2kgbqe100xyz0 as AccessMode_WRITE_getInstance,
  withRuntimeResource367q7asqscsa1 as withRuntimeResource,
  Key_instance284ivmzop7sd9 as Key_instance,
  RunId2h3r3ph0106mg as RunId,
  _AgentId___init__impl__m6udbt1v24axsjntasa as _AgentId___init__impl__m6udbt,
  AgentId36zdhs0111bpe as AgentId,
  taskGrapht7fjnnbp3lyv as taskGraph,
  CircuitBreakerPolicy29egv8iqr7wfb as CircuitBreakerPolicy,
  SupervisionPolicyzw6zkdv2xerw as SupervisionPolicy,
  _ContextRef___get_id__impl__uspq4f1d5eefgn28dbn as _ContextRef___get_id__impl__uspq4f,
  _ContextRef___init__impl__laq00z36p4flhrwnis6 as _ContextRef___init__impl__laq00z,
  Companion_getInstance176qkrnolkas as Companion_getInstance,
  Failed3jeye2l9srbvp as Failed,
  Completed3p9issjhh04x2 as Completed,
  AgentResultnrtvmxr4wdzg as AgentResult,
  ContextScope_PRIVATE_getInstancevzkuuvh6xefg as ContextScope_PRIVATE_getInstance,
  Inherit_instance3eojkg6b8g884 as Inherit_instance,
  Ephemeral_instanceg3x5ygrswisy as Ephemeral_instance,
  Threadwi21kgd5izpm as Thread,
  ChildFailurePolicy_PROPAGATE_getInstance2j6u9t2rbs646 as ChildFailurePolicy_PROPAGATE_getInstance,
  ChildFailurePolicy_CAPTURE_getInstancexk3kgeds970j as ChildFailurePolicy_CAPTURE_getInstance,
  AgentRuntime22n2er2c2jtiy as AgentRuntime,
  RunId__hashCode_impl_4harkc3izogbyeztm7f as RunId__hashCode_impl_4harkc,
  Quota3940mann21mmz as Quota,
  ToolOutputStream_Stdout_getInstance3kl2teq0u5jv9 as ToolOutputStream_Stdout_getInstance,
  ToolOutputStream_Stderr_getInstance3dchan4ksqfap as ToolOutputStream_Stderr_getInstance,
  Output3d618xddl0jua as Output,
  Status1jc5xgqdyrntu as Status,
  Custom2x7k1rxqer1y1 as Custom,
  ContextRef1cmaoz2m0ivax as ContextRef,
  ContextScope_GLOBAL_getInstance282km2iut510a as ContextScope_GLOBAL_getInstance,
  ContextScope_TASK_getInstance3v34m6yykq14s as ContextScope_TASK_getInstance,
  _RunId___init__impl__jfg80d39gh05ipyy9q9 as _RunId___init__impl__jfg80d,
  _AgentId___get_value__impl__1mym7n37pn4brtfygwu as _AgentId___get_value__impl__1mym7n,
  _RunId___get_value__impl__30zeivp33yqnh572zv as _RunId___get_value__impl__30zeiv,
  ThreadId21scpc0nj57qc as ThreadId,
  _ThreadId___get_value__impl__tytyxcp6hybs6mx9vr as _ThreadId___get_value__impl__tytyxc,
  TurnIdo7of7ptpmk5l as TurnId,
  _TurnId___get_value__impl__w6r3h917udioonb9tb4 as _TurnId___get_value__impl__w6r3h9,
  RuntimeMessage1673boi5j0x1r as RuntimeMessage,
  agent3roqjtkgj4v5n as agent,
  Key_instance3rikaljb0525l as Key_instance_0,
  ContextualTool2pa89d93ed3rs as ContextualTool,
  NoMemoryProvider_getInstance3r3q0ztr99x5e as NoMemoryProvider_getInstance,
  WindowMemoryProviderzvoz1awvz4m1 as WindowMemoryProvider,
  _MemoryProviderId___init__impl__vkxutoeycvcgh355zg as _MemoryProviderId___init__impl__vkxuto,
  FixedMemoryProvider3niknr1e3f1m2 as FixedMemoryProvider,
  KtorTransport1p3ssurzs5o3g as KtorTransport,
  ModelScopeydnzgbv5k1rk as ModelScope,
  toLanguageModel1yppatg5qyvic as toLanguageModel,
  _MemoryProviderId___get_value__impl__90yl2011zkzf5x46sgz as _MemoryProviderId___get_value__impl__90yl20,
  TurnRetention_CompletedOnly_getInstance3gs3fb1a6idq7 as TurnRetention_CompletedOnly_getInstance,
  TurnRetention_InterruptedIfSideEffects_getInstance1zzkb2uwwx4m9 as TurnRetention_InterruptedIfSideEffects_getInstance,
  TurnRetention_Interrupted_getInstance1clj3n1yfuiga as TurnRetention_Interrupted_getInstance,
  ThreadMemory1dswgl9efn3yf as ThreadMemory,
  Message1x6kaj8ypdoee as Message,
  TranscriptBasisi4fgd064euay as TranscriptBasis,
  McpTooltkaeo5pntkj4 as McpTool,
  _SkillId___get_value__impl__n6yl352zpgzt8cenesl as _SkillId___get_value__impl__n6yl35,
  SkillDescriptor3nmkeg8c0c71s as SkillDescriptor,
  SkillDefinition2wt50z036xune as SkillDefinition,
  _SkillId___init__impl__ou80gj2bgk3xbf1xti2 as _SkillId___init__impl__ou80gj,
  SkillResourceCursor23b789okxwrx4 as SkillResourceCursor,
  SkillResourceuo2pwlwaztap as SkillResource,
  AgentListener30c3usj4bnd9e as AgentListener,
  Proceed_instance2giofcc080wt1 as Proceed_instance,
  Deny3597ostucic39 as Deny,
  ProceedWith2cht2h4fqey0y as ProceedWith,
  Hook1u2wzh55ycpu8 as Hook,
  Companion_instance2khz9mlqwxdw1 as Companion_instance_2,
  Companion_getInstancextwtaoaved2h as Companion_getInstance_0,
  OutputSpecdv8gu1h59g62 as OutputSpec,
  ModelCallPhase_Normal_getInstance1007ql54uck2h as ModelCallPhase_Normal_getInstance,
  ToolSchema2ufbizf6sucuk as ToolSchema,
  Text_instance936fuxqirkv3 as Text_instance,
  ModelRequest2fvlnwc92shgb as ModelRequest,
  JsonSchema1bzd59uqo2uv as JsonSchema,
  JsonObject_instance30hvkp8z8mfx9 as JsonObject_instance,
  Failurekyf28q0z9hiq as Failure,
  Success3mq33eta8bi8i as Success,
  ToolError3d4h05fyqa7n2 as ToolError,
  ToolCallsfyoaxshhyk as ToolCall,
  Finished4z9e5g7v1wyk as Finished,
  _ProviderId___get_value__impl__xo1tux1l8qcslmantkx as _ProviderId___get_value__impl__xo1tux,
  ProviderEvent1t0ljokdqil6g as ProviderEvent,
  ToolCallCompleted225u0jsfjmco7 as ToolCallCompleted,
  ItemRef3v4f9mi7oyrky as ItemRef,
  _ItemRef___get_value__impl__fpjuyb3vqbahagzpip9 as _ItemRef___get_value__impl__fpjuyb,
  ToolCallDelta1owom9vbem28s as ToolCallDelta,
  ItemAddede8lfykdsw28t as ItemAdded,
  ReasoningDeltaytmmln995w27 as ReasoningDelta,
  TextDeltaq9h7728thclc as TextDelta,
  CheckpointUpdated1ph6xqbn4fzwh as CheckpointUpdated,
  Started1sf5a44qjgp0u as Started,
  _ItemRef___init__impl__ipmeexzal33vlj7m90 as _ItemRef___init__impl__ipmeex,
  _ProviderId___init__impl__nor0vf25jyftll92y3b as _ProviderId___init__impl__nor0vf,
  Failed2mkg32d93x5tt as Failed_0,
  Incompletel3n48a644js as Incomplete,
  Completedf7bahq5rqxjz as Completed_0,
  SuspendTerminationPolicy2ikqiyuycj12h as SuspendTerminationPolicy,
  SuspendErrorPolicy11qpiip1gm60s as SuspendErrorPolicy,
  McpClientConfig1y0d1kdip2fi2 as McpClientConfig,
  DefaultMcpClient2ix95c54p0pzm as DefaultMcpClient,
  Continue_instance2wm3hyifqn3li as Continue_instance,
  Custom12bedglhf154j as Custom_0,
  Stop1npjwdgx12etk as Stop,
  AgentStateq0h4yihlrppz as AgentState,
  Propagate_instance296jix3pc87l6 as Propagate_instance,
  Retry178h6bplcsekg as Retry,
  Substitute2awks4hhz3ray as Substitute,
  AgentErrorv0js0hohaolw as AgentError,
  ContextAccessExceptionzmtupk6xwihp as ContextAccessException,
  AgentIdConflictException3kleahgvhdh5k as AgentIdConflictException,
  Timeoutz57w70r5trqc as Timeout,
  PreparationError1mrn3vyzs5xe4 as PreparationError,
  SkillId2fmfj122nhxl as SkillId,
  SkillError383wa1og498ng as SkillError,
  ToolNotFound1yo0rzmynl0ge as ToolNotFound,
  ParseError1n78h8ml9fvik as ParseError,
  ModelErrori9ofbqyilwwf as ModelError,
  Other3cy8r7ld3h1ux as Other,
  Cancelled_instance1itykyif0mdkk as Cancelled_instance,
  ContentFilter_instance10ein6t2i9053 as ContentFilter_instance,
  MaxOutputTokens_instance2tn5unomigxz7 as MaxOutputTokens_instance,
  RunBudgetTokens2ht23ihfgefv0 as RunBudgetTokens,
  RunBudgetSteps280y2j9i34mbs as RunBudgetSteps,
  MaxTokenss3xql3j4ut43 as MaxTokens,
  MaxSteps2zextkr4xhmlx as MaxSteps,
  Terminatedk6xeqdaa3bel as Terminated,
  Incomplete3m6d5sq06dgkj as Incomplete_0,
  Failed19uwo7uuwioir as Failed_1,
  Terminated1yey6zz984p1a as Terminated_0,
  Incomplete22h0otjfc9qo as Incomplete_1,
  Completed39qr5embh95o2 as Completed_1,
  StepCompleted1ne9eg3zpjqsd as StepCompleted,
  ToolProgressi5m8ak0r1j7m as ToolProgress,
  ToolResult2ovl89m0pb3ia as ToolResult,
  ToolCallRequested3isqene1jrpyi as ToolCallRequested,
  ReasoningDelta2dbne4w7qnc6h as ReasoningDelta_0,
  TextDeltaykhe546olrru as TextDelta_0,
  ProviderItem17hp0vuxmlwze as ProviderItem,
  ReasoningSummary2dl0lxzty5z0 as ReasoningSummary,
  ToolResult2fndzcq38kgpy as ToolResult_0,
  ToolCall27jatgdodcelb as ToolCall_0,
  Audio23kgaookuy0z2 as Audio,
  Image2x6strlw6vlny as Image,
  Texttoggh19xftus as Text,
  Genericlzofu41340v as Generic,
  FileCitationygaccnkkyy7b as FileCitation,
  UrlCitation1viudi8jaexgt as UrlCitation,
  Companion_instance13097inxmcdi as Companion_instance_3,
  valueOf27dlu7ag21wc7 as valueOf,
  valueOf311z7t4cy802c as valueOf_0,
  ProviderScopedId2kn7so5x8kdlf as ProviderScopedId,
  CheckpointScope_InRun_getInstancehlz4h897r3cf as CheckpointScope_InRun_getInstance,
  CheckpointScope_CrossTurn_getInstance3flwfeb5t4aet as CheckpointScope_CrossTurn_getInstance,
  ProviderCheckpoint1ql47nh16mrq3 as ProviderCheckpoint,
  MemoryView36zuxzo826bia as MemoryView,
  Interrupted28j48dsr3pw62 as Interrupted,
  Completed_instancex7pny2bbjcdr as Completed_instance,
  Policy1tfroprjy15wd as Policy,
  Incomplete2f3jgrqbbwtg7 as Incomplete_2,
  Failed_instance170krqyyzqjb6 as Failed_instance,
  Cancelled_instance1xvdu9qggy3e5 as Cancelled_instance_0,
  HistoryGap1nlmsgc807ffz as HistoryGap,
  Lifecycle3kshxq8hzkipw as Lifecycle,
  Agent1la3ofrca8ngj as Agent,
  CircuitOpenjbljw57iigzs as CircuitOpen,
  Retrying24x66k5422sl1 as Retrying,
  SideEffectRollback14xwdx2gvwcoa as SideEffectRollback,
  UnhandledChildFailure3ktvfarkcohqb as UnhandledChildFailure,
  Cancelled26l1r8k2esjma as Cancelled,
  Failed3jso9l848cuqa as Failed_2,
  Terminated1k84iml5dt6u5 as Terminated_1,
  Incomplete1pu1upcmhhf6b as Incomplete_3,
  Finished2tky25kkkpuz9 as Finished_0,
  Resumed2u5yxlh7njkw8 as Resumed,
  Suspended1nd4z7dmshla8 as Suspended,
  Waiting10r2pml3uv9hn as Waiting,
  Running3t0jfgt4diep8 as Running,
  Spawned3htspwmgjbg6d as Spawned,
} from './koaks-core.mjs';
import {
  Flow3375h4584bu3w as Flow,
  cancelAndJoinca5q7i6o6enf as cancelAndJoin,
  withTimeoutbx36s8h1ezlh as withTimeout,
  TimeoutCancellationException198b5zwr3v3uw as TimeoutCancellationException,
  CoroutineStart_LAZY_getInstance1py9n0s9t79vw as CoroutineStart_LAZY_getInstance,
  launch1c91vkjzdi9sd as launch,
  Key_instance3o7pj7ik1b183 as Key_instance_1,
  joinAll1exxrn3zbq8yl as joinAll,
  FlowCollector26clgpmzihvke as FlowCollector,
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
  Dispatchers_getInstance1nk2l7rcqz5wi as Dispatchers_getInstance,
  SupervisorJobythnfxkr3jxc as SupervisorJob,
  CoroutineScopelux7s7zphw7e as CoroutineScope_0,
  promise1ky6tawqaxbt4 as promise,
  await3mtczq8ld88gb as await_0,
  flow3tazazxj2t7g4 as flow,
  withContext7utithjmd2zo as withContext,
} from './kotlinx-coroutines-core.mjs';
import {
  openaicl8tzbjx9bid as openai,
  openaiResponsess1z0i2bwwp6 as openaiResponses,
  ResponsesStateMode_ServerStored_getInstance1q4xwl1q3bxkc as ResponsesStateMode_ServerStored_getInstance,
  ResponsesStateMode_Conversation_getInstance3qpbkvax9clq3 as ResponsesStateMode_Conversation_getInstance,
  ResponsesStateMode_Replayable_getInstancetxnvwf44qxq8 as ResponsesStateMode_Replayable_getInstance,
} from './koaks-model-provider-openai.mjs';
import { qwen3m5zqusvdcxsm as qwen } from './koaks-model-provider-qwen.mjs';
import { anthropic200c8euko87qc as anthropic } from './koaks-model-provider-anthropic.mjs';
import { ollama3bi4tj0plt4pm as ollama } from './koaks-model-provider-ollama.mjs';
import { serializer1x79l67jvwntn as serializer } from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import { VectorMemoryProvider3fzzdfryhom7q as VectorMemoryProvider } from './koaks-koaks-memory-vector.mjs';
import {
  InMemoryAppendMemoryProvider36fa6bv0tgc8o as InMemoryAppendMemoryProvider,
  InMemorySummaryStateStore2chhijrm1nln0 as InMemorySummaryStateStore,
  SummarizingMemoryProvider29b3hnp93xy7 as SummarizingMemoryProvider,
  SummaryCheckpointbdrwa4y2hyh1 as SummaryCheckpoint,
  Failed1jq287m0zrctq as Failed_3,
  Completed2mtbtu49gr00m as Completed_2,
  Started1ko4w51qve81z as Started_0,
  CompactionObserver30xzoxxaw78du as CompactionObserver,
} from './koaks-koaks-memory-summarizing.mjs';
import { Companion_getInstance3n3majy04gpy as Companion_getInstance_1 } from './okio-parent-okio.mjs';
import './ktor-ktor-client-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class KoaksBridge$dispatch$o$collect$slambda {
  constructor($$this$unsafeFlow) {
    this.z7z_1 = $$this$unsafeFlow;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_0.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$dispatch$o$collect$slambda_0 {
  constructor($$this$unsafeFlow) {
    this.b80_1 = $$this$unsafeFlow;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_1.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$dispatch$o$collect$slambda_1 {
  constructor($$this$unsafeFlow) {
    this.d80_1 = $$this$unsafeFlow;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_2.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$streamAgent$o$collect$slambda {
  constructor($$this$unsafeFlow) {
    this.a81_1 = $$this$unsafeFlow;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_4.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolWithResource$slambda$slambda$slambda {
  constructor(this$0, $params) {
    this.r81_1 = this$0;
    this.s81_1 = $params;
  }
  vd($completion) {
    return this.r81_1.k80_1.t81(string(this.s81_1, 'callback_id'), VOID, $completion);
  }
}
class KoaksBridge$toolWithResource$slambda$slambda {
  constructor(this$0, $params) {
    this.w81_1 = this$0;
    this.x81_1 = $params;
  }
  vd($completion) {
    // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
    // Inline function 'kotlin.js.getCoroutineContext' call
    var tmp0_elvis_lhs = $completion.lc().yc(Key_instance);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw NodeBridgeException.d82('lifecycle_error', 'Resource operation has no execution branch');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var executionContext = tmp;
    return executionContext.d5s(KoaksBridge$toolWithResource$slambda$slambda$slambda_0(this.w81_1, this.x81_1), $completion);
  }
}
class KoaksBridge$toolIpcReceive$slambda$slambda {
  constructor($execution) {
    this.p82_1 = $execution;
  }
  vd($completion) {
    return this.p82_1.h82_1.n78_1.d6y(this.p82_1.h82_1.i78_1).n1a($completion);
  }
}
class KoaksBridge$toolIpcRequest$slambda$slambda$slambda {
  constructor($execution, $message) {
    this.q82_1 = $execution;
    this.r82_1 = $message;
  }
  vd($completion) {
    return this.q82_1.h82_1.n78_1.w76(this.r82_1, $completion);
  }
}
class KoaksBridge$toolIpcRequest$slambda$slambda {
  constructor(this$0, $params, $execution, $message) {
    this.u82_1 = this$0;
    this.v82_1 = $params;
    this.w82_1 = $execution;
    this.x82_1 = $message;
  }
  vd($completion) {
    return withIpcTimeout(this.u82_1, this.v82_1, KoaksBridge$toolIpcRequest$slambda$slambda$slambda_0(this.w82_1, this.x82_1), $completion);
  }
}
class KoaksBridge$toolIpcSubscribe$slambda$o$collect$slambda {
  constructor($$this$unsafeFlow) {
    this.b83_1 = $$this$unsafeFlow;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_15.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolIpcSubscribe$2$$inlined$map$1 {
  constructor($this) {
    this.c83_1 = $this;
  }
  o6d(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_3.bind(VOID, this, collector), $completion);
  }
  g1c(collector, $completion) {
    return this.o6d(collector, $completion);
  }
}
class KoaksBridge$runtimeIpcRequest$slambda$slambda {
  constructor(this$0, $params, $target) {
    this.g83_1 = this$0;
    this.h83_1 = $params;
    this.i83_1 = $target;
  }
  vd($completion) {
    return this.g83_1.n80_1.m6o_1.w76(toRuntimeMessage(this.h83_1, this.g83_1.n80_1.m6o_1.t76(), null, this.i83_1), $completion);
  }
}
class KoaksBridge$runtimeIpcSubscribe$o$collect$slambda {
  constructor($$this$unsafeFlow) {
    this.j83_1 = $$this$unsafeFlow;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_18.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$startSubscription$slambda$slambda {
  constructor(this$0, $callbackId) {
    this.l83_1 = this$0;
    this.m83_1 = $callbackId;
  }
  r83(event, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_19.bind(VOID, this, event), $completion);
  }
  td(p1, $completion) {
    return this.r83(p1 instanceof JsonObject ? p1 : THROW_CCE(), $completion);
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0 {
  constructor(function_0) {
    this.e84_1 = function_0;
  }
  t1c(value, $completion) {
    return this.e84_1(value, $completion);
  }
  n4() {
    return this.e84_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_0 {
  constructor(function_0) {
    this.f84_1 = function_0;
  }
  t1c(value, $completion) {
    return this.f84_1(value, $completion);
  }
  n4() {
    return this.f84_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_1 {
  constructor(function_0) {
    this.g84_1 = function_0;
  }
  t1c(value, $completion) {
    return this.g84_1(value, $completion);
  }
  n4() {
    return this.g84_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_2 {
  constructor(function_0) {
    this.h84_1 = function_0;
  }
  t1c(value, $completion) {
    return this.h84_1(value, $completion);
  }
  n4() {
    return this.h84_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_3 {
  constructor(function_0) {
    this.i84_1 = function_0;
  }
  t1c(value, $completion) {
    return this.i84_1(value, $completion);
  }
  n4() {
    return this.i84_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class KoaksBridge$request$slambda {
  constructor(this$0, $method, $paramsJson) {
    this.w7z_1 = this$0;
    this.x7z_1 = $method;
    this.y7z_1 = $paramsJson;
  }
  r1f($this$promise, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8.bind(VOID, this, $this$promise), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$dispatch$$inlined$map$1 {
  constructor($this) {
    this.a80_1 = $this;
  }
  o6d(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy.bind(VOID, this, collector), $completion);
  }
  g1c(collector, $completion) {
    return this.o6d(collector, $completion);
  }
}
class KoaksBridge$dispatch$$inlined$map$2 {
  constructor($this) {
    this.c80_1 = $this;
  }
  o6d(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_0.bind(VOID, this, collector), $completion);
  }
  g1c(collector, $completion) {
    return this.o6d(collector, $completion);
  }
}
class KoaksBridge$dispatch$$inlined$map$3 {
  constructor($this) {
    this.e80_1 = $this;
  }
  o6d(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_1.bind(VOID, this, collector), $completion);
  }
  g1c(collector, $completion) {
    return this.o6d(collector, $completion);
  }
}
class KoaksBridge$runAgent$slambda {
  constructor($params, $structured, this$0, $record) {
    this.f80_1 = $params;
    this.g80_1 = $structured;
    this.h80_1 = this$0;
    this.i80_1 = $record;
  }
  vd($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_3.bind(VOID, this), $completion);
  }
}
class KoaksBridge$streamAgent$$inlined$map$1 {
  constructor($this) {
    this.b81_1 = $this;
  }
  o6d(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_2.bind(VOID, this, collector), $completion);
  }
  g1c(collector, $completion) {
    return this.o6d(collector, $completion);
  }
}
class KoaksBridge$resumeAgent$slambda {
  constructor(this$0, $record, $params, $options) {
    this.c81_1 = this$0;
    this.d81_1 = $record;
    this.e81_1 = $params;
    this.f81_1 = $options;
  }
  vd($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_5.bind(VOID, this), $completion);
  }
}
class KoaksBridge$submit$lambda$slambda {
  constructor(this$0, $inputCallback) {
    this.g81_1 = this$0;
    this.h81_1 = $inputCallback;
  }
  j79(deps, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_6.bind(VOID, this, deps), $completion);
  }
  td(p1, $completion) {
    return this.j79((!(p1 == null) ? isInterface(p1, KtMap) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$spawnSupervised$slambda {
  constructor(this$0, $callback) {
    this.l81_1 = this$0;
    this.m81_1 = $callback;
  }
  j84(attempt, last, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_7.bind(VOID, this, attempt, last), $completion);
  }
  ud(p1, p2, $completion) {
    var tmp = (!(p1 == null) ? typeof p1 === 'number' : false) ? p1 : THROW_CCE();
    return this.j84(tmp, (!(p2 == null) ? isInterface(p2, AgentResult) : false) ? p2 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$handleResult$slambda {
  constructor($record) {
    this.q81_1 = $record;
  }
  k84(it, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_8.bind(VOID, this, it), $completion);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolWithResource$slambda {
  constructor($params, this$0) {
    this.u81_1 = $params;
    this.v81_1 = this$0;
  }
  k84(it, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_9.bind(VOID, this, it), $completion);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolPutContext$slambda {
  constructor($params) {
    this.l84_1 = $params;
  }
  k84(execution, $completion) {
    var scope = toolContextScope(this.l84_1);
    // Inline function 'kotlin.takeIf' call
    var this_0 = new RunId(execution.h82_1.i78_1);
    var tmp;
    this_0.z6w_1;
    if (scope.equals(ContextScope_PRIVATE_getInstance())) {
      tmp = this_0;
    } else {
      tmp = null;
    }
    var tmp_0 = tmp;
    var owner = tmp_0 == null ? null : tmp_0.z6w_1;
    return JsonPrimitive_0(_ContextRef___get_id__impl__uspq4f(execution.h82_1.o78_1.k75(items(this.l84_1), scope, owner)));
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolDeltaContext$slambda {
  constructor($params) {
    this.m84_1 = $params;
  }
  k84(execution, $completion) {
    var scope = toolContextScope(this.m84_1);
    // Inline function 'kotlin.takeIf' call
    var this_0 = new RunId(execution.h82_1.i78_1);
    var tmp;
    this_0.z6w_1;
    if (scope.equals(ContextScope_PRIVATE_getInstance())) {
      tmp = this_0;
    } else {
      tmp = null;
    }
    var tmp_0 = tmp;
    var owner = tmp_0 == null ? null : tmp_0.z6w_1;
    return JsonPrimitive_0(_ContextRef___get_id__impl__uspq4f(execution.h82_1.o78_1.l75(_ContextRef___init__impl__laq00z(string(this.m84_1, 'parent_ref')), items(this.m84_1), scope, owner)));
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolResolveContext$slambda {
  constructor($params) {
    this.n84_1 = $params;
  }
  k84(execution, $completion) {
    // Inline function 'kotlinx.serialization.json.buildJsonArray' call
    var builder = new JsonArrayBuilder();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = execution.h82_1.o78_1.i6z(_ContextRef___init__impl__laq00z(string(this.n84_1, 'ref')), execution.h82_1.i78_1).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      builder.p3o(toJson_18(element));
    }
    return builder.i3n();
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolSpawnChild$slambda {
  constructor(this$0, $params) {
    this.o84_1 = this$0;
    this.p84_1 = $params;
  }
  k84(execution, $completion) {
    var tmp0_elvis_lhs = this.o84_1.o80_1.h3(string(this.p84_1, 'agent_key'));
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw NodeBridgeException.d82('cross_runtime_agent', 'spawnChild requires an Agent from the same KoaksRuntime');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var child = tmp;
    var tmp1_elvis_lhs = objectOrNull(this.p84_1, 'options');
    var options = tmp1_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp1_elvis_lhs;
    var configured = objectOrNull(options, 'conversation');
    var tmp_0;
    if (configured == null) {
      tmp_0 = Inherit_instance;
    } else {
      var tmp2_elvis_lhs = stringOrNull(configured, 'type');
      var tmp_1;
      switch (tmp2_elvis_lhs == null ? 'inherit' : tmp2_elvis_lhs) {
        case 'inherit':
          tmp_1 = Inherit_instance;
          break;
        case 'ephemeral':
          tmp_1 = Ephemeral_instance;
          break;
        case 'thread':
          tmp_1 = new Thread(_ThreadId___init__impl__wwh4n0(string(configured, 'thread_id')));
          break;
        default:
          throw IllegalArgumentException.t("unknown child conversation '" + string(configured, 'type') + "'");
      }
      tmp_0 = tmp_1;
    }
    var conversation = tmp_0;
    var tmp4_elvis_lhs = stringOrNull(options, 'failure_policy');
    var tmp_2;
    switch (tmp4_elvis_lhs == null ? 'propagate' : tmp4_elvis_lhs) {
      case 'propagate':
        tmp_2 = ChildFailurePolicy_PROPAGATE_getInstance();
        break;
      case 'capture':
        tmp_2 = ChildFailurePolicy_CAPTURE_getInstance();
        break;
      default:
        throw IllegalArgumentException.t("unknown child failure policy '" + string(options, 'failure_policy') + "'");
    }
    var failurePolicy = tmp_2;
    var tmp_3 = string(this.p84_1, 'input');
    var tmp6_elvis_lhs = intOrNull(options, 'priority');
    var tmp_4 = tmp6_elvis_lhs == null ? 0 : tmp6_elvis_lhs;
    var tmp7_safe_receiver = objectOrNull(options, 'quota');
    var handle = execution.h82_1.m6z(child.z80_1.w80_1, tmp_3, tmp_4, tmp7_safe_receiver == null ? null : toQuota(tmp7_safe_receiver), contextRefs(options), failurePolicy, conversation);
    var handleId = nextId(this.o84_1, 'handle');
    var tmp0 = this.o84_1.q80_1;
    // Inline function 'kotlin.collections.set' call
    var value = new HandleRecord(child.y80_1, handle, execution.h82_1.i78_1);
    tmp0.k3(handleId, value);
    return handleDescriptor(handleId, handle, execution.h82_1.i78_1);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolIpcSend$slambda {
  constructor(this$0, $params) {
    this.e82_1 = this$0;
    this.f82_1 = $params;
  }
  k84(execution, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_10.bind(VOID, this, execution), $completion);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolIpcReceive$slambda {
  k84(execution, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_11.bind(VOID, this, execution), $completion);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolIpcRequest$slambda {
  constructor(this$0, $params) {
    this.s82_1 = this$0;
    this.t82_1 = $params;
  }
  k84(execution, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_12.bind(VOID, this, execution), $completion);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolIpcReply$slambda {
  constructor($params) {
    this.y82_1 = $params;
  }
  k84(execution, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_13.bind(VOID, this, execution), $completion);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolIpcPublish$slambda {
  constructor($params) {
    this.a83_1 = $params;
  }
  k84(execution, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_14.bind(VOID, this, execution), $completion);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolIpcSubscribe$slambda {
  constructor(this$0, $params) {
    this.q84_1 = this$0;
    this.r84_1 = $params;
  }
  k84(execution, $completion) {
    var tmp = this.q84_1.p80_1.h3(new AgentId(execution.h82_1.j78_1));
    var tmp_0 = string(this.r84_1, 'callback_id');
    // Inline function 'kotlinx.coroutines.flow.map' call
    // Inline function 'kotlinx.coroutines.flow.unsafeTransform' call
    var this_0 = execution.h82_1.n78_1.g76(string(this.r84_1, 'topic'));
    // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call
    var tmp$ret$2 = new KoaksBridge$toolIpcSubscribe$2$$inlined$map$1(this_0);
    return startSubscription(this.q84_1, tmp, tmp_0, tmp$ret$2, execution.g82_1);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$toolProgress$slambda {
  constructor($params) {
    this.d83_1 = $params;
  }
  k84(execution, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_16.bind(VOID, this, execution), $completion);
  }
  td(p1, $completion) {
    return this.k84(p1 instanceof Execution ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$runtimeIpcRequest$slambda {
  constructor(this$0, $params) {
    this.e83_1 = this$0;
    this.f83_1 = $params;
  }
  vd($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_17.bind(VOID, this), $completion);
  }
}
class KoaksBridge$runtimeIpcSubscribe$$inlined$map$1 {
  constructor($this) {
    this.k83_1 = $this;
  }
  o6d(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_4.bind(VOID, this, collector), $completion);
  }
  g1c(collector, $completion) {
    return this.o6d(collector, $completion);
  }
}
class KoaksBridge$withIpcTimeout$slambda {
  constructor($block) {
    this.s84_1 = $block;
  }
  r1f($this$withTimeout, $completion) {
    return this.s84_1($completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge$startSubscription$slambda {
  constructor($events, this$0, $callbackId, $id) {
    this.n83_1 = $events;
    this.o83_1 = this$0;
    this.p83_1 = $callbackId;
    this.q83_1 = $id;
  }
  r1f($this$launch, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_20.bind(VOID, this, $this$launch), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class KoaksBridge {
  constructor(configJson, invoke, notify) {
    this.j80_1 = CoroutineScope_0(Dispatchers_getInstance().k16_1.kn(SupervisorJob()));
    this.k80_1 = new CallbackGateway(invoke, notify);
    this.l80_1 = new ToolExecutionRegistry();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.m80_1 = ArrayList.k();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_0.o80_1 = LinkedHashMap.hc();
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_1.p80_1 = LinkedHashMap.hc();
    var tmp_2 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_2.q80_1 = LinkedHashMap.hc();
    var tmp_3 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_3.r80_1 = LinkedHashMap.hc();
    var tmp_4 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_4.s80_1 = LinkedHashMap.hc();
    var tmp_5 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_5.t80_1 = LinkedHashMap.hc();
    this.u80_1 = new Long(0, 0);
    this.v80_1 = false;
    var config = parseObject(configJson);
    var tmp_6 = this;
    tmp_6.n80_1 = AgentRuntime(KoaksBridge$lambda(config, this));
  }
  request(method, paramsJson) {
    return promise(this.j80_1, VOID, VOID, KoaksBridge$request$slambda_0(this, method, paramsJson));
  }
}
class AgentRecord {
  constructor(key, built) {
    this.y80_1 = key;
    this.z80_1 = built;
  }
  toString() {
    return 'AgentRecord(key=' + this.y80_1 + ', built=' + this.z80_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.y80_1);
    result = imul(result, 31) + this.z80_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AgentRecord))
      return false;
    var tmp0_other_with_cast = other instanceof AgentRecord ? other : THROW_CCE();
    if (!(this.y80_1 === tmp0_other_with_cast.y80_1))
      return false;
    if (!this.z80_1.equals(tmp0_other_with_cast.z80_1))
      return false;
    return true;
  }
}
class HandleRecord {
  constructor(agentKey, handle, parentRunId) {
    parentRunId = parentRunId === VOID ? null : parentRunId;
    this.n81_1 = agentKey;
    this.o81_1 = handle;
    this.p81_1 = parentRunId;
  }
  toString() {
    var tmp = toString(this.o81_1);
    var tmp_0 = this.p81_1;
    return 'HandleRecord(agentKey=' + this.n81_1 + ', handle=' + tmp + ', parentRunId=' + toString_0(tmp_0 == null ? null : new RunId(tmp_0)) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.n81_1);
    result = imul(result, 31) + hashCode(this.o81_1) | 0;
    var tmp = imul(result, 31);
    var tmp_0;
    var tmp_1 = this.p81_1;
    if ((tmp_1 == null ? null : new RunId(tmp_1)) == null) {
      tmp_0 = 0;
    } else {
      tmp_0 = RunId__hashCode_impl_4harkc(this.p81_1);
    }
    result = tmp + tmp_0 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof HandleRecord))
      return false;
    var tmp0_other_with_cast = other instanceof HandleRecord ? other : THROW_CCE();
    if (!(this.n81_1 === tmp0_other_with_cast.n81_1))
      return false;
    if (!equals(this.o81_1, tmp0_other_with_cast.o81_1))
      return false;
    var tmp = this.p81_1;
    var tmp_0 = tmp == null ? null : new RunId(tmp);
    var tmp_1 = tmp0_other_with_cast.p81_1;
    if (!equals(tmp_0, tmp_1 == null ? null : new RunId(tmp_1)))
      return false;
    return true;
  }
}
class SupervisedRecord {
  constructor(agentKey, handle) {
    this.s83_1 = agentKey;
    this.t83_1 = handle;
  }
  toString() {
    return 'SupervisedRecord(agentKey=' + this.s83_1 + ', handle=' + toString(this.t83_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.s83_1);
    result = imul(result, 31) + hashCode(this.t83_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SupervisedRecord))
      return false;
    var tmp0_other_with_cast = other instanceof SupervisedRecord ? other : THROW_CCE();
    if (!(this.s83_1 === tmp0_other_with_cast.s83_1))
      return false;
    if (!equals(this.t83_1, tmp0_other_with_cast.t83_1))
      return false;
    return true;
  }
}
class SubscriptionRecord {
  constructor(agentKey, job) {
    this.u83_1 = agentKey;
    this.v83_1 = job;
  }
  toString() {
    return 'SubscriptionRecord(agentKey=' + this.u83_1 + ', job=' + toString(this.v83_1) + ')';
  }
  hashCode() {
    var result = this.u83_1 == null ? 0 : getStringHashCode(this.u83_1);
    result = imul(result, 31) + hashCode(this.v83_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SubscriptionRecord))
      return false;
    var tmp0_other_with_cast = other instanceof SubscriptionRecord ? other : THROW_CCE();
    if (!(this.u83_1 == tmp0_other_with_cast.u83_1))
      return false;
    if (!equals(this.v83_1, tmp0_other_with_cast.v83_1))
      return false;
    return true;
  }
}
class OperationRecord {
  constructor(agentKey, job) {
    this.w83_1 = agentKey;
    this.x83_1 = job;
  }
  toString() {
    return 'OperationRecord(agentKey=' + this.w83_1 + ', job=' + toString(this.x83_1) + ')';
  }
  hashCode() {
    var result = this.w83_1 == null ? 0 : getStringHashCode(this.w83_1);
    result = imul(result, 31) + hashCode(this.x83_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OperationRecord))
      return false;
    var tmp0_other_with_cast = other instanceof OperationRecord ? other : THROW_CCE();
    if (!(this.w83_1 == tmp0_other_with_cast.w83_1))
      return false;
    if (!equals(this.x83_1, tmp0_other_with_cast.x83_1))
      return false;
    return true;
  }
}
class CallbackGateway {
  constructor(invoke, notify) {
    this.i81_1 = invoke;
    this.j81_1 = notify;
  }
  k81(id, payload, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_call__qqsb6e.bind(VOID, this, id, payload), $completion);
  }
  t81(id, payload, $completion, $super) {
    payload = payload === VOID ? JsonNull_getInstance() : payload;
    return $super === VOID ? this.k81(id, payload, $completion) : $super.k81.call(this, id, payload, $completion);
  }
  z84(id, payload) {
    if (!(id == null)) {
      // Inline function 'kotlin.runCatching' call
      var tmp;
      try {
        this.j81_1(id, get_nodeJson().y3l(Companion_instance_0.c3o(), payload));
        // Inline function 'kotlin.Companion.success' call
        tmp = _Result___init__impl__xyqfz8(Unit_instance);
      } catch ($p) {
        var tmp_0;
        if ($p instanceof Error) {
          var e = $p;
          // Inline function 'kotlin.Companion.failure' call
          tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
        } else {
          throw $p;
        }
        tmp = tmp_0;
      }
    }
  }
}
class BuiltAgent {
  constructor(agent, owned) {
    this.w80_1 = agent;
    this.x80_1 = owned;
  }
  toString() {
    return 'BuiltAgent(agent=' + toString(this.w80_1) + ', owned=' + toString(this.x80_1) + ')';
  }
  hashCode() {
    var result = hashCode(this.w80_1);
    result = imul(result, 31) + hashCode(this.x80_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof BuiltAgent))
      return false;
    var tmp0_other_with_cast = other instanceof BuiltAgent ? other : THROW_CCE();
    if (!equals(this.w80_1, tmp0_other_with_cast.w80_1))
      return false;
    if (!equals(this.x80_1, tmp0_other_with_cast.x80_1))
      return false;
    return true;
  }
}
class NodeTool$executeNode$slambda {
  constructor(this$0, $execution, $invocation, $input, $runtimeContext) {
    this.n85_1 = this$0;
    this.o85_1 = $execution;
    this.p85_1 = $invocation;
    this.q85_1 = $input;
    this.r85_1 = $runtimeContext;
  }
  vd($completion) {
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.r3o('execution_id', JsonPrimitive_0(this.o85_1.g82_1));
    var tmp0_safe_receiver = this.p85_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.g6k_1;
    builder.r3o('call_id', JsonPrimitive_0(tmp1_elvis_lhs == null ? this.o85_1.g82_1 : tmp1_elvis_lhs));
    builder.r3o('tool_name', JsonPrimitive_0(this.n85_1.c85_1));
    builder.r3o('arguments_json', JsonPrimitive_0(this.q85_1));
    builder.r3o('run_id', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(this.r85_1.i78_1).toString()));
    builder.r3o('agent_id', JsonPrimitive_0(_AgentId___get_value__impl__1mym7n(this.r85_1.j78_1)));
    var tmp2_safe_receiver = this.r85_1.k78_1;
    var tmp = tmp2_safe_receiver;
    if ((tmp == null ? null : new ThreadId(tmp)) == null)
      null;
    else {
      var tmp_0 = tmp2_safe_receiver;
      // Inline function 'kotlin.let' call
      var it = (tmp_0 == null ? null : new ThreadId(tmp_0)).n68_1;
      builder.r3o('thread_id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(it)));
    }
    var tmp3_safe_receiver = this.r85_1.l78_1;
    var tmp_1 = tmp3_safe_receiver;
    if ((tmp_1 == null ? null : new TurnId(tmp_1)) == null)
      null;
    else {
      var tmp_2 = tmp3_safe_receiver;
      // Inline function 'kotlin.let' call
      var it_0 = (tmp_2 == null ? null : new TurnId(tmp_2)).x6u_1;
      builder.r3o('turn_id', JsonPrimitive_0(_TurnId___get_value__impl__w6r3h9(it_0).toString()));
    }
    var tmp4_safe_receiver = this.r85_1.m78_1;
    if (tmp4_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.r3o('correlation_id', JsonPrimitive_0(tmp4_safe_receiver));
    }
    var tmp$ret$7 = builder.i3n();
    return this.n85_1.a85_1.k81(this.n85_1.j85_1, tmp$ret$7, $completion);
  }
}
class NodeTool {
  constructor(config, callbacks, toolExecutions) {
    this.a85_1 = callbacks;
    this.b85_1 = toolExecutions;
    this.c85_1 = string(config, 'name');
    var tmp = this;
    var tmp0_elvis_lhs = stringOrNull(config, 'description');
    tmp.d85_1 = tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs;
    this.e85_1 = serializer(StringCompanionObject_instance);
    var tmp_0 = this;
    var tmp0_elvis_lhs_0 = objectOrNull(config, 'input_schema');
    tmp_0.f85_1 = tmp0_elvis_lhs_0 == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs_0;
    this.g85_1 = true;
    var tmp_1 = this;
    var tmp0_elvis_lhs_1 = booleanOrNull(config, 'return_directly');
    tmp_1.h85_1 = tmp0_elvis_lhs_1 == null ? false : tmp0_elvis_lhs_1;
    var tmp_2 = this;
    var tmp0_elvis_lhs_2 = booleanOrNull(config, 'has_side_effects');
    tmp_2.i85_1 = tmp0_elvis_lhs_2 == null ? false : tmp0_elvis_lhs_2;
    this.j85_1 = string(config, 'execute_callback_id');
    this.k85_1 = stringOrNull(config, 'cancel_callback_id');
  }
  e44() {
    return this.c85_1;
  }
  r61() {
    return this.d85_1;
  }
  s61() {
    return this.e85_1;
  }
  u61() {
    return this.f85_1;
  }
  t61() {
    return this.g85_1;
  }
  y61() {
    return this.h85_1;
  }
  z61() {
    return this.i85_1;
  }
  v61(input, $completion) {
    return executeNode(this, input, null, $completion);
  }
  x61(input, $completion) {
    return this.v61((!(input == null) ? typeof input === 'string' : false) ? input : THROW_CCE(), $completion);
  }
  s85(input, context, $completion) {
    return executeNode(this, input, context, $completion);
  }
  q6k(input, context, $completion) {
    return this.s85((!(input == null) ? typeof input === 'string' : false) ? input : THROW_CCE(), context, $completion);
  }
}
class NodeThreadMemory {
  constructor(config, callbacks) {
    this.t85_1 = callbacks;
    this.u85_1 = string(config, 'load_callback_id');
    this.v85_1 = string(config, 'commit_callback_id');
    this.w85_1 = stringOrNull(config, 'close_callback_id');
    this.x85_1 = retention(config);
  }
  s68() {
    return this.x85_1;
  }
  t68(query, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda.bind(VOID, this, query), $completion);
  }
  u68(turn, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_commit__is9lbl.bind(VOID, this, turn), $completion);
  }
  a6() {
    this.t85_1.z84(this.w85_1, JsonNull_getInstance());
  }
}
class NodeSummaryStateStore {
  constructor(config, callbacks) {
    this.y85_1 = callbacks;
    this.z85_1 = string(config, 'state_load_callback_id');
    this.a86_1 = string(config, 'state_save_callback_id');
    this.b86_1 = string(config, 'state_delete_callback_id');
  }
  l7y(threadId, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda_0.bind(VOID, this, threadId), $completion);
  }
  m7y(threadId, checkpoint, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_save__qhzefp.bind(VOID, this, threadId, checkpoint), $completion);
  }
  n7y(threadId, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_delete__spiywt.bind(VOID, this, threadId), $completion);
  }
}
class NodeVectorStore {
  constructor(config, callbacks) {
    this.c86_1 = callbacks;
    this.d86_1 = string(config, 'add_callback_id');
    this.e86_1 = string(config, 'search_callback_id');
  }
  u7z(threadId, items, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_add__cbj1ot.bind(VOID, this, threadId, items), $completion);
  }
  v7z(threadId, query, topK, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_search__zesrvk.bind(VOID, this, threadId, query, topK), $completion);
  }
}
class NodeMcpGateway {
  constructor(config, callbacks) {
    this.f86_1 = callbacks;
    this.g86_1 = string(config, 'list_tools_callback_id');
    this.h86_1 = string(config, 'call_tool_callback_id');
  }
  j61($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_listTools__xmth8p.bind(VOID, this), $completion);
  }
  w61(name, argumentsJson, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_callTool__hwc8fm.bind(VOID, this, name, argumentsJson), $completion);
  }
}
class NodeSkillLoader {
  constructor(config, callbacks, toolExecutions) {
    this.i86_1 = callbacks;
    this.j86_1 = toolExecutions;
    this.k86_1 = string(config, 'discover_callback_id');
    this.l86_1 = string(config, 'load_callback_id');
  }
  k61($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_discover__xd3vwf.bind(VOID, this), $completion);
  }
  m6i(id, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda_1.bind(VOID, this, id), $completion);
  }
}
class NodeSkillResources {
  constructor(callback, callbacks) {
    this.m86_1 = callback;
    this.n86_1 = callbacks;
  }
  w6i(request, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_read__qih2oe.bind(VOID, this, request), $completion);
  }
}
class NodeClientActionHandler {
  constructor(callback, callbacks) {
    this.o86_1 = callback;
    this.p86_1 = callbacks;
  }
  f5z(item, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_handle__eiwcio.bind(VOID, this, item), $completion);
  }
}
class NodeListener {
  constructor(config, callbacks) {
    this.q86_1 = callbacks;
    this.r86_1 = string(config, 'callback_id');
  }
  p5u(event) {
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.r3o('type', JsonPrimitive_0('model_event'));
    builder.r3o('event', toJson_7(event));
    var tmp$ret$1 = builder.i3n();
    return this.q86_1.z84(this.r86_1, tmp$ret$1);
  }
  u5y(event) {
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.r3o('type', JsonPrimitive_0('agent_event'));
    builder.r3o('event', toJson_14(event));
    var tmp$ret$1 = builder.i3n();
    return this.q86_1.z84(this.r86_1, tmp$ret$1);
  }
  k5x(state) {
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.r3o('type', JsonPrimitive_0('step'));
    builder.r3o('state', toJson_26(state));
    var tmp$ret$1 = builder.i3n();
    return this.q86_1.z84(this.r86_1, tmp$ret$1);
  }
}
class NodeHook$onModelStream$slambda$slambda {
  constructor($this_flow, this$0, $id, $ctx) {
    this.s86_1 = $this_flow;
    this.t86_1 = this$0;
    this.u86_1 = $id;
    this.v86_1 = $ctx;
  }
  n6d(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_21.bind(VOID, this, value), $completion);
  }
  td(p1, $completion) {
    return this.n6d((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class sam$kotlinx_coroutines_flow_FlowCollector$0_4 {
  constructor(function_0) {
    this.i87_1 = function_0;
  }
  t1c(value, $completion) {
    return this.i87_1(value, $completion);
  }
  n4() {
    return this.i87_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, FlowCollector) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class NodeHook$onModelStream$slambda {
  constructor($this, this$0, $id, $ctx) {
    this.e87_1 = $this;
    this.f87_1 = this$0;
    this.g87_1 = $id;
    this.h87_1 = $ctx;
  }
  j87($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_22.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.j87((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class NodeHook$callToolHook$slambda {
  constructor(this$0, $callback, $request) {
    this.k87_1 = this$0;
    this.l87_1 = $callback;
    this.m87_1 = $request;
  }
  vd($completion) {
    return this.k87_1.w86_1.k81(this.l87_1, this.m87_1, $completion);
  }
}
class NodeHook {
  constructor(config, callbacks) {
    this.w86_1 = callbacks;
    this.x86_1 = stringOrNull(config, 'before_model_callback_id');
    this.y86_1 = stringOrNull(config, 'after_model_event_callback_id');
    this.z86_1 = stringOrNull(config, 'before_tool_callback_id');
    this.a87_1 = stringOrNull(config, 'after_tool_callback_id');
    this.b87_1 = stringOrNull(config, 'before_tool_cancel_callback_id');
    this.c87_1 = stringOrNull(config, 'after_tool_cancel_callback_id');
    this.d87_1 = new Long(0, 0);
  }
  v5y(ctx, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_onModelRequest__xhnds3.bind(VOID, this, ctx), $completion);
  }
  x5y(ctx, events) {
    var tmp0_elvis_lhs = this.y86_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return events;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var id = tmp;
    // Inline function 'kotlinx.coroutines.flow.transform' call
    return flow(NodeHook$onModelStream$slambda_0(events, this, id, ctx));
  }
  x5v(ctx, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_onToolCall__sokmxf.bind(VOID, this, ctx), $completion);
  }
  c5w(ctx, outcome, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_onToolResult__d20ol0.bind(VOID, this, ctx, outcome), $completion);
  }
}
class sam$org_koaks_memory_summarizing_CompactionObserver$0 {
  constructor(function_0) {
    this.n87_1 = function_0;
  }
  b7y(event) {
    return this.n87_1(event);
  }
  n4() {
    return this.n87_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, CompactionObserver) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$org_koaks_framework_policy_SuspendTerminationPolicy$0 {
  constructor(function_0) {
    this.o87_1 = function_0;
  }
  n5z(state, $completion) {
    return this.o87_1(state, $completion);
  }
  n4() {
    return this.o87_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, SuspendTerminationPolicy) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$org_koaks_framework_policy_SuspendErrorPolicy$0 {
  constructor(function_0) {
    this.p87_1 = function_0;
  }
  l5x(error, state, $completion) {
    return this.p87_1(error, state, $completion);
  }
  n4() {
    return this.p87_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, SuspendErrorPolicy) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class configureInstructions$lambda$slambda {
  constructor($callbacks, $obj) {
    this.q87_1 = $callbacks;
    this.r87_1 = $obj;
  }
  vd($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_23.bind(VOID, this), $completion);
  }
}
class buildMemory$slambda {
  constructor($callbacks, $config) {
    this.s87_1 = $callbacks;
    this.t87_1 = $config;
  }
  u87(thread, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_24.bind(VOID, this, thread), $completion);
  }
  td(p1, $completion) {
    return this.u87(p1 instanceof ThreadId ? p1.n68_1 : THROW_CCE(), $completion);
  }
}
class buildSuspendTerminationPolicy$slambda {
  constructor($callbacks, $callback) {
    this.v87_1 = $callbacks;
    this.w87_1 = $callback;
  }
  x87(state, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_25.bind(VOID, this, state), $completion);
  }
  td(p1, $completion) {
    return this.x87(p1 instanceof AgentState ? p1 : THROW_CCE(), $completion);
  }
}
class buildSuspendErrorPolicy$slambda {
  constructor($callbacks, $callback) {
    this.y87_1 = $callbacks;
    this.z87_1 = $callback;
  }
  a88(error, state, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_26.bind(VOID, this, error, state), $completion);
  }
  ud(p1, p2, $completion) {
    var tmp = (!(p1 == null) ? isInterface(p1, AgentError) : false) ? p1 : THROW_CCE();
    return this.a88(tmp, p2 instanceof AgentState ? p2 : THROW_CCE(), $completion);
  }
}
class NodeCallbackException extends RuntimeException {
  static y84(callbackType, message, callbackStack) {
    var $this = this.ra(message);
    captureStack($this, $this.x84_1);
    $this.v84_1 = callbackType;
    $this.w84_1 = callbackStack;
    return $this;
  }
}
class NodeBridgeException extends IllegalStateException {
  static d82(code, message) {
    var $this = this.t4(message);
    captureStack($this, $this.c82_1);
    $this.b82_1 = code;
    return $this;
  }
}
class ToolExecutionRegistry$execute$slambda$slambda {
  constructor($record, $block) {
    this.b88_1 = $record;
    this.c88_1 = $block;
  }
  vd($completion) {
    this.b88_1.d88();
    return this.c88_1(this.b88_1, $completion);
  }
}
class Execution {
  constructor(id, runtimeContext, executionContext, invocationContext) {
    this.g82_1 = id;
    this.h82_1 = runtimeContext;
    this.i82_1 = executionContext;
    this.j82_1 = invocationContext;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableSetOf' call
    tmp.k82_1 = LinkedHashSet.g1();
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_0.l82_1 = LinkedHashMap.hc();
    this.m82_1 = new Long(0, 0);
    this.n82_1 = true;
  }
  e88(job) {
    this.d88();
    // Inline function 'kotlin.collections.plusAssign' call
    this.k82_1.l(job);
    job.uv(ToolExecutionRegistry$Execution$track$lambda(this, job));
  }
  f88(job) {
    // Inline function 'kotlin.collections.minusAssign' call
    this.k82_1.z2(job);
  }
  o82(message) {
    this.d88();
    this.m82_1 = this.m82_1.z3();
    var token = 'reply-' + this.g82_1 + '-' + this.m82_1.toString();
    // Inline function 'kotlin.collections.set' call
    this.l82_1.k3(token, message);
    return token;
  }
  z82(token) {
    var tmp0_elvis_lhs = this.l82_1.l3(token);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw NodeBridgeException.d82('ipc_reply_invalid', 'IPC reply token is invalid or was already used');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  g88(reason) {
    if (!this.n82_1)
      return Unit_instance;
    this.n82_1 = false;
    this.l82_1.b3();
    var cancellation = CancellationException.nd(reason);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(this.k82_1).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      element.bw(cancellation);
    }
    this.k82_1.b3();
  }
  d88() {
    if (!this.n82_1) {
      throw NodeBridgeException.d82('tool_context_expired', "Tool RuntimeContext '" + this.g82_1 + "' has expired");
    }
  }
}
class ToolExecutionRegistry$execute$slambda {
  constructor($branch, $record, $block) {
    this.h88_1 = $branch;
    this.i88_1 = $record;
    this.j88_1 = $block;
  }
  r1f($this$withContext, $completion) {
    return this.h88_1.l5w(ToolExecutionRegistry$execute$slambda$slambda_0(this.i88_1, this.j88_1), $completion);
  }
  td(p1, $completion) {
    return this.r1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class ToolExecutionRegistry {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.y83_1 = LinkedHashMap.hc();
    this.z83_1 = new Long(0, 0);
  }
  l85(runtimeContext, executionContext, invocationContext) {
    this.z83_1 = this.z83_1.z3();
    var id = 'tool-execution-' + this.z83_1.toString();
    // Inline function 'kotlin.also' call
    var this_0 = new Execution(id, runtimeContext, executionContext, invocationContext);
    // Inline function 'kotlin.collections.set' call
    this.y83_1.k3(id, this_0);
    return this_0;
  }
  k88(id, reason) {
    var tmp0_safe_receiver = this.y83_1.l3(id);
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.g88(reason);
    }
  }
  m85(id, reason, $super) {
    reason = reason === VOID ? 'Tool execution completed' : reason;
    var tmp;
    if ($super === VOID) {
      this.k88(id, reason);
      tmp = Unit_instance;
    } else {
      tmp = $super.k88.call(this, id, reason);
    }
    return tmp;
  }
  l88(agentId, reason) {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = this.y83_1.j3();
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element.h82_1.j78_1 === agentId) {
        destination.l(element);
      }
    }
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(destination, 10));
    var _iterator__ex2g4s_0 = destination.y();
    while (_iterator__ex2g4s_0.z()) {
      var item = _iterator__ex2g4s_0.a1();
      var tmp$ret$3 = item.g82_1;
      destination_0.l(tmp$ret$3);
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = destination_0.y();
    while (_iterator__ex2g4s_1.z()) {
      var element_0 = _iterator__ex2g4s_1.a1();
      this.k88(element_0, reason);
    }
  }
  c84(agentId, reason, $super) {
    reason = reason === VOID ? 'Agent closed' : reason;
    var tmp;
    if ($super === VOID) {
      this.l88(agentId, reason);
      tmp = Unit_instance;
    } else {
      tmp = $super.l88.call(this, new AgentId(agentId), reason);
    }
    return tmp;
  }
  m88(reason) {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = toList(this.y83_1.i3()).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      this.k88(element, reason);
    }
  }
  d84(reason, $super) {
    reason = reason === VOID ? 'Runtime closed' : reason;
    var tmp;
    if ($super === VOID) {
      this.m88(reason);
      tmp = Unit_instance;
    } else {
      tmp = $super.m88.call(this, reason);
    }
    return tmp;
  }
  b84(id, job) {
    execution(this, id).e88(job);
  }
  a84(id, block, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_execute__d6syw1.bind(VOID, this, id, block), $completion);
  }
}
//endregion
function *_generator_invoke__zhh2q8($this, $this$promise, $completion) {
  var tmp;
  try {
    var tmp_0 = dispatch($this.w7z_1, $this.x7z_1, parseObject($this.y7z_1), $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = success(tmp_0);
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var failure_0 = $p;
      tmp_1 = failure(failure_0);
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  return tmp;
}
function *_generator_invoke__zhh2q8_0($this, value, $completion) {
  var $this$transform = $this.z7z_1;
  var tmp$ret$0 = toJson_31(value);
  var tmp = $this$transform.t1c(tmp$ret$0, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_collect__dlomyy($this, collector, $completion) {
  var tmp = KoaksBridge$dispatch$o$collect$slambda_2(collector);
  var tmp_0 = $this.a80_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function KoaksBridge$dispatch$o$collect$slambda_2($$this$unsafeFlow) {
  var i = new KoaksBridge$dispatch$o$collect$slambda($$this$unsafeFlow);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_1($this, value, $completion) {
  var $this$transform = $this.b80_1;
  var tmp$ret$0 = toJson_27(value);
  var tmp = $this$transform.t1c(tmp$ret$0, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_collect__dlomyy_0($this, collector, $completion) {
  var tmp = KoaksBridge$dispatch$o$collect$slambda_3(collector);
  var tmp_0 = $this.c80_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function KoaksBridge$dispatch$o$collect$slambda_3($$this$unsafeFlow) {
  var i = new KoaksBridge$dispatch$o$collect$slambda_0($$this$unsafeFlow);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_2($this, value, $completion) {
  var $this$transform = $this.d80_1;
  var tmp$ret$0 = toJson_28(value);
  var tmp = $this$transform.t1c(tmp$ret$0, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_collect__dlomyy_1($this, collector, $completion) {
  var tmp = KoaksBridge$dispatch$o$collect$slambda_4(collector);
  var tmp_0 = $this.e80_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function KoaksBridge$dispatch$o$collect$slambda_4($$this$unsafeFlow) {
  var i = new KoaksBridge$dispatch$o$collect$slambda_1($$this$unsafeFlow);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_3($this, $completion) {
  var tmp0_elvis_lhs = objectOrNull($this.f80_1, 'options');
  var options = tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  var tmp;
  if ($this.g80_1) {
    var tmp_0 = string($this.f80_1, 'input');
    var tmp1_safe_receiver = objectOrNull($this.f80_1, 'output');
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : toOutputSpec(tmp1_safe_receiver);
    var tmp_1;
    if (tmp2_elvis_lhs == null) {
      var message = "'output' is required";
      throw IllegalStateException.t4(toString(message));
    } else {
      tmp_1 = tmp2_elvis_lhs;
    }
    var tmp_2 = tmp_1;
    var tmp3_elvis_lhs = intOrNull(options, 'priority');
    var tmp_3 = tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
    var tmp4_safe_receiver = objectOrNull(options, 'quota');
    var tmp_4 = tmp4_safe_receiver == null ? null : toQuota(tmp4_safe_receiver);
    var tmp_5 = contextRefs(options);
    var tmp5_safe_receiver = stringOrNull(options, 'thread_id');
    var tmp_6;
    if (tmp5_safe_receiver == null) {
      tmp_6 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_6 = _ThreadId___init__impl__wwh4n0(tmp5_safe_receiver);
    }
    var tmp_7 = $this.h80_1.n80_1.e71($this.i80_1.z80_1.w80_1, tmp_0, tmp_2, tmp_3, tmp_4, tmp_5, tmp_6, stringOrNull(options, 'correlation_id'), $completion);
    if (tmp_7 === get_COROUTINE_SUSPENDED())
      tmp_7 = yield tmp_7;
    tmp = tmp_7;
  } else {
    var tmp_8 = string($this.f80_1, 'input');
    var tmp6_elvis_lhs = intOrNull(options, 'priority');
    var tmp_9 = tmp6_elvis_lhs == null ? 0 : tmp6_elvis_lhs;
    var tmp7_safe_receiver = objectOrNull(options, 'quota');
    var tmp_10 = tmp7_safe_receiver == null ? null : toQuota(tmp7_safe_receiver);
    var tmp_11 = contextRefs(options);
    var tmp8_safe_receiver = stringOrNull(options, 'thread_id');
    var tmp_12;
    if (tmp8_safe_receiver == null) {
      tmp_12 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_12 = _ThreadId___init__impl__wwh4n0(tmp8_safe_receiver);
    }
    var tmp_13 = $this.h80_1.n80_1.d71($this.i80_1.z80_1.w80_1, tmp_8, tmp_9, tmp_10, tmp_11, tmp_12, stringOrNull(options, 'correlation_id'), $completion);
    if (tmp_13 === get_COROUTINE_SUSPENDED())
      tmp_13 = yield tmp_13;
    tmp = tmp_13;
  }
  var result = tmp;
  return toJson_13(result);
}
function *_generator_invoke__zhh2q8_4($this, value, $completion) {
  var $this$transform = $this.a81_1;
  var tmp$ret$0 = toJson_14(value);
  var tmp = $this$transform.t1c(tmp$ret$0, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_collect__dlomyy_2($this, collector, $completion) {
  var tmp = KoaksBridge$streamAgent$o$collect$slambda_0(collector);
  var tmp_0 = $this.b81_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_0(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function KoaksBridge$streamAgent$o$collect$slambda_0($$this$unsafeFlow) {
  var i = new KoaksBridge$streamAgent$o$collect$slambda($$this$unsafeFlow);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_5($this, $completion) {
  var tmp = _ThreadId___init__impl__wwh4n0(string($this.e81_1, 'thread_id'));
  var tmp0_elvis_lhs = intOrNull($this.f81_1, 'priority');
  var tmp_0 = tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
  var tmp1_safe_receiver = objectOrNull($this.f81_1, 'quota');
  var tmp_1 = $this.c81_1.n80_1.h71($this.d81_1.z80_1.w80_1, tmp, tmp_0, tmp1_safe_receiver == null ? null : toQuota(tmp1_safe_receiver), contextRefs($this.f81_1), stringOrNull($this.f81_1, 'correlation_id'), $completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  return toJson_13(tmp_1);
}
function *_generator_invoke__zhh2q8_6($this, deps, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder_0 = new JsonObjectBuilder();
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = deps.l1().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var id = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var result = element.n1();
    builder_0.r3o(id, toJson_13(result));
  }
  var tmp$ret$6 = builder_0.i3n();
  builder.r3o('dependencies', tmp$ret$6);
  var tmp$ret$8 = builder.i3n();
  var tmp = $this.g81_1.k80_1.k81($this.h81_1, tmp$ret$8, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return get_jsonPrimitive(tmp).j3o();
}
function *_generator_invoke__zhh2q8_7($this, attempt, last, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('attempt', JsonPrimitive(attempt));
  builder.r3o('last', toJson_13(last));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.l81_1.k80_1.k81($this.m81_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return get_jsonPrimitive(tmp).j3o();
}
function *_generator_invoke__zhh2q8_8($this, it, $completion) {
  var tmp = $this.q81_1.o81_1.vw($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return toJson_13(tmp);
}
function KoaksBridge$toolWithResource$slambda$slambda$slambda_0(this$0, $params) {
  var i = new KoaksBridge$toolWithResource$slambda$slambda$slambda(this$0, $params);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function *_generator_invoke__zhh2q8_9($this, it, $completion) {
  var tmp0_elvis_lhs = stringOrNull($this.u81_1, 'mode');
  var tmp;
  switch (tmp0_elvis_lhs == null ? 'write' : tmp0_elvis_lhs) {
    case 'read':
      tmp = AccessMode_READ_getInstance();
      break;
    case 'write':
      tmp = AccessMode_WRITE_getInstance();
      break;
    default:
      throw IllegalArgumentException.t("unknown resource access mode '" + string($this.u81_1, 'mode') + "'");
  }
  var mode = tmp;
  var tmp_0 = string($this.u81_1, 'resource_id');
  var tmp_1 = withRuntimeResource(tmp_0, mode, KoaksBridge$toolWithResource$slambda$slambda_0($this.v81_1, $this.u81_1), $completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  return JsonNull_getInstance();
}
function KoaksBridge$toolWithResource$slambda$slambda_0(this$0, $params) {
  var i = new KoaksBridge$toolWithResource$slambda$slambda(this$0, $params);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function *_generator_invoke__zhh2q8_10($this, execution, $completion) {
  var target = requireIpcTarget($this.e82_1, string($this.f82_1, 'to_run_id'));
  var tmp = execution.h82_1.n78_1.v76(toRuntimeMessage($this.f82_1, execution.h82_1.n78_1.t76(), execution.h82_1.i78_1, target), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return JsonNull_getInstance();
}
function *_generator_invoke__zhh2q8_11($this, execution, $completion) {
  var tmp = execution.i82_1.d5s(KoaksBridge$toolIpcReceive$slambda$slambda_0(execution), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var message = tmp;
  var tmp_0;
  if (message.p76_1 == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = execution.o82(message);
  }
  var token = tmp_0;
  return toJson(message, token);
}
function KoaksBridge$toolIpcReceive$slambda$slambda_0($execution) {
  var i = new KoaksBridge$toolIpcReceive$slambda$slambda($execution);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function KoaksBridge$toolIpcRequest$slambda$slambda$slambda_0($execution, $message) {
  var i = new KoaksBridge$toolIpcRequest$slambda$slambda$slambda($execution, $message);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function *_generator_invoke__zhh2q8_12($this, execution, $completion) {
  var target = requireIpcTarget($this.s82_1, string($this.t82_1, 'to_run_id'));
  var message = toRuntimeMessage($this.t82_1, execution.h82_1.n78_1.t76(), execution.h82_1.i78_1, target);
  var tmp = execution.i82_1.d5s(KoaksBridge$toolIpcRequest$slambda$slambda_0($this.s82_1, $this.t82_1, execution, message), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return toJson(tmp);
}
function KoaksBridge$toolIpcRequest$slambda$slambda_0(this$0, $params, $execution, $message) {
  var i = new KoaksBridge$toolIpcRequest$slambda$slambda(this$0, $params, $execution, $message);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function *_generator_invoke__zhh2q8_13($this, execution, $completion) {
  var request = execution.z82(string($this.y82_1, 'reply_token'));
  var tmp = request.j76_1;
  if (!equals(tmp == null ? null : new RunId(tmp), new RunId(execution.h82_1.i78_1))) {
    throw NodeBridgeException.d82('ipc_reply_invalid', 'IPC request does not belong to the current run');
  }
  var tmp0_elvis_lhs = stringOrNull($this.y82_1, 'payload');
  var tmp_0 = execution.h82_1.n78_1.x76(request, tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs, contextRefs($this.y82_1), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return JsonNull_getInstance();
}
function *_generator_invoke__zhh2q8_14($this, execution, $completion) {
  var tmp = execution.h82_1.n78_1.f76(string($this.a83_1, 'topic'), toRuntimeMessage($this.a83_1, execution.h82_1.n78_1.t76(), execution.h82_1.i78_1, null), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return JsonNull_getInstance();
}
function *_generator_invoke__zhh2q8_15($this, value, $completion) {
  var $this$transform = $this.b83_1;
  var tmp$ret$0 = toJson(value);
  var tmp = $this$transform.t1c(tmp$ret$0, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_collect__dlomyy_3($this, collector, $completion) {
  var tmp = KoaksBridge$toolIpcSubscribe$slambda$o$collect$slambda_0(collector);
  var tmp_0 = $this.c83_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_1(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function KoaksBridge$toolIpcSubscribe$slambda$o$collect$slambda_0($$this$unsafeFlow) {
  var i = new KoaksBridge$toolIpcSubscribe$slambda$o$collect$slambda($$this$unsafeFlow);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_16($this, execution, $completion) {
  var tmp0_elvis_lhs = execution.j82_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw NodeBridgeException.d82('lifecycle_error', 'Tool progress requires a contextual tool invocation');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var invocation = tmp;
  var tmp1_safe_receiver = objectOrNull($this.d83_1, 'progress');
  var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : toToolProgress(tmp1_safe_receiver);
  var tmp_0;
  if (tmp2_elvis_lhs == null) {
    var message = "'progress' is required";
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp_0 = tmp2_elvis_lhs;
  }
  var tmp_1 = invocation.k6k(tmp_0, $completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  return JsonNull_getInstance();
}
function *_generator_invoke__zhh2q8_17($this, $completion) {
  var target = requireIpcTarget($this.e83_1, string($this.f83_1, 'to_run_id'));
  var tmp = withIpcTimeout($this.e83_1, $this.f83_1, KoaksBridge$runtimeIpcRequest$slambda$slambda_0($this.e83_1, $this.f83_1, target), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return toJson(tmp);
}
function KoaksBridge$runtimeIpcRequest$slambda$slambda_0(this$0, $params, $target) {
  var i = new KoaksBridge$runtimeIpcRequest$slambda$slambda(this$0, $params, $target);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function *_generator_invoke__zhh2q8_18($this, value, $completion) {
  var $this$transform = $this.j83_1;
  var tmp$ret$0 = toJson(value);
  var tmp = $this$transform.t1c(tmp$ret$0, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_collect__dlomyy_4($this, collector, $completion) {
  var tmp = KoaksBridge$runtimeIpcSubscribe$o$collect$slambda_0(collector);
  var tmp_0 = $this.k83_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_2(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function KoaksBridge$runtimeIpcSubscribe$o$collect$slambda_0($$this$unsafeFlow) {
  var i = new KoaksBridge$runtimeIpcSubscribe$o$collect$slambda($$this$unsafeFlow);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_19($this, event, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('type', JsonPrimitive_0('next'));
  builder.r3o('value', event);
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.l83_1.k80_1.k81($this.m83_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_20($this, $this$launch, $completion) {
  try {
    var tmp = KoaksBridge$startSubscription$slambda$slambda_0($this.o83_1, $this.p83_1);
    var tmp_0 = $this.n83_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_3(tmp), $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.r3o('type', JsonPrimitive_0('complete'));
    var tmp$ret$1 = builder.i3n();
    var tmp_1 = $this.o83_1.k80_1.k81($this.p83_1, tmp$ret$1, $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
  } catch ($p) {
    if ($p instanceof CancellationException) {
      var _unused_var__etf5q3 = $p;
      // Inline function 'kotlin.runCatching' call
      var tmp_2;
      try {
        // Inline function 'kotlinx.serialization.json.buildJsonObject' call
        var builder_0 = new JsonObjectBuilder();
        builder_0.r3o('type', JsonPrimitive_0('complete'));
        var tmp$ret$3 = builder_0.i3n();
        var tmp_3 = $this.o83_1.k80_1.k81($this.p83_1, tmp$ret$3, $completion);
        if (tmp_3 === get_COROUTINE_SUSPENDED())
          tmp_3 = yield tmp_3;
        // Inline function 'kotlin.Companion.success' call
        var value = tmp_3;
        tmp_2 = _Result___init__impl__xyqfz8(value);
      } catch ($p) {
        var tmp_4;
        if ($p instanceof Error) {
          var e = $p;
          // Inline function 'kotlin.Companion.failure' call
          tmp_4 = _Result___init__impl__xyqfz8(createFailure(e));
        } else {
          throw $p;
        }
        tmp_2 = tmp_4;
      }
      var tmp$ret$7 = tmp_2;
      new Result(tmp$ret$7);
    } else {
      if ($p instanceof Error) {
        var failure = $p;
        // Inline function 'kotlin.runCatching' call
        var tmp_5;
        try {
          // Inline function 'kotlinx.serialization.json.buildJsonObject' call
          var builder_1 = new JsonObjectBuilder();
          builder_1.r3o('type', JsonPrimitive_0('error'));
          builder_1.r3o('error', errorJson(failure));
          var tmp$ret$9 = builder_1.i3n();
          var tmp_6 = $this.o83_1.k80_1.k81($this.p83_1, tmp$ret$9, $completion);
          if (tmp_6 === get_COROUTINE_SUSPENDED())
            tmp_6 = yield tmp_6;
          // Inline function 'kotlin.Companion.success' call
          var value_0 = tmp_6;
          tmp_5 = _Result___init__impl__xyqfz8(value_0);
        } catch ($p) {
          var tmp_7;
          if ($p instanceof Error) {
            var e_0 = $p;
            // Inline function 'kotlin.Companion.failure' call
            tmp_7 = _Result___init__impl__xyqfz8(createFailure(e_0));
          } else {
            throw $p;
          }
          tmp_5 = tmp_7;
        }
        var tmp$ret$13 = tmp_5;
        new Result(tmp$ret$13);
      } else {
        throw $p;
      }
    }
  }
  finally {
    $this.o83_1.s80_1.l3($this.q83_1);
  }
  return Unit_instance;
}
function KoaksBridge$startSubscription$slambda$slambda_0(this$0, $callbackId) {
  var i = new KoaksBridge$startSubscription$slambda$slambda(this$0, $callbackId);
  var l = (event, $completion) => i.r83(event, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_dispatch__vq5iya($this, method, params, $completion) {
  if ($this.v80_1 && !(method === 'runtime.close')) {
    // Inline function 'kotlin.error' call
    var message = 'Koaks runtime is closed';
    throw IllegalStateException.t4(toString(message));
  }
  var tmp;
  switch (method) {
    case 'runtime.create_agent':
      var tmp_0 = createAgent($this, params, false, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      tmp = tmp_0;
      break;
    case 'runtime.replace_agent':
      var tmp_1 = createAgent($this, params, true, $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      tmp = tmp_1;
      break;
    case 'runtime.metrics':
      tmp = toJson_30($this.n80_1.z70());
      break;
    case 'runtime.runs':
      // Inline function 'kotlinx.serialization.json.buildJsonArray' call

      var builder = new JsonArrayBuilder();
      // Inline function 'kotlin.collections.forEach' call

      var _iterator__ex2g4s = $this.n80_1.v70().y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        builder.p3o(toJson_27(element));
      }

      tmp = builder.i3n();
      break;
    case 'runtime.snapshot':
      var tmp1_safe_receiver = $this.n80_1.w70(toRunId(string(params, 'run_id')));
      var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : toJson_27(tmp1_safe_receiver);
      tmp = tmp2_elvis_lhs == null ? JsonNull_getInstance() : tmp2_elvis_lhs;
      break;
    case 'runtime.thread_snapshot':
      var tmp_2 = $this.n80_1.x70(_ThreadId___init__impl__wwh4n0(string(params, 'thread_id')), $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      var tmp3_safe_receiver = tmp_2;
      var tmp4_elvis_lhs = tmp3_safe_receiver == null ? null : toJson_29(tmp3_safe_receiver);
      tmp = tmp4_elvis_lhs == null ? JsonNull_getInstance() : tmp4_elvis_lhs;
      break;
    case 'runtime.reap':
      tmp = reap($this, params);
      break;
    case 'runtime.put_context':
      tmp = putContext($this, params);
      break;
    case 'runtime.delta_context':
      tmp = deltaContext($this, params);
      break;
    case 'runtime.resolve_context':
      tmp = resolveContext($this, params);
      break;
    case 'runtime.submit':
      var tmp_3 = submit($this, params, $completion);
      if (tmp_3 === get_COROUTINE_SUSPENDED())
        tmp_3 = yield tmp_3;
      tmp = tmp_3;
      break;
    case 'runtime.spawn_supervised':
      tmp = spawnSupervised($this, params);
      break;
    case 'runtime.ipc.send':
      var tmp_4 = runtimeIpcSend($this, params, $completion);
      if (tmp_4 === get_COROUTINE_SUSPENDED())
        tmp_4 = yield tmp_4;
      tmp = tmp_4;
      break;
    case 'runtime.ipc.request':
      var tmp_5 = runtimeIpcRequest($this, params, $completion);
      if (tmp_5 === get_COROUTINE_SUSPENDED())
        tmp_5 = yield tmp_5;
      tmp = tmp_5;
      break;
    case 'runtime.ipc.publish':
      var tmp_6 = runtimeIpcPublish($this, params, $completion);
      if (tmp_6 === get_COROUTINE_SUSPENDED())
        tmp_6 = yield tmp_6;
      tmp = tmp_6;
      break;
    case 'runtime.ipc.subscribe':
      tmp = runtimeIpcSubscribe($this, params);
      break;
    case 'runtime.events':
      var tmp_7 = string(params, 'callback_id');
      // Inline function 'kotlinx.coroutines.flow.map' call

      // Inline function 'kotlinx.coroutines.flow.unsafeTransform' call

      var this_0 = $this.n80_1.u70();
      // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call

      var tmp$ret$6 = new KoaksBridge$dispatch$$inlined$map$1(this_0);
      tmp = startSubscription$default($this, null, tmp_7, tmp$ret$6);
      break;
    case 'runtime.close':
      var tmp_8 = closeRuntime($this, $completion);
      if (tmp_8 === get_COROUTINE_SUSPENDED())
        tmp_8 = yield tmp_8;
      tmp = JsonNull_getInstance();
      break;
    case 'agent.prepare':
      var tmp_9 = agent_0($this, params).o5o($completion);
      if (tmp_9 === get_COROUTINE_SUSPENDED())
        tmp_9 = yield tmp_9;
      tmp = JsonNull_getInstance();
      break;
    case 'agent.run':
      var tmp_10 = runAgent($this, params, false, $completion);
      if (tmp_10 === get_COROUTINE_SUSPENDED())
        tmp_10 = yield tmp_10;
      tmp = tmp_10;
      break;
    case 'agent.run_structured':
      var tmp_11 = runAgent($this, params, true, $completion);
      if (tmp_11 === get_COROUTINE_SUSPENDED())
        tmp_11 = yield tmp_11;
      tmp = tmp_11;
      break;
    case 'agent.stream':
      tmp = streamAgent($this, params, false);
      break;
    case 'agent.resume':
      tmp = streamAgent($this, params, true);
      break;
    case 'agent.resume_run':
      var tmp_12 = resumeAgent($this, params, $completion);
      if (tmp_12 === get_COROUTINE_SUSPENDED())
        tmp_12 = yield tmp_12;
      tmp = tmp_12;
      break;
    case 'agent.spawn':
      tmp = spawnAgent$default($this, params);
      break;
    case 'agent.spawn_structured':
      tmp = spawnAgent($this, params, true);
      break;
    case 'agent.spawn_resume':
      tmp = spawnResumeAgent($this, params);
      break;
    case 'agent.close':
      var tmp_13 = closeAgent($this, string(params, 'agent_key'), true, $completion);
      if (tmp_13 === get_COROUTINE_SUSPENDED())
        tmp_13 = yield tmp_13;
      tmp = JsonNull_getInstance();
      break;
    case 'handle.result':
      var tmp_14 = handleResult($this, params, $completion);
      if (tmp_14 === get_COROUTINE_SUSPENDED())
        tmp_14 = yield tmp_14;
      tmp = tmp_14;
      break;
    case 'handle.cancel':
      handle($this, params).o81_1.e6y(stringOrNull(params, 'reason'));
      tmp = JsonNull_getInstance();
      break;
    case 'handle.pause':
      handle($this, params).o81_1.m74();
      tmp = JsonNull_getInstance();
      break;
    case 'handle.resume':
      handle($this, params).o81_1.s1o();
      tmp = JsonNull_getInstance();
      break;
    case 'handle.snapshot':
      tmp = toJson_27(handle($this, params).o81_1.w6q());
      break;
    case 'handle.updates':
      var record = handle($this, params);
      var tmp_15 = string(params, 'callback_id');
      // Inline function 'kotlinx.coroutines.flow.map' call

      // Inline function 'kotlinx.coroutines.flow.unsafeTransform' call

      var this_1 = record.o81_1.g74();
      // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call

      var tmp$ret$9 = new KoaksBridge$dispatch$$inlined$map$2(this_1);
      tmp = startSubscription($this, record.n81_1, tmp_15, tmp$ret$9, stringOrNull(params, 'execution_id'));
      break;
    case 'handle.events':
      var record_0 = handle($this, params);
      var tmp_16 = string(params, 'callback_id');
      // Inline function 'kotlinx.coroutines.flow.map' call

      // Inline function 'kotlinx.coroutines.flow.unsafeTransform' call

      var this_2 = record_0.o81_1.l74(longOrNull(params, 'after_sequence'));
      // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call

      var tmp$ret$12 = new KoaksBridge$dispatch$$inlined$map$3(this_2);
      tmp = startSubscription($this, record_0.n81_1, tmp_16, tmp$ret$12, stringOrNull(params, 'execution_id'));
      break;
    case 'handle.release':
      $this.q80_1.l3(string(params, 'handle_id'));
      tmp = JsonNull_getInstance();
      break;
    case 'supervised.result':
      var tmp_17 = supervised($this, params).t83_1.vw($completion);
      if (tmp_17 === get_COROUTINE_SUSPENDED())
        tmp_17 = yield tmp_17;
      tmp = toJson_13(tmp_17);
      break;
    case 'supervised.cancel':
      supervised($this, params).t83_1.e6y(stringOrNull(params, 'reason'));
      tmp = JsonNull_getInstance();
      break;
    case 'supervised.release':
      $this.r80_1.l3(string(params, 'supervised_id'));
      tmp = JsonNull_getInstance();
      break;
    case 'tool.resource.with':
      var tmp_18 = toolWithResource($this, params, $completion);
      if (tmp_18 === get_COROUTINE_SUSPENDED())
        tmp_18 = yield tmp_18;
      tmp = tmp_18;
      break;
    case 'tool.progress':
      var tmp_19 = toolProgress($this, params, $completion);
      if (tmp_19 === get_COROUTINE_SUSPENDED())
        tmp_19 = yield tmp_19;
      tmp = tmp_19;
      break;
    case 'tool.context.put':
      var tmp_20 = toolPutContext($this, params, $completion);
      if (tmp_20 === get_COROUTINE_SUSPENDED())
        tmp_20 = yield tmp_20;
      tmp = tmp_20;
      break;
    case 'tool.context.delta':
      var tmp_21 = toolDeltaContext($this, params, $completion);
      if (tmp_21 === get_COROUTINE_SUSPENDED())
        tmp_21 = yield tmp_21;
      tmp = tmp_21;
      break;
    case 'tool.context.resolve':
      var tmp_22 = toolResolveContext($this, params, $completion);
      if (tmp_22 === get_COROUTINE_SUSPENDED())
        tmp_22 = yield tmp_22;
      tmp = tmp_22;
      break;
    case 'tool.spawn_child':
      var tmp_23 = toolSpawnChild($this, params, $completion);
      if (tmp_23 === get_COROUTINE_SUSPENDED())
        tmp_23 = yield tmp_23;
      tmp = tmp_23;
      break;
    case 'tool.ipc.send':
      var tmp_24 = toolIpcSend($this, params, $completion);
      if (tmp_24 === get_COROUTINE_SUSPENDED())
        tmp_24 = yield tmp_24;
      tmp = tmp_24;
      break;
    case 'tool.ipc.receive':
      var tmp_25 = toolIpcReceive($this, params, $completion);
      if (tmp_25 === get_COROUTINE_SUSPENDED())
        tmp_25 = yield tmp_25;
      tmp = tmp_25;
      break;
    case 'tool.ipc.request':
      var tmp_26 = toolIpcRequest($this, params, $completion);
      if (tmp_26 === get_COROUTINE_SUSPENDED())
        tmp_26 = yield tmp_26;
      tmp = tmp_26;
      break;
    case 'tool.ipc.reply':
      var tmp_27 = toolIpcReply($this, params, $completion);
      if (tmp_27 === get_COROUTINE_SUSPENDED())
        tmp_27 = yield tmp_27;
      tmp = tmp_27;
      break;
    case 'tool.ipc.publish':
      var tmp_28 = toolIpcPublish($this, params, $completion);
      if (tmp_28 === get_COROUTINE_SUSPENDED())
        tmp_28 = yield tmp_28;
      tmp = tmp_28;
      break;
    case 'tool.ipc.subscribe':
      var tmp_29 = toolIpcSubscribe($this, params, $completion);
      if (tmp_29 === get_COROUTINE_SUSPENDED())
        tmp_29 = yield tmp_29;
      tmp = tmp_29;
      break;
    case 'subscription.cancel':
      var tmp5_safe_receiver = $this.s80_1.l3(string(params, 'subscription_id'));
      var tmp6_safe_receiver = tmp5_safe_receiver == null ? null : tmp5_safe_receiver.v83_1;
      if (tmp6_safe_receiver == null)
        null;
      else {
        var tmp_30 = cancelAndJoin(tmp6_safe_receiver, $completion);
        if (tmp_30 === get_COROUTINE_SUSPENDED())
          tmp_30 = yield tmp_30;
      }

      tmp = JsonNull_getInstance();
      break;
    case 'operation.cancel':
      var tmp7_safe_receiver = $this.t80_1.h3(string(params, 'operation_id'));
      var tmp8_safe_receiver = tmp7_safe_receiver == null ? null : tmp7_safe_receiver.x83_1;
      if (tmp8_safe_receiver == null)
        null;
      else {
        var tmp9_elvis_lhs = stringOrNull(params, 'reason');
        tmp8_safe_receiver.bw(CancellationException.nd(tmp9_elvis_lhs == null ? 'operation cancelled' : tmp9_elvis_lhs));
      }

      tmp = JsonNull_getInstance();
      break;
    default:
      var message_0 = "unknown bridge method '" + method + "'";
      throw IllegalStateException.t4(toString(message_0));
  }
  return tmp;
}
function dispatch($this, method, params, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_dispatch__vq5iya.bind(VOID, $this, method, params), $completion);
}
function *_generator_createAgent__bxbcob($this, params, replace, $completion) {
  var tmp0_elvis_lhs = objectOrNull(params, 'config');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = "'config' is required";
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var config = tmp;
  var publicId = string(config, 'id');
  var existingKey = $this.p80_1.h3(new AgentId(_AgentId___init__impl__m6udbt(publicId)));
  if (!replace) {
    // Inline function 'kotlin.require' call
    if (!(existingKey == null)) {
      var message_0 = "agent '" + publicId + "' already exists";
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
  if (replace) {
    // Inline function 'kotlin.require' call
    if (!!(existingKey == null)) {
      var message_1 = "agent '" + publicId + "' does not exist";
      throw IllegalArgumentException.t(toString(message_1));
    }
  }
  var tmp_0;
  try {
    tmp_0 = buildAgent(config, $this.k80_1, $this.l80_1);
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var failure = $p;
      throw IllegalArgumentException.ae('Invalid agent config: ' + failure.message, failure);
    } else {
      throw $p;
    }
  }
  var built = tmp_0;
  var tmp_2;
  try {
    if (replace) {
      $this.n80_1.c71(built.w80_1);
    }
    var key = nextId($this, 'agent');
    var record = new AgentRecord(key, built);
    // Inline function 'kotlin.collections.set' call
    $this.o80_1.k3(key, record);
    var tmp6 = $this.p80_1;
    // Inline function 'kotlin.collections.set' call
    var key_0 = new AgentId(built.w80_1.i5m_1);
    tmp6.k3(key_0, key);
    if (!(existingKey == null)) {
      var tmp_3 = closeAgent($this, existingKey, false, $completion);
      if (tmp_3 === get_COROUTINE_SUSPENDED())
        tmp_3 = yield tmp_3;
    }
    tmp_2 = agentDescriptor(record);
  } catch ($p) {
    var tmp_4;
    if ($p instanceof Error) {
      var failure_0 = $p;
      closeBuiltAgent($this, built, false);
      throw failure_0;
    } else {
      throw $p;
    }
  }
  return tmp_2;
}
function createAgent($this, params, replace, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_createAgent__bxbcob.bind(VOID, $this, params, replace), $completion);
}
function runAgent($this, params, structured, $completion) {
  var record = agentRecord($this, params);
  var tmp = stringOrNull(params, 'operation_id');
  return withOperation($this, tmp, record.y80_1, KoaksBridge$runAgent$slambda_0(params, structured, $this, record), $completion);
}
function streamAgent($this, params, resume) {
  var record = agentRecord($this, params);
  var tmp0_elvis_lhs = objectOrNull(params, 'options');
  var options = tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  var tmp;
  if (resume) {
    var tmp_0 = _ThreadId___init__impl__wwh4n0(string(params, 'thread_id'));
    var tmp1_elvis_lhs = intOrNull(options, 'priority');
    var tmp_1 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
    var tmp2_safe_receiver = objectOrNull(options, 'quota');
    tmp = $this.n80_1.g71(record.z80_1.w80_1, tmp_0, tmp_1, tmp2_safe_receiver == null ? null : toQuota(tmp2_safe_receiver), contextRefs(options), stringOrNull(options, 'correlation_id'));
  } else {
    var tmp_2 = string(params, 'input');
    var tmp3_elvis_lhs = intOrNull(options, 'priority');
    var tmp_3 = tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
    var tmp4_safe_receiver = objectOrNull(options, 'quota');
    var tmp_4 = tmp4_safe_receiver == null ? null : toQuota(tmp4_safe_receiver);
    var tmp_5 = contextRefs(options);
    var tmp5_safe_receiver = stringOrNull(options, 'thread_id');
    var tmp_6;
    if (tmp5_safe_receiver == null) {
      tmp_6 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_6 = _ThreadId___init__impl__wwh4n0(tmp5_safe_receiver);
    }
    tmp = $this.n80_1.f71(record.z80_1.w80_1, tmp_2, tmp_3, tmp_4, tmp_5, tmp_6, stringOrNull(options, 'correlation_id'));
  }
  var flow = tmp;
  var tmp_7 = string(params, 'callback_id');
  // Inline function 'kotlinx.coroutines.flow.map' call
  // Inline function 'kotlinx.coroutines.flow.unsafeTransform' call
  // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call
  var tmp$ret$4 = new KoaksBridge$streamAgent$$inlined$map$1(flow);
  return startSubscription$default($this, record.y80_1, tmp_7, tmp$ret$4);
}
function resumeAgent($this, params, $completion) {
  var record = agentRecord($this, params);
  var tmp0_elvis_lhs = objectOrNull(params, 'options');
  var options = tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  var tmp = stringOrNull(params, 'operation_id');
  return withOperation($this, tmp, record.y80_1, KoaksBridge$resumeAgent$slambda_0($this, record, params, options), $completion);
}
function spawnAgent($this, params, structured) {
  var record = agentRecord($this, params);
  var tmp0_elvis_lhs = objectOrNull(params, 'options');
  var options = tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  var tmp;
  if (structured) {
    var tmp_0 = string(params, 'input');
    var tmp1_safe_receiver = objectOrNull(params, 'output');
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : toOutputSpec(tmp1_safe_receiver);
    var tmp_1;
    if (tmp2_elvis_lhs == null) {
      var message = "'output' is required";
      throw IllegalStateException.t4(toString(message));
    } else {
      tmp_1 = tmp2_elvis_lhs;
    }
    var tmp_2 = tmp_1;
    var tmp3_elvis_lhs = intOrNull(options, 'priority');
    var tmp_3 = tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
    var tmp4_safe_receiver = objectOrNull(options, 'quota');
    var tmp_4 = tmp4_safe_receiver == null ? null : toQuota(tmp4_safe_receiver);
    var tmp_5 = contextRefs(options);
    var tmp5_safe_receiver = stringOrNull(options, 'thread_id');
    var tmp_6;
    if (tmp5_safe_receiver == null) {
      tmp_6 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_6 = _ThreadId___init__impl__wwh4n0(tmp5_safe_receiver);
    }
    tmp = $this.n80_1.t6x(record.z80_1.w80_1, tmp_0, tmp_2, tmp_3, tmp_4, tmp_5, tmp_6, stringOrNull(options, 'correlation_id'));
  } else {
    var tmp_7 = string(params, 'input');
    var tmp6_elvis_lhs = intOrNull(options, 'priority');
    var tmp_8 = tmp6_elvis_lhs == null ? 0 : tmp6_elvis_lhs;
    var tmp7_safe_receiver = objectOrNull(options, 'quota');
    var tmp_9 = tmp7_safe_receiver == null ? null : toQuota(tmp7_safe_receiver);
    var tmp_10 = contextRefs(options);
    var tmp8_safe_receiver = stringOrNull(options, 'thread_id');
    var tmp_11;
    if (tmp8_safe_receiver == null) {
      tmp_11 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_11 = _ThreadId___init__impl__wwh4n0(tmp8_safe_receiver);
    }
    tmp = $this.n80_1.w6o(record.z80_1.w80_1, tmp_7, tmp_8, tmp_9, tmp_10, tmp_11, stringOrNull(options, 'correlation_id'));
  }
  var handle = tmp;
  var handleId = nextId($this, 'handle');
  var tmp5 = $this.q80_1;
  // Inline function 'kotlin.collections.set' call
  var value = new HandleRecord(record.y80_1, handle);
  tmp5.k3(handleId, value);
  return handleDescriptor(handleId, handle, null);
}
function spawnAgent$default($this, params, structured, $super) {
  structured = structured === VOID ? false : structured;
  return spawnAgent($this, params, structured);
}
function spawnResumeAgent($this, params) {
  var record = agentRecord($this, params);
  var tmp0_elvis_lhs = objectOrNull(params, 'options');
  var options = tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  var tmp = _ThreadId___init__impl__wwh4n0(string(params, 'thread_id'));
  var tmp1_elvis_lhs = intOrNull(options, 'priority');
  var tmp_0 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  var tmp2_safe_receiver = objectOrNull(options, 'quota');
  var handle = $this.n80_1.x6p(record.z80_1.w80_1, tmp, tmp_0, tmp2_safe_receiver == null ? null : toQuota(tmp2_safe_receiver), contextRefs(options), stringOrNull(options, 'correlation_id'));
  var handleId = nextId($this, 'handle');
  var tmp0 = $this.q80_1;
  // Inline function 'kotlin.collections.set' call
  var value = new HandleRecord(record.y80_1, handle);
  tmp0.k3(handleId, value);
  return handleDescriptor(handleId, handle, null);
}
function *_generator_submit__rtm368($this, params, $completion) {
  var graph = taskGraph(KoaksBridge$submit$lambda(params, $this));
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  var tmp = $this.n80_1.j71(graph, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = tmp.l1().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var id = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var result = element.n1();
    builder.r3o(id, toJson_13(result));
  }
  return builder.i3n();
}
function submit($this, params, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_submit__rtm368.bind(VOID, $this, params), $completion);
}
function spawnSupervised($this, params) {
  var record = agentRecord($this, params);
  var tmp0_elvis_lhs = objectOrNull(params, 'options');
  var options = tmp0_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp0_elvis_lhs;
  var tmp1_elvis_lhs = objectOrNull(params, 'policy');
  var policyConfig = tmp1_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp1_elvis_lhs;
  var tmp2_elvis_lhs = stringOrNull(policyConfig, 'retry_on');
  var retryMode = tmp2_elvis_lhs == null ? 'failed' : tmp2_elvis_lhs;
  var recoverCallback = stringOrNull(policyConfig, 'recover_callback_id');
  var tmp3_elvis_lhs = intOrNull(policyConfig, 'max_retries');
  var tmp = tmp3_elvis_lhs == null ? 2 : tmp3_elvis_lhs;
  var tmp4_elvis_lhs = longOrNull(policyConfig, 'initial_backoff_ms');
  var tmp_0 = tmp4_elvis_lhs == null ? new Long(100, 0) : tmp4_elvis_lhs;
  var tmp5_elvis_lhs = doubleOrNull(policyConfig, 'backoff_factor');
  var tmp_1 = tmp5_elvis_lhs == null ? 2.0 : tmp5_elvis_lhs;
  var tmp6_elvis_lhs = longOrNull(policyConfig, 'max_backoff_ms');
  var tmp_2 = tmp6_elvis_lhs == null ? new Long(5000, 0) : tmp6_elvis_lhs;
  var tmp7_safe_receiver = objectOrNull(policyConfig, 'circuit_breaker');
  var tmp_3;
  if (tmp7_safe_receiver == null) {
    tmp_3 = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_elvis_lhs_0 = intOrNull(tmp7_safe_receiver, 'failure_threshold');
    var tmp_4 = tmp0_elvis_lhs_0 == null ? 5 : tmp0_elvis_lhs_0;
    var tmp1_elvis_lhs_0 = longOrNull(tmp7_safe_receiver, 'reset_timeout_ms');
    tmp_3 = new CircuitBreakerPolicy(tmp_4, tmp1_elvis_lhs_0 == null ? new Long(30000, 0) : tmp1_elvis_lhs_0);
  }
  var tmp_5 = tmp_3;
  var tmp_6 = KoaksBridge$spawnSupervised$lambda(retryMode);
  var tmp_7;
  if (recoverCallback == null) {
    tmp_7 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_7 = KoaksBridge$spawnSupervised$slambda_0($this, recoverCallback);
  }
  var policy = new SupervisionPolicy(tmp, tmp_0, tmp_1, tmp_2, tmp_5, tmp_6, tmp_7);
  var tmp_8 = string(params, 'input');
  var tmp9_elvis_lhs = intOrNull(options, 'priority');
  var tmp_9 = tmp9_elvis_lhs == null ? 0 : tmp9_elvis_lhs;
  var tmp10_safe_receiver = objectOrNull(options, 'quota');
  var tmp_10 = tmp10_safe_receiver == null ? null : toQuota(tmp10_safe_receiver);
  var tmp_11 = contextRefs(options);
  var tmp11_safe_receiver = stringOrNull(options, 'thread_id');
  var tmp_12;
  if (tmp11_safe_receiver == null) {
    tmp_12 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_12 = _ThreadId___init__impl__wwh4n0(tmp11_safe_receiver);
  }
  var handle = $this.n80_1.i71(record.z80_1.w80_1, tmp_8, policy, tmp_9, tmp_10, tmp_11, tmp_12);
  var id = nextId($this, 'supervised');
  var tmp6 = $this.r80_1;
  // Inline function 'kotlin.collections.set' call
  var value = new SupervisedRecord(record.y80_1, handle);
  tmp6.k3(id, value);
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('supervised_id', JsonPrimitive_0(id));
  return builder.i3n();
}
function putContext($this, params) {
  var _destruct__k2r9zo = contextScope(params);
  var contextScope_0 = _destruct__k2r9zo.tl();
  var tmp = _destruct__k2r9zo.ul();
  var owner = tmp == null ? null : tmp.z6w_1;
  var ref = $this.n80_1.n6o_1.k75(items(params), contextScope_0, owner);
  return JsonPrimitive_0(_ContextRef___get_id__impl__uspq4f(ref));
}
function deltaContext($this, params) {
  var _destruct__k2r9zo = contextScope(params);
  var contextScope_0 = _destruct__k2r9zo.tl();
  var tmp = _destruct__k2r9zo.ul();
  var owner = tmp == null ? null : tmp.z6w_1;
  var ref = $this.n80_1.n6o_1.l75(_ContextRef___init__impl__laq00z(string(params, 'parent_ref')), items(params), contextScope_0, owner);
  return JsonPrimitive_0(_ContextRef___get_id__impl__uspq4f(ref));
}
function resolveContext($this, params) {
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder = new JsonArrayBuilder();
  var tmp = _ContextRef___init__impl__laq00z(string(params, 'ref'));
  var tmp0_safe_receiver = stringOrNull(params, 'requester_run_id');
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = $this.n80_1.n6o_1.i6z(tmp, tmp0_safe_receiver == null ? null : toRunId(tmp0_safe_receiver)).y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    builder.p3o(toJson_18(element));
  }
  return builder.i3n();
}
function reap($this, params) {
  var tmp0_elvis_lhs = longOrNull(params, 'older_than_ms');
  var count = $this.n80_1.a71(tmp0_elvis_lhs == null ? new Long(0, 0) : tmp0_elvis_lhs);
  var tmp = $this.q80_1.l1();
  removeAll(tmp, KoaksBridge$reap$lambda($this));
  return JsonPrimitive(count);
}
function *_generator_handleResult__mmpr2b($this, params, $completion) {
  var record = handle($this, params);
  var executionId = stringOrNull(params, 'execution_id');
  var tmp;
  if (executionId == null) {
    var tmp_0 = record.o81_1.vw($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = toJson_13(tmp_0);
  } else {
    var tmp_1 = $this.l80_1.a84(executionId, KoaksBridge$handleResult$slambda_0(record), $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    tmp = tmp_1;
  }
  return tmp;
}
function handleResult($this, params, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_handleResult__mmpr2b.bind(VOID, $this, params), $completion);
}
function toolWithResource($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolWithResource$slambda_0(params, $this), $completion);
}
function toolPutContext($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolPutContext$slambda_0(params), $completion);
}
function toolDeltaContext($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolDeltaContext$slambda_0(params), $completion);
}
function toolResolveContext($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolResolveContext$slambda_0(params), $completion);
}
function toolSpawnChild($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolSpawnChild$slambda_0($this, params), $completion);
}
function toolIpcSend($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolIpcSend$slambda_0($this, params), $completion);
}
function toolIpcReceive($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolIpcReceive$slambda_0(), $completion);
}
function toolIpcRequest($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolIpcRequest$slambda_0($this, params), $completion);
}
function toolIpcReply($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolIpcReply$slambda_0(params), $completion);
}
function toolIpcPublish($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolIpcPublish$slambda_0(params), $completion);
}
function toolIpcSubscribe($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolIpcSubscribe$slambda_0($this, params), $completion);
}
function toolProgress($this, params, $completion) {
  var tmp = string(params, 'execution_id');
  return $this.l80_1.a84(tmp, KoaksBridge$toolProgress$slambda_0(params), $completion);
}
function *_generator_runtimeIpcSend__s2ubpg($this, params, $completion) {
  var target = requireIpcTarget($this, string(params, 'to_run_id'));
  var tmp = $this.n80_1.m6o_1.v76(toRuntimeMessage(params, $this.n80_1.m6o_1.t76(), null, target), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return JsonNull_getInstance();
}
function runtimeIpcSend($this, params, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_runtimeIpcSend__s2ubpg.bind(VOID, $this, params), $completion);
}
function runtimeIpcRequest($this, params, $completion) {
  var tmp = stringOrNull(params, 'operation_id');
  return withOperation($this, tmp, null, KoaksBridge$runtimeIpcRequest$slambda_0($this, params), $completion);
}
function *_generator_runtimeIpcPublish__vmiax5($this, params, $completion) {
  var tmp = $this.n80_1.m6o_1.f76(string(params, 'topic'), toRuntimeMessage(params, $this.n80_1.m6o_1.t76(), null, null), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return JsonNull_getInstance();
}
function runtimeIpcPublish($this, params, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_runtimeIpcPublish__vmiax5.bind(VOID, $this, params), $completion);
}
function runtimeIpcSubscribe($this, params) {
  var tmp = string(params, 'callback_id');
  // Inline function 'kotlinx.coroutines.flow.map' call
  // Inline function 'kotlinx.coroutines.flow.unsafeTransform' call
  var this_0 = $this.n80_1.m6o_1.g76(string(params, 'topic'));
  // Inline function 'kotlinx.coroutines.flow.internal.unsafeFlow' call
  var tmp$ret$2 = new KoaksBridge$runtimeIpcSubscribe$$inlined$map$1(this_0);
  return startSubscription$default($this, null, tmp, tmp$ret$2);
}
function requireIpcTarget($this, value) {
  var runId = toRunId(value);
  var snapshot = $this.n80_1.w70(runId);
  if (snapshot == null || snapshot.c6r_1.n6p()) {
    throw NodeBridgeException.d82('ipc_target_unavailable', "IPC target run '" + value + "' is unavailable");
  }
  return runId;
}
function *_generator_withIpcTimeout__cxqod9($this, params, block, $completion) {
  var tmp0_elvis_lhs = longOrNull(params, 'timeout_ms');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var tmp_0 = block($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    return tmp_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var timeout = tmp;
  // Inline function 'kotlin.require' call
  if (!(timeout.s1(new Long(0, 0)) > 0)) {
    var message = 'timeoutMs must be greater than zero';
    throw IllegalArgumentException.t(toString(message));
  }
  var tmp_1;
  try {
    var tmp_2 = withTimeout(timeout, KoaksBridge$withIpcTimeout$slambda_0(block), $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    tmp_1 = tmp_2;
  } catch ($p) {
    var tmp_3;
    if ($p instanceof TimeoutCancellationException) {
      var _unused_var__etf5q3 = $p;
      throw NodeBridgeException.d82('timeout', 'IPC request timed out after ' + timeout.toString() + 'ms');
    } else {
      throw $p;
    }
  }
  return tmp_1;
}
function withIpcTimeout($this, params, block, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_withIpcTimeout__cxqod9.bind(VOID, $this, params, block), $completion);
}
function startSubscription($this, agentKey, callbackId, events, toolExecutionId) {
  var id = nextId($this, 'subscription');
  var tmp = CoroutineStart_LAZY_getInstance();
  var job = launch($this.j80_1, VOID, tmp, KoaksBridge$startSubscription$slambda_0(events, $this, callbackId, id));
  var tmp0 = $this.s80_1;
  // Inline function 'kotlin.collections.set' call
  var value = new SubscriptionRecord(agentKey, job);
  tmp0.k3(id, value);
  if (!(toolExecutionId == null)) {
    try {
      $this.l80_1.b84(toolExecutionId, job);
    } catch ($p) {
      if ($p instanceof Error) {
        var failure = $p;
        $this.s80_1.l3(id);
        job.cw();
        throw failure;
      } else {
        throw $p;
      }
    }
  }
  job.pv();
  return JsonPrimitive_0(id);
}
function startSubscription$default($this, agentKey, callbackId, events, toolExecutionId, $super) {
  toolExecutionId = toolExecutionId === VOID ? null : toolExecutionId;
  return startSubscription($this, agentKey, callbackId, events, toolExecutionId);
}
function *_generator_withOperation__37bbtf($this, operationId, agentKey, block, $completion) {
  if (operationId == null) {
    var tmp = block($completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    return tmp;
  }
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var tmp0_elvis_lhs = $completion.lc().yc(Key_instance_1);
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    var message = 'operation has no coroutine job';
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var job = tmp_0;
  // Inline function 'kotlin.require' call
  if (!($this.t80_1.k3(operationId, new OperationRecord(agentKey, job)) == null)) {
    var message_0 = "operation '" + operationId + "' already exists";
    throw IllegalArgumentException.t(toString(message_0));
  }
  var tmp_1;
  try {
    var tmp_2 = block($completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    tmp_1 = tmp_2;
  }finally {
    $this.t80_1.l3(operationId);
  }
  return tmp_1;
}
function withOperation($this, operationId, agentKey, block, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_withOperation__37bbtf.bind(VOID, $this, operationId, agentKey, block), $completion);
}
function *_generator_closeAgent__un3pkr($this, key, unregister, $completion) {
  var tmp0_elvis_lhs = $this.o80_1.h3(key);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var record = tmp;
  $this.l80_1.c84(record.z80_1.w80_1.i5m_1);
  // Inline function 'kotlin.collections.filter' call
  var tmp0 = $this.s80_1.j3();
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = tmp0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element.u83_1 === key) {
      destination.l(element);
    }
  }
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList.x(collectionSizeOrDefault(destination, 10));
  var _iterator__ex2g4s_0 = destination.y();
  while (_iterator__ex2g4s_0.z()) {
    var item = _iterator__ex2g4s_0.a1();
    var tmp$ret$3 = item.v83_1;
    destination_0.l(tmp$ret$3);
  }
  var agentSubscriptions = destination_0;
  // Inline function 'kotlin.collections.filter' call
  var tmp0_0 = $this.t80_1.j3();
  // Inline function 'kotlin.collections.filterTo' call
  var destination_1 = ArrayList.k();
  var _iterator__ex2g4s_1 = tmp0_0.y();
  while (_iterator__ex2g4s_1.z()) {
    var element_0 = _iterator__ex2g4s_1.a1();
    if (element_0.w83_1 === key) {
      destination_1.l(element_0);
    }
  }
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_2 = ArrayList.x(collectionSizeOrDefault(destination_1, 10));
  var _iterator__ex2g4s_2 = destination_1.y();
  while (_iterator__ex2g4s_2.z()) {
    var item_0 = _iterator__ex2g4s_2.a1();
    var tmp$ret$9 = item_0.x83_1;
    destination_2.l(tmp$ret$9);
  }
  var agentOperations = destination_2;
  // Inline function 'kotlin.collections.filter' call
  var tmp0_1 = $this.q80_1.j3();
  // Inline function 'kotlin.collections.filterTo' call
  var destination_3 = ArrayList.k();
  var _iterator__ex2g4s_3 = tmp0_1.y();
  while (_iterator__ex2g4s_3.z()) {
    var element_1 = _iterator__ex2g4s_3.a1();
    if (element_1.n81_1 === key) {
      destination_3.l(element_1);
    }
  }
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_4 = ArrayList.x(collectionSizeOrDefault(destination_3, 10));
  var _iterator__ex2g4s_4 = destination_3.y();
  while (_iterator__ex2g4s_4.z()) {
    var item_1 = _iterator__ex2g4s_4.a1();
    var tmp$ret$15 = item_1.o81_1;
    destination_4.l(tmp$ret$15);
  }
  var agentHandles = destination_4;
  // Inline function 'kotlin.collections.filter' call
  var tmp0_2 = $this.r80_1.j3();
  // Inline function 'kotlin.collections.filterTo' call
  var destination_5 = ArrayList.k();
  var _iterator__ex2g4s_5 = tmp0_2.y();
  while (_iterator__ex2g4s_5.z()) {
    var element_2 = _iterator__ex2g4s_5.a1();
    if (element_2.s83_1 === key) {
      destination_5.l(element_2);
    }
  }
  // Inline function 'kotlin.collections.map' call
  // Inline function 'kotlin.collections.mapTo' call
  var destination_6 = ArrayList.x(collectionSizeOrDefault(destination_5, 10));
  var _iterator__ex2g4s_6 = destination_5.y();
  while (_iterator__ex2g4s_6.z()) {
    var item_2 = _iterator__ex2g4s_6.a1();
    var tmp$ret$21 = item_2.t83_1;
    destination_6.l(tmp$ret$21);
  }
  var agentSupervised = destination_6;
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_7 = agentSubscriptions.y();
  while (_iterator__ex2g4s_7.z()) {
    var element_3 = _iterator__ex2g4s_7.a1();
    element_3.cw();
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_8 = agentOperations.y();
  while (_iterator__ex2g4s_8.z()) {
    var element_4 = _iterator__ex2g4s_8.a1();
    element_4.cw();
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_9 = agentHandles.y();
  while (_iterator__ex2g4s_9.z()) {
    var element_5 = _iterator__ex2g4s_9.a1();
    element_5.e6y('agent closed');
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_10 = agentSupervised.y();
  while (_iterator__ex2g4s_10.z()) {
    var element_6 = _iterator__ex2g4s_10.a1();
    element_6.e6y('agent closed');
  }
  var tmp_0 = joinAll(agentSubscriptions, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var tmp_1 = joinAll(agentOperations, $completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_11 = agentHandles.y();
  while (_iterator__ex2g4s_11.z()) {
    var element_7 = _iterator__ex2g4s_11.a1();
    // Inline function 'kotlin.runCatching' call
    var tmp_2;
    try {
      var tmp_3 = element_7.yv($completion);
      if (tmp_3 === get_COROUTINE_SUSPENDED())
        tmp_3 = yield tmp_3;
      // Inline function 'kotlin.Companion.success' call
      tmp_2 = _Result___init__impl__xyqfz8(Unit_instance);
    } catch ($p) {
      var tmp_4;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_4 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_2 = tmp_4;
    }
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_12 = agentSupervised.y();
  while (_iterator__ex2g4s_12.z()) {
    var element_8 = _iterator__ex2g4s_12.a1();
    // Inline function 'kotlin.runCatching' call
    var tmp_5;
    try {
      var tmp_6 = element_8.vw($completion);
      if (tmp_6 === get_COROUTINE_SUSPENDED())
        tmp_6 = yield tmp_6;
      // Inline function 'kotlin.Companion.success' call
      var value = tmp_6;
      tmp_5 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_7;
      if ($p instanceof Error) {
        var e_0 = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_7 = _Result___init__impl__xyqfz8(createFailure(e_0));
      } else {
        throw $p;
      }
      tmp_5 = tmp_7;
    }
  }
  var tmp_8 = $this.s80_1.l1();
  removeAll(tmp_8, KoaksBridge$closeAgent$lambda(key));
  var tmp_9 = $this.t80_1.l1();
  removeAll(tmp_9, KoaksBridge$closeAgent$lambda_0(key));
  var tmp_10 = $this.q80_1.l1();
  removeAll(tmp_10, KoaksBridge$closeAgent$lambda_1(key));
  var tmp_11 = $this.r80_1.l1();
  removeAll(tmp_11, KoaksBridge$closeAgent$lambda_2(key));
  if (unregister) {
    $this.n80_1.b71(record.z80_1.w80_1.i5m_1);
  }
  $this.o80_1.l3(key);
  if ($this.p80_1.h3(new AgentId(record.z80_1.w80_1.i5m_1)) === key) {
    $this.p80_1.l3(new AgentId(record.z80_1.w80_1.i5m_1));
  }
  closeBuiltAgent($this, record.z80_1, true);
  return Unit_instance;
}
function closeAgent($this, key, unregister, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_closeAgent__un3pkr.bind(VOID, $this, key, unregister), $completion);
}
function *_generator_closeRuntime__tfzw3s($this, $completion) {
  if ($this.v80_1)
    return Unit_instance;
  $this.v80_1 = true;
  $this.l80_1.d84();
  // Inline function 'kotlin.collections.map' call
  var this_0 = $this.s80_1.j3();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$0 = item.v83_1;
    destination.l(tmp$ret$0);
  }
  var activeSubscriptions = destination;
  // Inline function 'kotlin.collections.map' call
  var this_1 = $this.t80_1.j3();
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList.x(collectionSizeOrDefault(this_1, 10));
  var _iterator__ex2g4s_0 = this_1.y();
  while (_iterator__ex2g4s_0.z()) {
    var item_0 = _iterator__ex2g4s_0.a1();
    var tmp$ret$3 = item_0.x83_1;
    destination_0.l(tmp$ret$3);
  }
  var activeOperations = destination_0;
  // Inline function 'kotlin.collections.map' call
  var this_2 = $this.q80_1.j3();
  // Inline function 'kotlin.collections.mapTo' call
  var destination_1 = ArrayList.x(collectionSizeOrDefault(this_2, 10));
  var _iterator__ex2g4s_1 = this_2.y();
  while (_iterator__ex2g4s_1.z()) {
    var item_1 = _iterator__ex2g4s_1.a1();
    var tmp$ret$6 = item_1.o81_1;
    destination_1.l(tmp$ret$6);
  }
  var activeHandles = destination_1;
  // Inline function 'kotlin.collections.map' call
  var this_3 = $this.r80_1.j3();
  // Inline function 'kotlin.collections.mapTo' call
  var destination_2 = ArrayList.x(collectionSizeOrDefault(this_3, 10));
  var _iterator__ex2g4s_2 = this_3.y();
  while (_iterator__ex2g4s_2.z()) {
    var item_2 = _iterator__ex2g4s_2.a1();
    var tmp$ret$9 = item_2.t83_1;
    destination_2.l(tmp$ret$9);
  }
  var activeSupervised = destination_2;
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_3 = activeSubscriptions.y();
  while (_iterator__ex2g4s_3.z()) {
    var element = _iterator__ex2g4s_3.a1();
    element.cw();
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_4 = activeOperations.y();
  while (_iterator__ex2g4s_4.z()) {
    var element_0 = _iterator__ex2g4s_4.a1();
    element_0.cw();
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_5 = activeHandles.y();
  while (_iterator__ex2g4s_5.z()) {
    var element_1 = _iterator__ex2g4s_5.a1();
    element_1.e6y('runtime closed');
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_6 = activeSupervised.y();
  while (_iterator__ex2g4s_6.z()) {
    var element_2 = _iterator__ex2g4s_6.a1();
    element_2.e6y('runtime closed');
  }
  var tmp = joinAll(activeSubscriptions, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0 = joinAll(activeOperations, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_7 = activeHandles.y();
  while (_iterator__ex2g4s_7.z()) {
    var element_3 = _iterator__ex2g4s_7.a1();
    // Inline function 'kotlin.runCatching' call
    var tmp_1;
    try {
      var tmp_2 = element_3.yv($completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      // Inline function 'kotlin.Companion.success' call
      tmp_1 = _Result___init__impl__xyqfz8(Unit_instance);
    } catch ($p) {
      var tmp_3;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_3 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_1 = tmp_3;
    }
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_8 = activeSupervised.y();
  while (_iterator__ex2g4s_8.z()) {
    var element_4 = _iterator__ex2g4s_8.a1();
    // Inline function 'kotlin.runCatching' call
    var tmp_4;
    try {
      var tmp_5 = element_4.vw($completion);
      if (tmp_5 === get_COROUTINE_SUSPENDED())
        tmp_5 = yield tmp_5;
      // Inline function 'kotlin.Companion.success' call
      var value = tmp_5;
      tmp_4 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_6;
      if ($p instanceof Error) {
        var e_0 = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_6 = _Result___init__impl__xyqfz8(createFailure(e_0));
      } else {
        throw $p;
      }
      tmp_4 = tmp_6;
    }
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_9 = toList($this.o80_1.j3()).y();
  while (_iterator__ex2g4s_9.z()) {
    var element_5 = _iterator__ex2g4s_9.a1();
    closeBuiltAgent($this, element_5.z80_1, false);
  }
  $this.o80_1.b3();
  $this.p80_1.b3();
  $this.q80_1.b3();
  $this.r80_1.b3();
  $this.s80_1.b3();
  $this.t80_1.b3();
  $this.n80_1.a6();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_10 = asReversed($this.m80_1).y();
  while (_iterator__ex2g4s_10.z()) {
    var element_6 = _iterator__ex2g4s_10.a1();
    // Inline function 'kotlin.runCatching' call
    var tmp_7;
    try {
      element_6.a6();
      // Inline function 'kotlin.Companion.success' call
      tmp_7 = _Result___init__impl__xyqfz8(Unit_instance);
    } catch ($p) {
      var tmp_8;
      if ($p instanceof Error) {
        var e_1 = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_8 = _Result___init__impl__xyqfz8(createFailure(e_1));
      } else {
        throw $p;
      }
      tmp_7 = tmp_8;
    }
  }
  $this.m80_1.b3();
  return Unit_instance;
}
function closeRuntime($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_closeRuntime__tfzw3s.bind(VOID, $this), $completion);
}
function closeBuiltAgent($this, built, deferOwned) {
  // Inline function 'kotlin.runCatching' call
  var tmp;
  try {
    built.w80_1.a6();
    // Inline function 'kotlin.Companion.success' call
    tmp = _Result___init__impl__xyqfz8(Unit_instance);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var e = $p;
      // Inline function 'kotlin.Companion.failure' call
      tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  if (deferOwned) {
    var tmp2 = $this.m80_1;
    // Inline function 'kotlin.collections.plusAssign' call
    var elements = built.x80_1;
    addAll(tmp2, elements);
  } else {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = asReversed_0(built.x80_1).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.runCatching' call
      var tmp_1;
      try {
        element.a6();
        // Inline function 'kotlin.Companion.success' call
        tmp_1 = _Result___init__impl__xyqfz8(Unit_instance);
      } catch ($p) {
        var tmp_2;
        if ($p instanceof Error) {
          var e_0 = $p;
          // Inline function 'kotlin.Companion.failure' call
          tmp_2 = _Result___init__impl__xyqfz8(createFailure(e_0));
        } else {
          throw $p;
        }
        tmp_1 = tmp_2;
      }
    }
  }
}
function agent_0($this, params) {
  return agentRecord($this, params).z80_1.w80_1;
}
function agentRecord($this, params) {
  var tmp0_elvis_lhs = $this.o80_1.h3(string(params, 'agent_key'));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = 'unknown or closed agent';
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function handle($this, params) {
  var tmp0_elvis_lhs = $this.q80_1.h3(string(params, 'handle_id'));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = 'unknown or released run handle';
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function supervised($this, params) {
  var tmp0_elvis_lhs = $this.r80_1.h3(string(params, 'supervised_id'));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = 'unknown or released supervised handle';
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function nextId($this, prefix) {
  $this.u80_1 = $this.u80_1.z3();
  return prefix + '-' + $this.u80_1.toString();
}
function KoaksBridge$lambda($config, this$0) {
  return ($this$AgentRuntime) => {
    var tmp = $this$AgentRuntime;
    var tmp0_elvis_lhs = intOrNull($config, 'max_concurrency');
    tmp.p70_1 = tmp0_elvis_lhs == null ? 2147483647 : tmp0_elvis_lhs;
    var tmp_0 = $this$AgentRuntime;
    var tmp1_elvis_lhs = intOrNull($config, 'run_event_buffer_capacity');
    tmp_0.t70_1 = tmp1_elvis_lhs == null ? 1024 : tmp1_elvis_lhs;
    var tmp_1 = $this$AgentRuntime;
    var tmp2_safe_receiver = objectOrNull($config, 'default_quota');
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : toQuota(tmp2_safe_receiver);
    tmp_1.r70_1 = tmp3_elvis_lhs == null ? Companion_getInstance().l71_1 : tmp3_elvis_lhs;
    var tmp4_safe_receiver = objectOrNull($config, 'default_memory');
    if (tmp4_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$AgentRuntime.s70_1 = buildMemory(tmp4_safe_receiver, this$0.k80_1, this$0.m80_1);
    }
    return Unit_instance;
  };
}
function KoaksBridge$request$slambda_0(this$0, $method, $paramsJson) {
  var i = new KoaksBridge$request$slambda(this$0, $method, $paramsJson);
  var l = ($this$promise, $completion) => i.r1f($this$promise, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$runAgent$slambda_0($params, $structured, this$0, $record) {
  var i = new KoaksBridge$runAgent$slambda($params, $structured, this$0, $record);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function KoaksBridge$resumeAgent$slambda_0(this$0, $record, $params, $options) {
  var i = new KoaksBridge$resumeAgent$slambda(this$0, $record, $params, $options);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function KoaksBridge$submit$lambda$slambda_0(this$0, $inputCallback) {
  var i = new KoaksBridge$submit$lambda$slambda(this$0, $inputCallback);
  var l = (deps, $completion) => i.j79(deps, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$submit$lambda($params, this$0) {
  return ($this$taskGraph) => {
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_elvis_lhs = arrayOrNull($params, 'tasks');
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = (tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var task = get_jsonObject(element);
      var tmp0_elvis_lhs_0 = this$0.o80_1.h3(string(task, 'agent_key'));
      var tmp;
      if (tmp0_elvis_lhs_0 == null) {
        var message = 'unknown agent';
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp = tmp0_elvis_lhs_0;
      }
      var record = tmp;
      var inputCallback = stringOrNull(task, 'input_callback_id');
      if (inputCallback == null) {
        var tmp_0 = string(task, 'id');
        var tmp_1 = string(task, 'input');
        var tmp1_elvis_lhs = intOrNull(task, 'priority');
        var tmp_2 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
        // Inline function 'kotlin.collections.orEmpty' call
        var tmp0_elvis_lhs_1 = arrayOrNull(task, 'depends_on');
        // Inline function 'kotlin.collections.map' call
        var this_0 = tmp0_elvis_lhs_1 == null ? emptyList() : tmp0_elvis_lhs_1;
        // Inline function 'kotlin.collections.mapTo' call
        var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
        var _iterator__ex2g4s_0 = this_0.y();
        while (_iterator__ex2g4s_0.z()) {
          var item = _iterator__ex2g4s_0.a1();
          var tmp$ret$2 = get_jsonPrimitive(item).j3o();
          destination.l(tmp$ret$2);
        }
        $this$taskGraph.k79(tmp_0, record.z80_1.w80_1, tmp_1, tmp_2, destination);
      } else {
        var tmp_3 = string(task, 'id');
        var tmp2_elvis_lhs = intOrNull(task, 'priority');
        var tmp_4 = tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs;
        // Inline function 'kotlin.collections.orEmpty' call
        var tmp0_elvis_lhs_2 = arrayOrNull(task, 'depends_on');
        // Inline function 'kotlin.collections.map' call
        var this_1 = tmp0_elvis_lhs_2 == null ? emptyList() : tmp0_elvis_lhs_2;
        // Inline function 'kotlin.collections.mapTo' call
        var destination_0 = ArrayList.x(collectionSizeOrDefault(this_1, 10));
        var _iterator__ex2g4s_1 = this_1.y();
        while (_iterator__ex2g4s_1.z()) {
          var item_0 = _iterator__ex2g4s_1.a1();
          var tmp$ret$6 = get_jsonPrimitive(item_0).j3o();
          destination_0.l(tmp$ret$6);
        }
        var tmp_5 = destination_0;
        $this$taskGraph.l79(tmp_3, record.z80_1.w80_1, tmp_4, tmp_5, KoaksBridge$submit$lambda$slambda_0(this$0, inputCallback));
      }
    }
    return Unit_instance;
  };
}
function KoaksBridge$spawnSupervised$lambda($retryMode) {
  return (result) => {
    var tmp;
    switch ($retryMode) {
      case 'failed':
        tmp = result instanceof Failed;
        break;
      case 'not_completed':
        tmp = !(result instanceof Completed);
        break;
      default:
        var message = "unknown supervision retry_on '" + $retryMode + "'";
        throw IllegalStateException.t4(toString(message));
    }
    return tmp;
  };
}
function KoaksBridge$spawnSupervised$slambda_0(this$0, $callback) {
  var i = new KoaksBridge$spawnSupervised$slambda(this$0, $callback);
  var l = (attempt, last, $completion) => i.j84(attempt, last, $completion);
  l.$arity = 2;
  return l;
}
function KoaksBridge$reap$lambda(this$0) {
  return (it) => this$0.n80_1.w70(it.n1().o81_1.x6o_1) == null;
}
function KoaksBridge$handleResult$slambda_0($record) {
  var i = new KoaksBridge$handleResult$slambda($record);
  var l = (it, $completion) => i.k84(it, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolWithResource$slambda_0($params, this$0) {
  var i = new KoaksBridge$toolWithResource$slambda($params, this$0);
  var l = (it, $completion) => i.k84(it, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolPutContext$slambda_0($params) {
  var i = new KoaksBridge$toolPutContext$slambda($params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolDeltaContext$slambda_0($params) {
  var i = new KoaksBridge$toolDeltaContext$slambda($params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolResolveContext$slambda_0($params) {
  var i = new KoaksBridge$toolResolveContext$slambda($params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolSpawnChild$slambda_0(this$0, $params) {
  var i = new KoaksBridge$toolSpawnChild$slambda(this$0, $params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolIpcSend$slambda_0(this$0, $params) {
  var i = new KoaksBridge$toolIpcSend$slambda(this$0, $params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolIpcReceive$slambda_0() {
  var i = new KoaksBridge$toolIpcReceive$slambda();
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolIpcRequest$slambda_0(this$0, $params) {
  var i = new KoaksBridge$toolIpcRequest$slambda(this$0, $params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolIpcReply$slambda_0($params) {
  var i = new KoaksBridge$toolIpcReply$slambda($params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolIpcPublish$slambda_0($params) {
  var i = new KoaksBridge$toolIpcPublish$slambda($params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolIpcSubscribe$slambda_0(this$0, $params) {
  var i = new KoaksBridge$toolIpcSubscribe$slambda(this$0, $params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$toolProgress$slambda_0($params) {
  var i = new KoaksBridge$toolProgress$slambda($params);
  var l = (execution, $completion) => i.k84(execution, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$runtimeIpcRequest$slambda_0(this$0, $params) {
  var i = new KoaksBridge$runtimeIpcRequest$slambda(this$0, $params);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function KoaksBridge$withIpcTimeout$slambda_0($block) {
  var i = new KoaksBridge$withIpcTimeout$slambda($block);
  var l = ($this$withTimeout, $completion) => i.r1f($this$withTimeout, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$startSubscription$slambda_0($events, this$0, $callbackId, $id) {
  var i = new KoaksBridge$startSubscription$slambda($events, this$0, $callbackId, $id);
  var l = ($this$launch, $completion) => i.r1f($this$launch, $completion);
  l.$arity = 1;
  return l;
}
function KoaksBridge$closeAgent$lambda($key) {
  return (it) => it.n1().u83_1 === $key;
}
function KoaksBridge$closeAgent$lambda_0($key) {
  return (it) => it.n1().w83_1 === $key;
}
function KoaksBridge$closeAgent$lambda_1($key) {
  return (it) => it.n1().n81_1 === $key;
}
function KoaksBridge$closeAgent$lambda_2($key) {
  return (it) => it.n1().s83_1 === $key;
}
function createKoaksBridge(configJson, invoke, notify) {
  return new KoaksBridge(configJson, invoke, notify);
}
function toQuota(_this__u8e3s4) {
  return new Quota(intOrNull(_this__u8e3s4, 'max_steps'), intOrNull(_this__u8e3s4, 'max_tool_calls'), longOrNull(_this__u8e3s4, 'wall_clock_ms'));
}
function toToolProgress(_this__u8e3s4) {
  var tmp;
  switch (string(_this__u8e3s4, 'type')) {
    case 'output':
      tmp = new Output(string(_this__u8e3s4, 'text'), stringOrNull(_this__u8e3s4, 'stream') === 'stderr' ? ToolOutputStream_Stderr_getInstance() : ToolOutputStream_Stdout_getInstance());
      break;
    case 'status':
      tmp = new Status(string(_this__u8e3s4, 'message'));
      break;
    case 'custom':
      var tmp_0 = string(_this__u8e3s4, 'kind');
      var tmp1_elvis_lhs = _this__u8e3s4.w2f('payload');
      tmp = new Custom(tmp_0, tmp1_elvis_lhs == null ? JsonNull_getInstance() : tmp1_elvis_lhs);
      break;
    default:
      throw IllegalArgumentException.t("unknown tool progress type '" + string(_this__u8e3s4, 'type') + "'");
  }
  return tmp;
}
function contextRefs(_this__u8e3s4) {
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = arrayOrNull(_this__u8e3s4, 'context_refs');
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$1 = new ContextRef(_ContextRef___init__impl__laq00z(get_jsonPrimitive(item).j3o()));
    destination.l(tmp$ret$1);
  }
  return destination;
}
function items(_this__u8e3s4) {
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = arrayOrNull(_this__u8e3s4, 'items');
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$1 = toModelItem(get_jsonObject(item));
    destination.l(tmp$ret$1);
  }
  return destination;
}
function contextScope(_this__u8e3s4) {
  var tmp0_elvis_lhs = objectOrNull(_this__u8e3s4, 'scope');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return to(ContextScope_GLOBAL_getInstance(), null);
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var scope = tmp;
  var tmp1_elvis_lhs = stringOrNull(scope, 'type');
  var tmp_0;
  switch (tmp1_elvis_lhs == null ? 'global' : tmp1_elvis_lhs) {
    case 'global':
      tmp_0 = to(ContextScope_GLOBAL_getInstance(), null);
      break;
    case 'task':
      tmp_0 = to(ContextScope_TASK_getInstance(), null);
      break;
    case 'private':
      tmp_0 = to(ContextScope_PRIVATE_getInstance(), new RunId(toRunId(string(scope, 'owner_run_id'))));
      break;
    default:
      var message = "unknown context scope '" + string(scope, 'type') + "'";
      throw IllegalStateException.t4(toString(message));
  }
  return tmp_0;
}
function toRunId(_this__u8e3s4) {
  return _RunId___init__impl__jfg80d(toLong(_this__u8e3s4));
}
function agentDescriptor(record) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('agent_key', JsonPrimitive_0(record.y80_1));
  builder.r3o('id', JsonPrimitive_0(_AgentId___get_value__impl__1mym7n(record.z80_1.w80_1.i5m_1)));
  builder.r3o('name', JsonPrimitive_0(record.z80_1.w80_1.j5m_1));
  return builder.i3n();
}
function handleDescriptor(id, handle, parentRunId) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('handle_id', JsonPrimitive_0(id));
  builder.r3o('run_id', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(handle.x6o_1).toString()));
  builder.r3o('agent_id', JsonPrimitive_0(_AgentId___get_value__impl__1mym7n(handle.y6o_1)));
  var tmp0_safe_receiver = handle.z6o_1;
  var tmp = tmp0_safe_receiver;
  if ((tmp == null ? null : new ThreadId(tmp)) == null)
    null;
  else {
    var tmp_0 = tmp0_safe_receiver;
    // Inline function 'kotlin.let' call
    var it = (tmp_0 == null ? null : new ThreadId(tmp_0)).n68_1;
    builder.r3o('thread_id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(it)));
  }
  var tmp1_safe_receiver = handle.a6p_1;
  var tmp_1 = tmp1_safe_receiver;
  if ((tmp_1 == null ? null : new TurnId(tmp_1)) == null)
    null;
  else {
    var tmp_2 = tmp1_safe_receiver;
    // Inline function 'kotlin.let' call
    var it_0 = (tmp_2 == null ? null : new TurnId(tmp_2)).x6u_1;
    builder.r3o('turn_id', JsonPrimitive_0(_TurnId___get_value__impl__w6r3h9(it_0).toString()));
  }
  var tmp2_safe_receiver = handle.b6p_1;
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('correlation_id', JsonPrimitive_0(tmp2_safe_receiver));
  }
  var tmp_3 = parentRunId;
  if ((tmp_3 == null ? null : new RunId(tmp_3)) == null)
    null;
  else {
    var tmp_4 = parentRunId;
    // Inline function 'kotlin.let' call
    var it_1 = (tmp_4 == null ? null : new RunId(tmp_4)).z6w_1;
    builder.r3o('parent_run_id', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(it_1).toString()));
  }
  return builder.i3n();
}
function toolContextScope(_this__u8e3s4) {
  var tmp0_elvis_lhs = stringOrNull(_this__u8e3s4, 'scope');
  var tmp;
  switch (tmp0_elvis_lhs == null ? 'private' : tmp0_elvis_lhs) {
    case 'private':
      tmp = ContextScope_PRIVATE_getInstance();
      break;
    case 'task':
      tmp = ContextScope_TASK_getInstance();
      break;
    case 'global':
      tmp = ContextScope_GLOBAL_getInstance();
      break;
    default:
      throw IllegalArgumentException.t("unknown Tool Context scope '" + string(_this__u8e3s4, 'scope') + "'");
  }
  return tmp;
}
function toRuntimeMessage(_this__u8e3s4, id, sender, receiver) {
  var tmp = string(_this__u8e3s4, 'type');
  var tmp0_elvis_lhs = stringOrNull(_this__u8e3s4, 'payload');
  var tmp_0 = tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs;
  var tmp_1 = contextRefs(_this__u8e3s4);
  var tmp1_elvis_lhs = intOrNull(_this__u8e3s4, 'priority');
  return new RuntimeMessage(id, sender, receiver, tmp, tmp_0, tmp_1, tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs, longOrNull(_this__u8e3s4, 'deadline_epoch_ms'));
}
function toJson(_this__u8e3s4, replyToken) {
  replyToken = replyToken === VOID ? null : replyToken;
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('id', JsonPrimitive_0(_this__u8e3s4.h76_1.toString()));
  var tmp0_safe_receiver = _this__u8e3s4.i76_1;
  var tmp = tmp0_safe_receiver;
  if ((tmp == null ? null : new RunId(tmp)) == null)
    null;
  else {
    var tmp_0 = tmp0_safe_receiver;
    // Inline function 'kotlin.let' call
    var it = (tmp_0 == null ? null : new RunId(tmp_0)).z6w_1;
    builder.r3o('sender_run_id', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(it).toString()));
  }
  var tmp1_safe_receiver = _this__u8e3s4.j76_1;
  var tmp_1 = tmp1_safe_receiver;
  if ((tmp_1 == null ? null : new RunId(tmp_1)) == null)
    null;
  else {
    var tmp_2 = tmp1_safe_receiver;
    // Inline function 'kotlin.let' call
    var it_0 = (tmp_2 == null ? null : new RunId(tmp_2)).z6w_1;
    builder.r3o('receiver_run_id', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(it_0).toString()));
  }
  builder.r3o('type', JsonPrimitive_0(_this__u8e3s4.k76_1));
  builder.r3o('payload', JsonPrimitive_0(_this__u8e3s4.l76_1));
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.m76_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var it_1 = element.g6z_1;
    builder_0.p3o(JsonPrimitive_0(_ContextRef___get_id__impl__uspq4f(it_1)));
  }
  var tmp$ret$7 = builder_0.i3n();
  builder.r3o('context_refs', tmp$ret$7);
  builder.r3o('priority', JsonPrimitive(_this__u8e3s4.n76_1));
  var tmp2_safe_receiver = _this__u8e3s4.o76_1;
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('deadline_epoch_ms', JsonPrimitive(tmp2_safe_receiver));
  }
  if (replyToken == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('reply_token', JsonPrimitive_0(replyToken));
  }
  return builder.i3n();
}
function errorJson(error) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('type', JsonPrimitive_0(bridgeErrorCode(error)));
  var tmp0_elvis_lhs = error.message;
  var tmp1_elvis_lhs = tmp0_elvis_lhs == null ? getKClassFromExpression(error).hf() : tmp0_elvis_lhs;
  builder.r3o('message', JsonPrimitive_0(tmp1_elvis_lhs == null ? 'unknown error' : tmp1_elvis_lhs));
  var tmp2_safe_receiver = error instanceof NodeCallbackException ? error : null;
  var stack = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.w84_1;
  var tmp;
  if (stack == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.takeIf' call
    var tmp_0;
    // Inline function 'kotlin.text.isNotBlank' call
    if (!isBlank(stack)) {
      tmp_0 = stack;
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  var tmp4_safe_receiver = tmp;
  if (tmp4_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('stack', JsonPrimitive_0(tmp4_safe_receiver));
  }
  return builder.i3n();
}
function *_generator_call__qqsb6e($this, id, payload, $completion) {
  var tmp = await_0($this.i81_1(id, get_nodeJson().y3l(Companion_instance_0.c3o(), payload)), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var response = tmp;
  if (isBlank(response))
    return JsonNull_getInstance();
  var decoded = get_nodeJson().b3m(response);
  var tmp0_elvis_lhs = decoded instanceof JsonObject ? decoded : null;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return decoded;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var envelope = tmp_0;
  var tmp1_elvis_lhs = booleanOrNull(envelope, 'ok');
  var tmp_1;
  if (tmp1_elvis_lhs == null) {
    return decoded;
  } else {
    tmp_1 = tmp1_elvis_lhs;
  }
  var ok = tmp_1;
  if (ok) {
    var tmp2_elvis_lhs = envelope.w2f('value');
    return tmp2_elvis_lhs == null ? JsonNull_getInstance() : tmp2_elvis_lhs;
  }
  var tmp3_elvis_lhs = objectOrNull(envelope, 'error');
  var error = tmp3_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp3_elvis_lhs;
  var tmp4_elvis_lhs = stringOrNull(error, 'type');
  var tmp_2 = tmp4_elvis_lhs == null ? 'callback_error' : tmp4_elvis_lhs;
  var tmp5_elvis_lhs = stringOrNull(error, 'message');
  throw NodeCallbackException.y84(tmp_2, tmp5_elvis_lhs == null ? 'Node callback failed' : tmp5_elvis_lhs, stringOrNull(error, 'stack'));
}
function buildAgent(config, callbacks, toolExecutions) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var owned = ArrayList.k();
  var built = agent(buildAgent$lambda(config, callbacks, owned, toolExecutions));
  return new BuiltAgent(built, owned);
}
function configureInstructions(_this__u8e3s4, value, callbacks) {
  if (value != null && !equals(value, JsonNull_getInstance())) {
    if (value instanceof JsonPrimitive_1)
      _this__u8e3s4.g5p_1 = value.j3o();
    else {
      if (value instanceof JsonArray) {
        _this__u8e3s4.z5p(configureInstructions$lambda(value, callbacks));
      } else {
        // Inline function 'kotlin.error' call
        var message = "'instructions' must be a string or array";
        throw IllegalStateException.t4(toString(message));
      }
    }
  }
}
function selectProvider(_this__u8e3s4, config) {
  var tmp;
  switch (string(config, 'type')) {
    case 'openai':
      var tmp1_elvis_lhs = stringOrNull(config, 'base_url');
      var tmp_0 = tmp1_elvis_lhs == null ? 'https://api.openai.com' : tmp1_elvis_lhs;
      var tmp_1 = string(config, 'api_key');
      var tmp_2 = string(config, 'model');
      tmp = openai(_this__u8e3s4, tmp_0, tmp_1, tmp_2, selectProvider$lambda(config));
      break;
    case 'openai_responses':
    case 'openai-responses':
      var tmp2_elvis_lhs = stringOrNull(config, 'base_url');
      var tmp_3 = tmp2_elvis_lhs == null ? 'https://api.openai.com' : tmp2_elvis_lhs;
      var tmp_4 = string(config, 'api_key');
      var tmp_5 = string(config, 'model');
      tmp = openaiResponses(_this__u8e3s4, tmp_3, tmp_4, tmp_5, selectProvider$lambda_0(config));
      break;
    case 'qwen':
      var tmp3_elvis_lhs = stringOrNull(config, 'base_url');
      var tmp_6 = tmp3_elvis_lhs == null ? 'https://dashscope.aliyuncs.com/compatible-mode' : tmp3_elvis_lhs;
      var tmp_7 = string(config, 'api_key');
      var tmp_8 = string(config, 'model');
      tmp = qwen(_this__u8e3s4, tmp_6, tmp_7, tmp_8, selectProvider$lambda_1(config));
      break;
    case 'anthropic':
      var tmp4_elvis_lhs = stringOrNull(config, 'base_url');
      var tmp_9 = tmp4_elvis_lhs == null ? 'https://api.anthropic.com/v1/messages' : tmp4_elvis_lhs;
      var tmp_10 = string(config, 'api_key');
      var tmp_11 = string(config, 'model');
      tmp = anthropic(_this__u8e3s4, tmp_9, tmp_10, tmp_11, selectProvider$lambda_2(config));
      break;
    case 'ollama':
      var tmp_12 = string(config, 'base_url');
      var tmp5_elvis_lhs = stringOrNull(config, 'api_key');
      var tmp_13 = tmp5_elvis_lhs == null ? 'ollama' : tmp5_elvis_lhs;
      var tmp_14 = string(config, 'model');
      tmp = ollama(_this__u8e3s4, tmp_12, tmp_13, tmp_14, selectProvider$lambda_3(config));
      break;
    default:
      var message = "unknown provider type '" + string(config, 'type') + "'";
      throw IllegalStateException.t4(toString(message));
  }
  return tmp;
}
function *_generator_executeNode__r9ucjn($this, input, invocation, $completion) {
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var coroutineContext = $completion.lc();
  var tmp0_elvis_lhs = coroutineContext.yc(Key_instance_0);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw NodeBridgeException.d82('lifecycle_error', 'JS Tools require a runtime-managed execution');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var runtimeContext = tmp;
  var tmp1_elvis_lhs = coroutineContext.yc(Key_instance);
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    throw NodeBridgeException.d82('lifecycle_error', 'JS Tools require an Agent execution branch');
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var executionContext = tmp_0;
  var execution = $this.b85_1.l85(runtimeContext, executionContext, invocation);
  var tmp_1;
  try {
    var tmp_2 = executionContext.d5s(NodeTool$executeNode$slambda_0($this, execution, invocation, input, runtimeContext), $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    var response = get_jsonObject(tmp_2);
    tmp_1 = string(response, 'output');
  } catch ($p) {
    var tmp_3;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder = new JsonObjectBuilder();
      builder.r3o('execution_id', JsonPrimitive_0(execution.g82_1));
      var tmp0_elvis_lhs_0 = cancelled.message;
      builder.r3o('reason', JsonPrimitive_0(tmp0_elvis_lhs_0 == null ? 'cancelled' : tmp0_elvis_lhs_0));
      var tmp$ret$3 = builder.i3n();
      $this.a85_1.z84($this.k85_1, tmp$ret$3);
      throw cancelled;
    } else {
      throw $p;
    }
  }
  finally {
    $this.b85_1.m85(execution.g82_1);
  }
  return tmp_1;
}
function executeNode($this, input, invocation, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_executeNode__r9ucjn.bind(VOID, $this, input, invocation), $completion);
}
function NodeTool$executeNode$slambda_0(this$0, $execution, $invocation, $input, $runtimeContext) {
  var i = new NodeTool$executeNode$slambda(this$0, $execution, $invocation, $input, $runtimeContext);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function buildMemory(config, callbacks, owned) {
  var tmp;
  switch (string(config, 'type')) {
    case 'none':
      tmp = NoMemoryProvider_getInstance();
      break;
    case 'window':
      var tmp1_elvis_lhs = intOrNull(config, 'max_messages');
      tmp = new WindowMemoryProvider(tmp1_elvis_lhs == null ? 40 : tmp1_elvis_lhs, retention(config));
      break;
    case 'custom':
      var tmp_0 = _MemoryProviderId___init__impl__vkxuto(string(config, 'id'));
      tmp = new FixedMemoryProvider(tmp_0, buildMemory$slambda_0(callbacks, config));
      break;
    case 'vector':
      var tmp_1 = _MemoryProviderId___init__impl__vkxuto(string(config, 'id'));
      var tmp_2 = new NodeVectorStore(config, callbacks);
      var tmp2_elvis_lhs = intOrNull(config, 'top_k');
      tmp = new VectorMemoryProvider(tmp_1, tmp_2, tmp2_elvis_lhs == null ? 8 : tmp2_elvis_lhs, retention(config));
      break;
    case 'summarizing':
      // Inline function 'kotlin.also' call

      var this_0 = new KtorTransport();
      buildMemory$add(owned, this_0);
      var transport = this_0;
      // Inline function 'kotlin.apply' call

      var this_1 = new ModelScope();
      this_1.y5z(transport);
      var scope = this_1;
      var tmp3_elvis_lhs = objectOrNull(config, 'model');
      var tmp_3;
      if (tmp3_elvis_lhs == null) {
        var message = "summarizing memory requires 'model'";
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp_3 = tmp3_elvis_lhs;
      }

      var model = toLanguageModel(selectProvider(scope, tmp_3));
      var id = _MemoryProviderId___init__impl__vkxuto(string(config, 'id'));
      var tmp4_safe_receiver = objectOrNull(config, 'delegate');
      var tmp_4;
      if (tmp4_safe_receiver == null) {
        tmp_4 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_4 = buildMemory(tmp4_safe_receiver, callbacks, owned);
      }

      var tmp5_elvis_lhs = tmp_4;
      var delegate = tmp5_elvis_lhs == null ? new InMemoryAppendMemoryProvider(_MemoryProviderId___init__impl__vkxuto(_MemoryProviderId___get_value__impl__90yl20(id) + '-raw'), retention(config)) : tmp5_elvis_lhs;
      var tmp_5;
      if (stringOrNull(config, 'state_load_callback_id') == null) {
        tmp_5 = new InMemorySummaryStateStore();
      } else {
        tmp_5 = new NodeSummaryStateStore(config, callbacks);
      }

      var stateStore = tmp_5;
      var tmp6_safe_receiver = stringOrNull(config, 'compaction_callback_id');
      var tmp_6;
      if (tmp6_safe_receiver == null) {
        tmp_6 = null;
      } else {
        // Inline function 'kotlin.let' call
        var tmp_7 = buildMemory$lambda(callbacks, tmp6_safe_receiver);
        tmp_6 = new sam$org_koaks_memory_summarizing_CompactionObserver$0(tmp_7);
      }

      var tmp7_elvis_lhs = tmp_6;
      var tmp_8;
      if (tmp7_elvis_lhs == null) {
        var tmp_9 = buildMemory$lambda_0;
        tmp_8 = new sam$org_koaks_memory_summarizing_CompactionObserver$0(tmp_9);
      } else {
        tmp_8 = tmp7_elvis_lhs;
      }

      var observer = tmp_8;
      var tmp8_elvis_lhs = intOrNull(config, 'max_tokens');
      var tmp_10;
      if (tmp8_elvis_lhs == null) {
        var message_0 = "summarizing memory requires 'max_tokens'";
        throw IllegalStateException.t4(toString(message_0));
      } else {
        tmp_10 = tmp8_elvis_lhs;
      }

      var tmp_11 = tmp_10;
      var tmp9_elvis_lhs = intOrNull(config, 'keep_recent_turns');
      tmp = new SummarizingMemoryProvider(id, delegate, stateStore, model, tmp_11, tmp9_elvis_lhs == null ? 2 : tmp9_elvis_lhs, retention(config), observer);
      break;
    default:
      var message_1 = "unknown memory type '" + string(config, 'type') + "'";
      throw IllegalStateException.t4(toString(message_1));
  }
  return tmp;
}
function retention(_this__u8e3s4) {
  switch (stringOrNull(_this__u8e3s4, 'retention')) {
    case 'completed_only':
      return TurnRetention_CompletedOnly_getInstance();
    case 'interrupted_if_side_effects':
      return TurnRetention_InterruptedIfSideEffects_getInstance();
    default:
      return TurnRetention_Interrupted_getInstance();
  }
}
function *_generator_load__qllgda($this, query, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = query.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    builder_0.p3o(toJson_18(element));
  }
  var tmp$ret$3 = builder_0.i3n();
  builder.r3o('query', tmp$ret$3);
  var tmp$ret$5 = builder.i3n();
  var tmp = $this.t85_1.k81($this.u85_1, tmp$ret$5, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return toMemoryView(get_jsonObject(tmp));
}
function *_generator_commit__is9lbl($this, turn, $completion) {
  var tmp = $this.t85_1.k81($this.v85_1, toJson_22(turn), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_load__qllgda_0($this, threadId, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('thread_id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(threadId)));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.y85_1.k81($this.z85_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  // Inline function 'kotlin.let' call
  var it = tmp;
  var tmp_0;
  if (it instanceof JsonNull) {
    tmp_0 = null;
  } else {
    tmp_0 = toSummaryCheckpoint(get_jsonObject(it));
  }
  return tmp_0;
}
function *_generator_save__qhzefp($this, threadId, checkpoint, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('thread_id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(threadId)));
  builder.r3o('checkpoint', toJson_0(checkpoint));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.y85_1.k81($this.a86_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_delete__spiywt($this, threadId, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('thread_id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(threadId)));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.y85_1.k81($this.b86_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function toJson_0(_this__u8e3s4) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder_0 = new JsonObjectBuilder();
  builder_0.r3o('item_count', JsonPrimitive(_this__u8e3s4.y7y_1.c6b_1));
  builder_0.r3o('digest', JsonPrimitive_0(_this__u8e3s4.y7y_1.d6b_1));
  var tmp$ret$1 = builder_0.i3n();
  builder.r3o('basis', tmp$ret$1);
  builder.r3o('summary', toJson_18(_this__u8e3s4.z7y_1));
  builder.r3o('source_turn_id', JsonPrimitive_0(_this__u8e3s4.a7z_1));
  builder.r3o('created_at_epoch_ms', JsonPrimitive(_this__u8e3s4.b7z_1));
  return builder.i3n();
}
function toSummaryCheckpoint(_this__u8e3s4) {
  var tmp0_elvis_lhs = objectOrNull(_this__u8e3s4, 'basis');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = "summary checkpoint requires 'basis'";
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var basis = tmp;
  var tmp1_safe_receiver = objectOrNull(_this__u8e3s4, 'summary');
  var tmp_0 = tmp1_safe_receiver == null ? null : toModelItem(tmp1_safe_receiver);
  var tmp2_elvis_lhs = tmp_0 instanceof Message ? tmp_0 : null;
  var tmp_1;
  if (tmp2_elvis_lhs == null) {
    var message_0 = "summary checkpoint requires a message 'summary'";
    throw IllegalStateException.t4(toString(message_0));
  } else {
    tmp_1 = tmp2_elvis_lhs;
  }
  var summary = tmp_1;
  var tmp3_elvis_lhs = intOrNull(basis, 'item_count');
  var tmp_2;
  if (tmp3_elvis_lhs == null) {
    var message_1 = 'basis requires item_count';
    throw IllegalStateException.t4(toString(message_1));
  } else {
    tmp_2 = tmp3_elvis_lhs;
  }
  var tmp_3 = new TranscriptBasis(tmp_2, string(basis, 'digest'));
  var tmp_4 = string(_this__u8e3s4, 'source_turn_id');
  var tmp4_elvis_lhs = longOrNull(_this__u8e3s4, 'created_at_epoch_ms');
  var tmp_5;
  if (tmp4_elvis_lhs == null) {
    var message_2 = 'checkpoint requires created_at_epoch_ms';
    throw IllegalStateException.t4(toString(message_2));
  } else {
    tmp_5 = tmp4_elvis_lhs;
  }
  return new SummaryCheckpoint(tmp_3, summary, tmp_4, tmp_5);
}
function toJson_1(_this__u8e3s4) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('thread_id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(_this__u8e3s4.w6u())));
  builder.r3o('source_turn_id', JsonPrimitive_0(_this__u8e3s4.r7y()));
  if (_this__u8e3s4 instanceof Started_0) {
    builder.r3o('type', JsonPrimitive_0('started'));
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder_0 = new JsonObjectBuilder();
    builder_0.r3o('item_count', JsonPrimitive(_this__u8e3s4.q7y_1.c6b_1));
    builder_0.r3o('digest', JsonPrimitive_0(_this__u8e3s4.q7y_1.d6b_1));
    var tmp$ret$1 = builder_0.i3n();
    builder.r3o('basis', tmp$ret$1);
  } else {
    if (_this__u8e3s4 instanceof Completed_2) {
      builder.r3o('type', JsonPrimitive_0('completed'));
      builder.r3o('checkpoint', toJson_0(_this__u8e3s4.u7y_1));
    } else {
      if (_this__u8e3s4 instanceof Failed_3) {
        builder.r3o('type', JsonPrimitive_0('failed'));
        builder.r3o('message', JsonPrimitive_0(_this__u8e3s4.x7y_1));
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return builder.i3n();
}
function *_generator_add__cbj1ot($this, threadId, items, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('thread_id', JsonPrimitive_0(threadId));
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = items.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    builder_0.p3o(toJson_18(element));
  }
  var tmp$ret$3 = builder_0.i3n();
  builder.r3o('items', tmp$ret$3);
  var tmp$ret$5 = builder.i3n();
  var tmp = $this.c86_1.k81($this.d86_1, tmp$ret$5, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_search__zesrvk($this, threadId, query, topK, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('thread_id', JsonPrimitive_0(threadId));
  builder.r3o('query', JsonPrimitive_0(query));
  builder.r3o('top_k', JsonPrimitive(topK));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.c86_1.k81($this.e86_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  // Inline function 'kotlin.let' call
  var it = tmp;
  // Inline function 'kotlin.collections.map' call
  var this_0 = it instanceof JsonArray ? it : THROW_CCE();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$4 = toModelItem(get_jsonObject(item));
    destination.l(tmp$ret$4);
  }
  return destination;
}
function *_generator_listTools__xmth8p($this, $completion) {
  var tmp = $this.f86_1.t81($this.g86_1, VOID, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0 = tmp;
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp_0 instanceof JsonArray ? tmp_0 : THROW_CCE();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var obj = get_jsonObject(item);
    var tmp_1 = string(obj, 'name');
    var tmp0_elvis_lhs = stringOrNull(obj, 'description');
    var tmp$ret$0 = new McpTool(tmp_1, tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs, objectOrNull(obj, 'input_schema'));
    destination.l(tmp$ret$0);
  }
  return destination;
}
function *_generator_callTool__hwc8fm($this, name, argumentsJson, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('name', JsonPrimitive_0(name));
  builder.r3o('arguments_json', JsonPrimitive_0(argumentsJson));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.f86_1.k81($this.h86_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return string(get_jsonObject(tmp), 'output');
}
function *_generator_discover__xd3vwf($this, $completion) {
  var tmp = $this.i86_1.t81($this.k86_1, VOID, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0 = tmp;
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp_0 instanceof JsonArray ? tmp_0 : THROW_CCE();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$0 = toSkillDescriptor(get_jsonObject(item));
    destination.l(tmp$ret$0);
  }
  return destination;
}
function *_generator_load__qllgda_1($this, id, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('id', JsonPrimitive_0(_SkillId___get_value__impl__n6yl35(id)));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.i86_1.k81($this.l86_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var loaded = get_jsonObject(tmp);
  var tmp0_safe_receiver = objectOrNull(loaded, 'descriptor');
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toSkillDescriptor(tmp0_safe_receiver);
  var descriptor = tmp1_elvis_lhs == null ? new SkillDescriptor(id, string(loaded, 'description')) : tmp1_elvis_lhs;
  var resourceCallback = stringOrNull(loaded, 'resource_callback_id');
  var tmp_0 = string(loaded, 'instructions');
  var tmp_1;
  if (resourceCallback == null) {
    tmp_1 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_1 = new NodeSkillResources(resourceCallback, $this.i86_1);
  }
  var tmp_2 = tmp_1;
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = arrayOrNull(loaded, 'tools');
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$5 = new NodeTool(get_jsonObject(item), $this.i86_1, $this.j86_1);
    destination.l(tmp$ret$5);
  }
  return new SkillDefinition(descriptor, tmp_0, tmp_2, destination);
}
function toSkillDescriptor(_this__u8e3s4) {
  var tmp = _SkillId___init__impl__ou80gj(string(_this__u8e3s4, 'id'));
  var tmp_0 = string(_this__u8e3s4, 'description');
  var tmp0_safe_receiver = objectOrNull(_this__u8e3s4, 'metadata');
  var tmp_1;
  if (tmp0_safe_receiver == null) {
    tmp_1 = null;
  } else {
    // Inline function 'kotlin.collections.mapValues' call
    // Inline function 'kotlin.collections.mapValuesTo' call
    var destination = LinkedHashMap.ic(mapCapacity(tmp0_safe_receiver.b1()));
    // Inline function 'kotlin.collections.associateByTo' call
    var _iterator__ex2g4s = tmp0_safe_receiver.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp_2 = element.m1();
      var tmp$ret$1 = get_jsonPrimitive(element.n1()).j3o();
      destination.k3(tmp_2, tmp$ret$1);
    }
    tmp_1 = destination;
  }
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = tmp_1;
  var tmp$ret$5 = tmp0_elvis_lhs == null ? emptyMap() : tmp0_elvis_lhs;
  return new SkillDescriptor(tmp, tmp_0, tmp$ret$5);
}
function *_generator_read__qih2oe($this, request, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('path', JsonPrimitive_0(request.q6i_1));
  builder.r3o('line', JsonPrimitive(request.r6i_1.u6i_1));
  builder.r3o('column', JsonPrimitive(request.r6i_1.v6i_1));
  builder.r3o('max_lines', JsonPrimitive(request.s6i_1));
  builder.r3o('max_chars', JsonPrimitive(request.t6i_1));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.n86_1.k81($this.m86_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var response = get_jsonObject(tmp);
  var tmp_0 = string(response, 'path');
  var tmp_1 = string(response, 'content');
  var tmp_2 = ensureNotNull(intOrNull(response, 'first_line'));
  var tmp_3 = ensureNotNull(intOrNull(response, 'last_line'));
  var tmp_4 = ensureNotNull(intOrNull(response, 'total_lines'));
  var tmp0_safe_receiver = objectOrNull(response, 'next_cursor');
  var tmp_5;
  if (tmp0_safe_receiver == null) {
    tmp_5 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_5 = new SkillResourceCursor(ensureNotNull(intOrNull(tmp0_safe_receiver, 'line')), ensureNotNull(intOrNull(tmp0_safe_receiver, 'column')));
  }
  return new SkillResource(tmp_0, tmp_1, tmp_2, tmp_3, tmp_4, tmp_5);
}
function *_generator_handle__eiwcio($this, item, $completion) {
  var tmp = $this.p86_1.k81($this.o86_1, toJson_18(item), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  // Inline function 'kotlin.let' call
  var it = tmp;
  var tmp_0;
  if (it instanceof JsonNull) {
    tmp_0 = null;
  } else {
    tmp_0 = toModelItem(get_jsonObject(it));
  }
  return tmp_0;
}
function *_generator_invoke__zhh2q8_21($this, value, $completion) {
  var $this$transform = $this.s86_1;
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('context', toJson_2($this.v86_1));
  builder.r3o('event', toJson_7(value));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.t86_1.w86_1.k81($this.u86_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var response = tmp;
  if (!equals(response, JsonNull_getInstance())) {
    if (response instanceof JsonObject) {
      switch (stringOrNull(response, 'action')) {
        case 'keep':
          var tmp_0 = $this$transform.t1c(value, $completion);
          if (tmp_0 === get_COROUTINE_SUSPENDED())
            tmp_0 = yield tmp_0;
          break;
        case 'drop':
          break;
        case 'replace':
          var replacements = response.w2f('events');
          if (replacements instanceof JsonArray) {
            // Inline function 'kotlin.collections.forEach' call
            var _iterator__ex2g4s = replacements.y();
            while (_iterator__ex2g4s.z()) {
              var element = _iterator__ex2g4s.a1();
              var tmp_1 = $this$transform.t1c(toModelEvent(get_jsonObject(element)), $completion);
              if (tmp_1 === get_COROUTINE_SUSPENDED())
                tmp_1 = yield tmp_1;
            }
          } else {
            if (replacements instanceof JsonObject) {
              var tmp_2 = $this$transform.t1c(toModelEvent(replacements), $completion);
              if (tmp_2 === get_COROUTINE_SUSPENDED())
                tmp_2 = yield tmp_2;
            } else {
              // Inline function 'kotlin.error' call
              var message = "replace model event decision requires 'events'";
              throw IllegalStateException.t4(toString(message));
            }
          }

          break;
        case null:
          var tmp_3 = $this$transform.t1c(toModelEvent(response), $completion);
          if (tmp_3 === get_COROUTINE_SUSPENDED())
            tmp_3 = yield tmp_3;
          break;
        default:
          // Inline function 'kotlin.error' call

          var message_0 = "unknown model event decision '" + string(response, 'action') + "'";
          throw IllegalStateException.t4(toString(message_0));
      }
    } else {
      if (response instanceof JsonArray) {
        // Inline function 'kotlin.collections.forEach' call
        var _iterator__ex2g4s_0 = response.y();
        while (_iterator__ex2g4s_0.z()) {
          var element_0 = _iterator__ex2g4s_0.a1();
          var tmp_4 = $this$transform.t1c(toModelEvent(get_jsonObject(element_0)), $completion);
          if (tmp_4 === get_COROUTINE_SUSPENDED())
            tmp_4 = yield tmp_4;
        }
      } else {
        // Inline function 'kotlin.error' call
        var message_1 = 'after model event callback must return a decision object';
        throw IllegalStateException.t4(toString(message_1));
      }
    }
  }
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_22($this, $this$flow, $completion) {
  var tmp = NodeHook$onModelStream$slambda$slambda_0($this$flow, $this.f87_1, $this.g87_1, $this.h87_1);
  var tmp_0 = $this.e87_1.g1c(new sam$kotlinx_coroutines_flow_FlowCollector$0_4(tmp), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function NodeHook$onModelStream$slambda$slambda_0($this_flow, this$0, $id, $ctx) {
  var i = new NodeHook$onModelStream$slambda$slambda($this_flow, this$0, $id, $ctx);
  var l = (value, $completion) => i.n6d(value, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_onModelRequest__xhnds3($this, ctx, $completion) {
  var tmp0_elvis_lhs = $this.x86_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return ctx.s69_1;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var id = tmp;
  var tmp_0 = $this.w86_1.k81(id, toJson_2(ctx), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var response = tmp_0;
  var tmp_1;
  if (response instanceof JsonNull) {
    tmp_1 = ctx.s69_1;
  } else {
    tmp_1 = toModelRequest(get_jsonObject(response));
  }
  return tmp_1;
}
function *_generator_onToolCall__sokmxf($this, ctx, $completion) {
  var tmp0_elvis_lhs = $this.z86_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return Proceed_instance;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var id = tmp;
  var tmp_0 = callToolHook($this, id, $this.b87_1, toJson_3(ctx), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var response = tmp_0;
  if (response instanceof JsonNull)
    return Proceed_instance;
  var obj = get_jsonObject(response);
  var tmp_1;
  switch (string(obj, 'action')) {
    case 'proceed':
      tmp_1 = Proceed_instance;
      break;
    case 'deny':
      tmp_1 = new Deny(string(obj, 'reason'));
      break;
    case 'replace':
      tmp_1 = new ProceedWith(toToolCall(ensureNotNull(objectOrNull(obj, 'call'))));
      break;
    default:
      var message = "unknown tool decision '" + string(obj, 'action') + "'";
      throw IllegalStateException.t4(toString(message));
  }
  return tmp_1;
}
function *_generator_onToolResult__d20ol0($this, ctx, outcome, $completion) {
  var tmp0_elvis_lhs = $this.a87_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return outcome;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var id = tmp;
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('context', toJson_3(ctx));
  builder.r3o('outcome', toJson_6(outcome));
  var tmp$ret$1 = builder.i3n();
  var tmp_0 = callToolHook($this, id, $this.c87_1, tmp$ret$1, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var response = tmp_0;
  var tmp_1;
  if (response instanceof JsonNull) {
    tmp_1 = outcome;
  } else {
    tmp_1 = toToolOutcome(get_jsonObject(response));
  }
  return tmp_1;
}
function *_generator_callToolHook__mmhtqn($this, callback, cancelCallback, payload, $completion) {
  $this.d87_1 = $this.d87_1.z3();
  var hookExecutionId = 'hook-execution-' + $this.d87_1.toString();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = payload.l1().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var key = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var value = element.n1();
    builder.r3o(key, value);
  }
  builder.r3o('hook_execution_id', JsonPrimitive_0(hookExecutionId));
  var request = builder.i3n();
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var execution = $completion.lc().yc(Key_instance);
  var tmp;
  try {
    var tmp_0;
    if (execution == null) {
      var tmp_1 = $this.w86_1.k81(callback, request, $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      tmp_0 = tmp_1;
    } else {
      var tmp_2 = execution.d5s(NodeHook$callToolHook$slambda_0($this, callback, request), $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      tmp_0 = tmp_2;
    }
    tmp = tmp_0;
  } catch ($p) {
    var tmp_3;
    if ($p instanceof CancellationException) {
      var cancelled = $p;
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder_0 = new JsonObjectBuilder();
      builder_0.r3o('hook_execution_id', JsonPrimitive_0(hookExecutionId));
      var tmp0_safe_receiver = cancelled.message;
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder_0.r3o('reason', JsonPrimitive_0(tmp0_safe_receiver));
      }
      var tmp$ret$12 = builder_0.i3n();
      $this.w86_1.z84(cancelCallback, tmp$ret$12);
      throw cancelled;
    } else {
      throw $p;
    }
  }
  return tmp;
}
function callToolHook($this, callback, cancelCallback, payload, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_callToolHook__mmhtqn.bind(VOID, $this, callback, cancelCallback, payload), $completion);
}
function NodeHook$onModelStream$slambda_0($this, this$0, $id, $ctx) {
  var i = new NodeHook$onModelStream$slambda($this, this$0, $id, $ctx);
  var l = ($this$flow, $completion) => i.j87($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function NodeHook$callToolHook$slambda_0(this$0, $callback, $request) {
  var i = new NodeHook$callToolHook$slambda(this$0, $callback, $request);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function buildTerminationPolicy(config) {
  var maxSteps = intOrNull(config, 'max_steps');
  var maxTokens = intOrNull(config, 'max_tokens');
  var tmp;
  if (maxSteps == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = Companion_instance_2.w5p(maxSteps);
  }
  var tmp_0 = tmp;
  var tmp_1;
  if (maxTokens == null) {
    tmp_1 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_1 = Companion_instance_2.u6f(maxTokens);
  }
  var policies = listOfNotNull([tmp_0, tmp_1]);
  var tmp_2;
  switch (policies.b1()) {
    case 0:
      tmp_2 = Companion_instance_2.w5p(2147483647);
      break;
    case 1:
      tmp_2 = single(policies);
      break;
    default:
      var tmp_3 = Companion_instance_2;
      // Inline function 'kotlin.collections.toTypedArray' call

      var tmp$ret$4 = copyToArray(policies);
      tmp_2 = tmp_3.v6f(tmp$ret$4.slice());
      break;
  }
  return tmp_2;
}
function buildSuspendTerminationPolicy(callback, callbacks) {
  var tmp = buildSuspendTerminationPolicy$slambda_0(callbacks, callback);
  return new sam$org_koaks_framework_policy_SuspendTerminationPolicy$0(tmp);
}
function buildErrorPolicy(config) {
  var tmp;
  switch (string(config, 'type')) {
    case 'propagate':
      tmp = Companion_getInstance_0().x5p_1;
      break;
    case 'retry_retriable':
      var tmp_0 = Companion_getInstance_0();
      var tmp1_elvis_lhs = intOrNull(config, 'max_retries');
      var tmp_1 = tmp1_elvis_lhs == null ? 2 : tmp1_elvis_lhs;
      var tmp2_elvis_lhs = longOrNull(config, 'delay_ms');
      tmp = tmp_0.p6f(tmp_1, tmp2_elvis_lhs == null ? new Long(200, 0) : tmp2_elvis_lhs);
      break;
    case 'substitute':
      tmp = Companion_getInstance_0().q6f(toModelItem(ensureNotNull(objectOrNull(config, 'message'))));
      break;
    default:
      var message = "unsupported error policy '" + string(config, 'type') + "'";
      throw IllegalStateException.t4(toString(message));
  }
  return tmp;
}
function buildSuspendErrorPolicy(callback, callbacks) {
  var tmp = buildSuspendErrorPolicy$slambda_0(callbacks, callback);
  return new sam$org_koaks_framework_policy_SuspendErrorPolicy$0(tmp);
}
function toOutputSpec(_this__u8e3s4) {
  var tmp0_elvis_lhs = objectOrNull(_this__u8e3s4, 'schema');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = "'schema' is required";
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return new OutputSpec(tmp, string(_this__u8e3s4, 'name'));
}
function toJson_2(_this__u8e3s4) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('state', toJson_26(_this__u8e3s4.r69_1));
  builder.r3o('request', toJson_4(_this__u8e3s4.s69_1));
  builder.r3o('phase', JsonPrimitive_0(_this__u8e3s4.t69_1.equals(ModelCallPhase_Normal_getInstance()) ? 'normal' : 'structured_finalization'));
  return builder.i3n();
}
function toJson_3(_this__u8e3s4) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('call', toJson_16(_this__u8e3s4.u69_1));
  builder.r3o('state', toJson_26(_this__u8e3s4.v69_1));
  var tmp0_safe_receiver = _this__u8e3s4.w69_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder_0 = new JsonObjectBuilder();
    builder_0.r3o('run_id', JsonPrimitive_0(tmp0_safe_receiver.g5s_1));
    builder_0.r3o('agent_id', JsonPrimitive_0(tmp0_safe_receiver.h5s_1));
    var tmp0_safe_receiver_0 = tmp0_safe_receiver.i5s_1;
    if (tmp0_safe_receiver_0 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder_0.r3o('thread_id', JsonPrimitive_0(tmp0_safe_receiver_0));
    }
    var tmp1_safe_receiver = tmp0_safe_receiver.j5s_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder_0.r3o('turn_id', JsonPrimitive_0(tmp1_safe_receiver));
    }
    var tmp2_safe_receiver = tmp0_safe_receiver.k5s_1;
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder_0.r3o('correlation_id', JsonPrimitive_0(tmp2_safe_receiver));
    }
    var tmp$ret$7 = builder_0.i3n();
    builder.r3o('execution', tmp$ret$7);
  }
  return builder.i3n();
}
function toJson_4(_this__u8e3s4) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  var tmp0_safe_receiver = _this__u8e3s4.g5y_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('instructions', JsonPrimitive_0(tmp0_safe_receiver));
  }
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.h5y_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    builder_0.p3o(toJson_18(element));
  }
  var tmp$ret$5 = builder_0.i3n();
  builder.r3o('items', tmp$ret$5);
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_1 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_0 = _this__u8e3s4.i5y_1.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder_2 = new JsonObjectBuilder();
    builder_2.r3o('name', JsonPrimitive_0(element_0.u6k_1));
    builder_2.r3o('description', JsonPrimitive_0(element_0.v6k_1));
    builder_2.r3o('parameters', element_0.w6k_1);
    var tmp$ret$7 = builder_2.i3n();
    builder_1.p3o(tmp$ret$7);
  }
  var tmp$ret$11 = builder_1.i3n();
  builder.r3o('tools', tmp$ret$11);
  builder.r3o('output_format', toJson_5(_this__u8e3s4.j5y_1));
  var tmp1_safe_receiver = _this__u8e3s4.k5y_1;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('checkpoint', toJson_21(tmp1_safe_receiver));
  }
  builder.r3o('idempotency_key', JsonPrimitive_0(_this__u8e3s4.l5y_1));
  return builder.i3n();
}
function toModelRequest(_this__u8e3s4) {
  var tmp = stringOrNull(_this__u8e3s4, 'instructions');
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = arrayOrNull(_this__u8e3s4, 'items');
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$1 = toModelItem(get_jsonObject(item));
    destination.l(tmp$ret$1);
  }
  var tmp_0 = destination;
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs_0 = arrayOrNull(_this__u8e3s4, 'tools');
  // Inline function 'kotlin.collections.map' call
  var this_1 = tmp0_elvis_lhs_0 == null ? emptyList() : tmp0_elvis_lhs_0;
  // Inline function 'kotlin.collections.mapTo' call
  var destination_0 = ArrayList.x(collectionSizeOrDefault(this_1, 10));
  var _iterator__ex2g4s_0 = this_1.y();
  while (_iterator__ex2g4s_0.z()) {
    var item_0 = _iterator__ex2g4s_0.a1();
    // Inline function 'kotlin.let' call
    var it = get_jsonObject(item_0);
    var tmp_1 = string(it, 'name');
    var tmp0_elvis_lhs_1 = stringOrNull(it, 'description');
    var tmp_2 = tmp0_elvis_lhs_1 == null ? '' : tmp0_elvis_lhs_1;
    var tmp1_elvis_lhs = objectOrNull(it, 'parameters');
    var tmp$ret$7 = new ToolSchema(tmp_1, tmp_2, tmp1_elvis_lhs == null ? new JsonObject(emptyMap()) : tmp1_elvis_lhs);
    destination_0.l(tmp$ret$7);
  }
  var tmp_3 = destination_0;
  var tmp0_safe_receiver = objectOrNull(_this__u8e3s4, 'output_format');
  var tmp1_elvis_lhs_0 = tmp0_safe_receiver == null ? null : toOutputFormat(tmp0_safe_receiver);
  var tmp_4 = tmp1_elvis_lhs_0 == null ? Text_instance : tmp1_elvis_lhs_0;
  var tmp2_safe_receiver = objectOrNull(_this__u8e3s4, 'checkpoint');
  return new ModelRequest(tmp, tmp_0, tmp_3, tmp_4, tmp2_safe_receiver == null ? null : toCheckpoint(tmp2_safe_receiver), string(_this__u8e3s4, 'idempotency_key'));
}
function toJson_5(_this__u8e3s4) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (equals(_this__u8e3s4, Text_instance))
    builder.r3o('type', JsonPrimitive_0('text'));
  else {
    if (equals(_this__u8e3s4, JsonObject_instance))
      builder.r3o('type', JsonPrimitive_0('json_object'));
    else {
      if (_this__u8e3s4 instanceof JsonSchema) {
        builder.r3o('type', JsonPrimitive_0('json_schema'));
        builder.r3o('name', JsonPrimitive_0(_this__u8e3s4.k6e_1));
        builder.r3o('schema', _this__u8e3s4.l6e_1);
        builder.r3o('strict', JsonPrimitive_2(_this__u8e3s4.m6e_1));
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return builder.i3n();
}
function toOutputFormat(_this__u8e3s4) {
  var tmp;
  switch (string(_this__u8e3s4, 'type')) {
    case 'text':
      tmp = Text_instance;
      break;
    case 'json_object':
      tmp = JsonObject_instance;
      break;
    case 'json_schema':
      var tmp_0 = string(_this__u8e3s4, 'name');
      var tmp_1 = ensureNotNull(objectOrNull(_this__u8e3s4, 'schema'));
      var tmp1_elvis_lhs = booleanOrNull(_this__u8e3s4, 'strict');
      tmp = new JsonSchema(tmp_0, tmp_1, tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs);
      break;
    default:
      var message = 'unknown output format';
      throw IllegalStateException.t4(toString(message));
  }
  return tmp;
}
function toJson_6(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof Success) {
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.r3o('type', JsonPrimitive_0('success'));
    builder.r3o('output', JsonPrimitive_0(_this__u8e3s4.x5r_1));
    builder.r3o('return_directly', JsonPrimitive_2(_this__u8e3s4.y5r_1));
    tmp = builder.i3n();
  } else {
    if (_this__u8e3s4 instanceof Failure) {
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder_0 = new JsonObjectBuilder();
      builder_0.r3o('type', JsonPrimitive_0('failure'));
      builder_0.r3o('error', toJson_10(_this__u8e3s4.w5r_1));
      tmp = builder_0.i3n();
    } else {
      noWhenBranchMatchedException();
    }
  }
  return tmp;
}
function toToolOutcome(_this__u8e3s4) {
  var tmp;
  switch (string(_this__u8e3s4, 'type')) {
    case 'success':
      var tmp_0 = string(_this__u8e3s4, 'output');
      var tmp1_elvis_lhs = booleanOrNull(_this__u8e3s4, 'return_directly');
      tmp = new Success(tmp_0, tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs);
      break;
    case 'failure':
      var tmp2_safe_receiver = objectOrNull(_this__u8e3s4, 'error');
      var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : stringOrNull(tmp2_safe_receiver, 'message');
      tmp = new Failure(new ToolError('hook', tmp3_elvis_lhs == null ? 'hook failure' : tmp3_elvis_lhs, false));
      break;
    default:
      var message = 'unknown tool outcome';
      throw IllegalStateException.t4(toString(message));
  }
  return tmp;
}
function toToolCall(_this__u8e3s4) {
  return new ToolCall(string(_this__u8e3s4, 'id'), string(_this__u8e3s4, 'name'), string(_this__u8e3s4, 'arguments_json'));
}
function toJson_7(_this__u8e3s4) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof Started) {
    builder.r3o('type', JsonPrimitive_0('started'));
    var tmp1_safe_receiver = _this__u8e3s4.d61_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.r3o('response_id', JsonPrimitive_0(tmp1_safe_receiver));
    }
  } else {
    if (_this__u8e3s4 instanceof CheckpointUpdated) {
      builder.r3o('type', JsonPrimitive_0('checkpoint_updated'));
      builder.r3o('checkpoint', toJson_21(_this__u8e3s4.c61_1));
    } else {
      if (_this__u8e3s4 instanceof TextDelta) {
        builder.r3o('type', JsonPrimitive_0('text_delta'));
        builder.r3o('text', JsonPrimitive_0(_this__u8e3s4.g5v_1));
        var tmp2_safe_receiver = _this__u8e3s4.h5v_1;
        var tmp = tmp2_safe_receiver;
        if ((tmp == null ? null : new ItemRef(tmp)) == null)
          null;
        else {
          var tmp_0 = tmp2_safe_receiver;
          // Inline function 'kotlin.let' call
          var it = (tmp_0 == null ? null : new ItemRef(tmp_0)).b61_1;
          builder.r3o('item_ref', JsonPrimitive_0(_ItemRef___get_value__impl__fpjuyb(it)));
        }
      } else {
        if (_this__u8e3s4 instanceof ReasoningDelta) {
          builder.r3o('type', JsonPrimitive_0('reasoning_delta'));
          builder.r3o('text', JsonPrimitive_0(_this__u8e3s4.e5v_1));
          var tmp3_safe_receiver = _this__u8e3s4.f5v_1;
          var tmp_1 = tmp3_safe_receiver;
          if ((tmp_1 == null ? null : new ItemRef(tmp_1)) == null)
            null;
          else {
            var tmp_2 = tmp3_safe_receiver;
            // Inline function 'kotlin.let' call
            var it_0 = (tmp_2 == null ? null : new ItemRef(tmp_2)).b61_1;
            builder.r3o('item_ref', JsonPrimitive_0(_ItemRef___get_value__impl__fpjuyb(it_0)));
          }
        } else {
          if (_this__u8e3s4 instanceof ItemAdded) {
            builder.r3o('type', JsonPrimitive_0('item_added'));
            builder.r3o('item', toJson_18(_this__u8e3s4.a61_1));
          } else {
            if (_this__u8e3s4 instanceof ToolCallDelta) {
              builder.r3o('type', JsonPrimitive_0('tool_call_delta'));
              builder.r3o('id', JsonPrimitive_0(_this__u8e3s4.v60_1));
              var tmp4_safe_receiver = _this__u8e3s4.w60_1;
              if (tmp4_safe_receiver == null)
                null;
              else {
                // Inline function 'kotlin.let' call
                builder.r3o('index', JsonPrimitive(tmp4_safe_receiver));
              }
              var tmp5_safe_receiver = _this__u8e3s4.x60_1;
              if (tmp5_safe_receiver == null)
                null;
              else {
                // Inline function 'kotlin.let' call
                builder.r3o('name_delta', JsonPrimitive_0(tmp5_safe_receiver));
              }
              var tmp6_safe_receiver = _this__u8e3s4.y60_1;
              if (tmp6_safe_receiver == null)
                null;
              else {
                // Inline function 'kotlin.let' call
                builder.r3o('arguments_delta', JsonPrimitive_0(tmp6_safe_receiver));
              }
              var tmp7_safe_receiver = _this__u8e3s4.z60_1;
              var tmp_3 = tmp7_safe_receiver;
              if ((tmp_3 == null ? null : new ItemRef(tmp_3)) == null)
                null;
              else {
                var tmp_4 = tmp7_safe_receiver;
                // Inline function 'kotlin.let' call
                var it_1 = (tmp_4 == null ? null : new ItemRef(tmp_4)).b61_1;
                builder.r3o('item_ref', JsonPrimitive_0(_ItemRef___get_value__impl__fpjuyb(it_1)));
              }
            } else {
              if (_this__u8e3s4 instanceof ToolCallCompleted) {
                builder.r3o('type', JsonPrimitive_0('tool_call_completed'));
                builder.r3o('call', toJson_16(_this__u8e3s4.d5v_1));
              } else {
                if (_this__u8e3s4 instanceof ProviderEvent) {
                  builder.r3o('type', JsonPrimitive_0('provider_event'));
                  builder.r3o('provider_id', JsonPrimitive_0(_ProviderId___get_value__impl__xo1tux(_this__u8e3s4.t6d_1)));
                  builder.r3o('event_type', JsonPrimitive_0(_this__u8e3s4.u6d_1));
                  builder.r3o('payload', JsonPrimitive_0(_this__u8e3s4.v6d_1));
                } else {
                  if (_this__u8e3s4 instanceof Finished) {
                    builder.r3o('type', JsonPrimitive_0('finished'));
                    builder.r3o('response', toJson_8(_this__u8e3s4.q5u_1));
                  } else {
                    noWhenBranchMatchedException();
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return builder.i3n();
}
function toModelEvent(_this__u8e3s4) {
  var tmp;
  switch (string(_this__u8e3s4, 'type')) {
    case 'started':
      tmp = new Started(stringOrNull(_this__u8e3s4, 'response_id'));
      break;
    case 'checkpoint_updated':
      tmp = new CheckpointUpdated(toCheckpoint(ensureNotNull(objectOrNull(_this__u8e3s4, 'checkpoint'))));
      break;
    case 'text_delta':
      var tmp_0 = string(_this__u8e3s4, 'text');
      var tmp1_safe_receiver = stringOrNull(_this__u8e3s4, 'item_ref');
      var tmp_1;
      if (tmp1_safe_receiver == null) {
        tmp_1 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_1 = _ItemRef___init__impl__ipmeex(tmp1_safe_receiver);
      }

      tmp = new TextDelta(tmp_0, tmp_1);
      break;
    case 'reasoning_delta':
      var tmp_2 = string(_this__u8e3s4, 'text');
      var tmp2_safe_receiver = stringOrNull(_this__u8e3s4, 'item_ref');
      var tmp_3;
      if (tmp2_safe_receiver == null) {
        tmp_3 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_3 = _ItemRef___init__impl__ipmeex(tmp2_safe_receiver);
      }

      tmp = new ReasoningDelta(tmp_2, tmp_3);
      break;
    case 'item_added':
      tmp = new ItemAdded(toModelItem(ensureNotNull(objectOrNull(_this__u8e3s4, 'item'))));
      break;
    case 'tool_call_delta':
      var tmp_4 = string(_this__u8e3s4, 'id');
      var tmp_5 = intOrNull(_this__u8e3s4, 'index');
      var tmp_6 = stringOrNull(_this__u8e3s4, 'name_delta');
      var tmp_7 = stringOrNull(_this__u8e3s4, 'arguments_delta');
      var tmp3_safe_receiver = stringOrNull(_this__u8e3s4, 'item_ref');
      var tmp_8;
      if (tmp3_safe_receiver == null) {
        tmp_8 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_8 = _ItemRef___init__impl__ipmeex(tmp3_safe_receiver);
      }

      tmp = new ToolCallDelta(tmp_4, tmp_5, tmp_6, tmp_7, tmp_8);
      break;
    case 'tool_call_completed':
      tmp = new ToolCallCompleted(toToolCall(ensureNotNull(objectOrNull(_this__u8e3s4, 'call'))));
      break;
    case 'provider_event':
      tmp = new ProviderEvent(_ProviderId___init__impl__nor0vf(string(_this__u8e3s4, 'provider_id')), string(_this__u8e3s4, 'event_type'), string(_this__u8e3s4, 'payload'));
      break;
    default:
      var message = "model event replacement type '" + string(_this__u8e3s4, 'type') + "' is not supported";
      throw IllegalStateException.t4(toString(message));
  }
  return tmp;
}
function toJson_8(_this__u8e3s4) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof Completed_0)
    builder.r3o('status', JsonPrimitive_0('completed'));
  else {
    if (_this__u8e3s4 instanceof Incomplete) {
      builder.r3o('status', JsonPrimitive_0('incomplete'));
      builder.r3o('reason', JsonPrimitive_0(toString(_this__u8e3s4.x5x_1)));
    } else {
      if (_this__u8e3s4 instanceof Failed_0) {
        builder.r3o('status', JsonPrimitive_0('failed'));
        builder.r3o('error', toJson_10(_this__u8e3s4.u5u_1));
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  var tmp1_safe_receiver = _this__u8e3s4.t60();
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('id', JsonPrimitive_0(tmp1_safe_receiver));
  }
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.r60().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    builder_0.p3o(toJson_18(element));
  }
  var tmp$ret$5 = builder_0.i3n();
  builder.r3o('output', tmp$ret$5);
  builder.r3o('usage', toJson_9(_this__u8e3s4.k5r()));
  var tmp2_safe_receiver = _this__u8e3s4.s5u();
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('checkpoint', toJson_21(tmp2_safe_receiver));
  }
  return builder.i3n();
}
function buildMemory$add(receiver, p0) {
  receiver.l(p0);
}
function buildAgent$lambda$lambda($config) {
  return ($this$model) => {
    var tmp0_elvis_lhs = $config.w2f('model');
    var tmp;
    if (tmp0_elvis_lhs == null) {
      var message = "'model' is required";
      throw IllegalStateException.t4(toString(message));
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var element = tmp;
    var tmp_0;
    if (element instanceof JsonArray) {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(element, 10));
      var _iterator__ex2g4s = element.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$0 = get_jsonObject(item);
        destination.l(tmp$ret$0);
      }
      tmp_0 = destination;
    } else {
      if (element instanceof JsonObject) {
        tmp_0 = listOf(element);
      } else {
        var message_0 = "'model' must be an object or non-empty array";
        throw IllegalStateException.t4(toString(message_0));
      }
    }
    var models = tmp_0;
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.require' call
    if (!!models.h1()) {
      var message_1 = "'model' must not be empty";
      throw IllegalArgumentException.t(toString(message_1));
    }
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(models, 10));
    var _iterator__ex2g4s_0 = models.y();
    while (_iterator__ex2g4s_0.z()) {
      var item_0 = _iterator__ex2g4s_0.a1();
      var tmp$ret$6 = selectProvider($this$model, item_0);
      destination_0.l(tmp$ret$6);
    }
    // Inline function 'kotlin.collections.reduce' call
    var iterator = destination_0.y();
    if (!iterator.z())
      throw UnsupportedOperationException.da("Empty collection can't be reduced.");
    var accumulator = iterator.a1();
    while (iterator.z()) {
      var tmp9 = accumulator;
      var p1 = iterator.a1();
      accumulator = tmp9.d60(p1);
    }
    return accumulator;
  };
}
function buildAgent$lambda$lambda_0($definitions, $callbacks, $toolExecutions) {
  return ($this$tools) => {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $definitions.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      $this$tools.m60(new NodeTool(get_jsonObject(element), $callbacks, $toolExecutions));
    }
    return Unit_instance;
  };
}
function buildAgent$lambda$lambda_1($memory) {
  return ($this$memory) => {
    $this$memory.z5q($memory.a5r(), $memory);
    return Unit_instance;
  };
}
function buildAgent$lambda$lambda_2($skillConfig, $callbacks, $toolExecutions) {
  return ($this$skills) => {
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_elvis_lhs = arrayOrNull($skillConfig, 'sources');
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = (tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var obj = get_jsonObject(element);
      switch (string(obj, 'type')) {
        case 'directory':
          $this$skills.i6j(string(obj, 'path'));
          break;
        case 'loader':
          $this$skills.j6j(new NodeSkillLoader(obj, $callbacks, $toolExecutions));
          break;
        default:
          // Inline function 'kotlin.error' call

          var message = "unknown skill source type '" + string(obj, 'type') + "'";
          throw IllegalStateException.t4(toString(message));
      }
    }
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_elvis_lhs_0 = arrayOrNull($skillConfig, 'use');
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = (tmp0_elvis_lhs_0 == null ? emptyList() : tmp0_elvis_lhs_0).y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      $this$skills.k6j(get_jsonPrimitive(element_0).j3o());
    }
    return Unit_instance;
  };
}
function invoke$add(receiver, p0) {
  receiver.l(p0);
}
function buildAgent$lambda$lambda_3($gateways, $callbacks, $owned) {
  return ($this$tools) => {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $gateways.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var obj = get_jsonObject(element);
      var tmp;
      switch (string(obj, 'type')) {
        case 'gateway':
          tmp = new NodeMcpGateway(obj, $callbacks);
          break;
        case 'http':
          var tmp_0 = string(obj, 'url');
          var tmp1_elvis_lhs = intOrNull(obj, 'client_id');
          var tmp_1 = new McpClientConfig(tmp1_elvis_lhs == null ? 1 : tmp1_elvis_lhs);
          var tmp2_safe_receiver = objectOrNull(obj, 'headers');
          var tmp_2;
          if (tmp2_safe_receiver == null) {
            tmp_2 = null;
          } else {
            // Inline function 'kotlin.collections.mapValues' call
            // Inline function 'kotlin.collections.mapValuesTo' call
            var destination = LinkedHashMap.ic(mapCapacity(tmp2_safe_receiver.b1()));
            // Inline function 'kotlin.collections.associateByTo' call
            var _iterator__ex2g4s_0 = tmp2_safe_receiver.l1().y();
            while (_iterator__ex2g4s_0.z()) {
              var element_0 = _iterator__ex2g4s_0.a1();
              var tmp_3 = element_0.m1();
              var tmp$ret$1 = get_jsonPrimitive(element_0.n1()).j3o();
              destination.k3(tmp_3, tmp$ret$1);
            }
            tmp_2 = destination;
          }

          // Inline function 'kotlin.collections.orEmpty' call

          var tmp0_elvis_lhs = tmp_2;
          var tmp$ret$5 = tmp0_elvis_lhs == null ? emptyMap() : tmp0_elvis_lhs;
          // Inline function 'kotlin.also' call

          var this_0 = new DefaultMcpClient(tmp_0, tmp_1, tmp$ret$5);
          invoke$add($owned, this_0);
          tmp = this_0;
          break;
        default:
          var message = "unknown MCP type '" + string(obj, 'type') + "'";
          throw IllegalStateException.t4(toString(message));
      }
      var gateway = tmp;
      $this$tools.o60(gateway);
    }
    return Unit_instance;
  };
}
function buildAgent$lambda($config, $callbacks, $owned, $toolExecutions) {
  return ($this$agent) => {
    $this$agent.e5p_1 = string($config, 'id');
    var tmp = $this$agent;
    var tmp0_elvis_lhs = stringOrNull($config, 'name');
    tmp.f5p_1 = tmp0_elvis_lhs == null ? string($config, 'id') : tmp0_elvis_lhs;
    configureInstructions($this$agent, $config.w2f('instructions'), $callbacks);
    $this$agent.b5q(buildAgent$lambda$lambda($config));
    var tmp1_safe_receiver = arrayOrNull($config, 'tools');
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$agent.c5q(buildAgent$lambda$lambda_0(tmp1_safe_receiver, $callbacks, $toolExecutions));
    }
    var tmp2_safe_receiver = objectOrNull($config, 'memory');
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var memory = buildMemory(tmp2_safe_receiver, $callbacks, $owned);
      $this$agent.g5q(buildAgent$lambda$lambda_1(memory));
    }
    var tmp3_safe_receiver = objectOrNull($config, 'skills');
    if (tmp3_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$agent.d5q(buildAgent$lambda$lambda_2(tmp3_safe_receiver, $callbacks, $toolExecutions));
    }
    var tmp4_safe_receiver = arrayOrNull($config, 'mcp');
    if (tmp4_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$agent.c5q(buildAgent$lambda$lambda_3(tmp4_safe_receiver, $callbacks, $owned));
    }
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_elvis_lhs_0 = arrayOrNull($config, 'hooks');
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = (tmp0_elvis_lhs_0 == null ? emptyList() : tmp0_elvis_lhs_0).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      $this$agent.i5q(new NodeHook(get_jsonObject(element), $callbacks));
    }
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_elvis_lhs_1 = arrayOrNull($config, 'listeners');
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = (tmp0_elvis_lhs_1 == null ? emptyList() : tmp0_elvis_lhs_1).y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      $this$agent.j5q(new NodeListener(get_jsonObject(element_0), $callbacks));
    }
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_elvis_lhs_2 = arrayOrNull($config, 'client_actions');
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_1 = (tmp0_elvis_lhs_2 == null ? emptyList() : tmp0_elvis_lhs_2).y();
    while (_iterator__ex2g4s_1.z()) {
      var element_1 = _iterator__ex2g4s_1.a1();
      $this$agent.p5q(new NodeClientActionHandler(string(get_jsonObject(element_1), 'callback_id'), $callbacks));
    }
    var tmp5_safe_receiver = objectOrNull($config, 'termination');
    if (tmp5_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var callback = stringOrNull(tmp5_safe_receiver, 'callback_id');
      if (callback == null) {
        $this$agent.k5q(buildTerminationPolicy(tmp5_safe_receiver));
      } else {
        $this$agent.l5q(buildSuspendTerminationPolicy(callback, $callbacks));
      }
    }
    var tmp6_safe_receiver = objectOrNull($config, 'run_budget');
    if (tmp6_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$agent.m5q(intOrNull(tmp6_safe_receiver, 'max_total_steps'), intOrNull(tmp6_safe_receiver, 'max_total_tokens'));
    }
    var tmp7_safe_receiver = objectOrNull($config, 'error_policy');
    if (tmp7_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      if (string(tmp7_safe_receiver, 'type') === 'custom') {
        $this$agent.o5q(buildSuspendErrorPolicy(string(tmp7_safe_receiver, 'callback_id'), $callbacks));
      } else {
        $this$agent.n5q(buildErrorPolicy(tmp7_safe_receiver));
      }
    }
    return Unit_instance;
  };
}
function *_generator_invoke__zhh2q8_23($this, $completion) {
  var tmp = string($this.r87_1, 'callback_id');
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('type', JsonPrimitive_0('resolve_instructions'));
  var tmp$ret$1 = builder.i3n();
  var tmp_0 = $this.q87_1.k81(tmp, tmp$ret$1, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  // Inline function 'kotlin.let' call
  var it = tmp_0;
  var tmp_1;
  if (it instanceof JsonNull) {
    tmp_1 = null;
  } else {
    tmp_1 = get_jsonPrimitive(it).j3o();
  }
  return tmp_1;
}
function configureInstructions$lambda$slambda_0($callbacks, $obj) {
  var i = new configureInstructions$lambda$slambda($callbacks, $obj);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function configureInstructions$lambda($value, $callbacks) {
  return ($this$instructions) => {
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = $value.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var obj = get_jsonObject(element);
      switch (string(obj, 'type')) {
        case 'static':
          $this$instructions.u5z(string(obj, 'text'));
          break;
        case 'dynamic':
          $this$instructions.v5z(configureInstructions$lambda$slambda_0($callbacks, obj));
          break;
        default:
          // Inline function 'kotlin.error' call

          var message = "unknown instruction segment '" + string(obj, 'type') + "'";
          throw IllegalStateException.t4(toString(message));
      }
    }
    return Unit_instance;
  };
}
function selectProvider$lambda$lambda($parallel, $vision, $jsonObject, $jsonSchema) {
  return ($this$capabilities) => {
    $this$capabilities.j7i_1 = $parallel;
    $this$capabilities.k7i_1 = $vision;
    $this$capabilities.l7i_1 = $jsonObject;
    $this$capabilities.m7i_1 = $jsonSchema;
    return Unit_instance;
  };
}
function selectProvider$lambda($config) {
  return ($this$openai) => {
    $this$openai.w7h_1 = doubleOrNull($config, 'temperature');
    $this$openai.x7h_1 = intOrNull($config, 'max_completion_tokens');
    $this$openai.y7h_1 = doubleOrNull($config, 'top_p');
    var tmp = $this$openai;
    var tmp0_safe_receiver = arrayOrNull($config, 'stop');
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(tmp0_safe_receiver, 10));
      var _iterator__ex2g4s = tmp0_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$0 = get_jsonPrimitive(item).j3o();
        destination.l(tmp$ret$0);
      }
      tmp_0 = destination;
    }
    tmp.z7h_1 = tmp_0;
    $this$openai.a7i_1 = doubleOrNull($config, 'presence_penalty');
    $this$openai.b7i_1 = doubleOrNull($config, 'frequency_penalty');
    $this$openai.c7i_1 = stringOrNull($config, 'reasoning_effort');
    var tmp1_safe_receiver = longOrNull($config, 'stream_idle_timeout_ms');
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$openai.d7i_1 = tmp1_safe_receiver;
    }
    var tmp0 = objectOrNull($config, 'capabilities');
    $l$block: {
      // Inline function 'org.koaks.node.applyCapabilities' call
      if (tmp0 == null) {
        break $l$block;
      }
      var tmp0_elvis_lhs = booleanOrNull(tmp0, 'parallel_tool_calls');
      var tmp1 = tmp0_elvis_lhs == null ? true : tmp0_elvis_lhs;
      var tmp1_elvis_lhs = booleanOrNull(tmp0, 'vision');
      var tmp2 = tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs;
      var tmp2_elvis_lhs = booleanOrNull(tmp0, 'json_object');
      var tmp3 = tmp2_elvis_lhs == null ? false : tmp2_elvis_lhs;
      var tmp3_elvis_lhs = booleanOrNull(tmp0, 'json_schema');
      var jsonSchema = tmp3_elvis_lhs == null ? false : tmp3_elvis_lhs;
      $this$openai.i7i(selectProvider$lambda$lambda(tmp1, tmp2, tmp3, jsonSchema));
    }
    return Unit_instance;
  };
}
function selectProvider$lambda$lambda_0($parallel, $vision, $jsonObject, $jsonSchema) {
  return ($this$capabilities) => {
    $this$capabilities.m7n_1 = $parallel;
    $this$capabilities.n7n_1 = $vision;
    $this$capabilities.o7n_1 = $jsonObject;
    $this$capabilities.p7n_1 = $jsonSchema;
    return Unit_instance;
  };
}
function selectProvider$lambda_0($config) {
  return ($this$openaiResponses) => {
    $this$openaiResponses.v7m_1 = doubleOrNull($config, 'temperature');
    $this$openaiResponses.w7m_1 = doubleOrNull($config, 'top_p');
    $this$openaiResponses.x7m_1 = intOrNull($config, 'max_output_tokens');
    $this$openaiResponses.y7m_1 = objectOrNull($config, 'reasoning');
    $this$openaiResponses.z7m_1 = stringOrNull($config, 'truncation');
    $this$openaiResponses.a7n_1 = booleanOrNull($config, 'background');
    var tmp0_safe_receiver = longOrNull($config, 'background_poll_interval_ms');
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$openaiResponses.b7n_1 = tmp0_safe_receiver;
    }
    var tmp1_safe_receiver = longOrNull($config, 'stream_idle_timeout_ms');
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$openaiResponses.c7n_1 = tmp1_safe_receiver;
    }
    var tmp = $this$openaiResponses;
    switch (stringOrNull($config, 'state_mode')) {
      case 'server_stored':
        tmp.d7n_1 = ResponsesStateMode_ServerStored_getInstance();
        break;
      case 'conversation':
        tmp.d7n_1 = ResponsesStateMode_Conversation_getInstance();
        break;
      default:
        tmp.d7n_1 = ResponsesStateMode_Replayable_getInstance();
        break;
    }
    var tmp_0 = $this$openaiResponses;
    var tmp3_elvis_lhs = booleanOrNull($config, 'persist_checkpoint');
    tmp_0.e7n_1 = tmp3_elvis_lhs == null ? false : tmp3_elvis_lhs;
    var tmp_1 = $this$openaiResponses;
    var tmp4_safe_receiver = arrayOrNull($config, 'include');
    var tmp_2;
    if (tmp4_safe_receiver == null) {
      tmp_2 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(tmp4_safe_receiver, 10));
      var _iterator__ex2g4s = tmp4_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$4 = get_jsonPrimitive(item).j3o();
        destination.l(tmp$ret$4);
      }
      tmp_2 = destination;
    }
    tmp_1.f7n_1 = tmp_2;
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_elvis_lhs = arrayOrNull($config, 'server_tools');
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = (tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs).y();
    while (_iterator__ex2g4s_0.z()) {
      var element = _iterator__ex2g4s_0.a1();
      var obj = get_jsonObject(element);
      switch (string(obj, 'type')) {
        case 'web_search':
          $this$openaiResponses.i7n(stringOrNull(obj, 'search_context_size'));
          break;
        case 'file_search':
          // Inline function 'kotlin.collections.orEmpty' call

          var tmp0_elvis_lhs_0 = arrayOrNull(obj, 'vector_store_ids');
          // Inline function 'kotlin.collections.map' call

          var this_0 = tmp0_elvis_lhs_0 == null ? emptyList() : tmp0_elvis_lhs_0;
          // Inline function 'kotlin.collections.mapTo' call

          var destination_0 = ArrayList.x(collectionSizeOrDefault(this_0, 10));
          var _iterator__ex2g4s_1 = this_0.y();
          while (_iterator__ex2g4s_1.z()) {
            var item_0 = _iterator__ex2g4s_1.a1();
            var tmp$ret$9 = get_jsonPrimitive(item_0).j3o();
            destination_0.l(tmp$ret$9);
          }

          // Inline function 'kotlin.collections.toTypedArray' call

          var tmp$ret$12 = copyToArray(destination_0);
          $this$openaiResponses.j7n(tmp$ret$12.slice());
          break;
        case 'code_interpreter':
          $this$openaiResponses.k7n(stringOrNull(obj, 'container'));
          break;
      }
    }
    var tmp0 = objectOrNull($config, 'capabilities');
    $l$block: {
      // Inline function 'org.koaks.node.applyCapabilities' call
      if (tmp0 == null) {
        break $l$block;
      }
      var tmp0_elvis_lhs_1 = booleanOrNull(tmp0, 'parallel_tool_calls');
      var tmp1 = tmp0_elvis_lhs_1 == null ? true : tmp0_elvis_lhs_1;
      var tmp1_elvis_lhs = booleanOrNull(tmp0, 'vision');
      var tmp2 = tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs;
      var tmp2_elvis_lhs = booleanOrNull(tmp0, 'json_object');
      var tmp3 = tmp2_elvis_lhs == null ? false : tmp2_elvis_lhs;
      var tmp3_elvis_lhs_0 = booleanOrNull(tmp0, 'json_schema');
      var jsonSchema = tmp3_elvis_lhs_0 == null ? false : tmp3_elvis_lhs_0;
      $this$openaiResponses.l7n(selectProvider$lambda$lambda_0(tmp1, tmp2, tmp3, jsonSchema));
    }
    return Unit_instance;
  };
}
function selectProvider$lambda$lambda_1($parallel, $vision, $jsonObject) {
  return ($this$capabilities) => {
    $this$capabilities.i7h_1 = $parallel;
    $this$capabilities.j7h_1 = $vision;
    $this$capabilities.k7h_1 = $jsonObject;
    return Unit_instance;
  };
}
function selectProvider$lambda_1($config) {
  return ($this$qwen) => {
    $this$qwen.v7g_1 = doubleOrNull($config, 'temperature');
    $this$qwen.w7g_1 = intOrNull($config, 'max_tokens');
    $this$qwen.x7g_1 = doubleOrNull($config, 'top_p');
    var tmp = $this$qwen;
    var tmp0_safe_receiver = arrayOrNull($config, 'stop');
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(tmp0_safe_receiver, 10));
      var _iterator__ex2g4s = tmp0_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$0 = get_jsonPrimitive(item).j3o();
        destination.l(tmp$ret$0);
      }
      tmp_0 = destination;
    }
    tmp.y7g_1 = tmp_0;
    $this$qwen.z7g_1 = doubleOrNull($config, 'presence_penalty');
    $this$qwen.a7h_1 = doubleOrNull($config, 'frequency_penalty');
    $this$qwen.b7h_1 = booleanOrNull($config, 'enable_thinking');
    var tmp1_safe_receiver = longOrNull($config, 'stream_idle_timeout_ms');
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$qwen.c7h_1 = tmp1_safe_receiver;
    }
    var tmp0 = objectOrNull($config, 'capabilities');
    $l$block: {
      // Inline function 'org.koaks.node.applyCapabilities' call
      if (tmp0 == null) {
        break $l$block;
      }
      var tmp0_elvis_lhs = booleanOrNull(tmp0, 'parallel_tool_calls');
      var tmp1 = tmp0_elvis_lhs == null ? true : tmp0_elvis_lhs;
      var tmp1_elvis_lhs = booleanOrNull(tmp0, 'vision');
      var tmp2 = tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs;
      var tmp2_elvis_lhs = booleanOrNull(tmp0, 'json_object');
      var tmp3 = tmp2_elvis_lhs == null ? false : tmp2_elvis_lhs;
      booleanOrNull(tmp0, 'json_schema');
      $this$qwen.h7h(selectProvider$lambda$lambda_1(tmp1, tmp2, tmp3));
    }
    return Unit_instance;
  };
}
function selectProvider$lambda$lambda_2($caps) {
  return ($this$capabilities) => {
    var tmp0_safe_receiver = booleanOrNull($caps, 'parallel_tool_calls');
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$capabilities.n7w_1 = tmp0_safe_receiver;
    }
    var tmp1_safe_receiver = booleanOrNull($caps, 'vision');
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$capabilities.o7w_1 = tmp1_safe_receiver;
    }
    var tmp2_safe_receiver = booleanOrNull($caps, 'json_object');
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$capabilities.p7w_1 = tmp2_safe_receiver;
    }
    var tmp3_safe_receiver = booleanOrNull($caps, 'assistant_prefill');
    if (tmp3_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$capabilities.q7w_1 = tmp3_safe_receiver;
    }
    return Unit_instance;
  };
}
function selectProvider$lambda_2($config) {
  return ($this$anthropic) => {
    var tmp0_safe_receiver = intOrNull($config, 'max_tokens');
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$anthropic.a7w_1 = tmp0_safe_receiver;
    }
    $this$anthropic.b7w_1 = doubleOrNull($config, 'temperature');
    $this$anthropic.c7w_1 = doubleOrNull($config, 'top_p');
    $this$anthropic.d7w_1 = intOrNull($config, 'top_k');
    var tmp = $this$anthropic;
    var tmp1_safe_receiver = arrayOrNull($config, 'stop_sequences');
    var tmp_0;
    if (tmp1_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(tmp1_safe_receiver, 10));
      var _iterator__ex2g4s = tmp1_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$2 = get_jsonPrimitive(item).j3o();
        destination.l(tmp$ret$2);
      }
      tmp_0 = destination;
    }
    tmp.e7w_1 = tmp_0;
    $this$anthropic.f7w_1 = objectOrNull($config, 'thinking');
    var tmp2_safe_receiver = stringOrNull($config, 'anthropic_version');
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$anthropic.g7w_1 = tmp2_safe_receiver;
    }
    var tmp3_safe_receiver = longOrNull($config, 'stream_idle_timeout_ms');
    if (tmp3_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$anthropic.h7w_1 = tmp3_safe_receiver;
    }
    var caps = objectOrNull($config, 'capabilities');
    var tmp_1;
    if (!(caps == null)) {
      $this$anthropic.m7w(selectProvider$lambda$lambda_2(caps));
      tmp_1 = Unit_instance;
    }
    return Unit_instance;
  };
}
function selectProvider$lambda$lambda_3($parallel, $vision, $jsonObject) {
  return ($this$capabilities) => {
    $this$capabilities.m7r_1 = $parallel;
    $this$capabilities.n7r_1 = $vision;
    $this$capabilities.o7r_1 = $jsonObject;
    return Unit_instance;
  };
}
function selectProvider$lambda_3($config) {
  return ($this$ollama) => {
    $this$ollama.b7r_1 = doubleOrNull($config, 'temperature');
    $this$ollama.c7r_1 = doubleOrNull($config, 'top_p');
    $this$ollama.d7r_1 = intOrNull($config, 'max_tokens');
    var tmp = $this$ollama;
    var tmp0_safe_receiver = arrayOrNull($config, 'stop');
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(tmp0_safe_receiver, 10));
      var _iterator__ex2g4s = tmp0_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$0 = get_jsonPrimitive(item).j3o();
        destination.l(tmp$ret$0);
      }
      tmp_0 = destination;
    }
    tmp.e7r_1 = tmp_0;
    $this$ollama.f7r_1 = booleanOrNull($config, 'think');
    var tmp1_safe_receiver = longOrNull($config, 'stream_idle_timeout_ms');
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this$ollama.g7r_1 = tmp1_safe_receiver;
    }
    var tmp0 = objectOrNull($config, 'capabilities');
    $l$block: {
      // Inline function 'org.koaks.node.applyCapabilities' call
      if (tmp0 == null) {
        break $l$block;
      }
      var tmp0_elvis_lhs = booleanOrNull(tmp0, 'parallel_tool_calls');
      var tmp1 = tmp0_elvis_lhs == null ? true : tmp0_elvis_lhs;
      var tmp1_elvis_lhs = booleanOrNull(tmp0, 'vision');
      var tmp2 = tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs;
      var tmp2_elvis_lhs = booleanOrNull(tmp0, 'json_object');
      var tmp3 = tmp2_elvis_lhs == null ? false : tmp2_elvis_lhs;
      booleanOrNull(tmp0, 'json_schema');
      $this$ollama.l7r(selectProvider$lambda$lambda_3(tmp1, tmp2, tmp3));
    }
    return Unit_instance;
  };
}
function *_generator_invoke__zhh2q8_24($this, thread, $completion) {
  var tmp = string($this.t87_1, 'open_callback_id');
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('thread_id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(thread)));
  var tmp$ret$1 = builder.i3n();
  var tmp_0 = $this.s87_1.k81(tmp, tmp$ret$1, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var opened = get_jsonObject(tmp_0);
  return new NodeThreadMemory(opened, $this.s87_1);
}
function buildMemory$slambda_0($callbacks, $config) {
  var i = new buildMemory$slambda($callbacks, $config);
  var l = (thread, $completion) => i.u87(thread.n68_1, $completion);
  l.$arity = 1;
  return l;
}
function buildMemory$lambda($callbacks, $callback) {
  return (event) => {
    $callbacks.z84($callback, toJson_1(event));
    return Unit_instance;
  };
}
function buildMemory$lambda_0(it) {
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_25($this, state, $completion) {
  var tmp = $this.v87_1.k81($this.w87_1, toJson_26(state), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var decision = get_jsonObject(tmp);
  var tmp_0;
  switch (string(decision, 'action')) {
    case 'continue':
      tmp_0 = Continue_instance;
      break;
    case 'stop':
      tmp_0 = new Stop(new Custom_0(string(decision, 'message')));
      break;
    default:
      var message = "unknown termination decision '" + string(decision, 'action') + "'";
      throw IllegalStateException.t4(toString(message));
  }
  return tmp_0;
}
function buildSuspendTerminationPolicy$slambda_0($callbacks, $callback) {
  var i = new buildSuspendTerminationPolicy$slambda($callbacks, $callback);
  var l = (state, $completion) => i.x87(state, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_26($this, error, state, $completion) {
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('error', toJson_10(error));
  builder.r3o('state', toJson_26(state));
  var tmp$ret$1 = builder.i3n();
  var tmp = $this.y87_1.k81($this.z87_1, tmp$ret$1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var decision = get_jsonObject(tmp);
  var tmp_0;
  switch (string(decision, 'action')) {
    case 'propagate':
      tmp_0 = Propagate_instance;
      break;
    case 'retry':
      var tmp1_elvis_lhs = longOrNull(decision, 'delay_ms');
      var tmp_1 = tmp1_elvis_lhs == null ? new Long(0, 0) : tmp1_elvis_lhs;
      var tmp2_elvis_lhs = intOrNull(decision, 'max_retries');
      tmp_0 = new Retry(tmp_1, tmp2_elvis_lhs == null ? 1 : tmp2_elvis_lhs);
      break;
    case 'substitute':
      var tmp3_safe_receiver = objectOrNull(decision, 'message');
      var tmp4_elvis_lhs = tmp3_safe_receiver == null ? null : toModelItem(tmp3_safe_receiver);
      var tmp_2;
      if (tmp4_elvis_lhs == null) {
        var message = "substitute requires 'message'";
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp_2 = tmp4_elvis_lhs;
      }

      tmp_0 = new Substitute(tmp_2);
      break;
    default:
      var message_0 = "unknown error policy decision '" + string(decision, 'action') + "'";
      throw IllegalStateException.t4(toString(message_0));
  }
  return tmp_0;
}
function buildSuspendErrorPolicy$slambda_0($callbacks, $callback) {
  var i = new buildSuspendErrorPolicy$slambda($callbacks, $callback);
  var l = (error, state, $completion) => i.a88(error, state, $completion);
  l.$arity = 2;
  return l;
}
function get_nodeJson() {
  _init_properties_NodeJson_kt__ig6gx6();
  return nodeJson;
}
var nodeJson;
function parseObject(text) {
  _init_properties_NodeJson_kt__ig6gx6();
  return isBlank(text) ? new JsonObject(emptyMap()) : get_jsonObject(get_nodeJson().b3m(text));
}
function string(_this__u8e3s4, name) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp0_safe_receiver = _this__u8e3s4.w2f(name);
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
  var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : get_contentOrNull(tmp1_safe_receiver);
  var tmp;
  if (tmp2_elvis_lhs == null) {
    var message = "'" + name + "' is required";
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp = tmp2_elvis_lhs;
  }
  return tmp;
}
function stringOrNull(_this__u8e3s4, name) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp0_safe_receiver = _this__u8e3s4.w2f(name);
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
  return tmp1_safe_receiver == null ? null : get_contentOrNull(tmp1_safe_receiver);
}
function intOrNull(_this__u8e3s4, name) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp0_safe_receiver = _this__u8e3s4.w2f(name);
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
  return tmp1_safe_receiver == null ? null : get_intOrNull(tmp1_safe_receiver);
}
function longOrNull(_this__u8e3s4, name) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp0_safe_receiver = _this__u8e3s4.w2f(name);
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
  return tmp1_safe_receiver == null ? null : get_longOrNull(tmp1_safe_receiver);
}
function doubleOrNull(_this__u8e3s4, name) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp0_safe_receiver = _this__u8e3s4.w2f(name);
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
  return tmp1_safe_receiver == null ? null : get_doubleOrNull(tmp1_safe_receiver);
}
function booleanOrNull(_this__u8e3s4, name) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp0_safe_receiver = _this__u8e3s4.w2f(name);
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
  return tmp1_safe_receiver == null ? null : get_booleanOrNull(tmp1_safe_receiver);
}
function objectOrNull(_this__u8e3s4, name) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp = _this__u8e3s4.w2f(name);
  return tmp instanceof JsonObject ? tmp : null;
}
function arrayOrNull(_this__u8e3s4, name) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp = _this__u8e3s4.w2f(name);
  return tmp instanceof JsonArray ? tmp : null;
}
function success(value) {
  value = value === VOID ? JsonNull_getInstance() : value;
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp = get_nodeJson();
  var tmp_0 = Companion_instance_1.c3o();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('ok', JsonPrimitive_2(true));
  builder.r3o('value', value);
  var tmp$ret$1 = builder.i3n();
  return tmp.y3l(tmp_0, tmp$ret$1);
}
function failure(error) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp = get_nodeJson();
  var tmp_0 = Companion_instance_1.c3o();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('ok', JsonPrimitive_2(false));
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder_0 = new JsonObjectBuilder();
  builder_0.r3o('type', JsonPrimitive_0(bridgeErrorCode(error)));
  var tmp0_elvis_lhs = error.message;
  var tmp1_elvis_lhs = tmp0_elvis_lhs == null ? getKClassFromExpression(error).hf() : tmp0_elvis_lhs;
  builder_0.r3o('message', JsonPrimitive_0(tmp1_elvis_lhs == null ? 'unknown error' : tmp1_elvis_lhs));
  var tmp2_safe_receiver = error instanceof NodeCallbackException ? error : null;
  var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.w84_1;
  var stack = tmp3_elvis_lhs == null ? stackTraceToString(error) : tmp3_elvis_lhs;
  // Inline function 'kotlin.takeIf' call
  var tmp_1;
  // Inline function 'kotlin.text.isNotBlank' call
  if (!isBlank(stack)) {
    tmp_1 = stack;
  } else {
    tmp_1 = null;
  }
  var tmp4_safe_receiver = tmp_1;
  if (tmp4_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder_0.r3o('stack', JsonPrimitive_0(tmp4_safe_receiver));
  }
  var tmp$ret$6 = builder_0.i3n();
  builder.r3o('error', tmp$ret$6);
  var tmp$ret$8 = builder.i3n();
  return tmp.y3l(tmp_0, tmp$ret$8);
}
function bridgeErrorCode(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp;
  if (_this__u8e3s4 instanceof CancellationException) {
    tmp = 'cancelled';
  } else {
    if (_this__u8e3s4 instanceof NodeBridgeException) {
      tmp = _this__u8e3s4.b82_1;
    } else {
      if (_this__u8e3s4 instanceof NodeCallbackException) {
        tmp = _this__u8e3s4.v84_1;
      } else {
        if (_this__u8e3s4 instanceof IllegalArgumentException) {
          tmp = 'configuration_error';
        } else {
          if (_this__u8e3s4 instanceof AgentIdConflictException) {
            tmp = 'agent_conflict';
          } else {
            if (_this__u8e3s4 instanceof ContextAccessException) {
              tmp = 'context_access';
            } else {
              if (_this__u8e3s4 instanceof IllegalStateException) {
                tmp = 'lifecycle_error';
              } else {
                tmp = 'bridge_error';
              }
            }
          }
        }
      }
    }
  }
  return tmp;
}
function toJson_9(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('prompt_tokens', JsonPrimitive(_this__u8e3s4.n5y_1));
  builder.r3o('completion_tokens', JsonPrimitive(_this__u8e3s4.o5y_1));
  builder.r3o('total_tokens', JsonPrimitive(_this__u8e3s4.p5y_1));
  builder.r3o('cached_input_tokens', JsonPrimitive(_this__u8e3s4.q5y_1));
  builder.r3o('reasoning_output_tokens', JsonPrimitive(_this__u8e3s4.r5y_1));
  return builder.i3n();
}
function toJson_10(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof ModelError) {
    builder.r3o('type', JsonPrimitive_0('model_error'));
    builder.r3o('retriable', JsonPrimitive_2(_this__u8e3s4.y69_1));
  } else {
    if (_this__u8e3s4 instanceof ToolError) {
      builder.r3o('type', JsonPrimitive_0('tool_error'));
      builder.r3o('tool_name', JsonPrimitive_0(_this__u8e3s4.a6a_1));
      builder.r3o('retriable', JsonPrimitive_2(_this__u8e3s4.c6a_1));
    } else {
      if (_this__u8e3s4 instanceof ParseError) {
        builder.r3o('type', JsonPrimitive_0('parse_error'));
        builder.r3o('raw', JsonPrimitive_0(_this__u8e3s4.f6a_1));
      } else {
        if (_this__u8e3s4 instanceof ToolNotFound) {
          builder.r3o('type', JsonPrimitive_0('tool_not_found'));
          builder.r3o('tool_name', JsonPrimitive_0(_this__u8e3s4.h6a_1));
        } else {
          if (_this__u8e3s4 instanceof SkillError) {
            builder.r3o('type', JsonPrimitive_0('skill_error'));
            var tmp1_safe_receiver = _this__u8e3s4.i6a_1;
            var tmp = tmp1_safe_receiver;
            if ((tmp == null ? null : new SkillId(tmp)) == null)
              null;
            else {
              var tmp_0 = tmp1_safe_receiver;
              // Inline function 'kotlin.let' call
              var it = (tmp_0 == null ? null : new SkillId(tmp_0)).b6j_1;
              builder.r3o('skill_id', JsonPrimitive_0(_SkillId___get_value__impl__n6yl35(it)));
            }
            // Inline function 'kotlin.text.lowercase' call
            // Inline function 'kotlin.js.asDynamic' call
            var tmp$ret$3 = _this__u8e3s4.j6a_1.n3_1.toLowerCase();
            builder.r3o('stage', JsonPrimitive_0(tmp$ret$3));
          } else {
            if (_this__u8e3s4 instanceof PreparationError) {
              builder.r3o('type', JsonPrimitive_0('preparation_error'));
              builder.r3o('component', JsonPrimitive_0(_this__u8e3s4.m6a_1));
            } else {
              if (_this__u8e3s4 instanceof Timeout) {
                builder.r3o('type', JsonPrimitive_0('timeout'));
                builder.r3o('stage', JsonPrimitive_0(_this__u8e3s4.p6a_1));
                builder.r3o('elapsed_ms', JsonPrimitive(_this__u8e3s4.q6a_1));
              } else {
                builder.r3o('type', JsonPrimitive_0('unknown_error'));
              }
            }
          }
        }
      }
    }
  }
  builder.r3o('message', JsonPrimitive_0(_this__u8e3s4.h2()));
  var tmp2_safe_receiver = _this__u8e3s4.i2();
  var tmp3_safe_receiver = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.message;
  if (tmp3_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('cause', JsonPrimitive_0(tmp3_safe_receiver));
  }
  return builder.i3n();
}
function toJson_11(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (equals(_this__u8e3s4, MaxOutputTokens_instance))
    builder.r3o('type', JsonPrimitive_0('max_output_tokens'));
  else {
    if (equals(_this__u8e3s4, ContentFilter_instance))
      builder.r3o('type', JsonPrimitive_0('content_filter'));
    else {
      if (equals(_this__u8e3s4, Cancelled_instance))
        builder.r3o('type', JsonPrimitive_0('cancelled'));
      else {
        if (_this__u8e3s4 instanceof Other) {
          builder.r3o('type', JsonPrimitive_0('other'));
          builder.r3o('code', JsonPrimitive_0(_this__u8e3s4.j6e_1));
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  return builder.i3n();
}
function toJson_12(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof MaxSteps) {
    builder.r3o('type', JsonPrimitive_0('max_steps'));
    builder.r3o('max_steps', JsonPrimitive(_this__u8e3s4.w6f_1));
  } else {
    if (_this__u8e3s4 instanceof MaxTokens) {
      builder.r3o('type', JsonPrimitive_0('max_tokens'));
      builder.r3o('max_tokens', JsonPrimitive(_this__u8e3s4.x6f_1));
    } else {
      if (_this__u8e3s4 instanceof RunBudgetSteps) {
        builder.r3o('type', JsonPrimitive_0('run_budget_steps'));
        builder.r3o('max_total_steps', JsonPrimitive(_this__u8e3s4.y6f_1));
      } else {
        if (_this__u8e3s4 instanceof RunBudgetTokens) {
          builder.r3o('type', JsonPrimitive_0('run_budget_tokens'));
          builder.r3o('max_total_tokens', JsonPrimitive(_this__u8e3s4.z6f_1));
        } else {
          if (_this__u8e3s4 instanceof Custom_0) {
            builder.r3o('type', JsonPrimitive_0('custom'));
            builder.r3o('message', JsonPrimitive_0(_this__u8e3s4.a6g_1));
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
  }
  return builder.i3n();
}
function toJson_13(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof Completed)
    builder.r3o('status', JsonPrimitive_0('completed'));
  else {
    if (_this__u8e3s4 instanceof Incomplete_0) {
      builder.r3o('status', JsonPrimitive_0('incomplete'));
      builder.r3o('reason', toJson_11(_this__u8e3s4.i5t_1));
    } else {
      if (_this__u8e3s4 instanceof Terminated) {
        builder.r3o('status', JsonPrimitive_0('terminated'));
        builder.r3o('reason', toJson_12(_this__u8e3s4.l5t_1));
      } else {
        if (_this__u8e3s4 instanceof Failed) {
          builder.r3o('status', JsonPrimitive_0('failed'));
          builder.r3o('error', toJson_10(_this__u8e3s4.n5t_1));
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  builder.r3o('text', JsonPrimitive_0(_this__u8e3s4.f5t()));
  builder.r3o('message', toJson_18(_this__u8e3s4.h2()));
  builder.r3o('usage', toJson_9(_this__u8e3s4.k5r()));
  return builder.i3n();
}
function toJson_14(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof TextDelta_0) {
    builder.r3o('type', JsonPrimitive_0('text_delta'));
    builder.r3o('text', JsonPrimitive_0(_this__u8e3s4.b5r_1));
  } else {
    if (_this__u8e3s4 instanceof ReasoningDelta_0) {
      builder.r3o('type', JsonPrimitive_0('reasoning_delta'));
      builder.r3o('text', JsonPrimitive_0(_this__u8e3s4.c5r_1));
    } else {
      if (_this__u8e3s4 instanceof ToolCallRequested) {
        builder.r3o('type', JsonPrimitive_0('tool_call_requested'));
        builder.r3o('call', toJson_16(_this__u8e3s4.d5r_1));
      } else {
        if (_this__u8e3s4 instanceof ToolResult) {
          builder.r3o('type', JsonPrimitive_0('tool_result'));
          builder.r3o('call_id', JsonPrimitive_0(_this__u8e3s4.e5r_1));
          builder.r3o('output', JsonPrimitive_0(_this__u8e3s4.f5r_1));
          builder.r3o('is_error', JsonPrimitive_2(_this__u8e3s4.g5r_1));
        } else {
          if (_this__u8e3s4 instanceof ToolProgress) {
            builder.r3o('type', JsonPrimitive_0('tool_progress'));
            builder.r3o('call_id', JsonPrimitive_0(_this__u8e3s4.h5r_1));
            builder.r3o('progress', toJson_15(_this__u8e3s4.i5r_1));
          } else {
            if (_this__u8e3s4 instanceof StepCompleted) {
              builder.r3o('type', JsonPrimitive_0('step_completed'));
              builder.r3o('step', JsonPrimitive(_this__u8e3s4.j5r_1));
            } else {
              if (_this__u8e3s4 instanceof Completed_1) {
                builder.r3o('type', JsonPrimitive_0('completed'));
                builder.r3o('message', toJson_18(_this__u8e3s4.l5r_1));
                builder.r3o('usage', toJson_9(_this__u8e3s4.m5r_1));
              } else {
                if (_this__u8e3s4 instanceof Incomplete_1) {
                  builder.r3o('type', JsonPrimitive_0('incomplete'));
                  builder.r3o('message', toJson_18(_this__u8e3s4.n5r_1));
                  builder.r3o('usage', toJson_9(_this__u8e3s4.o5r_1));
                  builder.r3o('reason', toJson_11(_this__u8e3s4.p5r_1));
                } else {
                  if (_this__u8e3s4 instanceof Terminated_0) {
                    builder.r3o('type', JsonPrimitive_0('terminated'));
                    builder.r3o('message', toJson_18(_this__u8e3s4.q5r_1));
                    builder.r3o('usage', toJson_9(_this__u8e3s4.r5r_1));
                    builder.r3o('reason', toJson_12(_this__u8e3s4.s5r_1));
                  } else {
                    if (_this__u8e3s4 instanceof Failed_1) {
                      builder.r3o('type', JsonPrimitive_0('failed'));
                      builder.r3o('error', toJson_10(_this__u8e3s4.u5r_1));
                      builder.r3o('usage', toJson_9(_this__u8e3s4.v5r_1));
                    } else {
                      noWhenBranchMatchedException();
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return builder.i3n();
}
function toJson_15(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof Output) {
    builder.r3o('type', JsonPrimitive_0('output'));
    builder.r3o('text', JsonPrimitive_0(_this__u8e3s4.l6k_1));
    builder.r3o('stream', JsonPrimitive_0(_this__u8e3s4.m6k_1.equals(ToolOutputStream_Stdout_getInstance()) ? 'stdout' : 'stderr'));
  } else {
    if (_this__u8e3s4 instanceof Status) {
      builder.r3o('type', JsonPrimitive_0('status'));
      builder.r3o('message', JsonPrimitive_0(_this__u8e3s4.n6k_1));
    } else {
      if (_this__u8e3s4 instanceof Custom) {
        builder.r3o('type', JsonPrimitive_0('custom'));
        builder.r3o('kind', JsonPrimitive_0(_this__u8e3s4.o6k_1));
        builder.r3o('payload', _this__u8e3s4.p6k_1);
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return builder.i3n();
}
function toJson_16(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('id', JsonPrimitive_0(_this__u8e3s4.m5v_1));
  builder.r3o('name', JsonPrimitive_0(_this__u8e3s4.n5v_1));
  builder.r3o('arguments_json', JsonPrimitive_0(_this__u8e3s4.o5v_1));
  var tmp0_safe_receiver = _this__u8e3s4.p5v_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('native_id', toJson_17(tmp0_safe_receiver));
  }
  var tmp1_safe_receiver = _this__u8e3s4.q5v_1;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('native_item_id', toJson_17(tmp1_safe_receiver));
  }
  return builder.i3n();
}
function toJson_17(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('provider_id', JsonPrimitive_0(_ProviderId___get_value__impl__xo1tux(_this__u8e3s4.p6b_1)));
  builder.r3o('raw', JsonPrimitive_0(_this__u8e3s4.q6b_1));
  return builder.i3n();
}
function toJson_18(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('ref', JsonPrimitive_0(_ItemRef___get_value__impl__fpjuyb(_this__u8e3s4.s5z())));
  var tmp0_safe_receiver = _this__u8e3s4.l6b();
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('native_id', toJson_17(tmp0_safe_receiver));
  }
  if (_this__u8e3s4 instanceof Message) {
    builder.r3o('type', JsonPrimitive_0('message'));
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$3 = _this__u8e3s4.c5o_1.n3_1.toLowerCase();
    builder.r3o('role', JsonPrimitive_0(tmp$ret$3));
    // Inline function 'kotlinx.serialization.json.buildJsonArray' call
    var builder_0 = new JsonArrayBuilder();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = _this__u8e3s4.d5o_1.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      builder_0.p3o(toJson_19(element));
    }
    var tmp$ret$7 = builder_0.i3n();
    builder.r3o('content', tmp$ret$7);
    var tmp2_safe_receiver = _this__u8e3s4.e5o_1;
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.r3o('refusal', JsonPrimitive_0(tmp2_safe_receiver));
    }
    // Inline function 'kotlinx.serialization.json.buildJsonArray' call
    var builder_1 = new JsonArrayBuilder();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = _this__u8e3s4.f5o_1.y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      builder_1.p3o(toJson_20(element_0));
    }
    var tmp$ret$13 = builder_1.i3n();
    builder.r3o('annotations', tmp$ret$13);
  } else {
    if (_this__u8e3s4 instanceof ToolCall_0) {
      builder.r3o('type', JsonPrimitive_0('tool_call'));
      builder.r3o('name', JsonPrimitive_0(_this__u8e3s4.f69_1));
      builder.r3o('arguments_json', JsonPrimitive_0(_this__u8e3s4.g69_1));
      var tmp3_safe_receiver = _this__u8e3s4.h69_1;
      if (tmp3_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder.r3o('native_item_id', toJson_17(tmp3_safe_receiver));
      }
    } else {
      if (_this__u8e3s4 instanceof ToolResult_0) {
        builder.r3o('type', JsonPrimitive_0('tool_result'));
        builder.r3o('call_ref', JsonPrimitive_0(_ItemRef___get_value__impl__fpjuyb(_this__u8e3s4.a69_1)));
        builder.r3o('output', JsonPrimitive_0(_this__u8e3s4.b69_1));
        builder.r3o('is_error', JsonPrimitive_2(_this__u8e3s4.c69_1));
      } else {
        if (_this__u8e3s4 instanceof ReasoningSummary) {
          builder.r3o('type', JsonPrimitive_0('reasoning_summary'));
          builder.r3o('text', JsonPrimitive_0(_this__u8e3s4.o6b_1));
        } else {
          if (_this__u8e3s4 instanceof ProviderItem) {
            builder.r3o('type', JsonPrimitive_0('provider_item'));
            builder.r3o('provider_id', JsonPrimitive_0(_ProviderId___get_value__impl__xo1tux(_this__u8e3s4.a5z_1)));
            builder.r3o('kind', JsonPrimitive_0(_this__u8e3s4.b5z_1));
            builder.r3o('display_text', JsonPrimitive_0(_this__u8e3s4.c5z_1));
            // Inline function 'kotlin.text.lowercase' call
            // Inline function 'kotlin.js.asDynamic' call
            var tmp$ret$17 = _this__u8e3s4.d5z_1.n3_1.toLowerCase();
            builder.r3o('replay', JsonPrimitive_0(tmp$ret$17));
            builder.r3o('payload_base64', JsonPrimitive_0(_this__u8e3s4.e5z_1.e42()));
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
  }
  return builder.i3n();
}
function toJson_19(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof Text) {
    builder.r3o('type', JsonPrimitive_0('text'));
    builder.r3o('text', JsonPrimitive_0(_this__u8e3s4.w6b_1));
  } else {
    if (_this__u8e3s4 instanceof Image) {
      builder.r3o('type', JsonPrimitive_0('image'));
      var tmp1_safe_receiver = _this__u8e3s4.u6b_1;
      if (tmp1_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder.r3o('url', JsonPrimitive_0(tmp1_safe_receiver));
      }
      var tmp2_safe_receiver = _this__u8e3s4.v6b_1;
      if (tmp2_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder.r3o('base64', JsonPrimitive_0(tmp2_safe_receiver));
      }
    } else {
      if (_this__u8e3s4 instanceof Audio) {
        builder.r3o('type', JsonPrimitive_0('audio'));
        var tmp3_safe_receiver = _this__u8e3s4.r6b_1;
        if (tmp3_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          builder.r3o('url', JsonPrimitive_0(tmp3_safe_receiver));
        }
        var tmp4_safe_receiver = _this__u8e3s4.s6b_1;
        if (tmp4_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          builder.r3o('base64', JsonPrimitive_0(tmp4_safe_receiver));
        }
        builder.r3o('format', JsonPrimitive_0(_this__u8e3s4.t6b_1));
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return builder.i3n();
}
function toJson_20(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof UrlCitation) {
    builder.r3o('type', JsonPrimitive_0('url_citation'));
    builder.r3o('url', JsonPrimitive_0(_this__u8e3s4.r6a_1));
    var tmp1_safe_receiver = _this__u8e3s4.s6a_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.r3o('title', JsonPrimitive_0(tmp1_safe_receiver));
    }
    var tmp2_safe_receiver = _this__u8e3s4.t6a_1;
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.r3o('start_index', JsonPrimitive(tmp2_safe_receiver));
    }
    var tmp3_safe_receiver = _this__u8e3s4.u6a_1;
    if (tmp3_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.r3o('end_index', JsonPrimitive(tmp3_safe_receiver));
    }
  } else {
    if (_this__u8e3s4 instanceof FileCitation) {
      builder.r3o('type', JsonPrimitive_0('file_citation'));
      builder.r3o('file_id', JsonPrimitive_0(_this__u8e3s4.v6a_1));
      var tmp4_safe_receiver = _this__u8e3s4.w6a_1;
      if (tmp4_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder.r3o('filename', JsonPrimitive_0(tmp4_safe_receiver));
      }
      var tmp5_safe_receiver = _this__u8e3s4.x6a_1;
      if (tmp5_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder.r3o('start_index', JsonPrimitive(tmp5_safe_receiver));
      }
      var tmp6_safe_receiver = _this__u8e3s4.y6a_1;
      if (tmp6_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder.r3o('end_index', JsonPrimitive(tmp6_safe_receiver));
      }
    } else {
      if (_this__u8e3s4 instanceof Generic) {
        builder.r3o('type', JsonPrimitive_0('generic'));
        builder.r3o('kind', JsonPrimitive_0(_this__u8e3s4.z6a_1));
        builder.r3o('payload', JsonPrimitive_0(_this__u8e3s4.a6b_1));
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return builder.i3n();
}
function toModelItem(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp0_safe_receiver = stringOrNull(_this__u8e3s4, 'ref');
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = _ItemRef___init__impl__ipmeex(tmp0_safe_receiver);
  }
  var tmp1_elvis_lhs = tmp;
  var tmp_0;
  var tmp_1 = tmp1_elvis_lhs;
  if ((tmp_1 == null ? null : new ItemRef(tmp_1)) == null) {
    tmp_0 = Companion_instance_3.w6c();
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var ref = tmp_0;
  var tmp2_safe_receiver = objectOrNull(_this__u8e3s4, 'native_id');
  var nativeId = tmp2_safe_receiver == null ? null : toProviderScopedId(tmp2_safe_receiver);
  var tmp_2;
  switch (string(_this__u8e3s4, 'type')) {
    case 'message':
      // Inline function 'kotlin.text.uppercase' call

      // Inline function 'kotlin.js.asDynamic' call

      var tmp$ret$3 = string(_this__u8e3s4, 'role').toUpperCase();
      var tmp_3 = valueOf(tmp$ret$3);
      // Inline function 'kotlin.collections.orEmpty' call

      var tmp0_elvis_lhs = arrayOrNull(_this__u8e3s4, 'content');
      // Inline function 'kotlin.collections.map' call

      var this_0 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
      // Inline function 'kotlin.collections.mapTo' call

      var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
      var _iterator__ex2g4s = this_0.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$5 = toContentPart(get_jsonObject(item));
        destination.l(tmp$ret$5);
      }

      var tmp_4 = destination;
      var tmp_5 = stringOrNull(_this__u8e3s4, 'refusal');
      // Inline function 'kotlin.collections.orEmpty' call

      var tmp0_elvis_lhs_0 = arrayOrNull(_this__u8e3s4, 'annotations');
      // Inline function 'kotlin.collections.map' call

      var this_1 = tmp0_elvis_lhs_0 == null ? emptyList() : tmp0_elvis_lhs_0;
      // Inline function 'kotlin.collections.mapTo' call

      var destination_0 = ArrayList.x(collectionSizeOrDefault(this_1, 10));
      var _iterator__ex2g4s_0 = this_1.y();
      while (_iterator__ex2g4s_0.z()) {
        var item_0 = _iterator__ex2g4s_0.a1();
        var tmp$ret$9 = toAnnotation(get_jsonObject(item_0));
        destination_0.l(tmp$ret$9);
      }

      tmp_2 = new Message(ref, nativeId, tmp_3, tmp_4, tmp_5, destination_0);
      break;
    case 'tool_call':
      var tmp_6 = string(_this__u8e3s4, 'name');
      var tmp_7 = string(_this__u8e3s4, 'arguments_json');
      var tmp4_safe_receiver = objectOrNull(_this__u8e3s4, 'native_item_id');
      tmp_2 = new ToolCall_0(ref, nativeId, tmp_6, tmp_7, tmp4_safe_receiver == null ? null : toProviderScopedId(tmp4_safe_receiver));
      break;
    case 'tool_result':
      var tmp_8 = _ItemRef___init__impl__ipmeex(string(_this__u8e3s4, 'call_ref'));
      var tmp_9 = string(_this__u8e3s4, 'output');
      var tmp5_elvis_lhs = booleanOrNull(_this__u8e3s4, 'is_error');
      tmp_2 = new ToolResult_0(ref, nativeId, tmp_8, tmp_9, tmp5_elvis_lhs == null ? false : tmp5_elvis_lhs);
      break;
    case 'reasoning_summary':
      tmp_2 = new ReasoningSummary(ref, nativeId, string(_this__u8e3s4, 'text'));
      break;
    case 'provider_item':
      var tmp_10 = _ProviderId___init__impl__nor0vf(string(_this__u8e3s4, 'provider_id'));
      var tmp_11 = string(_this__u8e3s4, 'kind');
      var tmp_12 = string(_this__u8e3s4, 'display_text');
      // Inline function 'kotlin.text.replaceFirstChar' call

      var this_2 = string(_this__u8e3s4, 'replay');
      var tmp_13;
      // Inline function 'kotlin.text.isNotEmpty' call

      if (charSequenceLength(this_2) > 0) {
        // Inline function 'kotlin.text.uppercase' call
        var this_3 = charSequenceGet(this_2, 0);
        // Inline function 'kotlin.js.asDynamic' call
        // Inline function 'kotlin.js.unsafeCast' call
        var tmp$ret$16 = toString_1(this_3).toUpperCase();
        var tmp_14 = toString(tmp$ret$16);
        // Inline function 'kotlin.text.substring' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp_13 = tmp_14 + this_2.substring(1);
      } else {
        tmp_13 = this_2;
      }

      var tmp$ret$19 = tmp_13;
      var tmp_15 = valueOf_0(tmp$ret$19);
      var tmp11 = Companion_getInstance_1().b42(string(_this__u8e3s4, 'payload_base64'));
      var tmp$ret$21;
      $l$block: {
        // Inline function 'kotlin.requireNotNull' call
        if (tmp11 == null) {
          var message = 'invalid provider item payload_base64';
          throw IllegalArgumentException.t(toString(message));
        } else {
          tmp$ret$21 = tmp11;
          break $l$block;
        }
      }

      tmp_2 = new ProviderItem(ref, nativeId, tmp_10, tmp_11, tmp_12, tmp_15, tmp$ret$21);
      break;
    default:
      var message_0 = "unknown model item type '" + string(_this__u8e3s4, 'type') + "'";
      throw IllegalStateException.t4(toString(message_0));
  }
  return tmp_2;
}
function toProviderScopedId(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  return new ProviderScopedId(_ProviderId___init__impl__nor0vf(string(_this__u8e3s4, 'provider_id')), string(_this__u8e3s4, 'raw'));
}
function toContentPart(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp;
  switch (string(_this__u8e3s4, 'type')) {
    case 'text':
      tmp = new Text(string(_this__u8e3s4, 'text'));
      break;
    case 'image':
      tmp = new Image(stringOrNull(_this__u8e3s4, 'url'), stringOrNull(_this__u8e3s4, 'base64'));
      break;
    case 'audio':
      tmp = new Audio(stringOrNull(_this__u8e3s4, 'url'), stringOrNull(_this__u8e3s4, 'base64'), string(_this__u8e3s4, 'format'));
      break;
    default:
      var message = "unknown content part type '" + string(_this__u8e3s4, 'type') + "'";
      throw IllegalStateException.t4(toString(message));
  }
  return tmp;
}
function toAnnotation(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp;
  switch (string(_this__u8e3s4, 'type')) {
    case 'url_citation':
      tmp = new UrlCitation(string(_this__u8e3s4, 'url'), stringOrNull(_this__u8e3s4, 'title'), intOrNull(_this__u8e3s4, 'start_index'), intOrNull(_this__u8e3s4, 'end_index'));
      break;
    case 'file_citation':
      tmp = new FileCitation(string(_this__u8e3s4, 'file_id'), stringOrNull(_this__u8e3s4, 'filename'), intOrNull(_this__u8e3s4, 'start_index'), intOrNull(_this__u8e3s4, 'end_index'));
      break;
    case 'generic':
      tmp = new Generic(string(_this__u8e3s4, 'kind'), string(_this__u8e3s4, 'payload'));
      break;
    default:
      var message = "unknown annotation type '" + string(_this__u8e3s4, 'type') + "'";
      throw IllegalStateException.t4(toString(message));
  }
  return tmp;
}
function toJson_21(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('provider_id', JsonPrimitive_0(_ProviderId___get_value__impl__xo1tux(_this__u8e3s4.e6b_1)));
  builder.r3o('codec_version', JsonPrimitive(_this__u8e3s4.f6b_1));
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder_0 = new JsonObjectBuilder();
  builder_0.r3o('item_count', JsonPrimitive(_this__u8e3s4.g6b_1.c6b_1));
  builder_0.r3o('digest', JsonPrimitive_0(_this__u8e3s4.g6b_1.d6b_1));
  var tmp$ret$1 = builder_0.i3n();
  builder.r3o('basis', tmp$ret$1);
  var tmp;
  switch (_this__u8e3s4.h6b_1.o3_1) {
    case 0:
      tmp = 'in_run';
      break;
    case 1:
      tmp = 'cross_turn';
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  builder.r3o('scope', JsonPrimitive_0(tmp));
  builder.r3o('payload_base64', JsonPrimitive_0(_this__u8e3s4.i6b_1.e42()));
  var tmp1_safe_receiver = _this__u8e3s4.j6b_1;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('expires_at_epoch_ms', JsonPrimitive(tmp1_safe_receiver));
  }
  return builder.i3n();
}
function toCheckpoint(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  var tmp = _ProviderId___init__impl__nor0vf(string(_this__u8e3s4, 'provider_id'));
  var tmp0_elvis_lhs = intOrNull(_this__u8e3s4, 'codec_version');
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    var message = "'codec_version' is required";
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var tmp_1 = tmp_0;
  // Inline function 'kotlin.let' call
  var it = ensureNotNull(objectOrNull(_this__u8e3s4, 'basis'));
  var tmp_2 = new TranscriptBasis(ensureNotNull(intOrNull(it, 'item_count')), string(it, 'digest'));
  var tmp_3;
  switch (string(_this__u8e3s4, 'scope')) {
    case 'in_run':
      tmp_3 = CheckpointScope_InRun_getInstance();
      break;
    case 'cross_turn':
      tmp_3 = CheckpointScope_CrossTurn_getInstance();
      break;
    default:
      var message_0 = "unknown checkpoint scope '" + string(_this__u8e3s4, 'scope') + "'";
      throw IllegalStateException.t4(toString(message_0));
  }
  var tmp_4 = tmp_3;
  // Inline function 'kotlin.requireNotNull' call
  var tmp0 = Companion_getInstance_1().b42(string(_this__u8e3s4, 'payload_base64'));
  var tmp$ret$3;
  $l$block: {
    // Inline function 'kotlin.requireNotNull' call
    if (tmp0 == null) {
      var message_1 = 'Required value was null.';
      throw IllegalArgumentException.t(toString(message_1));
    } else {
      tmp$ret$3 = tmp0;
      break $l$block;
    }
  }
  var tmp$ret$4 = tmp$ret$3;
  return new ProviderCheckpoint(tmp, tmp_1, tmp_2, tmp_4, tmp$ret$4, longOrNull(_this__u8e3s4, 'expires_at_epoch_ms'));
}
function toMemoryView(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlin.collections.orEmpty' call
  var tmp0_elvis_lhs = arrayOrNull(_this__u8e3s4, 'transcript');
  // Inline function 'kotlin.collections.map' call
  var this_0 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$1 = toModelItem(get_jsonObject(item));
    destination.l(tmp$ret$1);
  }
  var tmp = destination;
  var tmp0_safe_receiver = objectOrNull(_this__u8e3s4, 'checkpoint');
  return new MemoryView(tmp, tmp0_safe_receiver == null ? null : toCheckpoint(tmp0_safe_receiver));
}
function toJson_22(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('id', JsonPrimitive_0(_this__u8e3s4.z67_1));
  builder.r3o('status', toJson_23(_this__u8e3s4.a68_1));
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.b68_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    builder_0.p3o(toJson_18(element));
  }
  var tmp$ret$3 = builder_0.i3n();
  builder.r3o('items', tmp$ret$3);
  var tmp0_safe_receiver = _this__u8e3s4.c68_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('checkpoint', toJson_21(tmp0_safe_receiver));
  }
  builder.r3o('usage', toJson_9(_this__u8e3s4.d68_1));
  return builder.i3n();
}
function toJson_23(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (equals(_this__u8e3s4, Completed_instance))
    builder.r3o('type', JsonPrimitive_0('completed'));
  else {
    if (_this__u8e3s4 instanceof Interrupted) {
      builder.r3o('type', JsonPrimitive_0('interrupted'));
      builder.r3o('reason', toJson_24(_this__u8e3s4.g68_1));
      builder.r3o('pending', toJson_25(_this__u8e3s4.h68_1));
    } else {
      noWhenBranchMatchedException();
    }
  }
  return builder.i3n();
}
function toJson_24(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (equals(_this__u8e3s4, Cancelled_instance_0))
    builder.r3o('type', JsonPrimitive_0('cancelled'));
  else {
    if (equals(_this__u8e3s4, Failed_instance))
      builder.r3o('type', JsonPrimitive_0('failed'));
    else {
      if (_this__u8e3s4 instanceof Incomplete_2) {
        builder.r3o('type', JsonPrimitive_0('incomplete'));
        builder.r3o('reason', toJson_11(_this__u8e3s4.i68_1));
      } else {
        if (_this__u8e3s4 instanceof Policy) {
          builder.r3o('type', JsonPrimitive_0('policy'));
          builder.r3o('detail', JsonPrimitive_0(_this__u8e3s4.j68_1));
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  return builder.i3n();
}
function toJson_25(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.k68_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var it = element.b61_1;
    builder_0.p3o(JsonPrimitive_0(_ItemRef___get_value__impl__fpjuyb(it)));
  }
  var tmp$ret$3 = builder_0.i3n();
  builder.r3o('unresolved_calls', tmp$ret$3);
  var tmp0_safe_receiver = _this__u8e3s4.l68_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('partial_text', JsonPrimitive_0(tmp0_safe_receiver));
  }
  var tmp1_safe_receiver = _this__u8e3s4.m68_1;
  var tmp = tmp1_safe_receiver;
  if ((tmp == null ? null : new ItemRef(tmp)) == null)
    null;
  else {
    var tmp_0 = tmp1_safe_receiver;
    // Inline function 'kotlin.let' call
    var it_0 = (tmp_0 == null ? null : new ItemRef(tmp_0)).b61_1;
    builder.r3o('partial_item', JsonPrimitive_0(_ItemRef___get_value__impl__fpjuyb(it_0)));
  }
  return builder.i3n();
}
function toJson_26(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.s5o_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    builder_0.p3o(toJson_18(element));
  }
  var tmp$ret$3 = builder_0.i3n();
  builder.r3o('items', tmp$ret$3);
  var tmp0_safe_receiver = _this__u8e3s4.t5o_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('instructions', JsonPrimitive_0(tmp0_safe_receiver));
  }
  var tmp1_safe_receiver = _this__u8e3s4.u5o_1;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('checkpoint', toJson_21(tmp1_safe_receiver));
  }
  builder.r3o('global_step', JsonPrimitive(_this__u8e3s4.v5o_1));
  builder.r3o('local_step', JsonPrimitive(_this__u8e3s4.w5o_1));
  builder.r3o('usage', toJson_9(_this__u8e3s4.x5o_1));
  builder.r3o('active_agent_name', JsonPrimitive_0(_this__u8e3s4.y5o_1));
  return builder.i3n();
}
function toJson_27(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('run_id', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(_this__u8e3s4.x6q_1).toString()));
  builder.r3o('agent_id', JsonPrimitive_0(_AgentId___get_value__impl__1mym7n(_this__u8e3s4.y6q_1)));
  builder.r3o('agent_name', JsonPrimitive_0(_this__u8e3s4.z6q_1));
  var tmp0_safe_receiver = _this__u8e3s4.a6r_1;
  var tmp = tmp0_safe_receiver;
  if ((tmp == null ? null : new ThreadId(tmp)) == null)
    null;
  else {
    var tmp_0 = tmp0_safe_receiver;
    // Inline function 'kotlin.let' call
    var it = (tmp_0 == null ? null : new ThreadId(tmp_0)).n68_1;
    builder.r3o('thread_id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(it)));
  }
  var tmp1_safe_receiver = _this__u8e3s4.b6r_1;
  var tmp_1 = tmp1_safe_receiver;
  if ((tmp_1 == null ? null : new TurnId(tmp_1)) == null)
    null;
  else {
    var tmp_2 = tmp1_safe_receiver;
    // Inline function 'kotlin.let' call
    var it_0 = (tmp_2 == null ? null : new TurnId(tmp_2)).x6u_1;
    builder.r3o('turn_id', JsonPrimitive_0(_TurnId___get_value__impl__w6r3h9(it_0).toString()));
  }
  // Inline function 'kotlin.text.lowercase' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$5 = _this__u8e3s4.c6r_1.n3_1.toLowerCase();
  builder.r3o('state', JsonPrimitive_0(tmp$ret$5));
  builder.r3o('priority', JsonPrimitive(_this__u8e3s4.d6r_1));
  var tmp2_safe_receiver = _this__u8e3s4.e6r_1;
  var tmp_3 = tmp2_safe_receiver;
  if ((tmp_3 == null ? null : new RunId(tmp_3)) == null)
    null;
  else {
    var tmp_4 = tmp2_safe_receiver;
    // Inline function 'kotlin.let' call
    var it_1 = (tmp_4 == null ? null : new RunId(tmp_4)).z6w_1;
    builder.r3o('parent', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(it_1).toString()));
  }
  var tmp3_safe_receiver = _this__u8e3s4.f6r_1;
  if (tmp3_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('correlation_id', JsonPrimitive_0(tmp3_safe_receiver));
  }
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.g6r_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var it_2 = element.z6w_1;
    builder_0.p3o(JsonPrimitive_0(_RunId___get_value__impl__30zeiv(it_2).toString()));
  }
  var tmp$ret$13 = builder_0.i3n();
  builder.r3o('children', tmp$ret$13);
  builder.r3o('accepting_children', JsonPrimitive_2(_this__u8e3s4.h6r_1));
  builder.r3o('usage', toJson_9(_this__u8e3s4.i6r_1));
  builder.r3o('steps_completed', JsonPrimitive(_this__u8e3s4.j6r_1));
  builder.r3o('tool_calls', JsonPrimitive(_this__u8e3s4.k6r_1));
  builder.r3o('elapsed_ms', JsonPrimitive(_this__u8e3s4.l6r_1));
  var tmp4_safe_receiver = _this__u8e3s4.m6r_1;
  if (tmp4_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('error', toJson_10(tmp4_safe_receiver));
  }
  return builder.i3n();
}
function toJson_28(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('run_id', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(_this__u8e3s4.b6n_1).toString()));
  builder.r3o('agent_id', JsonPrimitive_0(_AgentId___get_value__impl__1mym7n(_this__u8e3s4.c6n_1)));
  var tmp0_safe_receiver = _this__u8e3s4.d6n_1;
  var tmp = tmp0_safe_receiver;
  if ((tmp == null ? null : new ThreadId(tmp)) == null)
    null;
  else {
    var tmp_0 = tmp0_safe_receiver;
    // Inline function 'kotlin.let' call
    var it = (tmp_0 == null ? null : new ThreadId(tmp_0)).n68_1;
    builder.r3o('thread_id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(it)));
  }
  var tmp1_safe_receiver = _this__u8e3s4.e6n_1;
  var tmp_1 = tmp1_safe_receiver;
  if ((tmp_1 == null ? null : new TurnId(tmp_1)) == null)
    null;
  else {
    var tmp_2 = tmp1_safe_receiver;
    // Inline function 'kotlin.let' call
    var it_0 = (tmp_2 == null ? null : new TurnId(tmp_2)).x6u_1;
    builder.r3o('turn_id', JsonPrimitive_0(_TurnId___get_value__impl__w6r3h9(it_0).toString()));
  }
  var tmp2_safe_receiver = _this__u8e3s4.f6n_1;
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    builder.r3o('correlation_id', JsonPrimitive_0(tmp2_safe_receiver));
  }
  builder.r3o('sequence', JsonPrimitive(_this__u8e3s4.g6n_1));
  builder.r3o('timestamp_epoch_ms', JsonPrimitive(_this__u8e3s4.h6n_1));
  var value = _this__u8e3s4.i6n_1;
  if (value instanceof Agent) {
    builder.r3o('kind', JsonPrimitive_0('agent'));
    builder.r3o('event', toJson_14(value.t6n_1));
  } else {
    if (value instanceof Lifecycle) {
      builder.r3o('kind', JsonPrimitive_0('lifecycle'));
      builder.r3o('event', toJson_31(value.o74_1));
    } else {
      if (value instanceof HistoryGap) {
        builder.r3o('kind', JsonPrimitive_0('history_gap'));
        builder.r3o('requested_after', JsonPrimitive(value.j6n_1));
        builder.r3o('oldest_available', JsonPrimitive(value.k6n_1));
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return builder.i3n();
}
function toJson_29(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('id', JsonPrimitive_0(_ThreadId___get_value__impl__tytyxc(_this__u8e3s4.m79_1)));
  builder.r3o('memory_provider_id', JsonPrimitive_0(_MemoryProviderId___get_value__impl__90yl20(_this__u8e3s4.n79_1)));
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.o79_1.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var it = element.l5s_1;
    builder_0.p3o(JsonPrimitive_0(_AgentId___get_value__impl__1mym7n(it)));
  }
  var tmp$ret$3 = builder_0.i3n();
  builder.r3o('participants', tmp$ret$3);
  var tmp0_safe_receiver = _this__u8e3s4.p79_1;
  var tmp = tmp0_safe_receiver;
  if ((tmp == null ? null : new TurnId(tmp)) == null)
    null;
  else {
    var tmp_0 = tmp0_safe_receiver;
    // Inline function 'kotlin.let' call
    var it_0 = (tmp_0 == null ? null : new TurnId(tmp_0)).x6u_1;
    builder.r3o('active_turn', JsonPrimitive_0(_TurnId___get_value__impl__w6r3h9(it_0).toString()));
  }
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_1 = new JsonArrayBuilder();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_0 = _this__u8e3s4.q79_1.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    var it_1 = element_0.x6u_1;
    builder_1.p3o(JsonPrimitive_0(_TurnId___get_value__impl__w6r3h9(it_1).toString()));
  }
  var tmp$ret$9 = builder_1.i3n();
  builder.r3o('queued_turns', tmp$ret$9);
  return builder.i3n();
}
function toJson_30(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.r3o('total', JsonPrimitive(_this__u8e3s4.a77_1));
  builder.r3o('created', JsonPrimitive(_this__u8e3s4.b77_1));
  builder.r3o('thread_queued', JsonPrimitive(_this__u8e3s4.c77_1));
  builder.r3o('ready', JsonPrimitive(_this__u8e3s4.d77_1));
  builder.r3o('running', JsonPrimitive(_this__u8e3s4.e77_1));
  builder.r3o('waiting', JsonPrimitive(_this__u8e3s4.f77_1));
  builder.r3o('suspended', JsonPrimitive(_this__u8e3s4.g77_1));
  builder.r3o('committing', JsonPrimitive(_this__u8e3s4.h77_1));
  builder.r3o('finished', JsonPrimitive(_this__u8e3s4.i77_1));
  builder.r3o('failed', JsonPrimitive(_this__u8e3s4.j77_1));
  builder.r3o('cancelled', JsonPrimitive(_this__u8e3s4.k77_1));
  builder.r3o('total_tokens', JsonPrimitive(_this__u8e3s4.l77_1));
  builder.r3o('total_steps', JsonPrimitive(_this__u8e3s4.m77_1));
  builder.r3o('total_tool_calls', JsonPrimitive(_this__u8e3s4.n77_1));
  return builder.i3n();
}
function toJson_31(_this__u8e3s4) {
  _init_properties_NodeJson_kt__ig6gx6();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  if (_this__u8e3s4 instanceof Spawned) {
    var tmp = _RunId___get_value__impl__30zeiv(_this__u8e3s4.w73_1).toString();
    var tmp_0 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.x73_1);
    var tmp1_safe_receiver = _this__u8e3s4.z73_1;
    var tmp_1;
    var tmp_2 = tmp1_safe_receiver;
    if ((tmp_2 == null ? null : new ThreadId(tmp_2)) == null) {
      tmp_1 = null;
    } else {
      tmp_1 = _ThreadId___get_value__impl__tytyxc(tmp1_safe_receiver);
    }
    var tmp_3 = tmp_1;
    var tmp2_safe_receiver = _this__u8e3s4.a74_1;
    var tmp_4;
    var tmp_5 = tmp2_safe_receiver;
    if ((tmp_5 == null ? null : new TurnId(tmp_5)) == null) {
      tmp_4 = null;
    } else {
      tmp_4 = _TurnId___get_value__impl__w6r3h9(tmp2_safe_receiver);
    }
    var tmp3_safe_receiver = tmp_4;
    toJson$_anonymous_$base_opqqdz(builder, 'spawned', tmp, tmp_0, tmp_3, tmp3_safe_receiver == null ? null : tmp3_safe_receiver.toString());
    builder.r3o('agent_name', JsonPrimitive_0(_this__u8e3s4.y73_1));
    builder.r3o('priority', JsonPrimitive(_this__u8e3s4.b74_1));
    var tmp4_safe_receiver = _this__u8e3s4.c74_1;
    var tmp_6 = tmp4_safe_receiver;
    if ((tmp_6 == null ? null : new RunId(tmp_6)) == null)
      null;
    else {
      var tmp_7 = tmp4_safe_receiver;
      // Inline function 'kotlin.let' call
      var it = (tmp_7 == null ? null : new RunId(tmp_7)).z6w_1;
      builder.r3o('parent', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(it).toString()));
    }
  } else {
    if (_this__u8e3s4 instanceof Running) {
      var tmp_8 = _RunId___get_value__impl__30zeiv(_this__u8e3s4.r73_1).toString();
      var tmp_9 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.s73_1);
      var tmp5_safe_receiver = _this__u8e3s4.t73_1;
      var tmp_10;
      var tmp_11 = tmp5_safe_receiver;
      if ((tmp_11 == null ? null : new ThreadId(tmp_11)) == null) {
        tmp_10 = null;
      } else {
        tmp_10 = _ThreadId___get_value__impl__tytyxc(tmp5_safe_receiver);
      }
      var tmp_12 = tmp_10;
      var tmp6_safe_receiver = _this__u8e3s4.u73_1;
      var tmp_13;
      var tmp_14 = tmp6_safe_receiver;
      if ((tmp_14 == null ? null : new TurnId(tmp_14)) == null) {
        tmp_13 = null;
      } else {
        tmp_13 = _TurnId___get_value__impl__w6r3h9(tmp6_safe_receiver);
      }
      var tmp7_safe_receiver = tmp_13;
      toJson$_anonymous_$base_opqqdz(builder, 'running', tmp_8, tmp_9, tmp_12, tmp7_safe_receiver == null ? null : tmp7_safe_receiver.toString());
      builder.r3o('agent_name', JsonPrimitive_0(_this__u8e3s4.v73_1));
    } else {
      if (_this__u8e3s4 instanceof Waiting) {
        var tmp_15 = _RunId___get_value__impl__30zeiv(_this__u8e3s4.n73_1).toString();
        var tmp_16 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.o73_1);
        var tmp8_safe_receiver = _this__u8e3s4.p73_1;
        var tmp_17;
        var tmp_18 = tmp8_safe_receiver;
        if ((tmp_18 == null ? null : new ThreadId(tmp_18)) == null) {
          tmp_17 = null;
        } else {
          tmp_17 = _ThreadId___get_value__impl__tytyxc(tmp8_safe_receiver);
        }
        var tmp_19 = tmp_17;
        var tmp9_safe_receiver = _this__u8e3s4.q73_1;
        var tmp_20;
        var tmp_21 = tmp9_safe_receiver;
        if ((tmp_21 == null ? null : new TurnId(tmp_21)) == null) {
          tmp_20 = null;
        } else {
          tmp_20 = _TurnId___get_value__impl__w6r3h9(tmp9_safe_receiver);
        }
        var tmp10_safe_receiver = tmp_20;
        toJson$_anonymous_$base_opqqdz(builder, 'waiting', tmp_15, tmp_16, tmp_19, tmp10_safe_receiver == null ? null : tmp10_safe_receiver.toString());
      } else {
        if (_this__u8e3s4 instanceof Suspended) {
          var tmp_22 = _RunId___get_value__impl__30zeiv(_this__u8e3s4.j73_1).toString();
          var tmp_23 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.k73_1);
          var tmp11_safe_receiver = _this__u8e3s4.l73_1;
          var tmp_24;
          var tmp_25 = tmp11_safe_receiver;
          if ((tmp_25 == null ? null : new ThreadId(tmp_25)) == null) {
            tmp_24 = null;
          } else {
            tmp_24 = _ThreadId___get_value__impl__tytyxc(tmp11_safe_receiver);
          }
          var tmp_26 = tmp_24;
          var tmp12_safe_receiver = _this__u8e3s4.m73_1;
          var tmp_27;
          var tmp_28 = tmp12_safe_receiver;
          if ((tmp_28 == null ? null : new TurnId(tmp_28)) == null) {
            tmp_27 = null;
          } else {
            tmp_27 = _TurnId___get_value__impl__w6r3h9(tmp12_safe_receiver);
          }
          var tmp13_safe_receiver = tmp_27;
          toJson$_anonymous_$base_opqqdz(builder, 'suspended', tmp_22, tmp_23, tmp_26, tmp13_safe_receiver == null ? null : tmp13_safe_receiver.toString());
        } else {
          if (_this__u8e3s4 instanceof Resumed) {
            var tmp_29 = _RunId___get_value__impl__30zeiv(_this__u8e3s4.f73_1).toString();
            var tmp_30 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.g73_1);
            var tmp14_safe_receiver = _this__u8e3s4.h73_1;
            var tmp_31;
            var tmp_32 = tmp14_safe_receiver;
            if ((tmp_32 == null ? null : new ThreadId(tmp_32)) == null) {
              tmp_31 = null;
            } else {
              tmp_31 = _ThreadId___get_value__impl__tytyxc(tmp14_safe_receiver);
            }
            var tmp_33 = tmp_31;
            var tmp15_safe_receiver = _this__u8e3s4.i73_1;
            var tmp_34;
            var tmp_35 = tmp15_safe_receiver;
            if ((tmp_35 == null ? null : new TurnId(tmp_35)) == null) {
              tmp_34 = null;
            } else {
              tmp_34 = _TurnId___get_value__impl__w6r3h9(tmp15_safe_receiver);
            }
            var tmp16_safe_receiver = tmp_34;
            toJson$_anonymous_$base_opqqdz(builder, 'resumed', tmp_29, tmp_30, tmp_33, tmp16_safe_receiver == null ? null : tmp16_safe_receiver.toString());
          } else {
            if (_this__u8e3s4 instanceof Finished_0) {
              var tmp_36 = _RunId___get_value__impl__30zeiv(_this__u8e3s4.a73_1).toString();
              var tmp_37 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.b73_1);
              var tmp17_safe_receiver = _this__u8e3s4.c73_1;
              var tmp_38;
              var tmp_39 = tmp17_safe_receiver;
              if ((tmp_39 == null ? null : new ThreadId(tmp_39)) == null) {
                tmp_38 = null;
              } else {
                tmp_38 = _ThreadId___get_value__impl__tytyxc(tmp17_safe_receiver);
              }
              var tmp_40 = tmp_38;
              var tmp18_safe_receiver = _this__u8e3s4.d73_1;
              var tmp_41;
              var tmp_42 = tmp18_safe_receiver;
              if ((tmp_42 == null ? null : new TurnId(tmp_42)) == null) {
                tmp_41 = null;
              } else {
                tmp_41 = _TurnId___get_value__impl__w6r3h9(tmp18_safe_receiver);
              }
              var tmp19_safe_receiver = tmp_41;
              toJson$_anonymous_$base_opqqdz(builder, 'finished', tmp_36, tmp_37, tmp_40, tmp19_safe_receiver == null ? null : tmp19_safe_receiver.toString());
              builder.r3o('usage', toJson_9(_this__u8e3s4.e73_1));
            } else {
              if (_this__u8e3s4 instanceof Incomplete_3) {
                var tmp_43 = _RunId___get_value__impl__30zeiv(_this__u8e3s4.u72_1).toString();
                var tmp_44 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.v72_1);
                var tmp20_safe_receiver = _this__u8e3s4.w72_1;
                var tmp_45;
                var tmp_46 = tmp20_safe_receiver;
                if ((tmp_46 == null ? null : new ThreadId(tmp_46)) == null) {
                  tmp_45 = null;
                } else {
                  tmp_45 = _ThreadId___get_value__impl__tytyxc(tmp20_safe_receiver);
                }
                var tmp_47 = tmp_45;
                var tmp21_safe_receiver = _this__u8e3s4.x72_1;
                var tmp_48;
                var tmp_49 = tmp21_safe_receiver;
                if ((tmp_49 == null ? null : new TurnId(tmp_49)) == null) {
                  tmp_48 = null;
                } else {
                  tmp_48 = _TurnId___get_value__impl__w6r3h9(tmp21_safe_receiver);
                }
                var tmp22_safe_receiver = tmp_48;
                toJson$_anonymous_$base_opqqdz(builder, 'incomplete', tmp_43, tmp_44, tmp_47, tmp22_safe_receiver == null ? null : tmp22_safe_receiver.toString());
                builder.r3o('reason', toJson_11(_this__u8e3s4.y72_1));
                builder.r3o('usage', toJson_9(_this__u8e3s4.z72_1));
              } else {
                if (_this__u8e3s4 instanceof Terminated_1) {
                  var tmp_50 = _RunId___get_value__impl__30zeiv(_this__u8e3s4.p72_1).toString();
                  var tmp_51 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.q72_1);
                  var tmp23_safe_receiver = _this__u8e3s4.r72_1;
                  var tmp_52;
                  var tmp_53 = tmp23_safe_receiver;
                  if ((tmp_53 == null ? null : new ThreadId(tmp_53)) == null) {
                    tmp_52 = null;
                  } else {
                    tmp_52 = _ThreadId___get_value__impl__tytyxc(tmp23_safe_receiver);
                  }
                  var tmp_54 = tmp_52;
                  var tmp24_safe_receiver = _this__u8e3s4.s72_1;
                  var tmp_55;
                  var tmp_56 = tmp24_safe_receiver;
                  if ((tmp_56 == null ? null : new TurnId(tmp_56)) == null) {
                    tmp_55 = null;
                  } else {
                    tmp_55 = _TurnId___get_value__impl__w6r3h9(tmp24_safe_receiver);
                  }
                  var tmp25_safe_receiver = tmp_55;
                  toJson$_anonymous_$base_opqqdz(builder, 'terminated', tmp_50, tmp_51, tmp_54, tmp25_safe_receiver == null ? null : tmp25_safe_receiver.toString());
                  builder.r3o('reason', toJson_12(_this__u8e3s4.t72_1));
                } else {
                  if (_this__u8e3s4 instanceof Failed_2) {
                    var tmp_57 = _RunId___get_value__impl__30zeiv(_this__u8e3s4.k72_1).toString();
                    var tmp_58 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.l72_1);
                    var tmp26_safe_receiver = _this__u8e3s4.m72_1;
                    var tmp_59;
                    var tmp_60 = tmp26_safe_receiver;
                    if ((tmp_60 == null ? null : new ThreadId(tmp_60)) == null) {
                      tmp_59 = null;
                    } else {
                      tmp_59 = _ThreadId___get_value__impl__tytyxc(tmp26_safe_receiver);
                    }
                    var tmp_61 = tmp_59;
                    var tmp27_safe_receiver = _this__u8e3s4.n72_1;
                    var tmp_62;
                    var tmp_63 = tmp27_safe_receiver;
                    if ((tmp_63 == null ? null : new TurnId(tmp_63)) == null) {
                      tmp_62 = null;
                    } else {
                      tmp_62 = _TurnId___get_value__impl__w6r3h9(tmp27_safe_receiver);
                    }
                    var tmp28_safe_receiver = tmp_62;
                    toJson$_anonymous_$base_opqqdz(builder, 'failed', tmp_57, tmp_58, tmp_61, tmp28_safe_receiver == null ? null : tmp28_safe_receiver.toString());
                    builder.r3o('error', toJson_10(_this__u8e3s4.o72_1));
                  } else {
                    if (_this__u8e3s4 instanceof Cancelled) {
                      var tmp_64 = _RunId___get_value__impl__30zeiv(_this__u8e3s4.g72_1).toString();
                      var tmp_65 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.h72_1);
                      var tmp29_safe_receiver = _this__u8e3s4.i72_1;
                      var tmp_66;
                      var tmp_67 = tmp29_safe_receiver;
                      if ((tmp_67 == null ? null : new ThreadId(tmp_67)) == null) {
                        tmp_66 = null;
                      } else {
                        tmp_66 = _ThreadId___get_value__impl__tytyxc(tmp29_safe_receiver);
                      }
                      var tmp_68 = tmp_66;
                      var tmp30_safe_receiver = _this__u8e3s4.j72_1;
                      var tmp_69;
                      var tmp_70 = tmp30_safe_receiver;
                      if ((tmp_70 == null ? null : new TurnId(tmp_70)) == null) {
                        tmp_69 = null;
                      } else {
                        tmp_69 = _TurnId___get_value__impl__w6r3h9(tmp30_safe_receiver);
                      }
                      var tmp31_safe_receiver = tmp_69;
                      toJson$_anonymous_$base_opqqdz(builder, 'cancelled', tmp_64, tmp_65, tmp_68, tmp31_safe_receiver == null ? null : tmp31_safe_receiver.toString());
                    } else {
                      if (_this__u8e3s4 instanceof UnhandledChildFailure) {
                        toJson$_anonymous_$base_opqqdz(builder, 'unhandled_child_failure', _RunId___get_value__impl__30zeiv(_this__u8e3s4.d72_1).toString(), _AgentId___get_value__impl__1mym7n(_this__u8e3s4.e72_1), null, null);
                        builder.r3o('parent_run_id', JsonPrimitive_0(_RunId___get_value__impl__30zeiv(_this__u8e3s4.c72_1).toString()));
                        builder.r3o('error', toJson_10(_this__u8e3s4.f72_1));
                      } else {
                        if (_this__u8e3s4 instanceof SideEffectRollback) {
                          toJson$_anonymous_$base_opqqdz(builder, 'side_effect_rollback', _RunId___get_value__impl__30zeiv(_this__u8e3s4.y71_1).toString(), _AgentId___get_value__impl__1mym7n(_this__u8e3s4.z71_1), _ThreadId___get_value__impl__tytyxc(_this__u8e3s4.a72_1), _TurnId___get_value__impl__w6r3h9(_this__u8e3s4.b72_1).toString());
                        } else {
                          if (_this__u8e3s4 instanceof Retrying) {
                            var tmp32_safe_receiver = _this__u8e3s4.r71_1;
                            var tmp_71;
                            var tmp_72 = tmp32_safe_receiver;
                            if ((tmp_72 == null ? null : new RunId(tmp_72)) == null) {
                              tmp_71 = null;
                            } else {
                              tmp_71 = _RunId___get_value__impl__30zeiv(tmp32_safe_receiver);
                            }
                            var tmp33_safe_receiver = tmp_71;
                            var tmp_73 = tmp33_safe_receiver == null ? null : tmp33_safe_receiver.toString();
                            var tmp_74 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.s71_1);
                            var tmp34_safe_receiver = _this__u8e3s4.u71_1;
                            var tmp_75;
                            var tmp_76 = tmp34_safe_receiver;
                            if ((tmp_76 == null ? null : new ThreadId(tmp_76)) == null) {
                              tmp_75 = null;
                            } else {
                              tmp_75 = _ThreadId___get_value__impl__tytyxc(tmp34_safe_receiver);
                            }
                            var tmp_77 = tmp_75;
                            var tmp35_safe_receiver = _this__u8e3s4.v71_1;
                            var tmp_78;
                            var tmp_79 = tmp35_safe_receiver;
                            if ((tmp_79 == null ? null : new TurnId(tmp_79)) == null) {
                              tmp_78 = null;
                            } else {
                              tmp_78 = _TurnId___get_value__impl__w6r3h9(tmp35_safe_receiver);
                            }
                            var tmp36_safe_receiver = tmp_78;
                            toJson$_anonymous_$base_opqqdz(builder, 'retrying', tmp_73, tmp_74, tmp_77, tmp36_safe_receiver == null ? null : tmp36_safe_receiver.toString());
                            builder.r3o('agent_name', JsonPrimitive_0(_this__u8e3s4.t71_1));
                            builder.r3o('attempt', JsonPrimitive(_this__u8e3s4.w71_1));
                            builder.r3o('delay_ms', JsonPrimitive(_this__u8e3s4.x71_1));
                          } else {
                            if (_this__u8e3s4 instanceof CircuitOpen) {
                              var tmp37_safe_receiver = _this__u8e3s4.m71_1;
                              var tmp_80;
                              var tmp_81 = tmp37_safe_receiver;
                              if ((tmp_81 == null ? null : new RunId(tmp_81)) == null) {
                                tmp_80 = null;
                              } else {
                                tmp_80 = _RunId___get_value__impl__30zeiv(tmp37_safe_receiver);
                              }
                              var tmp38_safe_receiver = tmp_80;
                              var tmp_82 = tmp38_safe_receiver == null ? null : tmp38_safe_receiver.toString();
                              var tmp_83 = _AgentId___get_value__impl__1mym7n(_this__u8e3s4.n71_1);
                              var tmp39_safe_receiver = _this__u8e3s4.p71_1;
                              var tmp_84;
                              var tmp_85 = tmp39_safe_receiver;
                              if ((tmp_85 == null ? null : new ThreadId(tmp_85)) == null) {
                                tmp_84 = null;
                              } else {
                                tmp_84 = _ThreadId___get_value__impl__tytyxc(tmp39_safe_receiver);
                              }
                              var tmp_86 = tmp_84;
                              var tmp40_safe_receiver = _this__u8e3s4.q71_1;
                              var tmp_87;
                              var tmp_88 = tmp40_safe_receiver;
                              if ((tmp_88 == null ? null : new TurnId(tmp_88)) == null) {
                                tmp_87 = null;
                              } else {
                                tmp_87 = _TurnId___get_value__impl__w6r3h9(tmp40_safe_receiver);
                              }
                              var tmp41_safe_receiver = tmp_87;
                              toJson$_anonymous_$base_opqqdz(builder, 'circuit_open', tmp_82, tmp_83, tmp_86, tmp41_safe_receiver == null ? null : tmp41_safe_receiver.toString());
                              builder.r3o('agent_name', JsonPrimitive_0(_this__u8e3s4.o71_1));
                            } else {
                              noWhenBranchMatchedException();
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return builder.i3n();
}
function toJson$_anonymous_$base_opqqdz($this_buildJsonObject, type, run, agent, thread, turn) {
  $this_buildJsonObject.r3o('type', JsonPrimitive_0(type));
  if (run == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    $this_buildJsonObject.r3o('run_id', JsonPrimitive_0(run));
  }
  if (agent == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    $this_buildJsonObject.r3o('agent_id', JsonPrimitive_0(agent));
  }
  if (thread == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    $this_buildJsonObject.r3o('thread_id', JsonPrimitive_0(thread));
  }
  if (turn == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    $this_buildJsonObject.r3o('turn_id', JsonPrimitive_0(turn));
  }
}
function nodeJson$lambda($this$Json) {
  _init_properties_NodeJson_kt__ig6gx6();
  $this$Json.s3m_1 = false;
  $this$Json.r3m_1 = false;
  $this$Json.q3m_1 = true;
  return Unit_instance;
}
var properties_initialized_NodeJson_kt_2pucgc;
function _init_properties_NodeJson_kt__ig6gx6() {
  if (!properties_initialized_NodeJson_kt_2pucgc) {
    properties_initialized_NodeJson_kt_2pucgc = true;
    nodeJson = Json(VOID, nodeJson$lambda);
  }
}
function ToolExecutionRegistry$Execution$track$lambda(this$0, $job) {
  return (it) => {
    var tmp0 = this$0.k82_1;
    // Inline function 'kotlin.collections.minusAssign' call
    var element = $job;
    tmp0.z2(element);
    return Unit_instance;
  };
}
function ToolExecutionRegistry$execute$slambda$slambda_0($record, $block) {
  var i = new ToolExecutionRegistry$execute$slambda$slambda($record, $block);
  var l = ($completion) => i.vd($completion);
  l.$arity = 0;
  return l;
}
function *_generator_execute__d6syw1($this, id, block, $completion) {
  var record = execution($this, id);
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var tmp0_elvis_lhs = $completion.lc().yc(Key_instance_1);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw NodeBridgeException.d82('lifecycle_error', 'Tool context operation has no coroutine Job');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var job = tmp;
  record.e88(job);
  var tmp_0 = record.i82_1.e5s($completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var branch = tmp_0;
  record.d88();
  var tmp_1;
  try {
    var tmp_2 = record.h82_1.kn(record.i82_1);
    var tmp_3 = withContext(tmp_2, ToolExecutionRegistry$execute$slambda_0(branch, record, block), $completion);
    if (tmp_3 === get_COROUTINE_SUSPENDED())
      tmp_3 = yield tmp_3;
    tmp_1 = tmp_3;
  }finally {
    record.f88(job);
  }
  return tmp_1;
}
function execution($this, id) {
  var tmp0_elvis_lhs = $this.y83_1.h3(id);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw NodeBridgeException.d82('tool_context_expired', "Tool RuntimeContext '" + id + "' has expired");
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function ToolExecutionRegistry$execute$slambda_0($branch, $record, $block) {
  var i = new ToolExecutionRegistry$execute$slambda($branch, $record, $block);
  var l = ($this$withContext, $completion) => i.r1f($this$withContext, $completion);
  l.$arity = 1;
  return l;
}
//region block: post-declaration
initMetadataForLambda(KoaksBridge$dispatch$o$collect$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$dispatch$o$collect$slambda_0, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$dispatch$o$collect$slambda_1, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$streamAgent$o$collect$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolWithResource$slambda$slambda$slambda, VOID, VOID, [0]);
initMetadataForLambda(KoaksBridge$toolWithResource$slambda$slambda, VOID, VOID, [0]);
initMetadataForLambda(KoaksBridge$toolIpcReceive$slambda$slambda, VOID, VOID, [0]);
initMetadataForLambda(KoaksBridge$toolIpcRequest$slambda$slambda$slambda, VOID, VOID, [0]);
initMetadataForLambda(KoaksBridge$toolIpcRequest$slambda$slambda, VOID, VOID, [0]);
initMetadataForLambda(KoaksBridge$toolIpcSubscribe$slambda$o$collect$slambda, VOID, VOID, [1]);
initMetadataForClass(KoaksBridge$toolIpcSubscribe$2$$inlined$map$1, VOID, VOID, VOID, [Flow], [1]);
initMetadataForLambda(KoaksBridge$runtimeIpcRequest$slambda$slambda, VOID, VOID, [0]);
initMetadataForLambda(KoaksBridge$runtimeIpcSubscribe$o$collect$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$startSubscription$slambda$slambda, VOID, VOID, [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_0, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_1, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_2, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_3, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForLambda(KoaksBridge$request$slambda, VOID, VOID, [1]);
initMetadataForClass(KoaksBridge$dispatch$$inlined$map$1, VOID, VOID, VOID, [Flow], [1]);
initMetadataForClass(KoaksBridge$dispatch$$inlined$map$2, VOID, VOID, VOID, [Flow], [1]);
initMetadataForClass(KoaksBridge$dispatch$$inlined$map$3, VOID, VOID, VOID, [Flow], [1]);
initMetadataForLambda(KoaksBridge$runAgent$slambda, VOID, VOID, [0]);
initMetadataForClass(KoaksBridge$streamAgent$$inlined$map$1, VOID, VOID, VOID, [Flow], [1]);
initMetadataForLambda(KoaksBridge$resumeAgent$slambda, VOID, VOID, [0]);
initMetadataForLambda(KoaksBridge$submit$lambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$spawnSupervised$slambda, VOID, VOID, [2]);
initMetadataForLambda(KoaksBridge$handleResult$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolWithResource$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolPutContext$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolDeltaContext$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolResolveContext$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolSpawnChild$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolIpcSend$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolIpcReceive$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolIpcRequest$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolIpcReply$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolIpcPublish$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolIpcSubscribe$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$toolProgress$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$runtimeIpcRequest$slambda, VOID, VOID, [0]);
initMetadataForClass(KoaksBridge$runtimeIpcSubscribe$$inlined$map$1, VOID, VOID, VOID, [Flow], [1]);
initMetadataForLambda(KoaksBridge$withIpcTimeout$slambda, VOID, VOID, [1]);
initMetadataForLambda(KoaksBridge$startSubscription$slambda, VOID, VOID, [1]);
initMetadataForClass(KoaksBridge, 'KoaksBridge', VOID, VOID, VOID, [2, 1, 3, 0]);
initMetadataForClass(AgentRecord, 'AgentRecord');
initMetadataForClass(HandleRecord, 'HandleRecord');
initMetadataForClass(SupervisedRecord, 'SupervisedRecord');
initMetadataForClass(SubscriptionRecord, 'SubscriptionRecord');
initMetadataForClass(OperationRecord, 'OperationRecord');
initMetadataForClass(CallbackGateway, 'CallbackGateway', VOID, VOID, VOID, [2]);
initMetadataForClass(BuiltAgent, 'BuiltAgent');
initMetadataForLambda(NodeTool$executeNode$slambda, VOID, VOID, [0]);
initMetadataForClass(NodeTool, 'NodeTool', VOID, VOID, [ContextualTool], [1, 2]);
initMetadataForClass(NodeThreadMemory, 'NodeThreadMemory', VOID, VOID, [ThreadMemory], [1]);
initMetadataForClass(NodeSummaryStateStore, 'NodeSummaryStateStore', VOID, VOID, VOID, [1, 2]);
initMetadataForClass(NodeVectorStore, 'NodeVectorStore', VOID, VOID, VOID, [2, 3]);
initMetadataForClass(NodeMcpGateway, 'NodeMcpGateway', VOID, VOID, VOID, [0, 2]);
initMetadataForClass(NodeSkillLoader, 'NodeSkillLoader', VOID, VOID, VOID, [0, 1]);
initMetadataForClass(NodeSkillResources, 'NodeSkillResources', VOID, VOID, VOID, [1]);
initMetadataForClass(NodeClientActionHandler, 'NodeClientActionHandler', VOID, VOID, VOID, [1]);
initMetadataForClass(NodeListener, 'NodeListener', VOID, VOID, [AgentListener]);
initMetadataForLambda(NodeHook$onModelStream$slambda$slambda, VOID, VOID, [1]);
initMetadataForClass(sam$kotlinx_coroutines_flow_FlowCollector$0_4, 'sam$kotlinx_coroutines_flow_FlowCollector$0', VOID, VOID, [FlowCollector, FunctionAdapter], [1]);
initMetadataForLambda(NodeHook$onModelStream$slambda, VOID, VOID, [1]);
initMetadataForLambda(NodeHook$callToolHook$slambda, VOID, VOID, [0]);
initMetadataForClass(NodeHook, 'NodeHook', VOID, VOID, [Hook], [1, 2, 3]);
initMetadataForClass(sam$org_koaks_memory_summarizing_CompactionObserver$0, 'sam$org_koaks_memory_summarizing_CompactionObserver$0', VOID, VOID, [CompactionObserver, FunctionAdapter]);
initMetadataForClass(sam$org_koaks_framework_policy_SuspendTerminationPolicy$0, 'sam$org_koaks_framework_policy_SuspendTerminationPolicy$0', VOID, VOID, [SuspendTerminationPolicy, FunctionAdapter], [1]);
initMetadataForClass(sam$org_koaks_framework_policy_SuspendErrorPolicy$0, 'sam$org_koaks_framework_policy_SuspendErrorPolicy$0', VOID, VOID, [SuspendErrorPolicy, FunctionAdapter], [2]);
initMetadataForLambda(configureInstructions$lambda$slambda, VOID, VOID, [0]);
initMetadataForLambda(buildMemory$slambda, VOID, VOID, [1]);
initMetadataForLambda(buildSuspendTerminationPolicy$slambda, VOID, VOID, [1]);
initMetadataForLambda(buildSuspendErrorPolicy$slambda, VOID, VOID, [2]);
initMetadataForClass(NodeCallbackException, 'NodeCallbackException');
initMetadataForClass(NodeBridgeException, 'NodeBridgeException');
initMetadataForLambda(ToolExecutionRegistry$execute$slambda$slambda, VOID, VOID, [0]);
initMetadataForClass(Execution, 'Execution');
initMetadataForLambda(ToolExecutionRegistry$execute$slambda, VOID, VOID, [1]);
initMetadataForClass(ToolExecutionRegistry, 'ToolExecutionRegistry', ToolExecutionRegistry, VOID, VOID, [2]);
//endregion
//region block: exports
KoaksBridge.spawnAgent$default = spawnAgent$default;
KoaksBridge.startSubscription$default = startSubscription$default;
export {
  KoaksBridge as KoaksBridge,
  createKoaksBridge as createKoaksBridge,
};
//endregion

//# sourceMappingURL=koaks-node-bridge.mjs.map
