import {
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  equals2au1ep9vhcato as equals,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  isInterface3d6p8outrmvmk as isInterface,
  hashCodeq5arwsb9dgti as hashCode,
  VOID7hggqo3abtya as VOID,
  ArrayList3it5z8td81qkl as ArrayList,
  LinkedHashSet2tkztfx86kyx2 as LinkedHashSet,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  HashMap1a0ld5kgwhmhv as HashMap,
  Unit_instance104q5opgivhr8 as Unit_instance,
  Enum3alwj03lh1n41 as Enum,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  Char19o2r8palgjof as Char,
  setOf45ia9pnfhe90 as setOf,
  Regexxgw0gjiagf4z as Regex,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  toString35i91qxh73cps as toString_0,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  to2cs3ny02qtbcb as to,
  mapOf1xd03cq9cnmy8 as mapOf,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  contains2el4s70rdq4ld as contains,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  booleanArray2jdug9b51huk7 as booleanArray,
  numberToChar93r9buh19yek as numberToChar,
  decodeToString1x4faah2liw2p as decodeToString,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  NullPointerException3mu0rhxjjitqq as NullPointerException,
  StringBuildermazzzhj6kkai as StringBuilder,
  toString30pk9tzaqopn as toString_1,
  createThis2j2avj17cvnv2 as createThis,
  joinToString1cxrrlmo0chqs as joinToString,
  captureStack1fzi4aczwc4hg as captureStack,
  take3onnpy6q7ctcz as take,
  emptyList1g2z5xcrvp2zy as emptyList,
  toList3jhuyej2anx2q as toList,
  drop3na99dw9feawf as drop,
  takeLast2r8kr8e6g6hi7 as takeLast,
  drop336950s126lmj as drop_0,
  take9j4462mea726 as take_0,
  dropLastlqc2oyv04br0 as dropLast,
  repeat2w4c6j8zoq09o as repeat,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  trimMarginhyd3fsmh8iev as trimMargin,
  concatToString2syawgu50khxi as concatToString,
  toString1h6jjoch8cjt8 as toString_2,
  trimIndent1qytc1wvt8suh as trimIndent,
  RuntimeException1r3t0zl97011n as RuntimeException,
  IndexOutOfBoundsException1qfr429iumro0 as IndexOutOfBoundsException,
  get_indices38nlqzzvtaclf as get_indices,
  getOrNull1cdnsfrisdp41 as getOrNull,
  isLowSurrogateujxcv7hjn4ma as isLowSurrogate,
  isHighSurrogate11jfjw70ar0zf as isHighSurrogate,
  checkBuilderCapacity1h6g02949wvv as checkBuilderCapacity,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  Char__compareTo_impl_ypi4mb3fw4vcbfqkuba as Char__compareTo_impl_ypi4mb,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  plus17rl43at52ays as plus,
  emptyMapr06gerzljqtm as emptyMap,
  ArrayDeque2dzc9uld4xi7n as ArrayDeque,
  toMutableMapr5f3w62lv8sk as toMutableMap,
  NoSuchElementException679xzhnp5bpj as NoSuchElementException,
  toMapcf6xfku344cz as toMap,
  toCharArray32huqyw9tt7kx as toCharArray,
  listOfvhqybd2zx248 as listOf,
  distinct10qe1scfdvu5k as distinct,
  last1vo29oleiqj36 as last,
  addAll1k27qatfgp3k5 as addAll,
  first6e6strkelovp as first,
  firstOrNullf6vlo6vdgu1e as firstOrNull,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  isDigit3mimrri4wkzop as isDigit,
  toInt2q8uldh7sc951 as toInt,
  KtMap140uvy3s5zad8 as KtMap,
  toInt5qdj874w69jh as toInt_0,
  NumberFormatException3bgsm2s9o4t55 as NumberFormatException,
  CharacterCodingException3mvgnmpleqbz9 as CharacterCodingException,
  filterNotNullhujglslymx1l as filterNotNull,
  contains1tccixv8iwdcq as contains_0,
  Long2qws0ah9gnpki as Long,
  toLongw1zpgk99d84b as toLong,
  asList2ho2pewtsfvv as asList,
  coerceAtMost322komnqp70ag as coerceAtMost,
} from './kotlin-kotlin-stdlib.mjs';
import { UrlEncoderUtil_getInstance1lfpgbk9xk36s as UrlEncoderUtil_getInstance } from './urlencoder-urlencoder-lib.mjs';
import {
  Buffer3384y49aj0pxr as Buffer,
  IOException3fje1ukjwthwb as IOException,
  bufferbiiev5vr4b6f as buffer,
  BufferedSource3ezj4539oep1e as BufferedSource,
} from './okio-parent-okio.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class CollectionProvider {}
class SpecVersionMutator {}
class Companion {
  r20() {
    return new LoadSettingsBuilder();
  }
}
class LoadSettings {
  constructor(label, tagConstructors, defaultList, defaultSet, defaultMap, versionFunction, bufferSize, allowDuplicateKeys, allowRecursiveKeys, maxAliasesForCollections, useMarks, customProperties, envConfig, parseComments, codePointLimit, schema) {
    this.a45_1 = label;
    this.b45_1 = tagConstructors;
    this.c45_1 = defaultList;
    this.d45_1 = defaultSet;
    this.e45_1 = defaultMap;
    this.f45_1 = versionFunction;
    this.g45_1 = bufferSize;
    this.h45_1 = allowDuplicateKeys;
    this.i45_1 = allowRecursiveKeys;
    this.j45_1 = maxAliasesForCollections;
    this.k45_1 = useMarks;
    this.l45_1 = customProperties;
    this.m45_1 = envConfig;
    this.n45_1 = parseComments;
    this.o45_1 = codePointLimit;
    this.p45_1 = schema;
  }
}
class sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0 {
  constructor(function_0) {
    this.q45_1 = function_0;
  }
  n4() {
    return this.q45_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, CollectionProvider) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0_0 {
  constructor(function_0) {
    this.r45_1 = function_0;
  }
  n4() {
    return this.r45_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, CollectionProvider) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0_1 {
  constructor(function_0) {
    this.s45_1 = function_0;
  }
  n4() {
    return this.s45_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, CollectionProvider) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_SpecVersionMutator$0 {
  constructor(function_0) {
    this.t45_1 = function_0;
  }
  z44(version) {
    return this.t45_1(version);
  }
  n4() {
    return this.t45_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, SpecVersionMutator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class LoadSettingsBuilder {
  constructor() {
    this.b46_1 = HashMap.l8();
    this.c46_1 = 'reader';
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.d46_1 = LinkedHashMap.hc();
    var tmp_0 = this;
    var tmp_1 = LoadSettingsBuilder$defaultList$lambda;
    tmp_0.e46_1 = new sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0(tmp_1);
    var tmp_2 = this;
    var tmp_3 = LoadSettingsBuilder$defaultSet$lambda;
    tmp_2.f46_1 = new sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0_0(tmp_3);
    var tmp_4 = this;
    var tmp_5 = LoadSettingsBuilder$defaultMap$lambda;
    tmp_4.g46_1 = new sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0_1(tmp_5);
    var tmp_6 = this;
    var tmp_7 = LoadSettingsBuilder$versionFunction$lambda;
    tmp_6.h46_1 = new sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_SpecVersionMutator$0(tmp_7);
    this.i46_1 = 1024;
    this.j46_1 = false;
    this.k46_1 = false;
    this.l46_1 = false;
    this.m46_1 = 50;
    this.n46_1 = true;
    this.o46_1 = null;
    this.p46_1 = 3145728;
    this.q46_1 = new JsonSchema();
  }
  r46(label) {
    this.c46_1 = label;
    return this;
  }
  s46(codePointLimit) {
    this.p46_1 = codePointLimit;
    return this;
  }
  h2o() {
    return new LoadSettings(this.c46_1, this.d46_1, this.e46_1, this.f46_1, this.g46_1, this.h46_1, this.i46_1, this.j46_1, this.k46_1, this.m46_1, this.n46_1, this.b46_1, this.o46_1, this.l46_1, this.p46_1, this.q46_1);
  }
}
class CommentType extends Enum {}
class Companion_0 {
  constructor() {
    Companion_instance_0 = this;
    this.t46_1 = setOf([new Char(_Char___init__impl__6a9atx(91)), new Char(_Char___init__impl__6a9atx(93)), new Char(_Char___init__impl__6a9atx(123)), new Char(_Char___init__impl__6a9atx(125)), new Char(_Char___init__impl__6a9atx(44)), new Char(_Char___init__impl__6a9atx(42)), new Char(_Char___init__impl__6a9atx(38))]);
    this.u46_1 = Regex.xh('\\s');
  }
}
class Anchor {
  constructor(value) {
    Companion_getInstance_0();
    this.v46_1 = value;
    // Inline function 'kotlin.text.isNotEmpty' call
    var this_0 = this.v46_1;
    // Inline function 'kotlin.require' call
    if (!(charSequenceLength(this_0) > 0)) {
      var message = 'Empty anchor.';
      throw IllegalArgumentException.t(toString(message));
    }
    var indexedObject = this.v46_1;
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var element = charSequenceGet(indexedObject, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      if (Companion_getInstance_0().t46_1.v2(new Char(element))) {
        throw EmitterException.a47("Invalid character '" + toString_0(element) + "' in the anchor: " + this.v46_1);
      }
    }
    if (Companion_getInstance_0().u46_1.zh(this.v46_1)) {
      throw EmitterException.a47('Anchor may not contain spaces: ' + this.v46_1);
    }
  }
  toString() {
    return this.v46_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Anchor))
      return false;
    return this.v46_1 === other.v46_1;
  }
  hashCode() {
    return getStringHashCode(this.v46_1);
  }
}
class Companion_1 {
  constructor() {
    Companion_instance_1 = this;
    this.b47_1 = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-_';
    this.c47_1 = '\n';
    this.d47_1 = '\r\n';
    this.e47_1 = '\x00\r\n';
    this.f47_1 = ' \x00\r\n';
    this.g47_1 = '\t \x00\r\n';
    this.h47_1 = '\x00 \t';
    this.i47_1 = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-_-;/?:@&=+$_.!~*'()%";
    this.j47_1 = new CharConstants('\n');
    this.k47_1 = new CharConstants('\x00\r\n');
    this.l47_1 = new CharConstants(' \x00\r\n');
    this.m47_1 = new CharConstants('\t \x00\r\n');
    this.n47_1 = new CharConstants('\x00 \t');
    this.o47_1 = new CharConstants("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-_-;/?:@&=+$_.!~*'()%,[]");
    this.p47_1 = new CharConstants("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-_-;/?:@&=+$_.!~*'()%");
    this.q47_1 = new CharConstants('abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-_');
    this.r47_1 = 128;
    this.s47_1 = mapOf([to(new Char(_Char___init__impl__6a9atx(48)), '\x00'), to(new Char(_Char___init__impl__6a9atx(97)), '\x07'), to(new Char(_Char___init__impl__6a9atx(98)), '\b'), to(new Char(_Char___init__impl__6a9atx(116)), '\t'), to(new Char(_Char___init__impl__6a9atx(110)), '\n'), to(new Char(_Char___init__impl__6a9atx(118)), '\x0B'), to(new Char(_Char___init__impl__6a9atx(102)), '\f'), to(new Char(_Char___init__impl__6a9atx(114)), '\r'), to(new Char(_Char___init__impl__6a9atx(101)), '\x1B'), to(new Char(_Char___init__impl__6a9atx(32)), ' '), to(new Char(_Char___init__impl__6a9atx(34)), '"'), to(new Char(_Char___init__impl__6a9atx(47)), '/'), to(new Char(_Char___init__impl__6a9atx(92)), '\\'), to(new Char(_Char___init__impl__6a9atx(78)), '\x85'), to(new Char(_Char___init__impl__6a9atx(95)), '\xA0')]);
    var tmp = this;
    // Inline function 'kotlin.collections.associate' call
    var this_0 = this.s47_1.l1();
    var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
    // Inline function 'kotlin.collections.associateTo' call
    var destination = LinkedHashMap.ic(capacity);
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var k = element.m1().j2_1;
      // Inline function 'kotlin.collections.component2' call
      var v = element.n1();
      // Inline function 'kotlin.collections.plusAssign' call
      var pair = to(v, new Char(k));
      destination.k3(pair.rl_1, pair.sl_1);
    }
    tmp.t47_1 = destination;
    this.u47_1 = mapOf([to(new Char(_Char___init__impl__6a9atx(120)), 2), to(new Char(_Char___init__impl__6a9atx(117)), 4), to(new Char(_Char___init__impl__6a9atx(85)), 8)]);
  }
  v47(char) {
    var charString = toString_0(char);
    if (contains(' /"', char))
      return charString;
    var tmp = this.t47_1.h3(charString);
    var tmp0_elvis_lhs = tmp == null ? null : tmp.j2_1;
    var tmp_0;
    var tmp_1 = tmp0_elvis_lhs;
    if ((tmp_1 == null ? null : new Char(tmp_1)) == null) {
      return charString;
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var escaped = tmp_0;
    return '\\' + toString_0(escaped);
  }
}
class CharConstants {
  constructor(content) {
    Companion_getInstance_1();
    // Inline function 'kotlin.text.map' call
    // Inline function 'kotlin.text.mapTo' call
    var destination = ArrayList.x(charSequenceLength(content));
    var inductionVariable = 0;
    while (inductionVariable < charSequenceLength(content)) {
      var item = charSequenceGet(content, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var tmp$ret$1 = Char__toInt_impl_vasixd(item);
      destination.l(tmp$ret$1);
    }
    var contentCodes = destination;
    var tmp = this;
    var tmp_0 = 0;
    var tmp_1 = booleanArray(128);
    while (tmp_0 < 128) {
      var tmp_2 = tmp_0;
      tmp_1[tmp_2] = contentCodes.v2(tmp_2);
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.w47_1 = tmp_1;
  }
  x47(c) {
    return c < 128 && this.w47_1[c];
  }
  y47(c) {
    return !this.x47(c);
  }
  z47(c, additional) {
    return this.x47(c) || contains(additional, numberToChar(c));
  }
  a48(c, additional) {
    return !this.z47(c, additional);
  }
}
class FlowStyle extends Enum {}
class ScalarStyle extends Enum {
  constructor(name, ordinal, styleOpt) {
    super(name, ordinal);
    this.d48_1 = styleOpt;
  }
  toString() {
    var tmp0_elvis_lhs = this.d48_1;
    var tmp;
    var tmp_0 = tmp0_elvis_lhs;
    if ((tmp_0 == null ? null : new Char(tmp_0)) == null) {
      tmp = _Char___init__impl__6a9atx(58);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return toString_0(tmp);
  }
}
class SpecVersion {
  constructor(major, minor) {
    this.z45_1 = major;
    this.a46_1 = minor;
  }
  toString() {
    return 'Version{major=' + this.z45_1 + ', minor=' + this.a46_1 + '}';
  }
}
class UriEncoder {
  constructor() {
    this.e48_1 = "-_.!~*'()@:$&,;=[]/";
  }
  f48(uri) {
    return urlEncode(this, uri);
  }
  g48(buff) {
    var content = decodeToString(buff.h43());
    return this.h48(content);
  }
  h48(buff) {
    return urlDecode(this, buff);
  }
}
class Companion_2 {
  constructor() {
    Companion_instance_2 = this;
    this.i48_1 = mapOf([to('true', true), to('false', false)]);
  }
}
class ConstructScalar {
  constructor() {
    Companion_getInstance_2();
  }
}
class ConstructYamlNull extends ConstructScalar {}
class ConstructYamlBinary extends ConstructScalar {}
class ConstructYamlJsonBool extends ConstructScalar {}
class ConstructYamlJsonFloat extends ConstructScalar {}
class ConstructYamlJsonInt extends ConstructScalar {}
class Event {
  static x4a(startMark, endMark) {
    startMark = startMark === VOID ? null : startMark;
    endMark = endMark === VOID ? null : endMark;
    var $this = createThis(this);
    $this.v4a_1 = startMark;
    $this.w4a_1 = endMark;
    if (!($this.v4a_1 == null) && $this.w4a_1 == null || ($this.v4a_1 == null && !($this.w4a_1 == null))) {
      throw NullPointerException.df('Both marks must be either present or absent.');
    }
    return $this;
  }
}
class NodeEvent extends Event {
  static q4a(anchor, startMark, endMark) {
    var $this = this.x4a(startMark, endMark);
    $this.p4a_1 = anchor;
    return $this;
  }
}
class AliasEvent extends NodeEvent {
  static m4a(anchor, startMark, endMark) {
    startMark = startMark === VOID ? null : startMark;
    endMark = endMark === VOID ? null : endMark;
    var $this = this.q4a(anchor, startMark, endMark);
    var tmp = $this;
    var tmp_0;
    if (anchor == null) {
      throw NullPointerException.df('Anchor is required in AliasEvent');
    } else {
      tmp_0 = anchor;
    }
    tmp.l4a_1 = tmp_0;
    return $this;
  }
  r4a() {
    return ID_Alias_getInstance();
  }
  toString() {
    return '=ALI *' + this.l4a_1.toString();
  }
}
class CollectionEndEvent extends Event {
  static u4a(startMark, endMark) {
    var $this = this.x4a(startMark, endMark);
    init_it_krzeminski_snakeyaml_engine_kmp_events_CollectionEndEvent($this);
    return $this;
  }
  static y4a() {
    var $this = this.x4a();
    init_it_krzeminski_snakeyaml_engine_kmp_events_CollectionEndEvent($this);
    return $this;
  }
}
class CollectionStartEvent extends NodeEvent {
  static f4b(anchor, tag, implicit, flowStyle, startMark, endMark) {
    var $this = this.q4a(anchor, startMark, endMark);
    $this.c4b_1 = tag;
    $this.d4b_1 = implicit;
    $this.e4b_1 = flowStyle;
    return $this;
  }
  toString() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    if (!(this.p4a_1 == null)) {
      this_0.tb(' &' + toString_1(this.p4a_1));
    }
    if (!this.d4b_1) {
      if (!(this.c4b_1 == null)) {
        this_0.tb(' <' + this.c4b_1 + '>');
      }
    }
    return this_0.toString();
  }
}
class CommentEvent extends Event {
  static k4b(commentType, value, startMark, endMark) {
    var $this = this.x4a(startMark, endMark);
    $this.i4b_1 = commentType;
    $this.j4b_1 = value;
    return $this;
  }
  r4a() {
    return ID_Comment_getInstance();
  }
  toString() {
    return '=COM ' + this.i4b_1.toString() + ' ' + this.j4b_1;
  }
}
class DocumentEndEvent extends Event {
  static o4b(isExplicit, startMark, endMark) {
    startMark = startMark === VOID ? null : startMark;
    endMark = endMark === VOID ? null : endMark;
    var $this = this.x4a(startMark, endMark);
    $this.n4b_1 = isExplicit;
    return $this;
  }
  r4a() {
    return ID_DocumentEnd_getInstance();
  }
  toString() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb('-DOC');
    if (this.n4b_1) {
      this_0.tb(' ...');
    }
    return this_0.toString();
  }
}
class DocumentStartEvent extends Event {
  static u4b(explicit, specVersion, tags, startMark, endMark) {
    startMark = startMark === VOID ? null : startMark;
    endMark = endMark === VOID ? null : endMark;
    var $this = this.x4a(startMark, endMark);
    $this.r4b_1 = explicit;
    $this.s4b_1 = specVersion;
    $this.t4b_1 = tags;
    return $this;
  }
  r4a() {
    return ID_DocumentStart_getInstance();
  }
  toString() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb('+DOC');
    if (this.r4b_1) {
      this_0.tb(' ---');
    }
    return this_0.toString();
  }
}
class ID extends Enum {}
class ImplicitTuple {
  constructor(plain, nonPlain) {
    this.v4b_1 = plain;
    this.w4b_1 = nonPlain;
  }
  x4b() {
    return !this.v4b_1 && !this.w4b_1;
  }
  toString() {
    return 'implicit=[' + this.v4b_1 + ', ' + this.w4b_1 + ']';
  }
}
class MappingEndEvent extends CollectionEndEvent {
  static a4c(startMark, endMark) {
    var $this = this.u4a(startMark, endMark);
    init_it_krzeminski_snakeyaml_engine_kmp_events_MappingEndEvent($this);
    return $this;
  }
  static b4c() {
    var $this = this.y4a();
    init_it_krzeminski_snakeyaml_engine_kmp_events_MappingEndEvent($this);
    return $this;
  }
  r4a() {
    return ID_MappingEnd_getInstance();
  }
  toString() {
    return '-MAP';
  }
}
class MappingStartEvent extends CollectionStartEvent {
  static i4c(anchor, tag, implicit, flowStyle, startMark, endMark) {
    startMark = startMark === VOID ? null : startMark;
    endMark = endMark === VOID ? null : endMark;
    return this.f4b(anchor, tag, implicit, flowStyle, startMark, endMark);
  }
  r4a() {
    return ID_MappingStart_getInstance();
  }
  toString() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb('+MAP');
    if (this.e4b_1.equals(FlowStyle_FLOW_getInstance())) {
      this_0.tb(' {}');
    }
    this_0.tb(super.toString());
    return this_0.toString();
  }
}
class ScalarEvent extends NodeEvent {
  static q4c(anchor, tag, implicit, value, scalarStyle, startMark, endMark) {
    startMark = startMark === VOID ? null : startMark;
    endMark = endMark === VOID ? null : endMark;
    var $this = this.q4a(anchor, startMark, endMark);
    $this.m4c_1 = tag;
    $this.n4c_1 = implicit;
    $this.o4c_1 = value;
    $this.p4c_1 = scalarStyle;
    return $this;
  }
  r4a() {
    return ID_Scalar_getInstance();
  }
  r4c() {
    return this.p4c_1.equals(ScalarStyle_PLAIN_getInstance());
  }
  toString() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb('=VAL');
    if (!(this.p4a_1 == null)) {
      this_0.tb(' &' + toString_1(this.p4a_1));
    }
    if (this.n4c_1.x4b()) {
      if (!(this.m4c_1 == null)) {
        this_0.tb(' <' + this.m4c_1 + '>');
      }
    }
    this_0.tb(' ');
    this_0.tb(this.p4c_1.toString());
    this_0.tb(this.s4c());
    return this_0.toString();
  }
  s4c() {
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = toCodePoints(this.o4c_1);
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.code' call
      var this_0 = _Char___init__impl__6a9atx(65535);
      if (element < Char__toInt_impl_vasixd(this_0)) {
        destination.l(element);
      }
    }
    var tmp = destination;
    return joinToString(tmp, '', VOID, VOID, VOID, VOID, ScalarEvent$escapedValue$lambda);
  }
}
class SequenceEndEvent extends CollectionEndEvent {
  static v4c(startMark, endMark) {
    var $this = this.u4a(startMark, endMark);
    init_it_krzeminski_snakeyaml_engine_kmp_events_SequenceEndEvent($this);
    return $this;
  }
  static w4c() {
    var $this = this.y4a();
    init_it_krzeminski_snakeyaml_engine_kmp_events_SequenceEndEvent($this);
    return $this;
  }
  r4a() {
    return ID_SequenceEnd_getInstance();
  }
  toString() {
    return '-SEQ';
  }
}
class SequenceStartEvent extends CollectionStartEvent {
  static d4d(anchor, tag, implicit, flowStyle, startMark, endMark) {
    startMark = startMark === VOID ? null : startMark;
    endMark = endMark === VOID ? null : endMark;
    return this.f4b(anchor, tag, implicit, flowStyle, startMark, endMark);
  }
  r4a() {
    return ID_SequenceStart_getInstance();
  }
  toString() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb('+SEQ');
    if (this.e4b_1.equals(FlowStyle_FLOW_getInstance())) {
      this_0.tb(' []');
    }
    this_0.tb(super.toString());
    return this_0.toString();
  }
}
class StreamEndEvent extends Event {
  static g4d(startMark, endMark) {
    var $this = this.x4a(startMark, endMark);
    init_it_krzeminski_snakeyaml_engine_kmp_events_StreamEndEvent($this);
    return $this;
  }
  static h4d() {
    var $this = this.x4a();
    init_it_krzeminski_snakeyaml_engine_kmp_events_StreamEndEvent($this);
    return $this;
  }
  r4a() {
    return ID_StreamEnd_getInstance();
  }
  toString() {
    return '-STR';
  }
}
class StreamStartEvent extends Event {
  static k4d(startMark, endMark) {
    var $this = this.x4a(startMark, endMark);
    init_it_krzeminski_snakeyaml_engine_kmp_events_StreamStartEvent($this);
    return $this;
  }
  static l4d() {
    var $this = this.x4a();
    init_it_krzeminski_snakeyaml_engine_kmp_events_StreamStartEvent($this);
    return $this;
  }
  r4a() {
    return ID_StreamStart_getInstance();
  }
  toString() {
    return '+STR';
  }
}
class YamlEngineException extends RuntimeException {
  static p4d(message) {
    var $this = this.ra(message);
    init_it_krzeminski_snakeyaml_engine_kmp_exceptions_YamlEngineException($this);
    return $this;
  }
  static r4f(cause) {
    var $this = this.de(cause);
    init_it_krzeminski_snakeyaml_engine_kmp_exceptions_YamlEngineException($this);
    return $this;
  }
  static i4e(message, cause) {
    var $this = this.be(message, cause);
    init_it_krzeminski_snakeyaml_engine_kmp_exceptions_YamlEngineException($this);
    return $this;
  }
}
class EmitterException extends YamlEngineException {
  static a47(msg) {
    var $this = this.p4d(msg);
    captureStack($this, $this.z46_1);
    return $this;
  }
}
class Companion_3 {
  constructor() {
    this.q4d_1 = ' ... ';
  }
}
class Mark {
  constructor(name, index, line, column, codepoints, pointer) {
    pointer = pointer === VOID ? 0 : pointer;
    this.r4d_1 = name;
    this.s4d_1 = index;
    this.t4d_1 = line;
    this.u4d_1 = column;
    this.v4d_1 = codepoints;
    this.w4d_1 = pointer;
  }
  x4d(indentSize, maxLength) {
    var halfMaxLength = maxLength / 2 | 0;
    var tmp0 = take(this.v4d_1, this.w4d_1);
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'kotlin.collections.takeLastWhile' call
      if (tmp0.h1()) {
        tmp$ret$0 = emptyList();
        break $l$block_1;
      }
      var iterator = tmp0.i1(tmp0.b1());
      while (iterator.p6()) {
        var it = iterator.r6();
        if (!!isLineBreak(this, it)) {
          iterator.a1();
          var expectedSize = tmp0.b1() - iterator.q6() | 0;
          if (expectedSize === 0) {
            tmp$ret$0 = emptyList();
            break $l$block_1;
          }
          // Inline function 'kotlin.apply' call
          var this_0 = ArrayList.x(expectedSize);
          while (iterator.z()) {
            this_0.l(iterator.a1());
          }
          tmp$ret$0 = this_0;
          break $l$block_1;
        }
      }
      tmp$ret$0 = toList(tmp0);
    }
    var lineBeforePointer = joinCodepointsToString(tmp$ret$0);
    // Inline function 'kotlin.collections.takeWhile' call
    var this_1 = drop(this.v4d_1, this.w4d_1);
    var list = ArrayList.k();
    var _iterator__ex2g4s = this_1.y();
    $l$loop: while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      if (!!isLineBreak(this, item))
        break $l$loop;
      list.l(item);
    }
    var lineAfterPointer = joinCodepointsToString(list);
    var tmp;
    if (lineBeforePointer.length > halfMaxLength) {
      tmp = ' ... ' + drop_0(takeLast(lineBeforePointer, halfMaxLength), 5);
    } else {
      tmp = lineBeforePointer;
    }
    var head = tmp;
    var tmp_0;
    if (lineAfterPointer.length > halfMaxLength) {
      tmp_0 = dropLast(take_0(lineAfterPointer, halfMaxLength), 5) + ' ... ';
    } else {
      tmp_0 = lineAfterPointer;
    }
    var tail = tmp_0;
    var indent = repeat(' ', indentSize);
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_2 = StringBuilder.v();
    this_2.tb(indent);
    this_2.tb(head);
    this_2.tb(tail);
    // Inline function 'kotlin.text.appendLine' call
    this_2.ub(_Char___init__impl__6a9atx(10));
    this_2.tb(indent);
    this_2.tb(repeat(' ', head.length));
    this_2.tb('^');
    return this_2.toString();
  }
  y4d(indentSize, maxLength, $super) {
    indentSize = indentSize === VOID ? 4 : indentSize;
    maxLength = maxLength === VOID ? 75 : maxLength;
    return $super === VOID ? this.x4d(indentSize, maxLength) : $super.x4d.call(this, indentSize, maxLength);
  }
  toString() {
    var snippet = this.y4d();
    // Inline function 'kotlin.text.trim' call
    var this_0 = this.r4d_1;
    var tmp$ret$0 = toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
    return trimMargin('\n            | in ' + tmp$ret$0 + ', line ' + (this.t4d_1 + 1 | 0) + ', column ' + (this.u4d_1 + 1 | 0) + ':\n            |' + snippet + '\n        ');
  }
}
class Companion_4 {}
class MarkedYamlEngineException extends YamlEngineException {
  static h4e(context, contextMark, problem, problemMark, cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.i4e(buildReadableError(Companion_instance_4, context, contextMark, problem, problemMark), cause);
    captureStack($this, $this.g4e_1);
    $this.c4e_1 = context;
    $this.d4e_1 = contextMark;
    $this.e4e_1 = problem;
    $this.f4e_1 = problemMark;
    return $this;
  }
}
class ParserException extends MarkedYamlEngineException {
  static s4e(problem, contextMark, context, problemMark, cause) {
    context = context === VOID ? null : context;
    problemMark = problemMark === VOID ? null : problemMark;
    cause = cause === VOID ? null : cause;
    var $this = this.h4e(context, contextMark, problem, problemMark, cause);
    captureStack($this, $this.r4e_1);
    return $this;
  }
}
class ReaderException extends YamlEngineException {
  static a4f(name, position, codePoint, message) {
    var $this = this.p4d(message);
    captureStack($this, $this.z4e_1);
    $this.w4e_1 = name;
    $this.x4e_1 = position;
    $this.y4e_1 = codePoint;
    return $this;
  }
  toString() {
    var s = concatToString(Character_getInstance().g4f(this.y4e_1));
    // Inline function 'kotlin.text.uppercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var charHex = toString_2(this.y4e_1, 16).toUpperCase();
    return trimIndent("\n             unacceptable code point '" + s + "' (0x" + charHex + ') ' + this.message + '\n             in "' + this.w4e_1 + '", position ' + this.x4e_1 + '\n             ');
  }
}
class ScannerException extends MarkedYamlEngineException {
  static q4f(problem, problemMark, context, contextMark, cause) {
    context = context === VOID ? null : context;
    contextMark = contextMark === VOID ? null : contextMark;
    cause = cause === VOID ? null : cause;
    var $this = this.h4e(context, contextMark, problem, problemMark, cause);
    captureStack($this, $this.p4f_1);
    return $this;
  }
}
class YamlVersionException extends YamlEngineException {
  static y45(specVersion) {
    var $this = this.p4d(specVersion.toString());
    captureStack($this, $this.x45_1);
    return $this;
  }
}
class Character {
  constructor() {
    Character_instance = this;
    this.b4f_1 = 0;
    this.c4f_1 = 1114111;
    this.d4f_1 = 65536;
    this.e4f_1 = -56613888;
    this.f4f_1 = _Char___init__impl__6a9atx(55232);
  }
  x4f(codePoint) {
    return 65536 <= codePoint ? codePoint <= 1114111 : false;
  }
  w4f(codePoint) {
    return codePoint <= 65536 ? 1 : 2;
  }
  y4f(highSurrogate, lowSurrogate) {
    return isHighSurrogate(highSurrogate) && isLowSurrogate(lowSurrogate);
  }
  v4f(highSurrogate, lowSurrogate) {
    // Inline function 'kotlin.code' call
    var tmp = Char__toInt_impl_vasixd(highSurrogate) << 10;
    // Inline function 'kotlin.code' call
    return (tmp + Char__toInt_impl_vasixd(lowSurrogate) | 0) + -56613888 | 0;
  }
  g4f(codePoint) {
    var tmp;
    if (this.u4f(codePoint)) {
      // Inline function 'kotlin.charArrayOf' call
      tmp = charArrayOf([numberToChar(codePoint)]);
    } else {
      var hi = this.s4f(codePoint);
      var lo = this.t4f(codePoint);
      // Inline function 'kotlin.require' call
      // Inline function 'kotlin.require' call
      if (!this.y4f(hi, lo)) {
        var message = 'Failed requirement.';
        throw IllegalArgumentException.t(toString(message));
      }
      // Inline function 'kotlin.charArrayOf' call
      tmp = charArrayOf([hi, lo]);
    }
    return tmp;
  }
  u4f(codePoint) {
    return (codePoint >>> 16 | 0) === 0;
  }
  s4f(codePoint) {
    var tmp = codePoint >>> 10 | 0;
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(55232);
    var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
    return numberToChar(tmp + tmp$ret$0 | 0);
  }
  t4f(codePoint) {
    var tmp = codePoint & 1023;
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(56320);
    var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
    return numberToChar(tmp + tmp$ret$0 | 0);
  }
}
class Companion_5 {
  constructor() {
    Companion_instance_5 = this;
    this.z4f_1 = 'tag:yaml.org,2002:';
    this.a4g_1 = new Tag('tag:yaml.org,2002:set');
    this.b4g_1 = new Tag('tag:yaml.org,2002:binary');
    this.c4g_1 = new Tag('tag:yaml.org,2002:int');
    this.d4g_1 = new Tag('tag:yaml.org,2002:float');
    this.e4g_1 = new Tag('tag:yaml.org,2002:bool');
    this.f4g_1 = new Tag('tag:yaml.org,2002:null');
    this.g4g_1 = new Tag('tag:yaml.org,2002:str');
    this.h4g_1 = new Tag('tag:yaml.org,2002:seq');
    this.i4g_1 = new Tag('tag:yaml.org,2002:map');
    this.j4g_1 = new Tag('tag:yaml.org,2002:comment');
    this.k4g_1 = new Tag('!ENV_VARIABLE');
  }
}
class Tag {
  constructor(tag) {
    Companion_getInstance_5();
    // Inline function 'kotlin.text.isNotEmpty' call
    // Inline function 'kotlin.require' call
    if (!(charSequenceLength(tag) > 0)) {
      var message = 'Tag must not be empty.';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.text.trim' call
    // Inline function 'kotlin.text.trim' call
    var this_0 = isCharSequence(tag) ? tag : THROW_CCE();
    var startIndex = 0;
    var endIndex = charSequenceLength(this_0) - 1 | 0;
    var startFound = false;
    $l$loop: while (startIndex <= endIndex) {
      var index = !startFound ? startIndex : endIndex;
      var it = charSequenceGet(this_0, index);
      var match = Char__compareTo_impl_ypi4mb(it, _Char___init__impl__6a9atx(32)) <= 0;
      if (!startFound) {
        if (!match)
          startFound = true;
        else
          startIndex = startIndex + 1 | 0;
      } else {
        if (!match)
          break $l$loop;
        else
          endIndex = endIndex - 1 | 0;
      }
    }
    var tmp$ret$4 = charSequenceSubSequence(this_0, startIndex, endIndex + 1 | 0);
    // Inline function 'kotlin.require' call
    if (!(toString(tmp$ret$4).length === tag.length)) {
      var message_0 = 'Tag must not contain leading or trailing spaces.';
      throw IllegalArgumentException.t(toString(message_0));
    }
    this.l4g_1 = UriEncoder_instance.f48(tag);
  }
  toString() {
    return this.l4g_1;
  }
  equals(other) {
    var tmp;
    if (other instanceof Tag) {
      tmp = this.l4g_1 === other.l4g_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return getStringHashCode(this.l4g_1);
  }
}
class ParseStreamStart {
  constructor($outer) {
    this.b4i_1 = $outer;
  }
  t4g() {
    var tmp = this.b4i_1.n4g_1.a1();
    var token = tmp instanceof StreamStartToken ? tmp : THROW_CCE();
    var event = StreamStartEvent.k4d(token.y4g_1, token.z4g_1);
    this.b4i_1.r4g_1 = new ParseImplicitDocumentStart(this.b4i_1);
    return event;
  }
}
class ParseImplicitDocumentStart {
  constructor($outer) {
    this.c4i_1 = $outer;
  }
  t4g() {
    if (this.c4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.c4i_1.r4g_1 = new ParseImplicitDocumentStart(this.c4i_1);
      var tmp = this.c4i_1.n4g_1.a1();
      return produceCommentEvent(this.c4i_1, tmp instanceof CommentToken ? tmp : THROW_CCE());
    }
    var tmp_0;
    if (!this.c4i_1.n4g_1.e4i([ID_Directive_getInstance(), ID_DocumentStart_getInstance_0(), ID_StreamEnd_getInstance_0()])) {
      var token = this.c4i_1.n4g_1.r4h();
      var startMark = token.y4g_1;
      this.c4i_1.o4g_1.vk(new ParseDocumentEnd(this.c4i_1));
      this.c4i_1.r4g_1 = new ParseBlockNode(this.c4i_1);
      tmp_0 = DocumentStartEvent.u4b(false, null, emptyMap(), startMark, startMark);
    } else {
      tmp_0 = (new ParseDocumentStart(this.c4i_1)).t4g();
    }
    return tmp_0;
  }
}
class ParseDocumentStart {
  constructor($outer) {
    this.d4i_1 = $outer;
  }
  t4g() {
    if (this.d4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.d4i_1.r4g_1 = new ParseDocumentStart(this.d4i_1);
      var tmp = this.d4i_1.n4g_1.a1();
      return produceCommentEvent(this.d4i_1, tmp instanceof CommentToken ? tmp : THROW_CCE());
    }
    while (this.d4i_1.n4g_1.a4h(ID_DocumentEnd_getInstance_0())) {
      this.d4i_1.n4g_1.a1();
    }
    if (this.d4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.d4i_1.r4g_1 = new ParseDocumentStart(this.d4i_1);
      var tmp_0 = this.d4i_1.n4g_1.a1();
      return produceCommentEvent(this.d4i_1, tmp_0 instanceof CommentToken ? tmp_0 : THROW_CCE());
    }
    if (!this.d4i_1.n4g_1.a4h(ID_StreamEnd_getInstance_0())) {
      this.d4i_1.n4g_1.f4i();
      var tuple = processDirectives(this.d4i_1);
      while (this.d4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
        this.d4i_1.n4g_1.a1();
      }
      var tmp_1;
      if (!this.d4i_1.n4g_1.a4h(ID_StreamEnd_getInstance_0())) {
        if (!this.d4i_1.n4g_1.a4h(ID_DocumentStart_getInstance_0())) {
          throw ParserException.s4e("expected '<document start>', but found '" + this.d4i_1.n4g_1.r4h().s4h().toString() + "'", this.d4i_1.n4g_1.r4h().y4g_1);
        }
        var token = this.d4i_1.n4g_1.a1();
        var startMark = token.y4g_1;
        var endMark = token.z4g_1;
        this.d4i_1.o4g_1.vk(new ParseDocumentEnd(this.d4i_1));
        this.d4i_1.r4g_1 = new ParseDocumentContent(this.d4i_1);
        tmp_1 = DocumentStartEvent.u4b(true, tuple.g4i_1, tuple.h4i_1, startMark, endMark);
      } else {
        throw ParserException.s4e("expected '<document start>', but found '" + this.d4i_1.n4g_1.r4h().s4h().toString() + "'", this.d4i_1.n4g_1.r4h().y4g_1);
      }
      return tmp_1;
    }
    var tmp_2 = this.d4i_1.n4g_1.a1();
    var token_0 = tmp_2 instanceof StreamEndToken ? tmp_2 : THROW_CCE();
    if (!this.d4i_1.o4g_1.h1()) {
      throw YamlEngineException.p4d('Unexpected end of stream. States left: ' + this.d4i_1.o4g_1.toString());
    }
    if (!this.d4i_1.p4g_1.h1()) {
      throw YamlEngineException.p4d('Unexpected end of stream. Marks left: ' + this.d4i_1.p4g_1.toString());
    }
    this.d4i_1.r4g_1 = null;
    return StreamEndEvent.g4d(token_0.y4g_1, token_0.z4g_1);
  }
}
class ParseDocumentEnd {
  constructor($outer) {
    this.i4i_1 = $outer;
  }
  t4g() {
    var token = this.i4i_1.n4g_1.r4h();
    var startMark = token.y4g_1;
    var endMark;
    var explicit;
    if (this.i4i_1.n4g_1.a4h(ID_DocumentEnd_getInstance_0())) {
      token = this.i4i_1.n4g_1.a1();
      endMark = token.z4g_1;
      explicit = true;
    } else if (this.i4i_1.n4g_1.a4h(ID_Directive_getInstance())) {
      throw ParserException.s4e("expected '<document end>' before directives, but found '" + this.i4i_1.n4g_1.r4h().s4h().toString() + "'", this.i4i_1.n4g_1.r4h().y4g_1);
    } else {
      endMark = token.y4g_1;
      explicit = false;
    }
    this.i4i_1.s4g_1.b3();
    this.i4i_1.r4g_1 = new ParseDocumentStart(this.i4i_1);
    return DocumentEndEvent.o4b(explicit, startMark, endMark);
  }
}
class ParseDocumentContent {
  constructor($outer) {
    this.j4i_1 = $outer;
  }
  t4g() {
    var tmp;
    if (this.j4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.j4i_1.r4g_1 = new ParseDocumentContent(this.j4i_1);
      var tmp_0 = this.j4i_1.n4g_1.a1();
      return produceCommentEvent(this.j4i_1, tmp_0 instanceof CommentToken ? tmp_0 : THROW_CCE());
    } else if (this.j4i_1.n4g_1.e4i([ID_Directive_getInstance(), ID_DocumentStart_getInstance_0(), ID_DocumentEnd_getInstance_0(), ID_StreamEnd_getInstance_0()])) {
      this.j4i_1.r4g_1 = this.j4i_1.o4g_1.yk();
      var event = processEmptyScalar(this.j4i_1, this.j4i_1.n4g_1.r4h().y4g_1);
      tmp = event;
    } else {
      tmp = (new ParseBlockNode(this.j4i_1)).t4g();
    }
    return tmp;
  }
}
class ParseBlockNode {
  constructor($outer) {
    this.k4i_1 = $outer;
  }
  t4g() {
    return parseNode(this.k4i_1, true, false);
  }
}
class ParseBlockSequenceFirstEntry {
  constructor($outer) {
    this.l4i_1 = $outer;
  }
  t4g() {
    var token = this.l4i_1.n4g_1.a1();
    markPush(this.l4i_1, token.y4g_1);
    return (new ParseBlockSequenceEntryKey(this.l4i_1)).t4g();
  }
}
class ParseBlockSequenceEntryKey {
  constructor($outer) {
    this.m4i_1 = $outer;
  }
  t4g() {
    var tmp;
    if (this.m4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.m4i_1.r4g_1 = new ParseBlockSequenceEntryKey(this.m4i_1);
      var tmp_0 = this.m4i_1.n4g_1.a1();
      tmp = produceCommentEvent(this.m4i_1, tmp_0 instanceof CommentToken ? tmp_0 : THROW_CCE());
    } else if (this.m4i_1.n4g_1.a4h(ID_BlockEntry_getInstance())) {
      var tmp_1 = this.m4i_1.n4g_1.a1();
      var token = tmp_1 instanceof BlockEntryToken ? tmp_1 : THROW_CCE();
      tmp = (new ParseBlockSequenceEntryValue(this.m4i_1, token)).t4g();
    } else if (!this.m4i_1.n4g_1.a4h(ID_BlockEnd_getInstance())) {
      var token_0 = this.m4i_1.n4g_1.r4h();
      throw ParserException.s4e("expected <block end>, but found '" + token_0.s4h().toString() + "'", markPop(this.m4i_1), 'while parsing a block collection', token_0.y4g_1);
    } else {
      var token_1 = this.m4i_1.n4g_1.a1();
      this.m4i_1.r4g_1 = this.m4i_1.o4g_1.yk();
      markPop(this.m4i_1);
      tmp = SequenceEndEvent.v4c(token_1.y4g_1, token_1.z4g_1);
    }
    return tmp;
  }
}
class ParseBlockSequenceEntryValue {
  constructor($outer, token) {
    this.o4i_1 = $outer;
    this.n4i_1 = token;
  }
  t4g() {
    if (this.o4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.o4i_1.r4g_1 = new ParseBlockSequenceEntryValue(this.o4i_1, this.n4i_1);
      var tmp = this.o4i_1.n4g_1.a1();
      return produceCommentEvent(this.o4i_1, tmp instanceof CommentToken ? tmp : THROW_CCE());
    }
    var tmp_0;
    if (!this.o4i_1.n4g_1.e4i([ID_BlockEntry_getInstance(), ID_BlockEnd_getInstance()])) {
      this.o4i_1.o4g_1.vk(new ParseBlockSequenceEntryKey(this.o4i_1));
      tmp_0 = (new ParseBlockNode(this.o4i_1)).t4g();
    } else {
      this.o4i_1.r4g_1 = new ParseBlockSequenceEntryKey(this.o4i_1);
      tmp_0 = processEmptyScalar(this.o4i_1, this.n4i_1.z4g_1);
    }
    return tmp_0;
  }
}
class ParseIndentlessSequenceEntryKey {
  constructor($outer) {
    this.p4i_1 = $outer;
  }
  t4g() {
    if (this.p4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.p4i_1.r4g_1 = new ParseIndentlessSequenceEntryKey(this.p4i_1);
      var tmp = this.p4i_1.n4g_1.a1();
      return produceCommentEvent(this.p4i_1, tmp instanceof CommentToken ? tmp : THROW_CCE());
    }
    if (this.p4i_1.n4g_1.a4h(ID_BlockEntry_getInstance())) {
      var tmp_0 = this.p4i_1.n4g_1.a1();
      var token = tmp_0 instanceof BlockEntryToken ? tmp_0 : THROW_CCE();
      return (new ParseIndentlessSequenceEntryValue(this.p4i_1, token)).t4g();
    }
    var token_0 = this.p4i_1.n4g_1.r4h();
    this.p4i_1.r4g_1 = this.p4i_1.o4g_1.yk();
    return SequenceEndEvent.v4c(token_0.y4g_1, token_0.z4g_1);
  }
}
class ParseIndentlessSequenceEntryValue {
  constructor($outer, token) {
    this.r4i_1 = $outer;
    this.q4i_1 = token;
  }
  t4g() {
    var tmp;
    if (this.r4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.r4i_1.r4g_1 = new ParseIndentlessSequenceEntryValue(this.r4i_1, this.q4i_1);
      var tmp_0 = this.r4i_1.n4g_1.a1();
      tmp = produceCommentEvent(this.r4i_1, tmp_0 instanceof CommentToken ? tmp_0 : THROW_CCE());
    } else if (!this.r4i_1.n4g_1.e4i([ID_BlockEntry_getInstance(), ID_Key_getInstance(), ID_Value_getInstance(), ID_BlockEnd_getInstance()])) {
      this.r4i_1.o4g_1.vk(new ParseIndentlessSequenceEntryKey(this.r4i_1));
      tmp = (new ParseBlockNode(this.r4i_1)).t4g();
    } else {
      this.r4i_1.r4g_1 = new ParseIndentlessSequenceEntryKey(this.r4i_1);
      tmp = processEmptyScalar(this.r4i_1, this.q4i_1.z4g_1);
    }
    return tmp;
  }
}
class ParseBlockMappingFirstKey {
  constructor($outer) {
    this.s4i_1 = $outer;
  }
  t4g() {
    var token = this.s4i_1.n4g_1.a1();
    markPush(this.s4i_1, token.y4g_1);
    return (new ParseBlockMappingKey(this.s4i_1)).t4g();
  }
}
class ParseBlockMappingKey {
  constructor($outer) {
    this.t4i_1 = $outer;
  }
  t4g() {
    var tmp;
    if (this.t4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.t4i_1.r4g_1 = new ParseBlockMappingKey(this.t4i_1);
      var tmp_0 = this.t4i_1.n4g_1.a1();
      tmp = produceCommentEvent(this.t4i_1, tmp_0 instanceof CommentToken ? tmp_0 : THROW_CCE());
    } else if (this.t4i_1.n4g_1.a4h(ID_Key_getInstance())) {
      var token = this.t4i_1.n4g_1.a1();
      var tmp_1;
      if (!this.t4i_1.n4g_1.e4i([ID_Key_getInstance(), ID_Value_getInstance(), ID_BlockEnd_getInstance()])) {
        this.t4i_1.o4g_1.vk(new ParseBlockMappingValue(this.t4i_1));
        tmp_1 = parseBlockNodeOrIndentlessSequence(this.t4i_1);
      } else {
        this.t4i_1.r4g_1 = new ParseBlockMappingValue(this.t4i_1);
        tmp_1 = processEmptyScalar(this.t4i_1, token.z4g_1);
      }
      tmp = tmp_1;
    } else if (!this.t4i_1.n4g_1.a4h(ID_BlockEnd_getInstance())) {
      var token_0 = this.t4i_1.n4g_1.r4h();
      throw ParserException.s4e("expected <block end>, but found '" + token_0.s4h().toString() + "'", markPop(this.t4i_1), 'while parsing a block mapping', token_0.y4g_1);
    } else {
      var token_1 = this.t4i_1.n4g_1.a1();
      this.t4i_1.r4g_1 = this.t4i_1.o4g_1.yk();
      markPop(this.t4i_1);
      tmp = MappingEndEvent.a4c(token_1.y4g_1, token_1.z4g_1);
    }
    return tmp;
  }
}
class ParseBlockMappingValue {
  constructor($outer) {
    this.u4i_1 = $outer;
  }
  t4g() {
    if (this.u4i_1.n4g_1.a4h(ID_Value_getInstance())) {
      var token = this.u4i_1.n4g_1.a1();
      var tmp;
      if (this.u4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
        var p = new ParseBlockMappingValueComment(this.u4i_1);
        this.u4i_1.r4g_1 = p;
        tmp = p.t4g();
      } else if (!this.u4i_1.n4g_1.e4i([ID_Key_getInstance(), ID_Value_getInstance(), ID_BlockEnd_getInstance()])) {
        this.u4i_1.o4g_1.vk(new ParseBlockMappingKey(this.u4i_1));
        tmp = parseBlockNodeOrIndentlessSequence(this.u4i_1);
      } else {
        this.u4i_1.r4g_1 = new ParseBlockMappingKey(this.u4i_1);
        tmp = processEmptyScalar(this.u4i_1, token.z4g_1);
      }
      return tmp;
    } else if (this.u4i_1.n4g_1.a4h(ID_Scalar_getInstance_0())) {
      this.u4i_1.o4g_1.vk(new ParseBlockMappingKey(this.u4i_1));
      return parseBlockNodeOrIndentlessSequence(this.u4i_1);
    }
    this.u4i_1.r4g_1 = new ParseBlockMappingKey(this.u4i_1);
    var token_0 = this.u4i_1.n4g_1.r4h();
    return processEmptyScalar(this.u4i_1, token_0.y4g_1);
  }
}
class ParseBlockMappingValueComment {
  constructor($outer) {
    this.w4i_1 = $outer;
    this.v4i_1 = ArrayDeque.rk();
  }
  t4g() {
    var tmp;
    if (this.w4i_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      var tmp_0 = this.w4i_1.n4g_1.a1();
      this.v4i_1.l(tmp_0 instanceof CommentToken ? tmp_0 : THROW_CCE());
      tmp = this.t4g();
    } else if (!this.w4i_1.n4g_1.e4i([ID_Key_getInstance(), ID_Value_getInstance(), ID_BlockEnd_getInstance()])) {
      var tmp_1;
      // Inline function 'kotlin.collections.isNotEmpty' call
      if (!this.v4i_1.h1()) {
        tmp_1 = produceCommentEvent(this.w4i_1, this.v4i_1.wk());
      } else {
        this.w4i_1.o4g_1.vk(new ParseBlockMappingKey(this.w4i_1));
        tmp_1 = parseBlockNodeOrIndentlessSequence(this.w4i_1);
      }
      tmp = tmp_1;
    } else {
      this.w4i_1.r4g_1 = new ParseBlockMappingValueCommentList(this.w4i_1, this.v4i_1);
      tmp = processEmptyScalar(this.w4i_1, this.w4i_1.n4g_1.r4h().y4g_1);
    }
    return tmp;
  }
}
class ParseBlockMappingValueCommentList {
  constructor($outer, tokens) {
    this.y4i_1 = $outer;
    this.x4i_1 = tokens;
  }
  t4g() {
    var tmp;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this.x4i_1.h1()) {
      tmp = produceCommentEvent(this.y4i_1, this.x4i_1.wk());
    } else {
      tmp = (new ParseBlockMappingKey(this.y4i_1)).t4g();
    }
    return tmp;
  }
}
class ParseFlowSequenceFirstEntry {
  constructor($outer) {
    this.z4i_1 = $outer;
  }
  t4g() {
    var token = this.z4i_1.n4g_1.a1();
    markPush(this.z4i_1, token.y4g_1);
    return (new ParseFlowSequenceEntry(this.z4i_1, true)).t4g();
  }
}
class ParseFlowSequenceEntry {
  constructor($outer, first) {
    this.b4j_1 = $outer;
    this.a4j_1 = first;
  }
  t4g() {
    if (this.b4j_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.b4j_1.r4g_1 = new ParseFlowSequenceEntry(this.b4j_1, this.a4j_1);
      var tmp = this.b4j_1.n4g_1.a1();
      return produceCommentEvent(this.b4j_1, tmp instanceof CommentToken ? tmp : THROW_CCE());
    }
    if (!this.b4j_1.n4g_1.a4h(ID_FlowSequenceEnd_getInstance())) {
      if (!this.a4j_1) {
        if (this.b4j_1.n4g_1.a4h(ID_FlowEntry_getInstance())) {
          this.b4j_1.n4g_1.a1();
          if (this.b4j_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
            this.b4j_1.r4g_1 = new ParseFlowSequenceEntry(this.b4j_1, true);
            var tmp_0 = this.b4j_1.n4g_1.a1();
            return produceCommentEvent(this.b4j_1, tmp_0 instanceof CommentToken ? tmp_0 : THROW_CCE());
          }
        } else {
          var token = this.b4j_1.n4g_1.r4h();
          throw ParserException.s4e("expected ',' or ']', but got " + token.s4h().toString(), markPop(this.b4j_1), 'while parsing a flow sequence', token.y4g_1);
        }
      }
      if (this.b4j_1.n4g_1.a4h(ID_Key_getInstance())) {
        var token_0 = this.b4j_1.n4g_1.r4h();
        this.b4j_1.r4g_1 = new ParseFlowSequenceEntryMappingKey(this.b4j_1);
        return MappingStartEvent.i4c(null, null, true, FlowStyle_FLOW_getInstance(), token_0.y4g_1, token_0.z4g_1);
      } else if (!this.b4j_1.n4g_1.a4h(ID_FlowSequenceEnd_getInstance())) {
        this.b4j_1.o4g_1.vk(new ParseFlowSequenceEntry(this.b4j_1, false));
        return parseFlowNode(this.b4j_1);
      }
    }
    var token_1 = this.b4j_1.n4g_1.a1();
    var tmp_1 = this.b4j_1;
    var tmp_2;
    if (!this.b4j_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      tmp_2 = this.b4j_1.o4g_1.yk();
    } else {
      tmp_2 = new ParseFlowEndComment(this.b4j_1);
    }
    tmp_1.r4g_1 = tmp_2;
    markPop(this.b4j_1);
    return SequenceEndEvent.v4c(token_1.y4g_1, token_1.z4g_1);
  }
}
class ParseFlowEndComment {
  constructor($outer) {
    this.c4j_1 = $outer;
  }
  t4g() {
    var tmp = this.c4j_1.n4g_1.a1();
    var event = produceCommentEvent(this.c4j_1, tmp instanceof CommentToken ? tmp : THROW_CCE());
    if (!this.c4j_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      this.c4j_1.r4g_1 = this.c4j_1.o4g_1.yk();
    }
    return event;
  }
}
class ParseFlowSequenceEntryMappingKey {
  constructor($outer) {
    this.d4j_1 = $outer;
  }
  t4g() {
    var token = this.d4j_1.n4g_1.a1();
    var tmp;
    if (!this.d4j_1.n4g_1.e4i([ID_Value_getInstance(), ID_FlowEntry_getInstance(), ID_FlowSequenceEnd_getInstance()])) {
      this.d4j_1.o4g_1.vk(new ParseFlowSequenceEntryMappingValue(this.d4j_1));
      tmp = parseFlowNode(this.d4j_1);
    } else {
      this.d4j_1.r4g_1 = new ParseFlowSequenceEntryMappingValue(this.d4j_1);
      tmp = processEmptyScalar(this.d4j_1, token.z4g_1);
    }
    return tmp;
  }
}
class ParseFlowSequenceEntryMappingValue {
  constructor($outer) {
    this.e4j_1 = $outer;
  }
  t4g() {
    var tmp;
    if (this.e4j_1.n4g_1.a4h(ID_Value_getInstance())) {
      var token = this.e4j_1.n4g_1.a1();
      var tmp_0;
      if (!this.e4j_1.n4g_1.e4i([ID_FlowEntry_getInstance(), ID_FlowSequenceEnd_getInstance()])) {
        this.e4j_1.o4g_1.vk(new ParseFlowSequenceEntryMappingEnd(this.e4j_1));
        tmp_0 = parseFlowNode(this.e4j_1);
      } else {
        this.e4j_1.r4g_1 = new ParseFlowSequenceEntryMappingEnd(this.e4j_1);
        tmp_0 = processEmptyScalar(this.e4j_1, token.z4g_1);
      }
      tmp = tmp_0;
    } else {
      this.e4j_1.r4g_1 = new ParseFlowSequenceEntryMappingEnd(this.e4j_1);
      var token_0 = this.e4j_1.n4g_1.r4h();
      tmp = processEmptyScalar(this.e4j_1, token_0.y4g_1);
    }
    return tmp;
  }
}
class ParseFlowSequenceEntryMappingEnd {
  constructor($outer) {
    this.f4j_1 = $outer;
  }
  t4g() {
    this.f4j_1.r4g_1 = new ParseFlowSequenceEntry(this.f4j_1, false);
    var token = this.f4j_1.n4g_1.r4h();
    return MappingEndEvent.a4c(token.y4g_1, token.z4g_1);
  }
}
class ParseFlowMappingFirstKey {
  constructor($outer) {
    this.g4j_1 = $outer;
  }
  t4g() {
    var token = this.g4j_1.n4g_1.a1();
    markPush(this.g4j_1, token.y4g_1);
    return (new ParseFlowMappingKey(this.g4j_1, true)).t4g();
  }
}
class ParseFlowMappingKey {
  constructor($outer, first) {
    this.i4j_1 = $outer;
    this.h4j_1 = first;
  }
  t4g() {
    if (!this.i4j_1.n4g_1.a4h(ID_FlowMappingEnd_getInstance())) {
      if (!this.h4j_1) {
        if (this.i4j_1.n4g_1.a4h(ID_FlowEntry_getInstance())) {
          this.i4j_1.n4g_1.a1();
        } else {
          var token = this.i4j_1.n4g_1.r4h();
          throw ParserException.s4e("expected ',' or '}', but got " + token.s4h().toString(), markPop(this.i4j_1), 'while parsing a flow mapping', token.y4g_1);
        }
      }
      if (this.i4j_1.n4g_1.a4h(ID_Key_getInstance())) {
        var token_0 = this.i4j_1.n4g_1.a1();
        var tmp;
        if (!this.i4j_1.n4g_1.e4i([ID_Value_getInstance(), ID_FlowEntry_getInstance(), ID_FlowMappingEnd_getInstance()])) {
          this.i4j_1.o4g_1.vk(new ParseFlowMappingValue(this.i4j_1));
          tmp = parseFlowNode(this.i4j_1);
        } else {
          this.i4j_1.r4g_1 = new ParseFlowMappingValue(this.i4j_1);
          tmp = processEmptyScalar(this.i4j_1, token_0.z4g_1);
        }
        return tmp;
      } else if (!this.i4j_1.n4g_1.a4h(ID_FlowMappingEnd_getInstance())) {
        this.i4j_1.o4g_1.vk(new ParseFlowMappingEmptyValue(this.i4j_1));
        return parseFlowNode(this.i4j_1);
      }
    }
    var token_1 = this.i4j_1.n4g_1.a1();
    markPop(this.i4j_1);
    var tmp_0 = this.i4j_1;
    var tmp_1;
    if (!this.i4j_1.n4g_1.a4h(ID_Comment_getInstance_0())) {
      tmp_1 = this.i4j_1.o4g_1.yk();
    } else {
      tmp_1 = new ParseFlowEndComment(this.i4j_1);
    }
    tmp_0.r4g_1 = tmp_1;
    return MappingEndEvent.a4c(token_1.y4g_1, token_1.z4g_1);
  }
}
class ParseFlowMappingValue {
  constructor($outer) {
    this.j4j_1 = $outer;
  }
  t4g() {
    var tmp;
    if (this.j4j_1.n4g_1.a4h(ID_Value_getInstance())) {
      var token = this.j4j_1.n4g_1.a1();
      var tmp_0;
      if (!this.j4j_1.n4g_1.e4i([ID_FlowEntry_getInstance(), ID_FlowMappingEnd_getInstance()])) {
        this.j4j_1.o4g_1.vk(new ParseFlowMappingKey(this.j4j_1, false));
        tmp_0 = parseFlowNode(this.j4j_1);
      } else {
        this.j4j_1.r4g_1 = new ParseFlowMappingKey(this.j4j_1, false);
        tmp_0 = processEmptyScalar(this.j4j_1, token.z4g_1);
      }
      tmp = tmp_0;
    } else {
      this.j4j_1.r4g_1 = new ParseFlowMappingKey(this.j4j_1, false);
      var token_0 = this.j4j_1.n4g_1.r4h();
      tmp = processEmptyScalar(this.j4j_1, token_0.y4g_1);
    }
    return tmp;
  }
}
class ParseFlowMappingEmptyValue {
  constructor($outer) {
    this.k4j_1 = $outer;
  }
  t4g() {
    this.k4j_1.r4g_1 = new ParseFlowMappingKey(this.k4j_1, false);
    return processEmptyScalar(this.k4j_1, this.k4j_1.n4g_1.r4h().y4g_1);
  }
}
class Companion_6 {
  constructor() {
    Companion_instance_6 = this;
    this.i4h_1 = mapOf([to('!', '!'), to('!!', 'tag:yaml.org,2002:')]);
  }
}
class ParserImpl {
  static l4j(settings, scanner) {
    Companion_getInstance_6();
    var $this = createThis(this);
    $this.m4g_1 = settings;
    $this.n4g_1 = scanner;
    $this.o4g_1 = ArrayDeque.qk(100);
    $this.p4g_1 = ArrayDeque.qk(100);
    $this.q4g_1 = null;
    $this.r4g_1 = new ParseStreamStart($this);
    $this.s4g_1 = toMutableMap(Companion_getInstance_6().i4h_1);
    return $this;
  }
  static m4j(settings, reader) {
    Companion_getInstance_6();
    return this.l4j(settings, new ScannerImpl(settings, reader));
  }
  n4j() {
    produce(this);
    var tmp0_elvis_lhs = this.q4g_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw NoSuchElementException.p('No more Events found.');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  a1() {
    var value = this.n4j();
    this.q4g_1 = null;
    return value;
  }
  z() {
    produce(this);
    return !(this.q4g_1 == null);
  }
}
class VersionTagsTuple {
  constructor(specVersion, tags) {
    this.g4i_1 = specVersion;
    this.h4i_1 = tags;
  }
  toString() {
    return 'VersionTagsTuple<' + toString_1(this.g4i_1) + ', ' + toString(this.h4i_1) + '>';
  }
  hashCode() {
    var result = this.g4i_1 == null ? 0 : hashCode(this.g4i_1);
    result = imul(result, 31) + hashCode(this.h4i_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof VersionTagsTuple))
      return false;
    var tmp0_other_with_cast = other instanceof VersionTagsTuple ? other : THROW_CCE();
    if (!equals(this.g4i_1, tmp0_other_with_cast.g4i_1))
      return false;
    if (!equals(this.h4i_1, tmp0_other_with_cast.h4i_1))
      return false;
    return true;
  }
}
class ImplicitResolversBuilder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.o4j_1 = LinkedHashMap.hc();
  }
  p4j() {
    return toMap(this.o4j_1);
  }
  q4j(tag, regexp, first) {
    var tmp1_safe_receiver = first == null ? null : toCharArray(first);
    var tmp;
    if (tmp1_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(tmp1_safe_receiver.length);
      var inductionVariable = 0;
      var last = tmp1_safe_receiver.length;
      while (inductionVariable < last) {
        var item = tmp1_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        var tmp_0;
        // Inline function 'kotlin.code' call
        if (Char__toInt_impl_vasixd(item) === 0) {
          tmp_0 = null;
        } else {
          tmp_0 = item;
        }
        var tmp_1 = tmp_0;
        var tmp$ret$1 = tmp_1 == null ? null : new Char(tmp_1);
        destination.l(tmp$ret$1);
      }
      tmp = destination;
    }
    var tmp2_elvis_lhs = tmp;
    var keys = tmp2_elvis_lhs == null ? listOf(null) : tmp2_elvis_lhs;
    var _iterator__ex2g4s = distinct(keys).y();
    while (_iterator__ex2g4s.z()) {
      var tmp_2 = _iterator__ex2g4s.a1();
      var key = tmp_2 == null ? null : tmp_2.j2_1;
      var tmp2 = this.o4j_1;
      var tmp_3 = key;
      // Inline function 'kotlin.collections.getOrPut' call
      var key_0 = tmp_3 == null ? null : new Char(tmp_3);
      var value = tmp2.h3(key_0);
      var tmp_4;
      if (value == null) {
        // Inline function 'kotlin.collections.mutableListOf' call
        var answer = ArrayList.k();
        tmp2.k3(key_0, answer);
        tmp_4 = answer;
      } else {
        tmp_4 = value;
      }
      var curr = tmp_4;
      curr.l(new ResolverTuple(tag, regexp));
    }
  }
}
class Companion_7 {
  constructor() {
    Companion_instance_7 = this;
    this.r4j_1 = Regex.xh('^$');
    this.s4j_1 = Regex.xh('^\\$\\{\\s*(\\w+)(?:(:?[-?])(\\w+)?)?\\s*\\}$');
  }
}
class BaseScalarResolver {
  constructor(buildImplicitResolvers) {
    Companion_getInstance_7();
    var tmp;
    if (buildImplicitResolvers === VOID) {
      tmp = BaseScalarResolver$_init_$lambda_ep9miw;
    } else {
      tmp = buildImplicitResolvers;
    }
    buildImplicitResolvers = tmp;
    var tmp_0 = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new ImplicitResolversBuilder();
    buildImplicitResolvers(this_0);
    tmp_0.t4j_1 = this_0.p4j();
  }
}
class Companion_8 {
  constructor() {
    Companion_instance_8 = this;
    this.u4j_1 = Regex.xh('^(?:true|false)$');
    this.v4j_1 = Regex.xh('^(?:(-?(0|[1-9][0-9]*)(\\.[0-9]*)?([eE][-+]?[0-9]+)?)|(-?\\.inf)|(\\.nan))$');
    this.w4j_1 = Regex.xh('^-?(0|[1-9][0-9]*)$');
    this.x4j_1 = Regex.xh('^null$');
  }
}
class JsonScalarResolver extends BaseScalarResolver {
  constructor() {
    Companion_getInstance_8();
    super(JsonScalarResolver$_init_$lambda_2rw3ox);
  }
}
class ResolverTuple {
  constructor(tag, regexp) {
    this.y4j_1 = tag;
    this.z4j_1 = regexp;
  }
  toString() {
    return 'Tuple tag=' + this.y4j_1.toString() + ' regexp=' + this.z4j_1.toString();
  }
  hashCode() {
    var result = this.y4j_1.hashCode();
    result = imul(result, 31) + hashCode(this.z4j_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ResolverTuple))
      return false;
    var tmp0_other_with_cast = other instanceof ResolverTuple ? other : THROW_CCE();
    if (!this.y4j_1.equals(tmp0_other_with_cast.y4j_1))
      return false;
    if (!equals(this.z4j_1, tmp0_other_with_cast.z4j_1))
      return false;
    return true;
  }
}
class Scanner {}
function checkToken(choice) {
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$2 = [choice];
  return this.e4i(tmp$ret$2.slice());
}
class Companion_9 {
  constructor() {
    Companion_instance_9 = this;
    this.p4l_1 = 'while scanning a directive';
    this.q4l_1 = 'expected alphabetic or numeric character, but found ';
    this.r4l_1 = 'while scanning a block scalar';
    this.s4l_1 = 'while scanning a ';
    this.t4l_1 = Regex.xh('[^0-9A-Fa-f]');
  }
}
class ScannerImpl {
  constructor(settings, reader) {
    Companion_getInstance_9();
    this.a4k_1 = settings;
    this.b4k_1 = reader;
    this.c4k_1 = ArrayDeque.qk(100);
    this.d4k_1 = ArrayDeque.qk(10);
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.e4k_1 = LinkedHashMap.hc();
    this.f4k_1 = false;
    this.g4k_1 = 0;
    this.h4k_1 = null;
    this.i4k_1 = 0;
    this.j4k_1 = -1;
    this.k4k_1 = true;
    fetchStreamStart(this);
  }
  a4h(choice) {
    while (needMoreTokens(this)) {
      fetchMoreTokens(this);
    }
    if (!this.c4k_1.h1()) {
      return this.c4k_1.f1(0).s4h().equals(choice);
    }
    return false;
  }
  e4i(choices) {
    while (needMoreTokens(this)) {
      fetchMoreTokens(this);
    }
    var tmp0_safe_receiver = this.c4k_1.tk();
    var firstTokenId = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.s4h();
    var tmp;
    if (!(firstTokenId == null)) {
      var tmp_0;
      // Inline function 'kotlin.collections.isEmpty' call
      if (choices.length === 0) {
        tmp_0 = true;
      } else {
        tmp_0 = contains_0(choices, firstTokenId);
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  r4h() {
    while (needMoreTokens(this)) {
      fetchMoreTokens(this);
    }
    return this.c4k_1.sk();
  }
  z() {
    return this.e4i([]);
  }
  a1() {
    this.i4k_1 = this.i4k_1 + 1 | 0;
    var tmp0_elvis_lhs = this.c4k_1.xk();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw NoSuchElementException.p('No more Tokens found.');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  f4i() {
    return this.b4k_1.f4i();
  }
}
class Clip {
  constructor(increment) {
    this.u4l_1 = increment;
  }
  j4l() {
    return _Clip___get_increment__impl__6zmssn(this.u4l_1);
  }
  n4l() {
    return _Clip___get_addExistingFinalLineBreak__impl__v4gbjp(this.u4l_1);
  }
  o4l() {
    return _Clip___get_retainTrailingEmptyLines__impl__5r5ek5(this.u4l_1);
  }
  toString() {
    return Clip__toString_impl_8zbb0x(this.u4l_1);
  }
  hashCode() {
    return Clip__hashCode_impl_crulry(this.u4l_1);
  }
  equals(other) {
    return Clip__equals_impl_7672fy(this.u4l_1, other);
  }
}
class Strip {
  constructor(increment) {
    this.v4l_1 = increment;
  }
  j4l() {
    return _Strip___get_increment__impl__ultjnb(this.v4l_1);
  }
  n4l() {
    return _Strip___get_addExistingFinalLineBreak__impl__hh5hph(this.v4l_1);
  }
  o4l() {
    return _Strip___get_retainTrailingEmptyLines__impl__5bav0l(this.v4l_1);
  }
  toString() {
    return Strip__toString_impl_e44ikp(this.v4l_1);
  }
  hashCode() {
    return Strip__hashCode_impl_7n1e86(this.v4l_1);
  }
  equals(other) {
    return Strip__equals_impl_vbxlyi(this.v4l_1, other);
  }
}
class Keep {
  constructor(increment) {
    this.w4l_1 = increment;
  }
  j4l() {
    return _Keep___get_increment__impl__g32ff2(this.w4l_1);
  }
  n4l() {
    return _Keep___get_addExistingFinalLineBreak__impl__eevoo0(this.w4l_1);
  }
  o4l() {
    return _Keep___get_retainTrailingEmptyLines__impl__7i8cq2(this.w4l_1);
  }
  toString() {
    return Keep__toString_impl_5t9sg4(this.w4l_1);
  }
  hashCode() {
    return Keep__hashCode_impl_rkfp8z(this.w4l_1);
  }
  equals(other) {
    return Keep__equals_impl_3j9b7t(this.w4l_1, other);
  }
}
class BreakIntentHolder {
  constructor(breaks, maxIndent, endMark) {
    this.k4l_1 = breaks;
    this.l4l_1 = maxIndent;
    this.m4l_1 = endMark;
  }
}
class SimpleKey {
  constructor(tokenNumber, isRequired, index, line, column, mark) {
    this.y4k_1 = tokenNumber;
    this.z4k_1 = isRequired;
    this.a4l_1 = index;
    this.b4l_1 = line;
    this.c4l_1 = column;
    this.d4l_1 = mark;
  }
  toString() {
    return 'SimpleKey - tokenNumber=' + this.y4k_1 + ' required=' + this.z4k_1 + ' index=' + this.a4l_1 + ' line=' + this.b4l_1 + ' column=' + this.c4l_1;
  }
}
class Companion_10 {
  x4l(c) {
    return (32 <= c ? c <= 126 : false) || c === 9 || c === 10 || c === 13 || c === 133 || (160 <= c ? c <= 55295 : false) || (57344 <= c ? c <= 65533 : false) || (65536 <= c ? c <= 1114111 : false);
  }
}
class StreamReader {
  constructor(loadSettings, stream) {
    // Inline function 'kotlin.require' call
    if (!(loadSettings.g45_1 >= 4)) {
      var message = 'buffer size must be at least 4 bytes to be able to read all Unicode codepoints';
      throw IllegalArgumentException.t(toString(message));
    }
    var tmp = this;
    var tmp_0;
    if (isInterface(stream, BufferedSource)) {
      tmp_0 = stream;
    } else {
      tmp_0 = buffer(stream);
    }
    tmp.l4k_1 = tmp_0;
    this.m4k_1 = loadSettings.a45_1;
    this.n4k_1 = loadSettings.k45_1;
    this.o4k_1 = toLong(loadSettings.g45_1);
    this.p4k_1 = new Int32Array(0);
    this.q4k_1 = 0;
    this.r4k_1 = 0;
    this.s4k_1 = false;
    this.t4k_1 = 0;
    this.u4k_1 = 0;
    this.v4k_1 = 0;
    this.w4k_1 = 0;
  }
  x4k() {
    if (!this.n4k_1)
      return null;
    var tmp = this.t4k_1;
    var tmp_0 = this.v4k_1;
    var tmp_1 = this.w4k_1;
    // Inline function 'kotlin.collections.asList' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$1 = this.p4k_1;
    var tmp$ret$2 = asList(tmp$ret$1);
    return new Mark(this.m4k_1, tmp, tmp_0, tmp_1, tmp$ret$2, this.r4k_1);
  }
  e4l(length) {
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < length)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        $l$block: {
          if (!ensureEnoughData$default(this)) {
            break $l$block;
          }
          var tmp = this.p4k_1;
          var _unary__edvuaz = this.r4k_1;
          this.r4k_1 = _unary__edvuaz + 1 | 0;
          var c = tmp[_unary__edvuaz];
          moveIndices(this, 1);
          var tmp_0;
          if (Companion_getInstance_1().j47_1.x47(c)) {
            tmp_0 = true;
          } else {
            var tmp_1;
            var tmp_2;
            // Inline function 'kotlin.code' call
            var this_0 = _Char___init__impl__6a9atx(13);
            if (c === Char__toInt_impl_vasixd(this_0)) {
              tmp_2 = ensureEnoughData$default(this);
            } else {
              tmp_2 = false;
            }
            if (tmp_2) {
              var tmp_3 = this.p4k_1[this.r4k_1];
              // Inline function 'kotlin.code' call
              var this_1 = _Char___init__impl__6a9atx(10);
              tmp_1 = !(tmp_3 === Char__toInt_impl_vasixd(this_1));
            } else {
              tmp_1 = false;
            }
            tmp_0 = tmp_1;
          }
          if (tmp_0) {
            this.v4k_1 = this.v4k_1 + 1 | 0;
            this.w4k_1 = 0;
          } else {
            if (!(c === 65279)) {
              this.w4k_1 = this.w4k_1 + 1 | 0;
            }
          }
        }
      }
       while (inductionVariable < length);
  }
  f4l(length, $super) {
    length = length === VOID ? 1 : length;
    var tmp;
    if ($super === VOID) {
      this.e4l(length);
      tmp = Unit_instance;
    } else {
      tmp = $super.e4l.call(this, length);
    }
    return tmp;
  }
  l1m() {
    return ensureEnoughData$default(this) ? this.p4k_1[this.r4k_1] : 0;
  }
  h4l(index) {
    return ensureEnoughData(this, index) ? this.p4k_1[this.r4k_1 + index | 0] : 0;
  }
  g4l(length) {
    if (length === 0)
      return '';
    var stringLength = ensureEnoughData(this, length) ? length : coerceAtMost(length, this.q4k_1 - this.r4k_1 | 0);
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.xb(stringLength);
    var inductionVariable = this.r4k_1;
    var last = this.r4k_1 + stringLength | 0;
    if (inductionVariable < last)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        appendCodePoint(this_0, this.p4k_1[i]);
      }
       while (inductionVariable < last);
    return this_0.toString();
  }
  i4l(length) {
    var prefix = this.g4l(length);
    this.r4k_1 = this.r4k_1 + length | 0;
    moveIndices(this, length);
    this.w4k_1 = this.w4k_1 + length | 0;
    return prefix;
  }
  f4i() {
    this.u4k_1 = 0;
  }
}
class JsonSchema {
  constructor(scalarResolver, schemaTagConstructors) {
    scalarResolver = scalarResolver === VOID ? new JsonScalarResolver() : scalarResolver;
    schemaTagConstructors = schemaTagConstructors === VOID ? defaultSchemaTagConstructors(scalarResolver) : schemaTagConstructors;
    this.y4l_1 = scalarResolver;
    this.z4l_1 = schemaTagConstructors;
  }
}
class Token {
  constructor(startMark, endMark) {
    this.y4g_1 = startMark;
    this.z4g_1 = endMark;
  }
  toString() {
    return this.s4h().toString();
  }
}
class AliasToken extends Token {
  constructor(value, startMark, endMark) {
    super(startMark, endMark);
    this.a4i_1 = value;
  }
  s4h() {
    return ID_Alias_getInstance_0();
  }
}
class AnchorToken extends Token {
  constructor(value, startMark, endMark) {
    super(startMark, endMark);
    this.o4h_1 = value;
  }
  s4h() {
    return ID_Anchor_getInstance();
  }
}
class BlockEndToken extends Token {
  s4h() {
    return ID_BlockEnd_getInstance();
  }
}
class BlockEntryToken extends Token {
  s4h() {
    return ID_BlockEntry_getInstance();
  }
}
class BlockMappingStartToken extends Token {
  s4h() {
    return ID_BlockMappingStart_getInstance();
  }
}
class BlockSequenceStartToken extends Token {
  s4h() {
    return ID_BlockSequenceStart_getInstance();
  }
}
class CommentToken extends Token {
  constructor(commentType, value, startMark, endMark) {
    super(startMark, endMark);
    this.w4g_1 = commentType;
    this.x4g_1 = value;
  }
  s4h() {
    return ID_Comment_getInstance_0();
  }
}
class YamlDirective {
  constructor(major, minor) {
    this.e4h_1 = major;
    this.f4h_1 = minor;
  }
  tl() {
    return this.e4h_1;
  }
  ul() {
    return this.f4h_1;
  }
  toString() {
    return 'YamlDirective(major=' + this.e4h_1 + ', minor=' + this.f4h_1 + ')';
  }
  hashCode() {
    var result = this.e4h_1;
    result = imul(result, 31) + this.f4h_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof YamlDirective))
      return false;
    var tmp0_other_with_cast = other instanceof YamlDirective ? other : THROW_CCE();
    if (!(this.e4h_1 === tmp0_other_with_cast.e4h_1))
      return false;
    if (!(this.f4h_1 === tmp0_other_with_cast.f4h_1))
      return false;
    return true;
  }
}
class TagDirective {
  constructor(handle, prefix) {
    this.g4h_1 = handle;
    this.h4h_1 = prefix;
  }
  tl() {
    return this.g4h_1;
  }
  ul() {
    return this.h4h_1;
  }
  toString() {
    return 'TagDirective(handle=' + this.g4h_1 + ', prefix=' + this.h4h_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.g4h_1);
    result = imul(result, 31) + getStringHashCode(this.h4h_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof TagDirective))
      return false;
    var tmp0_other_with_cast = other instanceof TagDirective ? other : THROW_CCE();
    if (!(this.g4h_1 === tmp0_other_with_cast.g4h_1))
      return false;
    if (!(this.h4h_1 === tmp0_other_with_cast.h4h_1))
      return false;
    return true;
  }
}
class Companion_11 {
  constructor() {
    this.i4m_1 = 'YAML';
    this.j4m_1 = 'TAG';
  }
}
class DirectiveToken extends Token {
  constructor(value, startMark, endMark) {
    super(startMark, endMark);
    this.d4h_1 = value;
  }
  s4h() {
    return ID_Directive_getInstance();
  }
}
class DocumentEndToken extends Token {
  s4h() {
    return ID_DocumentEnd_getInstance_0();
  }
}
class DocumentStartToken extends Token {
  s4h() {
    return ID_DocumentStart_getInstance_0();
  }
}
class FlowEntryToken extends Token {
  s4h() {
    return ID_FlowEntry_getInstance();
  }
}
class FlowMappingEndToken extends Token {
  s4h() {
    return ID_FlowMappingEnd_getInstance();
  }
}
class FlowMappingStartToken extends Token {
  s4h() {
    return ID_FlowMappingStart_getInstance();
  }
}
class FlowSequenceEndToken extends Token {
  s4h() {
    return ID_FlowSequenceEnd_getInstance();
  }
}
class FlowSequenceStartToken extends Token {
  s4h() {
    return ID_FlowSequenceStart_getInstance();
  }
}
class KeyToken extends Token {
  s4h() {
    return ID_Key_getInstance();
  }
}
class ScalarToken extends Token {
  constructor(value, plain, startMark, endMark, style) {
    style = style === VOID ? ScalarStyle_PLAIN_getInstance() : style;
    super(startMark, endMark);
    this.v4h_1 = value;
    this.w4h_1 = plain;
    this.x4h_1 = style;
  }
  s4h() {
    return ID_Scalar_getInstance_0();
  }
  toString() {
    return this.s4h().toString() + ' plain=' + this.w4h_1 + ' style=' + this.x4h_1.toString() + ' value=' + this.v4h_1;
  }
}
class StreamEndToken extends Token {
  s4h() {
    return ID_StreamEnd_getInstance_0();
  }
}
class StreamStartToken extends Token {
  s4h() {
    return ID_StreamStart_getInstance_0();
  }
}
class TagToken extends Token {
  constructor(value, startMark, endMark) {
    super(startMark, endMark);
    this.l4h_1 = value;
  }
  s4h() {
    return ID_Tag_getInstance();
  }
}
class TagTuple {
  constructor(handle, suffix) {
    this.p4h_1 = handle;
    this.q4h_1 = suffix;
  }
}
class ID_0 extends Enum {
  constructor(name, ordinal, description) {
    super(name, ordinal);
    this.g4n_1 = description;
  }
  toString() {
    return this.g4n_1;
  }
}
class ValueToken extends Token {
  s4h() {
    return ID_Value_getInstance();
  }
}
//endregion
var Companion_instance;
function Companion_getInstance() {
  return Companion_instance;
}
function LoadSettingsBuilder$defaultList$lambda(initialCapacity) {
  return ArrayList.x(initialCapacity);
}
function LoadSettingsBuilder$defaultSet$lambda(initialCapacity) {
  return LinkedHashSet.j(initialCapacity);
}
function LoadSettingsBuilder$defaultMap$lambda(initialCapacity) {
  return LinkedHashMap.ic(initialCapacity);
}
function LoadSettingsBuilder$versionFunction$lambda(version) {
  if (!(version.z45_1 === 1))
    throw YamlVersionException.y45(version);
  return version;
}
var CommentType_BLANK_LINE_instance;
var CommentType_BLOCK_instance;
var CommentType_IN_LINE_instance;
var CommentType_entriesInitialized;
function CommentType_initEntries() {
  if (CommentType_entriesInitialized)
    return Unit_instance;
  CommentType_entriesInitialized = true;
  CommentType_BLANK_LINE_instance = new CommentType('BLANK_LINE', 0);
  CommentType_BLOCK_instance = new CommentType('BLOCK', 1);
  CommentType_IN_LINE_instance = new CommentType('IN_LINE', 2);
}
function CommentType_BLANK_LINE_getInstance() {
  CommentType_initEntries();
  return CommentType_BLANK_LINE_instance;
}
function CommentType_BLOCK_getInstance() {
  CommentType_initEntries();
  return CommentType_BLOCK_instance;
}
function CommentType_IN_LINE_getInstance() {
  CommentType_initEntries();
  return CommentType_IN_LINE_instance;
}
var Companion_instance_0;
function Companion_getInstance_0() {
  if (Companion_instance_0 === VOID)
    new Companion_0();
  return Companion_instance_0;
}
var Companion_instance_1;
function Companion_getInstance_1() {
  if (Companion_instance_1 === VOID)
    new Companion_1();
  return Companion_instance_1;
}
var FlowStyle_FLOW_instance;
var FlowStyle_BLOCK_instance;
var FlowStyle_AUTO_instance;
var FlowStyle_entriesInitialized;
function FlowStyle_initEntries() {
  if (FlowStyle_entriesInitialized)
    return Unit_instance;
  FlowStyle_entriesInitialized = true;
  FlowStyle_FLOW_instance = new FlowStyle('FLOW', 0);
  FlowStyle_BLOCK_instance = new FlowStyle('BLOCK', 1);
  FlowStyle_AUTO_instance = new FlowStyle('AUTO', 2);
}
function FlowStyle_FLOW_getInstance() {
  FlowStyle_initEntries();
  return FlowStyle_FLOW_instance;
}
function FlowStyle_BLOCK_getInstance() {
  FlowStyle_initEntries();
  return FlowStyle_BLOCK_instance;
}
var ScalarStyle_DOUBLE_QUOTED_instance;
var ScalarStyle_SINGLE_QUOTED_instance;
var ScalarStyle_LITERAL_instance;
var ScalarStyle_FOLDED_instance;
var ScalarStyle_JSON_SCALAR_STYLE_instance;
var ScalarStyle_PLAIN_instance;
var ScalarStyle_entriesInitialized;
function ScalarStyle_initEntries() {
  if (ScalarStyle_entriesInitialized)
    return Unit_instance;
  ScalarStyle_entriesInitialized = true;
  ScalarStyle_DOUBLE_QUOTED_instance = new ScalarStyle('DOUBLE_QUOTED', 0, _Char___init__impl__6a9atx(34));
  ScalarStyle_SINGLE_QUOTED_instance = new ScalarStyle('SINGLE_QUOTED', 1, _Char___init__impl__6a9atx(39));
  ScalarStyle_LITERAL_instance = new ScalarStyle('LITERAL', 2, _Char___init__impl__6a9atx(124));
  ScalarStyle_FOLDED_instance = new ScalarStyle('FOLDED', 3, _Char___init__impl__6a9atx(62));
  ScalarStyle_JSON_SCALAR_STYLE_instance = new ScalarStyle('JSON_SCALAR_STYLE', 4, _Char___init__impl__6a9atx(74));
  ScalarStyle_PLAIN_instance = new ScalarStyle('PLAIN', 5, null);
}
function ScalarStyle_DOUBLE_QUOTED_getInstance() {
  ScalarStyle_initEntries();
  return ScalarStyle_DOUBLE_QUOTED_instance;
}
function ScalarStyle_SINGLE_QUOTED_getInstance() {
  ScalarStyle_initEntries();
  return ScalarStyle_SINGLE_QUOTED_instance;
}
function ScalarStyle_LITERAL_getInstance() {
  ScalarStyle_initEntries();
  return ScalarStyle_LITERAL_instance;
}
function ScalarStyle_FOLDED_getInstance() {
  ScalarStyle_initEntries();
  return ScalarStyle_FOLDED_instance;
}
function ScalarStyle_PLAIN_getInstance() {
  ScalarStyle_initEntries();
  return ScalarStyle_PLAIN_instance;
}
function urlDecode($this, content) {
  return UrlEncoderUtil_getInstance().x44(content, false);
}
function urlEncode($this, content) {
  return UrlEncoderUtil_getInstance().y44(content, "-_.!~*'()@:$&,;=[]/", false);
}
var UriEncoder_instance;
function UriEncoder_getInstance() {
  return UriEncoder_instance;
}
var Companion_instance_2;
function Companion_getInstance_2() {
  if (Companion_instance_2 === VOID)
    new Companion_2();
  return Companion_instance_2;
}
function _get_emitComments__dxus78($this) {
  return $this.g49_1.e49_1;
}
function needMoreEvents($this) {
  if ($this.k49_1.h1()) {
    return true;
  }
  var iter = $this.k49_1.y();
  var event = iter.a1();
  $l$loop: while (event instanceof CommentEvent) {
    if (!iter.z()) {
      return true;
    }
    event = iter.a1();
  }
  var tmp0_subject = event;
  var tmp;
  if (tmp0_subject instanceof DocumentStartEvent) {
    tmp = needEvents($this, iter, 1);
  } else {
    if (tmp0_subject instanceof SequenceStartEvent) {
      tmp = needEvents($this, iter, 2);
    } else {
      if (tmp0_subject instanceof MappingStartEvent) {
        tmp = needEvents($this, iter, 3);
      } else {
        if (tmp0_subject instanceof StreamStartEvent) {
          tmp = needEvents($this, iter, 2);
        } else {
          if (tmp0_subject instanceof StreamEndEvent) {
            tmp = false;
          } else {
            tmp = _get_emitComments__dxus78($this) ? needEvents($this, iter, 1) : false;
          }
        }
      }
    }
  }
  return tmp;
}
function needEvents($this, iter, count) {
  var level = 0;
  var actualCount = 0;
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = iter;
  $l$loop: while (_iterator__ex2g4s.z()) {
    var event = _iterator__ex2g4s.a1();
    if (event instanceof CommentEvent) {
      continue $l$loop;
    }
    actualCount = actualCount + 1 | 0;
    var tmp;
    if (event instanceof DocumentStartEvent) {
      tmp = true;
    } else {
      tmp = event instanceof CollectionStartEvent;
    }
    if (tmp) {
      level = level + 1 | 0;
    } else {
      var tmp_0;
      if (event instanceof DocumentEndEvent) {
        tmp_0 = true;
      } else {
        tmp_0 = event instanceof CollectionEndEvent;
      }
      if (tmp_0) {
        level = level - 1 | 0;
      } else {
        if (event instanceof StreamEndEvent)
          level = -1;
      }
    }
    if (level < 0) {
      return false;
    }
  }
  return actualCount < count;
}
function init_it_krzeminski_snakeyaml_engine_kmp_events_CollectionEndEvent(_this__u8e3s4) {
}
var ID_Alias_instance;
var ID_Comment_instance;
var ID_DocumentEnd_instance;
var ID_DocumentStart_instance;
var ID_MappingEnd_instance;
var ID_MappingStart_instance;
var ID_Scalar_instance;
var ID_SequenceEnd_instance;
var ID_SequenceStart_instance;
var ID_StreamEnd_instance;
var ID_StreamStart_instance;
var ID_entriesInitialized;
function ID_initEntries() {
  if (ID_entriesInitialized)
    return Unit_instance;
  ID_entriesInitialized = true;
  ID_Alias_instance = new ID('Alias', 0);
  ID_Comment_instance = new ID('Comment', 1);
  ID_DocumentEnd_instance = new ID('DocumentEnd', 2);
  ID_DocumentStart_instance = new ID('DocumentStart', 3);
  ID_MappingEnd_instance = new ID('MappingEnd', 4);
  ID_MappingStart_instance = new ID('MappingStart', 5);
  ID_Scalar_instance = new ID('Scalar', 6);
  ID_SequenceEnd_instance = new ID('SequenceEnd', 7);
  ID_SequenceStart_instance = new ID('SequenceStart', 8);
  ID_StreamEnd_instance = new ID('StreamEnd', 9);
  ID_StreamStart_instance = new ID('StreamStart', 10);
}
function ID_Alias_getInstance() {
  ID_initEntries();
  return ID_Alias_instance;
}
function ID_Comment_getInstance() {
  ID_initEntries();
  return ID_Comment_instance;
}
function ID_DocumentEnd_getInstance() {
  ID_initEntries();
  return ID_DocumentEnd_instance;
}
function ID_DocumentStart_getInstance() {
  ID_initEntries();
  return ID_DocumentStart_instance;
}
function ID_MappingEnd_getInstance() {
  ID_initEntries();
  return ID_MappingEnd_instance;
}
function ID_MappingStart_getInstance() {
  ID_initEntries();
  return ID_MappingStart_instance;
}
function ID_Scalar_getInstance() {
  ID_initEntries();
  return ID_Scalar_instance;
}
function ID_SequenceEnd_getInstance() {
  ID_initEntries();
  return ID_SequenceEnd_instance;
}
function ID_SequenceStart_getInstance() {
  ID_initEntries();
  return ID_SequenceStart_instance;
}
function ID_StreamEnd_getInstance() {
  ID_initEntries();
  return ID_StreamEnd_instance;
}
function ID_StreamStart_getInstance() {
  ID_initEntries();
  return ID_StreamStart_instance;
}
function init_it_krzeminski_snakeyaml_engine_kmp_events_MappingEndEvent(_this__u8e3s4) {
}
function ScalarEvent$escapedValue$lambda(ch) {
  return Companion_getInstance_1().v47(numberToChar(ch));
}
function init_it_krzeminski_snakeyaml_engine_kmp_events_SequenceEndEvent(_this__u8e3s4) {
}
function init_it_krzeminski_snakeyaml_engine_kmp_events_StreamEndEvent(_this__u8e3s4) {
}
function init_it_krzeminski_snakeyaml_engine_kmp_events_StreamStartEvent(_this__u8e3s4) {
}
function isLineBreak($this, c) {
  return Companion_getInstance_1().k47_1.x47(c);
}
var Companion_instance_3;
function Companion_getInstance_3() {
  return Companion_instance_3;
}
function buildReadableError($this, context, contextMark, problem, problemMark) {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  if (!(context == null)) {
    // Inline function 'kotlin.text.appendLine' call
    // Inline function 'kotlin.text.appendLine' call
    this_0.tb(context).ub(_Char___init__impl__6a9atx(10));
  }
  if (!(contextMark == null)) {
    var problemIsPresent = !(problem == null) && !(problemMark == null);
    var tmp;
    var tmp_0;
    var tmp_1;
    if (!problemIsPresent) {
      tmp_1 = true;
    } else {
      tmp_1 = contextMark.r4d_1 === (problemMark == null ? null : problemMark.r4d_1);
    }
    if (tmp_1) {
      tmp_0 = true;
    } else {
      tmp_0 = !(contextMark.t4d_1 === (problemMark == null ? null : problemMark.t4d_1));
    }
    if (tmp_0) {
      tmp = true;
    } else {
      tmp = !(contextMark.u4d_1 === problemMark.u4d_1);
    }
    if (tmp) {
      // Inline function 'kotlin.text.appendLine' call
      // Inline function 'kotlin.text.appendLine' call
      this_0.sb(contextMark).ub(_Char___init__impl__6a9atx(10));
    }
  }
  if (!(problem == null)) {
    // Inline function 'kotlin.text.appendLine' call
    // Inline function 'kotlin.text.appendLine' call
    this_0.tb(problem).ub(_Char___init__impl__6a9atx(10));
  }
  if (!(problemMark == null)) {
    // Inline function 'kotlin.text.appendLine' call
    // Inline function 'kotlin.text.appendLine' call
    this_0.sb(problemMark).ub(_Char___init__impl__6a9atx(10));
  }
  return this_0.toString();
}
var Companion_instance_4;
function Companion_getInstance_4() {
  return Companion_instance_4;
}
function init_it_krzeminski_snakeyaml_engine_kmp_exceptions_YamlEngineException(_this__u8e3s4) {
  captureStack(_this__u8e3s4, _this__u8e3s4.o4d_1);
}
function appendCodePoint(_this__u8e3s4, codePoint) {
  if (Character_getInstance().u4f(codePoint)) {
    _this__u8e3s4.ub(numberToChar(codePoint));
  } else {
    _this__u8e3s4.ub(Character_getInstance().s4f(codePoint));
    _this__u8e3s4.ub(Character_getInstance().t4f(codePoint));
  }
  return _this__u8e3s4;
}
function joinCodepointsToString(_this__u8e3s4) {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  appendCodePoints(this_0, _this__u8e3s4);
  return this_0.toString();
}
function appendCodePoints(_this__u8e3s4, codePoints) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = codePoints.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    appendCodePoint(_this__u8e3s4, element);
  }
  return _this__u8e3s4;
}
function codePointAt(_this__u8e3s4, index) {
  if (!(0 <= index ? index <= (charSequenceLength(_this__u8e3s4) - 1 | 0) : false))
    throw IndexOutOfBoundsException.me('index ' + index + ' was not in range ' + get_indices(_this__u8e3s4).toString());
  var firstChar = charSequenceGet(_this__u8e3s4, index);
  if (isHighSurrogate(firstChar)) {
    var nextChar = getOrNull(_this__u8e3s4, index + 1 | 0);
    var tmp;
    var tmp_0 = nextChar;
    if ((tmp_0 == null ? null : new Char(tmp_0)) == null) {
      tmp = null;
    } else {
      tmp = isLowSurrogate(nextChar);
    }
    if (tmp === true) {
      return Character_getInstance().v4f(firstChar, nextChar);
    }
  }
  // Inline function 'kotlin.code' call
  return Char__toInt_impl_vasixd(firstChar);
}
function toCodePoints(_this__u8e3s4) {
  // Inline function 'kotlin.collections.buildList' call
  // Inline function 'kotlin.collections.buildListInternal' call
  var capacity = charSequenceLength(_this__u8e3s4);
  checkBuilderCapacity(capacity);
  // Inline function 'kotlin.apply' call
  var this_0 = ArrayList.x(capacity);
  var i = 0;
  var c = 0;
  while (i < charSequenceLength(_this__u8e3s4)) {
    var cp = codePointAt(_this__u8e3s4, i);
    this_0.l(cp);
    i = i + Character_getInstance().w4f(cp) | 0;
    c = c + 1 | 0;
  }
  return this_0.w7();
}
var Character_instance;
function Character_getInstance() {
  if (Character_instance === VOID)
    new Character();
  return Character_instance;
}
var Companion_instance_5;
function Companion_getInstance_5() {
  if (Companion_instance_5 === VOID)
    new Companion_5();
  return Companion_instance_5;
}
function produce($this) {
  if ($this.q4g_1 == null) {
    var tmp0_safe_receiver = $this.r4g_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      $this.q4g_1 = tmp0_safe_receiver.t4g();
    }
  }
}
function produceCommentEvent($this, token) {
  return CommentEvent.k4b(token.w4g_1, token.x4g_1, token.y4g_1, token.z4g_1);
}
function processDirectives($this) {
  var yamlSpecVersion = null;
  // Inline function 'kotlin.collections.mutableMapOf' call
  var tagHandles = LinkedHashMap.hc();
  $l$loop: while ($this.n4g_1.a4h(ID_Directive_getInstance())) {
    var tmp = $this.n4g_1.a1();
    var directive = tmp instanceof DirectiveToken ? tmp : THROW_CCE();
    if (directive.d4h_1 == null)
      continue $l$loop;
    var tmp0_subject = directive.d4h_1;
    if (tmp0_subject instanceof TagDirective) {
      var _destruct__k2r9zo = directive.d4h_1;
      var handle = _destruct__k2r9zo.tl();
      var prefix = _destruct__k2r9zo.ul();
      if (tagHandles.f3(handle)) {
        throw ParserException.s4e('duplicate tag handle ' + handle, directive.y4g_1);
      }
      // Inline function 'kotlin.collections.set' call
      tagHandles.k3(handle, prefix);
    } else {
      if (tmp0_subject instanceof YamlDirective) {
        if (!(yamlSpecVersion == null)) {
          throw ParserException.s4e('found duplicate YAML directive', directive.y4g_1);
        }
        var _destruct__k2r9zo_0 = directive.d4h_1;
        var major = _destruct__k2r9zo_0.tl();
        var minor = _destruct__k2r9zo_0.ul();
        yamlSpecVersion = $this.m4g_1.f45_1.z44(new SpecVersion(major, minor));
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  // Inline function 'kotlin.collections.mutableMapOf' call
  var detectedTagHandles = LinkedHashMap.hc();
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!tagHandles.h1()) {
    detectedTagHandles.m3(tagHandles);
  }
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = Companion_getInstance_6().i4h_1.l1().y();
  while (_iterator__ex2g4s.z()) {
    var _destruct__k2r9zo_1 = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var key = _destruct__k2r9zo_1.m1();
    // Inline function 'kotlin.collections.component2' call
    var value = _destruct__k2r9zo_1.n1();
    if (!tagHandles.f3(key)) {
      // Inline function 'kotlin.collections.set' call
      tagHandles.k3(key, value);
    }
  }
  $this.s4g_1 = tagHandles;
  return new VersionTagsTuple(yamlSpecVersion, detectedTagHandles);
}
function parseFlowNode($this) {
  return parseNode($this, false, false);
}
function parseBlockNodeOrIndentlessSequence($this) {
  return parseNode($this, true, true);
}
function parseNode($this, block, indentlessSequence) {
  var startMark = null;
  var endMark = null;
  var tagMark = null;
  if ($this.n4g_1.a4h(ID_Alias_getInstance_0())) {
    var tmp = $this.n4g_1.a1();
    var token = tmp instanceof AliasToken ? tmp : THROW_CCE();
    $this.r4g_1 = $this.o4g_1.yk();
    return AliasEvent.m4a(token.a4i_1, token.y4g_1, token.z4g_1);
  } else {
    var anchor;
    var tagTupleValue;
    if ($this.n4g_1.a4h(ID_Anchor_getInstance())) {
      var tmp_0 = $this.n4g_1.a1();
      var token_0 = tmp_0 instanceof AnchorToken ? tmp_0 : THROW_CCE();
      startMark = token_0.y4g_1;
      endMark = token_0.z4g_1;
      anchor = token_0.o4h_1;
      if ($this.n4g_1.a4h(ID_Tag_getInstance())) {
        var tmp_1 = $this.n4g_1.a1();
        var tagToken = tmp_1 instanceof TagToken ? tmp_1 : THROW_CCE();
        tagMark = tagToken.y4g_1;
        endMark = tagToken.z4g_1;
        tagTupleValue = tagToken.l4h_1;
      } else {
        tagTupleValue = null;
      }
    } else if ($this.n4g_1.a4h(ID_Tag_getInstance())) {
      var tmp_2 = $this.n4g_1.a1();
      var tagToken_0 = tmp_2 instanceof TagToken ? tmp_2 : THROW_CCE();
      startMark = tagToken_0.y4g_1;
      tagMark = startMark;
      endMark = tagToken_0.z4g_1;
      tagTupleValue = tagToken_0.l4h_1;
      if ($this.n4g_1.a4h(ID_Anchor_getInstance())) {
        var tmp_3 = $this.n4g_1.a1();
        var token_1 = tmp_3 instanceof AnchorToken ? tmp_3 : THROW_CCE();
        endMark = token_1.z4g_1;
        anchor = token_1.o4h_1;
      } else {
        anchor = null;
      }
    } else {
      tagTupleValue = null;
      anchor = null;
    }
    var tag;
    if (!(tagTupleValue == null)) {
      var handle = tagTupleValue.p4h_1;
      var tmp_4;
      if (!(handle == null)) {
        if (!$this.s4g_1.f3(handle)) {
          throw ParserException.s4e('found undefined tag handle ' + handle, startMark, 'while parsing a node', tagMark);
        }
        tmp_4 = plus($this.s4g_1.h3(handle), tagTupleValue.q4h_1);
      } else {
        tmp_4 = tagTupleValue.q4h_1;
      }
      tag = tmp_4;
    } else {
      tag = null;
    }
    if (startMark == null) {
      startMark = $this.n4g_1.r4h().y4g_1;
      endMark = startMark;
    }
    var implicit = tag == null;
    var tmp_5;
    if (indentlessSequence && $this.n4g_1.a4h(ID_BlockEntry_getInstance())) {
      endMark = $this.n4g_1.r4h().z4g_1;
      $this.r4g_1 = new ParseIndentlessSequenceEntryKey($this);
      tmp_5 = SequenceStartEvent.d4d(anchor, tag, implicit, FlowStyle_BLOCK_getInstance(), startMark, endMark);
    } else if ($this.n4g_1.a4h(ID_Scalar_getInstance_0())) {
      var tmp_6 = $this.n4g_1.a1();
      var token_2 = tmp_6 instanceof ScalarToken ? tmp_6 : THROW_CCE();
      endMark = token_2.z4g_1;
      var implicitValues = token_2.w4h_1 && tag == null ? new ImplicitTuple(true, false) : tag == null ? new ImplicitTuple(false, true) : new ImplicitTuple(false, false);
      $this.r4g_1 = $this.o4g_1.yk();
      tmp_5 = ScalarEvent.q4c(anchor, tag, implicitValues, token_2.v4h_1, token_2.x4h_1, startMark, endMark);
    } else if ($this.n4g_1.a4h(ID_FlowSequenceStart_getInstance())) {
      endMark = $this.n4g_1.r4h().z4g_1;
      $this.r4g_1 = new ParseFlowSequenceFirstEntry($this);
      tmp_5 = SequenceStartEvent.d4d(anchor, tag, implicit, FlowStyle_FLOW_getInstance(), startMark, endMark);
    } else if ($this.n4g_1.a4h(ID_FlowMappingStart_getInstance())) {
      endMark = $this.n4g_1.r4h().z4g_1;
      $this.r4g_1 = new ParseFlowMappingFirstKey($this);
      tmp_5 = MappingStartEvent.i4c(anchor, tag, implicit, FlowStyle_FLOW_getInstance(), startMark, endMark);
    } else if (block && $this.n4g_1.a4h(ID_BlockSequenceStart_getInstance())) {
      endMark = $this.n4g_1.r4h().y4g_1;
      $this.r4g_1 = new ParseBlockSequenceFirstEntry($this);
      tmp_5 = SequenceStartEvent.d4d(anchor, tag, implicit, FlowStyle_BLOCK_getInstance(), startMark, endMark);
    } else if (block && $this.n4g_1.a4h(ID_BlockMappingStart_getInstance())) {
      endMark = $this.n4g_1.r4h().y4g_1;
      $this.r4g_1 = new ParseBlockMappingFirstKey($this);
      tmp_5 = MappingStartEvent.i4c(anchor, tag, implicit, FlowStyle_BLOCK_getInstance(), startMark, endMark);
    } else if (!(anchor == null) || !(tag == null)) {
      $this.r4g_1 = $this.o4g_1.yk();
      var nonPlainImplicit = new ImplicitTuple(implicit, false);
      tmp_5 = ScalarEvent.q4c(anchor, tag, nonPlainImplicit, '', ScalarStyle_PLAIN_getInstance(), startMark, endMark);
    } else {
      var token_3 = $this.n4g_1.r4h();
      throw ParserException.s4e("expected the node content, but found '" + token_3.s4h().toString() + "'", startMark, 'while parsing a ' + (block ? 'block' : 'flow') + ' node', token_3.y4g_1);
    }
    return tmp_5;
  }
}
function processEmptyScalar($this, mark) {
  return ScalarEvent.q4c(null, null, new ImplicitTuple(true, false), '', ScalarStyle_PLAIN_getInstance(), mark, mark);
}
function markPop($this) {
  return $this.p4g_1.yk();
}
function markPush($this, mark) {
  return $this.p4g_1.vk(mark);
}
var Companion_instance_6;
function Companion_getInstance_6() {
  if (Companion_instance_6 === VOID)
    new Companion_6();
  return Companion_instance_6;
}
var Companion_instance_7;
function Companion_getInstance_7() {
  if (Companion_instance_7 === VOID)
    new Companion_7();
  return Companion_instance_7;
}
function BaseScalarResolver$_init_$lambda_ep9miw(_this__u8e3s4) {
  return Unit_instance;
}
var Companion_instance_8;
function Companion_getInstance_8() {
  if (Companion_instance_8 === VOID)
    new Companion_8();
  return Companion_instance_8;
}
function JsonScalarResolver$_init_$lambda_2rw3ox(_this__u8e3s4) {
  _this__u8e3s4.q4j(Companion_getInstance_5().f4g_1, Companion_getInstance_7().r4j_1, null);
  _this__u8e3s4.q4j(Companion_getInstance_5().e4g_1, Companion_getInstance_8().u4j_1, 'tf');
  _this__u8e3s4.q4j(Companion_getInstance_5().c4g_1, Companion_getInstance_8().w4j_1, '-0123456789');
  _this__u8e3s4.q4j(Companion_getInstance_5().d4g_1, Companion_getInstance_8().v4j_1, '-0123456789.');
  _this__u8e3s4.q4j(Companion_getInstance_5().f4g_1, Companion_getInstance_8().x4j_1, 'n\x00');
  _this__u8e3s4.q4j(Companion_getInstance_5().k4g_1, Companion_getInstance_7().s4j_1, '$');
  return Unit_instance;
}
function addToken($this, token) {
  $this.h4k_1 = token;
  $this.c4k_1.vk(token);
}
function addToken_0($this, index, token) {
  if (index === $this.c4k_1.nk_1) {
    $this.h4k_1 = token;
  }
  $this.c4k_1.d3(index, token);
}
function addAllTokens($this, tokens) {
  $this.h4k_1 = last(tokens);
  // Inline function 'kotlin.collections.plusAssign' call
  var this_0 = $this.c4k_1;
  addAll(this_0, tokens);
}
function isBlockContext($this) {
  return $this.g4k_1 === 0;
}
function isFlowContext($this) {
  return !isBlockContext($this);
}
function needMoreTokens($this) {
  if ($this.f4k_1)
    return false;
  if ($this.c4k_1.h1())
    return true;
  stalePossibleSimpleKeys($this);
  return nextPossibleSimpleKey($this) === $this.i4k_1;
}
function fetchMoreTokens($this) {
  if ($this.b4k_1.u4k_1 > $this.a4k_1.o45_1) {
    throw YamlEngineException.p4d('The incoming YAML document exceeds the limit: ' + $this.a4k_1.o45_1 + ' code points.');
  }
  scanToNextToken($this);
  stalePossibleSimpleKeys($this);
  unwindIndent($this, $this.b4k_1.w4k_1);
  var c = $this.b4k_1.l1m();
  if (c === 0) {
    fetchStreamEnd($this);
    return Unit_instance;
  }
  var tmp0_subject = numberToChar(c);
  if (tmp0_subject === _Char___init__impl__6a9atx(37)) {
    if (checkDirective($this)) {
      fetchDirective($this);
      return Unit_instance;
    }
  } else if (tmp0_subject === _Char___init__impl__6a9atx(45)) {
    if (checkDocumentStart($this)) {
      fetchDocumentStart($this);
      return Unit_instance;
    } else if (checkBlockEntry($this)) {
      fetchBlockEntry($this);
      return Unit_instance;
    }
  } else if (tmp0_subject === _Char___init__impl__6a9atx(46)) {
    if (checkDocumentEnd($this)) {
      fetchDocumentEnd($this);
      return Unit_instance;
    }
  } else if (tmp0_subject === _Char___init__impl__6a9atx(91)) {
    fetchFlowSequenceStart($this);
    return Unit_instance;
  } else if (tmp0_subject === _Char___init__impl__6a9atx(123)) {
    fetchFlowMappingStart($this);
    return Unit_instance;
  } else if (tmp0_subject === _Char___init__impl__6a9atx(93)) {
    fetchFlowSequenceEnd($this);
    return Unit_instance;
  } else if (tmp0_subject === _Char___init__impl__6a9atx(125)) {
    fetchFlowMappingEnd($this);
    return Unit_instance;
  } else if (tmp0_subject === _Char___init__impl__6a9atx(44)) {
    fetchFlowEntry($this);
    return Unit_instance;
  } else if (tmp0_subject === _Char___init__impl__6a9atx(63)) {
    if (checkKey($this)) {
      fetchKey($this);
      return Unit_instance;
    }
  } else if (tmp0_subject === _Char___init__impl__6a9atx(58)) {
    if (checkValue($this)) {
      fetchValue($this);
      return Unit_instance;
    }
  } else if (tmp0_subject === _Char___init__impl__6a9atx(42)) {
    fetchAlias($this);
    return Unit_instance;
  } else if (tmp0_subject === _Char___init__impl__6a9atx(38)) {
    fetchAnchor($this);
    return Unit_instance;
  } else if (tmp0_subject === _Char___init__impl__6a9atx(33)) {
    fetchTag($this);
    return Unit_instance;
  } else if (tmp0_subject === _Char___init__impl__6a9atx(124)) {
    if (isBlockContext($this)) {
      fetchLiteral($this);
      return Unit_instance;
    }
  } else if (tmp0_subject === _Char___init__impl__6a9atx(62)) {
    if (isBlockContext($this)) {
      fetchFolded($this);
      return Unit_instance;
    }
  } else if (tmp0_subject === _Char___init__impl__6a9atx(39)) {
    fetchSingle($this);
    return Unit_instance;
  } else if (tmp0_subject === _Char___init__impl__6a9atx(34)) {
    fetchDouble($this);
    return Unit_instance;
  }
  if (checkPlain($this)) {
    fetchPlain($this);
    return Unit_instance;
  }
  var chRepresentation = Companion_getInstance_1().v47(first(Character_getInstance().g4f(c)));
  // Inline function 'kotlin.code' call
  var this_0 = _Char___init__impl__6a9atx(9);
  if (c === Char__toInt_impl_vasixd(this_0)) {
    chRepresentation = chRepresentation + '(TAB)';
  }
  var tmp1_problem = "found character '" + chRepresentation + "' that cannot start any token. (Do not use " + chRepresentation + ' for indentation)';
  var tmp2_problemMark = $this.b4k_1.x4k();
  throw ScannerException.q4f(tmp1_problem, tmp2_problemMark, 'while scanning for the next token', null);
}
function nextPossibleSimpleKey($this) {
  var tmp0_safe_receiver = firstOrNull($this.e4k_1.j3());
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.y4k_1;
}
function stalePossibleSimpleKeys($this) {
  // Inline function 'kotlin.collections.iterator' call
  var iterator = $this.e4k_1.l1().y();
  while (iterator.z()) {
    var key = iterator.a1().n1();
    if (!(key.b4l_1 === $this.b4k_1.v4k_1) || ($this.b4k_1.t4k_1 - key.a4l_1 | 0) > 1024) {
      if (key.z4k_1) {
        var tmp0_contextMark = key.d4l_1;
        var tmp1_problemMark = $this.b4k_1.x4k();
        throw ScannerException.q4f("could not find expected ':'", tmp1_problemMark, 'while scanning a simple key', tmp0_contextMark);
      }
      iterator.e6();
    }
  }
}
function savePossibleSimpleKey($this) {
  var required = isBlockContext($this) && $this.j4k_1 === $this.b4k_1.w4k_1;
  if (!$this.k4k_1 && required) {
    throw YamlEngineException.p4d('A simple key is required only if it is the first token in the current line');
  }
  if ($this.k4k_1) {
    removePossibleSimpleKey($this);
    var tokenNumber = $this.i4k_1 + $this.c4k_1.nk_1 | 0;
    var key = new SimpleKey(tokenNumber, required, $this.b4k_1.t4k_1, $this.b4k_1.v4k_1, $this.b4k_1.w4k_1, $this.b4k_1.x4k());
    var tmp0 = $this.e4k_1;
    // Inline function 'kotlin.collections.set' call
    var key_0 = $this.g4k_1;
    tmp0.k3(key_0, key);
  }
}
function removePossibleSimpleKey($this) {
  var key = $this.e4k_1.l3($this.g4k_1);
  if (!(key == null) && key.z4k_1) {
    var tmp0_contextMark = key.d4l_1;
    var tmp1_problemMark = $this.b4k_1.x4k();
    throw ScannerException.q4f("could not find expected ':'", tmp1_problemMark, 'while scanning a simple key', tmp0_contextMark);
  }
}
function unwindIndent($this, col) {
  if (isFlowContext($this)) {
    return Unit_instance;
  }
  while ($this.j4k_1 > col) {
    var mark = $this.b4k_1.x4k();
    $this.j4k_1 = $this.d4k_1.yk();
    addToken($this, new BlockEndToken(mark, mark));
  }
}
function addIndent($this, column) {
  if ($this.j4k_1 >= column)
    return false;
  $this.d4k_1.vk($this.j4k_1);
  $this.j4k_1 = column;
  return true;
}
function fetchStreamStart($this) {
  var mark = $this.b4k_1.x4k();
  var token = new StreamStartToken(mark, mark);
  addToken($this, token);
}
function fetchStreamEnd($this) {
  unwindIndent($this, -1);
  removePossibleSimpleKey($this);
  $this.k4k_1 = false;
  $this.e4k_1.b3();
  var mark = $this.b4k_1.x4k();
  var token = new StreamEndToken(mark, mark);
  addToken($this, token);
  $this.f4k_1 = true;
}
function fetchDirective($this) {
  unwindIndent($this, -1);
  removePossibleSimpleKey($this);
  $this.k4k_1 = false;
  var tok = scanDirective($this);
  addAllTokens($this, tok);
}
function fetchDocumentStart($this) {
  return fetchDocumentIndicator($this, true);
}
function fetchDocumentEnd($this) {
  return fetchDocumentIndicator($this, false);
}
function fetchDocumentIndicator($this, isDocumentStart) {
  unwindIndent($this, -1);
  removePossibleSimpleKey($this);
  $this.k4k_1 = false;
  var startMark = $this.b4k_1.x4k();
  $this.b4k_1.e4l(3);
  var endMark = $this.b4k_1.x4k();
  var tmp;
  if (isDocumentStart) {
    tmp = new DocumentStartToken(startMark, endMark);
  } else {
    tmp = new DocumentEndToken(startMark, endMark);
  }
  var token = tmp;
  addToken($this, token);
}
function fetchFlowSequenceStart($this) {
  return fetchFlowCollectionStart($this, false);
}
function fetchFlowMappingStart($this) {
  return fetchFlowCollectionStart($this, true);
}
function fetchFlowCollectionStart($this, isMappingStart) {
  savePossibleSimpleKey($this);
  $this.g4k_1 = $this.g4k_1 + 1 | 0;
  $this.k4k_1 = true;
  var startMark = $this.b4k_1.x4k();
  $this.b4k_1.e4l(1);
  var endMark = $this.b4k_1.x4k();
  var tmp;
  if (isMappingStart) {
    tmp = new FlowMappingStartToken(startMark, endMark);
  } else {
    tmp = new FlowSequenceStartToken(startMark, endMark);
  }
  var token = tmp;
  addToken($this, token);
}
function fetchFlowSequenceEnd($this) {
  return fetchFlowCollectionEnd($this, false);
}
function fetchFlowMappingEnd($this) {
  return fetchFlowCollectionEnd($this, true);
}
function fetchFlowCollectionEnd($this, isMappingEnd) {
  removePossibleSimpleKey($this);
  $this.g4k_1 = $this.g4k_1 - 1 | 0;
  $this.k4k_1 = false;
  var startMark = $this.b4k_1.x4k();
  $this.b4k_1.f4l();
  var endMark = $this.b4k_1.x4k();
  var tmp;
  if (isMappingEnd) {
    tmp = new FlowMappingEndToken(startMark, endMark);
  } else {
    tmp = new FlowSequenceEndToken(startMark, endMark);
  }
  var token = tmp;
  addToken($this, token);
}
function fetchFlowEntry($this) {
  $this.k4k_1 = true;
  removePossibleSimpleKey($this);
  var startMark = $this.b4k_1.x4k();
  $this.b4k_1.f4l();
  var endMark = $this.b4k_1.x4k();
  var token = new FlowEntryToken(startMark, endMark);
  addToken($this, token);
}
function fetchBlockEntry($this) {
  if (isBlockContext($this)) {
    if (!$this.k4k_1) {
      throw ScannerException.q4f('', null, 'sequence entries are not allowed here', $this.b4k_1.x4k());
    }
    if (addIndent($this, $this.b4k_1.w4k_1)) {
      var mark = $this.b4k_1.x4k();
      addToken($this, new BlockSequenceStartToken(mark, mark));
    }
  }
  $this.k4k_1 = true;
  removePossibleSimpleKey($this);
  var startMark = $this.b4k_1.x4k();
  $this.b4k_1.f4l();
  var endMark = $this.b4k_1.x4k();
  var token = new BlockEntryToken(startMark, endMark);
  addToken($this, token);
}
function fetchKey($this) {
  if (isBlockContext($this)) {
    if (!$this.k4k_1) {
      throw ScannerException.q4f('mapping keys are not allowed here', $this.b4k_1.x4k());
    }
    if (addIndent($this, $this.b4k_1.w4k_1)) {
      var mark = $this.b4k_1.x4k();
      addToken($this, new BlockMappingStartToken(mark, mark));
    }
  }
  $this.k4k_1 = isBlockContext($this);
  removePossibleSimpleKey($this);
  var startMark = $this.b4k_1.x4k();
  $this.b4k_1.f4l();
  var endMark = $this.b4k_1.x4k();
  var token = new KeyToken(startMark, endMark);
  addToken($this, token);
}
function fetchValue($this) {
  var key = $this.e4k_1.l3($this.g4k_1);
  if (!(key == null)) {
    addToken_0($this, key.y4k_1 - $this.i4k_1 | 0, new KeyToken(key.d4l_1, key.d4l_1));
    if (isBlockContext($this) && addIndent($this, key.c4l_1)) {
      addToken_0($this, key.y4k_1 - $this.i4k_1 | 0, new BlockMappingStartToken(key.d4l_1, key.d4l_1));
    }
    $this.k4k_1 = false;
  } else {
    if (isBlockContext($this)) {
      if (!$this.k4k_1) {
        throw ScannerException.q4f('mapping values are not allowed here', $this.b4k_1.x4k());
      }
    }
    if (isBlockContext($this) && addIndent($this, $this.b4k_1.w4k_1)) {
      var mark = $this.b4k_1.x4k();
      addToken($this, new BlockMappingStartToken(mark, mark));
    }
    $this.k4k_1 = isBlockContext($this);
    removePossibleSimpleKey($this);
  }
  var startMark = $this.b4k_1.x4k();
  $this.b4k_1.f4l();
  var endMark = $this.b4k_1.x4k();
  var token = new ValueToken(startMark, endMark);
  addToken($this, token);
}
function fetchAlias($this) {
  savePossibleSimpleKey($this);
  $this.k4k_1 = false;
  var tok = scanAnchor($this, false);
  addToken($this, tok);
}
function fetchAnchor($this) {
  savePossibleSimpleKey($this);
  $this.k4k_1 = false;
  var tok = scanAnchor($this, true);
  addToken($this, tok);
}
function fetchTag($this) {
  savePossibleSimpleKey($this);
  $this.k4k_1 = false;
  var token = scanTag($this);
  addToken($this, token);
}
function fetchLiteral($this) {
  return fetchBlockScalar($this, ScalarStyle_LITERAL_getInstance());
}
function fetchFolded($this) {
  return fetchBlockScalar($this, ScalarStyle_FOLDED_getInstance());
}
function fetchBlockScalar($this, style) {
  $this.k4k_1 = true;
  removePossibleSimpleKey($this);
  var tok = scanBlockScalar($this, style);
  addAllTokens($this, tok);
}
function fetchSingle($this) {
  return fetchFlowScalar($this, ScalarStyle_SINGLE_QUOTED_getInstance());
}
function fetchDouble($this) {
  return fetchFlowScalar($this, ScalarStyle_DOUBLE_QUOTED_getInstance());
}
function fetchFlowScalar($this, style) {
  savePossibleSimpleKey($this);
  $this.k4k_1 = false;
  var tok = scanFlowScalar($this, ensureNotNull(style));
  addToken($this, tok);
}
function fetchPlain($this) {
  savePossibleSimpleKey($this);
  $this.k4k_1 = false;
  var tok = scanPlain($this);
  addToken($this, tok);
}
function checkDirective($this) {
  return $this.b4k_1.w4k_1 === 0;
}
function checkDocumentStart($this) {
  return checkDirective($this) && '---' === $this.b4k_1.g4l(3) && Companion_getInstance_1().m47_1.x47($this.b4k_1.h4l(3));
}
function checkDocumentEnd($this) {
  return checkDirective($this) && '...' === $this.b4k_1.g4l(3) && Companion_getInstance_1().m47_1.x47($this.b4k_1.h4l(3));
}
function checkBlockEntry($this) {
  return Companion_getInstance_1().m47_1.x47($this.b4k_1.h4l(1));
}
function checkKey($this) {
  return Companion_getInstance_1().m47_1.x47($this.b4k_1.h4l(1));
}
function checkValue($this) {
  return isFlowContext($this) || Companion_getInstance_1().m47_1.x47($this.b4k_1.h4l(1));
}
function checkPlain($this) {
  var c = $this.b4k_1.l1m();
  var notForbidden = Companion_getInstance_1().m47_1.a48(c, '-?:,[]{}#&*!|>\'"%@`');
  var tmp;
  if (notForbidden) {
    tmp = true;
  } else {
    var tmp_0;
    if (isBlockContext($this)) {
      tmp_0 = (Companion_getInstance_1().m47_1.y47($this.b4k_1.h4l(1)) && contains('-?:', numberToChar(c)));
    } else {
      tmp_0 = (Companion_getInstance_1().m47_1.a48($this.b4k_1.h4l(1), ',]') && contains('-?', numberToChar(c)));
    }
    tmp = tmp_0;
  }
  return tmp;
}
function scanToNextToken($this) {
  var found = false;
  var inlineStartColumn = -1;
  while (!found) {
    var startMark = $this.b4k_1.x4k();
    var columnBeforeComment = $this.b4k_1.w4k_1;
    var commentSeen = false;
    var ff = 0;
    $l$loop: while (true) {
      var tmp = $this.b4k_1.h4l(ff);
      // Inline function 'kotlin.code' call
      var this_0 = _Char___init__impl__6a9atx(32);
      if (!(tmp === Char__toInt_impl_vasixd(this_0))) {
        break $l$loop;
      }
      ff = ff + 1 | 0;
    }
    if (ff > 0) {
      $this.b4k_1.e4l(ff);
    }
    var tmp_0 = $this.b4k_1.l1m();
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(35);
    if (tmp_0 === Char__toInt_impl_vasixd(this_1)) {
      commentSeen = true;
      var type;
      var tmp_1;
      if (!(columnBeforeComment === 0)) {
        var tmp_2;
        if (!($this.h4k_1 == null)) {
          var tmp0_safe_receiver = $this.h4k_1;
          tmp_2 = equals(tmp0_safe_receiver == null ? null : tmp0_safe_receiver.s4h(), ID_BlockEntry_getInstance());
        } else {
          tmp_2 = false;
        }
        tmp_1 = !tmp_2;
      } else {
        tmp_1 = false;
      }
      if (tmp_1) {
        type = CommentType_IN_LINE_getInstance();
        inlineStartColumn = $this.b4k_1.w4k_1;
      } else {
        if (inlineStartColumn === $this.b4k_1.w4k_1) {
          type = CommentType_IN_LINE_getInstance();
        } else {
          inlineStartColumn = -1;
          type = CommentType_BLOCK_getInstance();
        }
      }
      var token = scanComment($this, type);
      if ($this.a4k_1.n45_1) {
        addToken($this, token);
      }
    }
    var breaksOpt = scanLineBreak($this);
    if (!(breaksOpt == null)) {
      if ($this.a4k_1.n45_1 && !commentSeen) {
        if (columnBeforeComment === 0) {
          addToken($this, new CommentToken(CommentType_BLANK_LINE_getInstance(), breaksOpt, startMark, $this.b4k_1.x4k()));
        }
      }
      if (isBlockContext($this)) {
        $this.k4k_1 = true;
      }
    } else {
      found = true;
    }
  }
}
function scanComment($this, type) {
  var startMark = $this.b4k_1.x4k();
  $this.b4k_1.f4l();
  var length = 0;
  while (Companion_getInstance_1().k47_1.y47($this.b4k_1.h4l(length))) {
    length = length + 1 | 0;
  }
  var value = $this.b4k_1.i4l(length);
  var endMark = $this.b4k_1.x4k();
  return new CommentToken(type, value, startMark, endMark);
}
function scanDirective($this) {
  var startMark = $this.b4k_1.x4k();
  var endMark;
  $this.b4k_1.f4l();
  var name = scanDirectiveName($this, startMark);
  var value;
  switch (name) {
    case 'YAML':
      value = scanYamlDirectiveValue($this, startMark);
      endMark = $this.b4k_1.x4k();
      break;
    case 'TAG':
      value = scanTagDirectiveValue($this, startMark);
      endMark = $this.b4k_1.x4k();
      break;
    default:
      endMark = $this.b4k_1.x4k();
      var ff = 0;
      while (Companion_getInstance_1().k47_1.y47($this.b4k_1.h4l(ff))) {
        ff = ff + 1 | 0;
      }

      if (ff > 0) {
        $this.b4k_1.e4l(ff);
      }

      value = null;
      break;
  }
  var commentToken = scanDirectiveIgnoredLine($this, startMark);
  var token = new DirectiveToken(value, startMark, endMark);
  return makeTokenList($this, [token, commentToken]);
}
function scanDirectiveName($this, startMark) {
  var length = 0;
  var c = $this.b4k_1.h4l(length);
  while (Companion_getInstance_1().q47_1.x47(c)) {
    length = length + 1 | 0;
    c = $this.b4k_1.h4l(length);
  }
  if (length === 0) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a directive', startMark, 'expected alphabetic or numeric character, but found ' + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  var value = $this.b4k_1.i4l(length);
  c = $this.b4k_1.l1m();
  if (Companion_getInstance_1().l47_1.y47(c)) {
    var s_0 = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a directive', startMark, 'expected alphabetic or numeric character, but found ' + s_0 + '(' + c + ')', $this.b4k_1.x4k());
  }
  return value;
}
function scanYamlDirectiveValue($this, startMark) {
  $l$loop: while (true) {
    var tmp = $this.b4k_1.l1m();
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(32);
    if (!(tmp === Char__toInt_impl_vasixd(this_0))) {
      break $l$loop;
    }
    $this.b4k_1.f4l();
  }
  var major = scanYamlDirectiveNumber($this, startMark);
  var c = $this.b4k_1.l1m();
  var tmp_0 = c;
  // Inline function 'kotlin.code' call
  var this_1 = _Char___init__impl__6a9atx(46);
  if (!(tmp_0 === Char__toInt_impl_vasixd(this_1))) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a directive', startMark, "expected a digit or '.', but found " + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  $this.b4k_1.f4l();
  var minor = scanYamlDirectiveNumber($this, startMark);
  c = $this.b4k_1.l1m();
  if (Companion_getInstance_1().l47_1.y47(c)) {
    var s_0 = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a directive', startMark, "expected a digit or ' ', but found " + s_0 + '(' + c + ')', $this.b4k_1.x4k());
  }
  return new YamlDirective(major, minor);
}
function scanYamlDirectiveNumber($this, startMark) {
  var c = $this.b4k_1.l1m();
  if (!isDigit(numberToChar(c))) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a directive', startMark, 'expected a digit, but found ' + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  var length = 0;
  while (isDigit(numberToChar($this.b4k_1.h4l(length)))) {
    length = length + 1 | 0;
  }
  var number = $this.b4k_1.i4l(length);
  if (length > 3) {
    throw ScannerException.q4f('while scanning a YAML directive', startMark, 'found a number which cannot represent a valid version: ' + number, $this.b4k_1.x4k());
  }
  return toInt(number);
}
function scanTagDirectiveValue($this, startMark) {
  $l$loop: while (true) {
    var tmp = $this.b4k_1.l1m();
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(32);
    if (!(tmp === Char__toInt_impl_vasixd(this_0))) {
      break $l$loop;
    }
    $this.b4k_1.f4l();
  }
  var handle = scanTagDirectiveHandle($this, startMark);
  $l$loop_0: while (true) {
    var tmp_0 = $this.b4k_1.l1m();
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(32);
    if (!(tmp_0 === Char__toInt_impl_vasixd(this_1))) {
      break $l$loop_0;
    }
    $this.b4k_1.f4l();
  }
  var prefix = scanTagDirectivePrefix($this, startMark);
  return new TagDirective(handle, prefix);
}
function scanTagDirectiveHandle($this, startMark) {
  var value = scanTagHandle($this, 'directive', startMark);
  var c = $this.b4k_1.l1m();
  // Inline function 'kotlin.code' call
  var this_0 = _Char___init__impl__6a9atx(32);
  if (!(c === Char__toInt_impl_vasixd(this_0))) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a directive', startMark, "expected ' ', but found " + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  return value;
}
function scanTagDirectivePrefix($this, startMark) {
  var value = scanTagUri($this, 'directive', Companion_getInstance_1().o47_1, startMark);
  var c = $this.b4k_1.l1m();
  if (Companion_getInstance_1().l47_1.y47(c)) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a directive', startMark, "expected ' ', but found " + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  return value;
}
function scanDirectiveIgnoredLine($this, startMark) {
  $l$loop: while (true) {
    var tmp = $this.b4k_1.l1m();
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(32);
    if (!(tmp === Char__toInt_impl_vasixd(this_0))) {
      break $l$loop;
    }
    $this.b4k_1.f4l();
  }
  var commentToken = null;
  var tmp_0 = $this.b4k_1.l1m();
  // Inline function 'kotlin.code' call
  var this_1 = _Char___init__impl__6a9atx(35);
  if (tmp_0 === Char__toInt_impl_vasixd(this_1)) {
    var comment = scanComment($this, CommentType_IN_LINE_getInstance());
    if ($this.a4k_1.n45_1) {
      commentToken = comment;
    }
  }
  var c = $this.b4k_1.l1m();
  if (scanLineBreak($this) == null && !(c === 0)) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a directive', startMark, 'expected a comment or a line break, but found ' + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  return commentToken;
}
function scanAnchor($this, isAnchor) {
  var startMark = $this.b4k_1.x4k();
  var indicator = $this.b4k_1.l1m();
  var tmp;
  // Inline function 'kotlin.code' call
  var this_0 = _Char___init__impl__6a9atx(42);
  if (indicator === Char__toInt_impl_vasixd(this_0)) {
    tmp = 'alias';
  } else {
    tmp = 'anchor';
  }
  var name = tmp;
  $this.b4k_1.f4l();
  var length = 0;
  var c = $this.b4k_1.h4l(length);
  while (Companion_getInstance_1().m47_1.a48(c, ',[]{}/.*&')) {
    length = length + 1 | 0;
    c = $this.b4k_1.h4l(length);
  }
  if (length === 0) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning an ' + name, startMark, 'unexpected character found ' + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  var value = $this.b4k_1.i4l(length);
  c = $this.b4k_1.l1m();
  if (Companion_getInstance_1().m47_1.a48(c, '?:,]}%@`')) {
    var s_0 = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning an ' + name, startMark, 'unexpected character found ' + s_0 + '(' + c + ')', $this.b4k_1.x4k());
  }
  var endMark = $this.b4k_1.x4k();
  var tmp_0;
  if (isAnchor) {
    tmp_0 = new AnchorToken(new Anchor(value), startMark, endMark);
  } else {
    tmp_0 = new AliasToken(new Anchor(value), startMark, endMark);
  }
  return tmp_0;
}
function scanTag($this) {
  var startMark = $this.b4k_1.x4k();
  var c = $this.b4k_1.h4l(1);
  var handle;
  var suffix;
  var tmp = c;
  // Inline function 'kotlin.code' call
  var this_0 = _Char___init__impl__6a9atx(60);
  if (tmp === Char__toInt_impl_vasixd(this_0)) {
    $this.b4k_1.e4l(2);
    suffix = scanTagUri($this, 'tag', Companion_getInstance_1().o47_1, startMark);
    c = $this.b4k_1.l1m();
    var tmp_0 = c;
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(62);
    if (!(tmp_0 === Char__toInt_impl_vasixd(this_1))) {
      var s = concatToString(Character_getInstance().g4f(c));
      throw ScannerException.q4f('while scanning a tag', startMark, "expected '>', but found '" + s + "' (" + c + ')', $this.b4k_1.x4k());
    }
    handle = null;
    $this.b4k_1.f4l();
  } else {
    if (Companion_getInstance_1().m47_1.x47(c)) {
      suffix = '!';
      handle = null;
      $this.b4k_1.f4l();
    } else {
      var length = 1;
      var useHandle = false;
      $l$loop: while (Companion_getInstance_1().l47_1.y47(c)) {
        var tmp_1 = c;
        // Inline function 'kotlin.code' call
        var this_2 = _Char___init__impl__6a9atx(33);
        if (tmp_1 === Char__toInt_impl_vasixd(this_2)) {
          useHandle = true;
          break $l$loop;
        }
        length = length + 1 | 0;
        c = $this.b4k_1.h4l(length);
      }
      if (useHandle) {
        handle = scanTagHandle($this, 'tag', startMark);
      } else {
        handle = '!';
        $this.b4k_1.f4l();
      }
      suffix = scanTagUri($this, 'tag', Companion_getInstance_1().p47_1, startMark);
    }
  }
  c = $this.b4k_1.l1m();
  if (Companion_getInstance_1().l47_1.y47(c)) {
    var s_0 = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a tag', startMark, "expected ' ', but found '" + s_0 + "' (" + c + ')', $this.b4k_1.x4k());
  }
  var value = new TagTuple(handle, suffix);
  var endMark = $this.b4k_1.x4k();
  return new TagToken(value, startMark, endMark);
}
function scanBlockScalar($this, style) {
  var stringBuilder = StringBuilder.v();
  var startMark = $this.b4k_1.x4k();
  $this.b4k_1.f4l();
  var chomping = scanBlockScalarIndicators($this, startMark);
  var commentToken = scanBlockScalarIgnoredLine($this, startMark);
  var minIndent = coerceAtLeast($this.j4k_1 + 1 | 0, 1);
  var breaks;
  var maxIndent;
  var blockIndent;
  var endMark;
  var chompingIncrement = chomping.j4l();
  if (chompingIncrement == null) {
    var brme = scanBlockScalarIndentation($this);
    breaks = brme.k4l_1;
    maxIndent = brme.l4l_1;
    endMark = brme.m4l_1;
    blockIndent = coerceAtLeast(minIndent, maxIndent);
  } else {
    blockIndent = (minIndent + chompingIncrement | 0) - 1 | 0;
    var brme_0 = scanBlockScalarBreaks($this, blockIndent);
    breaks = brme_0.k4l_1;
    endMark = brme_0.m4l_1;
  }
  var lineBreak = null;
  if ($this.b4k_1.w4k_1 < blockIndent && !($this.j4k_1 === $this.b4k_1.w4k_1)) {
    throw ScannerException.q4f('while scanning a block scalar', startMark, ' the leading empty lines contain more spaces (' + blockIndent + ') than the first non-empty line.', $this.b4k_1.x4k());
  }
  $l$loop: while ($this.b4k_1.w4k_1 === blockIndent && !($this.b4k_1.l1m() === 0)) {
    stringBuilder.tb(breaks);
    var leadingNonSpace = !contains(' \t', numberToChar($this.b4k_1.l1m()));
    var length = 0;
    while (Companion_getInstance_1().k47_1.y47($this.b4k_1.h4l(length))) {
      length = length + 1 | 0;
    }
    stringBuilder.tb($this.b4k_1.i4l(length));
    lineBreak = scanLineBreak($this);
    var brme_1 = scanBlockScalarBreaks($this, blockIndent);
    breaks = brme_1.k4l_1;
    endMark = brme_1.m4l_1;
    if ($this.b4k_1.w4k_1 === blockIndent && !($this.b4k_1.l1m() === 0)) {
      if (style.equals(ScalarStyle_FOLDED_getInstance()) && '\n' === lineBreak && leadingNonSpace && !contains(' \t', numberToChar($this.b4k_1.l1m()))) {
        // Inline function 'kotlin.text.isEmpty' call
        var this_0 = breaks;
        if (charSequenceLength(this_0) === 0) {
          stringBuilder.ub(_Char___init__impl__6a9atx(32));
        }
      } else {
        var tmp0_elvis_lhs = lineBreak;
        stringBuilder.tb(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs);
      }
    } else {
      break $l$loop;
    }
  }
  if (chomping.n4l()) {
    var tmp1_elvis_lhs = lineBreak;
    stringBuilder.tb(tmp1_elvis_lhs == null ? '' : tmp1_elvis_lhs);
  }
  if (chomping.o4l()) {
    stringBuilder.tb(breaks);
  }
  var scalarToken = new ScalarToken(stringBuilder.toString(), false, startMark, endMark, style);
  return makeTokenList($this, [commentToken, scalarToken]);
}
function scanBlockScalarIndicators($this, startMark) {
  var indicator;
  var increment;
  var c = $this.b4k_1.l1m();
  var tmp;
  var tmp_0 = c;
  // Inline function 'kotlin.code' call
  var this_0 = _Char___init__impl__6a9atx(45);
  if (tmp_0 === Char__toInt_impl_vasixd(this_0)) {
    tmp = true;
  } else {
    var tmp_1 = c;
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(43);
    tmp = tmp_1 === Char__toInt_impl_vasixd(this_1);
  }
  if (tmp) {
    indicator = c;
    $this.b4k_1.f4l();
    c = $this.b4k_1.l1m();
    if (isDigit(numberToChar(c))) {
      var incr = toInt(concatToString(Character_getInstance().g4f(c)));
      if (incr === 0) {
        throw ScannerException.q4f('while scanning a block scalar', startMark, 'expected indentation indicator in the range 1-9, but found 0', $this.b4k_1.x4k());
      }
      increment = incr;
      $this.b4k_1.f4l();
    } else {
      increment = null;
    }
  } else {
    if (isDigit(numberToChar(c))) {
      var incr_0 = toInt(concatToString(Character_getInstance().g4f(c)));
      if (incr_0 === 0) {
        throw ScannerException.q4f('while scanning a block scalar', startMark, 'expected indentation indicator in the range 1-9, but found 0', $this.b4k_1.x4k());
      }
      increment = incr_0;
      $this.b4k_1.f4l();
      c = $this.b4k_1.l1m();
      var tmp_2;
      var tmp_3 = c;
      // Inline function 'kotlin.code' call
      var this_2 = _Char___init__impl__6a9atx(45);
      if (tmp_3 === Char__toInt_impl_vasixd(this_2)) {
        tmp_2 = true;
      } else {
        var tmp_4 = c;
        // Inline function 'kotlin.code' call
        var this_3 = _Char___init__impl__6a9atx(43);
        tmp_2 = tmp_4 === Char__toInt_impl_vasixd(this_3);
      }
      if (tmp_2) {
        indicator = c;
        $this.b4k_1.f4l();
      } else {
        indicator = null;
      }
    } else {
      increment = null;
      indicator = null;
    }
  }
  c = $this.b4k_1.l1m();
  if (Companion_getInstance_1().l47_1.y47(c)) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a block scalar', startMark, 'expected chomping or indentation indicators, but found ' + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  var tmp0_elvis_lhs = Chomping(indicator, increment);
  var tmp_5;
  if (tmp0_elvis_lhs == null) {
    throw IllegalArgumentException.t('Unexpected block chomping indicator: ' + indicator);
  } else {
    tmp_5 = tmp0_elvis_lhs;
  }
  return tmp_5;
}
function scanBlockScalarIgnoredLine($this, startMark) {
  $l$loop: while (true) {
    var tmp = $this.b4k_1.l1m();
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(32);
    if (!(tmp === Char__toInt_impl_vasixd(this_0))) {
      break $l$loop;
    }
    $this.b4k_1.f4l();
  }
  var tmp_0;
  var tmp_1 = $this.b4k_1.l1m();
  // Inline function 'kotlin.code' call
  var this_1 = _Char___init__impl__6a9atx(35);
  if (tmp_1 === Char__toInt_impl_vasixd(this_1)) {
    tmp_0 = scanComment($this, CommentType_IN_LINE_getInstance());
  } else {
    tmp_0 = null;
  }
  var commentToken = tmp_0;
  var c = $this.b4k_1.l1m();
  if (scanLineBreak($this) == null && !(c === 0)) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a block scalar', startMark, 'expected a comment or a line break, but found ' + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  return commentToken;
}
function scanBlockScalarIndentation($this) {
  var chunks = StringBuilder.v();
  var maxIndent = 0;
  var endMark = $this.b4k_1.x4k();
  while (Companion_getInstance_1().j47_1.z47($this.b4k_1.l1m(), ' \r')) {
    var tmp = $this.b4k_1.l1m();
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(32);
    if (!(tmp === Char__toInt_impl_vasixd(this_0))) {
      var tmp0_elvis_lhs = scanLineBreak($this);
      chunks.tb(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs);
      endMark = $this.b4k_1.x4k();
    } else {
      $this.b4k_1.f4l();
      if ($this.b4k_1.w4k_1 > maxIndent) {
        maxIndent = $this.b4k_1.w4k_1;
      }
    }
  }
  return new BreakIntentHolder(chunks.toString(), maxIndent, endMark);
}
function scanBlockScalarBreaks($this, indent) {
  var chunks = StringBuilder.v();
  var endMark = $this.b4k_1.x4k();
  var col = $this.b4k_1.w4k_1;
  $l$loop: while (true) {
    var tmp;
    if (col < indent) {
      var tmp_0 = $this.b4k_1.l1m();
      // Inline function 'kotlin.code' call
      var this_0 = _Char___init__impl__6a9atx(32);
      tmp = tmp_0 === Char__toInt_impl_vasixd(this_0);
    } else {
      tmp = false;
    }
    if (!tmp) {
      break $l$loop;
    }
    $this.b4k_1.f4l();
    col = col + 1 | 0;
  }
  $l$loop_0: while (true) {
    var tmp0_elvis_lhs = scanLineBreak($this);
    var tmp_1;
    if (tmp0_elvis_lhs == null) {
      break $l$loop_0;
    } else {
      tmp_1 = tmp0_elvis_lhs;
    }
    var lineBreak = tmp_1;
    chunks.tb(lineBreak);
    endMark = $this.b4k_1.x4k();
    col = $this.b4k_1.w4k_1;
    $l$loop_1: while (true) {
      var tmp_2;
      if (col < indent) {
        var tmp_3 = $this.b4k_1.l1m();
        // Inline function 'kotlin.code' call
        var this_1 = _Char___init__impl__6a9atx(32);
        tmp_2 = tmp_3 === Char__toInt_impl_vasixd(this_1);
      } else {
        tmp_2 = false;
      }
      if (!tmp_2) {
        break $l$loop_1;
      }
      $this.b4k_1.f4l();
      col = col + 1 | 0;
    }
  }
  return new BreakIntentHolder(chunks.toString(), -1, endMark);
}
function scanFlowScalar($this, style) {
  var doubleValue = style.equals(ScalarStyle_DOUBLE_QUOTED_getInstance());
  var startMark = $this.b4k_1.x4k();
  var quote = $this.b4k_1.l1m();
  $this.b4k_1.f4l();
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  scanFlowScalarNonSpaces($this, doubleValue, startMark, this_0);
  while (!($this.b4k_1.l1m() === quote)) {
    scanFlowScalarSpaces($this, startMark, this_0);
    scanFlowScalarNonSpaces($this, doubleValue, startMark, this_0);
  }
  var chunks = this_0.toString();
  $this.b4k_1.f4l();
  var endMark = $this.b4k_1.x4k();
  return new ScalarToken(chunks, false, startMark, endMark, style);
}
function scanFlowScalarNonSpaces($this, doubleQuoted, startMark, chunks) {
  while (true) {
    var length = 0;
    while (Companion_getInstance_1().m47_1.a48($this.b4k_1.h4l(length), '\'"\\')) {
      length = length + 1 | 0;
    }
    if (!(length === 0)) {
      chunks.tb($this.b4k_1.i4l(length));
    }
    var c = $this.b4k_1.l1m();
    var tmp;
    var tmp_0;
    if (!doubleQuoted) {
      var tmp_1 = c;
      // Inline function 'kotlin.code' call
      var this_0 = _Char___init__impl__6a9atx(39);
      tmp_0 = tmp_1 === Char__toInt_impl_vasixd(this_0);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      var tmp_2 = $this.b4k_1.h4l(1);
      // Inline function 'kotlin.code' call
      var this_1 = _Char___init__impl__6a9atx(39);
      tmp = tmp_2 === Char__toInt_impl_vasixd(this_1);
    } else {
      tmp = false;
    }
    if (tmp) {
      chunks.ub(_Char___init__impl__6a9atx(39));
      $this.b4k_1.e4l(2);
    } else {
      var tmp_3;
      var tmp_4;
      if (doubleQuoted) {
        var tmp_5 = c;
        // Inline function 'kotlin.code' call
        var this_2 = _Char___init__impl__6a9atx(39);
        tmp_4 = tmp_5 === Char__toInt_impl_vasixd(this_2);
      } else {
        tmp_4 = false;
      }
      if (tmp_4) {
        tmp_3 = true;
      } else {
        tmp_3 = (!doubleQuoted && contains('"\\', numberToChar(c)));
      }
      if (tmp_3) {
        appendCodePoint(chunks, c);
        $this.b4k_1.f4l();
      } else {
        var tmp_6;
        if (doubleQuoted) {
          var tmp_7 = c;
          // Inline function 'kotlin.code' call
          var this_3 = _Char___init__impl__6a9atx(92);
          tmp_6 = tmp_7 === Char__toInt_impl_vasixd(this_3);
        } else {
          tmp_6 = false;
        }
        if (tmp_6) {
          $this.b4k_1.f4l();
          c = $this.b4k_1.l1m();
          var tmp_8;
          if (!Character_getInstance().x4f(c)) {
            var tmp4 = Companion_getInstance_1().s47_1;
            // Inline function 'kotlin.collections.contains' call
            // Inline function 'kotlin.collections.containsKey' call
            var key = new Char(numberToChar(c));
            tmp_8 = (isInterface(tmp4, KtMap) ? tmp4 : THROW_CCE()).f3(key);
          } else {
            tmp_8 = false;
          }
          if (tmp_8) {
            chunks.tb(Companion_getInstance_1().s47_1.h3(new Char(numberToChar(c))));
            $this.b4k_1.f4l();
          } else {
            var tmp_9;
            if (!Character_getInstance().x4f(c)) {
              var tmp6 = Companion_getInstance_1().u47_1;
              // Inline function 'kotlin.collections.contains' call
              // Inline function 'kotlin.collections.containsKey' call
              var key_0 = new Char(numberToChar(c));
              tmp_9 = (isInterface(tmp6, KtMap) ? tmp6 : THROW_CCE()).f3(key_0);
            } else {
              tmp_9 = false;
            }
            if (tmp_9) {
              length = ensureNotNull(Companion_getInstance_1().u47_1.h3(new Char(numberToChar(c))));
              $this.b4k_1.f4l();
              var hex = $this.b4k_1.g4l(length);
              if (Companion_getInstance_9().t4l_1.zh(hex)) {
                throw ScannerException.q4f('while scanning a double-quoted scalar', startMark, 'expected escape sequence of ' + length + ' hexadecimal numbers, but found: ' + hex, $this.b4k_1.x4k());
              }
              try {
                var decimal = toInt_0(hex, 16);
                appendCodePoint(chunks, decimal);
                $this.b4k_1.e4l(length);
              } catch ($p) {
                if ($p instanceof IllegalArgumentException) {
                  var e = $p;
                  throw ScannerException.q4f('while scanning a double-quoted scalar', startMark, 'found unknown escape character ' + hex, $this.b4k_1.x4k());
                } else {
                  throw $p;
                }
              }
            } else {
              if (!(scanLineBreak($this) == null)) {
                chunks.tb(scanFlowScalarBreaks($this, startMark));
              } else {
                var s = concatToString(Character_getInstance().g4f(c));
                throw ScannerException.q4f('while scanning a double-quoted scalar', startMark, 'found unknown escape character ' + s + '(' + c + ')', $this.b4k_1.x4k());
              }
            }
          }
        } else {
          return Unit_instance;
        }
      }
    }
  }
}
function scanFlowScalarSpaces($this, startMark, chunks) {
  var length = 0;
  while (contains(' \t', numberToChar($this.b4k_1.h4l(length)))) {
    length = length + 1 | 0;
  }
  var whitespaces = $this.b4k_1.i4l(length);
  if ($this.b4k_1.l1m() === 0) {
    throw ScannerException.q4f('found unexpected end of stream', $this.b4k_1.x4k(), 'while scanning a quoted scalar', startMark);
  }
  var lineBreakOpt = scanLineBreak($this);
  // Inline function 'kotlin.apply' call
  if (!(lineBreakOpt == null)) {
    var breaks = scanFlowScalarBreaks($this, startMark);
    if (!('\n' === lineBreakOpt)) {
      chunks.tb(lineBreakOpt);
    } else {
      // Inline function 'kotlin.text.isEmpty' call
      if (charSequenceLength(breaks) === 0) {
        chunks.ub(_Char___init__impl__6a9atx(32));
      }
    }
    chunks.tb(breaks);
  } else {
    chunks.tb(whitespaces);
  }
}
function scanFlowScalarBreaks($this, startMark) {
  var chunks = StringBuilder.v();
  $l$loop: while (true) {
    var prefix = $this.b4k_1.g4l(3);
    if (('---' === prefix || '...' === prefix) && Companion_getInstance_1().m47_1.x47($this.b4k_1.h4l(3))) {
      throw ScannerException.q4f('while scanning a quoted scalar', startMark, 'found unexpected document separator', $this.b4k_1.x4k());
    }
    while (contains(' \t', numberToChar($this.b4k_1.l1m()))) {
      $this.b4k_1.f4l();
    }
    var tmp0_elvis_lhs = scanLineBreak($this);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break $l$loop;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var lineBreakOpt = tmp;
    chunks.tb(lineBreakOpt);
  }
  return chunks.toString();
}
function scanPlain($this) {
  var chunks = StringBuilder.v();
  var startMark = $this.b4k_1.x4k();
  var endMark = startMark;
  var plainIndent = $this.j4k_1 + 1 | 0;
  var spaces = '';
  $l$loop_2: while (true) {
    var c;
    var length = 0;
    var tmp = $this.b4k_1.l1m();
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(35);
    if (tmp === Char__toInt_impl_vasixd(this_0)) {
      break $l$loop_2;
    }
    $l$loop_0: while (true) {
      c = $this.b4k_1.h4l(length);
      var tmp_0;
      var tmp_1;
      if (Companion_getInstance_1().m47_1.x47(c)) {
        tmp_1 = true;
      } else {
        var tmp_2;
        var tmp_3 = c;
        // Inline function 'kotlin.code' call
        var this_1 = _Char___init__impl__6a9atx(58);
        if (tmp_3 === Char__toInt_impl_vasixd(this_1)) {
          tmp_2 = Companion_getInstance_1().m47_1.z47($this.b4k_1.h4l(length + 1 | 0), isFlowContext($this) ? ',[]{}' : '');
        } else {
          tmp_2 = false;
        }
        tmp_1 = tmp_2;
      }
      if (tmp_1) {
        tmp_0 = true;
      } else {
        tmp_0 = (isFlowContext($this) && contains(',[]{}', numberToChar(c)));
      }
      if (tmp_0) {
        break $l$loop_0;
      }
      length = length + 1 | 0;
    }
    if (length === 0) {
      break $l$loop_2;
    }
    $this.k4k_1 = false;
    chunks.tb(spaces);
    chunks.tb($this.b4k_1.i4l(length));
    endMark = $this.b4k_1.x4k();
    spaces = scanPlainSpaces($this);
    var tmp_4;
    var tmp_5;
    // Inline function 'kotlin.text.isEmpty' call
    var this_2 = spaces;
    if (charSequenceLength(this_2) === 0) {
      tmp_5 = true;
    } else {
      var tmp_6 = $this.b4k_1.l1m();
      // Inline function 'kotlin.code' call
      var this_3 = _Char___init__impl__6a9atx(35);
      tmp_5 = tmp_6 === Char__toInt_impl_vasixd(this_3);
    }
    if (tmp_5) {
      tmp_4 = true;
    } else {
      tmp_4 = (isBlockContext($this) && $this.b4k_1.w4k_1 < plainIndent);
    }
    if (tmp_4) {
      break $l$loop_2;
    }
  }
  return new ScalarToken(chunks.toString(), true, startMark, endMark);
}
function atEndOfPlain($this) {
  var wsLength = 0;
  var wsColumn = $this.b4k_1.w4k_1;
  $l$loop: while (true) {
    var c = $this.b4k_1.h4l(wsLength);
    if (c === 0 || !Companion_getInstance_1().m47_1.x47(c)) {
      break $l$loop;
    } else {
      wsLength = wsLength + 1 | 0;
      var tmp;
      var tmp_0;
      if (!Companion_getInstance_1().j47_1.x47(c)) {
        var tmp_1;
        // Inline function 'kotlin.code' call
        var this_0 = _Char___init__impl__6a9atx(13);
        if (!(c === Char__toInt_impl_vasixd(this_0))) {
          tmp_1 = true;
        } else {
          var tmp_2 = $this.b4k_1.h4l(wsLength + 1 | 0);
          // Inline function 'kotlin.code' call
          var this_1 = _Char___init__impl__6a9atx(10);
          tmp_1 = !(tmp_2 === Char__toInt_impl_vasixd(this_1));
        }
        tmp_0 = tmp_1;
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp = !(c === 65279);
      } else {
        tmp = false;
      }
      if (tmp) {
        wsColumn = wsColumn + 1 | 0;
      } else {
        wsColumn = 0;
      }
    }
  }
  var tmp_3;
  var tmp_4;
  var tmp_5 = $this.b4k_1.h4l(wsLength);
  // Inline function 'kotlin.code' call
  var this_2 = _Char___init__impl__6a9atx(35);
  if (tmp_5 === Char__toInt_impl_vasixd(this_2)) {
    tmp_4 = true;
  } else {
    tmp_4 = $this.b4k_1.h4l(wsLength + 1 | 0) === 0;
  }
  if (tmp_4) {
    tmp_3 = true;
  } else {
    tmp_3 = (isBlockContext($this) && wsColumn < $this.j4k_1);
  }
  if (tmp_3) {
    return true;
  }
  if (isBlockContext($this)) {
    var extra = 1;
    $l$loop_0: while (true) {
      var c_0 = $this.b4k_1.h4l(wsLength + extra | 0);
      if (c_0 === 0 || Companion_getInstance_1().m47_1.x47(c_0)) {
        break $l$loop_0;
      } else {
        // Inline function 'kotlin.code' call
        var this_3 = _Char___init__impl__6a9atx(58);
        if (c_0 === Char__toInt_impl_vasixd(this_3)) {
          var nextC = $this.b4k_1.h4l((wsLength + extra | 0) + 1 | 0);
          if (Companion_getInstance_1().m47_1.x47(nextC)) {
            return true;
          }
        }
      }
      extra = extra + 1 | 0;
    }
  }
  return false;
}
function scanPlainSpaces($this) {
  var length = 0;
  while (contains(' \t', numberToChar($this.b4k_1.h4l(length)))) {
    length = length + 1 | 0;
  }
  var whitespaces = $this.b4k_1.i4l(length);
  var tmp0_elvis_lhs = scanLineBreak($this);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return whitespaces;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var lineBreak = tmp;
  $this.k4k_1 = true;
  var prefix = $this.b4k_1.g4l(3);
  if ('---' === prefix || ('...' === prefix && Companion_getInstance_1().m47_1.x47($this.b4k_1.h4l(3)))) {
    return '';
  } else if ($this.a4k_1.n45_1 && atEndOfPlain($this)) {
    return '';
  } else {
    var breaks = StringBuilder.v();
    $l$loop: while (true) {
      if (contains(' \t', numberToChar($this.b4k_1.l1m()))) {
        $this.b4k_1.f4l();
      } else {
        var lbOpt = scanLineBreak($this);
        if (!(lbOpt == null)) {
          breaks.tb(lbOpt);
          prefix = $this.b4k_1.g4l(3);
          if ('---' === prefix || ('...' === prefix && Companion_getInstance_1().m47_1.x47($this.b4k_1.h4l(3)))) {
            return '';
          }
        } else {
          break $l$loop;
        }
      }
    }
    var tmp_0;
    if (!('\n' === lineBreak)) {
      tmp_0 = lineBreak + breaks.toString();
    } else {
      // Inline function 'kotlin.text.isEmpty' call
      if (charSequenceLength(breaks) === 0) {
        tmp_0 = ' ';
      } else {
        tmp_0 = breaks.toString();
      }
    }
    return tmp_0;
  }
}
function scanTagHandle($this, name, startMark) {
  var c = $this.b4k_1.l1m();
  var tmp = c;
  // Inline function 'kotlin.code' call
  var this_0 = _Char___init__impl__6a9atx(33);
  if (!(tmp === Char__toInt_impl_vasixd(this_0))) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a ' + name, startMark, "expected '!', but found " + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  var length = 1;
  c = $this.b4k_1.h4l(length);
  var tmp_0 = c;
  // Inline function 'kotlin.code' call
  var this_1 = _Char___init__impl__6a9atx(32);
  if (!(tmp_0 === Char__toInt_impl_vasixd(this_1))) {
    while (Companion_getInstance_1().q47_1.x47(c)) {
      length = length + 1 | 0;
      c = $this.b4k_1.h4l(length);
    }
    var tmp_1 = c;
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(33);
    if (!(tmp_1 === Char__toInt_impl_vasixd(this_2))) {
      $this.b4k_1.e4l(length);
      var s_0 = concatToString(Character_getInstance().g4f(c));
      throw ScannerException.q4f('while scanning a ' + name, startMark, "expected '!', but found " + s_0 + '(' + c + ')', $this.b4k_1.x4k());
    }
    length = length + 1 | 0;
  }
  return $this.b4k_1.i4l(length);
}
function scanTagUri($this, name, range, startMark) {
  var chunks = StringBuilder.v();
  var length = 0;
  var c = $this.b4k_1.h4l(length);
  while (range.x47(c)) {
    var tmp = c;
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(37);
    if (tmp === Char__toInt_impl_vasixd(this_0)) {
      chunks.tb($this.b4k_1.i4l(length));
      length = 0;
      chunks.tb(scanUriEscapes($this, name, startMark));
    } else {
      length = length + 1 | 0;
    }
    c = $this.b4k_1.h4l(length);
  }
  if (!(length === 0)) {
    chunks.tb($this.b4k_1.i4l(length));
  }
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(chunks) === 0) {
    var s = concatToString(Character_getInstance().g4f(c));
    throw ScannerException.q4f('while scanning a ' + name, startMark, 'expected URI, but found ' + s + '(' + c + ')', $this.b4k_1.x4k());
  }
  return chunks.toString();
}
function scanUriEscapes($this, name, startMark) {
  var length = 1;
  $l$loop: while (true) {
    var tmp = $this.b4k_1.h4l(imul(length, 3));
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(37);
    if (!(tmp === Char__toInt_impl_vasixd(this_0))) {
      break $l$loop;
    }
    length = length + 1 | 0;
  }
  var beginningMark = $this.b4k_1.x4k();
  var buff = new Buffer();
  $l$loop_0: while (true) {
    var tmp_0 = $this.b4k_1.l1m();
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(37);
    if (!(tmp_0 === Char__toInt_impl_vasixd(this_1))) {
      break $l$loop_0;
    }
    $this.b4k_1.f4l();
    try {
      var code = toInt_0($this.b4k_1.g4l(2), 16);
      buff.m43(code);
    } catch ($p) {
      if ($p instanceof NumberFormatException) {
        var nfe = $p;
        var c1 = $this.b4k_1.l1m();
        var s1 = concatToString(Character_getInstance().g4f(c1));
        var c2 = $this.b4k_1.h4l(1);
        var s2 = concatToString(Character_getInstance().g4f(c2));
        throw ScannerException.q4f('while scanning a ' + name, startMark, 'expected URI escape sequence of 2 hexadecimal numbers, but found ' + s1 + '(' + c1 + ') and ' + s2 + '(' + c2 + ')', $this.b4k_1.x4k());
      } else {
        throw $p;
      }
    }
    $this.b4k_1.e4l(2);
  }
  buff.r43();
  try {
    return UriEncoder_instance.g48(buff);
  } catch ($p) {
    if ($p instanceof CharacterCodingException) {
      var e = $p;
      throw ScannerException.q4f('while scanning a ' + name, startMark, 'expected URI in UTF-8: ' + e.message, beginningMark);
    } else {
      throw $p;
    }
  }
}
function scanLineBreak($this) {
  var c = $this.b4k_1.l1m();
  var tmp;
  var tmp_0;
  // Inline function 'kotlin.code' call
  var this_0 = _Char___init__impl__6a9atx(13);
  if (c === Char__toInt_impl_vasixd(this_0)) {
    tmp_0 = true;
  } else {
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(10);
    tmp_0 = c === Char__toInt_impl_vasixd(this_1);
  }
  if (tmp_0) {
    tmp = true;
  } else {
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(133);
    tmp = c === Char__toInt_impl_vasixd(this_2);
  }
  if (tmp) {
    var tmp_1;
    // Inline function 'kotlin.code' call
    var this_3 = _Char___init__impl__6a9atx(13);
    if (c === Char__toInt_impl_vasixd(this_3)) {
      // Inline function 'kotlin.code' call
      var this_4 = _Char___init__impl__6a9atx(10);
      tmp_1 = Char__toInt_impl_vasixd(this_4) === $this.b4k_1.h4l(1);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      $this.b4k_1.e4l(2);
    } else {
      $this.b4k_1.f4l();
    }
    return '\n';
  }
  return null;
}
function makeTokenList($this, tokens) {
  var notNullTokens = filterNotNull(tokens);
  var tmp;
  if (!$this.a4k_1.n45_1) {
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = notNullTokens.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (!(element instanceof CommentToken)) {
        destination.l(element);
      }
    }
    tmp = destination;
  } else {
    tmp = notNullTokens;
  }
  return tmp;
}
var Companion_instance_9;
function Companion_getInstance_9() {
  if (Companion_instance_9 === VOID)
    new Companion_9();
  return Companion_instance_9;
}
function _Clip___init__impl__llmhrl(increment) {
  return increment;
}
function _Clip___get_increment__impl__6zmssn($this) {
  return $this;
}
function _Clip___get_addExistingFinalLineBreak__impl__v4gbjp($this) {
  return true;
}
function _Clip___get_retainTrailingEmptyLines__impl__5r5ek5($this) {
  return false;
}
function Clip__toString_impl_8zbb0x($this) {
  return 'Clip(increment=' + $this + ')';
}
function Clip__hashCode_impl_crulry($this) {
  return $this == null ? 0 : $this;
}
function Clip__equals_impl_7672fy($this, other) {
  if (!(other instanceof Clip))
    return false;
  if (!($this == (other instanceof Clip ? other.u4l_1 : THROW_CCE())))
    return false;
  return true;
}
function _Strip___init__impl__1l0fz5(increment) {
  return increment;
}
function _Strip___get_increment__impl__ultjnb($this) {
  return $this;
}
function _Strip___get_addExistingFinalLineBreak__impl__hh5hph($this) {
  return false;
}
function _Strip___get_retainTrailingEmptyLines__impl__5bav0l($this) {
  return false;
}
function Strip__toString_impl_e44ikp($this) {
  return 'Strip(increment=' + $this + ')';
}
function Strip__hashCode_impl_7n1e86($this) {
  return $this == null ? 0 : $this;
}
function Strip__equals_impl_vbxlyi($this, other) {
  if (!(other instanceof Strip))
    return false;
  if (!($this == (other instanceof Strip ? other.v4l_1 : THROW_CCE())))
    return false;
  return true;
}
function _Keep___init__impl__7pj66c(increment) {
  return increment;
}
function _Keep___get_increment__impl__g32ff2($this) {
  return $this;
}
function _Keep___get_addExistingFinalLineBreak__impl__eevoo0($this) {
  return true;
}
function _Keep___get_retainTrailingEmptyLines__impl__7i8cq2($this) {
  return true;
}
function Keep__toString_impl_5t9sg4($this) {
  return 'Keep(increment=' + $this + ')';
}
function Keep__hashCode_impl_rkfp8z($this) {
  return $this == null ? 0 : $this;
}
function Keep__equals_impl_3j9b7t($this, other) {
  if (!(other instanceof Keep))
    return false;
  if (!($this == (other instanceof Keep ? other.w4l_1 : THROW_CCE())))
    return false;
  return true;
}
function Chomping(indicatorCodePoint, increment) {
  var tmp;
  // Inline function 'kotlin.code' call
  var this_0 = _Char___init__impl__6a9atx(43);
  if (indicatorCodePoint === Char__toInt_impl_vasixd(this_0)) {
    tmp = new Keep(_Keep___init__impl__7pj66c(increment));
  } else {
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(45);
    if (indicatorCodePoint === Char__toInt_impl_vasixd(this_1)) {
      tmp = new Strip(_Strip___init__impl__1l0fz5(increment));
    } else {
      if (indicatorCodePoint == null) {
        tmp = new Clip(_Clip___init__impl__llmhrl(increment));
      } else {
        tmp = null;
      }
    }
  }
  return tmp;
}
function copyOfRangeSafe($this, _this__u8e3s4, fromIndex, toIndex) {
  var tmp = 0;
  var tmp_0 = toIndex - fromIndex | 0;
  var tmp_1 = new Int32Array(tmp_0);
  while (tmp < tmp_0) {
    var tmp_2 = tmp;
    // Inline function 'kotlin.collections.getOrElse' call
    var index = fromIndex + tmp_2 | 0;
    var tmp_3;
    if (0 <= index ? index <= (_this__u8e3s4.length - 1 | 0) : false) {
      tmp_3 = _this__u8e3s4[index];
    } else {
      tmp_3 = 0;
    }
    tmp_1[tmp_2] = tmp_3;
    tmp = tmp + 1 | 0;
  }
  return tmp_1;
}
function ensureEnoughData($this, size) {
  if (!$this.s4k_1 && ($this.r4k_1 + size | 0) >= $this.q4k_1) {
    update($this);
  }
  return ($this.r4k_1 + size | 0) < $this.q4k_1;
}
function ensureEnoughData$default($this, size, $super) {
  size = size === VOID ? 0 : size;
  return ensureEnoughData($this, size);
}
function update($this) {
  try {
    var tmp0 = $this.l4k_1;
    // Inline function 'it.krzeminski.snakeyaml.engine.kmp.internal.utils.readUtf8WithLimit' call
    var tmp1 = $this.o4k_1;
    var tmp$ret$0;
    $l$block_4: {
      // Inline function 'it.krzeminski.snakeyaml.engine.kmp.internal.utils.sizeOfFullValidUtf8String' call
      var hasAll = tmp0.j1l(tmp1);
      var originalSize = hasAll ? tmp1 : tmp0.g1l().p40_1;
      if (originalSize.equals(new Long(0, 0))) {
        tmp$ret$0 = new Long(0, 0);
        break $l$block_4;
      }
      var tmp = tmp0.g1l();
      // Inline function 'kotlin.Long.minus' call
      var tmp$ret$1 = originalSize.v3(toLong(1));
      var byte = tmp.c1m(tmp$ret$1);
      // Inline function 'it.krzeminski.snakeyaml.engine.kmp.internal.utils.isContinuationByte' call
      var asInt = byte;
      if (!((asInt & 192) === 128)) {
        // Inline function 'kotlin.Long.minus' call
        var other = byte < 0 ? 1 : 0;
        tmp$ret$0 = originalSize.v3(toLong(other));
        break $l$block_4;
      }
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$4 = originalSize.u3(toLong(1));
      if (!tmp0.j1l(tmp$ret$4)) {
        tmp$ret$0 = originalSize;
        break $l$block_4;
      }
      // Inline function 'it.krzeminski.snakeyaml.engine.kmp.internal.utils.isContinuationByte' call
      var asInt_0 = tmp0.g1l().c1m(originalSize);
      if (!((asInt_0 & 192) === 128)) {
        tmp$ret$0 = originalSize;
        break $l$block_4;
      }
      var size = originalSize;
      // Inline function 'kotlin.repeat' call
      var inductionVariable = 0;
      if (inductionVariable < 3)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          // Inline function 'kotlin.Long.minus' call
          size = size.v3(toLong(1));
          if (size.equals(new Long(0, 0))) {
            tmp$ret$0 = originalSize;
            break $l$block_4;
          }
          var tmp_0 = tmp0.g1l();
          // Inline function 'kotlin.Long.minus' call
          var tmp$ret$7 = size.v3(toLong(1));
          var byte_0 = tmp_0.c1m(tmp$ret$7);
          // Inline function 'it.krzeminski.snakeyaml.engine.kmp.internal.utils.isContinuationByte' call
          var asInt_1 = byte_0;
          if (!((asInt_1 & 192) === 128)) {
            var tmp_1;
            if (byte_0 >= 0) {
              tmp_1 = originalSize;
            } else {
              // Inline function 'it.krzeminski.snakeyaml.engine.kmp.internal.utils.continuationBytesCountFor' call
              var asInt_2 = byte_0;
              if (((asInt_2 & 224) === 192 ? 1 : (asInt_2 & 240) === 224 ? 2 : (asInt_2 & 248) === 240 ? 3 : 0) < (index + 1 | 0)) {
                tmp_1 = originalSize;
              } else {
                // Inline function 'kotlin.Long.minus' call
                tmp_1 = size.v3(toLong(1));
              }
            }
            tmp$ret$0 = tmp_1;
            break $l$block_4;
          }
        }
         while (inductionVariable < 3);
      tmp$ret$0 = originalSize;
    }
    var fullUtf8Size = tmp$ret$0;
    var buffer = tmp0.g43(fullUtf8Size);
    var buffer_0 = buffer;
    var read = buffer_0.length;
    if (read > 0) {
      var cpIndex = $this.q4k_1 - $this.r4k_1 | 0;
      $this.p4k_1 = copyOfRangeSafe(Companion_instance_10, $this.p4k_1, $this.r4k_1, $this.q4k_1 + read | 0);
      var nonPrintable = null;
      var i = 0;
      while (i < read) {
        var codePoint = codePointAt(buffer_0, i);
        $this.p4k_1[cpIndex] = codePoint;
        if (Companion_instance_10.x4l(codePoint)) {
          i = i + Character_getInstance().w4f(codePoint) | 0;
        } else {
          nonPrintable = codePoint;
          i = read;
        }
        cpIndex = cpIndex + 1 | 0;
      }
      $this.q4k_1 = cpIndex;
      $this.r4k_1 = 0;
      if (!(nonPrintable == null)) {
        throw ReaderException.a4f($this.m4k_1, cpIndex - 1 | 0, nonPrintable, 'special characters are not allowed');
      }
    } else {
      $this.s4k_1 = true;
    }
  } catch ($p) {
    if ($p instanceof IOException) {
      var ioe = $p;
      throw YamlEngineException.r4f(ioe);
    } else {
      throw $p;
    }
  }
}
function moveIndices($this, length) {
  $this.t4k_1 = $this.t4k_1 + length | 0;
  $this.u4k_1 = $this.u4k_1 + length | 0;
}
var Companion_instance_10;
function Companion_getInstance_10() {
  return Companion_instance_10;
}
function defaultSchemaTagConstructors(scalarResolver) {
  // Inline function 'kotlin.collections.buildMap' call
  // Inline function 'kotlin.collections.buildMapInternal' call
  // Inline function 'kotlin.apply' call
  var this_0 = LinkedHashMap.hc();
  this_0.k3(Companion_getInstance_5().f4g_1, new ConstructYamlNull());
  this_0.k3(Companion_getInstance_5().e4g_1, new ConstructYamlJsonBool());
  this_0.k3(Companion_getInstance_5().c4g_1, new ConstructYamlJsonInt());
  this_0.k3(Companion_getInstance_5().d4g_1, new ConstructYamlJsonFloat());
  this_0.k3(Companion_getInstance_5().b4g_1, new ConstructYamlBinary());
  this_0.m3(targetSchemaTagConstructors(scalarResolver));
  return this_0.w7();
}
var Companion_instance_11;
function Companion_getInstance_11() {
  return Companion_instance_11;
}
var ID_Alias_instance_0;
var ID_Anchor_instance;
var ID_BlockEnd_instance;
var ID_BlockEntry_instance;
var ID_BlockMappingStart_instance;
var ID_BlockSequenceStart_instance;
var ID_Directive_instance;
var ID_DocumentEnd_instance_0;
var ID_DocumentStart_instance_0;
var ID_FlowEntry_instance;
var ID_FlowMappingEnd_instance;
var ID_FlowMappingStart_instance;
var ID_FlowSequenceEnd_instance;
var ID_FlowSequenceStart_instance;
var ID_Key_instance;
var ID_Scalar_instance_0;
var ID_StreamEnd_instance_0;
var ID_StreamStart_instance_0;
var ID_Tag_instance;
var ID_Comment_instance_0;
var ID_Value_instance;
var ID_entriesInitialized_0;
function ID_initEntries_0() {
  if (ID_entriesInitialized_0)
    return Unit_instance;
  ID_entriesInitialized_0 = true;
  ID_Alias_instance_0 = new ID_0('Alias', 0, '<alias>');
  ID_Anchor_instance = new ID_0('Anchor', 1, '<anchor>');
  ID_BlockEnd_instance = new ID_0('BlockEnd', 2, '<block end>');
  ID_BlockEntry_instance = new ID_0('BlockEntry', 3, '-');
  ID_BlockMappingStart_instance = new ID_0('BlockMappingStart', 4, '<block mapping start>');
  ID_BlockSequenceStart_instance = new ID_0('BlockSequenceStart', 5, '<block sequence start>');
  ID_Directive_instance = new ID_0('Directive', 6, '<directive>');
  ID_DocumentEnd_instance_0 = new ID_0('DocumentEnd', 7, '<document end>');
  ID_DocumentStart_instance_0 = new ID_0('DocumentStart', 8, '<document start>');
  ID_FlowEntry_instance = new ID_0('FlowEntry', 9, ',');
  ID_FlowMappingEnd_instance = new ID_0('FlowMappingEnd', 10, '}');
  ID_FlowMappingStart_instance = new ID_0('FlowMappingStart', 11, '{');
  ID_FlowSequenceEnd_instance = new ID_0('FlowSequenceEnd', 12, ']');
  ID_FlowSequenceStart_instance = new ID_0('FlowSequenceStart', 13, '[');
  ID_Key_instance = new ID_0('Key', 14, '?');
  ID_Scalar_instance_0 = new ID_0('Scalar', 15, '<scalar>');
  ID_StreamEnd_instance_0 = new ID_0('StreamEnd', 16, '<stream end>');
  ID_StreamStart_instance_0 = new ID_0('StreamStart', 17, '<stream start>');
  ID_Tag_instance = new ID_0('Tag', 18, '<tag>');
  ID_Comment_instance_0 = new ID_0('Comment', 19, '#');
  ID_Value_instance = new ID_0('Value', 20, ':');
}
function ID_Alias_getInstance_0() {
  ID_initEntries_0();
  return ID_Alias_instance_0;
}
function ID_Anchor_getInstance() {
  ID_initEntries_0();
  return ID_Anchor_instance;
}
function ID_BlockEnd_getInstance() {
  ID_initEntries_0();
  return ID_BlockEnd_instance;
}
function ID_BlockEntry_getInstance() {
  ID_initEntries_0();
  return ID_BlockEntry_instance;
}
function ID_BlockMappingStart_getInstance() {
  ID_initEntries_0();
  return ID_BlockMappingStart_instance;
}
function ID_BlockSequenceStart_getInstance() {
  ID_initEntries_0();
  return ID_BlockSequenceStart_instance;
}
function ID_Directive_getInstance() {
  ID_initEntries_0();
  return ID_Directive_instance;
}
function ID_DocumentEnd_getInstance_0() {
  ID_initEntries_0();
  return ID_DocumentEnd_instance_0;
}
function ID_DocumentStart_getInstance_0() {
  ID_initEntries_0();
  return ID_DocumentStart_instance_0;
}
function ID_FlowEntry_getInstance() {
  ID_initEntries_0();
  return ID_FlowEntry_instance;
}
function ID_FlowMappingEnd_getInstance() {
  ID_initEntries_0();
  return ID_FlowMappingEnd_instance;
}
function ID_FlowMappingStart_getInstance() {
  ID_initEntries_0();
  return ID_FlowMappingStart_instance;
}
function ID_FlowSequenceEnd_getInstance() {
  ID_initEntries_0();
  return ID_FlowSequenceEnd_instance;
}
function ID_FlowSequenceStart_getInstance() {
  ID_initEntries_0();
  return ID_FlowSequenceStart_instance;
}
function ID_Key_getInstance() {
  ID_initEntries_0();
  return ID_Key_instance;
}
function ID_Scalar_getInstance_0() {
  ID_initEntries_0();
  return ID_Scalar_instance_0;
}
function ID_StreamEnd_getInstance_0() {
  ID_initEntries_0();
  return ID_StreamEnd_instance_0;
}
function ID_StreamStart_getInstance_0() {
  ID_initEntries_0();
  return ID_StreamStart_instance_0;
}
function ID_Tag_getInstance() {
  ID_initEntries_0();
  return ID_Tag_instance;
}
function ID_Comment_getInstance_0() {
  ID_initEntries_0();
  return ID_Comment_instance_0;
}
function ID_Value_getInstance() {
  ID_initEntries_0();
  return ID_Value_instance;
}
function targetSchemaTagConstructors(scalarResolver) {
  return emptyMap();
}
//region block: post-declaration
initMetadataForInterface(CollectionProvider, 'CollectionProvider');
initMetadataForInterface(SpecVersionMutator, 'SpecVersionMutator');
initMetadataForCompanion(Companion);
initMetadataForClass(LoadSettings, 'LoadSettings');
initMetadataForClass(sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0, 'sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0', VOID, VOID, [CollectionProvider, FunctionAdapter]);
initMetadataForClass(sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0_0, 'sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0', VOID, VOID, [CollectionProvider, FunctionAdapter]);
initMetadataForClass(sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0_1, 'sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_CollectionProvider$0', VOID, VOID, [CollectionProvider, FunctionAdapter]);
initMetadataForClass(sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_SpecVersionMutator$0, 'sam$it_krzeminski_snakeyaml_engine_kmp_api_LoadSettings_SpecVersionMutator$0', VOID, VOID, [SpecVersionMutator, FunctionAdapter]);
initMetadataForClass(LoadSettingsBuilder, 'LoadSettingsBuilder');
initMetadataForClass(CommentType, 'CommentType');
initMetadataForCompanion(Companion_0);
initMetadataForClass(Anchor, 'Anchor');
initMetadataForCompanion(Companion_1);
initMetadataForClass(CharConstants, 'CharConstants');
initMetadataForClass(FlowStyle, 'FlowStyle');
initMetadataForClass(ScalarStyle, 'ScalarStyle');
initMetadataForClass(SpecVersion, 'SpecVersion');
initMetadataForObject(UriEncoder, 'UriEncoder');
initMetadataForCompanion(Companion_2);
initMetadataForClass(ConstructScalar, 'ConstructScalar');
initMetadataForClass(ConstructYamlNull, 'ConstructYamlNull', ConstructYamlNull);
initMetadataForClass(ConstructYamlBinary, 'ConstructYamlBinary', ConstructYamlBinary);
initMetadataForClass(ConstructYamlJsonBool, 'ConstructYamlJsonBool', ConstructYamlJsonBool);
initMetadataForClass(ConstructYamlJsonFloat, 'ConstructYamlJsonFloat', ConstructYamlJsonFloat);
initMetadataForClass(ConstructYamlJsonInt, 'ConstructYamlJsonInt', ConstructYamlJsonInt);
initMetadataForClass(Event, 'Event');
initMetadataForClass(NodeEvent, 'NodeEvent');
initMetadataForClass(AliasEvent, 'AliasEvent');
initMetadataForClass(CollectionEndEvent, 'CollectionEndEvent');
initMetadataForClass(CollectionStartEvent, 'CollectionStartEvent');
initMetadataForClass(CommentEvent, 'CommentEvent');
initMetadataForClass(DocumentEndEvent, 'DocumentEndEvent');
initMetadataForClass(DocumentStartEvent, 'DocumentStartEvent');
initMetadataForClass(ID, 'ID');
initMetadataForClass(ImplicitTuple, 'ImplicitTuple');
initMetadataForClass(MappingEndEvent, 'MappingEndEvent', MappingEndEvent.b4c);
initMetadataForClass(MappingStartEvent, 'MappingStartEvent');
initMetadataForClass(ScalarEvent, 'ScalarEvent');
initMetadataForClass(SequenceEndEvent, 'SequenceEndEvent', SequenceEndEvent.w4c);
initMetadataForClass(SequenceStartEvent, 'SequenceStartEvent');
initMetadataForClass(StreamEndEvent, 'StreamEndEvent', StreamEndEvent.h4d);
initMetadataForClass(StreamStartEvent, 'StreamStartEvent', StreamStartEvent.l4d);
initMetadataForClass(YamlEngineException, 'YamlEngineException');
initMetadataForClass(EmitterException, 'EmitterException');
initMetadataForCompanion(Companion_3);
initMetadataForClass(Mark, 'Mark');
initMetadataForCompanion(Companion_4);
initMetadataForClass(MarkedYamlEngineException, 'MarkedYamlEngineException');
initMetadataForClass(ParserException, 'ParserException');
initMetadataForClass(ReaderException, 'ReaderException');
initMetadataForClass(ScannerException, 'ScannerException');
initMetadataForClass(YamlVersionException, 'YamlVersionException');
initMetadataForObject(Character, 'Character');
initMetadataForCompanion(Companion_5);
initMetadataForClass(Tag, 'Tag');
initMetadataForClass(ParseStreamStart, 'ParseStreamStart');
initMetadataForClass(ParseImplicitDocumentStart, 'ParseImplicitDocumentStart');
initMetadataForClass(ParseDocumentStart, 'ParseDocumentStart');
initMetadataForClass(ParseDocumentEnd, 'ParseDocumentEnd');
initMetadataForClass(ParseDocumentContent, 'ParseDocumentContent');
initMetadataForClass(ParseBlockNode, 'ParseBlockNode');
initMetadataForClass(ParseBlockSequenceFirstEntry, 'ParseBlockSequenceFirstEntry');
initMetadataForClass(ParseBlockSequenceEntryKey, 'ParseBlockSequenceEntryKey');
initMetadataForClass(ParseBlockSequenceEntryValue, 'ParseBlockSequenceEntryValue');
initMetadataForClass(ParseIndentlessSequenceEntryKey, 'ParseIndentlessSequenceEntryKey');
initMetadataForClass(ParseIndentlessSequenceEntryValue, 'ParseIndentlessSequenceEntryValue');
initMetadataForClass(ParseBlockMappingFirstKey, 'ParseBlockMappingFirstKey');
initMetadataForClass(ParseBlockMappingKey, 'ParseBlockMappingKey');
initMetadataForClass(ParseBlockMappingValue, 'ParseBlockMappingValue');
initMetadataForClass(ParseBlockMappingValueComment, 'ParseBlockMappingValueComment');
initMetadataForClass(ParseBlockMappingValueCommentList, 'ParseBlockMappingValueCommentList');
initMetadataForClass(ParseFlowSequenceFirstEntry, 'ParseFlowSequenceFirstEntry');
initMetadataForClass(ParseFlowSequenceEntry, 'ParseFlowSequenceEntry');
initMetadataForClass(ParseFlowEndComment, 'ParseFlowEndComment');
initMetadataForClass(ParseFlowSequenceEntryMappingKey, 'ParseFlowSequenceEntryMappingKey');
initMetadataForClass(ParseFlowSequenceEntryMappingValue, 'ParseFlowSequenceEntryMappingValue');
initMetadataForClass(ParseFlowSequenceEntryMappingEnd, 'ParseFlowSequenceEntryMappingEnd');
initMetadataForClass(ParseFlowMappingFirstKey, 'ParseFlowMappingFirstKey');
initMetadataForClass(ParseFlowMappingKey, 'ParseFlowMappingKey');
initMetadataForClass(ParseFlowMappingValue, 'ParseFlowMappingValue');
initMetadataForClass(ParseFlowMappingEmptyValue, 'ParseFlowMappingEmptyValue');
initMetadataForCompanion(Companion_6);
initMetadataForClass(ParserImpl, 'ParserImpl');
initMetadataForClass(VersionTagsTuple, 'VersionTagsTuple');
initMetadataForClass(ImplicitResolversBuilder, 'ImplicitResolversBuilder', ImplicitResolversBuilder);
initMetadataForCompanion(Companion_7);
initMetadataForClass(BaseScalarResolver, 'BaseScalarResolver');
initMetadataForCompanion(Companion_8);
initMetadataForClass(JsonScalarResolver, 'JsonScalarResolver', JsonScalarResolver);
initMetadataForClass(ResolverTuple, 'ResolverTuple');
initMetadataForInterface(Scanner, 'Scanner');
initMetadataForCompanion(Companion_9);
initMetadataForClass(ScannerImpl, 'ScannerImpl', VOID, VOID, [Scanner]);
initMetadataForClass(Clip, 'Clip');
initMetadataForClass(Strip, 'Strip');
initMetadataForClass(Keep, 'Keep');
initMetadataForClass(BreakIntentHolder, 'BreakIntentHolder');
initMetadataForClass(SimpleKey, 'SimpleKey');
initMetadataForCompanion(Companion_10);
initMetadataForClass(StreamReader, 'StreamReader');
initMetadataForClass(JsonSchema, 'JsonSchema', JsonSchema);
initMetadataForClass(Token, 'Token');
initMetadataForClass(AliasToken, 'AliasToken');
initMetadataForClass(AnchorToken, 'AnchorToken');
initMetadataForClass(BlockEndToken, 'BlockEndToken');
initMetadataForClass(BlockEntryToken, 'BlockEntryToken');
initMetadataForClass(BlockMappingStartToken, 'BlockMappingStartToken');
initMetadataForClass(BlockSequenceStartToken, 'BlockSequenceStartToken');
initMetadataForClass(CommentToken, 'CommentToken');
initMetadataForClass(YamlDirective, 'YamlDirective');
initMetadataForClass(TagDirective, 'TagDirective');
initMetadataForCompanion(Companion_11);
initMetadataForClass(DirectiveToken, 'DirectiveToken');
initMetadataForClass(DocumentEndToken, 'DocumentEndToken');
initMetadataForClass(DocumentStartToken, 'DocumentStartToken');
initMetadataForClass(FlowEntryToken, 'FlowEntryToken');
initMetadataForClass(FlowMappingEndToken, 'FlowMappingEndToken');
initMetadataForClass(FlowMappingStartToken, 'FlowMappingStartToken');
initMetadataForClass(FlowSequenceEndToken, 'FlowSequenceEndToken');
initMetadataForClass(FlowSequenceStartToken, 'FlowSequenceStartToken');
initMetadataForClass(KeyToken, 'KeyToken');
initMetadataForClass(ScalarToken, 'ScalarToken');
initMetadataForClass(StreamEndToken, 'StreamEndToken');
initMetadataForClass(StreamStartToken, 'StreamStartToken');
initMetadataForClass(TagToken, 'TagToken');
initMetadataForClass(TagTuple, 'TagTuple');
initMetadataForClass(ID_0, 'ID');
initMetadataForClass(ValueToken, 'ValueToken');
//endregion
//region block: init
Companion_instance = new Companion();
UriEncoder_instance = new UriEncoder();
Companion_instance_3 = new Companion_3();
Companion_instance_4 = new Companion_4();
Companion_instance_10 = new Companion_10();
Companion_instance_11 = new Companion_11();
//endregion
//region block: exports
export {
  ScalarStyle_PLAIN_getInstance as ScalarStyle_PLAIN_getInstance1obdwln5ua0w3,
  ID_DocumentEnd_getInstance as ID_DocumentEnd_getInstancex65d9aiwrrbl,
  ID_DocumentStart_getInstance as ID_DocumentStart_getInstanceczzq2c0g00no,
  ID_MappingEnd_getInstance as ID_MappingEnd_getInstance1a5lsxz9wd5fg,
  ID_Scalar_getInstance as ID_Scalar_getInstance2s7932vtifxcy,
  ID_SequenceEnd_getInstance as ID_SequenceEnd_getInstanceaarfjmfxap0t,
  ID_StreamEnd_getInstance as ID_StreamEnd_getInstance1robf3bbs8brr,
  ID_StreamStart_getInstance as ID_StreamStart_getInstance29csm9f9x17rl,
  Companion_instance as Companion_instance1ilxrpxzdyjh5,
  AliasEvent as AliasEvent18arfb3x5sd0q,
  ImplicitTuple as ImplicitTuple2t3yly3nn5jjs,
  MappingStartEvent as MappingStartEvent1lr1mcqmcpbry,
  NodeEvent as NodeEvent1xqamwd0s6axm,
  ScalarEvent as ScalarEvent1tfmd4lt1nu9c,
  SequenceStartEvent as SequenceStartEvent27qj1ypmim9wn,
  MarkedYamlEngineException as MarkedYamlEngineExceptionra3nsv6mim88,
  ParserImpl as ParserImpl2xms7a4twiiy,
  StreamReader as StreamReader2jtln3s95380r,
};
//endregion

//# sourceMappingURL=snakeyaml-engine-kmp.mjs.map
