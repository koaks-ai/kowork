import {
  EmptySerializersModule991ju6pz9b79 as EmptySerializersModule,
  Decoder23nde051s631g as Decoder,
  CompositeDecoder2tzm7wpwkr0og as CompositeDecoder,
  SerializerFactory1qv9hivitncuv as SerializerFactory,
  serializer1x79l67jvwntn as serializer,
  InlinePrimitiveDescriptor3i6ccn1a4fw94 as InlinePrimitiveDescriptor,
  SEALED_getInstance15u0wl5f5h4qk as SEALED_getInstance,
  buildSerialDescriptor2873qmkp8r2ib as buildSerialDescriptor,
  KSerializerzf77vz1967fq as KSerializer,
  MapSerializer11kmegt3g5c1g as MapSerializer,
  SerialDescriptor2pelqekb5ic3a as SerialDescriptor,
  ListSerializer1hxuk9dx5n9du as ListSerializer,
  ENUM_getInstance3doea03ve3rgg as ENUM_getInstance,
  STRING_getInstance2gbamclnmtzqa as STRING_getInstance,
  PrimitiveSerialDescriptor3egfp53lutxj2 as PrimitiveSerialDescriptor,
  serializer2lw83vwvpnyms as serializer_0,
  get_isNullable36pbikm8xb7bz as get_isNullable,
  get_isInline5x26qrhi9qs6 as get_isInline,
  get_annotationshjxdbdcl8kmv as get_annotations,
  Encoderqvmrpqtq8hnu as Encoder,
  CompositeEncoderknecpkexzn3v as CompositeEncoder,
  ElementMarker33ojvsajwmzts as ElementMarker,
  SerializationExceptioneqrdve3ts2n9 as SerializationException,
  CLASS_getInstance1ss90e870vddp as CLASS_getInstance,
  LIST_getInstance3iji3zetpdcxm as LIST_getInstance,
  CONTEXTUAL_getInstance40twmib99zqv as CONTEXTUAL_getInstance,
  PolymorphicKindla9gurooefwb as PolymorphicKind,
  PrimitiveKindndgbuh6is7ze as PrimitiveKind,
  MAP_getInstance2l4ulrz8ljw5i as MAP_getInstance,
  ENUMlmq49cvwy4ow as ENUM,
  contextual3hpp1gupsu4al as contextual,
  SerializersModuleCollector3dddz14wd7brg as SerializersModuleCollector,
  SealedClassSerializeriwipiibk55zc as SealedClassSerializer,
  jsonCachedSerialNameslxufy2gu43jt as jsonCachedSerialNames,
  AbstractDecoder35guh02ubh2hm as AbstractDecoder,
  AbstractPolymorphicSerializer1ccxwp48nfy58 as AbstractPolymorphicSerializer,
  DeserializationStrategy1z3z5pj9f7zc8 as DeserializationStrategy,
  findPolymorphicSerializer1nm87hvemahcj as findPolymorphicSerializer,
  MissingFieldException24tqif29emcmi as MissingFieldException,
  AbstractEncoder2gxtu3xmy3f8j as AbstractEncoder,
  OBJECT_getInstancee89a3hlgr5ys as OBJECT_getInstance,
  findPolymorphicSerializerk638ixyjovk5 as findPolymorphicSerializer_0,
  SerializationStrategyh6ouydnm6hci as SerializationStrategy,
  serializer3ikrxnm8b29d6 as serializer_1,
  serializer36584sjyg5661 as serializer_2,
  serializer1q7c5q67ysppr as serializer_3,
  NamedValueDecoderzk26ztf92xbq as NamedValueDecoder,
  NamedValueEncoder1lca9edk1lf89 as NamedValueEncoder,
  getContextualDescriptor2n1gf3b895yb8 as getContextualDescriptor,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  VOID7hggqo3abtya as VOID,
  Unit_instance104q5opgivhr8 as Unit_instance,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  equals2au1ep9vhcato as equals,
  toString30pk9tzaqopn as toString_0,
  Enum3alwj03lh1n41 as Enum,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  StringBuildermazzzhj6kkai as StringBuilder,
  hashCodeq5arwsb9dgti as hashCode,
  joinToString1cxrrlmo0chqs as joinToString,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  KtMap140uvy3s5zad8 as KtMap,
  KtList3hktaavzmj137 as KtList,
  numberRangeToNumber25vse2rgp6rs8 as numberRangeToNumber,
  ClosedRangehokgr73im9z3 as ClosedRange,
  isInterface3d6p8outrmvmk as isInterface,
  contains2c50nlxg7en7o as contains,
  toDoubleOrNullkxwozihadygj as toDoubleOrNull,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  toDouble1kn912gjoizjp as toDouble,
  StringCompanionObject_instance2odz3s3zbrixa as StringCompanionObject_instance,
  ArrayList3it5z8td81qkl as ArrayList,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  toLongOrNullutqivezb0wx1 as toLongOrNull,
  toULongOrNullojoyxi0i9tgj as toULongOrNull,
  ULong3f9k7s38t3rfp as ULong,
  Companion_getInstance1poxudqc1ru3p as Companion_getInstance,
  _ULong___get_data__impl__fggpzb1jl4xe0gulani as _ULong___get_data__impl__fggpzb,
  toBooleanStrictOrNull2j0md398tkvbj as toBooleanStrictOrNull,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  lazy2hsh8ze7j6ikd as lazy,
  protoOf180f3jzyo7rfj as protoOf,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  toLongw1zpgk99d84b as toLong,
  _UInt___init__impl__l7qpdl1vpobek1e692 as _UInt___init__impl__l7qpdl,
  UInt__toString_impl_dbgl212oeqkp5cl059g as UInt__toString_impl_dbgl21,
  _ULong___init__impl__c78o9k2uqxdjm6b0lbg as _ULong___init__impl__c78o9k,
  ULong__toString_impl_f9au7k2b7ohj6omvcs4 as ULong__toString_impl_f9au7k,
  _UByte___init__impl__g9hnc415bxbmye0j11o as _UByte___init__impl__g9hnc4,
  UByte__toString_impl_v72jgd49yaowf0kue as UByte__toString_impl_v72jg,
  _UShort___init__impl__jigrne3h2nm35iaibum as _UShort___init__impl__jigrne,
  UShort__toString_impl_edaoee1aumkcln5sauo as UShort__toString_impl_edaoee,
  captureStack1fzi4aczwc4hg as captureStack,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  coerceAtMost322komnqp70ag as coerceAtMost,
  Collection1k04j3hzsbod0 as Collection,
  singleOrNullrknfaxokm1sl as singleOrNull,
  emptyMapr06gerzljqtm as emptyMap,
  getValue48kllevslyh6 as getValue,
  copyOf2ng0t8oizk6it as copyOf,
  copyOf3rutauicler23 as copyOf_0,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  DeepRecursiveFunction3r49v8igsve1g as DeepRecursiveFunction,
  invoke246lvi6tzooz1 as invoke,
  DeepRecursiveScope1pqaydvh4vdcu as DeepRecursiveScope,
  Unitkvevlwgzwiuc as Unit,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  getKClass1s3j9wy1cofik as getKClass,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  substringBefore3n7kj60w69hju as substringBefore,
  removeSuffix3d61x5lsuvuho as removeSuffix,
  substringAfter1hku067gwr5ve as substringAfter,
  contains3ue2qo8xhmpf1 as contains_0,
  plus17rl43at52ays as plus,
  isFinite1tx0gn65nl9tj as isFinite,
  isFinite2t9l5a275mxm6 as isFinite_0,
  toUInt21lx0mz8wkp7c as toUInt,
  _UInt___get_data__impl__f0vqqw9xdox7iecbly as _UInt___get_data__impl__f0vqqw,
  toULong266mnyksbttkw as toULong,
  toUByteh6p4wmqswkrs as toUByte,
  _UByte___get_data__impl__jof9qrfj1ch8mjizvj as _UByte___get_data__impl__jof9qr,
  toUShort7yqspfnhrot4 as toUShort,
  _UShort___get_data__impl__g02459z5yfs6z0kj0 as _UShort___get_data__impl__g0245,
  toString35i91qxh73cps as toString_1,
  Companion_getInstance1z323tr26bmxd as Companion_getInstance_0,
  Companion_getInstance374brtr06v94p as Companion_getInstance_1,
  Companion_getInstanceojp2cj59jqir as Companion_getInstance_2,
  setOf45ia9pnfhe90 as setOf,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  numberToChar93r9buh19yek as numberToChar,
  equals2v6cggk171b6e as equals_0,
  toByte4i43936u611k as toByte,
  startsWith26w8qjqapeeq6 as startsWith,
  single29ec4rh52687r as single,
  Char19o2r8palgjof as Char,
  emptySetcxexqki71qfa as emptySet,
  plus1ogy4liedzq5j as plus_0,
  toInt2q8uldh7sc951 as toInt,
  toList3jhuyej2anx2q as toList,
  throwUninitializedPropertyAccessExceptionyynx7gkm73wd as throwUninitializedPropertyAccessException,
  enumEntries20mr21zbe3az4 as enumEntries,
  last1vo29oleiqj36 as last,
  removeLast3759euu1xvfa3 as removeLast,
  lastIndexOf2d52xhix5ymjr as lastIndexOf,
  Long2qws0ah9gnpki as Long,
  Char__minus_impl_a2frrhem8aw2sny2of as Char__minus_impl_a2frrh,
  numberToLong1a4cndvg6c52s as numberToLong,
  charArray2ujmm1qusno00 as charArray,
  indexOfwa4w6635jewi as indexOf,
  indexOf1xbs558u7wr52 as indexOf_0,
  HashMap1a0ld5kgwhmhv as HashMap,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class Json {
  constructor(configuration, serializersModule) {
    Default_getInstance();
    this.v3l_1 = configuration;
    this.w3l_1 = serializersModule;
    this.x3l_1 = new DescriptorSchemaCache();
  }
  f1y() {
    return this.w3l_1;
  }
  y3l(serializer, value) {
    var result = new JsonToStringWriter();
    try {
      encodeByWriter(this, result, serializer, value);
      return result.toString();
    }finally {
      result.d1i();
    }
  }
  z3l(deserializer, string) {
    var lexer = StringJsonLexer_0(this, string);
    var input = new StreamingJsonDecoder(this, WriteMode_OBJ_getInstance(), lexer, deserializer.h1t(), null);
    var result = input.p1x(deserializer);
    lexer.p3m();
    return result;
  }
  a3m(serializer, value) {
    return writeJson(this, value, serializer);
  }
  b3m(string) {
    return this.z3l(JsonElementSerializer_getInstance(), string);
  }
}
class Default extends Json {
  constructor() {
    Default_instance = null;
    super(new JsonConfiguration(), EmptySerializersModule());
    Default_instance = this;
  }
}
class JsonBuilder {
  constructor(json) {
    this.q3m_1 = json.v3l_1.j3n_1;
    this.r3m_1 = json.v3l_1.o3n_1;
    this.s3m_1 = json.v3l_1.k3n_1;
    this.t3m_1 = json.v3l_1.l3n_1;
    this.u3m_1 = json.v3l_1.n3n_1;
    this.v3m_1 = json.v3l_1.p3n_1;
    this.w3m_1 = json.v3l_1.q3n_1;
    this.x3m_1 = json.v3l_1.s3n_1;
    this.y3m_1 = json.v3l_1.z3n_1;
    this.z3m_1 = json.v3l_1.u3n_1;
    this.a3n_1 = json.v3l_1.v3n_1;
    this.b3n_1 = json.v3l_1.w3n_1;
    this.c3n_1 = json.v3l_1.x3n_1;
    this.d3n_1 = json.v3l_1.y3n_1;
    this.e3n_1 = json.v3l_1.t3n_1;
    this.f3n_1 = json.v3l_1.m3n_1;
    this.g3n_1 = json.v3l_1.r3n_1;
    this.h3n_1 = json.f1y();
  }
  i3n() {
    if (this.g3n_1) {
      // Inline function 'kotlin.require' call
      if (!(this.x3m_1 === 'type')) {
        var message = 'Class discriminator should not be specified when array polymorphism is specified';
        throw IllegalArgumentException.t(toString(message));
      }
      // Inline function 'kotlin.require' call
      if (!this.y3m_1.equals(ClassDiscriminatorMode_POLYMORPHIC_getInstance())) {
        var message_0 = 'useArrayPolymorphism option can only be used if classDiscriminatorMode in a default POLYMORPHIC state.';
        throw IllegalArgumentException.t(toString(message_0));
      }
    }
    if (!this.u3m_1) {
      // Inline function 'kotlin.require' call
      if (!(this.v3m_1 === '    ')) {
        var message_1 = 'Indent should not be specified when default printing mode is used';
        throw IllegalArgumentException.t(toString(message_1));
      }
    } else if (!(this.v3m_1 === '    ')) {
      var tmp3 = this.v3m_1;
      var tmp$ret$7;
      $l$block: {
        // Inline function 'kotlin.text.all' call
        var inductionVariable = 0;
        while (inductionVariable < charSequenceLength(tmp3)) {
          var element = charSequenceGet(tmp3, inductionVariable);
          inductionVariable = inductionVariable + 1 | 0;
          if (!(element === _Char___init__impl__6a9atx(32) || element === _Char___init__impl__6a9atx(9) || element === _Char___init__impl__6a9atx(13) || element === _Char___init__impl__6a9atx(10))) {
            tmp$ret$7 = false;
            break $l$block;
          }
        }
        tmp$ret$7 = true;
      }
      var allWhitespaces = tmp$ret$7;
      // Inline function 'kotlin.require' call
      if (!allWhitespaces) {
        var message_2 = 'Only whitespace, tab, newline and carriage return are allowed as pretty print symbols. Had ' + this.v3m_1;
        throw IllegalArgumentException.t(toString(message_2));
      }
    }
    return new JsonConfiguration(this.q3m_1, this.s3m_1, this.t3m_1, this.f3n_1, this.u3m_1, this.r3m_1, this.v3m_1, this.w3m_1, this.g3n_1, this.x3m_1, this.e3n_1, this.z3m_1, this.a3n_1, this.b3n_1, this.c3n_1, this.d3n_1, this.y3m_1);
  }
}
class JsonImpl extends Json {
  constructor(configuration, module_0) {
    super(configuration, module_0);
    validateConfiguration(this);
  }
}
class JsonClassDiscriminator {}
class JsonIgnoreUnknownKeys {}
class JsonNames {}
class JsonConfiguration {
  constructor(encodeDefaults, ignoreUnknownKeys, isLenient, allowStructuredMapKeys, prettyPrint, explicitNulls, prettyPrintIndent, coerceInputValues, useArrayPolymorphism, classDiscriminator, allowSpecialFloatingPointValues, useAlternativeNames, namingStrategy, decodeEnumsCaseInsensitive, allowTrailingComma, allowComments, classDiscriminatorMode) {
    encodeDefaults = encodeDefaults === VOID ? false : encodeDefaults;
    ignoreUnknownKeys = ignoreUnknownKeys === VOID ? false : ignoreUnknownKeys;
    isLenient = isLenient === VOID ? false : isLenient;
    allowStructuredMapKeys = allowStructuredMapKeys === VOID ? false : allowStructuredMapKeys;
    prettyPrint = prettyPrint === VOID ? false : prettyPrint;
    explicitNulls = explicitNulls === VOID ? true : explicitNulls;
    prettyPrintIndent = prettyPrintIndent === VOID ? '    ' : prettyPrintIndent;
    coerceInputValues = coerceInputValues === VOID ? false : coerceInputValues;
    useArrayPolymorphism = useArrayPolymorphism === VOID ? false : useArrayPolymorphism;
    classDiscriminator = classDiscriminator === VOID ? 'type' : classDiscriminator;
    allowSpecialFloatingPointValues = allowSpecialFloatingPointValues === VOID ? false : allowSpecialFloatingPointValues;
    useAlternativeNames = useAlternativeNames === VOID ? true : useAlternativeNames;
    namingStrategy = namingStrategy === VOID ? null : namingStrategy;
    decodeEnumsCaseInsensitive = decodeEnumsCaseInsensitive === VOID ? false : decodeEnumsCaseInsensitive;
    allowTrailingComma = allowTrailingComma === VOID ? false : allowTrailingComma;
    allowComments = allowComments === VOID ? false : allowComments;
    classDiscriminatorMode = classDiscriminatorMode === VOID ? ClassDiscriminatorMode_POLYMORPHIC_getInstance() : classDiscriminatorMode;
    this.j3n_1 = encodeDefaults;
    this.k3n_1 = ignoreUnknownKeys;
    this.l3n_1 = isLenient;
    this.m3n_1 = allowStructuredMapKeys;
    this.n3n_1 = prettyPrint;
    this.o3n_1 = explicitNulls;
    this.p3n_1 = prettyPrintIndent;
    this.q3n_1 = coerceInputValues;
    this.r3n_1 = useArrayPolymorphism;
    this.s3n_1 = classDiscriminator;
    this.t3n_1 = allowSpecialFloatingPointValues;
    this.u3n_1 = useAlternativeNames;
    this.v3n_1 = namingStrategy;
    this.w3n_1 = decodeEnumsCaseInsensitive;
    this.x3n_1 = allowTrailingComma;
    this.y3n_1 = allowComments;
    this.z3n_1 = classDiscriminatorMode;
  }
  toString() {
    return 'JsonConfiguration(encodeDefaults=' + this.j3n_1 + ', ignoreUnknownKeys=' + this.k3n_1 + ', isLenient=' + this.l3n_1 + ', ' + ('allowStructuredMapKeys=' + this.m3n_1 + ', prettyPrint=' + this.n3n_1 + ', explicitNulls=' + this.o3n_1 + ', ') + ("prettyPrintIndent='" + this.p3n_1 + "', coerceInputValues=" + this.q3n_1 + ', useArrayPolymorphism=' + this.r3n_1 + ', ') + ("classDiscriminator='" + this.s3n_1 + "', allowSpecialFloatingPointValues=" + this.t3n_1 + ', ') + ('useAlternativeNames=' + this.u3n_1 + ', namingStrategy=' + toString_0(this.v3n_1) + ', decodeEnumsCaseInsensitive=' + this.w3n_1 + ', ') + ('allowTrailingComma=' + this.x3n_1 + ', allowComments=' + this.y3n_1 + ', classDiscriminatorMode=' + this.z3n_1.toString() + ')');
  }
}
class ClassDiscriminatorMode extends Enum {}
class JsonDecoder {}
class Companion {
  c3o() {
    return JsonObjectSerializer_getInstance();
  }
}
class JsonElement {}
class JsonObject extends JsonElement {
  constructor(content) {
    super();
    this.d3o_1 = content;
  }
  equals(other) {
    return equals(this.d3o_1, other);
  }
  hashCode() {
    return hashCode(this.d3o_1);
  }
  toString() {
    var tmp = this.d3o_1.l1();
    return joinToString(tmp, ',', '{', '}', VOID, VOID, JsonObject$toString$lambda);
  }
  h1() {
    return this.d3o_1.h1();
  }
  v2f(key) {
    return this.d3o_1.f3(key);
  }
  f3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return false;
    return this.v2f((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  w2f(key) {
    return this.d3o_1.h3(key);
  }
  h3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return null;
    return this.w2f((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  b1() {
    return this.d3o_1.b1();
  }
  i3() {
    return this.d3o_1.i3();
  }
  j3() {
    return this.d3o_1.j3();
  }
  l1() {
    return this.d3o_1.l1();
  }
}
class Companion_0 {
  c3o() {
    return JsonElementSerializer_getInstance();
  }
}
class Companion_1 {}
class JsonArray extends JsonElement {
  constructor(content) {
    super();
    this.e3o_1 = content;
  }
  equals(other) {
    return equals(this.e3o_1, other);
  }
  hashCode() {
    return hashCode(this.e3o_1);
  }
  toString() {
    return joinToString(this.e3o_1, ',', '[', ']');
  }
  h1() {
    return this.e3o_1.h1();
  }
  f3o(element) {
    return this.e3o_1.v2(element);
  }
  v2(element) {
    if (!(element instanceof JsonElement))
      return false;
    return this.f3o(element instanceof JsonElement ? element : THROW_CCE());
  }
  y() {
    return this.e3o_1.y();
  }
  g3o(elements) {
    return this.e3o_1.w2(elements);
  }
  w2(elements) {
    return this.g3o(elements);
  }
  f1(index) {
    return this.e3o_1.f1(index);
  }
  h3o(element) {
    return this.e3o_1.x2(element);
  }
  x2(element) {
    if (!(element instanceof JsonElement))
      return -1;
    return this.h3o(element instanceof JsonElement ? element : THROW_CCE());
  }
  i1(index) {
    return this.e3o_1.i1(index);
  }
  y2(fromIndex, toIndex) {
    return this.e3o_1.y2(fromIndex, toIndex);
  }
  b1() {
    return this.e3o_1.b1();
  }
}
class JsonPrimitive extends JsonElement {
  toString() {
    return this.j3o();
  }
}
class JsonNull extends JsonPrimitive {
  constructor() {
    JsonNull_instance = null;
    super();
    JsonNull_instance = this;
    this.i3o_1 = 'null';
  }
  j3o() {
    return this.i3o_1;
  }
  c3o() {
    return JsonNullSerializer_getInstance();
  }
  g26(typeParamsSerializers) {
    return this.c3o();
  }
}
class Companion_2 {}
class JsonLiteral extends JsonPrimitive {
  constructor(body, isString, coerceToInlineType) {
    coerceToInlineType = coerceToInlineType === VOID ? null : coerceToInlineType;
    super();
    this.k3o_1 = isString;
    this.l3o_1 = coerceToInlineType;
    this.m3o_1 = toString(body);
    if (!(this.l3o_1 == null)) {
      // Inline function 'kotlin.require' call
      // Inline function 'kotlin.require' call
      if (!this.l3o_1.v1v()) {
        var message = 'Failed requirement.';
        throw IllegalArgumentException.t(toString(message));
      }
    }
  }
  j3o() {
    return this.m3o_1;
  }
  toString() {
    var tmp;
    if (this.k3o_1) {
      // Inline function 'kotlin.text.buildString' call
      // Inline function 'kotlin.apply' call
      var this_0 = StringBuilder.v();
      printQuoted(this_0, this.m3o_1);
      tmp = this_0.toString();
    } else {
      tmp = this.m3o_1;
    }
    return tmp;
  }
  equals(other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof JsonLiteral))
      THROW_CCE();
    if (!(this.k3o_1 === other.k3o_1))
      return false;
    if (!(this.m3o_1 === other.m3o_1))
      return false;
    return true;
  }
  hashCode() {
    var result = getBooleanHashCode(this.k3o_1);
    result = imul(31, result) + getStringHashCode(this.m3o_1) | 0;
    return result;
  }
}
class JsonArrayBuilder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.o3o_1 = ArrayList.k();
  }
  p3o(element) {
    // Inline function 'kotlin.collections.plusAssign' call
    this.o3o_1.l(element);
    return true;
  }
  i3n() {
    return new JsonArray(this.o3o_1);
  }
}
class JsonObjectBuilder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.linkedMapOf' call
    tmp.q3o_1 = LinkedHashMap.hc();
  }
  r3o(key, element) {
    return this.q3o_1.k3(key, element);
  }
  i3n() {
    return new JsonObject(this.q3o_1);
  }
}
class JsonElementSerializer {
  constructor() {
    JsonElementSerializer_instance = this;
    var tmp = this;
    var tmp_0 = SEALED_getInstance();
    tmp.x3o_1 = buildSerialDescriptor('kotlinx.serialization.json.JsonElement', tmp_0, [], JsonElementSerializer$descriptor$lambda);
  }
  h1t() {
    return this.x3o_1;
  }
  y3o(encoder, value) {
    verify(encoder);
    if (value instanceof JsonPrimitive) {
      encoder.j1z(JsonPrimitiveSerializer_getInstance(), value);
    } else {
      if (value instanceof JsonObject) {
        encoder.j1z(JsonObjectSerializer_getInstance(), value);
      } else {
        if (value instanceof JsonArray) {
          encoder.j1z(JsonArraySerializer_getInstance(), value);
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  i1t(encoder, value) {
    return this.y3o(encoder, value instanceof JsonElement ? value : THROW_CCE());
  }
  j1t(decoder) {
    var input = asJsonDecoder(decoder);
    return input.b3o();
  }
}
class JsonObjectDescriptor {
  constructor() {
    JsonObjectDescriptor_instance = this;
    this.z3o_1 = MapSerializer(serializer(StringCompanionObject_instance), JsonElementSerializer_getInstance()).h1t();
    this.a3p_1 = 'kotlinx.serialization.json.JsonObject';
  }
  k1u() {
    return this.a3p_1;
  }
  y1v(index) {
    return this.z3o_1.y1v(index);
  }
  z1v(name) {
    return this.z3o_1.z1v(name);
  }
  a1w(index) {
    return this.z3o_1.a1w(index);
  }
  b1w(index) {
    return this.z3o_1.b1w(index);
  }
  c1w(index) {
    return this.z3o_1.c1w(index);
  }
  u1v() {
    return this.z3o_1.u1v();
  }
  q1v() {
    return this.z3o_1.q1v();
  }
  v1v() {
    return this.z3o_1.v1v();
  }
  w1v() {
    return this.z3o_1.w1v();
  }
  x1v() {
    return this.z3o_1.x1v();
  }
}
class JsonObjectSerializer {
  constructor() {
    JsonObjectSerializer_instance = this;
    this.v3o_1 = JsonObjectDescriptor_getInstance();
  }
  h1t() {
    return this.v3o_1;
  }
  b3p(encoder, value) {
    verify(encoder);
    MapSerializer(serializer(StringCompanionObject_instance), JsonElementSerializer_getInstance()).i1t(encoder, value);
  }
  i1t(encoder, value) {
    return this.b3p(encoder, value instanceof JsonObject ? value : THROW_CCE());
  }
  j1t(decoder) {
    verify_0(decoder);
    return new JsonObject(MapSerializer(serializer(StringCompanionObject_instance), JsonElementSerializer_getInstance()).j1t(decoder));
  }
}
class JsonArrayDescriptor {
  constructor() {
    JsonArrayDescriptor_instance = this;
    this.c3p_1 = ListSerializer(JsonElementSerializer_getInstance()).h1t();
    this.d3p_1 = 'kotlinx.serialization.json.JsonArray';
  }
  k1u() {
    return this.d3p_1;
  }
  y1v(index) {
    return this.c3p_1.y1v(index);
  }
  z1v(name) {
    return this.c3p_1.z1v(name);
  }
  a1w(index) {
    return this.c3p_1.a1w(index);
  }
  b1w(index) {
    return this.c3p_1.b1w(index);
  }
  c1w(index) {
    return this.c3p_1.c1w(index);
  }
  u1v() {
    return this.c3p_1.u1v();
  }
  q1v() {
    return this.c3p_1.q1v();
  }
  v1v() {
    return this.c3p_1.v1v();
  }
  w1v() {
    return this.c3p_1.w1v();
  }
  x1v() {
    return this.c3p_1.x1v();
  }
}
class JsonArraySerializer {
  constructor() {
    JsonArraySerializer_instance = this;
    this.w3o_1 = JsonArrayDescriptor_getInstance();
  }
  h1t() {
    return this.w3o_1;
  }
  e3p(encoder, value) {
    verify(encoder);
    ListSerializer(JsonElementSerializer_getInstance()).i1t(encoder, value);
  }
  i1t(encoder, value) {
    return this.e3p(encoder, value instanceof JsonArray ? value : THROW_CCE());
  }
  j1t(decoder) {
    verify_0(decoder);
    return new JsonArray(ListSerializer(JsonElementSerializer_getInstance()).j1t(decoder));
  }
}
class JsonNullSerializer {
  constructor() {
    JsonNullSerializer_instance = this;
    this.t3o_1 = buildSerialDescriptor('kotlinx.serialization.json.JsonNull', ENUM_getInstance(), []);
  }
  h1t() {
    return this.t3o_1;
  }
  f3p(encoder, value) {
    verify(encoder);
    encoder.m1y();
  }
  i1t(encoder, value) {
    return this.f3p(encoder, value instanceof JsonNull ? value : THROW_CCE());
  }
  j1t(decoder) {
    verify_0(decoder);
    if (decoder.b1x()) {
      throw JsonDecodingException.m3p("Expected 'null' literal");
    }
    decoder.c1x();
    return JsonNull_getInstance();
  }
}
class JsonPrimitiveSerializer {
  constructor() {
    JsonPrimitiveSerializer_instance = this;
    this.s3o_1 = buildSerialDescriptor('kotlinx.serialization.json.JsonPrimitive', STRING_getInstance(), []);
  }
  h1t() {
    return this.s3o_1;
  }
  n3p(encoder, value) {
    verify(encoder);
    var tmp;
    if (value instanceof JsonNull) {
      encoder.j1z(JsonNullSerializer_getInstance(), JsonNull_getInstance());
      tmp = Unit_instance;
    } else {
      var tmp_0 = JsonLiteralSerializer_getInstance();
      encoder.j1z(tmp_0, value instanceof JsonLiteral ? value : THROW_CCE());
      tmp = Unit_instance;
    }
    return tmp;
  }
  i1t(encoder, value) {
    return this.n3p(encoder, value instanceof JsonPrimitive ? value : THROW_CCE());
  }
  j1t(decoder) {
    var result = asJsonDecoder(decoder).b3o();
    if (!(result instanceof JsonPrimitive))
      throw JsonDecodingException_0(-1, 'Unexpected JSON element, expected JsonPrimitive, had ' + toString(getKClassFromExpression(result)), toString(result));
    return result;
  }
}
class JsonLiteralSerializer {
  constructor() {
    JsonLiteralSerializer_instance = this;
    this.u3o_1 = PrimitiveSerialDescriptor('kotlinx.serialization.json.JsonLiteral', STRING_getInstance());
  }
  h1t() {
    return this.u3o_1;
  }
  o3p(encoder, value) {
    verify(encoder);
    if (value.k3o_1) {
      return encoder.v1y(value.m3o_1);
    }
    if (!(value.l3o_1 == null)) {
      return encoder.x1y(value.l3o_1).v1y(value.m3o_1);
    }
    var tmp0_safe_receiver = toLongOrNull(value.m3o_1);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return encoder.r1y(tmp0_safe_receiver);
    }
    var tmp1_safe_receiver = toULongOrNull(value.m3o_1);
    var tmp = tmp1_safe_receiver;
    if ((tmp == null ? null : new ULong(tmp)) == null)
      null;
    else {
      var tmp_0 = tmp1_safe_receiver;
      // Inline function 'kotlin.let' call
      var it = (tmp_0 == null ? null : new ULong(tmp_0)).kt_1;
      var tmp_1 = encoder.x1y(serializer_0(Companion_getInstance()).h1t());
      // Inline function 'kotlin.ULong.toLong' call
      var tmp$ret$1 = _ULong___get_data__impl__fggpzb(it);
      tmp_1.r1y(tmp$ret$1);
      return Unit_instance;
    }
    var tmp2_safe_receiver = toDoubleOrNull(value.m3o_1);
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return encoder.t1y(tmp2_safe_receiver);
    }
    var tmp3_safe_receiver = toBooleanStrictOrNull(value.m3o_1);
    if (tmp3_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return encoder.n1y(tmp3_safe_receiver);
    }
    encoder.v1y(value.m3o_1);
  }
  i1t(encoder, value) {
    return this.o3p(encoder, value instanceof JsonLiteral ? value : THROW_CCE());
  }
  j1t(decoder) {
    var result = asJsonDecoder(decoder).b3o();
    if (!(result instanceof JsonLiteral))
      throw JsonDecodingException_0(-1, 'Unexpected JSON element, expected JsonLiteral, had ' + toString(getKClassFromExpression(result)), toString(result));
    return result;
  }
}
class defer$1 {
  constructor($deferred) {
    this.p3p_1 = lazy($deferred);
  }
  k1u() {
    return _get_original__l7ku1m(this).k1u();
  }
  u1v() {
    return _get_original__l7ku1m(this).u1v();
  }
  w1v() {
    return _get_original__l7ku1m(this).w1v();
  }
  y1v(index) {
    return _get_original__l7ku1m(this).y1v(index);
  }
  z1v(name) {
    return _get_original__l7ku1m(this).z1v(name);
  }
  a1w(index) {
    return _get_original__l7ku1m(this).a1w(index);
  }
  b1w(index) {
    return _get_original__l7ku1m(this).b1w(index);
  }
  c1w(index) {
    return _get_original__l7ku1m(this).c1w(index);
  }
}
class JsonEncoder {}
class Composer {
  constructor(writer) {
    this.q3p_1 = writer;
    this.r3p_1 = true;
  }
  s3p() {
    this.r3p_1 = true;
  }
  t3p() {
    return Unit_instance;
  }
  u3p() {
    this.r3p_1 = false;
  }
  v3p() {
    this.r3p_1 = false;
  }
  w3p() {
    return Unit_instance;
  }
  x3p(v) {
    return this.q3p_1.y3p(v);
  }
  z3p(v) {
    return this.q3p_1.a3q(v);
  }
  b3q(v) {
    return this.q3p_1.a3q(v.toString());
  }
  c3q(v) {
    return this.q3p_1.a3q(v.toString());
  }
  d3q(v) {
    return this.q3p_1.e3q(toLong(v));
  }
  f3q(v) {
    return this.q3p_1.e3q(toLong(v));
  }
  g3q(v) {
    return this.q3p_1.e3q(toLong(v));
  }
  h3q(v) {
    return this.q3p_1.e3q(v);
  }
  i3q(v) {
    return this.q3p_1.a3q(v.toString());
  }
  j3q(value) {
    return this.q3p_1.k3q(value);
  }
}
class ComposerForUnsignedNumbers extends Composer {
  constructor(writer, forceQuoting) {
    super(writer);
    this.n3q_1 = forceQuoting;
  }
  g3q(v) {
    if (this.n3q_1) {
      // Inline function 'kotlin.toUInt' call
      var tmp$ret$0 = _UInt___init__impl__l7qpdl(v);
      this.j3q(UInt__toString_impl_dbgl21(tmp$ret$0));
    } else {
      // Inline function 'kotlin.toUInt' call
      var tmp$ret$1 = _UInt___init__impl__l7qpdl(v);
      this.z3p(UInt__toString_impl_dbgl21(tmp$ret$1));
    }
  }
  h3q(v) {
    if (this.n3q_1) {
      // Inline function 'kotlin.toULong' call
      var tmp$ret$0 = _ULong___init__impl__c78o9k(v);
      this.j3q(ULong__toString_impl_f9au7k(tmp$ret$0));
    } else {
      // Inline function 'kotlin.toULong' call
      var tmp$ret$1 = _ULong___init__impl__c78o9k(v);
      this.z3p(ULong__toString_impl_f9au7k(tmp$ret$1));
    }
  }
  d3q(v) {
    if (this.n3q_1) {
      // Inline function 'kotlin.toUByte' call
      var tmp$ret$0 = _UByte___init__impl__g9hnc4(v);
      this.j3q(UByte__toString_impl_v72jg(tmp$ret$0));
    } else {
      // Inline function 'kotlin.toUByte' call
      var tmp$ret$1 = _UByte___init__impl__g9hnc4(v);
      this.z3p(UByte__toString_impl_v72jg(tmp$ret$1));
    }
  }
  f3q(v) {
    if (this.n3q_1) {
      // Inline function 'kotlin.toUShort' call
      var tmp$ret$0 = _UShort___init__impl__jigrne(v);
      this.j3q(UShort__toString_impl_edaoee(tmp$ret$0));
    } else {
      // Inline function 'kotlin.toUShort' call
      var tmp$ret$1 = _UShort___init__impl__jigrne(v);
      this.z3p(UShort__toString_impl_edaoee(tmp$ret$1));
    }
  }
}
class ComposerForUnquotedLiterals extends Composer {
  constructor(writer, forceQuoting) {
    super(writer);
    this.q3q_1 = forceQuoting;
  }
  j3q(value) {
    if (this.q3q_1) {
      super.j3q(value);
    } else {
      super.z3p(value);
    }
  }
}
class ComposerWithPrettyPrint extends Composer {
  constructor(writer, json) {
    super(writer);
    this.t3q_1 = json;
    this.u3q_1 = 0;
  }
  s3p() {
    this.r3p_1 = true;
    this.u3q_1 = this.u3q_1 + 1 | 0;
  }
  t3p() {
    this.u3q_1 = this.u3q_1 - 1 | 0;
  }
  u3p() {
    this.r3p_1 = false;
    this.z3p('\n');
    // Inline function 'kotlin.repeat' call
    var times = this.u3q_1;
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.z3p(this.t3q_1.v3l_1.p3n_1);
      }
       while (inductionVariable < times);
  }
  v3p() {
    if (this.r3p_1)
      this.r3p_1 = false;
    else {
      this.u3p();
    }
  }
  w3p() {
    this.x3p(_Char___init__impl__6a9atx(32));
  }
}
class JsonElementMarker {
  constructor(descriptor) {
    var tmp = this;
    tmp.v3q_1 = new ElementMarker(descriptor, JsonElementMarker$readIfAbsent$ref(this));
    this.w3q_1 = false;
  }
  x3q(index) {
    this.v3q_1.x23(index);
  }
  y3q() {
    return this.v3q_1.y23();
  }
}
class JsonException extends SerializationException {
  static e3r(message) {
    var $this = this.t1u(message);
    captureStack($this, $this.d3r_1);
    return $this;
  }
}
class JsonDecodingException extends JsonException {
  static m3p(message) {
    var $this = this.e3r(message);
    captureStack($this, $this.l3p_1);
    return $this;
  }
}
class JsonEncodingException extends JsonException {
  static n3r(message) {
    var $this = this.e3r(message);
    captureStack($this, $this.m3r_1);
    return $this;
  }
}
class Tombstone {}
class JsonPath {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.arrayOfNulls' call
    tmp.s3r_1 = Array(8);
    var tmp_0 = this;
    var tmp_1 = 0;
    var tmp_2 = new Int32Array(8);
    while (tmp_1 < 8) {
      tmp_2[tmp_1] = -1;
      tmp_1 = tmp_1 + 1 | 0;
    }
    tmp_0.t3r_1 = tmp_2;
    this.u3r_1 = -1;
  }
  v3r(sd) {
    this.u3r_1 = this.u3r_1 + 1 | 0;
    var depth = this.u3r_1;
    if (depth === this.s3r_1.length) {
      resize(this);
    }
    this.s3r_1[depth] = sd;
  }
  w3r(index) {
    this.t3r_1[this.u3r_1] = index;
  }
  x3r(key) {
    var tmp;
    if (!(this.t3r_1[this.u3r_1] === -2)) {
      this.u3r_1 = this.u3r_1 + 1 | 0;
      tmp = this.u3r_1 === this.s3r_1.length;
    } else {
      tmp = false;
    }
    if (tmp) {
      resize(this);
    }
    this.s3r_1[this.u3r_1] = key;
    this.t3r_1[this.u3r_1] = -2;
  }
  y3r() {
    if (this.t3r_1[this.u3r_1] === -2) {
      this.s3r_1[this.u3r_1] = Tombstone_instance;
    }
  }
  z3r() {
    var depth = this.u3r_1;
    if (this.t3r_1[depth] === -2) {
      this.t3r_1[depth] = -1;
      this.u3r_1 = this.u3r_1 - 1 | 0;
    }
    if (!(this.u3r_1 === -1)) {
      this.u3r_1 = this.u3r_1 - 1 | 0;
    }
  }
  a3s() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb('$');
    // Inline function 'kotlin.repeat' call
    var times = this.u3r_1 + 1 | 0;
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var element = this.s3r_1[index];
        if (!(element == null) ? isInterface(element, SerialDescriptor) : false) {
          if (equals(element.u1v(), LIST_getInstance())) {
            if (!(this.t3r_1[index] === -1)) {
              this_0.tb('[');
              this_0.fh(this.t3r_1[index]);
              this_0.tb(']');
            }
          } else {
            var idx = this.t3r_1[index];
            if (idx >= 0) {
              this_0.tb('.');
              this_0.tb(element.y1v(idx));
            }
          }
        } else {
          if (!(element === Tombstone_instance)) {
            this_0.tb('[');
            this_0.tb("'");
            this_0.sb(element);
            this_0.tb("'");
            this_0.tb(']');
          }
        }
      }
       while (inductionVariable < times);
    return this_0.toString();
  }
  toString() {
    return this.a3s();
  }
}
class JsonSerializersModuleValidator {
  constructor(configuration) {
    this.b3s_1 = configuration.s3n_1;
    this.c3s_1 = configuration.r3n_1;
    this.d3s_1 = !configuration.z3n_1.equals(ClassDiscriminatorMode_NONE_getInstance());
  }
  a2f(kClass, provider) {
  }
  d2f(baseClass, actualClass, actualSerializer) {
    var descriptor = actualSerializer.h1t();
    checkKind(this, descriptor, actualClass);
    if (!this.c3s_1 && this.d3s_1) {
      checkDiscriminatorCollisions(this, descriptor, actualClass);
    }
  }
  e2f(baseClass, defaultSerializerProvider) {
  }
  f2f(baseClass, defaultDeserializerProvider) {
  }
}
class JsonTreeReader$readDeepRecursive$slambda {
  constructor(this$0) {
    this.s3s_1 = this$0;
  }
  a3t($this$DeepRecursiveFunction, it, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8.bind(VOID, this, $this$DeepRecursiveFunction, it), $completion);
  }
  ud(p1, p2, $completion) {
    var tmp = p1 instanceof DeepRecursiveScope ? p1 : THROW_CCE();
    return this.a3t(tmp, p2 instanceof Unit ? p2 : THROW_CCE(), $completion);
  }
}
class JsonTreeReader {
  constructor(configuration, lexer) {
    this.o3s_1 = lexer;
    this.p3s_1 = configuration.l3n_1;
    this.q3s_1 = configuration.x3n_1;
    this.r3s_1 = 0;
  }
  y3s() {
    var token = this.o3s_1.t3s();
    var tmp;
    if (token === 1) {
      tmp = readValue(this, true);
    } else if (token === 0) {
      tmp = readValue(this, false);
    } else if (token === 6) {
      var tmp_0;
      this.r3s_1 = this.r3s_1 + 1 | 0;
      if (this.r3s_1 === 200) {
        tmp_0 = readDeepRecursive(this);
      } else {
        tmp_0 = readObject(this);
      }
      var result = tmp_0;
      this.r3s_1 = this.r3s_1 - 1 | 0;
      tmp = result;
    } else if (token === 8) {
      tmp = readArray(this);
    } else {
      this.o3s_1.g3r('Cannot read Json element because of unexpected ' + tokenDescription(token));
    }
    return tmp;
  }
}
class Key {}
class DescriptorSchemaCache {
  constructor() {
    this.o3r_1 = createMapForCache(16);
  }
  c3t(descriptor, key, value) {
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.o3r_1;
    var value_0 = this_0.h3(descriptor);
    var tmp;
    if (value_0 == null) {
      var answer = createMapForCache(2);
      this_0.k3(descriptor, answer);
      tmp = answer;
    } else {
      tmp = value_0;
    }
    var tmp2 = tmp;
    var tmp3 = key instanceof Key ? key : THROW_CCE();
    // Inline function 'kotlin.collections.set' call
    var value_1 = !(value == null) ? value : THROW_CCE();
    tmp2.k3(tmp3, value_1);
  }
  p3r(descriptor, key, defaultValue) {
    var tmp0_safe_receiver = this.d3t(descriptor, key);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var value = defaultValue();
    this.c3t(descriptor, key, value);
    return value;
  }
  d3t(descriptor, key) {
    var tmp0_safe_receiver = this.o3r_1.h3(descriptor);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      tmp = tmp0_safe_receiver.h3(key instanceof Key ? key : THROW_CCE());
    }
    var tmp_0 = tmp;
    return !(tmp_0 == null) ? tmp_0 : null;
  }
}
class DiscriminatorHolder {
  constructor(discriminatorToSkip) {
    this.e3t_1 = discriminatorToSkip;
  }
}
class StreamingJsonDecoder extends AbstractDecoder {
  constructor(json, mode, lexer, descriptor, discriminatorHolder) {
    super();
    this.d3m_1 = json;
    this.e3m_1 = mode;
    this.f3m_1 = lexer;
    this.g3m_1 = this.d3m_1.f1y();
    this.h3m_1 = -1;
    this.i3m_1 = discriminatorHolder;
    this.j3m_1 = this.d3m_1.v3l_1;
    this.k3m_1 = this.j3m_1.o3n_1 ? null : new JsonElementMarker(descriptor);
  }
  a3o() {
    return this.d3m_1;
  }
  f1y() {
    return this.g3m_1;
  }
  b3o() {
    return (new JsonTreeReader(this.d3m_1.v3l_1, this.f3m_1)).y3s();
  }
  p1x(deserializer) {
    try {
      var tmp;
      if (!(deserializer instanceof AbstractPolymorphicSerializer)) {
        tmp = true;
      } else {
        tmp = this.d3m_1.v3l_1.r3n_1;
      }
      if (tmp) {
        return deserializer.j1t(this);
      }
      var discriminator = classDiscriminator(deserializer.h1t(), this.d3m_1);
      var tmp0_elvis_lhs = this.f3m_1.n3t(discriminator, this.j3m_1.l3n_1);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        var tmp1 = isInterface(deserializer, DeserializationStrategy) ? deserializer : THROW_CCE();
        var tmp$ret$0;
        $l$block: {
          // Inline function 'kotlinx.serialization.json.internal.decodeSerializableValuePolymorphic' call
          var tmp_1;
          if (!(tmp1 instanceof AbstractPolymorphicSerializer)) {
            tmp_1 = true;
          } else {
            tmp_1 = this.a3o().v3l_1.r3n_1;
          }
          if (tmp_1) {
            tmp$ret$0 = tmp1.j1t(this);
            break $l$block;
          }
          var discriminator_0 = classDiscriminator(tmp1.h1t(), this.a3o());
          var tmp0 = this.b3o();
          // Inline function 'kotlinx.serialization.json.internal.cast' call
          var serialName = tmp1.h1t().k1u();
          if (!(tmp0 instanceof JsonObject)) {
            var tmp_2 = getKClass(JsonObject).hf();
            var tmp_3 = getKClassFromExpression(tmp0).hf();
            var tmp$ret$1 = this.f3m_1.m3m_1.a3s();
            throw JsonDecodingException_0(-1, 'Expected ' + tmp_2 + ', but had ' + tmp_3 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$1, toString(tmp0));
          }
          var jsonTree = tmp0;
          var tmp0_safe_receiver = jsonTree.w2f(discriminator_0);
          var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
          var type = tmp1_safe_receiver == null ? null : get_contentOrNull(tmp1_safe_receiver);
          var tmp_4;
          try {
            tmp_4 = findPolymorphicSerializer(tmp1, this, type);
          } catch ($p) {
            var tmp_5;
            if ($p instanceof SerializationException) {
              var it = $p;
              throw JsonDecodingException_0(-1, ensureNotNull(it.message), jsonTree.toString());
            } else {
              throw $p;
            }
          }
          var tmp_6 = tmp_4;
          var actualSerializer = isInterface(tmp_6, DeserializationStrategy) ? tmp_6 : THROW_CCE();
          tmp$ret$0 = readPolymorphicJson(this.a3o(), discriminator_0, jsonTree, actualSerializer);
        }
        return tmp$ret$0;
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      var type_0 = tmp_0;
      var tmp_7;
      try {
        tmp_7 = findPolymorphicSerializer(deserializer, this, type_0);
      } catch ($p) {
        var tmp_8;
        if ($p instanceof SerializationException) {
          var it_0 = $p;
          var message = removeSuffix(substringBefore(ensureNotNull(it_0.message), _Char___init__impl__6a9atx(10)), '.');
          var hint = substringAfter(ensureNotNull(it_0.message), _Char___init__impl__6a9atx(10), '');
          this.f3m_1.g3r(message, VOID, hint);
        } else {
          throw $p;
        }
        tmp_7 = tmp_8;
      }
      var tmp_9 = tmp_7;
      var actualSerializer_0 = isInterface(tmp_9, DeserializationStrategy) ? tmp_9 : THROW_CCE();
      this.i3m_1 = new DiscriminatorHolder(discriminator);
      return actualSerializer_0.j1t(this);
    } catch ($p) {
      if ($p instanceof MissingFieldException) {
        var e = $p;
        if (contains_0(ensureNotNull(e.message), 'at path'))
          throw e;
        throw MissingFieldException.b1v(e.z1u_1, plus(e.message, ' at path: ') + this.f3m_1.m3m_1.a3s(), e);
      } else {
        throw $p;
      }
    }
  }
  q1x(descriptor) {
    var newMode = switchMode(this.d3m_1, descriptor);
    this.f3m_1.m3m_1.v3r(descriptor);
    this.f3m_1.f3t(newMode.q3t_1);
    checkLeadingComma(this);
    var tmp;
    switch (newMode.o3_1) {
      case 1:
      case 2:
      case 3:
        tmp = new StreamingJsonDecoder(this.d3m_1, newMode, this.f3m_1, descriptor, this.i3m_1);
        break;
      default:
        var tmp_0;
        if (this.e3m_1.equals(newMode) && this.d3m_1.v3l_1.o3n_1) {
          tmp_0 = this;
        } else {
          tmp_0 = new StreamingJsonDecoder(this.d3m_1, newMode, this.f3m_1, descriptor, this.i3m_1);
        }

        tmp = tmp_0;
        break;
    }
    return tmp;
  }
  r1x(descriptor) {
    if (descriptor.w1v() === 0 && ignoreUnknownKeys(descriptor, this.d3m_1)) {
      skipLeftoverElements(this, descriptor);
    }
    if (this.f3m_1.g3t() && !this.d3m_1.v3l_1.x3n_1) {
      invalidTrailingComma(this.f3m_1, '');
    }
    this.f3m_1.f3t(this.e3m_1.r3t_1);
    this.f3m_1.m3m_1.z3r();
  }
  b1x() {
    var tmp;
    var tmp0_safe_receiver = this.k3m_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.w3q_1;
    if (!(tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs)) {
      tmp = !this.f3m_1.s3t();
    } else {
      tmp = false;
    }
    return tmp;
  }
  c1x() {
    return null;
  }
  c1y(descriptor, index, deserializer, previousValue) {
    var isMapKey = this.e3m_1.equals(WriteMode_MAP_getInstance()) && (index & 1) === 0;
    if (isMapKey) {
      this.f3m_1.m3m_1.y3r();
    }
    var value = super.c1y(descriptor, index, deserializer, previousValue);
    if (isMapKey) {
      this.f3m_1.m3m_1.x3r(value);
    }
    return value;
  }
  h1y(descriptor) {
    var index;
    switch (this.e3m_1.o3_1) {
      case 0:
        index = decodeObjectIndex(this, descriptor);
        break;
      case 2:
        index = decodeMapIndex(this);
        break;
      default:
        index = decodeListIndex(this);
        break;
    }
    if (!this.e3m_1.equals(WriteMode_MAP_getInstance())) {
      this.f3m_1.m3m_1.w3r(index);
    }
    return index;
  }
  d1x() {
    return this.f3m_1.t3t();
  }
  e1x() {
    var value = this.f3m_1.u3t();
    if (!value.equals(toLong(value.k4()))) {
      this.f3m_1.g3r("Failed to parse byte for input '" + value.toString() + "'");
    }
    return value.k4();
  }
  f1x() {
    var value = this.f3m_1.u3t();
    if (!value.equals(toLong(value.l4()))) {
      this.f3m_1.g3r("Failed to parse short for input '" + value.toString() + "'");
    }
    return value.l4();
  }
  g1x() {
    var value = this.f3m_1.u3t();
    if (!value.equals(toLong(value.x1()))) {
      this.f3m_1.g3r("Failed to parse int for input '" + value.toString() + "'");
    }
    return value.x1();
  }
  h1x() {
    return this.f3m_1.u3t();
  }
  i1x() {
    var tmp0 = this.f3m_1;
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.x3s();
      try {
        // Inline function 'kotlin.text.toFloat' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$4 = toDouble(input);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.g3r("Failed to parse type '" + 'float' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    var result = tmp$ret$4;
    var specialFp = this.d3m_1.v3l_1.t3n_1;
    if (specialFp || isFinite(result))
      return result;
    throwInvalidFloatingPointDecoded(this.f3m_1, result);
  }
  j1x() {
    var tmp0 = this.f3m_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.x3s();
      try {
        tmp$ret$1 = toDouble(input);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.g3r("Failed to parse type '" + 'double' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    var result = tmp$ret$1;
    var specialFp = this.d3m_1.v3l_1.t3n_1;
    if (specialFp || isFinite_0(result))
      return result;
    throwInvalidFloatingPointDecoded(this.f3m_1, result);
  }
  k1x() {
    var string = this.f3m_1.x3s();
    if (!(string.length === 1)) {
      this.f3m_1.g3r("Expected single char, but got '" + string + "'");
    }
    return charSequenceGet(string, 0);
  }
  l1x() {
    var tmp;
    if (this.j3m_1.l3n_1) {
      tmp = this.f3m_1.m3t();
    } else {
      tmp = this.f3m_1.w3s();
    }
    return tmp;
  }
  n1x(descriptor) {
    return get_isUnsignedNumber(descriptor) ? new JsonDecoderForUnsignedTypes(this.f3m_1, this.d3m_1) : super.n1x(descriptor);
  }
  m1x(enumDescriptor) {
    return getJsonNameIndexOrThrow(enumDescriptor, this.d3m_1, this.l1x(), ' at path ' + this.f3m_1.m3m_1.a3s());
  }
}
class JsonDecoderForUnsignedTypes extends AbstractDecoder {
  constructor(lexer, json) {
    super();
    this.v3t_1 = lexer;
    this.w3t_1 = json.f1y();
  }
  f1y() {
    return this.w3t_1;
  }
  h1y(descriptor) {
    var message = 'unsupported';
    throw IllegalStateException.t4(toString(message));
  }
  g1x() {
    var tmp0 = this.v3t_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.x3s();
      try {
        // Inline function 'kotlin.UInt.toInt' call
        var this_0 = toUInt(input);
        tmp$ret$2 = _UInt___get_data__impl__f0vqqw(this_0);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.g3r("Failed to parse type '" + 'UInt' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$2;
  }
  h1x() {
    var tmp0 = this.v3t_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.x3s();
      try {
        // Inline function 'kotlin.ULong.toLong' call
        var this_0 = toULong(input);
        tmp$ret$2 = _ULong___get_data__impl__fggpzb(this_0);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.g3r("Failed to parse type '" + 'ULong' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$2;
  }
  e1x() {
    var tmp0 = this.v3t_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.x3s();
      try {
        // Inline function 'kotlin.UByte.toByte' call
        var this_0 = toUByte(input);
        tmp$ret$2 = _UByte___get_data__impl__jof9qr(this_0);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.g3r("Failed to parse type '" + 'UByte' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$2;
  }
  f1x() {
    var tmp0 = this.v3t_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.x3s();
      try {
        // Inline function 'kotlin.UShort.toShort' call
        var this_0 = toUShort(input);
        tmp$ret$2 = _UShort___get_data__impl__g0245(this_0);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.g3r("Failed to parse type '" + 'UShort' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$2;
  }
}
class StreamingJsonEncoder extends AbstractEncoder {
  static x3t(composer, json, mode, modeReuseCache) {
    var $this = this.j1y();
    $this.e3s_1 = composer;
    $this.f3s_1 = json;
    $this.g3s_1 = mode;
    $this.h3s_1 = modeReuseCache;
    $this.i3s_1 = $this.f3s_1.f1y();
    $this.j3s_1 = $this.f3s_1.v3l_1;
    $this.k3s_1 = false;
    $this.l3s_1 = null;
    $this.m3s_1 = null;
    var i = $this.g3s_1.o3_1;
    if (!($this.h3s_1 == null)) {
      if (!($this.h3s_1[i] === null) || !($this.h3s_1[i] === $this)) {
        $this.h3s_1[i] = $this;
      }
    }
    return $this;
  }
  a3o() {
    return this.f3s_1;
  }
  static n3s(output, json, mode, modeReuseCache) {
    return this.x3t(Composer_0(output, json), json, mode, modeReuseCache);
  }
  f1y() {
    return this.i3s_1;
  }
  o1z(descriptor, index) {
    return this.j3s_1.j3n_1;
  }
  j1z(serializer, value) {
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically' call
      if (this.a3o().v3l_1.r3n_1) {
        serializer.i1t(this, value);
        break $l$block;
      }
      var isPolymorphicSerializer = serializer instanceof AbstractPolymorphicSerializer;
      var tmp;
      if (isPolymorphicSerializer) {
        tmp = !this.a3o().v3l_1.z3n_1.equals(ClassDiscriminatorMode_NONE_getInstance());
      } else {
        var tmp_0;
        switch (this.a3o().v3l_1.z3n_1.o3_1) {
          case 0:
          case 2:
            tmp_0 = false;
            break;
          case 1:
            // Inline function 'kotlin.let' call

            var it = serializer.h1t().u1v();
            tmp_0 = equals(it, CLASS_getInstance()) || equals(it, OBJECT_getInstance());
            break;
          default:
            noWhenBranchMatchedException();
            break;
        }
        tmp = tmp_0;
      }
      var needDiscriminator = tmp;
      var baseClassDiscriminator = needDiscriminator ? classDiscriminator(serializer.h1t(), this.a3o()) : null;
      var tmp_1;
      if (isPolymorphicSerializer) {
        var casted = serializer instanceof AbstractPolymorphicSerializer ? serializer : THROW_CCE();
        $l$block_0: {
          // Inline function 'kotlin.requireNotNull' call
          if (value == null) {
            var message = 'Value for serializer ' + toString(serializer.h1t()) + ' should always be non-null. Please report issue to the kotlinx.serialization tracker.';
            throw IllegalArgumentException.t(toString(message));
          } else {
            break $l$block_0;
          }
        }
        var actual = findPolymorphicSerializer_0(casted, this, value);
        if (!(baseClassDiscriminator == null)) {
          access$validateIfSealed$tPolymorphicKt(serializer, actual, baseClassDiscriminator);
          checkKind_0(actual.h1t().u1v());
        }
        tmp_1 = isInterface(actual, SerializationStrategy) ? actual : THROW_CCE();
      } else {
        tmp_1 = serializer;
      }
      var actualSerializer = tmp_1;
      if (!(baseClassDiscriminator == null)) {
        var serialName = actualSerializer.h1t().k1u();
        this.l3s_1 = baseClassDiscriminator;
        this.m3s_1 = serialName;
      }
      actualSerializer.i1t(this, value);
    }
  }
  q1x(descriptor) {
    var newMode = switchMode(this.f3s_1, descriptor);
    if (!(newMode.q3t_1 === _Char___init__impl__6a9atx(0))) {
      this.e3s_1.x3p(newMode.q3t_1);
      this.e3s_1.s3p();
    }
    var discriminator = this.l3s_1;
    if (!(discriminator == null)) {
      var tmp0_elvis_lhs = this.m3s_1;
      encodeTypeInfo(this, discriminator, tmp0_elvis_lhs == null ? descriptor.k1u() : tmp0_elvis_lhs);
      this.l3s_1 = null;
      this.m3s_1 = null;
    }
    if (this.g3s_1.equals(newMode)) {
      return this;
    }
    var tmp1_safe_receiver = this.h3s_1;
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver[newMode.o3_1];
    return tmp2_elvis_lhs == null ? StreamingJsonEncoder.x3t(this.e3s_1, this.f3s_1, newMode, this.h3s_1) : tmp2_elvis_lhs;
  }
  r1x(descriptor) {
    if (!(this.g3s_1.r3t_1 === _Char___init__impl__6a9atx(0))) {
      this.e3s_1.t3p();
      this.e3s_1.v3p();
      this.e3s_1.x3p(this.g3s_1.r3t_1);
    }
  }
  k1y(descriptor, index) {
    switch (this.g3s_1.o3_1) {
      case 1:
        if (!this.e3s_1.r3p_1) {
          this.e3s_1.x3p(_Char___init__impl__6a9atx(44));
        }

        this.e3s_1.u3p();
        break;
      case 2:
        if (!this.e3s_1.r3p_1) {
          var tmp = this;
          var tmp_0;
          if ((index % 2 | 0) === 0) {
            this.e3s_1.x3p(_Char___init__impl__6a9atx(44));
            this.e3s_1.u3p();
            tmp_0 = true;
          } else {
            this.e3s_1.x3p(_Char___init__impl__6a9atx(58));
            this.e3s_1.w3p();
            tmp_0 = false;
          }
          tmp.k3s_1 = tmp_0;
        } else {
          this.k3s_1 = true;
          this.e3s_1.u3p();
        }

        break;
      case 3:
        if (index === 0)
          this.k3s_1 = true;
        if (index === 1) {
          this.e3s_1.x3p(_Char___init__impl__6a9atx(44));
          this.e3s_1.w3p();
          this.k3s_1 = false;
        }

        break;
      default:
        if (!this.e3s_1.r3p_1) {
          this.e3s_1.x3p(_Char___init__impl__6a9atx(44));
        }

        this.e3s_1.u3p();
        this.v1y(getJsonElementName(descriptor, this.f3s_1, index));
        this.e3s_1.x3p(_Char___init__impl__6a9atx(58));
        this.e3s_1.w3p();
        break;
    }
    return true;
  }
  k1z(descriptor, index, serializer, value) {
    if (!(value == null) || this.j3s_1.o3n_1) {
      super.k1z(descriptor, index, serializer, value);
    }
  }
  x1y(descriptor) {
    var tmp;
    if (get_isUnsignedNumber(descriptor)) {
      // Inline function 'kotlinx.serialization.json.internal.StreamingJsonEncoder.composerAs' call
      var tmp_0;
      var tmp_1 = this.e3s_1;
      if (tmp_1 instanceof ComposerForUnsignedNumbers) {
        tmp_0 = this.e3s_1;
      } else {
        var tmp1 = this.e3s_1.q3p_1;
        var p1 = this.k3s_1;
        tmp_0 = new ComposerForUnsignedNumbers(tmp1, p1);
      }
      var tmp$ret$1 = tmp_0;
      tmp = StreamingJsonEncoder.x3t(tmp$ret$1, this.f3s_1, this.g3s_1, null);
    } else if (get_isUnquotedLiteral(descriptor)) {
      // Inline function 'kotlinx.serialization.json.internal.StreamingJsonEncoder.composerAs' call
      var tmp_2;
      var tmp_3 = this.e3s_1;
      if (tmp_3 instanceof ComposerForUnquotedLiterals) {
        tmp_2 = this.e3s_1;
      } else {
        var tmp4 = this.e3s_1.q3p_1;
        var p1_0 = this.k3s_1;
        tmp_2 = new ComposerForUnquotedLiterals(tmp4, p1_0);
      }
      var tmp$ret$3 = tmp_2;
      tmp = StreamingJsonEncoder.x3t(tmp$ret$3, this.f3s_1, this.g3s_1, null);
    } else if (!(this.l3s_1 == null)) {
      // Inline function 'kotlin.apply' call
      this.m3s_1 = descriptor.k1u();
      tmp = this;
    } else {
      tmp = super.x1y(descriptor);
    }
    return tmp;
  }
  m1y() {
    this.e3s_1.z3p('null');
  }
  n1y(value) {
    if (this.k3s_1) {
      this.v1y(value.toString());
    } else {
      this.e3s_1.i3q(value);
    }
  }
  o1y(value) {
    if (this.k3s_1) {
      this.v1y(value.toString());
    } else {
      this.e3s_1.d3q(value);
    }
  }
  p1y(value) {
    if (this.k3s_1) {
      this.v1y(value.toString());
    } else {
      this.e3s_1.f3q(value);
    }
  }
  q1y(value) {
    if (this.k3s_1) {
      this.v1y(value.toString());
    } else {
      this.e3s_1.g3q(value);
    }
  }
  r1y(value) {
    if (this.k3s_1) {
      this.v1y(value.toString());
    } else {
      this.e3s_1.h3q(value);
    }
  }
  s1y(value) {
    if (this.k3s_1) {
      this.v1y(value.toString());
    } else {
      this.e3s_1.b3q(value);
    }
    if (!this.j3s_1.t3n_1 && !isFinite(value)) {
      throw InvalidFloatingPointEncoded_0(value, toString(this.e3s_1.q3p_1));
    }
  }
  t1y(value) {
    if (this.k3s_1) {
      this.v1y(value.toString());
    } else {
      this.e3s_1.c3q(value);
    }
    if (!this.j3s_1.t3n_1 && !isFinite_0(value)) {
      throw InvalidFloatingPointEncoded_0(value, toString(this.e3s_1.q3p_1));
    }
  }
  u1y(value) {
    this.v1y(toString_1(value));
  }
  v1y(value) {
    return this.e3s_1.j3q(value);
  }
  w1y(enumDescriptor, index) {
    this.v1y(enumDescriptor.y1v(index));
  }
}
class AbstractJsonTreeDecoder extends NamedValueDecoder {
  constructor(json, value, polymorphicDiscriminator) {
    polymorphicDiscriminator = polymorphicDiscriminator === VOID ? null : polymorphicDiscriminator;
    super();
    this.a3u_1 = json;
    this.b3u_1 = value;
    this.c3u_1 = polymorphicDiscriminator;
    this.d3u_1 = this.a3o().v3l_1;
  }
  a3o() {
    return this.a3u_1;
  }
  n1() {
    return this.b3u_1;
  }
  f1y() {
    return this.a3o().f1y();
  }
  f3u() {
    var tmp0_safe_receiver = this.w2b();
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = this.g3u(tmp0_safe_receiver);
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? this.n1() : tmp1_elvis_lhs;
  }
  e3u(currentTag) {
    return this.u2c() + ('.' + currentTag);
  }
  b3o() {
    return this.f3u();
  }
  p1x(deserializer) {
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.decodeSerializableValuePolymorphic' call
      var tmp;
      if (!(deserializer instanceof AbstractPolymorphicSerializer)) {
        tmp = true;
      } else {
        tmp = this.a3o().v3l_1.r3n_1;
      }
      if (tmp) {
        tmp$ret$0 = deserializer.j1t(this);
        break $l$block;
      }
      var discriminator = classDiscriminator(deserializer.h1t(), this.a3o());
      var tmp0 = this.b3o();
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var serialName = deserializer.h1t().k1u();
      if (!(tmp0 instanceof JsonObject)) {
        var tmp_0 = getKClass(JsonObject).hf();
        var tmp_1 = getKClassFromExpression(tmp0).hf();
        var tmp$ret$1 = this.u2c();
        throw JsonDecodingException_0(-1, 'Expected ' + tmp_0 + ', but had ' + tmp_1 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$1, toString(tmp0));
      }
      var jsonTree = tmp0;
      var tmp0_safe_receiver = jsonTree.w2f(discriminator);
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
      var type = tmp1_safe_receiver == null ? null : get_contentOrNull(tmp1_safe_receiver);
      var tmp_2;
      try {
        tmp_2 = findPolymorphicSerializer(deserializer, this, type);
      } catch ($p) {
        var tmp_3;
        if ($p instanceof SerializationException) {
          var it = $p;
          throw JsonDecodingException_0(-1, ensureNotNull(it.message), jsonTree.toString());
        } else {
          throw $p;
        }
      }
      var tmp_4 = tmp_2;
      var actualSerializer = isInterface(tmp_4, DeserializationStrategy) ? tmp_4 : THROW_CCE();
      tmp$ret$0 = readPolymorphicJson(this.a3o(), discriminator, jsonTree, actualSerializer);
    }
    return tmp$ret$0;
  }
  x2b(parentName, childName) {
    return childName;
  }
  q1x(descriptor) {
    var currentObject = this.f3u();
    var tmp0_subject = descriptor.u1v();
    var tmp;
    var tmp_0;
    if (equals(tmp0_subject, LIST_getInstance())) {
      tmp_0 = true;
    } else {
      tmp_0 = tmp0_subject instanceof PolymorphicKind;
    }
    if (tmp_0) {
      var tmp_1 = this.a3o();
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var serialName = descriptor.k1u();
      if (!(currentObject instanceof JsonArray)) {
        var tmp_2 = getKClass(JsonArray).hf();
        var tmp_3 = getKClassFromExpression(currentObject).hf();
        var tmp$ret$0 = this.u2c();
        throw JsonDecodingException_0(-1, 'Expected ' + tmp_2 + ', but had ' + tmp_3 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$0, toString(currentObject));
      }
      tmp = new JsonTreeListDecoder(tmp_1, currentObject);
    } else {
      if (equals(tmp0_subject, MAP_getInstance())) {
        // Inline function 'kotlinx.serialization.json.internal.selectMapMode' call
        var this_0 = this.a3o();
        var keyDescriptor = carrierDescriptor(descriptor.b1w(0), this_0.f1y());
        var keyKind = keyDescriptor.u1v();
        var tmp_4;
        var tmp_5;
        if (keyKind instanceof PrimitiveKind) {
          tmp_5 = true;
        } else {
          tmp_5 = equals(keyKind, ENUM_getInstance());
        }
        if (tmp_5) {
          var tmp_6 = this.a3o();
          // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
          // Inline function 'kotlinx.serialization.json.internal.cast' call
          var serialName_0 = descriptor.k1u();
          if (!(currentObject instanceof JsonObject)) {
            var tmp_7 = getKClass(JsonObject).hf();
            var tmp_8 = getKClassFromExpression(currentObject).hf();
            var tmp$ret$3 = this.u2c();
            throw JsonDecodingException_0(-1, 'Expected ' + tmp_7 + ', but had ' + tmp_8 + ' as the serialized body of ' + serialName_0 + ' at element: ' + tmp$ret$3, toString(currentObject));
          }
          tmp_4 = new JsonTreeMapDecoder(tmp_6, currentObject);
        } else {
          if (this_0.v3l_1.m3n_1) {
            var tmp_9 = this.a3o();
            // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
            // Inline function 'kotlinx.serialization.json.internal.cast' call
            var serialName_1 = descriptor.k1u();
            if (!(currentObject instanceof JsonArray)) {
              var tmp_10 = getKClass(JsonArray).hf();
              var tmp_11 = getKClassFromExpression(currentObject).hf();
              var tmp$ret$7 = this.u2c();
              throw JsonDecodingException_0(-1, 'Expected ' + tmp_10 + ', but had ' + tmp_11 + ' as the serialized body of ' + serialName_1 + ' at element: ' + tmp$ret$7, toString(currentObject));
            }
            tmp_4 = new JsonTreeListDecoder(tmp_9, currentObject);
          } else {
            throw InvalidKeyKindException(keyDescriptor);
          }
        }
        tmp = tmp_4;
      } else {
        var tmp_12 = this.a3o();
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
        // Inline function 'kotlinx.serialization.json.internal.cast' call
        var serialName_2 = descriptor.k1u();
        if (!(currentObject instanceof JsonObject)) {
          var tmp_13 = getKClass(JsonObject).hf();
          var tmp_14 = getKClassFromExpression(currentObject).hf();
          var tmp$ret$12 = this.u2c();
          throw JsonDecodingException_0(-1, 'Expected ' + tmp_13 + ', but had ' + tmp_14 + ' as the serialized body of ' + serialName_2 + ' at element: ' + tmp$ret$12, toString(currentObject));
        }
        tmp = new JsonTreeDecoder(tmp_12, currentObject, this.c3u_1);
      }
    }
    return tmp;
  }
  r1x(descriptor) {
  }
  b1x() {
    var tmp = this.f3u();
    return !(tmp instanceof JsonNull);
  }
  h3u(tag, enumDescriptor) {
    var tmp = this.a3o();
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
    var tmp1 = this.g3u(tag);
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
    // Inline function 'kotlinx.serialization.json.internal.cast' call
    var serialName = enumDescriptor.k1u();
    if (!(tmp1 instanceof JsonPrimitive)) {
      var tmp_0 = getKClass(JsonPrimitive).hf();
      var tmp_1 = getKClassFromExpression(tmp1).hf();
      var tmp$ret$0 = this.e3u(tag);
      throw JsonDecodingException_0(-1, 'Expected ' + tmp_0 + ', but had ' + tmp_1 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$0, toString(tmp1));
    }
    return getJsonNameIndexOrThrow(enumDescriptor, tmp, tmp1.j3o());
  }
  g2d(tag, enumDescriptor) {
    return this.h3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), enumDescriptor);
  }
  i3u(tag) {
    return !(this.g3u(tag) === JsonNull_getInstance());
  }
  w2c(tag) {
    return this.i3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  j3u(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.g3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.e3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'boolean' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = get_booleanOrNull(literal);
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'boolean', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'boolean', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$4;
  }
  x2c(tag) {
    return this.j3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  k3u(tag) {
    var tmp$ret$5;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.g3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.e3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'byte' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var result = parseLongImpl(literal);
        var tmp_1;
        // Inline function 'kotlin.ranges.contains' call
        var this_0 = numberRangeToNumber(-128, 127);
        if (contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), result)) {
          tmp_1 = result.k4();
        } else {
          tmp_1 = null;
        }
        var tmp0_elvis_lhs = tmp_1;
        var tmp_2;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'byte', tag);
        } else {
          tmp_2 = tmp0_elvis_lhs;
        }
        tmp$ret$5 = tmp_2;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'byte', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$5;
  }
  y2c(tag) {
    return this.k3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  l3u(tag) {
    var tmp$ret$5;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.g3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.e3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'short' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var result = parseLongImpl(literal);
        var tmp_1;
        // Inline function 'kotlin.ranges.contains' call
        var this_0 = numberRangeToNumber(-32768, 32767);
        if (contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), result)) {
          tmp_1 = result.l4();
        } else {
          tmp_1 = null;
        }
        var tmp0_elvis_lhs = tmp_1;
        var tmp_2;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'short', tag);
        } else {
          tmp_2 = tmp0_elvis_lhs;
        }
        tmp$ret$5 = tmp_2;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'short', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$5;
  }
  z2c(tag) {
    return this.l3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  m3u(tag) {
    var tmp$ret$5;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.g3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.e3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'int' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var result = parseLongImpl(literal);
        var tmp_1;
        // Inline function 'kotlin.ranges.contains' call
        var this_0 = numberRangeToNumber(-2147483648, 2147483647);
        if (contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), result)) {
          tmp_1 = result.x1();
        } else {
          tmp_1 = null;
        }
        var tmp0_elvis_lhs = tmp_1;
        var tmp_2;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'int', tag);
        } else {
          tmp_2 = tmp0_elvis_lhs;
        }
        tmp$ret$5 = tmp_2;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'int', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$5;
  }
  a2d(tag) {
    return this.m3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  n3u(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.g3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.e3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'long' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = parseLongImpl(literal);
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'long', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'long', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$4;
  }
  b2d(tag) {
    return this.n3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  o3u(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.g3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.e3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'float' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = get_float(literal);
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'float', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'float', tag);
        } else {
          throw $p;
        }
      }
    }
    var result = tmp$ret$4;
    var specialFp = this.a3o().v3l_1.t3n_1;
    if (specialFp || isFinite(result))
      return result;
    throw InvalidFloatingPointDecoded(result, tag, toString(this.f3u()));
  }
  c2d(tag) {
    return this.o3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  p3u(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.g3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.e3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'double' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = get_double(literal);
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'double', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'double', tag);
        } else {
          throw $p;
        }
      }
    }
    var result = tmp$ret$4;
    var specialFp = this.a3o().v3l_1.t3n_1;
    if (specialFp || isFinite_0(result))
      return result;
    throw InvalidFloatingPointDecoded(result, tag, toString(this.f3u()));
  }
  d2d(tag) {
    return this.p3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  q3u(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.g3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.e3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'char' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = new Char(single(literal.j3o()));
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'char', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1.j2_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'char', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$4;
  }
  e2d(tag) {
    return this.q3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  r3u(tag) {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
    // Inline function 'kotlinx.serialization.json.internal.cast' call
    var value = this.g3u(tag);
    if (!(value instanceof JsonPrimitive)) {
      var tmp = getKClass(JsonPrimitive).hf();
      var tmp_0 = getKClassFromExpression(value).hf();
      var tmp$ret$0 = this.e3u(tag);
      throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'string' + ' at element: ' + tmp$ret$0, toString(value));
    }
    var value_0 = value;
    if (!(value_0 instanceof JsonLiteral))
      throw JsonDecodingException_0(-1, "Expected string value for a non-null key '" + tag + "', got null literal instead at element: " + this.e3u(tag), toString(this.f3u()));
    if (!value_0.k3o_1 && !this.a3o().v3l_1.l3n_1) {
      throw JsonDecodingException_0(-1, "String literal for key '" + tag + "' should be quoted at element: " + this.e3u(tag) + ".\nUse 'isLenient = true' in 'Json {}' builder to accept non-compliant JSON.", toString(this.f3u()));
    }
    return value_0.m3o_1;
  }
  f2d(tag) {
    return this.r3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  s3u(tag, inlineDescriptor) {
    var tmp;
    if (get_isUnsignedNumber(inlineDescriptor)) {
      var tmp_0 = this.a3o();
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      var tmp1 = this.g3u(tag);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var serialName = inlineDescriptor.k1u();
      if (!(tmp1 instanceof JsonPrimitive)) {
        var tmp_1 = getKClass(JsonPrimitive).hf();
        var tmp_2 = getKClassFromExpression(tmp1).hf();
        var tmp$ret$0 = this.e3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp_1 + ', but had ' + tmp_2 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$0, toString(tmp1));
      }
      var lexer = StringJsonLexer_0(tmp_0, tmp1.j3o());
      tmp = new JsonDecoderForUnsignedTypes(lexer, this.a3o());
    } else {
      tmp = super.h2d(tag, inlineDescriptor);
    }
    return tmp;
  }
  h2d(tag, inlineDescriptor) {
    return this.s3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), inlineDescriptor);
  }
  n1x(descriptor) {
    return !(this.w2b() == null) ? super.n1x(descriptor) : (new JsonPrimitiveDecoder(this.a3o(), this.n1(), this.c3u_1)).n1x(descriptor);
  }
}
class JsonTreeDecoder extends AbstractJsonTreeDecoder {
  constructor(json, value, polymorphicDiscriminator, polyDescriptor) {
    polymorphicDiscriminator = polymorphicDiscriminator === VOID ? null : polymorphicDiscriminator;
    polyDescriptor = polyDescriptor === VOID ? null : polyDescriptor;
    super(json, value, polymorphicDiscriminator);
    this.z3u_1 = value;
    this.a3v_1 = polyDescriptor;
    this.b3v_1 = 0;
    this.c3v_1 = false;
  }
  n1() {
    return this.z3u_1;
  }
  h1y(descriptor) {
    $l$loop: while (this.b3v_1 < descriptor.w1v()) {
      var _unary__edvuaz = this.b3v_1;
      this.b3v_1 = _unary__edvuaz + 1 | 0;
      var name = this.s2b(descriptor, _unary__edvuaz);
      var index = this.b3v_1 - 1 | 0;
      this.c3v_1 = false;
      var tmp;
      // Inline function 'kotlin.collections.contains' call
      // Inline function 'kotlin.collections.containsKey' call
      var this_0 = this.n1();
      if ((isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).f3(name)) {
        tmp = true;
      } else {
        tmp = setForceNull(this, descriptor, index);
      }
      if (tmp) {
        if (!this.d3u_1.q3n_1)
          return index;
        var tmp2 = this.a3o();
        var tmp$ret$3;
        $l$block_2: {
          // Inline function 'kotlinx.serialization.json.internal.tryCoerceValue' call
          var isOptional = descriptor.c1w(index);
          var elementDescriptor = descriptor.b1w(index);
          var tmp_0;
          if (isOptional && !elementDescriptor.q1v()) {
            var tmp_1 = this.d3v(name);
            tmp_0 = tmp_1 instanceof JsonNull;
          } else {
            tmp_0 = false;
          }
          if (tmp_0) {
            tmp$ret$3 = true;
            break $l$block_2;
          }
          if (equals(elementDescriptor.u1v(), ENUM_getInstance())) {
            var tmp_2;
            if (elementDescriptor.q1v()) {
              var tmp_3 = this.d3v(name);
              tmp_2 = tmp_3 instanceof JsonNull;
            } else {
              tmp_2 = false;
            }
            if (tmp_2) {
              tmp$ret$3 = false;
              break $l$block_2;
            }
            var tmp_4 = this.d3v(name);
            var tmp0_safe_receiver = tmp_4 instanceof JsonPrimitive ? tmp_4 : null;
            var tmp0_elvis_lhs = tmp0_safe_receiver == null ? null : get_contentOrNull(tmp0_safe_receiver);
            var tmp_5;
            if (tmp0_elvis_lhs == null) {
              tmp$ret$3 = false;
              break $l$block_2;
            } else {
              tmp_5 = tmp0_elvis_lhs;
            }
            var enumValue = tmp_5;
            var enumIndex = getJsonNameIndex(elementDescriptor, tmp2, enumValue);
            var coerceToNull = !tmp2.v3l_1.o3n_1 && elementDescriptor.q1v();
            if (enumIndex === -3 && (isOptional || coerceToNull)) {
              if (setForceNull(this, descriptor, index))
                return index;
              tmp$ret$3 = true;
              break $l$block_2;
            }
          }
          tmp$ret$3 = false;
        }
        if (tmp$ret$3)
          continue $l$loop;
        return index;
      }
    }
    return -1;
  }
  b1x() {
    return !this.c3v_1 && super.b1x();
  }
  t2b(descriptor, index) {
    var strategy = namingStrategy(descriptor, this.a3o());
    var baseName = descriptor.y1v(index);
    if (strategy == null) {
      if (!this.d3u_1.u3n_1)
        return baseName;
      if (this.n1().i3().v2(baseName))
        return baseName;
    }
    var deserializationNamesMap_0 = deserializationNamesMap(this.a3o(), descriptor);
    // Inline function 'kotlin.collections.find' call
    var tmp0 = this.n1().i3();
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (deserializationNamesMap_0.h3(element) === index) {
          tmp$ret$1 = element;
          break $l$block;
        }
      }
      tmp$ret$1 = null;
    }
    var tmp0_safe_receiver = tmp$ret$1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var fallbackName = strategy == null ? null : strategy.r3r(descriptor, index, baseName);
    return fallbackName == null ? baseName : fallbackName;
  }
  g3u(tag) {
    return getValue(this.n1(), tag);
  }
  d3v(tag) {
    return this.n1().w2f(tag);
  }
  q1x(descriptor) {
    if (descriptor === this.a3v_1) {
      var tmp = this.a3o();
      var tmp1 = this.f3u();
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var serialName = this.a3v_1.k1u();
      if (!(tmp1 instanceof JsonObject)) {
        var tmp_0 = getKClass(JsonObject).hf();
        var tmp_1 = getKClassFromExpression(tmp1).hf();
        var tmp$ret$0 = this.u2c();
        throw JsonDecodingException_0(-1, 'Expected ' + tmp_0 + ', but had ' + tmp_1 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$0, toString(tmp1));
      }
      return new JsonTreeDecoder(tmp, tmp1, this.c3u_1, this.a3v_1);
    }
    return super.q1x(descriptor);
  }
  r1x(descriptor) {
    var tmp;
    if (ignoreUnknownKeys(descriptor, this.a3o())) {
      tmp = true;
    } else {
      var tmp_0 = descriptor.u1v();
      tmp = tmp_0 instanceof PolymorphicKind;
    }
    if (tmp)
      return Unit_instance;
    var strategy = namingStrategy(descriptor, this.a3o());
    var tmp_1;
    if (strategy == null && !this.d3u_1.u3n_1) {
      tmp_1 = jsonCachedSerialNames(descriptor);
    } else if (!(strategy == null)) {
      tmp_1 = deserializationNamesMap(this.a3o(), descriptor).i3();
    } else {
      var tmp_2 = jsonCachedSerialNames(descriptor);
      var tmp0_safe_receiver = get_schemaCache(this.a3o()).d3t(descriptor, get_JsonDeserializationNamesKey());
      // Inline function 'kotlin.collections.orEmpty' call
      var tmp0_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i3();
      var tmp$ret$0 = tmp0_elvis_lhs == null ? emptySet() : tmp0_elvis_lhs;
      tmp_1 = plus_0(tmp_2, tmp$ret$0);
    }
    var names = tmp_1;
    var _iterator__ex2g4s = this.n1().i3().y();
    while (_iterator__ex2g4s.z()) {
      var key = _iterator__ex2g4s.a1();
      if (!names.v2(key) && !(key === this.c3u_1)) {
        throw JsonDecodingException_1(-1, "Encountered an unknown key '" + key + "' at element: " + this.u2c() + '\n' + "Use 'ignoreUnknownKeys = true' in 'Json {}' builder or '@JsonIgnoreUnknownKeys' annotation to ignore unknown keys.\n" + ('JSON input: ' + toString(minify(this.n1().toString()))));
      }
    }
  }
}
class JsonTreeListDecoder extends AbstractJsonTreeDecoder {
  constructor(json, value) {
    super(json, value);
    this.k3v_1 = value;
    this.l3v_1 = this.k3v_1.b1();
    this.m3v_1 = -1;
  }
  n1() {
    return this.k3v_1;
  }
  t2b(descriptor, index) {
    return index.toString();
  }
  g3u(tag) {
    return this.k3v_1.f1(toInt(tag));
  }
  h1y(descriptor) {
    while (this.m3v_1 < (this.l3v_1 - 1 | 0)) {
      this.m3v_1 = this.m3v_1 + 1 | 0;
      return this.m3v_1;
    }
    return -1;
  }
}
class JsonPrimitiveDecoder extends AbstractJsonTreeDecoder {
  constructor(json, value, polymorphicDiscriminator) {
    polymorphicDiscriminator = polymorphicDiscriminator === VOID ? null : polymorphicDiscriminator;
    super(json, value, polymorphicDiscriminator);
    this.t3v_1 = value;
    this.o2c('primitive');
  }
  n1() {
    return this.t3v_1;
  }
  h1y(descriptor) {
    return 0;
  }
  g3u(tag) {
    // Inline function 'kotlin.require' call
    if (!(tag === 'primitive')) {
      var message = "This input can only handle primitives with 'primitive' tag";
      throw IllegalArgumentException.t(toString(message));
    }
    return this.t3v_1;
  }
}
class JsonTreeMapDecoder extends JsonTreeDecoder {
  constructor(json, value) {
    super(json, value);
    this.e3w_1 = value;
    this.f3w_1 = toList(this.e3w_1.i3());
    this.g3w_1 = imul(this.f3w_1.b1(), 2);
    this.h3w_1 = -1;
  }
  n1() {
    return this.e3w_1;
  }
  t2b(descriptor, index) {
    var i = index / 2 | 0;
    return this.f3w_1.f1(i);
  }
  h1y(descriptor) {
    while (this.h3w_1 < (this.g3w_1 - 1 | 0)) {
      this.h3w_1 = this.h3w_1 + 1 | 0;
      return this.h3w_1;
    }
    return -1;
  }
  g3u(tag) {
    return (this.h3w_1 % 2 | 0) === 0 ? JsonPrimitive_1(tag) : getValue(this.e3w_1, tag);
  }
  r1x(descriptor) {
  }
}
class AbstractJsonTreeEncoder extends NamedValueEncoder {
  constructor(json, nodeConsumer) {
    super();
    this.j3w_1 = json;
    this.k3w_1 = nodeConsumer;
    this.l3w_1 = this.j3w_1.v3l_1;
    this.m3w_1 = null;
    this.n3w_1 = null;
  }
  a3o() {
    return this.j3w_1;
  }
  f1y() {
    return this.j3w_1.f1y();
  }
  t2b(descriptor, index) {
    return getJsonElementName(descriptor, this.j3w_1, index);
  }
  o1z(descriptor, index) {
    return this.l3w_1.j3n_1;
  }
  x2b(parentName, childName) {
    return childName;
  }
  m1z() {
  }
  m1y() {
    var tmp0_elvis_lhs = this.w2b();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return this.k3w_1(JsonNull_getInstance());
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var tag = tmp;
    this.x3w(tag);
  }
  x3w(tag) {
    return this.v3w(tag, JsonNull_getInstance());
  }
  a2c(tag) {
    return this.x3w((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  y3w(tag, value) {
    return this.v3w(tag, JsonPrimitive_0(value));
  }
  b2c(tag, value) {
    return this.y3w((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  z3w(tag, value) {
    return this.v3w(tag, JsonPrimitive_0(value));
  }
  c2c(tag, value) {
    return this.z3w((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  a3x(tag, value) {
    return this.v3w(tag, JsonPrimitive_0(value));
  }
  d2c(tag, value) {
    return this.a3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  b3x(tag, value) {
    return this.v3w(tag, JsonPrimitive_0(value));
  }
  e2c(tag, value) {
    return this.b3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  c3x(tag, value) {
    this.v3w(tag, JsonPrimitive_0(value));
    if (!this.l3w_1.t3n_1 && !isFinite(value)) {
      throw InvalidFloatingPointEncoded(value, tag, toString(this.w3w()));
    }
  }
  f2c(tag, value) {
    return this.c3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  j1z(serializer, value) {
    if (!(this.w2b() == null) || !get_requiresTopLevelTag(carrierDescriptor(serializer.h1t(), this.f1y()))) {
      $l$block: {
        // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically' call
        if (this.a3o().v3l_1.r3n_1) {
          serializer.i1t(this, value);
          break $l$block;
        }
        var isPolymorphicSerializer = serializer instanceof AbstractPolymorphicSerializer;
        var tmp;
        if (isPolymorphicSerializer) {
          tmp = !this.a3o().v3l_1.z3n_1.equals(ClassDiscriminatorMode_NONE_getInstance());
        } else {
          var tmp_0;
          switch (this.a3o().v3l_1.z3n_1.o3_1) {
            case 0:
            case 2:
              tmp_0 = false;
              break;
            case 1:
              // Inline function 'kotlin.let' call

              var it = serializer.h1t().u1v();
              tmp_0 = equals(it, CLASS_getInstance()) || equals(it, OBJECT_getInstance());
              break;
            default:
              noWhenBranchMatchedException();
              break;
          }
          tmp = tmp_0;
        }
        var needDiscriminator = tmp;
        var baseClassDiscriminator = needDiscriminator ? classDiscriminator(serializer.h1t(), this.a3o()) : null;
        var tmp_1;
        if (isPolymorphicSerializer) {
          var casted = serializer instanceof AbstractPolymorphicSerializer ? serializer : THROW_CCE();
          $l$block_0: {
            // Inline function 'kotlin.requireNotNull' call
            if (value == null) {
              var message = 'Value for serializer ' + toString(serializer.h1t()) + ' should always be non-null. Please report issue to the kotlinx.serialization tracker.';
              throw IllegalArgumentException.t(toString(message));
            } else {
              break $l$block_0;
            }
          }
          var actual = findPolymorphicSerializer_0(casted, this, value);
          if (!(baseClassDiscriminator == null)) {
            access$validateIfSealed$tPolymorphicKt(serializer, actual, baseClassDiscriminator);
            checkKind_0(actual.h1t().u1v());
          }
          tmp_1 = isInterface(actual, SerializationStrategy) ? actual : THROW_CCE();
        } else {
          tmp_1 = serializer;
        }
        var actualSerializer = tmp_1;
        if (!(baseClassDiscriminator == null)) {
          var serialName = actualSerializer.h1t().k1u();
          this.m3w_1 = baseClassDiscriminator;
          this.n3w_1 = serialName;
        }
        actualSerializer.i1t(this, value);
      }
    } else {
      // Inline function 'kotlin.apply' call
      (new JsonPrimitiveEncoder(this.j3w_1, this.k3w_1)).j1z(serializer, value);
    }
  }
  d3x(tag, value) {
    this.v3w(tag, JsonPrimitive_0(value));
    if (!this.l3w_1.t3n_1 && !isFinite_0(value)) {
      throw InvalidFloatingPointEncoded(value, tag, toString(this.w3w()));
    }
  }
  g2c(tag, value) {
    return this.d3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  e3x(tag, value) {
    return this.v3w(tag, JsonPrimitive_2(value));
  }
  h2c(tag, value) {
    return this.e3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  f3x(tag, value) {
    return this.v3w(tag, JsonPrimitive_1(toString_1(value)));
  }
  i2c(tag, value) {
    return this.f3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  g3x(tag, value) {
    return this.v3w(tag, JsonPrimitive_1(value));
  }
  j2c(tag, value) {
    return this.g3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  h3x(tag, enumDescriptor, ordinal) {
    return this.v3w(tag, JsonPrimitive_1(enumDescriptor.y1v(ordinal)));
  }
  k2c(tag, enumDescriptor, ordinal) {
    return this.h3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), enumDescriptor, ordinal);
  }
  i3x(tag, value) {
    this.v3w(tag, JsonPrimitive_1(toString(value)));
  }
  y2b(tag, value) {
    return this.i3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  j3x(tag, inlineDescriptor) {
    return get_isUnsignedNumber(inlineDescriptor) ? inlineUnsignedNumberEncoder(this, tag) : get_isUnquotedLiteral(inlineDescriptor) ? inlineUnquotedLiteralEncoder(this, tag, inlineDescriptor) : super.l2c(tag, inlineDescriptor);
  }
  l2c(tag, inlineDescriptor) {
    return this.j3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), inlineDescriptor);
  }
  x1y(descriptor) {
    var tmp;
    if (!(this.w2b() == null)) {
      if (!(this.m3w_1 == null))
        this.n3w_1 = descriptor.k1u();
      tmp = super.x1y(descriptor);
    } else {
      tmp = (new JsonPrimitiveEncoder(this.j3w_1, this.k3w_1)).x1y(descriptor);
    }
    return tmp;
  }
  q1x(descriptor) {
    var tmp;
    if (this.w2b() == null) {
      tmp = this.k3w_1;
    } else {
      tmp = AbstractJsonTreeEncoder$beginStructure$lambda(this);
    }
    var consumer = tmp;
    var tmp0_subject = descriptor.u1v();
    var tmp_0;
    var tmp_1;
    if (equals(tmp0_subject, LIST_getInstance())) {
      tmp_1 = true;
    } else {
      tmp_1 = tmp0_subject instanceof PolymorphicKind;
    }
    if (tmp_1) {
      tmp_0 = new JsonTreeListEncoder(this.j3w_1, consumer);
    } else {
      if (equals(tmp0_subject, MAP_getInstance())) {
        // Inline function 'kotlinx.serialization.json.internal.selectMapMode' call
        var this_0 = this.j3w_1;
        var keyDescriptor = carrierDescriptor(descriptor.b1w(0), this_0.f1y());
        var keyKind = keyDescriptor.u1v();
        var tmp_2;
        var tmp_3;
        if (keyKind instanceof PrimitiveKind) {
          tmp_3 = true;
        } else {
          tmp_3 = equals(keyKind, ENUM_getInstance());
        }
        if (tmp_3) {
          tmp_2 = new JsonTreeMapEncoder(this.j3w_1, consumer);
        } else {
          if (this_0.v3l_1.m3n_1) {
            tmp_2 = new JsonTreeListEncoder(this.j3w_1, consumer);
          } else {
            throw InvalidKeyKindException(keyDescriptor);
          }
        }
        tmp_0 = tmp_2;
      } else {
        tmp_0 = new JsonTreeEncoder(this.j3w_1, consumer);
      }
    }
    var encoder = tmp_0;
    var discriminator = this.m3w_1;
    if (!(discriminator == null)) {
      if (encoder instanceof JsonTreeMapEncoder) {
        encoder.v3w('key', JsonPrimitive_1(discriminator));
        var tmp1_elvis_lhs = this.n3w_1;
        encoder.v3w('value', JsonPrimitive_1(tmp1_elvis_lhs == null ? descriptor.k1u() : tmp1_elvis_lhs));
      } else {
        var tmp2_elvis_lhs = this.n3w_1;
        encoder.v3w(discriminator, JsonPrimitive_1(tmp2_elvis_lhs == null ? descriptor.k1u() : tmp2_elvis_lhs));
      }
      this.m3w_1 = null;
      this.n3w_1 = null;
    }
    return encoder;
  }
  m2c(descriptor) {
    this.k3w_1(this.w3w());
  }
}
class JsonTreeEncoder extends AbstractJsonTreeEncoder {
  constructor(json, nodeConsumer) {
    super(json, nodeConsumer);
    var tmp = this;
    // Inline function 'kotlin.collections.linkedMapOf' call
    tmp.u3w_1 = LinkedHashMap.hc();
  }
  v3w(key, element) {
    // Inline function 'kotlin.collections.set' call
    this.u3w_1.k3(key, element);
  }
  k1z(descriptor, index, serializer, value) {
    if (!(value == null) || this.l3w_1.o3n_1) {
      super.k1z(descriptor, index, serializer, value);
    }
  }
  w3w() {
    return new JsonObject(this.u3w_1);
  }
}
class AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1 extends AbstractEncoder {
  static n3x(this$0, $tag, $box) {
    if ($box === VOID)
      $box = {};
    $box.l3x_1 = this$0;
    $box.m3x_1 = $tag;
    var $this = this.j1y($box);
    $this.k3x_1 = this$0.j3w_1.f1y();
    return $this;
  }
  f1y() {
    return this.k3x_1;
  }
  s3x(s) {
    return this.l3x_1.v3w(this.m3x_1, new JsonLiteral(s, false));
  }
  q1y(value) {
    // Inline function 'kotlin.toUInt' call
    var tmp$ret$0 = _UInt___init__impl__l7qpdl(value);
    return this.s3x(UInt__toString_impl_dbgl21(tmp$ret$0));
  }
  r1y(value) {
    // Inline function 'kotlin.toULong' call
    var tmp$ret$0 = _ULong___init__impl__c78o9k(value);
    return this.s3x(ULong__toString_impl_f9au7k(tmp$ret$0));
  }
  o1y(value) {
    // Inline function 'kotlin.toUByte' call
    var tmp$ret$0 = _UByte___init__impl__g9hnc4(value);
    return this.s3x(UByte__toString_impl_v72jg(tmp$ret$0));
  }
  p1y(value) {
    // Inline function 'kotlin.toUShort' call
    var tmp$ret$0 = _UShort___init__impl__jigrne(value);
    return this.s3x(UShort__toString_impl_edaoee(tmp$ret$0));
  }
}
class AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1 extends AbstractEncoder {
  static r3x(this$0, $tag, $inlineDescriptor, $box) {
    if ($box === VOID)
      $box = {};
    $box.o3x_1 = this$0;
    $box.p3x_1 = $tag;
    $box.q3x_1 = $inlineDescriptor;
    return this.j1y($box);
  }
  f1y() {
    return this.o3x_1.j3w_1.f1y();
  }
  v1y(value) {
    return this.o3x_1.v3w(this.p3x_1, new JsonLiteral(value, false, this.q3x_1));
  }
}
class JsonPrimitiveEncoder extends AbstractJsonTreeEncoder {
  constructor(json, nodeConsumer) {
    super(json, nodeConsumer);
    this.i3y_1 = null;
    this.o2c('primitive');
  }
  v3w(key, element) {
    // Inline function 'kotlin.require' call
    if (!(key === 'primitive')) {
      var message = "This output can only consume primitives with 'primitive' tag";
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.i3y_1 == null)) {
      var message_0 = 'Primitive element was already recorded. Does call to .encodeXxx happen more than once?';
      throw IllegalArgumentException.t(toString(message_0));
    }
    this.i3y_1 = element;
    this.k3w_1(element);
  }
  w3w() {
    var tmp0 = this.i3y_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.requireNotNull' call
      if (tmp0 == null) {
        var message = 'Primitive element has not been recorded. Is call to .encodeXxx is missing in serializer?';
        throw IllegalArgumentException.t(toString(message));
      } else {
        tmp$ret$1 = tmp0;
        break $l$block;
      }
    }
    return tmp$ret$1;
  }
}
class JsonTreeListEncoder extends AbstractJsonTreeEncoder {
  constructor(json, nodeConsumer) {
    super(json, nodeConsumer);
    var tmp = this;
    // Inline function 'kotlin.collections.arrayListOf' call
    tmp.p3y_1 = ArrayList.k();
  }
  t2b(descriptor, index) {
    return index.toString();
  }
  v3w(key, element) {
    var idx = toInt(key);
    this.p3y_1.d3(idx, element);
  }
  w3w() {
    return new JsonArray(this.p3y_1);
  }
}
class JsonTreeMapEncoder extends JsonTreeEncoder {
  constructor(json, nodeConsumer) {
    super(json, nodeConsumer);
    this.b3y_1 = true;
  }
  v3w(key, element) {
    if (this.b3y_1) {
      var tmp = this;
      var tmp_0;
      if (element instanceof JsonPrimitive) {
        tmp_0 = element.j3o();
      } else {
        if (element instanceof JsonObject) {
          throw InvalidKeyKindException(JsonObjectSerializer_getInstance().v3o_1);
        } else {
          if (element instanceof JsonArray) {
            throw InvalidKeyKindException(JsonArraySerializer_getInstance().w3o_1);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
      tmp.a3y_1 = tmp_0;
      this.b3y_1 = false;
    } else {
      var tmp0 = this.u3w_1;
      // Inline function 'kotlin.collections.set' call
      var key_0 = _get_tag__e6h4qf(this);
      tmp0.k3(key_0, element);
      this.b3y_1 = true;
    }
  }
  w3w() {
    return new JsonObject(this.u3w_1);
  }
}
class WriteMode extends Enum {
  constructor(name, ordinal, begin, end) {
    super(name, ordinal);
    this.q3t_1 = begin;
    this.r3t_1 = end;
  }
}
class AbstractJsonLexer {
  constructor() {
    this.l3m_1 = 0;
    this.m3m_1 = new JsonPath();
    this.n3m_1 = null;
    this.o3m_1 = StringBuilder.v();
  }
  t3y() {
  }
  g3t() {
    var current = this.u3y();
    var source = this.r3y();
    if (current >= charSequenceLength(source) || current === -1)
      return false;
    if (charSequenceGet(source, current) === _Char___init__impl__6a9atx(44)) {
      this.l3m_1 = this.l3m_1 + 1 | 0;
      return true;
    }
    return false;
  }
  v3y(c) {
    return c === _Char___init__impl__6a9atx(125) || c === _Char___init__impl__6a9atx(93) || (c === _Char___init__impl__6a9atx(58) || c === _Char___init__impl__6a9atx(44)) ? false : true;
  }
  p3m() {
    var nextToken = this.z3s();
    if (!(nextToken === 10)) {
      this.g3r('Expected EOF after parsing, but had ' + toString_1(charSequenceGet(this.r3y(), this.l3m_1 - 1 | 0)) + ' instead');
    }
  }
  u3s(expected) {
    var token = this.z3s();
    if (!(token === expected)) {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.fail' call
      var expected_0 = tokenDescription(expected);
      var position = true ? this.l3m_1 - 1 | 0 : this.l3m_1;
      var s = this.l3m_1 === charSequenceLength(this.r3y()) || position < 0 ? 'EOF' : toString_1(charSequenceGet(this.r3y(), position));
      var tmp$ret$0 = 'Expected ' + expected_0 + ", but had '" + s + "' instead";
      this.g3r(tmp$ret$0, position);
    }
    return token;
  }
  w3y(expected) {
    if (this.l3m_1 > 0 && expected === _Char___init__impl__6a9atx(34)) {
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.withPositionRollback' call
        var snapshot = this.l3m_1;
        try {
          this.l3m_1 = this.l3m_1 - 1 | 0;
          tmp$ret$1 = this.x3s();
          break $l$block;
        }finally {
          this.l3m_1 = snapshot;
        }
      }
      var inputLiteral = tmp$ret$1;
      if (inputLiteral === 'null') {
        this.f3r("Expected string literal but 'null' literal was found", this.l3m_1 - 1 | 0, "Use 'coerceInputValues = true' in 'Json {}' builder to coerce nulls if property has a default value.");
      }
    }
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.fail' call
    var expectedToken = charToTokenClass(expected);
    var expected_0 = tokenDescription(expectedToken);
    var position = true ? this.l3m_1 - 1 | 0 : this.l3m_1;
    var s = this.l3m_1 === charSequenceLength(this.r3y()) || position < 0 ? 'EOF' : toString_1(charSequenceGet(this.r3y(), position));
    var tmp$ret$2 = 'Expected ' + expected_0 + ", but had '" + s + "' instead";
    this.g3r(tmp$ret$2, position);
  }
  t3s() {
    var source = this.r3y();
    var cpos = this.l3m_1;
    $l$loop_0: while (true) {
      cpos = this.s3y(cpos);
      if (cpos === -1)
        break $l$loop_0;
      var ch = charSequenceGet(source, cpos);
      if (ch === _Char___init__impl__6a9atx(32) || ch === _Char___init__impl__6a9atx(10) || ch === _Char___init__impl__6a9atx(13) || ch === _Char___init__impl__6a9atx(9)) {
        cpos = cpos + 1 | 0;
        continue $l$loop_0;
      }
      this.l3m_1 = cpos;
      return charToTokenClass(ch);
    }
    this.l3m_1 = cpos;
    return 10;
  }
  h3t(doConsume) {
    var current = this.u3y();
    current = this.s3y(current);
    var len = charSequenceLength(this.r3y()) - current | 0;
    if (len < 4 || current === -1)
      return false;
    var inductionVariable = 0;
    if (inductionVariable <= 3)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(charSequenceGet('null', i) === charSequenceGet(this.r3y(), current + i | 0)))
          return false;
      }
       while (inductionVariable <= 3);
    if (len > 4 && charToTokenClass(charSequenceGet(this.r3y(), current + 4 | 0)) === 0)
      return false;
    if (doConsume) {
      this.l3m_1 = current + 4 | 0;
    }
    return true;
  }
  s3t(doConsume, $super) {
    doConsume = doConsume === VOID ? true : doConsume;
    return $super === VOID ? this.h3t(doConsume) : $super.h3t.call(this, doConsume);
  }
  i3t(isLenient) {
    var token = this.t3s();
    var tmp;
    if (isLenient) {
      if (!(token === 1) && !(token === 0))
        return null;
      tmp = this.x3s();
    } else {
      if (!(token === 1))
        return null;
      tmp = this.w3s();
    }
    var string = tmp;
    this.n3m_1 = string;
    return string;
  }
  x3y() {
    this.n3m_1 = null;
  }
  u1k(startPos, endPos) {
    // Inline function 'kotlin.text.substring' call
    var this_0 = this.r3y();
    return toString(charSequenceSubSequence(this_0, startPos, endPos));
  }
  w3s() {
    if (!(this.n3m_1 == null)) {
      return takePeeked(this);
    }
    return this.l3t();
  }
  consumeString2(source, startPosition, current) {
    var currentPosition = current;
    var lastPosition = startPosition;
    var char = charSequenceGet(source, currentPosition);
    var usedAppend = false;
    while (!(char === _Char___init__impl__6a9atx(34))) {
      if (char === _Char___init__impl__6a9atx(92)) {
        usedAppend = true;
        currentPosition = this.s3y(appendEscape(this, lastPosition, currentPosition));
        if (currentPosition === -1) {
          this.g3r('Unexpected EOF', currentPosition);
        }
        lastPosition = currentPosition;
      } else {
        currentPosition = currentPosition + 1 | 0;
        if (currentPosition >= charSequenceLength(source)) {
          usedAppend = true;
          this.q3y(lastPosition, currentPosition);
          currentPosition = this.s3y(currentPosition);
          if (currentPosition === -1) {
            this.g3r('Unexpected EOF', currentPosition);
          }
          lastPosition = currentPosition;
        }
      }
      char = charSequenceGet(source, currentPosition);
    }
    var tmp;
    if (!usedAppend) {
      tmp = this.u1k(lastPosition, currentPosition);
    } else {
      tmp = decodedString(this, lastPosition, currentPosition);
    }
    var string = tmp;
    this.l3m_1 = currentPosition + 1 | 0;
    return string;
  }
  m3t() {
    var result = this.x3s();
    if (result === 'null' && wasUnquotedString(this)) {
      this.g3r("Unexpected 'null' value instead of string literal");
    }
    return result;
  }
  x3s() {
    if (!(this.n3m_1 == null)) {
      return takePeeked(this);
    }
    var current = this.u3y();
    if (current >= charSequenceLength(this.r3y()) || current === -1) {
      this.g3r('EOF', current);
    }
    var token = charToTokenClass(charSequenceGet(this.r3y(), current));
    if (token === 1) {
      return this.w3s();
    }
    if (!(token === 0)) {
      this.g3r('Expected beginning of the string, but got ' + toString_1(charSequenceGet(this.r3y(), current)));
    }
    var usedAppend = false;
    while (charToTokenClass(charSequenceGet(this.r3y(), current)) === 0) {
      current = current + 1 | 0;
      if (current >= charSequenceLength(this.r3y())) {
        usedAppend = true;
        this.q3y(this.l3m_1, current);
        var eof = this.s3y(current);
        if (eof === -1) {
          this.l3m_1 = current;
          return decodedString(this, 0, 0);
        } else {
          current = eof;
        }
      }
    }
    var tmp;
    if (!usedAppend) {
      tmp = this.u1k(this.l3m_1, current);
    } else {
      tmp = decodedString(this, this.l3m_1, current);
    }
    var result = tmp;
    this.l3m_1 = current;
    return result;
  }
  q3y(fromIndex, toIndex) {
    this.o3m_1.ch(this.r3y(), fromIndex, toIndex);
  }
  k3t(allowLenientStrings) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var tokenStack = ArrayList.k();
    var lastToken = this.t3s();
    if (!(lastToken === 8) && !(lastToken === 6)) {
      this.x3s();
      return Unit_instance;
    }
    $l$loop: while (true) {
      lastToken = this.t3s();
      if (lastToken === 1) {
        if (allowLenientStrings)
          this.x3s();
        else
          this.l3t();
        continue $l$loop;
      }
      var tmp0_subject = lastToken;
      if (tmp0_subject === 8 || tmp0_subject === 6) {
        tokenStack.l(lastToken);
      } else if (tmp0_subject === 9) {
        if (!(last(tokenStack) === 8))
          throw JsonDecodingException_0(this.l3m_1, 'found ] instead of } at path: ' + this.m3m_1.toString(), this.r3y());
        removeLast(tokenStack);
      } else if (tmp0_subject === 7) {
        if (!(last(tokenStack) === 6))
          throw JsonDecodingException_0(this.l3m_1, 'found } instead of ] at path: ' + this.m3m_1.toString(), this.r3y());
        removeLast(tokenStack);
      } else if (tmp0_subject === 10) {
        this.g3r('Unexpected end of input due to malformed JSON during ignoring unknown keys');
      }
      this.z3s();
      if (tokenStack.b1() === 0)
        return Unit_instance;
    }
  }
  toString() {
    return "JsonReader(source='" + toString(this.r3y()) + "', currentPosition=" + this.l3m_1 + ')';
  }
  j3t(key) {
    var processed = this.u1k(0, this.l3m_1);
    var lastIndexOf_0 = lastIndexOf(processed, key);
    throw JsonDecodingException.m3p("Encountered an unknown key '" + key + "' at offset " + lastIndexOf_0 + ' at path: ' + this.m3m_1.a3s() + "\nUse 'ignoreUnknownKeys = true' in 'Json {}' builder or '@JsonIgnoreUnknownKeys' annotation to ignore unknown keys.\n" + ('JSON input: ' + toString(minify(this.r3y(), lastIndexOf_0))));
  }
  f3r(message, position, hint) {
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(hint) === 0) {
      tmp = '';
    } else {
      tmp = '\n' + hint;
    }
    var hintMessage = tmp;
    throw JsonDecodingException_0(position, message + ' at path: ' + this.m3m_1.a3s() + hintMessage, this.r3y());
  }
  g3r(message, position, hint, $super) {
    position = position === VOID ? this.l3m_1 : position;
    hint = hint === VOID ? '' : hint;
    return $super === VOID ? this.f3r(message, position, hint) : $super.f3r.call(this, message, position, hint);
  }
  u3t() {
    var current = this.u3y();
    current = this.s3y(current);
    if (current >= charSequenceLength(this.r3y()) || current === -1) {
      this.g3r('EOF');
    }
    var tmp;
    if (charSequenceGet(this.r3y(), current) === _Char___init__impl__6a9atx(34)) {
      current = current + 1 | 0;
      if (current === charSequenceLength(this.r3y())) {
        this.g3r('EOF');
      }
      tmp = true;
    } else {
      tmp = false;
    }
    var hasQuotation = tmp;
    var accumulator = new Long(0, 0);
    var exponentAccumulator = new Long(0, 0);
    var isNegative = false;
    var isExponentPositive = false;
    var hasExponent = false;
    var start = current;
    $l$loop_4: while (!(current === charSequenceLength(this.r3y()))) {
      var ch = charSequenceGet(this.r3y(), current);
      if ((ch === _Char___init__impl__6a9atx(101) || ch === _Char___init__impl__6a9atx(69)) && !hasExponent) {
        if (current === start) {
          this.g3r('Unexpected symbol ' + toString_1(ch) + ' in numeric literal');
        }
        isExponentPositive = true;
        hasExponent = true;
        current = current + 1 | 0;
        continue $l$loop_4;
      }
      if (ch === _Char___init__impl__6a9atx(45) && hasExponent) {
        if (current === start) {
          this.g3r("Unexpected symbol '-' in numeric literal");
        }
        isExponentPositive = false;
        current = current + 1 | 0;
        continue $l$loop_4;
      }
      if (ch === _Char___init__impl__6a9atx(43) && hasExponent) {
        if (current === start) {
          this.g3r("Unexpected symbol '+' in numeric literal");
        }
        isExponentPositive = true;
        current = current + 1 | 0;
        continue $l$loop_4;
      }
      if (ch === _Char___init__impl__6a9atx(45)) {
        if (!(current === start)) {
          this.g3r("Unexpected symbol '-' in numeric literal");
        }
        isNegative = true;
        current = current + 1 | 0;
        continue $l$loop_4;
      }
      var token = charToTokenClass(ch);
      if (!(token === 0))
        break $l$loop_4;
      current = current + 1 | 0;
      var digit = Char__minus_impl_a2frrh(ch, _Char___init__impl__6a9atx(48));
      if (!(0 <= digit ? digit <= 9 : false)) {
        this.g3r("Unexpected symbol '" + toString_1(ch) + "' in numeric literal");
      }
      if (hasExponent) {
        // Inline function 'kotlin.Long.times' call
        // Inline function 'kotlin.Long.plus' call
        exponentAccumulator = exponentAccumulator.w3(toLong(10)).u3(toLong(digit));
        continue $l$loop_4;
      }
      // Inline function 'kotlin.Long.times' call
      // Inline function 'kotlin.Long.minus' call
      accumulator = accumulator.w3(toLong(10)).v3(toLong(digit));
      if (accumulator.s1(new Long(0, 0)) > 0) {
        this.g3r('Numeric value overflow');
      }
    }
    var hasChars = !(current === start);
    if (start === current || (isNegative && start === (current - 1 | 0))) {
      this.g3r('Expected numeric literal');
    }
    if (hasQuotation) {
      if (!hasChars) {
        this.g3r('EOF');
      }
      if (!(charSequenceGet(this.r3y(), current) === _Char___init__impl__6a9atx(34))) {
        this.g3r('Expected closing quotation mark');
      }
      current = current + 1 | 0;
    }
    this.l3m_1 = current;
    if (hasExponent) {
      var doubleAccumulator = accumulator.m4() * consumeNumericLiteral$calculateExponent(exponentAccumulator, isExponentPositive);
      if (doubleAccumulator > (new Long(-1, 2147483647)).m4() || doubleAccumulator < (new Long(0, -2147483648)).m4()) {
        this.g3r('Numeric value overflow');
      }
      // Inline function 'kotlin.math.floor' call
      if (!(Math.floor(doubleAccumulator) === doubleAccumulator)) {
        this.g3r("Can't convert " + doubleAccumulator + ' to Long');
      }
      accumulator = numberToLong(doubleAccumulator);
    }
    var tmp_0;
    if (isNegative) {
      tmp_0 = accumulator;
    } else if (!accumulator.equals(new Long(0, -2147483648))) {
      tmp_0 = accumulator.b4();
    } else {
      this.g3r('Numeric value overflow');
    }
    return tmp_0;
  }
  n3o() {
    var result = this.u3t();
    var next = this.z3s();
    if (!(next === 10)) {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.fail' call
      var expected = tokenDescription(10);
      var position = true ? this.l3m_1 - 1 | 0 : this.l3m_1;
      var s = this.l3m_1 === charSequenceLength(this.r3y()) || position < 0 ? 'EOF' : toString_1(charSequenceGet(this.r3y(), position));
      var tmp$ret$0 = "Expected input to contain a single valid number, but got '" + s + "' after it";
      this.g3r(tmp$ret$0, position);
    }
    return result;
  }
  t3t() {
    var current = this.u3y();
    if (current === charSequenceLength(this.r3y())) {
      this.g3r('EOF');
    }
    var tmp;
    if (charSequenceGet(this.r3y(), current) === _Char___init__impl__6a9atx(34)) {
      current = current + 1 | 0;
      tmp = true;
    } else {
      tmp = false;
    }
    var hasQuotation = tmp;
    var result = consumeBoolean2(this, current);
    if (hasQuotation) {
      if (this.l3m_1 === charSequenceLength(this.r3y())) {
        this.g3r('EOF');
      }
      if (!(charSequenceGet(this.r3y(), this.l3m_1) === _Char___init__impl__6a9atx(34))) {
        this.g3r('Expected closing quotation mark');
      }
      this.l3m_1 = this.l3m_1 + 1 | 0;
    }
    return result;
  }
}
class CharMappings {
  constructor() {
    CharMappings_instance = this;
    this.y3y_1 = charArray(117);
    this.z3y_1 = new Int8Array(126);
    initEscape(this);
    initCharToToken(this);
  }
}
class StringJsonLexer extends AbstractJsonLexer {
  constructor(source) {
    super();
    this.j3z_1 = source;
  }
  r3y() {
    return this.j3z_1;
  }
  s3y(position) {
    return position < this.r3y().length ? position : -1;
  }
  z3s() {
    var source = this.r3y();
    var cpos = this.l3m_1;
    $l$loop: while (!(cpos === -1) && cpos < source.length) {
      var _unary__edvuaz = cpos;
      cpos = _unary__edvuaz + 1 | 0;
      var c = charSequenceGet(source, _unary__edvuaz);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9))
        continue $l$loop;
      this.l3m_1 = cpos;
      return charToTokenClass(c);
    }
    this.l3m_1 = source.length;
    return 10;
  }
  v3s() {
    var current = this.l3m_1;
    if (current === -1)
      return false;
    var source = this.r3y();
    $l$loop: while (current < source.length) {
      var c = charSequenceGet(source, current);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9)) {
        current = current + 1 | 0;
        continue $l$loop;
      }
      this.l3m_1 = current;
      return this.v3y(c);
    }
    this.l3m_1 = current;
    return false;
  }
  u3y() {
    var current = this.l3m_1;
    if (current === -1)
      return current;
    var source = this.r3y();
    $l$loop: while (current < source.length) {
      var c = charSequenceGet(source, current);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9)) {
        current = current + 1 | 0;
      } else {
        break $l$loop;
      }
    }
    this.l3m_1 = current;
    return current;
  }
  f3t(expected) {
    if (this.l3m_1 === -1) {
      this.w3y(expected);
    }
    var source = this.r3y();
    var cpos = this.l3m_1;
    $l$loop: while (cpos < source.length) {
      var _unary__edvuaz = cpos;
      cpos = _unary__edvuaz + 1 | 0;
      var c = charSequenceGet(source, _unary__edvuaz);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9))
        continue $l$loop;
      this.l3m_1 = cpos;
      if (c === expected)
        return Unit_instance;
      this.w3y(expected);
    }
    this.l3m_1 = -1;
    this.w3y(expected);
  }
  l3t() {
    this.f3t(_Char___init__impl__6a9atx(34));
    var current = this.l3m_1;
    var closingQuote = indexOf_0(this.r3y(), _Char___init__impl__6a9atx(34), current);
    if (closingQuote === -1) {
      this.x3s();
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.fail' call
      var expected = tokenDescription(1);
      var position = false ? this.l3m_1 - 1 | 0 : this.l3m_1;
      var s = this.l3m_1 === charSequenceLength(this.r3y()) || position < 0 ? 'EOF' : toString_1(charSequenceGet(this.r3y(), position));
      var tmp$ret$0 = 'Expected ' + expected + ", but had '" + s + "' instead";
      this.g3r(tmp$ret$0, position);
    }
    var inductionVariable = current;
    if (inductionVariable < closingQuote)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (charSequenceGet(this.r3y(), i) === _Char___init__impl__6a9atx(92)) {
          return this.consumeString2(this.r3y(), this.l3m_1, i);
        }
      }
       while (inductionVariable < closingQuote);
    this.l3m_1 = closingQuote + 1 | 0;
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    return this.r3y().substring(current, closingQuote);
  }
  n3t(keyToMatch, isLenient) {
    var positionSnapshot = this.l3m_1;
    try {
      if (!(this.z3s() === 6))
        return null;
      var firstKey = this.i3t(isLenient);
      if (!(firstKey === keyToMatch))
        return null;
      this.x3y();
      if (!(this.z3s() === 5))
        return null;
      return this.i3t(isLenient);
    }finally {
      this.l3m_1 = positionSnapshot;
      this.x3y();
    }
  }
}
class StringJsonLexerWithComments extends StringJsonLexer {
  z3s() {
    var source = this.r3y();
    var cpos = this.u3y();
    if (cpos >= source.length || cpos === -1)
      return 10;
    this.l3m_1 = cpos + 1 | 0;
    return charToTokenClass(charSequenceGet(source, cpos));
  }
  v3s() {
    var current = this.u3y();
    if (current >= this.r3y().length || current === -1)
      return false;
    return this.v3y(charSequenceGet(this.r3y(), current));
  }
  f3t(expected) {
    var source = this.r3y();
    var current = this.u3y();
    if (current >= source.length || current === -1) {
      this.l3m_1 = -1;
      this.w3y(expected);
    }
    var c = charSequenceGet(source, current);
    this.l3m_1 = current + 1 | 0;
    if (c === expected)
      return Unit_instance;
    else {
      this.w3y(expected);
    }
  }
  t3s() {
    var source = this.r3y();
    var cpos = this.u3y();
    if (cpos >= source.length || cpos === -1)
      return 10;
    this.l3m_1 = cpos;
    return charToTokenClass(charSequenceGet(source, cpos));
  }
  u3y() {
    var current = this.l3m_1;
    if (current === -1)
      return current;
    var source = this.r3y();
    $l$loop_1: while (current < source.length) {
      var c = charSequenceGet(source, current);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9)) {
        current = current + 1 | 0;
        continue $l$loop_1;
      }
      if (c === _Char___init__impl__6a9atx(47) && (current + 1 | 0) < source.length) {
        var tmp0_subject = charSequenceGet(source, current + 1 | 0);
        if (tmp0_subject === _Char___init__impl__6a9atx(47)) {
          current = indexOf_0(source, _Char___init__impl__6a9atx(10), current + 2 | 0);
          if (current === -1) {
            current = source.length;
          } else {
            current = current + 1 | 0;
          }
          continue $l$loop_1;
        } else if (tmp0_subject === _Char___init__impl__6a9atx(42)) {
          current = indexOf(source, '*/', current + 2 | 0);
          if (current === -1) {
            this.l3m_1 = source.length;
            this.g3r('Expected end of the block comment: "*/", but had EOF instead');
          } else {
            current = current + 2 | 0;
          }
          continue $l$loop_1;
        }
      }
      break $l$loop_1;
    }
    this.l3m_1 = current;
    return current;
  }
}
class JsonToStringWriter {
  constructor() {
    this.c3m_1 = StringBuilder.xb(128);
  }
  e3q(value) {
    this.c3m_1.gh(value);
  }
  y3p(char) {
    this.c3m_1.ub(char);
  }
  a3q(text) {
    this.c3m_1.tb(text);
  }
  k3q(text) {
    printQuoted(this.c3m_1, text);
  }
  d1i() {
    this.c3m_1.jh();
  }
  toString() {
    return this.c3m_1.toString();
  }
}
//endregion
var Default_instance;
function Default_getInstance() {
  if (Default_instance === VOID)
    new Default();
  return Default_instance;
}
function Json_0(from, builderAction) {
  from = from === VOID ? Default_getInstance() : from;
  var builder = new JsonBuilder(from);
  builderAction(builder);
  var conf = builder.i3n();
  return new JsonImpl(conf, builder.h3n_1);
}
function validateConfiguration($this) {
  if (equals($this.f1y(), EmptySerializersModule()))
    return Unit_instance;
  var collector = new JsonSerializersModuleValidator($this.v3l_1);
  $this.f1y().r2e(collector);
}
var ClassDiscriminatorMode_NONE_instance;
var ClassDiscriminatorMode_ALL_JSON_OBJECTS_instance;
var ClassDiscriminatorMode_POLYMORPHIC_instance;
var ClassDiscriminatorMode_entriesInitialized;
function ClassDiscriminatorMode_initEntries() {
  if (ClassDiscriminatorMode_entriesInitialized)
    return Unit_instance;
  ClassDiscriminatorMode_entriesInitialized = true;
  ClassDiscriminatorMode_NONE_instance = new ClassDiscriminatorMode('NONE', 0);
  ClassDiscriminatorMode_ALL_JSON_OBJECTS_instance = new ClassDiscriminatorMode('ALL_JSON_OBJECTS', 1);
  ClassDiscriminatorMode_POLYMORPHIC_instance = new ClassDiscriminatorMode('POLYMORPHIC', 2);
}
function ClassDiscriminatorMode_NONE_getInstance() {
  ClassDiscriminatorMode_initEntries();
  return ClassDiscriminatorMode_NONE_instance;
}
function ClassDiscriminatorMode_POLYMORPHIC_getInstance() {
  ClassDiscriminatorMode_initEntries();
  return ClassDiscriminatorMode_POLYMORPHIC_instance;
}
function get_jsonUnquotedLiteralDescriptor() {
  _init_properties_JsonElement_kt__7cbdc2();
  return jsonUnquotedLiteralDescriptor;
}
var jsonUnquotedLiteralDescriptor;
var Companion_instance;
function Companion_getInstance_3() {
  return Companion_instance;
}
function JsonObject$toString$lambda(_destruct__k2r9zo) {
  // Inline function 'kotlin.collections.component1' call
  var k = _destruct__k2r9zo.m1();
  // Inline function 'kotlin.collections.component2' call
  var v = _destruct__k2r9zo.n1();
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  printQuoted(this_0, k);
  this_0.ub(_Char___init__impl__6a9atx(58));
  this_0.sb(v);
  return this_0.toString();
}
var Companion_instance_0;
function Companion_getInstance_4() {
  return Companion_instance_0;
}
var Companion_instance_1;
function Companion_getInstance_5() {
  return Companion_instance_1;
}
var JsonNull_instance;
function JsonNull_getInstance() {
  if (JsonNull_instance === VOID)
    new JsonNull();
  return JsonNull_instance;
}
var Companion_instance_2;
function Companion_getInstance_6() {
  return Companion_instance_2;
}
function get_jsonObject(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof JsonObject ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    error(_this__u8e3s4, 'JsonObject');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function get_jsonPrimitive(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof JsonPrimitive ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    error(_this__u8e3s4, 'JsonPrimitive');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function JsonPrimitive_0(value) {
  _init_properties_JsonElement_kt__7cbdc2();
  if (value == null)
    return JsonNull_getInstance();
  return new JsonLiteral(value, false);
}
function JsonPrimitive_1(value) {
  _init_properties_JsonElement_kt__7cbdc2();
  if (value == null)
    return JsonNull_getInstance();
  return new JsonLiteral(value, true);
}
function JsonPrimitive_2(value) {
  _init_properties_JsonElement_kt__7cbdc2();
  if (value == null)
    return JsonNull_getInstance();
  return new JsonLiteral(value, false);
}
function get_contentOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  var tmp;
  if (_this__u8e3s4 instanceof JsonNull) {
    tmp = null;
  } else {
    tmp = _this__u8e3s4.j3o();
  }
  return tmp;
}
function get_intOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  // Inline function 'kotlinx.serialization.json.exceptionToNull' call
  var tmp;
  try {
    tmp = parseLongImpl(_this__u8e3s4);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof JsonDecodingException) {
      var e = $p;
      tmp_0 = null;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  var tmp0_elvis_lhs = tmp;
  var tmp_1;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp_1 = tmp0_elvis_lhs;
  }
  var result = tmp_1;
  // Inline function 'kotlin.ranges.contains' call
  var this_0 = numberRangeToNumber(-2147483648, 2147483647);
  if (!contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), result))
    return null;
  return result.x1();
}
function get_longOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  // Inline function 'kotlinx.serialization.json.exceptionToNull' call
  var tmp;
  try {
    tmp = parseLongImpl(_this__u8e3s4);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof JsonDecodingException) {
      var e = $p;
      tmp_0 = null;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function get_doubleOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return toDoubleOrNull(_this__u8e3s4.j3o());
}
function get_booleanOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return toBooleanStrictOrNull_0(_this__u8e3s4.j3o());
}
function error(_this__u8e3s4, element) {
  _init_properties_JsonElement_kt__7cbdc2();
  throw IllegalArgumentException.t('Element ' + toString(getKClassFromExpression(_this__u8e3s4)) + ' is not a ' + element);
}
function parseLongImpl(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return (new StringJsonLexer(_this__u8e3s4.j3o())).n3o();
}
function get_float(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  // Inline function 'kotlin.text.toFloat' call
  var this_0 = _this__u8e3s4.j3o();
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return toDouble(this_0);
}
function get_double(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return toDouble(_this__u8e3s4.j3o());
}
var properties_initialized_JsonElement_kt_abxy8s;
function _init_properties_JsonElement_kt__7cbdc2() {
  if (!properties_initialized_JsonElement_kt_abxy8s) {
    properties_initialized_JsonElement_kt_abxy8s = true;
    jsonUnquotedLiteralDescriptor = InlinePrimitiveDescriptor('kotlinx.serialization.json.JsonUnquotedLiteral', serializer(StringCompanionObject_instance));
  }
}
function JsonElementSerializer$descriptor$lambda($this$buildSerialDescriptor) {
  $this$buildSerialDescriptor.s1t('JsonPrimitive', defer(JsonElementSerializer$descriptor$lambda$lambda));
  $this$buildSerialDescriptor.s1t('JsonNull', defer(JsonElementSerializer$descriptor$lambda$lambda_0));
  $this$buildSerialDescriptor.s1t('JsonLiteral', defer(JsonElementSerializer$descriptor$lambda$lambda_1));
  $this$buildSerialDescriptor.s1t('JsonObject', defer(JsonElementSerializer$descriptor$lambda$lambda_2));
  $this$buildSerialDescriptor.s1t('JsonArray', defer(JsonElementSerializer$descriptor$lambda$lambda_3));
  return Unit_instance;
}
function JsonElementSerializer$descriptor$lambda$lambda() {
  return JsonPrimitiveSerializer_getInstance().s3o_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_0() {
  return JsonNullSerializer_getInstance().t3o_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_1() {
  return JsonLiteralSerializer_getInstance().u3o_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_2() {
  return JsonObjectSerializer_getInstance().v3o_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_3() {
  return JsonArraySerializer_getInstance().w3o_1;
}
var JsonElementSerializer_instance;
function JsonElementSerializer_getInstance() {
  if (JsonElementSerializer_instance === VOID)
    new JsonElementSerializer();
  return JsonElementSerializer_instance;
}
var JsonObjectDescriptor_instance;
function JsonObjectDescriptor_getInstance() {
  if (JsonObjectDescriptor_instance === VOID)
    new JsonObjectDescriptor();
  return JsonObjectDescriptor_instance;
}
var JsonObjectSerializer_instance;
function JsonObjectSerializer_getInstance() {
  if (JsonObjectSerializer_instance === VOID)
    new JsonObjectSerializer();
  return JsonObjectSerializer_instance;
}
var JsonArrayDescriptor_instance;
function JsonArrayDescriptor_getInstance() {
  if (JsonArrayDescriptor_instance === VOID)
    new JsonArrayDescriptor();
  return JsonArrayDescriptor_instance;
}
var JsonArraySerializer_instance;
function JsonArraySerializer_getInstance() {
  if (JsonArraySerializer_instance === VOID)
    new JsonArraySerializer();
  return JsonArraySerializer_instance;
}
var JsonNullSerializer_instance;
function JsonNullSerializer_getInstance() {
  if (JsonNullSerializer_instance === VOID)
    new JsonNullSerializer();
  return JsonNullSerializer_instance;
}
var JsonPrimitiveSerializer_instance;
function JsonPrimitiveSerializer_getInstance() {
  if (JsonPrimitiveSerializer_instance === VOID)
    new JsonPrimitiveSerializer();
  return JsonPrimitiveSerializer_instance;
}
function defer(deferred) {
  return new defer$1(deferred);
}
var JsonLiteralSerializer_instance;
function JsonLiteralSerializer_getInstance() {
  if (JsonLiteralSerializer_instance === VOID)
    new JsonLiteralSerializer();
  return JsonLiteralSerializer_instance;
}
function verify(encoder) {
  asJsonEncoder(encoder);
}
function asJsonDecoder(_this__u8e3s4) {
  var tmp0_elvis_lhs = isInterface(_this__u8e3s4, JsonDecoder) ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException.t4('This serializer can be used only with Json format.' + ('Expected Decoder to be JsonDecoder, got ' + toString(getKClassFromExpression(_this__u8e3s4))));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function verify_0(decoder) {
  asJsonDecoder(decoder);
}
function asJsonEncoder(_this__u8e3s4) {
  var tmp0_elvis_lhs = isInterface(_this__u8e3s4, JsonEncoder) ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException.t4('This serializer can be used only with Json format.' + ('Expected Encoder to be JsonEncoder, got ' + toString(getKClassFromExpression(_this__u8e3s4))));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function _get_original__l7ku1m($this) {
  var tmp0 = $this.p3p_1;
  // Inline function 'kotlin.getValue' call
  original$factory();
  return tmp0.n1();
}
function original$factory() {
  return getPropertyCallableRef('original', 1, KProperty1, (receiver) => _get_original__l7ku1m(receiver), null);
}
function Composer_0(sb, json) {
  return json.v3l_1.n3n_1 ? new ComposerWithPrettyPrint(sb, json) : new Composer(sb);
}
function readIfAbsent($this, descriptor, index) {
  $this.w3q_1 = (!descriptor.c1w(index) && descriptor.b1w(index).q1v());
  return $this.w3q_1;
}
function JsonElementMarker$readIfAbsent$ref($boundThis) {
  var l = (p0, p1) => readIfAbsent($boundThis, p0, p1);
  l.callableName = 'readIfAbsent';
  return l;
}
function invalidTrailingComma(_this__u8e3s4, entity) {
  entity = entity === VOID ? 'object' : entity;
  _this__u8e3s4.f3r('Trailing comma before the end of JSON ' + entity, _this__u8e3s4.l3m_1 - 1 | 0, "Trailing commas are non-complaint JSON and not allowed by default. Use 'allowTrailingComma = true' in 'Json {}' builder to support them.");
}
function throwInvalidFloatingPointDecoded(_this__u8e3s4, result) {
  _this__u8e3s4.g3r('Unexpected special floating-point value ' + toString(result) + '. By default, ' + 'non-finite floating point values are prohibited because they do not conform JSON specification', VOID, "It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'");
}
function InvalidKeyKindException(keyDescriptor) {
  return JsonEncodingException.n3r("Value of type '" + keyDescriptor.k1u() + "' can't be used in JSON as a key in the map. " + ("It should have either primitive or enum kind, but its kind is '" + keyDescriptor.u1v().toString() + "'.\n") + "Use 'allowStructuredMapKeys = true' in 'Json {}' builder to convert such maps to [key1, value1, key2, value2,...] arrays.");
}
function InvalidFloatingPointEncoded(value, key, output) {
  return JsonEncodingException.n3r(unexpectedFpErrorMessage(value, key, output));
}
function JsonDecodingException_0(offset, message, input) {
  return JsonDecodingException_1(offset, message + '\nJSON input: ' + toString(minify(input, offset)));
}
function InvalidFloatingPointDecoded(value, key, output) {
  return JsonDecodingException_1(-1, unexpectedFpErrorMessage(value, key, output));
}
function JsonDecodingException_1(offset, message) {
  return JsonDecodingException.m3p(offset >= 0 ? 'Unexpected JSON token at offset ' + offset + ': ' + message : message);
}
function minify(_this__u8e3s4, offset) {
  offset = offset === VOID ? -1 : offset;
  if (charSequenceLength(_this__u8e3s4) < 200)
    return _this__u8e3s4;
  if (offset === -1) {
    var start = charSequenceLength(_this__u8e3s4) - 60 | 0;
    if (start <= 0)
      return _this__u8e3s4;
    // Inline function 'kotlin.text.substring' call
    var endIndex = charSequenceLength(_this__u8e3s4);
    return '.....' + toString(charSequenceSubSequence(_this__u8e3s4, start, endIndex));
  }
  var start_0 = offset - 30 | 0;
  var end = offset + 30 | 0;
  var prefix = start_0 <= 0 ? '' : '.....';
  var suffix = end >= charSequenceLength(_this__u8e3s4) ? '' : '.....';
  var tmp4 = coerceAtLeast(start_0, 0);
  // Inline function 'kotlin.text.substring' call
  var endIndex_0 = coerceAtMost(end, charSequenceLength(_this__u8e3s4));
  return prefix + toString(charSequenceSubSequence(_this__u8e3s4, tmp4, endIndex_0)) + suffix;
}
function unexpectedFpErrorMessage(value, key, output) {
  return 'Unexpected special floating-point value ' + toString(value) + ' with key ' + key + '. By default, ' + "non-finite floating point values are prohibited because they do not conform JSON specification. It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'\n" + ('Current output: ' + toString(minify(output)));
}
function InvalidFloatingPointEncoded_0(value, output) {
  return JsonEncodingException.n3r('Unexpected special floating-point value ' + toString(value) + '. By default, ' + "non-finite floating point values are prohibited because they do not conform JSON specification. It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'\n" + ('Current output: ' + toString(minify(output))));
}
function get_JsonDeserializationNamesKey() {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return JsonDeserializationNamesKey;
}
var JsonDeserializationNamesKey;
function get_JsonSerializationNamesKey() {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return JsonSerializationNamesKey;
}
var JsonSerializationNamesKey;
function ignoreUnknownKeys(_this__u8e3s4, json) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp;
  if (json.v3l_1.k3n_1) {
    tmp = true;
  } else {
    var tmp0 = _this__u8e3s4.x1v();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp_0;
      if (isInterface(tmp0, Collection)) {
        tmp_0 = tmp0.h1();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (element instanceof JsonIgnoreUnknownKeys) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    tmp = tmp$ret$0;
  }
  return tmp;
}
function getJsonNameIndex(_this__u8e3s4, json, name) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  if (decodeCaseInsensitive(json, _this__u8e3s4)) {
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$1 = name.toLowerCase();
    return getJsonNameIndexSlowPath(_this__u8e3s4, json, tmp$ret$1);
  }
  var strategy = namingStrategy(_this__u8e3s4, json);
  if (!(strategy == null))
    return getJsonNameIndexSlowPath(_this__u8e3s4, json, name);
  var index = _this__u8e3s4.z1v(name);
  if (!(index === -3))
    return index;
  if (!json.v3l_1.u3n_1)
    return index;
  return getJsonNameIndexSlowPath(_this__u8e3s4, json, name);
}
function getJsonNameIndexOrThrow(_this__u8e3s4, json, name, suffix) {
  suffix = suffix === VOID ? '' : suffix;
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var index = getJsonNameIndex(_this__u8e3s4, json, name);
  if (index === -3)
    throw SerializationException.t1u(_this__u8e3s4.k1u() + " does not contain element with name '" + name + "'" + suffix);
  return index;
}
function getJsonElementName(_this__u8e3s4, json, index) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var strategy = namingStrategy(_this__u8e3s4, json);
  return strategy == null ? _this__u8e3s4.y1v(index) : serializationNamesIndices(_this__u8e3s4, json, strategy)[index];
}
function namingStrategy(_this__u8e3s4, json) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return equals(_this__u8e3s4.u1v(), CLASS_getInstance()) ? json.v3l_1.v3n_1 : null;
}
function deserializationNamesMap(_this__u8e3s4, descriptor) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp = get_schemaCache(_this__u8e3s4);
  var tmp_0 = get_JsonDeserializationNamesKey();
  return tmp.p3r(descriptor, tmp_0, deserializationNamesMap$lambda(descriptor, _this__u8e3s4));
}
function decodeCaseInsensitive(_this__u8e3s4, descriptor) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return _this__u8e3s4.v3l_1.w3n_1 && equals(descriptor.u1v(), ENUM_getInstance());
}
function getJsonNameIndexSlowPath(_this__u8e3s4, json, name) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp0_elvis_lhs = deserializationNamesMap(json, _this__u8e3s4).h3(name);
  return tmp0_elvis_lhs == null ? -3 : tmp0_elvis_lhs;
}
function serializationNamesIndices(_this__u8e3s4, json, strategy) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp = get_schemaCache(json);
  var tmp_0 = get_JsonSerializationNamesKey();
  return tmp.p3r(_this__u8e3s4, tmp_0, serializationNamesIndices$lambda(_this__u8e3s4, strategy));
}
function buildDeserializationNamesMap(_this__u8e3s4, json) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  // Inline function 'kotlin.collections.mutableMapOf' call
  var builder = LinkedHashMap.hc();
  var useLowercaseEnums = decodeCaseInsensitive(json, _this__u8e3s4);
  var strategyForClasses = namingStrategy(_this__u8e3s4, json);
  var inductionVariable = 0;
  var last = _this__u8e3s4.w1v();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.collections.filterIsInstance' call
      var tmp0 = _this__u8e3s4.a1w(i);
      // Inline function 'kotlin.collections.filterIsInstanceTo' call
      var destination = ArrayList.k();
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (element instanceof JsonNames) {
          destination.l(element);
        }
      }
      var tmp0_safe_receiver = singleOrNull(destination);
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.q3r_1;
      if (tmp1_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var inductionVariable_0 = 0;
        var last_0 = tmp1_safe_receiver.length;
        while (inductionVariable_0 < last_0) {
          var element_0 = tmp1_safe_receiver[inductionVariable_0];
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          var tmp;
          if (useLowercaseEnums) {
            // Inline function 'kotlin.text.lowercase' call
            // Inline function 'kotlin.js.asDynamic' call
            tmp = element_0.toLowerCase();
          } else {
            tmp = element_0;
          }
          buildDeserializationNamesMap$putOrThrow(builder, _this__u8e3s4, tmp, i);
        }
      }
      var tmp_0;
      if (useLowercaseEnums) {
        // Inline function 'kotlin.text.lowercase' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp_0 = _this__u8e3s4.y1v(i).toLowerCase();
      } else if (!(strategyForClasses == null)) {
        tmp_0 = strategyForClasses.r3r(_this__u8e3s4, i, _this__u8e3s4.y1v(i));
      } else {
        tmp_0 = null;
      }
      var nameToPut = tmp_0;
      if (nameToPut == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        buildDeserializationNamesMap$putOrThrow(builder, _this__u8e3s4, nameToPut, i);
      }
    }
     while (inductionVariable < last);
  // Inline function 'kotlin.collections.ifEmpty' call
  var tmp_1;
  if (builder.h1()) {
    tmp_1 = emptyMap();
  } else {
    tmp_1 = builder;
  }
  return tmp_1;
}
function buildDeserializationNamesMap$putOrThrow(_this__u8e3s4, $this_buildDeserializationNamesMap, name, index) {
  var entity = equals($this_buildDeserializationNamesMap.u1v(), ENUM_getInstance()) ? 'enum value' : 'property';
  // Inline function 'kotlin.collections.contains' call
  // Inline function 'kotlin.collections.containsKey' call
  if ((isInterface(_this__u8e3s4, KtMap) ? _this__u8e3s4 : THROW_CCE()).f3(name)) {
    throw JsonException.e3r("The suggested name '" + name + "' for " + entity + ' ' + $this_buildDeserializationNamesMap.y1v(index) + ' is already one of the names for ' + entity + ' ' + ($this_buildDeserializationNamesMap.y1v(getValue(_this__u8e3s4, name)) + ' in ' + toString($this_buildDeserializationNamesMap)));
  }
  // Inline function 'kotlin.collections.set' call
  _this__u8e3s4.k3(name, index);
}
function deserializationNamesMap$lambda($descriptor, $this_deserializationNamesMap) {
  return () => buildDeserializationNamesMap($descriptor, $this_deserializationNamesMap);
}
function serializationNamesIndices$lambda($this_serializationNamesIndices, $strategy) {
  return () => {
    var tmp = 0;
    var tmp_0 = $this_serializationNamesIndices.w1v();
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      var baseName = $this_serializationNamesIndices.y1v(tmp_2);
      tmp_1[tmp_2] = $strategy.r3r($this_serializationNamesIndices, tmp_2, baseName);
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  };
}
var properties_initialized_JsonNamesMap_kt_ljpf42;
function _init_properties_JsonNamesMap_kt__cbbp0k() {
  if (!properties_initialized_JsonNamesMap_kt_ljpf42) {
    properties_initialized_JsonNamesMap_kt_ljpf42 = true;
    JsonDeserializationNamesKey = new Key();
    JsonSerializationNamesKey = new Key();
  }
}
var Tombstone_instance;
function Tombstone_getInstance() {
  return Tombstone_instance;
}
function resize($this) {
  var newSize = imul($this.u3r_1, 2);
  $this.s3r_1 = copyOf($this.s3r_1, newSize);
  $this.t3r_1 = copyOf_0($this.t3r_1, newSize);
}
function checkKind($this, descriptor, actualClass) {
  var kind = descriptor.u1v();
  var tmp;
  if (kind instanceof PolymorphicKind) {
    tmp = true;
  } else {
    tmp = equals(kind, CONTEXTUAL_getInstance());
  }
  if (tmp) {
    throw IllegalArgumentException.t('Serializer for ' + actualClass.hf() + " can't be registered as a subclass for polymorphic serialization " + ('because its kind ' + kind.toString() + ' is not concrete. To work with multiple hierarchies, register it as a base class.'));
  }
  if ($this.c3s_1)
    return Unit_instance;
  if (!$this.d3s_1)
    return Unit_instance;
  var tmp_0;
  var tmp_1;
  if (equals(kind, LIST_getInstance()) || equals(kind, MAP_getInstance())) {
    tmp_1 = true;
  } else {
    tmp_1 = kind instanceof PrimitiveKind;
  }
  if (tmp_1) {
    tmp_0 = true;
  } else {
    tmp_0 = kind instanceof ENUM;
  }
  if (tmp_0) {
    throw IllegalArgumentException.t('Serializer for ' + actualClass.hf() + ' of kind ' + kind.toString() + ' cannot be serialized polymorphically with class discriminator.');
  }
}
function checkDiscriminatorCollisions($this, descriptor, actualClass) {
  var inductionVariable = 0;
  var last = descriptor.w1v();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var name = descriptor.y1v(i);
      if (name === $this.b3s_1) {
        throw IllegalArgumentException.t('Polymorphic serializer for ' + toString(actualClass) + " has property '" + name + "' that conflicts " + 'with JSON class discriminator. You can either change class discriminator in JsonConfiguration, rename property with @SerialName annotation or fall back to array polymorphism');
      }
    }
     while (inductionVariable < last);
}
function encodeByWriter(json, writer, serializer, value) {
  var tmp = WriteMode_OBJ_getInstance();
  // Inline function 'kotlin.arrayOfNulls' call
  var size = get_entries().b1();
  var tmp$ret$0 = Array(size);
  var encoder = StreamingJsonEncoder.n3s(writer, json, tmp, tmp$ret$0);
  encoder.j1z(serializer, value);
}
function *_generator_invoke__zhh2q8($this, $this$DeepRecursiveFunction, it, $completion) {
  var tmp0_subject = $this.s3s_1.o3s_1.t3s();
  var tmp;
  if (tmp0_subject === 1) {
    tmp = readValue($this.s3s_1, true);
  } else if (tmp0_subject === 0) {
    tmp = readValue($this.s3s_1, false);
  } else if (tmp0_subject === 6) {
    var tmp_0 = readObject_0($this.s3s_1, $this$DeepRecursiveFunction, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } else if (tmp0_subject === 8) {
    tmp = readArray($this.s3s_1);
  } else {
    $this.s3s_1.o3s_1.g3r("Can't begin reading element, unexpected token");
  }
  return tmp;
}
function readObject($this) {
  // Inline function 'kotlinx.serialization.json.internal.JsonTreeReader.readObjectImpl' call
  var lastToken = $this.o3s_1.u3s(6);
  if ($this.o3s_1.t3s() === 4) {
    $this.o3s_1.g3r('Unexpected leading comma');
  }
  // Inline function 'kotlin.collections.linkedMapOf' call
  var result = LinkedHashMap.hc();
  $l$loop: while ($this.o3s_1.v3s()) {
    var key = $this.p3s_1 ? $this.o3s_1.x3s() : $this.o3s_1.w3s();
    $this.o3s_1.u3s(5);
    var element = $this.y3s();
    // Inline function 'kotlin.collections.set' call
    result.k3(key, element);
    lastToken = $this.o3s_1.z3s();
    var tmp0_subject = lastToken;
    if (tmp0_subject !== 4)
      if (tmp0_subject === 7)
        break $l$loop;
      else {
        $this.o3s_1.g3r('Expected end of the object or comma');
      }
  }
  if (lastToken === 6) {
    $this.o3s_1.u3s(7);
  } else if (lastToken === 4) {
    if (!$this.q3s_1) {
      invalidTrailingComma($this.o3s_1);
    }
    $this.o3s_1.u3s(7);
  }
  return new JsonObject(result);
}
function *_generator_readObject__361wel($this, _this__u8e3s4, $completion) {
  // Inline function 'kotlinx.serialization.json.internal.JsonTreeReader.readObjectImpl' call
  var lastToken = $this.o3s_1.u3s(6);
  if ($this.o3s_1.t3s() === 4) {
    $this.o3s_1.g3r('Unexpected leading comma');
  }
  // Inline function 'kotlin.collections.linkedMapOf' call
  var result = LinkedHashMap.hc();
  $l$loop: while ($this.o3s_1.v3s()) {
    var key = $this.p3s_1 ? $this.o3s_1.x3s() : $this.o3s_1.w3s();
    $this.o3s_1.u3s(5);
    var tmp = _this__u8e3s4.or(Unit_instance, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var element = tmp;
    // Inline function 'kotlin.collections.set' call
    result.k3(key, element);
    lastToken = $this.o3s_1.z3s();
    var tmp0_subject = lastToken;
    if (tmp0_subject !== 4)
      if (tmp0_subject === 7)
        break $l$loop;
      else {
        $this.o3s_1.g3r('Expected end of the object or comma');
      }
  }
  if (lastToken === 6) {
    $this.o3s_1.u3s(7);
  } else if (lastToken === 4) {
    if (!$this.q3s_1) {
      invalidTrailingComma($this.o3s_1);
    }
    $this.o3s_1.u3s(7);
  }
  return new JsonObject(result);
}
function readObject_0($this, _this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readObject__361wel.bind(VOID, $this, _this__u8e3s4), $completion);
}
function readArray($this) {
  var lastToken = $this.o3s_1.z3s();
  if ($this.o3s_1.t3s() === 4) {
    $this.o3s_1.g3r('Unexpected leading comma');
  }
  // Inline function 'kotlin.collections.arrayListOf' call
  var result = ArrayList.k();
  while ($this.o3s_1.v3s()) {
    var element = $this.y3s();
    result.l(element);
    lastToken = $this.o3s_1.z3s();
    if (!(lastToken === 4)) {
      var tmp0 = $this.o3s_1;
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.require' call
      var condition = lastToken === 9;
      var position = tmp0.l3m_1;
      if (!condition) {
        var tmp$ret$1 = 'Expected end of the array or comma';
        tmp0.g3r(tmp$ret$1, position);
      }
    }
  }
  if (lastToken === 8) {
    $this.o3s_1.u3s(9);
  } else if (lastToken === 4) {
    if (!$this.q3s_1) {
      invalidTrailingComma($this.o3s_1, 'array');
    }
    $this.o3s_1.u3s(9);
  }
  return new JsonArray(result);
}
function readValue($this, isString) {
  var tmp;
  if ($this.p3s_1 || !isString) {
    tmp = $this.o3s_1.x3s();
  } else {
    tmp = $this.o3s_1.w3s();
  }
  var string = tmp;
  if (!isString && string === 'null')
    return JsonNull_getInstance();
  return new JsonLiteral(string, isString);
}
function readDeepRecursive($this) {
  return invoke(new DeepRecursiveFunction(JsonTreeReader$readDeepRecursive$slambda_0($this)), Unit_instance);
}
function JsonTreeReader$readDeepRecursive$slambda_0(this$0) {
  var i = new JsonTreeReader$readDeepRecursive$slambda(this$0);
  var l = ($this$DeepRecursiveFunction, it, $completion) => i.a3t($this$DeepRecursiveFunction, it, $completion);
  l.$arity = 2;
  return l;
}
function classDiscriminator(_this__u8e3s4, json) {
  var _iterator__ex2g4s = _this__u8e3s4.x1v().y();
  while (_iterator__ex2g4s.z()) {
    var annotation = _iterator__ex2g4s.a1();
    if (annotation instanceof JsonClassDiscriminator)
      return annotation.b3t_1;
  }
  return json.v3l_1.s3n_1;
}
function validateIfSealed(serializer, actualSerializer, classDiscriminator) {
  if (!(serializer instanceof SealedClassSerializer))
    return Unit_instance;
  if (jsonCachedSerialNames(actualSerializer.h1t()).v2(classDiscriminator)) {
    var baseName = serializer.h1t().k1u();
    var actualName = actualSerializer.h1t().k1u();
    // Inline function 'kotlin.error' call
    var message = "Sealed class '" + actualName + "' cannot be serialized as base class '" + baseName + "' because" + (" it has property name that conflicts with JSON class discriminator '" + classDiscriminator + "'. ") + 'You can either change class discriminator in JsonConfiguration, rename property with @SerialName annotation or fall back to array polymorphism';
    throw IllegalStateException.t4(toString(message));
  }
}
function checkKind_0(kind) {
  if (kind instanceof ENUM) {
    // Inline function 'kotlin.error' call
    var message = "Enums cannot be serialized polymorphically with 'type' parameter. You can use 'JsonBuilder.useArrayPolymorphism' instead";
    throw IllegalStateException.t4(toString(message));
  }
  if (kind instanceof PrimitiveKind) {
    // Inline function 'kotlin.error' call
    var message_0 = "Primitives cannot be serialized polymorphically with 'type' parameter. You can use 'JsonBuilder.useArrayPolymorphism' instead";
    throw IllegalStateException.t4(toString(message_0));
  }
  if (kind instanceof PolymorphicKind) {
    // Inline function 'kotlin.error' call
    var message_1 = 'Actual serializer for polymorphic cannot be polymorphic itself';
    throw IllegalStateException.t4(toString(message_1));
  }
}
function access$validateIfSealed$tPolymorphicKt(serializer, actualSerializer, classDiscriminator) {
  return validateIfSealed(serializer, actualSerializer, classDiscriminator);
}
function trySkip($this, _this__u8e3s4, unknownKey) {
  if (_this__u8e3s4 == null)
    return false;
  if (_this__u8e3s4.e3t_1 === unknownKey) {
    _this__u8e3s4.e3t_1 = null;
    return true;
  }
  return false;
}
function skipLeftoverElements($this, descriptor) {
  while (!($this.h1y(descriptor) === -1)) {
  }
}
function checkLeadingComma($this) {
  if ($this.f3m_1.t3s() === 4) {
    $this.f3m_1.g3r('Unexpected leading comma');
  }
}
function decodeMapIndex($this) {
  var hasComma = false;
  var decodingKey = !(($this.h3m_1 % 2 | 0) === 0);
  if (decodingKey) {
    if (!($this.h3m_1 === -1)) {
      hasComma = $this.f3m_1.g3t();
    }
  } else {
    $this.f3m_1.f3t(_Char___init__impl__6a9atx(58));
  }
  var tmp;
  if ($this.f3m_1.v3s()) {
    if (decodingKey) {
      if ($this.h3m_1 === -1) {
        var tmp0 = $this.f3m_1;
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.require' call
        var condition = !hasComma;
        var position = tmp0.l3m_1;
        if (!condition) {
          var tmp$ret$0 = 'Unexpected leading comma';
          tmp0.g3r(tmp$ret$0, position);
        }
      } else {
        var tmp3 = $this.f3m_1;
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.require' call
        var condition_0 = hasComma;
        var position_0 = tmp3.l3m_1;
        if (!condition_0) {
          var tmp$ret$2 = 'Expected comma after the key-value pair';
          tmp3.g3r(tmp$ret$2, position_0);
        }
      }
    }
    $this.h3m_1 = $this.h3m_1 + 1 | 0;
    tmp = $this.h3m_1;
  } else {
    if (hasComma && !$this.d3m_1.v3l_1.x3n_1) {
      invalidTrailingComma($this.f3m_1);
    }
    tmp = -1;
  }
  return tmp;
}
function coerceInputValue($this, descriptor, index) {
  var tmp0 = $this.d3m_1;
  var tmp$ret$1;
  $l$block_2: {
    // Inline function 'kotlinx.serialization.json.internal.tryCoerceValue' call
    var isOptional = descriptor.c1w(index);
    var elementDescriptor = descriptor.b1w(index);
    var tmp;
    if (isOptional && !elementDescriptor.q1v()) {
      tmp = $this.f3m_1.h3t(true);
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$1 = true;
      break $l$block_2;
    }
    if (equals(elementDescriptor.u1v(), ENUM_getInstance())) {
      var tmp_0;
      if (elementDescriptor.q1v()) {
        tmp_0 = $this.f3m_1.h3t(false);
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$1 = false;
        break $l$block_2;
      }
      var tmp0_elvis_lhs = $this.f3m_1.i3t($this.j3m_1.l3n_1);
      var tmp_1;
      if (tmp0_elvis_lhs == null) {
        tmp$ret$1 = false;
        break $l$block_2;
      } else {
        tmp_1 = tmp0_elvis_lhs;
      }
      var enumValue = tmp_1;
      var enumIndex = getJsonNameIndex(elementDescriptor, tmp0, enumValue);
      var coerceToNull = !tmp0.v3l_1.o3n_1 && elementDescriptor.q1v();
      if (enumIndex === -3 && (isOptional || coerceToNull)) {
        $this.f3m_1.w3s();
        tmp$ret$1 = true;
        break $l$block_2;
      }
    }
    tmp$ret$1 = false;
  }
  return tmp$ret$1;
}
function decodeObjectIndex($this, descriptor) {
  var hasComma = $this.f3m_1.g3t();
  while ($this.f3m_1.v3s()) {
    hasComma = false;
    var key = decodeStringKey($this);
    $this.f3m_1.f3t(_Char___init__impl__6a9atx(58));
    var index = getJsonNameIndex(descriptor, $this.d3m_1, key);
    var tmp;
    if (!(index === -3)) {
      var tmp_0;
      if ($this.j3m_1.q3n_1 && coerceInputValue($this, descriptor, index)) {
        hasComma = $this.f3m_1.g3t();
        tmp_0 = false;
      } else {
        var tmp0_safe_receiver = $this.k3m_1;
        if (tmp0_safe_receiver == null)
          null;
        else {
          tmp0_safe_receiver.x3q(index);
        }
        return index;
      }
      tmp = tmp_0;
    } else {
      tmp = true;
    }
    var isUnknown = tmp;
    if (isUnknown) {
      hasComma = handleUnknown($this, descriptor, key);
    }
  }
  if (hasComma && !$this.d3m_1.v3l_1.x3n_1) {
    invalidTrailingComma($this.f3m_1);
  }
  var tmp1_safe_receiver = $this.k3m_1;
  var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.y3q();
  return tmp2_elvis_lhs == null ? -1 : tmp2_elvis_lhs;
}
function handleUnknown($this, descriptor, key) {
  if (ignoreUnknownKeys(descriptor, $this.d3m_1) || trySkip($this, $this.i3m_1, key)) {
    $this.f3m_1.k3t($this.j3m_1.l3n_1);
  } else {
    $this.f3m_1.m3m_1.z3r();
    $this.f3m_1.j3t(key);
  }
  return $this.f3m_1.g3t();
}
function decodeListIndex($this) {
  var hasComma = $this.f3m_1.g3t();
  var tmp;
  if ($this.f3m_1.v3s()) {
    if (!($this.h3m_1 === -1) && !hasComma) {
      $this.f3m_1.g3r('Expected end of the array or comma');
    }
    $this.h3m_1 = $this.h3m_1 + 1 | 0;
    tmp = $this.h3m_1;
  } else {
    if (hasComma && !$this.d3m_1.v3l_1.x3n_1) {
      invalidTrailingComma($this.f3m_1, 'array');
    }
    tmp = -1;
  }
  return tmp;
}
function decodeStringKey($this) {
  var tmp;
  if ($this.j3m_1.l3n_1) {
    tmp = $this.f3m_1.m3t();
  } else {
    tmp = $this.f3m_1.l3t();
  }
  return tmp;
}
function get_unsignedNumberDescriptors() {
  _init_properties_StreamingJsonEncoder_kt__pn1bsi();
  return unsignedNumberDescriptors;
}
var unsignedNumberDescriptors;
function encodeTypeInfo($this, discriminator, serialName) {
  $this.e3s_1.u3p();
  $this.v1y(discriminator);
  $this.e3s_1.x3p(_Char___init__impl__6a9atx(58));
  $this.e3s_1.w3p();
  $this.v1y(serialName);
}
function get_isUnsignedNumber(_this__u8e3s4) {
  _init_properties_StreamingJsonEncoder_kt__pn1bsi();
  return _this__u8e3s4.v1v() && get_unsignedNumberDescriptors().v2(_this__u8e3s4);
}
function get_isUnquotedLiteral(_this__u8e3s4) {
  _init_properties_StreamingJsonEncoder_kt__pn1bsi();
  return _this__u8e3s4.v1v() && equals(_this__u8e3s4, get_jsonUnquotedLiteralDescriptor());
}
var properties_initialized_StreamingJsonEncoder_kt_6ifwwk;
function _init_properties_StreamingJsonEncoder_kt__pn1bsi() {
  if (!properties_initialized_StreamingJsonEncoder_kt_6ifwwk) {
    properties_initialized_StreamingJsonEncoder_kt_6ifwwk = true;
    unsignedNumberDescriptors = setOf([serializer_1(Companion_getInstance_0()).h1t(), serializer_0(Companion_getInstance()).h1t(), serializer_2(Companion_getInstance_1()).h1t(), serializer_3(Companion_getInstance_2()).h1t()]);
  }
}
function get_ESCAPE_STRINGS() {
  _init_properties_StringOps_kt__fcy1db();
  return ESCAPE_STRINGS;
}
var ESCAPE_STRINGS;
var ESCAPE_MARKERS;
function toHexChar(i) {
  _init_properties_StringOps_kt__fcy1db();
  var d = i & 15;
  var tmp;
  if (d < 10) {
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(48);
    var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
    tmp = numberToChar(d + tmp$ret$0 | 0);
  } else {
    var tmp_0 = d - 10 | 0;
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(97);
    var tmp$ret$1 = Char__toInt_impl_vasixd(this_1);
    tmp = numberToChar(tmp_0 + tmp$ret$1 | 0);
  }
  return tmp;
}
function printQuoted(_this__u8e3s4, value) {
  _init_properties_StringOps_kt__fcy1db();
  _this__u8e3s4.ub(_Char___init__impl__6a9atx(34));
  var lastPos = 0;
  var inductionVariable = 0;
  var last = charSequenceLength(value) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(value, i);
      var c = Char__toInt_impl_vasixd(this_0);
      if (c < get_ESCAPE_STRINGS().length && !(get_ESCAPE_STRINGS()[c] == null)) {
        _this__u8e3s4.ch(value, lastPos, i);
        _this__u8e3s4.tb(get_ESCAPE_STRINGS()[c]);
        lastPos = i + 1 | 0;
      }
    }
     while (inductionVariable <= last);
  if (!(lastPos === 0))
    _this__u8e3s4.ch(value, lastPos, value.length);
  else
    _this__u8e3s4.tb(value);
  _this__u8e3s4.ub(_Char___init__impl__6a9atx(34));
}
function toBooleanStrictOrNull_0(_this__u8e3s4) {
  _init_properties_StringOps_kt__fcy1db();
  return equals_0(_this__u8e3s4, 'true', true) ? true : equals_0(_this__u8e3s4, 'false', true) ? false : null;
}
var properties_initialized_StringOps_kt_wzaea7;
function _init_properties_StringOps_kt__fcy1db() {
  if (!properties_initialized_StringOps_kt_wzaea7) {
    properties_initialized_StringOps_kt_wzaea7 = true;
    // Inline function 'kotlin.arrayOfNulls' call
    // Inline function 'kotlin.apply' call
    var this_0 = Array(93);
    var inductionVariable = 0;
    if (inductionVariable <= 31)
      do {
        var c = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var c1 = toHexChar(c >> 12);
        var c2 = toHexChar(c >> 8);
        var c3 = toHexChar(c >> 4);
        var c4 = toHexChar(c);
        this_0[c] = '\\u' + toString_1(c1) + toString_1(c2) + toString_1(c3) + toString_1(c4);
      }
       while (inductionVariable <= 31);
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(34);
    this_0[Char__toInt_impl_vasixd(this_1)] = '\\"';
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(92);
    this_0[Char__toInt_impl_vasixd(this_2)] = '\\\\';
    // Inline function 'kotlin.code' call
    var this_3 = _Char___init__impl__6a9atx(9);
    this_0[Char__toInt_impl_vasixd(this_3)] = '\\t';
    // Inline function 'kotlin.code' call
    var this_4 = _Char___init__impl__6a9atx(8);
    this_0[Char__toInt_impl_vasixd(this_4)] = '\\b';
    // Inline function 'kotlin.code' call
    var this_5 = _Char___init__impl__6a9atx(10);
    this_0[Char__toInt_impl_vasixd(this_5)] = '\\n';
    // Inline function 'kotlin.code' call
    var this_6 = _Char___init__impl__6a9atx(13);
    this_0[Char__toInt_impl_vasixd(this_6)] = '\\r';
    this_0[12] = '\\f';
    ESCAPE_STRINGS = this_0;
    // Inline function 'kotlin.apply' call
    var this_7 = new Int8Array(93);
    var inductionVariable_0 = 0;
    if (inductionVariable_0 <= 31)
      do {
        var c_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        this_7[c_0] = 1;
      }
       while (inductionVariable_0 <= 31);
    // Inline function 'kotlin.code' call
    var this_8 = _Char___init__impl__6a9atx(34);
    var tmp = Char__toInt_impl_vasixd(this_8);
    // Inline function 'kotlin.code' call
    var this_9 = _Char___init__impl__6a9atx(34);
    var tmp$ret$1 = Char__toInt_impl_vasixd(this_9);
    this_7[tmp] = toByte(tmp$ret$1);
    // Inline function 'kotlin.code' call
    var this_10 = _Char___init__impl__6a9atx(92);
    var tmp_0 = Char__toInt_impl_vasixd(this_10);
    // Inline function 'kotlin.code' call
    var this_11 = _Char___init__impl__6a9atx(92);
    var tmp$ret$3 = Char__toInt_impl_vasixd(this_11);
    this_7[tmp_0] = toByte(tmp$ret$3);
    // Inline function 'kotlin.code' call
    var this_12 = _Char___init__impl__6a9atx(9);
    var tmp_1 = Char__toInt_impl_vasixd(this_12);
    // Inline function 'kotlin.code' call
    var this_13 = _Char___init__impl__6a9atx(116);
    var tmp$ret$5 = Char__toInt_impl_vasixd(this_13);
    this_7[tmp_1] = toByte(tmp$ret$5);
    // Inline function 'kotlin.code' call
    var this_14 = _Char___init__impl__6a9atx(8);
    var tmp_2 = Char__toInt_impl_vasixd(this_14);
    // Inline function 'kotlin.code' call
    var this_15 = _Char___init__impl__6a9atx(98);
    var tmp$ret$7 = Char__toInt_impl_vasixd(this_15);
    this_7[tmp_2] = toByte(tmp$ret$7);
    // Inline function 'kotlin.code' call
    var this_16 = _Char___init__impl__6a9atx(10);
    var tmp_3 = Char__toInt_impl_vasixd(this_16);
    // Inline function 'kotlin.code' call
    var this_17 = _Char___init__impl__6a9atx(110);
    var tmp$ret$9 = Char__toInt_impl_vasixd(this_17);
    this_7[tmp_3] = toByte(tmp$ret$9);
    // Inline function 'kotlin.code' call
    var this_18 = _Char___init__impl__6a9atx(13);
    var tmp_4 = Char__toInt_impl_vasixd(this_18);
    // Inline function 'kotlin.code' call
    var this_19 = _Char___init__impl__6a9atx(114);
    var tmp$ret$11 = Char__toInt_impl_vasixd(this_19);
    this_7[tmp_4] = toByte(tmp$ret$11);
    // Inline function 'kotlin.code' call
    var this_20 = _Char___init__impl__6a9atx(102);
    var tmp$ret$12 = Char__toInt_impl_vasixd(this_20);
    this_7[12] = toByte(tmp$ret$12);
    ESCAPE_MARKERS = this_7;
  }
}
function unparsedPrimitive($this, literal, primitive, tag) {
  var type = startsWith(primitive, 'i') ? 'an ' + primitive : 'a ' + primitive;
  throw JsonDecodingException_0(-1, "Failed to parse literal '" + literal.toString() + "' as " + type + ' value at element: ' + $this.e3u(tag), toString($this.f3u()));
}
function setForceNull($this, descriptor, index) {
  $this.c3v_1 = (!$this.a3o().v3l_1.o3n_1 && !descriptor.c1w(index) && descriptor.b1w(index).q1v());
  return $this.c3v_1;
}
function readPolymorphicJson(_this__u8e3s4, discriminator, element, deserializer) {
  return (new JsonTreeDecoder(_this__u8e3s4, element, discriminator, deserializer.h1t())).p1x(deserializer);
}
function writeJson(json, value, serializer) {
  var result = {_v: null};
  var encoder = new JsonTreeEncoder(json, writeJson$lambda(result));
  encoder.j1z(serializer, value);
  var tmp;
  if (result._v == null) {
    throwUninitializedPropertyAccessException('result');
  } else {
    tmp = result._v;
  }
  return tmp;
}
function inlineUnsignedNumberEncoder($this, tag) {
  return AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1.n3x($this, tag);
}
function inlineUnquotedLiteralEncoder($this, tag, inlineDescriptor) {
  return AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1.r3x($this, tag, inlineDescriptor);
}
function AbstractJsonTreeEncoder$beginStructure$lambda(this$0) {
  return (node) => {
    this$0.v3w(this$0.n2c(), node);
    return Unit_instance;
  };
}
function get_requiresTopLevelTag(_this__u8e3s4) {
  var tmp;
  var tmp_0 = _this__u8e3s4.u1v();
  if (tmp_0 instanceof PrimitiveKind) {
    tmp = true;
  } else {
    tmp = _this__u8e3s4.u1v() === ENUM_getInstance();
  }
  return tmp;
}
function _get_tag__e6h4qf($this) {
  var tmp = $this.a3y_1;
  if (!(tmp == null))
    return tmp;
  else {
    throwUninitializedPropertyAccessException('tag');
  }
}
function writeJson$lambda($result) {
  return (it) => {
    $result._v = it;
    return Unit_instance;
  };
}
var WriteMode_OBJ_instance;
var WriteMode_LIST_instance;
var WriteMode_MAP_instance;
var WriteMode_POLY_OBJ_instance;
function values() {
  return [WriteMode_OBJ_getInstance(), WriteMode_LIST_getInstance(), WriteMode_MAP_getInstance(), WriteMode_POLY_OBJ_getInstance()];
}
function get_entries() {
  if ($ENTRIES == null)
    $ENTRIES = enumEntries(values());
  return $ENTRIES;
}
var WriteMode_entriesInitialized;
function WriteMode_initEntries() {
  if (WriteMode_entriesInitialized)
    return Unit_instance;
  WriteMode_entriesInitialized = true;
  WriteMode_OBJ_instance = new WriteMode('OBJ', 0, _Char___init__impl__6a9atx(123), _Char___init__impl__6a9atx(125));
  WriteMode_LIST_instance = new WriteMode('LIST', 1, _Char___init__impl__6a9atx(91), _Char___init__impl__6a9atx(93));
  WriteMode_MAP_instance = new WriteMode('MAP', 2, _Char___init__impl__6a9atx(123), _Char___init__impl__6a9atx(125));
  WriteMode_POLY_OBJ_instance = new WriteMode('POLY_OBJ', 3, _Char___init__impl__6a9atx(91), _Char___init__impl__6a9atx(93));
}
var $ENTRIES;
function switchMode(_this__u8e3s4, desc) {
  var tmp0_subject = desc.u1v();
  var tmp;
  if (tmp0_subject instanceof PolymorphicKind) {
    tmp = WriteMode_POLY_OBJ_getInstance();
  } else {
    if (equals(tmp0_subject, LIST_getInstance())) {
      tmp = WriteMode_LIST_getInstance();
    } else {
      if (equals(tmp0_subject, MAP_getInstance())) {
        // Inline function 'kotlinx.serialization.json.internal.selectMapMode' call
        var keyDescriptor = carrierDescriptor(desc.b1w(0), _this__u8e3s4.f1y());
        var keyKind = keyDescriptor.u1v();
        var tmp_0;
        var tmp_1;
        if (keyKind instanceof PrimitiveKind) {
          tmp_1 = true;
        } else {
          tmp_1 = equals(keyKind, ENUM_getInstance());
        }
        if (tmp_1) {
          tmp_0 = WriteMode_MAP_getInstance();
        } else {
          if (_this__u8e3s4.v3l_1.m3n_1) {
            tmp_0 = WriteMode_LIST_getInstance();
          } else {
            throw InvalidKeyKindException(keyDescriptor);
          }
        }
        tmp = tmp_0;
      } else {
        tmp = WriteMode_OBJ_getInstance();
      }
    }
  }
  return tmp;
}
function carrierDescriptor(_this__u8e3s4, module_0) {
  var tmp;
  if (equals(_this__u8e3s4.u1v(), CONTEXTUAL_getInstance())) {
    var tmp0_safe_receiver = getContextualDescriptor(module_0, _this__u8e3s4);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : carrierDescriptor(tmp0_safe_receiver, module_0);
    tmp = tmp1_elvis_lhs == null ? _this__u8e3s4 : tmp1_elvis_lhs;
  } else if (_this__u8e3s4.v1v()) {
    tmp = carrierDescriptor(_this__u8e3s4.b1w(0), module_0);
  } else {
    tmp = _this__u8e3s4;
  }
  return tmp;
}
function WriteMode_OBJ_getInstance() {
  WriteMode_initEntries();
  return WriteMode_OBJ_instance;
}
function WriteMode_LIST_getInstance() {
  WriteMode_initEntries();
  return WriteMode_LIST_instance;
}
function WriteMode_MAP_getInstance() {
  WriteMode_initEntries();
  return WriteMode_MAP_instance;
}
function WriteMode_POLY_OBJ_getInstance() {
  WriteMode_initEntries();
  return WriteMode_POLY_OBJ_instance;
}
function appendEscape($this, lastPosition, current) {
  $this.q3y(lastPosition, current);
  return appendEsc($this, current + 1 | 0);
}
function decodedString($this, lastPosition, currentPosition) {
  $this.q3y(lastPosition, currentPosition);
  var result = $this.o3m_1.toString();
  $this.o3m_1.ih(0);
  return result;
}
function takePeeked($this) {
  // Inline function 'kotlin.also' call
  var this_0 = ensureNotNull($this.n3m_1);
  $this.n3m_1 = null;
  return this_0;
}
function wasUnquotedString($this) {
  return !(charSequenceGet($this.r3y(), $this.l3m_1 - 1 | 0) === _Char___init__impl__6a9atx(34));
}
function appendEsc($this, startPosition) {
  var currentPosition = startPosition;
  currentPosition = $this.s3y(currentPosition);
  if (currentPosition === -1) {
    $this.g3r('Expected escape sequence to continue, got EOF');
  }
  var tmp = $this.r3y();
  var _unary__edvuaz = currentPosition;
  currentPosition = _unary__edvuaz + 1 | 0;
  var currentChar = charSequenceGet(tmp, _unary__edvuaz);
  if (currentChar === _Char___init__impl__6a9atx(117)) {
    return appendHex($this, $this.r3y(), currentPosition);
  }
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(currentChar);
  var c = escapeToChar(tmp$ret$0);
  if (c === _Char___init__impl__6a9atx(0)) {
    $this.g3r("Invalid escaped char '" + toString_1(currentChar) + "'");
  }
  $this.o3m_1.ub(c);
  return currentPosition;
}
function appendHex($this, source, startPos) {
  if ((startPos + 4 | 0) >= charSequenceLength(source)) {
    $this.l3m_1 = startPos;
    $this.t3y();
    if (($this.l3m_1 + 4 | 0) >= charSequenceLength(source)) {
      $this.g3r('Unexpected EOF during unicode escape');
    }
    return appendHex($this, source, $this.l3m_1);
  }
  $this.o3m_1.ub(numberToChar((((fromHexChar($this, source, startPos) << 12) + (fromHexChar($this, source, startPos + 1 | 0) << 8) | 0) + (fromHexChar($this, source, startPos + 2 | 0) << 4) | 0) + fromHexChar($this, source, startPos + 3 | 0) | 0));
  return startPos + 4 | 0;
}
function fromHexChar($this, source, currentPosition) {
  var character = charSequenceGet(source, currentPosition);
  var tmp;
  if (_Char___init__impl__6a9atx(48) <= character ? character <= _Char___init__impl__6a9atx(57) : false) {
    // Inline function 'kotlin.code' call
    var tmp_0 = Char__toInt_impl_vasixd(character);
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(48);
    tmp = tmp_0 - Char__toInt_impl_vasixd(this_0) | 0;
  } else if (_Char___init__impl__6a9atx(97) <= character ? character <= _Char___init__impl__6a9atx(102) : false) {
    // Inline function 'kotlin.code' call
    var tmp_1 = Char__toInt_impl_vasixd(character);
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(97);
    tmp = (tmp_1 - Char__toInt_impl_vasixd(this_1) | 0) + 10 | 0;
  } else if (_Char___init__impl__6a9atx(65) <= character ? character <= _Char___init__impl__6a9atx(70) : false) {
    // Inline function 'kotlin.code' call
    var tmp_2 = Char__toInt_impl_vasixd(character);
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(65);
    tmp = (tmp_2 - Char__toInt_impl_vasixd(this_2) | 0) + 10 | 0;
  } else {
    $this.g3r("Invalid toHexChar char '" + toString_1(character) + "' in unicode escape");
  }
  return tmp;
}
function consumeBoolean2($this, start) {
  var current = $this.s3y(start);
  if (current >= charSequenceLength($this.r3y()) || current === -1) {
    $this.g3r('EOF');
  }
  var tmp = $this.r3y();
  var _unary__edvuaz = current;
  current = _unary__edvuaz + 1 | 0;
  // Inline function 'kotlin.code' call
  var this_0 = charSequenceGet(tmp, _unary__edvuaz);
  var tmp0_subject = Char__toInt_impl_vasixd(this_0) | 32;
  var tmp_0;
  // Inline function 'kotlin.code' call
  var this_1 = _Char___init__impl__6a9atx(116);
  if (tmp0_subject === Char__toInt_impl_vasixd(this_1)) {
    consumeBooleanLiteral($this, 'rue', current);
    tmp_0 = true;
  } else {
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(102);
    if (tmp0_subject === Char__toInt_impl_vasixd(this_2)) {
      consumeBooleanLiteral($this, 'alse', current);
      tmp_0 = false;
    } else {
      $this.g3r("Expected valid boolean literal prefix, but had '" + $this.x3s() + "'");
    }
  }
  return tmp_0;
}
function consumeBooleanLiteral($this, literalSuffix, current) {
  if ((charSequenceLength($this.r3y()) - current | 0) < literalSuffix.length) {
    $this.g3r('Unexpected end of boolean literal');
  }
  var inductionVariable = 0;
  var last = charSequenceLength(literalSuffix) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var expected = charSequenceGet(literalSuffix, i);
      var actual = charSequenceGet($this.r3y(), current + i | 0);
      // Inline function 'kotlin.code' call
      var tmp = Char__toInt_impl_vasixd(expected);
      // Inline function 'kotlin.code' call
      if (!(tmp === (Char__toInt_impl_vasixd(actual) | 32))) {
        $this.g3r("Expected valid boolean literal prefix, but had '" + $this.x3s() + "'");
      }
    }
     while (inductionVariable <= last);
  $this.l3m_1 = current + literalSuffix.length | 0;
}
function consumeNumericLiteral$calculateExponent(exponentAccumulator, isExponentPositive) {
  var tmp;
  switch (isExponentPositive) {
    case false:
      // Inline function 'kotlin.math.pow' call

      var x = -exponentAccumulator.m4();
      tmp = Math.pow(10.0, x);
      break;
    case true:
      // Inline function 'kotlin.math.pow' call

      var x_0 = exponentAccumulator.m4();
      tmp = Math.pow(10.0, x_0);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function charToTokenClass(c) {
  var tmp;
  // Inline function 'kotlin.code' call
  if (Char__toInt_impl_vasixd(c) < 126) {
    var tmp_0 = CharMappings_getInstance().z3y_1;
    // Inline function 'kotlin.code' call
    tmp = tmp_0[Char__toInt_impl_vasixd(c)];
  } else {
    tmp = 0;
  }
  return tmp;
}
function tokenDescription(token) {
  return token === 1 ? "quotation mark '\"'" : token === 2 ? "string escape sequence '\\'" : token === 4 ? "comma ','" : token === 5 ? "colon ':'" : token === 6 ? "start of the object '{'" : token === 7 ? "end of the object '}'" : token === 8 ? "start of the array '['" : token === 9 ? "end of the array ']'" : token === 10 ? 'end of the input' : token === 127 ? 'invalid token' : 'valid token';
}
function escapeToChar(c) {
  return c < 117 ? CharMappings_getInstance().y3y_1[c] : _Char___init__impl__6a9atx(0);
}
function initEscape($this) {
  var inductionVariable = 0;
  if (inductionVariable <= 31)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      initC2ESC($this, i, _Char___init__impl__6a9atx(117));
    }
     while (inductionVariable <= 31);
  initC2ESC($this, 8, _Char___init__impl__6a9atx(98));
  initC2ESC($this, 9, _Char___init__impl__6a9atx(116));
  initC2ESC($this, 10, _Char___init__impl__6a9atx(110));
  initC2ESC($this, 12, _Char___init__impl__6a9atx(102));
  initC2ESC($this, 13, _Char___init__impl__6a9atx(114));
  initC2ESC_0($this, _Char___init__impl__6a9atx(47), _Char___init__impl__6a9atx(47));
  initC2ESC_0($this, _Char___init__impl__6a9atx(34), _Char___init__impl__6a9atx(34));
  initC2ESC_0($this, _Char___init__impl__6a9atx(92), _Char___init__impl__6a9atx(92));
}
function initCharToToken($this) {
  var inductionVariable = 0;
  if (inductionVariable <= 32)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      initC2TC($this, i, 127);
    }
     while (inductionVariable <= 32);
  initC2TC($this, 9, 3);
  initC2TC($this, 10, 3);
  initC2TC($this, 13, 3);
  initC2TC($this, 32, 3);
  initC2TC_0($this, _Char___init__impl__6a9atx(44), 4);
  initC2TC_0($this, _Char___init__impl__6a9atx(58), 5);
  initC2TC_0($this, _Char___init__impl__6a9atx(123), 6);
  initC2TC_0($this, _Char___init__impl__6a9atx(125), 7);
  initC2TC_0($this, _Char___init__impl__6a9atx(91), 8);
  initC2TC_0($this, _Char___init__impl__6a9atx(93), 9);
  initC2TC_0($this, _Char___init__impl__6a9atx(34), 1);
  initC2TC_0($this, _Char___init__impl__6a9atx(92), 2);
}
function initC2ESC($this, c, esc) {
  if (!(esc === _Char___init__impl__6a9atx(117))) {
    // Inline function 'kotlin.code' call
    var tmp$ret$0 = Char__toInt_impl_vasixd(esc);
    $this.y3y_1[tmp$ret$0] = numberToChar(c);
  }
}
function initC2ESC_0($this, c, esc) {
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(c);
  return initC2ESC($this, tmp$ret$0, esc);
}
function initC2TC($this, c, cl) {
  $this.z3y_1[c] = cl;
}
function initC2TC_0($this, c, cl) {
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(c);
  return initC2TC($this, tmp$ret$0, cl);
}
var CharMappings_instance;
function CharMappings_getInstance() {
  if (CharMappings_instance === VOID)
    new CharMappings();
  return CharMappings_instance;
}
function StringJsonLexer_0(json, source) {
  return !json.v3l_1.y3n_1 ? new StringJsonLexer(source) : new StringJsonLexerWithComments(source);
}
function get_schemaCache(_this__u8e3s4) {
  return _this__u8e3s4.x3l_1;
}
function createMapForCache(initialCapacity) {
  return HashMap.z8(initialCapacity);
}
//region block: post-declaration
initMetadataForClass(Json, 'Json');
initMetadataForObject(Default, 'Default');
initMetadataForClass(JsonBuilder, 'JsonBuilder');
initMetadataForClass(JsonImpl, 'JsonImpl');
initMetadataForClass(JsonClassDiscriminator, 'JsonClassDiscriminator');
initMetadataForClass(JsonIgnoreUnknownKeys, 'JsonIgnoreUnknownKeys');
initMetadataForClass(JsonNames, 'JsonNames');
initMetadataForClass(JsonConfiguration, 'JsonConfiguration');
initMetadataForClass(ClassDiscriminatorMode, 'ClassDiscriminatorMode');
initMetadataForInterface(JsonDecoder, 'JsonDecoder', VOID, VOID, [Decoder, CompositeDecoder]);
initMetadataForCompanion(Companion);
initMetadataForClass(JsonElement, 'JsonElement', VOID, VOID, VOID, VOID, VOID, {0: JsonElementSerializer_getInstance});
initMetadataForClass(JsonObject, 'JsonObject', VOID, VOID, [JsonElement, KtMap], VOID, VOID, {0: JsonObjectSerializer_getInstance});
initMetadataForCompanion(Companion_0);
initMetadataForCompanion(Companion_1);
initMetadataForClass(JsonArray, 'JsonArray', VOID, VOID, [JsonElement, KtList], VOID, VOID, {0: JsonArraySerializer_getInstance});
initMetadataForClass(JsonPrimitive, 'JsonPrimitive', VOID, VOID, VOID, VOID, VOID, {0: JsonPrimitiveSerializer_getInstance});
initMetadataForObject(JsonNull, 'JsonNull', VOID, VOID, [JsonPrimitive, SerializerFactory], VOID, VOID, {0: JsonNullSerializer_getInstance});
initMetadataForCompanion(Companion_2);
initMetadataForClass(JsonLiteral, 'JsonLiteral');
initMetadataForClass(JsonArrayBuilder, 'JsonArrayBuilder');
initMetadataForClass(JsonObjectBuilder, 'JsonObjectBuilder');
initMetadataForObject(JsonElementSerializer, 'JsonElementSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonObjectDescriptor, 'JsonObjectDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForObject(JsonObjectSerializer, 'JsonObjectSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonArrayDescriptor, 'JsonArrayDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForObject(JsonArraySerializer, 'JsonArraySerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonNullSerializer, 'JsonNullSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonPrimitiveSerializer, 'JsonPrimitiveSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonLiteralSerializer, 'JsonLiteralSerializer', VOID, VOID, [KSerializer]);
protoOf(defer$1).q1v = get_isNullable;
protoOf(defer$1).v1v = get_isInline;
protoOf(defer$1).x1v = get_annotations;
initMetadataForClass(defer$1, VOID, VOID, VOID, [SerialDescriptor]);
initMetadataForInterface(JsonEncoder, 'JsonEncoder', VOID, VOID, [Encoder, CompositeEncoder]);
initMetadataForClass(Composer, 'Composer');
initMetadataForClass(ComposerForUnsignedNumbers, 'ComposerForUnsignedNumbers');
initMetadataForClass(ComposerForUnquotedLiterals, 'ComposerForUnquotedLiterals');
initMetadataForClass(ComposerWithPrettyPrint, 'ComposerWithPrettyPrint');
initMetadataForClass(JsonElementMarker, 'JsonElementMarker');
initMetadataForClass(JsonException, 'JsonException');
initMetadataForClass(JsonDecodingException, 'JsonDecodingException');
initMetadataForClass(JsonEncodingException, 'JsonEncodingException');
initMetadataForObject(Tombstone, 'Tombstone');
initMetadataForClass(JsonPath, 'JsonPath', JsonPath);
protoOf(JsonSerializersModuleValidator).c2f = contextual;
initMetadataForClass(JsonSerializersModuleValidator, 'JsonSerializersModuleValidator', VOID, VOID, [SerializersModuleCollector]);
initMetadataForLambda(JsonTreeReader$readDeepRecursive$slambda, VOID, VOID, [2]);
initMetadataForClass(JsonTreeReader, 'JsonTreeReader', VOID, VOID, VOID, [0]);
initMetadataForClass(Key, 'Key', Key);
initMetadataForClass(DescriptorSchemaCache, 'DescriptorSchemaCache', DescriptorSchemaCache);
initMetadataForClass(DiscriminatorHolder, 'DiscriminatorHolder');
initMetadataForClass(StreamingJsonDecoder, 'StreamingJsonDecoder', VOID, VOID, [JsonDecoder, AbstractDecoder]);
initMetadataForClass(JsonDecoderForUnsignedTypes, 'JsonDecoderForUnsignedTypes');
initMetadataForClass(StreamingJsonEncoder, 'StreamingJsonEncoder', VOID, VOID, [JsonEncoder, AbstractEncoder]);
initMetadataForClass(AbstractJsonTreeDecoder, 'AbstractJsonTreeDecoder', VOID, VOID, [NamedValueDecoder, JsonDecoder]);
initMetadataForClass(JsonTreeDecoder, 'JsonTreeDecoder');
initMetadataForClass(JsonTreeListDecoder, 'JsonTreeListDecoder');
initMetadataForClass(JsonPrimitiveDecoder, 'JsonPrimitiveDecoder');
initMetadataForClass(JsonTreeMapDecoder, 'JsonTreeMapDecoder');
initMetadataForClass(AbstractJsonTreeEncoder, 'AbstractJsonTreeEncoder', VOID, VOID, [NamedValueEncoder, JsonEncoder]);
initMetadataForClass(JsonTreeEncoder, 'JsonTreeEncoder');
initMetadataForClass(AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1);
initMetadataForClass(AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1);
initMetadataForClass(JsonPrimitiveEncoder, 'JsonPrimitiveEncoder');
initMetadataForClass(JsonTreeListEncoder, 'JsonTreeListEncoder');
initMetadataForClass(JsonTreeMapEncoder, 'JsonTreeMapEncoder');
initMetadataForClass(WriteMode, 'WriteMode');
initMetadataForClass(AbstractJsonLexer, 'AbstractJsonLexer');
initMetadataForObject(CharMappings, 'CharMappings');
initMetadataForClass(StringJsonLexer, 'StringJsonLexer');
initMetadataForClass(StringJsonLexerWithComments, 'StringJsonLexerWithComments');
initMetadataForClass(JsonToStringWriter, 'JsonToStringWriter', JsonToStringWriter);
//endregion
//region block: init
Companion_instance = new Companion();
Companion_instance_0 = new Companion_0();
Companion_instance_1 = new Companion_1();
Companion_instance_2 = new Companion_2();
Tombstone_instance = new Tombstone();
//endregion
//region block: exports
export {
  Companion_instance_0 as Companion_instance20spzcd6u6icp,
  JsonElementSerializer_getInstance as JsonElementSerializer_getInstance1rgo1giz8g15y,
  JsonNull_getInstance as JsonNull_getInstance1q6cansbfp6ip,
  Companion_instance as Companion_instance2xnbmyqibbp8t,
  JsonObjectSerializer_getInstance as JsonObjectSerializer_getInstance197qdg6ernwdp,
  JsonArrayBuilder as JsonArrayBuilderu8edol6ui3pj,
  JsonArray as JsonArray2urf8ey7u44sd,
  JsonNull as JsonNull2liwjj96vm0w2,
  JsonObjectBuilder as JsonObjectBuilder2nl6rv6vdayuk,
  JsonObject as JsonObjectee06ihoeeiqj,
  JsonPrimitive_1 as JsonPrimitiveolttw629wj53,
  JsonPrimitive_0 as JsonPrimitive2fp8648nd60dn,
  JsonPrimitive_2 as JsonPrimitive1xkjzc5d7ihuv,
  JsonPrimitive as JsonPrimitive3ttzjh2ft5dnx,
  Json_0 as Jsonsmkyu9xjl7fv,
  get_booleanOrNull as get_booleanOrNull376axlcpdhkmo,
  get_contentOrNull as get_contentOrNull35s97cgi8z9eo,
  get_doubleOrNull as get_doubleOrNull2fo14gjg922um,
  get_intOrNull as get_intOrNulld29i64b3udf,
  get_jsonObject as get_jsonObject2u4z2ch1uuca9,
  get_jsonPrimitive as get_jsonPrimitivez17tyd5rw1ql,
  get_longOrNull as get_longOrNull1kg1ha9scz5pa,
};
//endregion

//# sourceMappingURL=kotlinx-serialization-kotlinx-serialization-json.mjs.map
