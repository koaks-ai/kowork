import {
  VOID7hggqo3abtya as VOID,
  StringBuildermazzzhj6kkai as StringBuilder,
  Unit_instance104q5opgivhr8 as Unit_instance,
  charArray2ujmm1qusno00 as charArray,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  concatToString2syawgu50khxi as concatToString,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  toString1pkumu07cwy4m as toString,
  Char19o2r8palgjof as Char,
  isSurrogatewe8xicw8z84n as isSurrogate,
  Char__plus_impl_qi7pgj1zq2c0uiotg93 as Char__plus_impl_qi7pgj,
  Char__minus_impl_a2frrhe8uo2lu35qi1 as Char__minus_impl_a2frrh,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  toString35i91qxh73cps as toString_0,
  toByte4i43936u611k as toByte,
  decodeToString1dbzcjd620q25 as decodeToString,
  Exceptiondt2hlxn7j7vw as Exception,
  captureStack1fzi4aczwc4hg as captureStack,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  Char__minus_impl_a2frrhem8aw2sny2of as Char__minus_impl_a2frrh_0,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  numberToChar93r9buh19yek as numberToChar,
  Char__rangeTo_impl_tkncvp940rgm6i9zbm as Char__rangeTo_impl_tkncvp,
  plus39kp8wyage607 as plus,
  plus310ted5e4i90h as plus_0,
  ArrayList3it5z8td81qkl as ArrayList,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  toSet2orjxp16sotqu as toSet,
  setOf45ia9pnfhe90 as setOf,
  plus1ogy4liedzq5j as plus_1,
  listOf1jh22dvmctj1r as listOf,
  equals2v6cggk171b6e as equals,
  Collection1k04j3hzsbod0 as Collection,
  isInterface3d6p8outrmvmk as isInterface,
  isBlank1dvkhjjvox3p0 as isBlank,
  last1vo29oleiqj36 as last,
  indexOf1xbs558u7wr52 as indexOf,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  contains2el4s70rdq4ld as contains,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  startsWith38d3sbg25w0lx as startsWith,
  emptyList1g2z5xcrvp2zy as emptyList,
  plus20p0vtfmu0596 as plus_2,
  equals2au1ep9vhcato as equals_0,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  createThis2j2avj17cvnv2 as createThis,
  get_lastIndex1yw0x4k50k51w as get_lastIndex,
  first3kg261hmihapu as first,
  last2n4gf5az1lkn4 as last_0,
  get_lastIndexld83bqhfgcdd as get_lastIndex_0,
  emptySetcxexqki71qfa as emptySet,
  protoOf180f3jzyo7rfj as protoOf,
  emptyMapr06gerzljqtm as emptyMap,
  listOfvhqybd2zx248 as listOf_0,
  toDoubleOrNullkxwozihadygj as toDoubleOrNull,
  LazyThreadSafetyMode_NONE_getInstance31hcehq5w8bn3 as LazyThreadSafetyMode_NONE_getInstance,
  lazy1261dae0bgscp as lazy,
  to2cs3ny02qtbcb as to,
  asList2ho2pewtsfvv as asList,
  Char__compareTo_impl_ypi4mb3fw4vcbfqkuba as Char__compareTo_impl_ypi4mb,
  toLongkk4waq8msp1k as toLong,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  Comparable198qfk8pnblz0 as Comparable,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  isWhitespace25occ8z1ed1s9 as isWhitespace,
  startsWith1bgirhbedtv2y as startsWith_0,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  split3d3yeauc4rm2n as split,
  toMutableList20rdgwi7d3cwi as toMutableList,
  first58ocm7j58k3q as first_0,
  joinToString1cxrrlmo0chqs as joinToString,
  indexOfAny2ijjuuzpljsyd as indexOfAny,
  dropLast1vpiyky649o34 as dropLast,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  indexOfwa4w6635jewi as indexOf_0,
  toInt2q8uldh7sc951 as toInt,
  startsWith26w8qjqapeeq6 as startsWith_1,
  addAll1k27qatfgp3k5 as addAll,
  joinTo3lkanfaxbzac2 as joinTo,
  toString30pk9tzaqopn as toString_1,
  lazy2hsh8ze7j6ikd as lazy_0,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  boxApply1qmzdb3dh90hg as boxApply,
  toLongw1zpgk99d84b as toLong_0,
  take9j4462mea726 as take,
} from './kotlin-kotlin-stdlib.mjs';
import {
  Charsets_getInstancemd62gu5po4os as Charsets_getInstance,
  encode35e4rpnc94tb5 as encode,
  takeWhile34751tcfg6owx as takeWhile,
  canRead1guo8vbveth0f as canRead,
  forName2faodmskqnoz5 as forName,
  get_name2f11g4r0d5pxp as get_name,
  toByteArray1i3ns5jnoqlv6 as toByteArray,
} from './ktor-ktor-io.mjs';
import {
  StringValuesBuilderImpl3ey9etj3bwnqf as StringValuesBuilderImpl,
  get3oezx9z3zutmm as get,
  forEachghjt92rkrpzo as forEach,
  StringValuesjqid5a6cuday as StringValues,
  StringValuesImpl2l95y9du7b61t as StringValuesImpl,
  StringValuesSingleImpl1uh7q2c2zm7va as StringValuesSingleImpl,
  toCharArray1qby3f4cdahde as toCharArray,
  toLowerCasePreservingASCIIRulesa2d90zyoc6kw as toLowerCasePreservingASCIIRules,
  isLowerCase2jodys5jo7d58 as isLowerCase,
  appendAlltwnjnu28pmtx as appendAll,
  PlatformUtils_getInstance3trl22jwg7wgb as PlatformUtils_getInstance,
} from './ktor-ktor-utils.mjs';
import {
  STRING_getInstance2gbamclnmtzqa as STRING_getInstance,
  PrimitiveSerialDescriptor3egfp53lutxj2 as PrimitiveSerialDescriptor,
  KSerializerzf77vz1967fq as KSerializer,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class URLDecodeException extends Exception {
  static o2l(message) {
    var $this = this.l5(message);
    captureStack($this, $this.n2l_1);
    return $this;
  }
}
class Companion {
  constructor() {
    Companion_instance = this;
    this.u2l_1 = ContentType.z2l('*', '*');
  }
  ds(value) {
    if (isBlank(value))
      return this.u2l_1;
    // Inline function 'io.ktor.http.Companion.parse' call
    var headerValue = last(parseHeaderValue(value));
    var tmp2 = headerValue.a2m_1;
    var parameters = headerValue.b2m_1;
    var slash = indexOf(tmp2, _Char___init__impl__6a9atx(47));
    if (slash === -1) {
      // Inline function 'kotlin.text.trim' call
      if (toString(trim(isCharSequence(tmp2) ? tmp2 : THROW_CCE())) === '*')
        return Companion_getInstance().u2l_1;
      throw BadContentTypeFormatException.f2m(value);
    }
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'kotlin.text.trim' call
    var this_0 = tmp2.substring(0, slash);
    var type = toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(type) === 0) {
      throw BadContentTypeFormatException.f2m(value);
    }
    // Inline function 'kotlin.text.substring' call
    var startIndex = slash + 1 | 0;
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'kotlin.text.trim' call
    var this_1 = tmp2.substring(startIndex);
    var subtype = toString(trim(isCharSequence(this_1) ? this_1 : THROW_CCE()));
    if (contains(type, _Char___init__impl__6a9atx(32)) || contains(subtype, _Char___init__impl__6a9atx(32))) {
      throw BadContentTypeFormatException.f2m(value);
    }
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(subtype) === 0) {
      tmp = true;
    } else {
      tmp = contains(subtype, _Char___init__impl__6a9atx(47));
    }
    if (tmp) {
      throw BadContentTypeFormatException.f2m(value);
    }
    return ContentType.z2l(type, subtype, parameters);
  }
}
class Application {
  constructor() {
    Application_instance = this;
    this.g2m_1 = 'application';
    this.h2m_1 = ContentType.z2l('application', '*');
    this.i2m_1 = ContentType.z2l('application', 'atom+xml');
    this.j2m_1 = ContentType.z2l('application', 'cbor');
    this.k2m_1 = ContentType.z2l('application', 'json');
    this.l2m_1 = ContentType.z2l('application', 'hal+json');
    this.m2m_1 = ContentType.z2l('application', 'javascript');
    this.n2m_1 = ContentType.z2l('application', 'octet-stream');
    this.o2m_1 = ContentType.z2l('application', 'rss+xml');
    this.p2m_1 = ContentType.z2l('application', 'soap+xml');
    this.q2m_1 = ContentType.z2l('application', 'xml');
    this.r2m_1 = ContentType.z2l('application', 'xml-dtd');
    this.s2m_1 = ContentType.z2l('application', 'yaml');
    this.t2m_1 = ContentType.z2l('application', 'zip');
    this.u2m_1 = ContentType.z2l('application', 'gzip');
    this.v2m_1 = ContentType.z2l('application', 'x-www-form-urlencoded');
    this.w2m_1 = ContentType.z2l('application', 'pdf');
    this.x2m_1 = ContentType.z2l('application', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    this.y2m_1 = ContentType.z2l('application', 'vnd.openxmlformats-officedocument.wordprocessingml.document');
    this.z2m_1 = ContentType.z2l('application', 'vnd.openxmlformats-officedocument.presentationml.presentation');
    this.a2n_1 = ContentType.z2l('application', 'protobuf');
    this.b2n_1 = ContentType.z2l('application', 'wasm');
    this.c2n_1 = ContentType.z2l('application', 'problem+json');
    this.d2n_1 = ContentType.z2l('application', 'problem+xml');
  }
}
class MultiPart {
  constructor() {
    MultiPart_instance = this;
    this.e2n_1 = 'multipart';
    this.f2n_1 = ContentType.z2l('multipart', '*');
    this.g2n_1 = ContentType.z2l('multipart', 'mixed');
    this.h2n_1 = ContentType.z2l('multipart', 'alternative');
    this.i2n_1 = ContentType.z2l('multipart', 'related');
    this.j2n_1 = ContentType.z2l('multipart', 'form-data');
    this.k2n_1 = ContentType.z2l('multipart', 'signed');
    this.l2n_1 = ContentType.z2l('multipart', 'encrypted');
    this.m2n_1 = ContentType.z2l('multipart', 'byteranges');
  }
  n2n(contentType) {
    return startsWith(contentType, 'multipart/', true);
  }
}
class Text {
  constructor() {
    Text_instance = this;
    this.o2n_1 = 'text';
    this.p2n_1 = ContentType.z2l('text', '*');
    this.q2n_1 = ContentType.z2l('text', 'plain');
    this.r2n_1 = ContentType.z2l('text', 'css');
    this.s2n_1 = ContentType.z2l('text', 'csv');
    this.t2n_1 = ContentType.z2l('text', 'html');
    this.u2n_1 = ContentType.z2l('text', 'javascript');
    this.v2n_1 = ContentType.z2l('text', 'vcard');
    this.w2n_1 = ContentType.z2l('text', 'xml');
    this.x2n_1 = ContentType.z2l('text', 'event-stream');
  }
}
class HeaderValueWithParameters {
  static z2n(content, parameters) {
    parameters = parameters === VOID ? emptyList() : parameters;
    var $this = createThis(this);
    $this.p2l_1 = content;
    $this.q2l_1 = parameters;
    return $this;
  }
  d2o(name) {
    var inductionVariable = 0;
    var last = get_lastIndex(this.q2l_1);
    if (inductionVariable <= last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var parameter = this.q2l_1.f1(index);
        if (equals(parameter.r2l_1, name, true)) {
          return parameter.s2l_1;
        }
      }
       while (!(index === last));
    return null;
  }
  toString() {
    var tmp;
    if (this.q2l_1.h1()) {
      tmp = this.p2l_1;
    } else {
      var tmp_0 = this.p2l_1.length;
      // Inline function 'kotlin.collections.sumOf' call
      var sum = 0;
      var _iterator__ex2g4s = this.q2l_1.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        var tmp_1 = sum;
        sum = tmp_1 + ((element.r2l_1.length + element.s2l_1.length | 0) + 3 | 0) | 0;
      }
      var size = tmp_0 + sum | 0;
      // Inline function 'kotlin.apply' call
      var this_0 = StringBuilder.xb(size);
      this_0.tb(this.p2l_1);
      var inductionVariable = 0;
      var last = get_lastIndex(this.q2l_1);
      if (inductionVariable <= last)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var element_0 = this.q2l_1.f1(index);
          this_0.tb('; ');
          this_0.tb(element_0.r2l_1);
          this_0.tb('=');
          // Inline function 'io.ktor.http.escapeIfNeededTo' call
          var this_1 = element_0.s2l_1;
          if (needQuotes(this_1))
            this_0.tb(quote(this_1));
          else
            this_0.tb(this_1);
        }
         while (!(index === last));
      tmp = this_0.toString();
    }
    return tmp;
  }
}
class ContentType extends HeaderValueWithParameters {
  static y2n(contentType, contentSubtype, existingContent, parameters) {
    Companion_getInstance();
    parameters = parameters === VOID ? emptyList() : parameters;
    var $this = this.z2n(existingContent, parameters);
    $this.x2l_1 = contentType;
    $this.y2l_1 = contentSubtype;
    return $this;
  }
  static z2l(contentType, contentSubtype, parameters) {
    Companion_getInstance();
    parameters = parameters === VOID ? emptyList() : parameters;
    return this.y2n(contentType, contentSubtype, contentType + '/' + contentSubtype, parameters);
  }
  a2o(name, value) {
    if (hasParameter(this, name, value))
      return this;
    return ContentType.y2n(this.x2l_1, this.y2l_1, this.p2l_1, plus_2(this.q2l_1, HeaderValueParam.b2o(name, value)));
  }
  c2o(pattern) {
    if (!(pattern.x2l_1 === '*') && !equals(pattern.x2l_1, this.x2l_1, true)) {
      return false;
    }
    if (!(pattern.y2l_1 === '*') && !equals(pattern.y2l_1, this.y2l_1, true)) {
      return false;
    }
    var _iterator__ex2g4s = pattern.q2l_1.y();
    while (_iterator__ex2g4s.z()) {
      var _destruct__k2r9zo = _iterator__ex2g4s.a1();
      var patternName = _destruct__k2r9zo.tl();
      var patternValue = _destruct__k2r9zo.ul();
      var tmp;
      if (patternName === '*') {
        var tmp_0;
        if (patternValue === '*') {
          tmp_0 = true;
        } else {
          var tmp0 = this.q2l_1;
          var tmp$ret$0;
          $l$block_0: {
            // Inline function 'kotlin.collections.any' call
            var tmp_1;
            if (isInterface(tmp0, Collection)) {
              tmp_1 = tmp0.h1();
            } else {
              tmp_1 = false;
            }
            if (tmp_1) {
              tmp$ret$0 = false;
              break $l$block_0;
            }
            var _iterator__ex2g4s_0 = tmp0.y();
            while (_iterator__ex2g4s_0.z()) {
              var element = _iterator__ex2g4s_0.a1();
              if (equals(element.s2l_1, patternValue, true)) {
                tmp$ret$0 = true;
                break $l$block_0;
              }
            }
            tmp$ret$0 = false;
          }
          tmp_0 = tmp$ret$0;
        }
        tmp = tmp_0;
      } else {
        var value = this.d2o(patternName);
        tmp = patternValue === '*' ? !(value == null) : equals(value, patternValue, true);
      }
      var matches = tmp;
      if (!matches) {
        return false;
      }
    }
    return true;
  }
  equals(other) {
    var tmp;
    var tmp_0;
    var tmp_1;
    if (other instanceof ContentType) {
      tmp_1 = equals(this.x2l_1, other.x2l_1, true);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = equals(this.y2l_1, other.y2l_1, true);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = equals_0(this.q2l_1, other.q2l_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$1 = this.x2l_1.toLowerCase();
    var result = getStringHashCode(tmp$ret$1);
    var tmp = result;
    var tmp_0 = imul(31, result);
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$3 = this.y2l_1.toLowerCase();
    result = tmp + (tmp_0 + getStringHashCode(tmp$ret$3) | 0) | 0;
    result = result + imul(31, hashCode(this.q2l_1)) | 0;
    return result;
  }
}
class BadContentTypeFormatException extends Exception {
  static f2m(value) {
    var $this = this.l5('Bad Content-Type format: ' + value);
    captureStack($this, $this.e2m_1);
    return $this;
  }
}
class Companion_0 {}
class Companion_1 {
  constructor() {
    Companion_instance_1 = this;
    this.e2o_1 = EmptyHeaders_instance;
  }
}
class HeadersBuilder extends StringValuesBuilderImpl {
  constructor(size) {
    size = size === VOID ? 8 : size;
    super(true, size);
  }
  h2o() {
    return new HeadersImpl(this.h2h_1);
  }
  i2h(name) {
    super.i2h(name);
    HttpHeaders_getInstance().e2s(name);
  }
  m2h(value) {
    super.m2h(value);
    HttpHeaders_getInstance().f2s(value);
  }
}
class EmptyHeaders {
  b2h() {
    return true;
  }
  c2h(name) {
    return null;
  }
  d2h() {
    return emptySet();
  }
  e2h() {
    return emptySet();
  }
  toString() {
    return 'Headers ' + toString(this.e2h());
  }
}
class HeadersImpl extends StringValuesImpl {
  constructor(values) {
    values = values === VOID ? emptyMap() : values;
    super(true, values);
  }
  toString() {
    return 'Headers ' + toString(this.e2h());
  }
}
class HeadersSingleImpl extends StringValuesSingleImpl {
  constructor(name, values) {
    super(true, name, values);
  }
  toString() {
    return 'Headers ' + toString(this.e2h());
  }
}
class HeaderValueParam {
  static g2s(name, value, escapeValue) {
    var $this = createThis(this);
    $this.r2l_1 = name;
    $this.s2l_1 = value;
    $this.t2l_1 = escapeValue;
    return $this;
  }
  static b2o(name, value) {
    return this.g2s(name, value, false);
  }
  equals(other) {
    var tmp;
    var tmp_0;
    if (other instanceof HeaderValueParam) {
      tmp_0 = equals(other.r2l_1, this.r2l_1, true);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = equals(other.s2l_1, this.s2l_1, true);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$1 = this.r2l_1.toLowerCase();
    var result = getStringHashCode(tmp$ret$1);
    var tmp = result;
    var tmp_0 = imul(31, result);
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$3 = this.s2l_1.toLowerCase();
    result = tmp + (tmp_0 + getStringHashCode(tmp$ret$3) | 0) | 0;
    return result;
  }
  tl() {
    return this.r2l_1;
  }
  ul() {
    return this.s2l_1;
  }
  toString() {
    return 'HeaderValueParam(name=' + this.r2l_1 + ', value=' + this.s2l_1 + ', escapeValue=' + this.t2l_1 + ')';
  }
}
class HeaderValue {
  constructor(value, params) {
    params = params === VOID ? emptyList() : params;
    this.a2m_1 = value;
    this.b2m_1 = params;
    var tmp = this;
    var tmp0 = this.b2m_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (element.r2l_1 === 'q') {
          tmp$ret$1 = element;
          break $l$block;
        }
      }
      tmp$ret$1 = null;
    }
    var tmp0_safe_receiver = tmp$ret$1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.s2l_1;
    var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : toDoubleOrNull(tmp1_safe_receiver);
    var tmp_0;
    if (tmp2_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.takeIf' call
      var tmp_1;
      if (0.0 <= tmp2_safe_receiver ? tmp2_safe_receiver <= 1.0 : false) {
        tmp_1 = tmp2_safe_receiver;
      } else {
        tmp_1 = null;
      }
      tmp_0 = tmp_1;
    }
    var tmp3_elvis_lhs = tmp_0;
    tmp.c2m_1 = tmp3_elvis_lhs == null ? 1.0 : tmp3_elvis_lhs;
  }
  toString() {
    return 'HeaderValue(value=' + this.a2m_1 + ', params=' + toString(this.b2m_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.a2m_1);
    result = imul(result, 31) + hashCode(this.b2m_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof HeaderValue))
      return false;
    var tmp0_other_with_cast = other instanceof HeaderValue ? other : THROW_CCE();
    if (!(this.a2m_1 === tmp0_other_with_cast.a2m_1))
      return false;
    if (!equals_0(this.b2m_1, tmp0_other_with_cast.b2m_1))
      return false;
    return true;
  }
}
class HttpHeaders {
  constructor() {
    HttpHeaders_instance = this;
    this.i2o_1 = 'Accept';
    this.j2o_1 = 'Accept-Charset';
    this.k2o_1 = 'Accept-Encoding';
    this.l2o_1 = 'Accept-Language';
    this.m2o_1 = 'Accept-Ranges';
    this.n2o_1 = 'Age';
    this.o2o_1 = 'Allow';
    this.p2o_1 = 'ALPN';
    this.q2o_1 = 'Authentication-Info';
    this.r2o_1 = 'Authorization';
    this.s2o_1 = 'Cache-Control';
    this.t2o_1 = 'Connection';
    this.u2o_1 = 'Content-Disposition';
    this.v2o_1 = 'Content-Encoding';
    this.w2o_1 = 'Content-Language';
    this.x2o_1 = 'Content-Length';
    this.y2o_1 = 'Content-Location';
    this.z2o_1 = 'Content-Range';
    this.a2p_1 = 'Content-Type';
    this.b2p_1 = 'Cookie';
    this.c2p_1 = 'DASL';
    this.d2p_1 = 'Date';
    this.e2p_1 = 'DAV';
    this.f2p_1 = 'Depth';
    this.g2p_1 = 'Destination';
    this.h2p_1 = 'ETag';
    this.i2p_1 = 'Expect';
    this.j2p_1 = 'Expires';
    this.k2p_1 = 'From';
    this.l2p_1 = 'Forwarded';
    this.m2p_1 = 'Host';
    this.n2p_1 = 'HTTP2-Settings';
    this.o2p_1 = 'If';
    this.p2p_1 = 'If-Match';
    this.q2p_1 = 'If-Modified-Since';
    this.r2p_1 = 'If-None-Match';
    this.s2p_1 = 'If-Range';
    this.t2p_1 = 'If-Schedule-Tag-Match';
    this.u2p_1 = 'If-Unmodified-Since';
    this.v2p_1 = 'Last-Modified';
    this.w2p_1 = 'Location';
    this.x2p_1 = 'Lock-Token';
    this.y2p_1 = 'Link';
    this.z2p_1 = 'Max-Forwards';
    this.a2q_1 = 'MIME-Version';
    this.b2q_1 = 'Ordering-Type';
    this.c2q_1 = 'Origin';
    this.d2q_1 = 'Overwrite';
    this.e2q_1 = 'Position';
    this.f2q_1 = 'Pragma';
    this.g2q_1 = 'Prefer';
    this.h2q_1 = 'Preference-Applied';
    this.i2q_1 = 'Proxy-Authenticate';
    this.j2q_1 = 'Proxy-Authentication-Info';
    this.k2q_1 = 'Proxy-Authorization';
    this.l2q_1 = 'Public-Key-Pins';
    this.m2q_1 = 'Public-Key-Pins-Report-Only';
    this.n2q_1 = 'Range';
    this.o2q_1 = 'Referer';
    this.p2q_1 = 'Retry-After';
    this.q2q_1 = 'Schedule-Reply';
    this.r2q_1 = 'Schedule-Tag';
    this.s2q_1 = 'Sec-WebSocket-Accept';
    this.t2q_1 = 'Sec-WebSocket-Extensions';
    this.u2q_1 = 'Sec-WebSocket-Key';
    this.v2q_1 = 'Sec-WebSocket-Protocol';
    this.w2q_1 = 'Sec-WebSocket-Version';
    this.x2q_1 = 'Server';
    this.y2q_1 = 'Set-Cookie';
    this.z2q_1 = 'SLUG';
    this.a2r_1 = 'Strict-Transport-Security';
    this.b2r_1 = 'TE';
    this.c2r_1 = 'Timeout';
    this.d2r_1 = 'Trailer';
    this.e2r_1 = 'Transfer-Encoding';
    this.f2r_1 = 'Upgrade';
    this.g2r_1 = 'User-Agent';
    this.h2r_1 = 'Vary';
    this.i2r_1 = 'Via';
    this.j2r_1 = 'Warning';
    this.k2r_1 = 'WWW-Authenticate';
    this.l2r_1 = 'Access-Control-Allow-Origin';
    this.m2r_1 = 'Access-Control-Allow-Methods';
    this.n2r_1 = 'Access-Control-Allow-Credentials';
    this.o2r_1 = 'Access-Control-Allow-Headers';
    this.p2r_1 = 'Access-Control-Request-Method';
    this.q2r_1 = 'Access-Control-Request-Headers';
    this.r2r_1 = 'Access-Control-Expose-Headers';
    this.s2r_1 = 'Access-Control-Max-Age';
    this.t2r_1 = 'X-Http-Method-Override';
    this.u2r_1 = 'X-Forwarded-Host';
    this.v2r_1 = 'X-Forwarded-Server';
    this.w2r_1 = 'X-Forwarded-Proto';
    this.x2r_1 = 'X-Forwarded-For';
    this.y2r_1 = 'X-Forwarded-Port';
    this.z2r_1 = 'X-Request-ID';
    this.a2s_1 = 'X-Correlation-ID';
    this.b2s_1 = 'X-Total-Count';
    var tmp = this;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.c2s_1 = [this.e2r_1, this.f2r_1];
    this.d2s_1 = asList(this.c2s_1);
  }
  e2s(name) {
    // Inline function 'kotlin.text.forEachIndexed' call
    var index = 0;
    var inductionVariable = 0;
    while (inductionVariable < charSequenceLength(name)) {
      var item = charSequenceGet(name, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      if (Char__compareTo_impl_ypi4mb(item, _Char___init__impl__6a9atx(32)) <= 0 || isDelimiter(item)) {
        throw IllegalHeaderNameException.n2s(name, _unary__edvuaz);
      }
    }
  }
  f2s(value) {
    // Inline function 'kotlin.text.forEachIndexed' call
    var index = 0;
    var inductionVariable = 0;
    while (inductionVariable < charSequenceLength(value)) {
      var item = charSequenceGet(value, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      if (Char__compareTo_impl_ypi4mb(item, _Char___init__impl__6a9atx(32)) < 0 && !(item === _Char___init__impl__6a9atx(9))) {
        throw IllegalHeaderValueException.u2s(value, _unary__edvuaz);
      }
    }
  }
}
class IllegalHeaderNameException extends IllegalArgumentException {
  static n2s(headerName, position) {
    var tmp = "Header name '" + headerName + "' contains illegal character '" + toString_0(charSequenceGet(headerName, position)) + "'";
    // Inline function 'kotlin.code' call
    var this_0 = charSequenceGet(headerName, position);
    var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
    var $this = this.t(tmp + (' (code ' + (tmp$ret$0 & 255) + ')'));
    captureStack($this, $this.m2s_1);
    $this.k2s_1 = headerName;
    $this.l2s_1 = position;
    return $this;
  }
}
class IllegalHeaderValueException extends IllegalArgumentException {
  static u2s(headerValue, position) {
    var tmp = "Header value '" + headerValue + "' contains illegal character '" + toString_0(charSequenceGet(headerValue, position)) + "'";
    // Inline function 'kotlin.code' call
    var this_0 = charSequenceGet(headerValue, position);
    var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
    var $this = this.t(tmp + (' (code ' + (tmp$ret$0 & 255) + ')'));
    captureStack($this, $this.t2s_1);
    $this.r2s_1 = headerValue;
    $this.s2s_1 = position;
    return $this;
  }
}
class UnsafeHeaderException extends IllegalArgumentException {
  static z2s(header) {
    var $this = this.t('Header(s) ' + header + ' are controlled by the engine and ' + 'cannot be set explicitly');
    captureStack($this, $this.y2s_1);
    return $this;
  }
}
class Companion_2 {
  constructor() {
    Companion_instance_2 = this;
    this.b2t_1 = new HttpMethod('GET');
    this.c2t_1 = new HttpMethod('POST');
    this.d2t_1 = new HttpMethod('PUT');
    this.e2t_1 = new HttpMethod('PATCH');
    this.f2t_1 = new HttpMethod('DELETE');
    this.g2t_1 = new HttpMethod('HEAD');
    this.h2t_1 = new HttpMethod('OPTIONS');
    this.i2t_1 = listOf([this.b2t_1, this.c2t_1, this.d2t_1, this.e2t_1, this.f2t_1, this.g2t_1, this.h2t_1]);
  }
}
class HttpMethod {
  constructor(value) {
    Companion_getInstance_2();
    this.j2t_1 = value;
  }
  toString() {
    return this.j2t_1;
  }
  hashCode() {
    return getStringHashCode(this.j2t_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof HttpMethod))
      return false;
    var tmp0_other_with_cast = other instanceof HttpMethod ? other : THROW_CCE();
    if (!(this.j2t_1 === tmp0_other_with_cast.j2t_1))
      return false;
    return true;
  }
}
class Companion_3 {
  constructor() {
    Companion_instance_3 = this;
    this.k2t_1 = new HttpProtocolVersion('HTTP', 2, 0);
    this.l2t_1 = new HttpProtocolVersion('HTTP', 1, 1);
    this.m2t_1 = new HttpProtocolVersion('HTTP', 1, 0);
    this.n2t_1 = new HttpProtocolVersion('SPDY', 3, 0);
    this.o2t_1 = new HttpProtocolVersion('QUIC', 1, 0);
  }
}
class HttpProtocolVersion {
  constructor(name, major, minor) {
    Companion_getInstance_3();
    this.p2t_1 = name;
    this.q2t_1 = major;
    this.r2t_1 = minor;
  }
  toString() {
    return this.p2t_1 + '/' + this.q2t_1 + '.' + this.r2t_1;
  }
  hashCode() {
    var result = getStringHashCode(this.p2t_1);
    result = imul(result, 31) + this.q2t_1 | 0;
    result = imul(result, 31) + this.r2t_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof HttpProtocolVersion))
      return false;
    var tmp0_other_with_cast = other instanceof HttpProtocolVersion ? other : THROW_CCE();
    if (!(this.p2t_1 === tmp0_other_with_cast.p2t_1))
      return false;
    if (!(this.q2t_1 === tmp0_other_with_cast.q2t_1))
      return false;
    if (!(this.r2t_1 === tmp0_other_with_cast.r2t_1))
      return false;
    return true;
  }
}
class Companion_4 {
  constructor() {
    Companion_instance_4 = this;
    this.s2t_1 = new HttpStatusCode(100, 'Continue');
    this.t2t_1 = new HttpStatusCode(101, 'Switching Protocols');
    this.u2t_1 = new HttpStatusCode(102, 'Processing');
    this.v2t_1 = new HttpStatusCode(200, 'OK');
    this.w2t_1 = new HttpStatusCode(201, 'Created');
    this.x2t_1 = new HttpStatusCode(202, 'Accepted');
    this.y2t_1 = new HttpStatusCode(203, 'Non-Authoritative Information');
    this.z2t_1 = new HttpStatusCode(204, 'No Content');
    this.a2u_1 = new HttpStatusCode(205, 'Reset Content');
    this.b2u_1 = new HttpStatusCode(206, 'Partial Content');
    this.c2u_1 = new HttpStatusCode(207, 'Multi-Status');
    this.d2u_1 = new HttpStatusCode(300, 'Multiple Choices');
    this.e2u_1 = new HttpStatusCode(301, 'Moved Permanently');
    this.f2u_1 = new HttpStatusCode(302, 'Found');
    this.g2u_1 = new HttpStatusCode(303, 'See Other');
    this.h2u_1 = new HttpStatusCode(304, 'Not Modified');
    this.i2u_1 = new HttpStatusCode(305, 'Use Proxy');
    this.j2u_1 = new HttpStatusCode(306, 'Switch Proxy');
    this.k2u_1 = new HttpStatusCode(307, 'Temporary Redirect');
    this.l2u_1 = new HttpStatusCode(308, 'Permanent Redirect');
    this.m2u_1 = new HttpStatusCode(400, 'Bad Request');
    this.n2u_1 = new HttpStatusCode(401, 'Unauthorized');
    this.o2u_1 = new HttpStatusCode(402, 'Payment Required');
    this.p2u_1 = new HttpStatusCode(403, 'Forbidden');
    this.q2u_1 = new HttpStatusCode(404, 'Not Found');
    this.r2u_1 = new HttpStatusCode(405, 'Method Not Allowed');
    this.s2u_1 = new HttpStatusCode(406, 'Not Acceptable');
    this.t2u_1 = new HttpStatusCode(407, 'Proxy Authentication Required');
    this.u2u_1 = new HttpStatusCode(408, 'Request Timeout');
    this.v2u_1 = new HttpStatusCode(409, 'Conflict');
    this.w2u_1 = new HttpStatusCode(410, 'Gone');
    this.x2u_1 = new HttpStatusCode(411, 'Length Required');
    this.y2u_1 = new HttpStatusCode(412, 'Precondition Failed');
    this.z2u_1 = new HttpStatusCode(413, 'Payload Too Large');
    this.a2v_1 = new HttpStatusCode(414, 'Request-URI Too Long');
    this.b2v_1 = new HttpStatusCode(415, 'Unsupported Media Type');
    this.c2v_1 = new HttpStatusCode(416, 'Requested Range Not Satisfiable');
    this.d2v_1 = new HttpStatusCode(417, 'Expectation Failed');
    this.e2v_1 = new HttpStatusCode(422, 'Unprocessable Entity');
    this.f2v_1 = new HttpStatusCode(423, 'Locked');
    this.g2v_1 = new HttpStatusCode(424, 'Failed Dependency');
    this.h2v_1 = new HttpStatusCode(425, 'Too Early');
    this.i2v_1 = new HttpStatusCode(426, 'Upgrade Required');
    this.j2v_1 = new HttpStatusCode(429, 'Too Many Requests');
    this.k2v_1 = new HttpStatusCode(431, 'Request Header Fields Too Large');
    this.l2v_1 = new HttpStatusCode(500, 'Internal Server Error');
    this.m2v_1 = new HttpStatusCode(501, 'Not Implemented');
    this.n2v_1 = new HttpStatusCode(502, 'Bad Gateway');
    this.o2v_1 = new HttpStatusCode(503, 'Service Unavailable');
    this.p2v_1 = new HttpStatusCode(504, 'Gateway Timeout');
    this.q2v_1 = new HttpStatusCode(505, 'HTTP Version Not Supported');
    this.r2v_1 = new HttpStatusCode(506, 'Variant Also Negotiates');
    this.s2v_1 = new HttpStatusCode(507, 'Insufficient Storage');
    this.t2v_1 = allStatusCodes();
    var tmp = this;
    // Inline function 'kotlin.collections.associateBy' call
    var this_0 = this.t2v_1;
    var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
    // Inline function 'kotlin.collections.associateByTo' call
    var destination = LinkedHashMap.ic(capacity);
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp$ret$0 = element.v2v_1;
      destination.k3(tmp$ret$0, element);
    }
    tmp.u2v_1 = destination;
  }
}
class HttpStatusCode {
  constructor(value, description) {
    Companion_getInstance_4();
    this.v2v_1 = value;
    this.w2v_1 = description;
  }
  toString() {
    return '' + this.v2v_1 + ' ' + this.w2v_1;
  }
  equals(other) {
    var tmp;
    if (other instanceof HttpStatusCode) {
      tmp = other.v2v_1 === this.v2v_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return this.v2v_1;
  }
  x2v(other) {
    return this.v2v_1 - other.v2v_1 | 0;
  }
  d(other) {
    return this.x2v(other instanceof HttpStatusCode ? other : THROW_CCE());
  }
}
class Companion_5 {
  constructor() {
    Companion_instance_5 = this;
    this.y2v_1 = EmptyParameters_instance;
  }
}
class Parameters {}
class EmptyParameters {
  b2h() {
    return true;
  }
  c2h(name) {
    return null;
  }
  d2h() {
    return emptySet();
  }
  e2h() {
    return emptySet();
  }
  h1() {
    return true;
  }
  toString() {
    return 'Parameters ' + toString(this.e2h());
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Parameters) : false) {
      tmp = other.h1();
    } else {
      tmp = false;
    }
    return tmp;
  }
}
class ParametersBuilderImpl extends StringValuesBuilderImpl {
  constructor(size) {
    size = size === VOID ? 8 : size;
    super(true, size);
  }
  h2o() {
    return new ParametersImpl(this.h2h_1);
  }
}
class ParametersImpl extends StringValuesImpl {
  constructor(values) {
    values = values === VOID ? emptyMap() : values;
    super(true, values);
  }
  toString() {
    return 'Parameters ' + toString(this.e2h());
  }
}
class Companion_6 {
  constructor() {
    Companion_instance_6 = this;
    this.h2x_1 = Url_0(get_origin(this));
    this.i2x_1 = 256;
  }
}
class URLBuilder {
  constructor(protocol, host, port, user, password, pathSegments, parameters, fragment, trailingQuery) {
    Companion_getInstance_6();
    protocol = protocol === VOID ? null : protocol;
    host = host === VOID ? '' : host;
    port = port === VOID ? 0 : port;
    user = user === VOID ? null : user;
    password = password === VOID ? null : password;
    pathSegments = pathSegments === VOID ? emptyList() : pathSegments;
    parameters = parameters === VOID ? Companion_getInstance_5().y2v_1 : parameters;
    fragment = fragment === VOID ? '' : fragment;
    trailingQuery = trailingQuery === VOID ? false : trailingQuery;
    this.b2w_1 = host;
    this.c2w_1 = trailingQuery;
    this.d2w_1 = port;
    this.e2w_1 = protocol;
    var tmp = this;
    tmp.f2w_1 = user == null ? null : encodeURLParameter(user);
    var tmp_0 = this;
    tmp_0.g2w_1 = password == null ? null : encodeURLParameter(password);
    this.h2w_1 = encodeURLQueryComponent(fragment);
    var tmp_1 = this;
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(pathSegments, 10));
    var _iterator__ex2g4s = pathSegments.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = encodeURLPathPart(item);
      destination.l(tmp$ret$0);
    }
    tmp_1.i2w_1 = destination;
    this.j2w_1 = encodeParameters(parameters);
    this.k2w_1 = new UrlDecodedParametersBuilder(this.j2w_1);
  }
  j2x(value) {
    // Inline function 'kotlin.require' call
    if (!(0 <= value ? value <= 65535 : false)) {
      var message = 'Port must be between 0 and 65535, or 0 if not set. Provided: ' + value;
      throw IllegalArgumentException.t(toString(message));
    }
    this.d2w_1 = value;
  }
  k2x(value) {
    this.e2w_1 = value;
  }
  n2w() {
    var tmp0_elvis_lhs = this.e2w_1;
    return tmp0_elvis_lhs == null ? Companion_getInstance_7().l2x_1 : tmp0_elvis_lhs;
  }
  r2x(value) {
    var tmp = this;
    tmp.f2w_1 = value == null ? null : encodeURLParameter(value);
  }
  s2x() {
    var tmp0_safe_receiver = this.f2w_1;
    return tmp0_safe_receiver == null ? null : decodeURLPart(tmp0_safe_receiver);
  }
  t2x() {
    var tmp0_safe_receiver = this.g2w_1;
    return tmp0_safe_receiver == null ? null : decodeURLPart(tmp0_safe_receiver);
  }
  u2x() {
    return decodeURLQueryComponent(this.h2w_1);
  }
  v2x() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.i2w_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = decodeURLPart(item);
      destination.l(tmp$ret$0);
    }
    return destination;
  }
  w2x(value) {
    this.j2w_1 = value;
    this.k2w_1 = new UrlDecodedParametersBuilder(value);
  }
  x2x() {
    applyOrigin(this);
    return appendTo(this, StringBuilder.xb(256)).toString();
  }
  toString() {
    return appendTo(this, StringBuilder.xb(256)).toString();
  }
  h2o() {
    applyOrigin(this);
    return new Url(this.e2w_1, this.b2w_1, this.d2w_1, this.v2x(), this.k2w_1.h2o(), this.u2x(), this.s2x(), this.t2x(), this.c2w_1, this.x2x());
  }
}
class URLParserException extends IllegalStateException {
  static c2y(urlString, cause) {
    var $this = this.pd('Fail to parse url: ' + urlString, cause);
    captureStack($this, $this.b2y_1);
    return $this;
  }
}
class Companion_7 {
  constructor() {
    Companion_instance_7 = this;
    this.l2x_1 = new URLProtocol('http', 80);
    this.m2x_1 = new URLProtocol('https', 443);
    this.n2x_1 = new URLProtocol('ws', 80);
    this.o2x_1 = new URLProtocol('wss', 443);
    this.p2x_1 = new URLProtocol('socks', 1080);
    var tmp = this;
    // Inline function 'kotlin.collections.associateBy' call
    var this_0 = listOf([this.l2x_1, this.m2x_1, this.n2x_1, this.o2x_1, this.p2x_1]);
    var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
    // Inline function 'kotlin.collections.associateByTo' call
    var destination = LinkedHashMap.ic(capacity);
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var tmp$ret$0 = element.l2w_1;
      destination.k3(tmp$ret$0, element);
    }
    tmp.q2x_1 = destination;
  }
  d2y(name) {
    // Inline function 'kotlin.let' call
    var it = toLowerCasePreservingASCIIRules(name);
    var tmp0_elvis_lhs = Companion_getInstance_7().q2x_1.h3(it);
    return tmp0_elvis_lhs == null ? new URLProtocol(it, 0) : tmp0_elvis_lhs;
  }
}
class URLProtocol {
  constructor(name, defaultPort) {
    Companion_getInstance_7();
    this.l2w_1 = name;
    this.m2w_1 = defaultPort;
    var tmp0 = this.l2w_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.text.all' call
      var inductionVariable = 0;
      while (inductionVariable < charSequenceLength(tmp0)) {
        var element = charSequenceGet(tmp0, inductionVariable);
        inductionVariable = inductionVariable + 1 | 0;
        if (!isLowerCase(element)) {
          tmp$ret$1 = false;
          break $l$block;
        }
      }
      tmp$ret$1 = true;
    }
    // Inline function 'kotlin.require' call
    if (!tmp$ret$1) {
      var message = 'All characters should be lower case';
      throw IllegalArgumentException.t(toString(message));
    }
  }
  toString() {
    return 'URLProtocol(name=' + this.l2w_1 + ', defaultPort=' + this.m2w_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.l2w_1);
    result = imul(result, 31) + this.m2w_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof URLProtocol))
      return false;
    var tmp0_other_with_cast = other instanceof URLProtocol ? other : THROW_CCE();
    if (!(this.l2w_1 === tmp0_other_with_cast.l2w_1))
      return false;
    if (!(this.m2w_1 === tmp0_other_with_cast.m2w_1))
      return false;
    return true;
  }
}
class Companion_8 {}
class Url {
  constructor(protocol, host, specifiedPort, pathSegments, parameters, fragment, user, password, trailingQuery, urlString) {
    this.o2w_1 = host;
    this.p2w_1 = specifiedPort;
    this.q2w_1 = parameters;
    this.r2w_1 = fragment;
    this.s2w_1 = user;
    this.t2w_1 = password;
    this.u2w_1 = trailingQuery;
    this.v2w_1 = urlString;
    var containsArg = this.p2w_1;
    // Inline function 'kotlin.require' call
    if (!(0 <= containsArg ? containsArg <= 65535 : false)) {
      var message = 'Port must be between 0 and 65535, or 0 if not set. Provided: ' + this.p2w_1;
      throw IllegalArgumentException.t(toString(message));
    }
    this.w2w_1 = pathSegments;
    this.x2w_1 = pathSegments;
    var tmp = this;
    tmp.y2w_1 = lazy_0(Url$segments$delegate$lambda(pathSegments));
    this.z2w_1 = protocol;
    var tmp_0 = this;
    var tmp0_elvis_lhs = this.z2w_1;
    tmp_0.a2x_1 = tmp0_elvis_lhs == null ? Companion_getInstance_7().l2x_1 : tmp0_elvis_lhs;
    var tmp_1 = this;
    tmp_1.b2x_1 = lazy_0(Url$encodedPath$delegate$lambda(pathSegments, this));
    var tmp_2 = this;
    tmp_2.c2x_1 = lazy_0(Url$encodedQuery$delegate$lambda(this));
    var tmp_3 = this;
    tmp_3.d2x_1 = lazy_0(Url$encodedPathAndQuery$delegate$lambda(this));
    var tmp_4 = this;
    tmp_4.e2x_1 = lazy_0(Url$encodedUser$delegate$lambda(this));
    var tmp_5 = this;
    tmp_5.f2x_1 = lazy_0(Url$encodedPassword$delegate$lambda(this));
    var tmp_6 = this;
    tmp_6.g2x_1 = lazy_0(Url$encodedFragment$delegate$lambda(this));
  }
  e2y() {
    // Inline function 'kotlin.takeUnless' call
    var this_0 = this.p2w_1;
    var tmp;
    if (!(this_0 === 0)) {
      tmp = this_0;
    } else {
      tmp = null;
    }
    var tmp0_elvis_lhs = tmp;
    return tmp0_elvis_lhs == null ? this.a2x_1.m2w_1 : tmp0_elvis_lhs;
  }
  f2y() {
    var tmp0 = this.b2x_1;
    // Inline function 'kotlin.getValue' call
    encodedPath$factory();
    return tmp0.n1();
  }
  i2y() {
    var tmp0 = this.c2x_1;
    // Inline function 'kotlin.getValue' call
    encodedQuery$factory();
    return tmp0.n1();
  }
  g2y() {
    var tmp0 = this.e2x_1;
    // Inline function 'kotlin.getValue' call
    encodedUser$factory();
    return tmp0.n1();
  }
  h2y() {
    var tmp0 = this.f2x_1;
    // Inline function 'kotlin.getValue' call
    encodedPassword$factory();
    return tmp0.n1();
  }
  j2y() {
    var tmp0 = this.g2x_1;
    // Inline function 'kotlin.getValue' call
    encodedFragment$factory();
    return tmp0.n1();
  }
  toString() {
    return this.v2w_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof Url))
      THROW_CCE();
    return this.v2w_1 === other.v2w_1;
  }
  hashCode() {
    return getStringHashCode(this.v2w_1);
  }
}
class UrlSerializer {
  constructor() {
    UrlSerializer_instance = this;
    this.k2y_1 = PrimitiveSerialDescriptor('io.ktor.http.Url', STRING_getInstance());
  }
  h1t() {
    return this.k2y_1;
  }
  j1t(decoder) {
    return Url_0(decoder.l1x());
  }
  l2y(encoder, value) {
    encoder.v1y(value.toString());
  }
  i1t(encoder, value) {
    return this.l2y(encoder, value instanceof Url ? value : THROW_CCE());
  }
}
class UrlDecodedParametersBuilder {
  constructor(encodedParametersBuilder) {
    this.m2y_1 = encodedParametersBuilder;
    this.n2y_1 = this.m2y_1.b2h();
  }
  h2o() {
    return decodeParameters(this.m2y_1);
  }
  b2h() {
    return this.n2y_1;
  }
  c2h(name) {
    var tmp0_safe_receiver = this.m2y_1.c2h(encodeURLParameter(name));
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(tmp0_safe_receiver, 10));
      var _iterator__ex2g4s = tmp0_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$0 = decodeURLQueryComponent(item, VOID, VOID, true);
        destination.l(tmp$ret$0);
      }
      tmp = destination;
    }
    return tmp;
  }
  k2h(name) {
    return this.m2y_1.k2h(encodeURLParameter(name));
  }
  d2h() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.m2y_1.d2h();
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = decodeURLQueryComponent(item);
      destination.l(tmp$ret$0);
    }
    return toSet(destination);
  }
  h1() {
    return this.m2y_1.h1();
  }
  e2h() {
    return decodeParameters(this.m2y_1).e2h();
  }
  n2h(name, value) {
    return this.m2y_1.n2h(encodeURLParameter(name), encodeURLParameterValue(value));
  }
  o2h(stringValues) {
    return appendAllEncoded(this.m2y_1, stringValues);
  }
  j2h(name, values) {
    var tmp = encodeURLParameter(name);
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(values, 10));
    var _iterator__ex2g4s = values.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = encodeURLParameterValue(item);
      destination.l(tmp$ret$0);
    }
    return this.m2y_1.j2h(tmp, destination);
  }
  b3() {
    return this.m2y_1.b3();
  }
}
class MultiPartData {}
class OutgoingContent {
  constructor($box) {
    boxApply(this, $box);
    this.o2y_1 = null;
  }
  p2y() {
    return null;
  }
  q2y() {
    return null;
  }
  a2t() {
    return Companion_getInstance_1().e2o_1;
  }
}
class NoContent extends OutgoingContent {}
class ReadChannelContent extends OutgoingContent {}
class WriteChannelContent extends OutgoingContent {}
class ByteArrayContent extends OutgoingContent {}
class ProtocolUpgrade extends OutgoingContent {}
class ContentWrapper extends OutgoingContent {
  z2y() {
    return this.y2y_1;
  }
}
class NullBody {}
class TextContent extends ByteArrayContent {
  constructor(text, contentType, status) {
    status = status === VOID ? null : status;
    super();
    this.b2z_1 = text;
    this.c2z_1 = contentType;
    this.d2z_1 = status;
    var tmp = this;
    var tmp0_elvis_lhs = charset(this.c2z_1);
    tmp.e2z_1 = toByteArray(this.b2z_1, tmp0_elvis_lhs == null ? Charsets_getInstance().f1s_1 : tmp0_elvis_lhs);
  }
  p2y() {
    return this.c2z_1;
  }
  q2y() {
    return toLong_0(this.e2z_1.length);
  }
  w2y() {
    return this.e2z_1;
  }
  toString() {
    return 'TextContent[' + this.c2z_1.toString() + '] "' + take(this.b2z_1, 30) + '"';
  }
}
//endregion
function get_URL_ALPHABET() {
  _init_properties_Codecs_kt__fudxxf();
  return URL_ALPHABET;
}
var URL_ALPHABET;
function get_URL_ALPHABET_CHARS() {
  _init_properties_Codecs_kt__fudxxf();
  return URL_ALPHABET_CHARS;
}
var URL_ALPHABET_CHARS;
function get_HEX_ALPHABET() {
  _init_properties_Codecs_kt__fudxxf();
  return HEX_ALPHABET;
}
var HEX_ALPHABET;
function get_URL_PROTOCOL_PART() {
  _init_properties_Codecs_kt__fudxxf();
  return URL_PROTOCOL_PART;
}
var URL_PROTOCOL_PART;
function get_VALID_PATH_PART() {
  _init_properties_Codecs_kt__fudxxf();
  return VALID_PATH_PART;
}
var VALID_PATH_PART;
var ATTRIBUTE_CHARACTERS;
function get_SPECIAL_SYMBOLS() {
  _init_properties_Codecs_kt__fudxxf();
  return SPECIAL_SYMBOLS;
}
var SPECIAL_SYMBOLS;
function encodeURLParameter(_this__u8e3s4, spaceToPlus) {
  spaceToPlus = spaceToPlus === VOID ? false : spaceToPlus;
  _init_properties_Codecs_kt__fudxxf();
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  var content = encode(Charsets_getInstance().f1s_1.i1s(), _this__u8e3s4);
  forEach_0(content, encodeURLParameter$lambda(this_0, spaceToPlus));
  return this_0.toString();
}
function decodeURLPart(_this__u8e3s4, start, end, charset) {
  start = start === VOID ? 0 : start;
  end = end === VOID ? _this__u8e3s4.length : end;
  charset = charset === VOID ? Charsets_getInstance().f1s_1 : charset;
  _init_properties_Codecs_kt__fudxxf();
  return decodeScan(_this__u8e3s4, start, end, false, charset);
}
function encodeURLQueryComponent(_this__u8e3s4, encodeFull, spaceToPlus, charset) {
  encodeFull = encodeFull === VOID ? false : encodeFull;
  spaceToPlus = spaceToPlus === VOID ? false : spaceToPlus;
  charset = charset === VOID ? Charsets_getInstance().f1s_1 : charset;
  _init_properties_Codecs_kt__fudxxf();
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  var content = encode(charset.i1s(), _this__u8e3s4);
  forEach_0(content, encodeURLQueryComponent$lambda(spaceToPlus, this_0, encodeFull));
  return this_0.toString();
}
function decodeURLQueryComponent(_this__u8e3s4, start, end, plusIsSpace, charset) {
  start = start === VOID ? 0 : start;
  end = end === VOID ? _this__u8e3s4.length : end;
  plusIsSpace = plusIsSpace === VOID ? false : plusIsSpace;
  charset = charset === VOID ? Charsets_getInstance().f1s_1 : charset;
  _init_properties_Codecs_kt__fudxxf();
  return decodeScan(_this__u8e3s4, start, end, plusIsSpace, charset);
}
function encodeURLPathPart(_this__u8e3s4) {
  _init_properties_Codecs_kt__fudxxf();
  return encodeURLPath(_this__u8e3s4, true);
}
function forEach_0(_this__u8e3s4, block) {
  _init_properties_Codecs_kt__fudxxf();
  takeWhile(_this__u8e3s4, forEach$lambda(block));
}
function percentEncode(_this__u8e3s4) {
  _init_properties_Codecs_kt__fudxxf();
  var code = _this__u8e3s4 & 255;
  var array = charArray(3);
  array[0] = _Char___init__impl__6a9atx(37);
  array[1] = hexDigitToChar(code >> 4);
  array[2] = hexDigitToChar(code & 15);
  return concatToString(array);
}
function decodeScan(_this__u8e3s4, start, end, plusIsSpace, charset) {
  _init_properties_Codecs_kt__fudxxf();
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var ch = charSequenceGet(_this__u8e3s4, index);
      if (ch === _Char___init__impl__6a9atx(37) || (plusIsSpace && ch === _Char___init__impl__6a9atx(43))) {
        return decodeImpl(_this__u8e3s4, start, end, index, plusIsSpace, charset);
      }
    }
     while (inductionVariable < end);
  var tmp;
  if (start === 0 && end === _this__u8e3s4.length) {
    tmp = toString(_this__u8e3s4);
  } else {
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp = _this__u8e3s4.substring(start, end);
  }
  return tmp;
}
function encodeURLPath(_this__u8e3s4, encodeSlash, encodeEncoded) {
  encodeSlash = encodeSlash === VOID ? false : encodeSlash;
  encodeEncoded = encodeEncoded === VOID ? true : encodeEncoded;
  _init_properties_Codecs_kt__fudxxf();
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  var charset = Charsets_getInstance().f1s_1;
  var index = 0;
  $l$loop_0: while (index < _this__u8e3s4.length) {
    var current = charSequenceGet(_this__u8e3s4, index);
    if (!encodeSlash && current === _Char___init__impl__6a9atx(47) || get_URL_ALPHABET_CHARS().v2(new Char(current)) || get_VALID_PATH_PART().v2(new Char(current))) {
      this_0.ub(current);
      index = index + 1 | 0;
      continue $l$loop_0;
    }
    if (!encodeEncoded && current === _Char___init__impl__6a9atx(37) && (index + 2 | 0) < _this__u8e3s4.length && get_HEX_ALPHABET().v2(new Char(charSequenceGet(_this__u8e3s4, index + 1 | 0))) && get_HEX_ALPHABET().v2(new Char(charSequenceGet(_this__u8e3s4, index + 2 | 0)))) {
      this_0.ub(current);
      this_0.ub(charSequenceGet(_this__u8e3s4, index + 1 | 0));
      this_0.ub(charSequenceGet(_this__u8e3s4, index + 2 | 0));
      index = index + 3 | 0;
      continue $l$loop_0;
    }
    var symbolSize = isSurrogate(current) ? 2 : 1;
    var tmp = encode(charset.i1s(), _this__u8e3s4, index, index + symbolSize | 0);
    forEach_0(tmp, encodeURLPath$lambda(this_0));
    index = index + symbolSize | 0;
  }
  return this_0.toString();
}
function hexDigitToChar(digit) {
  _init_properties_Codecs_kt__fudxxf();
  return (0 <= digit ? digit <= 9 : false) ? Char__plus_impl_qi7pgj(_Char___init__impl__6a9atx(48), digit) : Char__minus_impl_a2frrh(Char__plus_impl_qi7pgj(_Char___init__impl__6a9atx(65), digit), 10);
}
function decodeImpl(_this__u8e3s4, start, end, prefixEnd, plusIsSpace, charset) {
  _init_properties_Codecs_kt__fudxxf();
  var length = end - start | 0;
  var sbSize = length > 255 ? length / 3 | 0 : length;
  var sb = StringBuilder.xb(sbSize);
  if (prefixEnd > start) {
    sb.ch(_this__u8e3s4, start, prefixEnd);
  }
  var index = prefixEnd;
  var bytes = null;
  while (index < end) {
    var c = charSequenceGet(_this__u8e3s4, index);
    if (plusIsSpace && c === _Char___init__impl__6a9atx(43)) {
      sb.ub(_Char___init__impl__6a9atx(32));
      index = index + 1 | 0;
    } else if (c === _Char___init__impl__6a9atx(37)) {
      if (bytes == null) {
        bytes = new Int8Array((end - index | 0) / 3 | 0);
      }
      var count = 0;
      while (index < end && charSequenceGet(_this__u8e3s4, index) === _Char___init__impl__6a9atx(37)) {
        if ((index + 2 | 0) >= end) {
          // Inline function 'kotlin.text.substring' call
          var startIndex = index;
          var endIndex = charSequenceLength(_this__u8e3s4);
          var tmp$ret$0 = toString(charSequenceSubSequence(_this__u8e3s4, startIndex, endIndex));
          throw URLDecodeException.o2l('Incomplete trailing HEX escape: ' + tmp$ret$0 + ', in ' + toString(_this__u8e3s4) + ' at ' + index);
        }
        var digit1 = charToHexDigit(charSequenceGet(_this__u8e3s4, index + 1 | 0));
        var digit2 = charToHexDigit(charSequenceGet(_this__u8e3s4, index + 2 | 0));
        if (digit1 === -1 || digit2 === -1) {
          throw URLDecodeException.o2l('Wrong HEX escape: %' + toString_0(charSequenceGet(_this__u8e3s4, index + 1 | 0)) + toString_0(charSequenceGet(_this__u8e3s4, index + 2 | 0)) + ', in ' + toString(_this__u8e3s4) + ', at ' + index);
        }
        var tmp = bytes;
        var _unary__edvuaz = count;
        count = _unary__edvuaz + 1 | 0;
        tmp[_unary__edvuaz] = toByte(imul(digit1, 16) + digit2 | 0);
        index = index + 3 | 0;
      }
      sb.tb(decodeToString(bytes, 0, 0 + count | 0));
    } else {
      sb.ub(c);
      index = index + 1 | 0;
    }
  }
  return sb.toString();
}
function charToHexDigit(c2) {
  _init_properties_Codecs_kt__fudxxf();
  return (_Char___init__impl__6a9atx(48) <= c2 ? c2 <= _Char___init__impl__6a9atx(57) : false) ? Char__minus_impl_a2frrh_0(c2, _Char___init__impl__6a9atx(48)) : (_Char___init__impl__6a9atx(65) <= c2 ? c2 <= _Char___init__impl__6a9atx(70) : false) ? Char__minus_impl_a2frrh_0(c2, _Char___init__impl__6a9atx(65)) + 10 | 0 : (_Char___init__impl__6a9atx(97) <= c2 ? c2 <= _Char___init__impl__6a9atx(102) : false) ? Char__minus_impl_a2frrh_0(c2, _Char___init__impl__6a9atx(97)) + 10 | 0 : -1;
}
function encodeURLParameterValue(_this__u8e3s4) {
  _init_properties_Codecs_kt__fudxxf();
  return encodeURLParameter(_this__u8e3s4, true);
}
function encodeURLParameter$lambda($$this$buildString, $spaceToPlus) {
  return (it) => {
    if (get_URL_ALPHABET().v2(it) || get_SPECIAL_SYMBOLS().v2(it))
      $$this$buildString.ub(numberToChar(it));
    else {
      var tmp;
      if ($spaceToPlus) {
        var tmp_0 = it;
        // Inline function 'kotlin.code' call
        var this_0 = _Char___init__impl__6a9atx(32);
        var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
        tmp = tmp_0 === toByte(tmp$ret$0);
      } else {
        tmp = false;
      }
      if (tmp)
        $$this$buildString.ub(_Char___init__impl__6a9atx(43));
      else {
        $$this$buildString.tb(percentEncode(it));
      }
    }
    return Unit_instance;
  };
}
function encodeURLQueryComponent$lambda($spaceToPlus, $$this$buildString, $encodeFull) {
  return (it) => {
    var tmp = it;
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(32);
    var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
    if (tmp === toByte(tmp$ret$0))
      if ($spaceToPlus)
        $$this$buildString.ub(_Char___init__impl__6a9atx(43));
      else
        $$this$buildString.tb('%20');
    else {
      if (get_URL_ALPHABET().v2(it) || (!$encodeFull && get_URL_PROTOCOL_PART().v2(it)))
        $$this$buildString.ub(numberToChar(it));
      else {
        $$this$buildString.tb(percentEncode(it));
      }
    }
    return Unit_instance;
  };
}
function forEach$lambda($block) {
  return (buffer) => {
    while (canRead(buffer)) {
      $block(buffer.k1l());
    }
    return true;
  };
}
function encodeURLPath$lambda($$this$buildString) {
  return (it) => {
    $$this$buildString.tb(percentEncode(it));
    return Unit_instance;
  };
}
var properties_initialized_Codecs_kt_hkj9s1;
function _init_properties_Codecs_kt__fudxxf() {
  if (!properties_initialized_Codecs_kt_hkj9s1) {
    properties_initialized_Codecs_kt_hkj9s1 = true;
    // Inline function 'kotlin.collections.map' call
    var this_0 = plus_0(plus(Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(97), _Char___init__impl__6a9atx(122)), Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(65), _Char___init__impl__6a9atx(90))), Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(48), _Char___init__impl__6a9atx(57)));
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.code' call
      var this_1 = item.j2_1;
      var tmp$ret$0 = Char__toInt_impl_vasixd(this_1);
      var tmp$ret$1 = toByte(tmp$ret$0);
      destination.l(tmp$ret$1);
    }
    URL_ALPHABET = toSet(destination);
    URL_ALPHABET_CHARS = toSet(plus_0(plus(Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(97), _Char___init__impl__6a9atx(122)), Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(65), _Char___init__impl__6a9atx(90))), Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(48), _Char___init__impl__6a9atx(57))));
    HEX_ALPHABET = toSet(plus_0(plus(Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(97), _Char___init__impl__6a9atx(102)), Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(65), _Char___init__impl__6a9atx(70))), Char__rangeTo_impl_tkncvp(_Char___init__impl__6a9atx(48), _Char___init__impl__6a9atx(57))));
    // Inline function 'kotlin.collections.map' call
    var this_2 = setOf([new Char(_Char___init__impl__6a9atx(58)), new Char(_Char___init__impl__6a9atx(47)), new Char(_Char___init__impl__6a9atx(63)), new Char(_Char___init__impl__6a9atx(35)), new Char(_Char___init__impl__6a9atx(91)), new Char(_Char___init__impl__6a9atx(93)), new Char(_Char___init__impl__6a9atx(64)), new Char(_Char___init__impl__6a9atx(33)), new Char(_Char___init__impl__6a9atx(36)), new Char(_Char___init__impl__6a9atx(38)), new Char(_Char___init__impl__6a9atx(39)), new Char(_Char___init__impl__6a9atx(40)), new Char(_Char___init__impl__6a9atx(41)), new Char(_Char___init__impl__6a9atx(42)), new Char(_Char___init__impl__6a9atx(44)), new Char(_Char___init__impl__6a9atx(59)), new Char(_Char___init__impl__6a9atx(61)), new Char(_Char___init__impl__6a9atx(45)), new Char(_Char___init__impl__6a9atx(46)), new Char(_Char___init__impl__6a9atx(95)), new Char(_Char___init__impl__6a9atx(126)), new Char(_Char___init__impl__6a9atx(43))]);
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(this_2, 10));
    var _iterator__ex2g4s_0 = this_2.y();
    while (_iterator__ex2g4s_0.z()) {
      var item_0 = _iterator__ex2g4s_0.a1();
      // Inline function 'kotlin.code' call
      var this_3 = item_0.j2_1;
      var tmp$ret$0_0 = Char__toInt_impl_vasixd(this_3);
      var tmp$ret$1_0 = toByte(tmp$ret$0_0);
      destination_0.l(tmp$ret$1_0);
    }
    URL_PROTOCOL_PART = destination_0;
    VALID_PATH_PART = setOf([new Char(_Char___init__impl__6a9atx(58)), new Char(_Char___init__impl__6a9atx(64)), new Char(_Char___init__impl__6a9atx(33)), new Char(_Char___init__impl__6a9atx(36)), new Char(_Char___init__impl__6a9atx(38)), new Char(_Char___init__impl__6a9atx(39)), new Char(_Char___init__impl__6a9atx(40)), new Char(_Char___init__impl__6a9atx(41)), new Char(_Char___init__impl__6a9atx(42)), new Char(_Char___init__impl__6a9atx(43)), new Char(_Char___init__impl__6a9atx(44)), new Char(_Char___init__impl__6a9atx(59)), new Char(_Char___init__impl__6a9atx(61)), new Char(_Char___init__impl__6a9atx(45)), new Char(_Char___init__impl__6a9atx(46)), new Char(_Char___init__impl__6a9atx(95)), new Char(_Char___init__impl__6a9atx(126))]);
    ATTRIBUTE_CHARACTERS = plus_1(get_URL_ALPHABET_CHARS(), setOf([new Char(_Char___init__impl__6a9atx(33)), new Char(_Char___init__impl__6a9atx(35)), new Char(_Char___init__impl__6a9atx(36)), new Char(_Char___init__impl__6a9atx(38)), new Char(_Char___init__impl__6a9atx(43)), new Char(_Char___init__impl__6a9atx(45)), new Char(_Char___init__impl__6a9atx(46)), new Char(_Char___init__impl__6a9atx(94)), new Char(_Char___init__impl__6a9atx(95)), new Char(_Char___init__impl__6a9atx(96)), new Char(_Char___init__impl__6a9atx(124)), new Char(_Char___init__impl__6a9atx(126))]));
    // Inline function 'kotlin.collections.map' call
    var this_4 = listOf([new Char(_Char___init__impl__6a9atx(45)), new Char(_Char___init__impl__6a9atx(46)), new Char(_Char___init__impl__6a9atx(95)), new Char(_Char___init__impl__6a9atx(126))]);
    // Inline function 'kotlin.collections.mapTo' call
    var destination_1 = ArrayList.x(collectionSizeOrDefault(this_4, 10));
    var _iterator__ex2g4s_1 = this_4.y();
    while (_iterator__ex2g4s_1.z()) {
      var item_1 = _iterator__ex2g4s_1.a1();
      // Inline function 'kotlin.code' call
      var this_5 = item_1.j2_1;
      var tmp$ret$0_1 = Char__toInt_impl_vasixd(this_5);
      var tmp$ret$1_1 = toByte(tmp$ret$0_1);
      destination_1.l(tmp$ret$1_1);
    }
    SPECIAL_SYMBOLS = destination_1;
  }
}
function hasParameter($this, name, value) {
  var tmp;
  switch ($this.q2l_1.b1()) {
    case 0:
      tmp = false;
      break;
    case 1:
      // Inline function 'kotlin.let' call

      var it = $this.q2l_1.f1(0);
      tmp = (equals(it.r2l_1, name, true) && equals(it.s2l_1, value, true));
      break;
    default:
      var tmp2 = $this.q2l_1;
      var tmp$ret$2;
      $l$block_0: {
        // Inline function 'kotlin.collections.any' call
        var tmp_0;
        if (isInterface(tmp2, Collection)) {
          tmp_0 = tmp2.h1();
        } else {
          tmp_0 = false;
        }
        if (tmp_0) {
          tmp$ret$2 = false;
          break $l$block_0;
        }
        var _iterator__ex2g4s = tmp2.y();
        while (_iterator__ex2g4s.z()) {
          var element = _iterator__ex2g4s.a1();
          if (equals(element.r2l_1, name, true) && equals(element.s2l_1, value, true)) {
            tmp$ret$2 = true;
            break $l$block_0;
          }
        }
        tmp$ret$2 = false;
      }

      tmp = tmp$ret$2;
      break;
  }
  return tmp;
}
var Companion_instance;
function Companion_getInstance() {
  if (Companion_instance === VOID)
    new Companion();
  return Companion_instance;
}
var Application_instance;
function Application_getInstance() {
  if (Application_instance === VOID)
    new Application();
  return Application_instance;
}
var MultiPart_instance;
function MultiPart_getInstance() {
  if (MultiPart_instance === VOID)
    new MultiPart();
  return MultiPart_instance;
}
var Text_instance;
function Text_getInstance() {
  if (Text_instance === VOID)
    new Text();
  return Text_instance;
}
function charset(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.d2o('charset');
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp_0;
    try {
      tmp_0 = forName(Charsets_getInstance(), tmp0_safe_receiver);
    } catch ($p) {
      var tmp_1;
      if ($p instanceof IllegalArgumentException) {
        var exception = $p;
        tmp_1 = null;
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function withCharset(_this__u8e3s4, charset) {
  return _this__u8e3s4.a2o('charset', get_name(charset));
}
function get_HeaderFieldValueSeparators() {
  _init_properties_HeaderValueWithParameters_kt__z6luvy();
  return HeaderFieldValueSeparators;
}
var HeaderFieldValueSeparators;
var Companion_instance_0;
function Companion_getInstance_0() {
  return Companion_instance_0;
}
function needQuotes(_this__u8e3s4) {
  _init_properties_HeaderValueWithParameters_kt__z6luvy();
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(_this__u8e3s4) === 0)
    return true;
  if (isQuoted(_this__u8e3s4))
    return false;
  var inductionVariable = 0;
  var last = _this__u8e3s4.length;
  while (inductionVariable < last) {
    var element = charSequenceGet(_this__u8e3s4, inductionVariable);
    inductionVariable = inductionVariable + 1 | 0;
    if (get_HeaderFieldValueSeparators().v2(new Char(element)))
      return true;
  }
  return false;
}
function quote(_this__u8e3s4) {
  _init_properties_HeaderValueWithParameters_kt__z6luvy();
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  quoteTo(_this__u8e3s4, this_0);
  return this_0.toString();
}
function isQuoted(_this__u8e3s4) {
  _init_properties_HeaderValueWithParameters_kt__z6luvy();
  if (_this__u8e3s4.length < 2) {
    return false;
  }
  if (!(first(_this__u8e3s4) === _Char___init__impl__6a9atx(34)) || !(last_0(_this__u8e3s4) === _Char___init__impl__6a9atx(34))) {
    return false;
  }
  var startIndex = 1;
  $l$loop: do {
    var index = indexOf(_this__u8e3s4, _Char___init__impl__6a9atx(34), startIndex);
    if (index === get_lastIndex_0(_this__u8e3s4)) {
      break $l$loop;
    }
    var slashesCount = 0;
    var slashIndex = index - 1 | 0;
    while (charSequenceGet(_this__u8e3s4, slashIndex) === _Char___init__impl__6a9atx(92)) {
      slashesCount = slashesCount + 1 | 0;
      slashIndex = slashIndex - 1 | 0;
    }
    if ((slashesCount % 2 | 0) === 0) {
      return false;
    }
    startIndex = index + 1 | 0;
  }
   while (startIndex < _this__u8e3s4.length);
  return true;
}
function quoteTo(_this__u8e3s4, out) {
  _init_properties_HeaderValueWithParameters_kt__z6luvy();
  out.tb('"');
  var inductionVariable = 0;
  var last = _this__u8e3s4.length;
  while (inductionVariable < last) {
    var element = charSequenceGet(_this__u8e3s4, inductionVariable);
    inductionVariable = inductionVariable + 1 | 0;
    var ch = element;
    if (ch === _Char___init__impl__6a9atx(92))
      out.tb('\\\\');
    else if (ch === _Char___init__impl__6a9atx(10))
      out.tb('\\n');
    else if (ch === _Char___init__impl__6a9atx(13))
      out.tb('\\r');
    else if (ch === _Char___init__impl__6a9atx(9))
      out.tb('\\t');
    else if (ch === _Char___init__impl__6a9atx(34))
      out.tb('\\"');
    else
      out.ub(ch);
  }
  out.tb('"');
}
var properties_initialized_HeaderValueWithParameters_kt_yu5xg;
function _init_properties_HeaderValueWithParameters_kt__z6luvy() {
  if (!properties_initialized_HeaderValueWithParameters_kt_yu5xg) {
    properties_initialized_HeaderValueWithParameters_kt_yu5xg = true;
    HeaderFieldValueSeparators = setOf([new Char(_Char___init__impl__6a9atx(40)), new Char(_Char___init__impl__6a9atx(41)), new Char(_Char___init__impl__6a9atx(60)), new Char(_Char___init__impl__6a9atx(62)), new Char(_Char___init__impl__6a9atx(64)), new Char(_Char___init__impl__6a9atx(44)), new Char(_Char___init__impl__6a9atx(59)), new Char(_Char___init__impl__6a9atx(58)), new Char(_Char___init__impl__6a9atx(92)), new Char(_Char___init__impl__6a9atx(34)), new Char(_Char___init__impl__6a9atx(47)), new Char(_Char___init__impl__6a9atx(91)), new Char(_Char___init__impl__6a9atx(93)), new Char(_Char___init__impl__6a9atx(63)), new Char(_Char___init__impl__6a9atx(61)), new Char(_Char___init__impl__6a9atx(123)), new Char(_Char___init__impl__6a9atx(125)), new Char(_Char___init__impl__6a9atx(32)), new Char(_Char___init__impl__6a9atx(9)), new Char(_Char___init__impl__6a9atx(10)), new Char(_Char___init__impl__6a9atx(13))]);
  }
}
var Companion_instance_1;
function Companion_getInstance_1() {
  if (Companion_instance_1 === VOID)
    new Companion_1();
  return Companion_instance_1;
}
var EmptyHeaders_instance;
function EmptyHeaders_getInstance() {
  return EmptyHeaders_instance;
}
function headersOf(name, value) {
  return new HeadersSingleImpl(name, listOf_0(value));
}
function parseHeaderValue(text) {
  return parseHeaderValue_0(text, false);
}
function parseHeaderValue_0(text, parametersOnly) {
  if (text == null) {
    return emptyList();
  }
  var position = 0;
  var tmp = LazyThreadSafetyMode_NONE_getInstance();
  var items = lazy(tmp, parseHeaderValue$lambda);
  while (position <= get_lastIndex_0(text)) {
    position = parseHeaderValueItem(text, position, items, parametersOnly);
  }
  return valueOrEmpty(items);
}
function parseHeaderValueItem(text, start, items, parametersOnly) {
  var position = start;
  var tmp = LazyThreadSafetyMode_NONE_getInstance();
  var parameters = lazy(tmp, parseHeaderValueItem$lambda);
  var valueEnd = parametersOnly ? position : null;
  while (position <= get_lastIndex_0(text)) {
    var tmp0_subject = charSequenceGet(text, position);
    if (tmp0_subject === _Char___init__impl__6a9atx(44)) {
      var tmp_0 = items.n1();
      var tmp1_elvis_lhs = valueEnd;
      tmp_0.l(new HeaderValue(subtrim(text, start, tmp1_elvis_lhs == null ? position : tmp1_elvis_lhs), valueOrEmpty(parameters)));
      return position + 1 | 0;
    } else if (tmp0_subject === _Char___init__impl__6a9atx(59)) {
      if (valueEnd == null)
        valueEnd = position;
      position = parseHeaderValueParameter(text, position + 1 | 0, parameters);
    } else {
      var tmp_1;
      if (parametersOnly) {
        tmp_1 = parseHeaderValueParameter(text, position, parameters);
      } else {
        tmp_1 = position + 1 | 0;
      }
      position = tmp_1;
    }
  }
  var tmp_2 = items.n1();
  var tmp2_elvis_lhs = valueEnd;
  tmp_2.l(new HeaderValue(subtrim(text, start, tmp2_elvis_lhs == null ? position : tmp2_elvis_lhs), valueOrEmpty(parameters)));
  return position;
}
function valueOrEmpty(_this__u8e3s4) {
  return _this__u8e3s4.yr() ? _this__u8e3s4.n1() : emptyList();
}
function subtrim(_this__u8e3s4, start, end) {
  // Inline function 'kotlin.text.substring' call
  // Inline function 'kotlin.js.asDynamic' call
  // Inline function 'kotlin.text.trim' call
  var this_0 = _this__u8e3s4.substring(start, end);
  return toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
}
function parseHeaderValueParameter(text, start, parameters) {
  var position = start;
  while (position <= get_lastIndex_0(text)) {
    var tmp0_subject = charSequenceGet(text, position);
    if (tmp0_subject === _Char___init__impl__6a9atx(61)) {
      var _destruct__k2r9zo = parseHeaderValueParameterValue(text, position + 1 | 0);
      var paramEnd = _destruct__k2r9zo.tl();
      var paramValue = _destruct__k2r9zo.ul();
      parseHeaderValueParameter$addParam(parameters, text, start, position, paramValue);
      return paramEnd;
    } else if (tmp0_subject === _Char___init__impl__6a9atx(59) || tmp0_subject === _Char___init__impl__6a9atx(44)) {
      parseHeaderValueParameter$addParam(parameters, text, start, position, '');
      return position;
    } else {
      position = position + 1 | 0;
    }
  }
  parseHeaderValueParameter$addParam(parameters, text, start, position, '');
  return position;
}
function parseHeaderValueParameterValue(value, start) {
  if (value.length === start) {
    return to(start, '');
  }
  var position = start;
  if (charSequenceGet(value, start) === _Char___init__impl__6a9atx(34)) {
    return parseHeaderValueParameterValueQuoted(value, position + 1 | 0);
  }
  while (position <= get_lastIndex_0(value)) {
    var tmp0_subject = charSequenceGet(value, position);
    if (tmp0_subject === _Char___init__impl__6a9atx(59) || tmp0_subject === _Char___init__impl__6a9atx(44))
      return to(position, subtrim(value, start, position));
    else {
      position = position + 1 | 0;
    }
  }
  return to(position, subtrim(value, start, position));
}
function parseHeaderValueParameterValueQuoted(value, start) {
  var position = start;
  var builder = StringBuilder.v();
  loop: while (position <= get_lastIndex_0(value)) {
    var currentChar = charSequenceGet(value, position);
    if (currentChar === _Char___init__impl__6a9atx(34) && nextIsDelimiterOrEnd(value, position)) {
      return to(position + 1 | 0, builder.toString());
    } else if (currentChar === _Char___init__impl__6a9atx(92) && position < (get_lastIndex_0(value) - 2 | 0)) {
      builder.ub(charSequenceGet(value, position + 1 | 0));
      position = position + 2 | 0;
      continue loop;
    }
    builder.ub(currentChar);
    position = position + 1 | 0;
  }
  var tmp = position;
  var tmp0 = _Char___init__impl__6a9atx(34);
  // Inline function 'kotlin.text.plus' call
  var other = builder.toString();
  var tmp$ret$0 = toString_0(tmp0) + other;
  return to(tmp, tmp$ret$0);
}
function nextIsDelimiterOrEnd(_this__u8e3s4, start) {
  var position = start + 1 | 0;
  loop: while (position < _this__u8e3s4.length && charSequenceGet(_this__u8e3s4, position) === _Char___init__impl__6a9atx(32)) {
    position = position + 1 | 0;
  }
  return position === _this__u8e3s4.length || charSequenceGet(_this__u8e3s4, position) === _Char___init__impl__6a9atx(59) || charSequenceGet(_this__u8e3s4, position) === _Char___init__impl__6a9atx(44);
}
function parseHeaderValueParameter$addParam($parameters, text, start, end, value) {
  var name = subtrim(text, start, end);
  // Inline function 'kotlin.text.isEmpty' call
  if (charSequenceLength(name) === 0) {
    return Unit_instance;
  }
  $parameters.n1().l(HeaderValueParam.b2o(name, value));
}
function parseHeaderValue$lambda() {
  // Inline function 'kotlin.collections.arrayListOf' call
  return ArrayList.k();
}
function parseHeaderValueItem$lambda() {
  // Inline function 'kotlin.collections.arrayListOf' call
  return ArrayList.k();
}
var HttpHeaders_instance;
function HttpHeaders_getInstance() {
  if (HttpHeaders_instance === VOID)
    new HttpHeaders();
  return HttpHeaders_instance;
}
function isDelimiter(ch) {
  return contains('"(),/:;<=>?@[\\]{}', ch);
}
function contentLength(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.a2t().w2f(HttpHeaders_getInstance().x2o_1);
  return tmp0_safe_receiver == null ? null : toLong(tmp0_safe_receiver);
}
function charset_0(_this__u8e3s4) {
  var tmp0_safe_receiver = contentType_1(_this__u8e3s4);
  return tmp0_safe_receiver == null ? null : charset(tmp0_safe_receiver);
}
function contentType(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.a2t().w2f(HttpHeaders_getInstance().a2p_1);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = Companion_getInstance().ds(tmp0_safe_receiver);
  }
  return tmp;
}
function contentType_0(_this__u8e3s4, type) {
  return _this__u8e3s4.a2t().l2h(HttpHeaders_getInstance().a2p_1, type.toString());
}
function contentType_1(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.a2t().w2f(HttpHeaders_getInstance().a2p_1);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = Companion_getInstance().ds(tmp0_safe_receiver);
  }
  return tmp;
}
function get_REQUESTS_WITHOUT_BODY() {
  _init_properties_HttpMethod_kt__cbus5z();
  return REQUESTS_WITHOUT_BODY;
}
var REQUESTS_WITHOUT_BODY;
var Companion_instance_2;
function Companion_getInstance_2() {
  if (Companion_instance_2 === VOID)
    new Companion_2();
  return Companion_instance_2;
}
function get_supportsRequestBody(_this__u8e3s4) {
  _init_properties_HttpMethod_kt__cbus5z();
  return !get_REQUESTS_WITHOUT_BODY().v2(_this__u8e3s4);
}
var properties_initialized_HttpMethod_kt_ogor3f;
function _init_properties_HttpMethod_kt__cbus5z() {
  if (!properties_initialized_HttpMethod_kt_ogor3f) {
    properties_initialized_HttpMethod_kt_ogor3f = true;
    REQUESTS_WITHOUT_BODY = setOf([Companion_getInstance_2().b2t_1, Companion_getInstance_2().g2t_1, Companion_getInstance_2().h2t_1, new HttpMethod('TRACE')]);
  }
}
var Companion_instance_3;
function Companion_getInstance_3() {
  if (Companion_instance_3 === VOID)
    new Companion_3();
  return Companion_instance_3;
}
var Companion_instance_4;
function Companion_getInstance_4() {
  if (Companion_instance_4 === VOID)
    new Companion_4();
  return Companion_instance_4;
}
function allStatusCodes() {
  return listOf([Companion_getInstance_4().s2t_1, Companion_getInstance_4().t2t_1, Companion_getInstance_4().u2t_1, Companion_getInstance_4().v2t_1, Companion_getInstance_4().w2t_1, Companion_getInstance_4().x2t_1, Companion_getInstance_4().y2t_1, Companion_getInstance_4().z2t_1, Companion_getInstance_4().a2u_1, Companion_getInstance_4().b2u_1, Companion_getInstance_4().c2u_1, Companion_getInstance_4().d2u_1, Companion_getInstance_4().e2u_1, Companion_getInstance_4().f2u_1, Companion_getInstance_4().g2u_1, Companion_getInstance_4().h2u_1, Companion_getInstance_4().i2u_1, Companion_getInstance_4().j2u_1, Companion_getInstance_4().k2u_1, Companion_getInstance_4().l2u_1, Companion_getInstance_4().m2u_1, Companion_getInstance_4().n2u_1, Companion_getInstance_4().o2u_1, Companion_getInstance_4().p2u_1, Companion_getInstance_4().q2u_1, Companion_getInstance_4().r2u_1, Companion_getInstance_4().s2u_1, Companion_getInstance_4().t2u_1, Companion_getInstance_4().u2u_1, Companion_getInstance_4().v2u_1, Companion_getInstance_4().w2u_1, Companion_getInstance_4().x2u_1, Companion_getInstance_4().y2u_1, Companion_getInstance_4().z2u_1, Companion_getInstance_4().a2v_1, Companion_getInstance_4().b2v_1, Companion_getInstance_4().c2v_1, Companion_getInstance_4().d2v_1, Companion_getInstance_4().e2v_1, Companion_getInstance_4().f2v_1, Companion_getInstance_4().g2v_1, Companion_getInstance_4().h2v_1, Companion_getInstance_4().i2v_1, Companion_getInstance_4().j2v_1, Companion_getInstance_4().k2v_1, Companion_getInstance_4().l2v_1, Companion_getInstance_4().m2v_1, Companion_getInstance_4().n2v_1, Companion_getInstance_4().o2v_1, Companion_getInstance_4().p2v_1, Companion_getInstance_4().q2v_1, Companion_getInstance_4().r2v_1, Companion_getInstance_4().s2v_1]);
}
function isSuccess(_this__u8e3s4) {
  var containsArg = _this__u8e3s4.v2v_1;
  return 200 <= containsArg ? containsArg < 300 : false;
}
var Companion_instance_5;
function Companion_getInstance_5() {
  if (Companion_instance_5 === VOID)
    new Companion_5();
  return Companion_instance_5;
}
var EmptyParameters_instance;
function EmptyParameters_getInstance() {
  return EmptyParameters_instance;
}
function ParametersBuilder(size) {
  size = size === VOID ? 8 : size;
  return new ParametersBuilderImpl(size);
}
function parseQueryString(query, startIndex, limit, decode) {
  startIndex = startIndex === VOID ? 0 : startIndex;
  limit = limit === VOID ? 1000 : limit;
  decode = decode === VOID ? true : decode;
  var tmp;
  if (startIndex > get_lastIndex_0(query)) {
    tmp = Companion_getInstance_5().y2v_1;
  } else {
    // Inline function 'io.ktor.http.Companion.build' call
    Companion_getInstance_5();
    // Inline function 'kotlin.apply' call
    var this_0 = ParametersBuilder();
    parse(this_0, query, startIndex, limit, decode);
    tmp = this_0.h2o();
  }
  return tmp;
}
function parse(_this__u8e3s4, query, startIndex, limit, decode) {
  var count = 0;
  var nameIndex = startIndex;
  var equalIndex = -1;
  var inductionVariable = startIndex;
  var last = get_lastIndex_0(query);
  if (inductionVariable <= last)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (count === limit) {
        return Unit_instance;
      }
      var tmp0_subject = charSequenceGet(query, index);
      if (tmp0_subject === _Char___init__impl__6a9atx(38)) {
        appendParam(_this__u8e3s4, query, nameIndex, equalIndex, index, decode);
        nameIndex = index + 1 | 0;
        equalIndex = -1;
        count = count + 1 | 0;
      } else if (tmp0_subject === _Char___init__impl__6a9atx(61)) {
        if (equalIndex === -1) {
          equalIndex = index;
        }
      }
    }
     while (!(index === last));
  if (count === limit) {
    return Unit_instance;
  }
  appendParam(_this__u8e3s4, query, nameIndex, equalIndex, query.length, decode);
}
function appendParam(_this__u8e3s4, query, nameIndex, equalIndex, endIndex, decode) {
  if (equalIndex === -1) {
    var spaceNameIndex = trimStart(nameIndex, endIndex, query);
    var spaceEndIndex = trimEnd(spaceNameIndex, endIndex, query);
    if (spaceEndIndex > spaceNameIndex) {
      var tmp;
      if (decode) {
        tmp = decodeURLQueryComponent(query, spaceNameIndex, spaceEndIndex);
      } else {
        // Inline function 'kotlin.text.substring' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp = query.substring(spaceNameIndex, spaceEndIndex);
      }
      var name = tmp;
      _this__u8e3s4.j2h(name, emptyList());
    }
    return Unit_instance;
  }
  var spaceNameIndex_0 = trimStart(nameIndex, equalIndex, query);
  var spaceEqualIndex = trimEnd(spaceNameIndex_0, equalIndex, query);
  if (spaceEqualIndex > spaceNameIndex_0) {
    var tmp_0;
    if (decode) {
      tmp_0 = decodeURLQueryComponent(query, spaceNameIndex_0, spaceEqualIndex);
    } else {
      // Inline function 'kotlin.text.substring' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp_0 = query.substring(spaceNameIndex_0, spaceEqualIndex);
    }
    var name_0 = tmp_0;
    var spaceValueIndex = trimStart(equalIndex + 1 | 0, endIndex, query);
    var spaceEndIndex_0 = trimEnd(spaceValueIndex, endIndex, query);
    var tmp_1;
    if (decode) {
      tmp_1 = decodeURLQueryComponent(query, spaceValueIndex, spaceEndIndex_0, true);
    } else {
      // Inline function 'kotlin.text.substring' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp_1 = query.substring(spaceValueIndex, spaceEndIndex_0);
    }
    var value = tmp_1;
    _this__u8e3s4.n2h(name_0, value);
  }
}
function trimStart(start, end, query) {
  var spaceIndex = start;
  while (spaceIndex < end && isWhitespace(charSequenceGet(query, spaceIndex))) {
    spaceIndex = spaceIndex + 1 | 0;
  }
  return spaceIndex;
}
function trimEnd(start, end, text) {
  var spaceIndex = end;
  while (spaceIndex > start && isWhitespace(charSequenceGet(text, spaceIndex - 1 | 0))) {
    spaceIndex = spaceIndex - 1 | 0;
  }
  return spaceIndex;
}
function applyOrigin($this) {
  var tmp;
  // Inline function 'kotlin.text.isNotEmpty' call
  var this_0 = $this.b2w_1;
  if (charSequenceLength(this_0) > 0) {
    tmp = true;
  } else {
    tmp = $this.n2w().l2w_1 === 'file';
  }
  if (tmp)
    return Unit_instance;
  $this.b2w_1 = Companion_getInstance_6().h2x_1.o2w_1;
  if ($this.e2w_1 == null)
    $this.e2w_1 = Companion_getInstance_6().h2x_1.z2w_1;
  if ($this.d2w_1 === 0) {
    $this.j2x(Companion_getInstance_6().h2x_1.p2w_1);
  }
}
var Companion_instance_6;
function Companion_getInstance_6() {
  if (Companion_instance_6 === VOID)
    new Companion_6();
  return Companion_instance_6;
}
function get_authority(_this__u8e3s4) {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  this_0.tb(get_encodedUserAndPassword(_this__u8e3s4));
  this_0.tb(_this__u8e3s4.b2w_1);
  if (!(_this__u8e3s4.d2w_1 === 0) && !(_this__u8e3s4.d2w_1 === _this__u8e3s4.n2w().m2w_1)) {
    this_0.tb(':');
    this_0.tb(_this__u8e3s4.d2w_1.toString());
  }
  return this_0.toString();
}
function appendTo(_this__u8e3s4, out) {
  out.w(_this__u8e3s4.n2w().l2w_1);
  switch (_this__u8e3s4.n2w().l2w_1) {
    case 'file':
      appendFile(out, _this__u8e3s4.b2w_1, get_encodedPath(_this__u8e3s4));
      return out;
    case 'mailto':
      appendMailto(out, get_encodedUserAndPassword(_this__u8e3s4), _this__u8e3s4.b2w_1);
      return out;
    case 'about':
      appendPayload(out, _this__u8e3s4.b2w_1);
      return out;
    case 'tel':
      appendPayload(out, _this__u8e3s4.b2w_1);
      return out;
    case 'data':
      appendPayload(out, _this__u8e3s4.b2w_1);
      return out;
  }
  out.w('://');
  out.w(get_authority(_this__u8e3s4));
  appendUrlFullPath(out, get_encodedPath(_this__u8e3s4), _this__u8e3s4.j2w_1, _this__u8e3s4.c2w_1);
  // Inline function 'kotlin.text.isNotEmpty' call
  var this_0 = _this__u8e3s4.h2w_1;
  if (charSequenceLength(this_0) > 0) {
    out.ub(_Char___init__impl__6a9atx(35));
    out.w(_this__u8e3s4.h2w_1);
  }
  return out;
}
function get_encodedUserAndPassword(_this__u8e3s4) {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  appendUserAndPassword(this_0, _this__u8e3s4.f2w_1, _this__u8e3s4.g2w_1);
  return this_0.toString();
}
function appendFile(_this__u8e3s4, host, encodedPath) {
  _this__u8e3s4.w('://');
  _this__u8e3s4.w(host);
  if (!startsWith_0(encodedPath, _Char___init__impl__6a9atx(47))) {
    _this__u8e3s4.ub(_Char___init__impl__6a9atx(47));
  }
  _this__u8e3s4.w(encodedPath);
}
function set_encodedPath(_this__u8e3s4, value) {
  _this__u8e3s4.i2w_1 = isBlank(value) ? emptyList() : value === '/' ? get_ROOT_PATH() : toMutableList(split(value, charArrayOf([_Char___init__impl__6a9atx(47)])));
}
function get_encodedPath(_this__u8e3s4) {
  return joinPath(_this__u8e3s4.i2w_1);
}
function appendMailto(_this__u8e3s4, encodedUser, host) {
  _this__u8e3s4.w(':');
  _this__u8e3s4.w(encodedUser);
  _this__u8e3s4.w(host);
}
function appendPayload(_this__u8e3s4, host) {
  _this__u8e3s4.w(':');
  _this__u8e3s4.w(host);
}
function joinPath(_this__u8e3s4) {
  if (_this__u8e3s4.h1())
    return '';
  if (_this__u8e3s4.b1() === 1) {
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = first_0(_this__u8e3s4);
    if (charSequenceLength(this_0) === 0)
      return '/';
    return first_0(_this__u8e3s4);
  }
  return joinToString(_this__u8e3s4, '/');
}
function get_ROOT_PATH() {
  _init_properties_URLParser_kt__sf11to();
  return ROOT_PATH;
}
var ROOT_PATH;
function takeFrom(_this__u8e3s4, urlString) {
  _init_properties_URLParser_kt__sf11to();
  if (isBlank(urlString))
    return _this__u8e3s4;
  var tmp;
  try {
    tmp = takeFromUnsafe(_this__u8e3s4, urlString);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var cause = $p;
      throw URLParserException.c2y(urlString, cause);
    } else {
      throw $p;
    }
  }
  return tmp;
}
function takeFromUnsafe(_this__u8e3s4, urlString) {
  _init_properties_URLParser_kt__sf11to();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.text.indexOfFirst' call
    var inductionVariable = 0;
    var last = charSequenceLength(urlString) - 1 | 0;
    if (inductionVariable <= last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var it = charSequenceGet(urlString, index);
        if (!isWhitespace(it)) {
          tmp$ret$1 = index;
          break $l$block;
        }
      }
       while (inductionVariable <= last);
    tmp$ret$1 = -1;
  }
  var startIndex = tmp$ret$1;
  var tmp$ret$3;
  $l$block_0: {
    // Inline function 'kotlin.text.indexOfLast' call
    var inductionVariable_0 = charSequenceLength(urlString) - 1 | 0;
    if (0 <= inductionVariable_0)
      do {
        var index_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + -1 | 0;
        var it_0 = charSequenceGet(urlString, index_0);
        if (!isWhitespace(it_0)) {
          tmp$ret$3 = index_0;
          break $l$block_0;
        }
      }
       while (0 <= inductionVariable_0);
    tmp$ret$3 = -1;
  }
  var endIndex = tmp$ret$3 + 1 | 0;
  var schemeLength = findScheme(urlString, startIndex, endIndex);
  if (schemeLength > 0) {
    var tmp5 = startIndex;
    // Inline function 'kotlin.text.substring' call
    var endIndex_0 = startIndex + schemeLength | 0;
    // Inline function 'kotlin.js.asDynamic' call
    var scheme = urlString.substring(tmp5, endIndex_0);
    _this__u8e3s4.k2x(Companion_getInstance_7().d2y(scheme));
    startIndex = startIndex + (schemeLength + 1 | 0) | 0;
  }
  if (_this__u8e3s4.n2w().l2w_1 === 'data') {
    var tmp = _this__u8e3s4;
    // Inline function 'kotlin.text.substring' call
    var startIndex_0 = startIndex;
    // Inline function 'kotlin.js.asDynamic' call
    tmp.b2w_1 = urlString.substring(startIndex_0, endIndex);
    return _this__u8e3s4;
  }
  var slashCount = count(urlString, startIndex, endIndex, _Char___init__impl__6a9atx(47));
  startIndex = startIndex + slashCount | 0;
  if (_this__u8e3s4.n2w().l2w_1 === 'file') {
    parseFile(_this__u8e3s4, urlString, startIndex, endIndex, slashCount);
    return _this__u8e3s4;
  }
  if (_this__u8e3s4.n2w().l2w_1 === 'mailto') {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(slashCount === 0)) {
      var message = 'Failed requirement.';
      throw IllegalArgumentException.t(toString(message));
    }
    parseMailto(_this__u8e3s4, urlString, startIndex, endIndex);
    return _this__u8e3s4;
  }
  if (_this__u8e3s4.n2w().l2w_1 === 'about') {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(slashCount === 0)) {
      var message_0 = 'Failed requirement.';
      throw IllegalArgumentException.t(toString(message_0));
    }
    var tmp_0 = _this__u8e3s4;
    // Inline function 'kotlin.text.substring' call
    var startIndex_1 = startIndex;
    // Inline function 'kotlin.js.asDynamic' call
    tmp_0.b2w_1 = urlString.substring(startIndex_1, endIndex);
    return _this__u8e3s4;
  }
  if (_this__u8e3s4.n2w().l2w_1 === 'tel') {
    // Inline function 'kotlin.require' call
    // Inline function 'kotlin.require' call
    if (!(slashCount === 0)) {
      var message_1 = 'Failed requirement.';
      throw IllegalArgumentException.t(toString(message_1));
    }
    var tmp_1 = _this__u8e3s4;
    // Inline function 'kotlin.text.substring' call
    var startIndex_2 = startIndex;
    // Inline function 'kotlin.js.asDynamic' call
    tmp_1.b2w_1 = urlString.substring(startIndex_2, endIndex);
    return _this__u8e3s4;
  }
  if (slashCount >= 2) {
    loop: while (true) {
      // Inline function 'kotlin.takeIf' call
      var this_0 = indexOfAny(urlString, toCharArray('@/\\?#'), startIndex);
      var tmp_2;
      if (this_0 > 0) {
        tmp_2 = this_0;
      } else {
        tmp_2 = null;
      }
      var tmp0_elvis_lhs = tmp_2;
      var delimiter = tmp0_elvis_lhs == null ? endIndex : tmp0_elvis_lhs;
      if (delimiter < endIndex && charSequenceGet(urlString, delimiter) === _Char___init__impl__6a9atx(64)) {
        var passwordIndex = indexOfColonInHostPort(urlString, startIndex, delimiter);
        if (!(passwordIndex === -1)) {
          var tmp_3 = _this__u8e3s4;
          // Inline function 'kotlin.text.substring' call
          var startIndex_3 = startIndex;
          // Inline function 'kotlin.js.asDynamic' call
          tmp_3.f2w_1 = urlString.substring(startIndex_3, passwordIndex);
          var tmp_4 = _this__u8e3s4;
          // Inline function 'kotlin.text.substring' call
          var startIndex_4 = passwordIndex + 1 | 0;
          // Inline function 'kotlin.js.asDynamic' call
          tmp_4.g2w_1 = urlString.substring(startIndex_4, delimiter);
        } else {
          var tmp_5 = _this__u8e3s4;
          // Inline function 'kotlin.text.substring' call
          var startIndex_5 = startIndex;
          // Inline function 'kotlin.js.asDynamic' call
          tmp_5.f2w_1 = urlString.substring(startIndex_5, delimiter);
        }
        startIndex = delimiter + 1 | 0;
      } else {
        fillHost(_this__u8e3s4, urlString, startIndex, delimiter);
        startIndex = delimiter;
        break loop;
      }
    }
  }
  if (startIndex >= endIndex) {
    _this__u8e3s4.i2w_1 = charSequenceGet(urlString, endIndex - 1 | 0) === _Char___init__impl__6a9atx(47) ? get_ROOT_PATH() : emptyList();
    return _this__u8e3s4;
  }
  var tmp_6 = _this__u8e3s4;
  var tmp_7;
  if (slashCount === 0) {
    tmp_7 = dropLast(_this__u8e3s4.i2w_1, 1);
  } else {
    tmp_7 = emptyList();
  }
  tmp_6.i2w_1 = tmp_7;
  // Inline function 'kotlin.takeIf' call
  var this_1 = indexOfAny(urlString, toCharArray('?#'), startIndex);
  var tmp_8;
  if (this_1 > 0) {
    tmp_8 = this_1;
  } else {
    tmp_8 = null;
  }
  var tmp1_elvis_lhs = tmp_8;
  var pathEnd = tmp1_elvis_lhs == null ? endIndex : tmp1_elvis_lhs;
  if (pathEnd > startIndex) {
    // Inline function 'kotlin.text.substring' call
    var startIndex_6 = startIndex;
    // Inline function 'kotlin.js.asDynamic' call
    var rawPath = urlString.substring(startIndex_6, pathEnd);
    var tmp_9;
    var tmp_10;
    if (_this__u8e3s4.i2w_1.b1() === 1) {
      // Inline function 'kotlin.text.isEmpty' call
      var this_2 = first_0(_this__u8e3s4.i2w_1);
      tmp_10 = charSequenceLength(this_2) === 0;
    } else {
      tmp_10 = false;
    }
    if (tmp_10) {
      tmp_9 = emptyList();
    } else {
      tmp_9 = _this__u8e3s4.i2w_1;
    }
    var basePath = tmp_9;
    var rawChunks = rawPath === '/' ? get_ROOT_PATH() : split(rawPath, charArrayOf([_Char___init__impl__6a9atx(47)]));
    var relativePath = plus_0(slashCount === 1 ? get_ROOT_PATH() : emptyList(), rawChunks);
    _this__u8e3s4.i2w_1 = plus_0(basePath, relativePath);
    startIndex = pathEnd;
  }
  if (startIndex < endIndex && charSequenceGet(urlString, startIndex) === _Char___init__impl__6a9atx(63)) {
    startIndex = parseQuery(_this__u8e3s4, urlString, startIndex, endIndex);
  }
  parseFragment(_this__u8e3s4, urlString, startIndex, endIndex);
  return _this__u8e3s4;
}
function findScheme(urlString, startIndex, endIndex) {
  _init_properties_URLParser_kt__sf11to();
  var current = startIndex;
  var incorrectSchemePosition = -1;
  var firstChar = charSequenceGet(urlString, current);
  if (!(_Char___init__impl__6a9atx(97) <= firstChar ? firstChar <= _Char___init__impl__6a9atx(122) : false) && !(_Char___init__impl__6a9atx(65) <= firstChar ? firstChar <= _Char___init__impl__6a9atx(90) : false)) {
    incorrectSchemePosition = current;
  }
  while (current < endIndex) {
    var char = charSequenceGet(urlString, current);
    if (char === _Char___init__impl__6a9atx(58)) {
      if (!(incorrectSchemePosition === -1)) {
        throw IllegalArgumentException.t('Illegal character in scheme at position ' + incorrectSchemePosition);
      }
      return current - startIndex | 0;
    }
    if (char === _Char___init__impl__6a9atx(47) || char === _Char___init__impl__6a9atx(63) || char === _Char___init__impl__6a9atx(35))
      return -1;
    if (incorrectSchemePosition === -1 && !(_Char___init__impl__6a9atx(97) <= char ? char <= _Char___init__impl__6a9atx(122) : false) && !(_Char___init__impl__6a9atx(65) <= char ? char <= _Char___init__impl__6a9atx(90) : false) && !(_Char___init__impl__6a9atx(48) <= char ? char <= _Char___init__impl__6a9atx(57) : false) && !(char === _Char___init__impl__6a9atx(46)) && !(char === _Char___init__impl__6a9atx(43)) && !(char === _Char___init__impl__6a9atx(45))) {
      incorrectSchemePosition = current;
    }
    current = current + 1 | 0;
  }
  return -1;
}
function count(urlString, startIndex, endIndex, char) {
  _init_properties_URLParser_kt__sf11to();
  var result = 0;
  $l$loop: while ((startIndex + result | 0) < endIndex && charSequenceGet(urlString, startIndex + result | 0) === char) {
    result = result + 1 | 0;
  }
  return result;
}
function parseFile(_this__u8e3s4, urlString, startIndex, endIndex, slashCount) {
  _init_properties_URLParser_kt__sf11to();
  switch (slashCount) {
    case 1:
      _this__u8e3s4.b2w_1 = '';
      // Inline function 'kotlin.text.substring' call

      // Inline function 'kotlin.js.asDynamic' call

      var tmp$ret$1 = urlString.substring(startIndex, endIndex);
      set_encodedPath(_this__u8e3s4, tmp$ret$1);
      break;
    case 2:
      var nextSlash = indexOf(urlString, _Char___init__impl__6a9atx(47), startIndex);
      if (nextSlash === -1 || nextSlash === endIndex) {
        var tmp = _this__u8e3s4;
        // Inline function 'kotlin.text.substring' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp.b2w_1 = urlString.substring(startIndex, endIndex);
        return Unit_instance;
      }

      var tmp_0 = _this__u8e3s4;
      // Inline function 'kotlin.text.substring' call

      // Inline function 'kotlin.js.asDynamic' call

      tmp_0.b2w_1 = urlString.substring(startIndex, nextSlash);
      // Inline function 'kotlin.text.substring' call

      // Inline function 'kotlin.js.asDynamic' call

      var tmp$ret$7 = urlString.substring(nextSlash, endIndex);
      set_encodedPath(_this__u8e3s4, tmp$ret$7);
      break;
    case 3:
      _this__u8e3s4.b2w_1 = '';
      // Inline function 'kotlin.text.substring' call

      // Inline function 'kotlin.js.asDynamic' call

      var tmp$ret$9 = urlString.substring(startIndex, endIndex);
      set_encodedPath(_this__u8e3s4, '/' + tmp$ret$9);
      break;
    default:
      throw IllegalArgumentException.t('Invalid file url: ' + urlString);
  }
}
function parseMailto(_this__u8e3s4, urlString, startIndex, endIndex) {
  _init_properties_URLParser_kt__sf11to();
  var delimiter = indexOf_0(urlString, '@', startIndex);
  if (delimiter === -1) {
    throw IllegalArgumentException.t('Invalid mailto url: ' + urlString + ", it should contain '@'.");
  }
  // Inline function 'kotlin.text.substring' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$1 = urlString.substring(startIndex, delimiter);
  _this__u8e3s4.r2x(decodeURLPart(tmp$ret$1));
  var tmp = _this__u8e3s4;
  // Inline function 'kotlin.text.substring' call
  var startIndex_0 = delimiter + 1 | 0;
  // Inline function 'kotlin.js.asDynamic' call
  tmp.b2w_1 = urlString.substring(startIndex_0, endIndex);
}
function indexOfColonInHostPort(_this__u8e3s4, startIndex, endIndex) {
  _init_properties_URLParser_kt__sf11to();
  var skip = false;
  var inductionVariable = startIndex;
  if (inductionVariable < endIndex)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp0_subject = charSequenceGet(_this__u8e3s4, index);
      if (tmp0_subject === _Char___init__impl__6a9atx(91))
        skip = true;
      else if (tmp0_subject === _Char___init__impl__6a9atx(93))
        skip = false;
      else if (tmp0_subject === _Char___init__impl__6a9atx(58))
        if (!skip)
          return index;
    }
     while (inductionVariable < endIndex);
  return -1;
}
function fillHost(_this__u8e3s4, urlString, startIndex, endIndex) {
  _init_properties_URLParser_kt__sf11to();
  // Inline function 'kotlin.takeIf' call
  var this_0 = indexOfColonInHostPort(urlString, startIndex, endIndex);
  var tmp;
  if (this_0 > 0) {
    tmp = this_0;
  } else {
    tmp = null;
  }
  var tmp0_elvis_lhs = tmp;
  var colonIndex = tmp0_elvis_lhs == null ? endIndex : tmp0_elvis_lhs;
  var tmp_0 = _this__u8e3s4;
  // Inline function 'kotlin.text.substring' call
  // Inline function 'kotlin.js.asDynamic' call
  tmp_0.b2w_1 = urlString.substring(startIndex, colonIndex);
  var tmp_1;
  if ((colonIndex + 1 | 0) < endIndex) {
    // Inline function 'kotlin.text.substring' call
    var startIndex_0 = colonIndex + 1 | 0;
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$5 = urlString.substring(startIndex_0, endIndex);
    tmp_1 = toInt(tmp$ret$5);
  } else {
    tmp_1 = 0;
  }
  _this__u8e3s4.j2x(tmp_1);
}
function parseQuery(_this__u8e3s4, urlString, startIndex, endIndex) {
  _init_properties_URLParser_kt__sf11to();
  if ((startIndex + 1 | 0) === endIndex) {
    _this__u8e3s4.c2w_1 = true;
    return endIndex;
  }
  // Inline function 'kotlin.takeIf' call
  var this_0 = indexOf(urlString, _Char___init__impl__6a9atx(35), startIndex + 1 | 0);
  var tmp;
  if (this_0 > 0) {
    tmp = this_0;
  } else {
    tmp = null;
  }
  var tmp0_elvis_lhs = tmp;
  var fragmentStart = tmp0_elvis_lhs == null ? endIndex : tmp0_elvis_lhs;
  // Inline function 'kotlin.text.substring' call
  var startIndex_0 = startIndex + 1 | 0;
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$3 = urlString.substring(startIndex_0, fragmentStart);
  var rawParameters = parseQueryString(tmp$ret$3, VOID, VOID, false);
  rawParameters.f2h(parseQuery$lambda(_this__u8e3s4));
  return fragmentStart;
}
function parseFragment(_this__u8e3s4, urlString, startIndex, endIndex) {
  _init_properties_URLParser_kt__sf11to();
  if (startIndex < endIndex && charSequenceGet(urlString, startIndex) === _Char___init__impl__6a9atx(35)) {
    var tmp = _this__u8e3s4;
    // Inline function 'kotlin.text.substring' call
    var startIndex_0 = startIndex + 1 | 0;
    // Inline function 'kotlin.js.asDynamic' call
    tmp.h2w_1 = urlString.substring(startIndex_0, endIndex);
  }
}
function parseQuery$lambda($this_parseQuery) {
  return (key, values) => {
    $this_parseQuery.j2w_1.j2h(key, values);
    return Unit_instance;
  };
}
var properties_initialized_URLParser_kt_hd1g6a;
function _init_properties_URLParser_kt__sf11to() {
  if (!properties_initialized_URLParser_kt_hd1g6a) {
    properties_initialized_URLParser_kt_hd1g6a = true;
    ROOT_PATH = listOf_0('');
  }
}
var Companion_instance_7;
function Companion_getInstance_7() {
  if (Companion_instance_7 === VOID)
    new Companion_7();
  return Companion_instance_7;
}
function isSecure(_this__u8e3s4) {
  return _this__u8e3s4.l2w_1 === 'https' || _this__u8e3s4.l2w_1 === 'wss';
}
function isWebsocket(_this__u8e3s4) {
  return _this__u8e3s4.l2w_1 === 'ws' || _this__u8e3s4.l2w_1 === 'wss';
}
function takeFrom_0(_this__u8e3s4, url) {
  _this__u8e3s4.e2w_1 = url.e2w_1;
  _this__u8e3s4.b2w_1 = url.b2w_1;
  _this__u8e3s4.j2x(url.d2w_1);
  _this__u8e3s4.i2w_1 = url.i2w_1;
  _this__u8e3s4.f2w_1 = url.f2w_1;
  _this__u8e3s4.g2w_1 = url.g2w_1;
  // Inline function 'kotlin.apply' call
  var this_0 = ParametersBuilder();
  appendAll(this_0, url.j2w_1);
  _this__u8e3s4.w2x(this_0);
  _this__u8e3s4.h2w_1 = url.h2w_1;
  _this__u8e3s4.c2w_1 = url.c2w_1;
  return _this__u8e3s4;
}
function get_hostWithPortIfSpecified(_this__u8e3s4) {
  var tmp0_subject = _this__u8e3s4.p2w_1;
  return tmp0_subject === 0 || tmp0_subject === _this__u8e3s4.a2x_1.m2w_1 ? _this__u8e3s4.o2w_1 : get_hostWithPort(_this__u8e3s4);
}
function Url_0(urlString) {
  return URLBuilder_0(urlString).h2o();
}
function appendUserAndPassword(_this__u8e3s4, encodedUser, encodedPassword) {
  if (encodedUser == null) {
    return Unit_instance;
  }
  _this__u8e3s4.tb(encodedUser);
  if (!(encodedPassword == null)) {
    _this__u8e3s4.ub(_Char___init__impl__6a9atx(58));
    _this__u8e3s4.tb(encodedPassword);
  }
  _this__u8e3s4.tb('@');
}
function appendUrlFullPath(_this__u8e3s4, encodedPath, encodedQueryParameters, trailingQuery) {
  var tmp;
  // Inline function 'kotlin.text.isNotBlank' call
  if (!isBlank(encodedPath)) {
    tmp = !startsWith_1(encodedPath, '/');
  } else {
    tmp = false;
  }
  if (tmp) {
    _this__u8e3s4.ub(_Char___init__impl__6a9atx(47));
  }
  _this__u8e3s4.w(encodedPath);
  if (!encodedQueryParameters.h1() || trailingQuery) {
    _this__u8e3s4.w('?');
  }
  // Inline function 'kotlin.collections.flatMap' call
  var tmp0 = encodedQueryParameters.e2h();
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = tmp0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var key = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var value = element.n1();
    var tmp_0;
    if (value.h1()) {
      tmp_0 = listOf_0(to(key, null));
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination_0 = ArrayList.x(collectionSizeOrDefault(value, 10));
      var _iterator__ex2g4s_0 = value.y();
      while (_iterator__ex2g4s_0.z()) {
        var item = _iterator__ex2g4s_0.a1();
        var tmp$ret$3 = to(key, item);
        destination_0.l(tmp$ret$3);
      }
      tmp_0 = destination_0;
    }
    var list = tmp_0;
    addAll(destination, list);
  }
  var tmp_1 = destination;
  joinTo(tmp_1, _this__u8e3s4, '&', VOID, VOID, VOID, VOID, appendUrlFullPath$lambda);
}
function get_hostWithPort(_this__u8e3s4) {
  return _this__u8e3s4.o2w_1 + ':' + _this__u8e3s4.e2y();
}
function URLBuilder_0(urlString) {
  return takeFrom(new URLBuilder(), urlString);
}
function URLBuilder_1(url) {
  return takeFrom_1(new URLBuilder(), url);
}
function takeFrom_1(_this__u8e3s4, url) {
  _this__u8e3s4.e2w_1 = url.z2w_1;
  _this__u8e3s4.b2w_1 = url.o2w_1;
  _this__u8e3s4.j2x(url.e2y());
  set_encodedPath(_this__u8e3s4, url.f2y());
  _this__u8e3s4.f2w_1 = url.g2y();
  _this__u8e3s4.g2w_1 = url.h2y();
  // Inline function 'kotlin.apply' call
  var this_0 = ParametersBuilder();
  this_0.o2h(parseQueryString(url.i2y(), VOID, VOID, false));
  _this__u8e3s4.w2x(this_0);
  _this__u8e3s4.h2w_1 = url.j2y();
  _this__u8e3s4.c2w_1 = url.u2w_1;
  return _this__u8e3s4;
}
function appendUrlFullPath$lambda(it) {
  var key = it.rl_1;
  var tmp;
  if (it.sl_1 == null) {
    tmp = key;
  } else {
    var value = toString_1(it.sl_1);
    tmp = key + '=' + value;
  }
  return tmp;
}
var Companion_instance_8;
function Companion_getInstance_8() {
  return Companion_instance_8;
}
function Url$segments$delegate$lambda($pathSegments) {
  return () => {
    var tmp;
    if ($pathSegments.h1()) {
      return emptyList();
    }
    var tmp_0;
    var tmp_1;
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = first_0($pathSegments);
    if (charSequenceLength(this_0) === 0) {
      tmp_1 = $pathSegments.b1() > 1;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = 1;
    } else {
      tmp_0 = 0;
    }
    var start = tmp_0;
    var tmp_2;
    // Inline function 'kotlin.text.isEmpty' call
    var this_1 = last($pathSegments);
    if (charSequenceLength(this_1) === 0) {
      tmp_2 = get_lastIndex($pathSegments);
    } else {
      tmp_2 = get_lastIndex($pathSegments) + 1 | 0;
    }
    var end = tmp_2;
    return $pathSegments.y2(start, end);
  };
}
function Url$encodedPath$delegate$lambda($pathSegments, this$0) {
  return () => {
    var tmp;
    if ($pathSegments.h1()) {
      return '';
    }
    var pathStartIndex = indexOf(this$0.v2w_1, _Char___init__impl__6a9atx(47), this$0.a2x_1.l2w_1.length + 3 | 0);
    var tmp_0;
    if (pathStartIndex === -1) {
      return '';
    }
    // Inline function 'kotlin.charArrayOf' call
    var tmp$ret$0 = charArrayOf([_Char___init__impl__6a9atx(63), _Char___init__impl__6a9atx(35)]);
    var pathEndIndex = indexOfAny(this$0.v2w_1, tmp$ret$0, pathStartIndex);
    var tmp_1;
    if (pathEndIndex === -1) {
      // Inline function 'kotlin.text.substring' call
      // Inline function 'kotlin.js.asDynamic' call
      return this$0.v2w_1.substring(pathStartIndex);
    }
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    return this$0.v2w_1.substring(pathStartIndex, pathEndIndex);
  };
}
function Url$encodedQuery$delegate$lambda(this$0) {
  return () => {
    var queryStart = indexOf(this$0.v2w_1, _Char___init__impl__6a9atx(63)) + 1 | 0;
    var tmp;
    if (queryStart === 0) {
      return '';
    }
    var queryEnd = indexOf(this$0.v2w_1, _Char___init__impl__6a9atx(35), queryStart);
    var tmp_0;
    if (queryEnd === -1) {
      // Inline function 'kotlin.text.substring' call
      // Inline function 'kotlin.js.asDynamic' call
      return this$0.v2w_1.substring(queryStart);
    }
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    return this$0.v2w_1.substring(queryStart, queryEnd);
  };
}
function Url$encodedPathAndQuery$delegate$lambda(this$0) {
  return () => {
    var pathStart = indexOf(this$0.v2w_1, _Char___init__impl__6a9atx(47), this$0.a2x_1.l2w_1.length + 3 | 0);
    var tmp;
    if (pathStart === -1) {
      return '';
    }
    var queryEnd = indexOf(this$0.v2w_1, _Char___init__impl__6a9atx(35), pathStart);
    var tmp_0;
    if (queryEnd === -1) {
      // Inline function 'kotlin.text.substring' call
      // Inline function 'kotlin.js.asDynamic' call
      return this$0.v2w_1.substring(pathStart);
    }
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    return this$0.v2w_1.substring(pathStart, queryEnd);
  };
}
function Url$encodedUser$delegate$lambda(this$0) {
  return () => {
    var tmp;
    if (this$0.s2w_1 == null) {
      return null;
    }
    var tmp_0;
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = this$0.s2w_1;
    if (charSequenceLength(this_0) === 0) {
      return '';
    }
    var usernameStart = this$0.a2x_1.l2w_1.length + 3 | 0;
    // Inline function 'kotlin.charArrayOf' call
    var tmp$ret$1 = charArrayOf([_Char___init__impl__6a9atx(58), _Char___init__impl__6a9atx(64)]);
    var usernameEnd = indexOfAny(this$0.v2w_1, tmp$ret$1, usernameStart);
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    return this$0.v2w_1.substring(usernameStart, usernameEnd);
  };
}
function Url$encodedPassword$delegate$lambda(this$0) {
  return () => {
    var tmp;
    if (this$0.t2w_1 == null) {
      return null;
    }
    var tmp_0;
    // Inline function 'kotlin.text.isEmpty' call
    var this_0 = this$0.t2w_1;
    if (charSequenceLength(this_0) === 0) {
      return '';
    }
    var passwordStart = indexOf(this$0.v2w_1, _Char___init__impl__6a9atx(58), this$0.a2x_1.l2w_1.length + 3 | 0) + 1 | 0;
    var passwordEnd = indexOf(this$0.v2w_1, _Char___init__impl__6a9atx(64));
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    return this$0.v2w_1.substring(passwordStart, passwordEnd);
  };
}
function Url$encodedFragment$delegate$lambda(this$0) {
  return () => {
    var fragmentStart = indexOf(this$0.v2w_1, _Char___init__impl__6a9atx(35)) + 1 | 0;
    var tmp;
    if (fragmentStart === 0) {
      return '';
    }
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    return this$0.v2w_1.substring(fragmentStart);
  };
}
function get_authority_0(_this__u8e3s4) {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  this_0.tb(get_encodedUserAndPassword_0(_this__u8e3s4));
  this_0.tb(get_hostWithPortIfSpecified(_this__u8e3s4));
  return this_0.toString();
}
var UrlSerializer_instance;
function UrlSerializer_getInstance() {
  if (UrlSerializer_instance === VOID)
    new UrlSerializer();
  return UrlSerializer_instance;
}
function get_encodedUserAndPassword_0(_this__u8e3s4) {
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  appendUserAndPassword(this_0, _this__u8e3s4.g2y(), _this__u8e3s4.h2y());
  return this_0.toString();
}
function encodedPath$factory() {
  return getPropertyCallableRef('encodedPath', 1, KProperty1, (receiver) => receiver.f2y(), null);
}
function encodedQuery$factory() {
  return getPropertyCallableRef('encodedQuery', 1, KProperty1, (receiver) => receiver.i2y(), null);
}
function encodedUser$factory() {
  return getPropertyCallableRef('encodedUser', 1, KProperty1, (receiver) => receiver.g2y(), null);
}
function encodedPassword$factory() {
  return getPropertyCallableRef('encodedPassword', 1, KProperty1, (receiver) => receiver.h2y(), null);
}
function encodedFragment$factory() {
  return getPropertyCallableRef('encodedFragment', 1, KProperty1, (receiver) => receiver.j2y(), null);
}
function encodeParameters(parameters) {
  // Inline function 'kotlin.apply' call
  var this_0 = ParametersBuilder();
  appendAllEncoded(this_0, parameters);
  return this_0;
}
function decodeParameters(parameters) {
  // Inline function 'kotlin.apply' call
  var this_0 = ParametersBuilder();
  appendAllDecoded(this_0, parameters);
  return this_0.h2o();
}
function appendAllEncoded(_this__u8e3s4, parameters) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = parameters.d2h().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp0_elvis_lhs = parameters.c2h(element);
    var values = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
    var tmp = encodeURLParameter(element);
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(values, 10));
    var _iterator__ex2g4s_0 = values.y();
    while (_iterator__ex2g4s_0.z()) {
      var item = _iterator__ex2g4s_0.a1();
      var tmp$ret$0 = encodeURLParameterValue(item);
      destination.l(tmp$ret$0);
    }
    _this__u8e3s4.j2h(tmp, destination);
  }
}
function appendAllDecoded(_this__u8e3s4, parameters) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = parameters.d2h().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp0_elvis_lhs = parameters.c2h(element);
    var values = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
    var tmp = decodeURLQueryComponent(element);
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(values, 10));
    var _iterator__ex2g4s_0 = values.y();
    while (_iterator__ex2g4s_0.z()) {
      var item = _iterator__ex2g4s_0.a1();
      var tmp$ret$0 = decodeURLQueryComponent(item, VOID, VOID, true);
      destination.l(tmp$ret$0);
    }
    _this__u8e3s4.j2h(tmp, destination);
  }
}
var NullBody_instance;
function NullBody_getInstance() {
  return NullBody_instance;
}
function isEmpty(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof NoContent) {
    tmp = true;
  } else {
    if (_this__u8e3s4 instanceof ContentWrapper) {
      tmp = isEmpty(_this__u8e3s4.z2y());
    } else {
      tmp = false;
    }
  }
  return tmp;
}
function get_origin(_this__u8e3s4) {
  return PlatformUtils_getInstance().t2g_1 ? locationOrigin() : 'http://localhost';
}
function locationOrigin() {
  return function () {
    var tmpLocation = null;
    if (typeof window !== 'undefined') {
      tmpLocation = window.location;
    } else if (typeof self !== 'undefined') {
      tmpLocation = self.location;
    }
    var origin = '';
    if (tmpLocation) {
      origin = tmpLocation.origin;
    }
    return origin && origin != 'null' ? origin : 'http://localhost';
  }();
}
//region block: post-declaration
initMetadataForClass(URLDecodeException, 'URLDecodeException');
initMetadataForCompanion(Companion);
initMetadataForObject(Application, 'Application');
initMetadataForObject(MultiPart, 'MultiPart');
initMetadataForObject(Text, 'Text');
initMetadataForClass(HeaderValueWithParameters, 'HeaderValueWithParameters');
initMetadataForClass(ContentType, 'ContentType');
initMetadataForClass(BadContentTypeFormatException, 'BadContentTypeFormatException');
initMetadataForCompanion(Companion_0);
initMetadataForCompanion(Companion_1);
initMetadataForClass(HeadersBuilder, 'HeadersBuilder', HeadersBuilder);
protoOf(EmptyHeaders).w2f = get;
protoOf(EmptyHeaders).f2h = forEach;
initMetadataForObject(EmptyHeaders, 'EmptyHeaders', VOID, VOID, [StringValues]);
initMetadataForClass(HeadersImpl, 'HeadersImpl', HeadersImpl, VOID, [StringValues, StringValuesImpl]);
initMetadataForClass(HeadersSingleImpl, 'HeadersSingleImpl', VOID, VOID, [StringValues, StringValuesSingleImpl]);
initMetadataForClass(HeaderValueParam, 'HeaderValueParam');
initMetadataForClass(HeaderValue, 'HeaderValue');
initMetadataForObject(HttpHeaders, 'HttpHeaders');
initMetadataForClass(IllegalHeaderNameException, 'IllegalHeaderNameException');
initMetadataForClass(IllegalHeaderValueException, 'IllegalHeaderValueException');
initMetadataForClass(UnsafeHeaderException, 'UnsafeHeaderException');
initMetadataForCompanion(Companion_2);
initMetadataForClass(HttpMethod, 'HttpMethod');
initMetadataForCompanion(Companion_3);
initMetadataForClass(HttpProtocolVersion, 'HttpProtocolVersion');
initMetadataForCompanion(Companion_4);
initMetadataForClass(HttpStatusCode, 'HttpStatusCode', VOID, VOID, [Comparable]);
initMetadataForCompanion(Companion_5);
initMetadataForInterface(Parameters, 'Parameters', VOID, VOID, [StringValues]);
protoOf(EmptyParameters).f2h = forEach;
initMetadataForObject(EmptyParameters, 'EmptyParameters', VOID, VOID, [Parameters]);
initMetadataForClass(ParametersBuilderImpl, 'ParametersBuilderImpl', ParametersBuilderImpl);
initMetadataForClass(ParametersImpl, 'ParametersImpl', ParametersImpl, VOID, [Parameters, StringValuesImpl]);
initMetadataForCompanion(Companion_6);
initMetadataForClass(URLBuilder, 'URLBuilder', URLBuilder);
initMetadataForClass(URLParserException, 'URLParserException');
initMetadataForCompanion(Companion_7);
initMetadataForClass(URLProtocol, 'URLProtocol');
initMetadataForCompanion(Companion_8);
initMetadataForClass(Url, 'Url', VOID, VOID, VOID, VOID, VOID, {0: UrlSerializer_getInstance});
initMetadataForObject(UrlSerializer, 'UrlSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(UrlDecodedParametersBuilder, 'UrlDecodedParametersBuilder');
initMetadataForInterface(MultiPartData, 'MultiPartData', VOID, VOID, VOID, [0]);
initMetadataForClass(OutgoingContent, 'OutgoingContent');
initMetadataForClass(NoContent, 'NoContent');
initMetadataForClass(ReadChannelContent, 'ReadChannelContent');
initMetadataForClass(WriteChannelContent, 'WriteChannelContent', VOID, VOID, VOID, [1]);
initMetadataForClass(ByteArrayContent, 'ByteArrayContent');
initMetadataForClass(ProtocolUpgrade, 'ProtocolUpgrade', VOID, VOID, VOID, [4]);
initMetadataForClass(ContentWrapper, 'ContentWrapper');
initMetadataForObject(NullBody, 'NullBody');
initMetadataForClass(TextContent, 'TextContent');
//endregion
//region block: init
Companion_instance_0 = new Companion_0();
EmptyHeaders_instance = new EmptyHeaders();
EmptyParameters_instance = new EmptyParameters();
Companion_instance_8 = new Companion_8();
NullBody_instance = new NullBody();
//endregion
//region block: exports
export {
  NullBody_instance as NullBody_instance9oj4j8z4op1j,
  Application_getInstance as Application_getInstance1d4ly18wdhadx,
  Companion_getInstance as Companion_getInstance2t5xhismubxj4,
  MultiPart_getInstance as MultiPart_getInstance2x0sgwr24mfqp,
  Text_getInstance as Text_getInstance3g3w54guxue7x,
  Companion_getInstance_1 as Companion_getInstance12n7p6s0jad4v,
  HttpHeaders_getInstance as HttpHeaders_getInstancekqele34vb34f,
  Companion_getInstance_2 as Companion_getInstancepumzx9q4106p,
  Companion_getInstance_3 as Companion_getInstance3s68g5cirsb1h,
  Companion_getInstance_4 as Companion_getInstancec9pdr3n9tfq9,
  MultiPartData as MultiPartData57syw40llxls,
  NullBody as NullBody1903zz7riiwr0,
  ByteArrayContent as ByteArrayContent2n0wb43y6ugs1,
  ContentWrapper as ContentWrapper3n9gdymgnbto9,
  NoContent as NoContent1bdx48poqrifq,
  ProtocolUpgrade as ProtocolUpgradexnnpt2xliy8g,
  ReadChannelContent as ReadChannelContentz1amb4hnpqp4,
  WriteChannelContent as WriteChannelContent1d7f40hsfcaxg,
  OutgoingContent as OutgoingContent3t2ohmyam9o76,
  TextContent as TextContent1rb6ftlpvl1d2,
  isEmpty as isEmpty1yq29t926r0va,
  HeadersBuilder as HeadersBuilder3h7sn3kkvu98m,
  HttpStatusCode as HttpStatusCode3o1wkms10pg4k,
  ParametersBuilder as ParametersBuilder1ry9ntvvg567r,
  URLBuilder_1 as URLBuilder1hwx1b9569i61,
  URLBuilder as URLBuilder2mz8zkz4u9ray,
  UnsafeHeaderException as UnsafeHeaderException3ncvrrp48xjzq,
  get_authority as get_authorityakhc3pgcrb9j,
  get_authority_0 as get_authority2s3hk87lssumy,
  charset_0 as charset3qqtyytkmxogi,
  charset as charset1dribv3ku48b1,
  contentLength as contentLength2suzxu1lzutku,
  contentType as contentType2zzm38yxo3syt,
  contentType_0 as contentType1lwcfjsjo0z8g,
  contentType_1 as contentType317fn4f991q9a,
  headersOf as headersOf2tgdoojg8tifn,
  isSecure as isSecurex1qiiavqi0xu,
  isSuccess as isSuccess1pokn37fdu56v,
  isWebsocket as isWebsocket1w1xog9vfgwm1,
  get_supportsRequestBody as get_supportsRequestBodyjdtitrt33hir,
  takeFrom_0 as takeFromkqlcz7c6dx2r,
  takeFrom as takeFrom3rd40szpqy350,
  withCharset as withCharset27k3t3dvzhi4n,
};
//endregion

//# sourceMappingURL=ktor-ktor-http.mjs.map
