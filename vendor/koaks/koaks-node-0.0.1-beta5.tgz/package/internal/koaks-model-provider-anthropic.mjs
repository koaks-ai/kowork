import {
  ChatModel1ekuxcd3gk3yy as ChatModel,
  Support_Unsupported_getInstance2l560r5zg87nd as Support_Unsupported_getInstance,
  Support_Supported_getInstance2iy50h3ebt6qe as Support_Supported_getInstance,
  ModelCapabilities1z2n3zkdibnvb as ModelCapabilities,
  JsonUtil_getInstance3itlrleq4m1cs as JsonUtil_getInstance,
  HttpMethod_POST_getInstance2vunzl2e30rwd as HttpMethod_POST_getInstance,
  authHeaders3pbiyo76b6dd9 as authHeaders,
  Framing_Sse_getInstance1id84wnv2jikt as Framing_Sse_getInstance,
  timeoutsvuf8aepeqg28 as timeouts,
  WireCall3namx761k5vmg as WireCall,
  Message1x6kaj8ypdoee as Message,
  Role_SYSTEM_getInstance3m9lasmspf7k5 as Role_SYSTEM_getInstance,
  ReasoningSummary2dl0lxzty5z0 as ReasoningSummary,
  ProviderItem17hp0vuxmlwze as ProviderItem,
  ToolCall27jatgdodcelb as ToolCall,
  Texttoggh19xftus as Text,
  Role_USER_getInstance1gsro7tt6a7i2 as Role_USER_getInstance,
  ToolResult2fndzcq38kgpy as ToolResult,
  Companion_getInstance3ot1bqjky10hu as Companion_getInstance,
  rawFor3526oyw9fazp7 as rawFor,
  _ItemRef___get_value__impl__fpjuyb3vqbahagzpip9 as _ItemRef___get_value__impl__fpjuyb,
  Role_ASSISTANT_getInstance3m8z8upy020dy as Role_ASSISTANT_getInstance,
  ensureDroppable3mu5lhcnsp146 as ensureDroppable,
  AgentFrameworkException23juzeg1t595u as AgentFrameworkException,
  PreparationError1mrn3vyzs5xe4 as PreparationError,
  Header291p2k6if4y3m as Header,
  ModelConfig4o28u6uqe7xk as ModelConfig,
  Support_Unknown_getInstance3blv79i14mlk4 as Support_Unknown_getInstance,
  Companion_instance13097inxmcdi as Companion_instance,
  Usage3sdv1daz6y20z as Usage,
  Failed2mkg32d93x5tt as Failed,
  Finished4z9e5g7v1wyk as Finished,
  HttpError1wj82nej166el as HttpError,
  Ndjson1kkk3x9modr28 as Ndjson,
  Body2ccosqk3y8ycb as Body,
  Sset7uvtqde4kyu as Sse,
  Companion_getInstance1u9wsm29ioh2k as Companion_getInstance_0,
  ProviderEventSource_HTTP_ERROR_getInstance3vqdfpfczozn6 as ProviderEventSource_HTTP_ERROR_getInstance,
  ProviderEventSource_NDJSON_getInstance77r5c8apmydv as ProviderEventSource_NDJSON_getInstance,
  ProviderEventSource_BODY_getInstance27y22y0ygedw8 as ProviderEventSource_BODY_getInstance,
  ProviderEventSource_SSE_getInstance2egxj3c7et7br as ProviderEventSource_SSE_getInstance,
  ProviderEvent1t0ljokdqil6g as ProviderEvent,
  EventDetail_SEMANTIC_getInstancegjhulsc99tvi as EventDetail_SEMANTIC_getInstance,
  EventDetail_LOSSLESS_getInstance3his02bn6fqrv as EventDetail_LOSSLESS_getInstance,
  ModelErrori9ofbqyilwwf as ModelError,
  Started1sf5a44qjgp0u as Started,
  TextDeltaq9h7728thclc as TextDelta,
  ReasoningKind_RAW_getInstance37w1uc2k0atvb as ReasoningKind_RAW_getInstance,
  ReasoningDeltaytmmln995w27 as ReasoningDelta,
  ToolCallDelta1owom9vbem28s as ToolCallDelta,
  ReplayPolicy_Required_getInstance1o7kby0tmyj43 as ReplayPolicy_Required_getInstance,
  ItemAddede8lfykdsw28t as ItemAdded,
  Companion_instancelgypg95btxw8 as Companion_instance_0,
  ProviderScopedId2kn7so5x8kdlf as ProviderScopedId,
  ToolCallsfyoaxshhyk as ToolCall_0,
  ToolCallCompleted225u0jsfjmco7 as ToolCallCompleted,
  Completedf7bahq5rqxjz as Completed,
} from './koaks-core.mjs';
import {
  VOID7hggqo3abtya as VOID,
  listOfNotNull1v4ggfackvuny as listOfNotNull,
  ArrayList3it5z8td81qkl as ArrayList,
  Unit_instance104q5opgivhr8 as Unit_instance,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  plus310ted5e4i90h as plus,
  joinToString1cxrrlmo0chqs as joinToString,
  isBlank1dvkhjjvox3p0 as isBlank,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  toString30pk9tzaqopn as toString,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  equals2au1ep9vhcato as equals,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  Companion_instance3fplhgf4ipvld as Companion_instance_1,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  toString1pkumu07cwy4m as toString_0,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  createThis2j2avj17cvnv2 as createThis,
  getKClass1s3j9wy1cofik as getKClass,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  Long2qws0ah9gnpki as Long,
  to2cs3ny02qtbcb as to,
  mapOf2zpbbmyqk8xpf as mapOf,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  trimEndvvzjdhan75g as trimEnd,
  endsWith3cq61xxngobwh as endsWith,
  StringBuildermazzzhj6kkai as StringBuilder,
  emptyList1g2z5xcrvp2zy as emptyList,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  listOfvhqybd2zx248 as listOf,
  _Result___get_isFailure__impl__jpirivzehaw445b0cy as _Result___get_isFailure__impl__jpiriv,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  isInterface3d6p8outrmvmk as isInterface,
  Comparator2b3maoeh98xtg as Comparator,
  compareValues1n2ayl87ihzfk as compareValues,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  firstOrNull1982767dljvdy as firstOrNull,
  sortedWith2csnbbb21k0lg as sortedWith,
  toList3jhuyej2anx2q as toList,
} from './kotlin-kotlin-stdlib.mjs';
import {
  ArrayListSerializer7k5wnrulb3y6 as ArrayListSerializer,
  StringSerializer_getInstance1k1oz5j50sfik as StringSerializer_getInstance,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  DoubleSerializer_getInstance2avi1jm48x8le as DoubleSerializer_getInstance,
  IntSerializer_getInstance9scrtcljaiv6 as IntSerializer_getInstance,
  UnknownFieldExceptiona60e3a6v1xqo as UnknownFieldException,
  get_nullable197rfua9r7fsz as get_nullable,
  BooleanSerializer_getInstancet3wtk7fl7i4f as BooleanSerializer_getInstance,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
  SealedClassSerializeriwipiibk55zc as SealedClassSerializer,
  SerializerFactory1qv9hivitncuv as SerializerFactory,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  JsonObjectSerializer_getInstance197qdg6ernwdp as JsonObjectSerializer_getInstance,
  JsonElementSerializer_getInstance1rgo1giz8g15y as JsonElementSerializer_getInstance,
  get_jsonObject2u4z2ch1uuca9 as get_jsonObject,
  JsonPrimitive3ttzjh2ft5dnx as JsonPrimitive,
  get_contentOrNull35s97cgi8z9eo as get_contentOrNull,
  get_longOrNull1kg1ha9scz5pa as get_longOrNull,
} from './kotlinx-serialization-kotlinx-serialization-json.mjs';
import { Companion_getInstance3n3majy04gpy as Companion_getInstance_1 } from './okio-parent-okio.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class AnthropicChatModel extends ChatModel {
  constructor(config, transport, params, capabilities) {
    params = params === VOID ? new AnthropicParams() : params;
    capabilities = capabilities === VOID ? new ModelCapabilities(VOID, VOID, Support_Unsupported_getInstance(), VOID, Support_Supported_getInstance()) : capabilities;
    super(config, transport);
    this.s7t_1 = params;
    this.t7t_1 = capabilities;
  }
  n5o() {
    return this.t7t_1;
  }
  j1s() {
    return new AnthropicWireDecoder();
  }
  n6h(request) {
    return new AnthropicWireDecoder(request.a5z_1);
  }
  s6h(req) {
    var body = JsonUtil_getInstance().m6g(this.u7t(req), Companion_getInstance_2().c3o());
    return new WireCall(HttpMethod_POST_getInstance(), this.l6h_1.w6h_1, authHeaders(this.l6h_1), body, Framing_Sse_getInstance(), req.z5y_1, timeouts(this.l6h_1), this.l6h_1.f6i_1, this.l6h_1.g6i_1);
  }
  u7t(req) {
    var tmp = listOfNotNull(req.u5y_1);
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = req.v5y_1;
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element instanceof Message) {
        destination.l(element);
      }
    }
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination_0 = ArrayList.k();
    var _iterator__ex2g4s_0 = destination.y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      if (element_0.e5o_1.equals(Role_SYSTEM_getInstance())) {
        destination_0.l(element_0);
      }
    }
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_1 = ArrayList.x(collectionSizeOrDefault(destination_0, 10));
    var _iterator__ex2g4s_1 = destination_0.y();
    while (_iterator__ex2g4s_1.z()) {
      var item = _iterator__ex2g4s_1.a1();
      var tmp$ret$5 = item.n5t();
      destination_1.l(tmp$ret$5);
    }
    // Inline function 'kotlin.text.ifBlank' call
    var this_0 = joinToString(plus(tmp, destination_1), '\n');
    var tmp_0;
    if (isBlank(this_0)) {
      tmp_0 = null;
    } else {
      tmp_0 = this_0;
    }
    var system = tmp_0;
    var tmp_1 = toAnthropicMessages(req.v5y_1);
    // Inline function 'kotlin.takeIf' call
    var this_1 = req.w5y_1;
    var tmp_2;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this_1.h1()) {
      tmp_2 = this_1;
    } else {
      tmp_2 = null;
    }
    var tmp0_safe_receiver = tmp_2;
    var tmp_3;
    if (tmp0_safe_receiver == null) {
      tmp_3 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination_2 = ArrayList.x(collectionSizeOrDefault(tmp0_safe_receiver, 10));
      var _iterator__ex2g4s_2 = tmp0_safe_receiver.y();
      while (_iterator__ex2g4s_2.z()) {
        var item_0 = _iterator__ex2g4s_2.a1();
        var tmp$ret$13 = new AnthropicTool(item_0.w6l_1, item_0.x6l_1, item_0.y6l_1);
        destination_2.l(tmp$ret$13);
      }
      tmp_3 = destination_2;
    }
    return new AnthropicChatRequest(this.l6h_1.y6h_1, this.s7t_1.w7t_1, tmp_1, system, tmp_3, true, this.s7t_1.x7t_1, this.s7t_1.y7t_1, this.s7t_1.z7t_1, this.s7t_1.a7u_1, this.s7t_1.b7u_1);
  }
}
class AnthropicParams {
  constructor(maxTokens, temperature, topP, topK, stopSequences, thinking) {
    maxTokens = maxTokens === VOID ? 4096 : maxTokens;
    temperature = temperature === VOID ? null : temperature;
    topP = topP === VOID ? null : topP;
    topK = topK === VOID ? null : topK;
    stopSequences = stopSequences === VOID ? null : stopSequences;
    thinking = thinking === VOID ? null : thinking;
    this.w7t_1 = maxTokens;
    this.x7t_1 = temperature;
    this.y7t_1 = topP;
    this.z7t_1 = topK;
    this.a7u_1 = stopSequences;
    this.b7u_1 = thinking;
  }
  toString() {
    return 'AnthropicParams(maxTokens=' + this.w7t_1 + ', temperature=' + this.x7t_1 + ', topP=' + this.y7t_1 + ', topK=' + this.z7t_1 + ', stopSequences=' + toString(this.a7u_1) + ', thinking=' + toString(this.b7u_1) + ')';
  }
  hashCode() {
    var result = this.w7t_1;
    result = imul(result, 31) + (this.x7t_1 == null ? 0 : getNumberHashCode(this.x7t_1)) | 0;
    result = imul(result, 31) + (this.y7t_1 == null ? 0 : getNumberHashCode(this.y7t_1)) | 0;
    result = imul(result, 31) + (this.z7t_1 == null ? 0 : this.z7t_1) | 0;
    result = imul(result, 31) + (this.a7u_1 == null ? 0 : hashCode(this.a7u_1)) | 0;
    result = imul(result, 31) + (this.b7u_1 == null ? 0 : this.b7u_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicParams))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicParams ? other : THROW_CCE();
    if (!(this.w7t_1 === tmp0_other_with_cast.w7t_1))
      return false;
    if (!equals(this.x7t_1, tmp0_other_with_cast.x7t_1))
      return false;
    if (!equals(this.y7t_1, tmp0_other_with_cast.y7t_1))
      return false;
    if (!(this.z7t_1 == tmp0_other_with_cast.z7t_1))
      return false;
    if (!equals(this.a7u_1, tmp0_other_with_cast.a7u_1))
      return false;
    if (!equals(this.b7u_1, tmp0_other_with_cast.b7u_1))
      return false;
    return true;
  }
}
class Companion {
  constructor() {
    Companion_instance_2 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_1 = lazy(tmp_0, AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r);
    var tmp_2 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_3 = lazy(tmp_2, AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r_0);
    var tmp_4 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.v7t_1 = [null, null, tmp_1, null, tmp_3, null, null, null, null, lazy(tmp_4, AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r_1), null];
  }
  c3o() {
    return $serializer_getInstance();
  }
}
class $serializer {
  constructor() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatRequest', this, 11);
    tmp0_serialDesc.f25('model', false);
    tmp0_serialDesc.f25('max_tokens', false);
    tmp0_serialDesc.f25('messages', false);
    tmp0_serialDesc.f25('system', true);
    tmp0_serialDesc.f25('tools', true);
    tmp0_serialDesc.f25('stream', true);
    tmp0_serialDesc.f25('temperature', true);
    tmp0_serialDesc.f25('top_p', true);
    tmp0_serialDesc.f25('top_k', true);
    tmp0_serialDesc.f25('stop_sequences', true);
    tmp0_serialDesc.f25('thinking', true);
    this.c7u_1 = tmp0_serialDesc;
  }
  d7u(encoder, value) {
    var tmp0_desc = this.c7u_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    var tmp2_cached = Companion_getInstance_2().v7t_1;
    tmp1_output.g1z(tmp0_desc, 0, value.e7u_1);
    tmp1_output.b1z(tmp0_desc, 1, value.f7u_1);
    tmp1_output.i1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.g7u_1);
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.h7u_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, StringSerializer_getInstance(), value.h7u_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.i7u_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 4, tmp2_cached[4].n1(), value.i7u_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 5) ? true : !(value.j7u_1 === true)) {
      tmp1_output.y1y(tmp0_desc, 5, value.j7u_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 6) ? true : !(value.k7u_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 6, DoubleSerializer_getInstance(), value.k7u_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 7) ? true : !(value.l7u_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 7, DoubleSerializer_getInstance(), value.l7u_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 8) ? true : !(value.m7u_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 8, IntSerializer_getInstance(), value.m7u_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 9) ? true : !(value.n7u_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 9, tmp2_cached[9].n1(), value.n7u_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 10) ? true : !(value.o7u_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 10, JsonObjectSerializer_getInstance(), value.o7u_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.d7u(encoder, value instanceof AnthropicChatRequest ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.c7u_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = 0;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_local5 = false;
    var tmp10_local6 = null;
    var tmp11_local7 = null;
    var tmp12_local8 = null;
    var tmp13_local9 = null;
    var tmp14_local10 = null;
    var tmp15_input = decoder.q1x(tmp0_desc);
    var tmp16_cached = Companion_getInstance_2().v7t_1;
    if (tmp15_input.g1y()) {
      tmp4_local0 = tmp15_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp15_input.v1x(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp15_input.c1y(tmp0_desc, 2, tmp16_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp15_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp15_input.e1y(tmp0_desc, 4, tmp16_cached[4].n1(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp15_input.s1x(tmp0_desc, 5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp15_input.e1y(tmp0_desc, 6, DoubleSerializer_getInstance(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
      tmp11_local7 = tmp15_input.e1y(tmp0_desc, 7, DoubleSerializer_getInstance(), tmp11_local7);
      tmp3_bitMask0 = tmp3_bitMask0 | 128;
      tmp12_local8 = tmp15_input.e1y(tmp0_desc, 8, IntSerializer_getInstance(), tmp12_local8);
      tmp3_bitMask0 = tmp3_bitMask0 | 256;
      tmp13_local9 = tmp15_input.e1y(tmp0_desc, 9, tmp16_cached[9].n1(), tmp13_local9);
      tmp3_bitMask0 = tmp3_bitMask0 | 512;
      tmp14_local10 = tmp15_input.e1y(tmp0_desc, 10, JsonObjectSerializer_getInstance(), tmp14_local10);
      tmp3_bitMask0 = tmp3_bitMask0 | 1024;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp15_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp15_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp15_input.v1x(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp15_input.c1y(tmp0_desc, 2, tmp16_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp15_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp15_input.e1y(tmp0_desc, 4, tmp16_cached[4].n1(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp15_input.s1x(tmp0_desc, 5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp15_input.e1y(tmp0_desc, 6, DoubleSerializer_getInstance(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          case 7:
            tmp11_local7 = tmp15_input.e1y(tmp0_desc, 7, DoubleSerializer_getInstance(), tmp11_local7);
            tmp3_bitMask0 = tmp3_bitMask0 | 128;
            break;
          case 8:
            tmp12_local8 = tmp15_input.e1y(tmp0_desc, 8, IntSerializer_getInstance(), tmp12_local8);
            tmp3_bitMask0 = tmp3_bitMask0 | 256;
            break;
          case 9:
            tmp13_local9 = tmp15_input.e1y(tmp0_desc, 9, tmp16_cached[9].n1(), tmp13_local9);
            tmp3_bitMask0 = tmp3_bitMask0 | 512;
            break;
          case 10:
            tmp14_local10 = tmp15_input.e1y(tmp0_desc, 10, JsonObjectSerializer_getInstance(), tmp14_local10);
            tmp3_bitMask0 = tmp3_bitMask0 | 1024;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp15_input.r1x(tmp0_desc);
    return AnthropicChatRequest.p7u(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, tmp12_local8, tmp13_local9, tmp14_local10, null);
  }
  h1t() {
    return this.c7u_1;
  }
  u25() {
    var tmp0_cached = Companion_getInstance_2().v7t_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), IntSerializer_getInstance(), tmp0_cached[2].n1(), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[4].n1()), BooleanSerializer_getInstance(), get_nullable(DoubleSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(tmp0_cached[9].n1()), get_nullable(JsonObjectSerializer_getInstance())];
  }
}
class AnthropicChatRequest {
  constructor(model, maxTokens, messages, system, tools, stream, temperature, topP, topK, stopSequences, thinking) {
    Companion_getInstance_2();
    system = system === VOID ? null : system;
    tools = tools === VOID ? null : tools;
    stream = stream === VOID ? true : stream;
    temperature = temperature === VOID ? null : temperature;
    topP = topP === VOID ? null : topP;
    topK = topK === VOID ? null : topK;
    stopSequences = stopSequences === VOID ? null : stopSequences;
    thinking = thinking === VOID ? null : thinking;
    this.e7u_1 = model;
    this.f7u_1 = maxTokens;
    this.g7u_1 = messages;
    this.h7u_1 = system;
    this.i7u_1 = tools;
    this.j7u_1 = stream;
    this.k7u_1 = temperature;
    this.l7u_1 = topP;
    this.m7u_1 = topK;
    this.n7u_1 = stopSequences;
    this.o7u_1 = thinking;
  }
  toString() {
    return 'AnthropicChatRequest(model=' + this.e7u_1 + ', maxTokens=' + this.f7u_1 + ', messages=' + toString_0(this.g7u_1) + ', system=' + this.h7u_1 + ', tools=' + toString(this.i7u_1) + ', stream=' + this.j7u_1 + ', temperature=' + this.k7u_1 + ', topP=' + this.l7u_1 + ', topK=' + this.m7u_1 + ', stopSequences=' + toString(this.n7u_1) + ', thinking=' + toString(this.o7u_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.e7u_1);
    result = imul(result, 31) + this.f7u_1 | 0;
    result = imul(result, 31) + hashCode(this.g7u_1) | 0;
    result = imul(result, 31) + (this.h7u_1 == null ? 0 : getStringHashCode(this.h7u_1)) | 0;
    result = imul(result, 31) + (this.i7u_1 == null ? 0 : hashCode(this.i7u_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.j7u_1) | 0;
    result = imul(result, 31) + (this.k7u_1 == null ? 0 : getNumberHashCode(this.k7u_1)) | 0;
    result = imul(result, 31) + (this.l7u_1 == null ? 0 : getNumberHashCode(this.l7u_1)) | 0;
    result = imul(result, 31) + (this.m7u_1 == null ? 0 : this.m7u_1) | 0;
    result = imul(result, 31) + (this.n7u_1 == null ? 0 : hashCode(this.n7u_1)) | 0;
    result = imul(result, 31) + (this.o7u_1 == null ? 0 : this.o7u_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicChatRequest))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicChatRequest ? other : THROW_CCE();
    if (!(this.e7u_1 === tmp0_other_with_cast.e7u_1))
      return false;
    if (!(this.f7u_1 === tmp0_other_with_cast.f7u_1))
      return false;
    if (!equals(this.g7u_1, tmp0_other_with_cast.g7u_1))
      return false;
    if (!(this.h7u_1 == tmp0_other_with_cast.h7u_1))
      return false;
    if (!equals(this.i7u_1, tmp0_other_with_cast.i7u_1))
      return false;
    if (!(this.j7u_1 === tmp0_other_with_cast.j7u_1))
      return false;
    if (!equals(this.k7u_1, tmp0_other_with_cast.k7u_1))
      return false;
    if (!equals(this.l7u_1, tmp0_other_with_cast.l7u_1))
      return false;
    if (!(this.m7u_1 == tmp0_other_with_cast.m7u_1))
      return false;
    if (!equals(this.n7u_1, tmp0_other_with_cast.n7u_1))
      return false;
    if (!equals(this.o7u_1, tmp0_other_with_cast.o7u_1))
      return false;
    return true;
  }
  static p7u(seen0, model, maxTokens, messages, system, tools, stream, temperature, topP, topK, stopSequences, thinking, serializationConstructorMarker) {
    Companion_getInstance_2();
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance().c7u_1);
    }
    var $this = createThis(this);
    $this.e7u_1 = model;
    $this.f7u_1 = maxTokens;
    $this.g7u_1 = messages;
    if (0 === (seen0 & 8))
      $this.h7u_1 = null;
    else
      $this.h7u_1 = system;
    if (0 === (seen0 & 16))
      $this.i7u_1 = null;
    else
      $this.i7u_1 = tools;
    if (0 === (seen0 & 32))
      $this.j7u_1 = true;
    else
      $this.j7u_1 = stream;
    if (0 === (seen0 & 64))
      $this.k7u_1 = null;
    else
      $this.k7u_1 = temperature;
    if (0 === (seen0 & 128))
      $this.l7u_1 = null;
    else
      $this.l7u_1 = topP;
    if (0 === (seen0 & 256))
      $this.m7u_1 = null;
    else
      $this.m7u_1 = topK;
    if (0 === (seen0 & 512))
      $this.n7u_1 = null;
    else
      $this.n7u_1 = stopSequences;
    if (0 === (seen0 & 1024))
      $this.o7u_1 = null;
    else
      $this.o7u_1 = thinking;
    return $this;
  }
}
class Companion_0 {
  constructor() {
    Companion_instance_3 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.q7u_1 = [null, lazy(tmp_0, AnthropicMessage$Companion$$childSerializers$_anonymous__qndbyp)];
  }
}
class $serializer_0 {
  constructor() {
    $serializer_instance_0 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicMessage', this, 2);
    tmp0_serialDesc.f25('role', false);
    tmp0_serialDesc.f25('content', false);
    this.r7u_1 = tmp0_serialDesc;
  }
  s7u(encoder, value) {
    var tmp0_desc = this.r7u_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    var tmp2_cached = Companion_getInstance_3().q7u_1;
    tmp1_output.g1z(tmp0_desc, 0, value.t7u_1);
    tmp1_output.i1z(tmp0_desc, 1, tmp2_cached[1].n1(), value.u7u_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.s7u(encoder, value instanceof AnthropicMessage ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.r7u_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    var tmp7_cached = Companion_getInstance_3().q7u_1;
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.c1y(tmp0_desc, 1, tmp7_cached[1].n1(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.c1y(tmp0_desc, 1, tmp7_cached[1].n1(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return AnthropicMessage.v7u(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.r7u_1;
  }
  u25() {
    var tmp0_cached = Companion_getInstance_3().q7u_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), tmp0_cached[1].n1()];
  }
}
class AnthropicMessage {
  constructor(role, content) {
    Companion_getInstance_3();
    this.t7u_1 = role;
    this.u7u_1 = content;
  }
  toString() {
    return 'AnthropicMessage(role=' + this.t7u_1 + ', content=' + toString_0(this.u7u_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.t7u_1);
    result = imul(result, 31) + hashCode(this.u7u_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicMessage))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicMessage ? other : THROW_CCE();
    if (!(this.t7u_1 === tmp0_other_with_cast.t7u_1))
      return false;
    if (!equals(this.u7u_1, tmp0_other_with_cast.u7u_1))
      return false;
    return true;
  }
  static v7u(seen0, role, content, serializationConstructorMarker) {
    Companion_getInstance_3();
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_0().r7u_1);
    }
    var $this = createThis(this);
    $this.t7u_1 = role;
    $this.u7u_1 = content;
    return $this;
  }
}
class Companion_1 {}
class $serializer_1 {
  constructor() {
    $serializer_instance_1 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicTool', this, 3);
    tmp0_serialDesc.f25('name', false);
    tmp0_serialDesc.f25('description', false);
    tmp0_serialDesc.f25('input_schema', false);
    this.w7u_1 = tmp0_serialDesc;
  }
  x7u(encoder, value) {
    var tmp0_desc = this.w7u_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.y7u_1);
    tmp1_output.g1z(tmp0_desc, 1, value.z7u_1);
    tmp1_output.i1z(tmp0_desc, 2, JsonObjectSerializer_getInstance(), value.a7v_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.x7u(encoder, value instanceof AnthropicTool ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.w7u_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return AnthropicTool.b7v(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.w7u_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), JsonObjectSerializer_getInstance()];
  }
}
class AnthropicTool {
  constructor(name, description, inputSchema) {
    this.y7u_1 = name;
    this.z7u_1 = description;
    this.a7v_1 = inputSchema;
  }
  toString() {
    return 'AnthropicTool(name=' + this.y7u_1 + ', description=' + this.z7u_1 + ', inputSchema=' + this.a7v_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.y7u_1);
    result = imul(result, 31) + getStringHashCode(this.z7u_1) | 0;
    result = imul(result, 31) + this.a7v_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicTool))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicTool ? other : THROW_CCE();
    if (!(this.y7u_1 === tmp0_other_with_cast.y7u_1))
      return false;
    if (!(this.z7u_1 === tmp0_other_with_cast.z7u_1))
      return false;
    if (!this.a7v_1.equals(tmp0_other_with_cast.a7v_1))
      return false;
    return true;
  }
  static b7v(seen0, name, description, inputSchema, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_1().w7u_1);
    }
    var $this = createThis(this);
    $this.y7u_1 = name;
    $this.z7u_1 = description;
    $this.a7v_1 = inputSchema;
    return $this;
  }
}
class Companion_2 {}
class $serializer_2 {
  constructor() {
    $serializer_instance_2 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('thinking', this, 2);
    tmp0_serialDesc.f25('thinking', false);
    tmp0_serialDesc.f25('signature', true);
    this.c7v_1 = tmp0_serialDesc;
  }
  d7v(encoder, value) {
    var tmp0_desc = this.c7v_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.e7v_1);
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.f7v_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.f7v_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.d7v(encoder, value instanceof Thinking ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.c7v_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return Thinking.g7v(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.c7v_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_3 {}
class $serializer_3 {
  constructor() {
    $serializer_instance_3 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('redacted_thinking', this, 1);
    tmp0_serialDesc.f25('data', false);
    this.h7v_1 = tmp0_serialDesc;
  }
  i7v(encoder, value) {
    var tmp0_desc = this.h7v_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.j7v_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.i7v(encoder, value instanceof RedactedThinking ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.h7v_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return RedactedThinking.k7v(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.h7v_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance()];
  }
}
class Companion_4 {}
class $serializer_4 {
  constructor() {
    $serializer_instance_4 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('text', this, 1);
    tmp0_serialDesc.f25('text', false);
    this.l7v_1 = tmp0_serialDesc;
  }
  m7v(encoder, value) {
    var tmp0_desc = this.l7v_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.n7v_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.m7v(encoder, value instanceof Text_0 ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.l7v_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.q1x(tmp0_desc);
    if (tmp5_input.g1y()) {
      tmp4_local0 = tmp5_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp5_input.r1x(tmp0_desc);
    return Text_0.o7v(tmp3_bitMask0, tmp4_local0, null);
  }
  h1t() {
    return this.l7v_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance()];
  }
}
class Companion_5 {}
class $serializer_5 {
  constructor() {
    $serializer_instance_5 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('tool_use', this, 3);
    tmp0_serialDesc.f25('id', false);
    tmp0_serialDesc.f25('name', false);
    tmp0_serialDesc.f25('input', false);
    this.p7v_1 = tmp0_serialDesc;
  }
  q7v(encoder, value) {
    var tmp0_desc = this.p7v_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.r7v_1);
    tmp1_output.g1z(tmp0_desc, 1, value.s7v_1);
    tmp1_output.i1z(tmp0_desc, 2, JsonElementSerializer_getInstance(), value.t7v_1);
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.q7v(encoder, value instanceof ToolUse ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.p7v_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, JsonElementSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.c1y(tmp0_desc, 2, JsonElementSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return ToolUse.u7v(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.p7v_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), JsonElementSerializer_getInstance()];
  }
}
class Companion_6 {}
class $serializer_6 {
  constructor() {
    $serializer_instance_6 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('tool_result', this, 3);
    tmp0_serialDesc.f25('tool_use_id', false);
    tmp0_serialDesc.f25('content', false);
    tmp0_serialDesc.f25('is_error', true);
    this.v7v_1 = tmp0_serialDesc;
  }
  w7v(encoder, value) {
    var tmp0_desc = this.v7v_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    tmp1_output.g1z(tmp0_desc, 0, value.x7v_1);
    tmp1_output.g1z(tmp0_desc, 1, value.y7v_1);
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.z7v_1 === false)) {
      tmp1_output.y1y(tmp0_desc, 2, value.z7v_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.w7v(encoder, value instanceof ToolResult_0 ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.v7v_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = false;
    var tmp7_input = decoder.q1x(tmp0_desc);
    if (tmp7_input.g1y()) {
      tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.s1x(tmp0_desc, 2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.a1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.a1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.s1x(tmp0_desc, 2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp7_input.r1x(tmp0_desc);
    return ToolResult_0.a7w(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  h1t() {
    return this.v7v_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), BooleanSerializer_getInstance()];
  }
}
class AnthropicContentBlock {}
class Thinking {
  constructor(thinking, signature) {
    signature = signature === VOID ? null : signature;
    this.e7v_1 = thinking;
    this.f7v_1 = signature;
  }
  toString() {
    return 'Thinking(thinking=' + this.e7v_1 + ', signature=' + this.f7v_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.e7v_1);
    result = imul(result, 31) + (this.f7v_1 == null ? 0 : getStringHashCode(this.f7v_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Thinking))
      return false;
    var tmp0_other_with_cast = other instanceof Thinking ? other : THROW_CCE();
    if (!(this.e7v_1 === tmp0_other_with_cast.e7v_1))
      return false;
    if (!(this.f7v_1 == tmp0_other_with_cast.f7v_1))
      return false;
    return true;
  }
  static g7v(seen0, thinking, signature, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_2().c7v_1);
    }
    var $this = createThis(this);
    $this.e7v_1 = thinking;
    if (0 === (seen0 & 2))
      $this.f7v_1 = null;
    else
      $this.f7v_1 = signature;
    return $this;
  }
}
class RedactedThinking {
  constructor(data) {
    this.j7v_1 = data;
  }
  toString() {
    return 'RedactedThinking(data=' + this.j7v_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.j7v_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RedactedThinking))
      return false;
    var tmp0_other_with_cast = other instanceof RedactedThinking ? other : THROW_CCE();
    if (!(this.j7v_1 === tmp0_other_with_cast.j7v_1))
      return false;
    return true;
  }
  static k7v(seen0, data, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_3().h7v_1);
    }
    var $this = createThis(this);
    $this.j7v_1 = data;
    return $this;
  }
}
class Text_0 {
  constructor(text) {
    this.n7v_1 = text;
  }
  toString() {
    return 'Text(text=' + this.n7v_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.n7v_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Text_0))
      return false;
    var tmp0_other_with_cast = other instanceof Text_0 ? other : THROW_CCE();
    if (!(this.n7v_1 === tmp0_other_with_cast.n7v_1))
      return false;
    return true;
  }
  static o7v(seen0, text, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_4().l7v_1);
    }
    var $this = createThis(this);
    $this.n7v_1 = text;
    return $this;
  }
}
class ToolUse {
  constructor(id, name, input) {
    this.r7v_1 = id;
    this.s7v_1 = name;
    this.t7v_1 = input;
  }
  toString() {
    return 'ToolUse(id=' + this.r7v_1 + ', name=' + this.s7v_1 + ', input=' + toString_0(this.t7v_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.r7v_1);
    result = imul(result, 31) + getStringHashCode(this.s7v_1) | 0;
    result = imul(result, 31) + hashCode(this.t7v_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolUse))
      return false;
    var tmp0_other_with_cast = other instanceof ToolUse ? other : THROW_CCE();
    if (!(this.r7v_1 === tmp0_other_with_cast.r7v_1))
      return false;
    if (!(this.s7v_1 === tmp0_other_with_cast.s7v_1))
      return false;
    if (!equals(this.t7v_1, tmp0_other_with_cast.t7v_1))
      return false;
    return true;
  }
  static u7v(seen0, id, name, input, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_5().p7v_1);
    }
    var $this = createThis(this);
    $this.r7v_1 = id;
    $this.s7v_1 = name;
    $this.t7v_1 = input;
    return $this;
  }
}
class ToolResult_0 {
  constructor(toolUseId, content, isError) {
    isError = isError === VOID ? false : isError;
    this.x7v_1 = toolUseId;
    this.y7v_1 = content;
    this.z7v_1 = isError;
  }
  toString() {
    return 'ToolResult(toolUseId=' + this.x7v_1 + ', content=' + this.y7v_1 + ', isError=' + this.z7v_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.x7v_1);
    result = imul(result, 31) + getStringHashCode(this.y7v_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.z7v_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolResult_0))
      return false;
    var tmp0_other_with_cast = other instanceof ToolResult_0 ? other : THROW_CCE();
    if (!(this.x7v_1 === tmp0_other_with_cast.x7v_1))
      return false;
    if (!(this.y7v_1 === tmp0_other_with_cast.y7v_1))
      return false;
    if (!(this.z7v_1 === tmp0_other_with_cast.z7v_1))
      return false;
    return true;
  }
  static a7w(seen0, toolUseId, content, isError, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_6().v7v_1);
    }
    var $this = createThis(this);
    $this.x7v_1 = toolUseId;
    $this.y7v_1 = content;
    if (0 === (seen0 & 4))
      $this.z7v_1 = false;
    else
      $this.z7v_1 = isError;
    return $this;
  }
}
class Companion_7 {
  c3o() {
    var tmp = getKClass(AnthropicContentBlock);
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = [getKClass(RedactedThinking), getKClass(Text_0), getKClass(Thinking), getKClass(ToolResult_0), getKClass(ToolUse)];
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_1 = [$serializer_getInstance_3(), $serializer_getInstance_4(), $serializer_getInstance_2(), $serializer_getInstance_6(), $serializer_getInstance_5()];
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$8 = [];
    return SealedClassSerializer.n1u('org.koaks.provider.anthropic.AnthropicContentBlock', tmp, tmp_0, tmp_1, tmp$ret$8);
  }
  g26(typeParamsSerializers) {
    return this.c3o();
  }
}
class Companion_8 {}
class $serializer_7 {
  constructor() {
    $serializer_instance_7 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.Message', this, 2);
    tmp0_serialDesc.f25('id', true);
    tmp0_serialDesc.f25('usage', true);
    this.b7w_1 = tmp0_serialDesc;
  }
  c7w(encoder, value) {
    var tmp0_desc = this.b7w_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.d7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.d7w_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.e7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, $serializer_getInstance_10(), value.e7w_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.c7w(encoder, value instanceof Message_0 ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.b7w_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, $serializer_getInstance_10(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, $serializer_getInstance_10(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return Message_0.f7w(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.b7w_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable($serializer_getInstance_10())];
  }
}
class Companion_9 {}
class $serializer_8 {
  constructor() {
    $serializer_instance_8 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.ContentBlock', this, 4);
    tmp0_serialDesc.f25('type', true);
    tmp0_serialDesc.f25('id', true);
    tmp0_serialDesc.f25('name', true);
    tmp0_serialDesc.f25('data', true);
    this.g7w_1 = tmp0_serialDesc;
  }
  h7w(encoder, value) {
    var tmp0_desc = this.g7w_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.i7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.i7w_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.j7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.j7w_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.k7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, StringSerializer_getInstance(), value.k7w_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.l7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, StringSerializer_getInstance(), value.l7w_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.h7w(encoder, value instanceof ContentBlock ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.g7w_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.q1x(tmp0_desc);
    if (tmp8_input.g1y()) {
      tmp4_local0 = tmp8_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp8_input.r1x(tmp0_desc);
    return ContentBlock.m7w(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  h1t() {
    return this.g7w_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_10 {}
class $serializer_9 {
  constructor() {
    $serializer_instance_9 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.Delta', this, 5);
    tmp0_serialDesc.f25('type', true);
    tmp0_serialDesc.f25('text', true);
    tmp0_serialDesc.f25('thinking', true);
    tmp0_serialDesc.f25('signature', true);
    tmp0_serialDesc.f25('partial_json', true);
    this.n7w_1 = tmp0_serialDesc;
  }
  o7w(encoder, value) {
    var tmp0_desc = this.n7w_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.p7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.p7w_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.q7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.q7w_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.r7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, StringSerializer_getInstance(), value.r7w_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.s7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, StringSerializer_getInstance(), value.s7w_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.t7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 4, StringSerializer_getInstance(), value.t7w_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.o7w(encoder, value instanceof Delta ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.n7w_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.q1x(tmp0_desc);
    if (tmp9_input.g1y()) {
      tmp4_local0 = tmp9_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.e1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.e1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.e1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp9_input.r1x(tmp0_desc);
    return Delta.u7w(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  h1t() {
    return this.n7w_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_11 {}
class $serializer_10 {
  constructor() {
    $serializer_instance_10 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.Usage', this, 2);
    tmp0_serialDesc.f25('input_tokens', true);
    tmp0_serialDesc.f25('output_tokens', true);
    this.v7w_1 = tmp0_serialDesc;
  }
  w7w(encoder, value) {
    var tmp0_desc = this.v7w_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.x7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, IntSerializer_getInstance(), value.x7w_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.y7w_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, IntSerializer_getInstance(), value.y7w_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.w7w(encoder, value instanceof Usage_0 ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.v7w_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return Usage_0.z7w(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.v7w_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance())];
  }
}
class Companion_12 {}
class $serializer_11 {
  constructor() {
    $serializer_instance_11 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.ErrorOutput', this, 2);
    tmp0_serialDesc.f25('type', true);
    tmp0_serialDesc.f25('message', true);
    this.a7x_1 = tmp0_serialDesc;
  }
  b7x(encoder, value) {
    var tmp0_desc = this.a7x_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.c7x_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.c7x_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.d7x_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, StringSerializer_getInstance(), value.d7x_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.b7x(encoder, value instanceof ErrorOutput ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.a7x_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.q1x(tmp0_desc);
    if (tmp6_input.g1y()) {
      tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.e1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp6_input.r1x(tmp0_desc);
    return ErrorOutput.e7x(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  h1t() {
    return this.a7x_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Message_0 {
  constructor(id, usage) {
    id = id === VOID ? null : id;
    usage = usage === VOID ? null : usage;
    this.d7w_1 = id;
    this.e7w_1 = usage;
  }
  toString() {
    return 'Message(id=' + this.d7w_1 + ', usage=' + toString(this.e7w_1) + ')';
  }
  hashCode() {
    var result = this.d7w_1 == null ? 0 : getStringHashCode(this.d7w_1);
    result = imul(result, 31) + (this.e7w_1 == null ? 0 : this.e7w_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Message_0))
      return false;
    var tmp0_other_with_cast = other instanceof Message_0 ? other : THROW_CCE();
    if (!(this.d7w_1 == tmp0_other_with_cast.d7w_1))
      return false;
    if (!equals(this.e7w_1, tmp0_other_with_cast.e7w_1))
      return false;
    return true;
  }
  static f7w(seen0, id, usage, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_7().b7w_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.d7w_1 = null;
    else
      $this.d7w_1 = id;
    if (0 === (seen0 & 2))
      $this.e7w_1 = null;
    else
      $this.e7w_1 = usage;
    return $this;
  }
}
class ContentBlock {
  constructor(type, id, name, data) {
    type = type === VOID ? null : type;
    id = id === VOID ? null : id;
    name = name === VOID ? null : name;
    data = data === VOID ? null : data;
    this.i7w_1 = type;
    this.j7w_1 = id;
    this.k7w_1 = name;
    this.l7w_1 = data;
  }
  toString() {
    return 'ContentBlock(type=' + this.i7w_1 + ', id=' + this.j7w_1 + ', name=' + this.k7w_1 + ', data=' + this.l7w_1 + ')';
  }
  hashCode() {
    var result = this.i7w_1 == null ? 0 : getStringHashCode(this.i7w_1);
    result = imul(result, 31) + (this.j7w_1 == null ? 0 : getStringHashCode(this.j7w_1)) | 0;
    result = imul(result, 31) + (this.k7w_1 == null ? 0 : getStringHashCode(this.k7w_1)) | 0;
    result = imul(result, 31) + (this.l7w_1 == null ? 0 : getStringHashCode(this.l7w_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ContentBlock))
      return false;
    var tmp0_other_with_cast = other instanceof ContentBlock ? other : THROW_CCE();
    if (!(this.i7w_1 == tmp0_other_with_cast.i7w_1))
      return false;
    if (!(this.j7w_1 == tmp0_other_with_cast.j7w_1))
      return false;
    if (!(this.k7w_1 == tmp0_other_with_cast.k7w_1))
      return false;
    if (!(this.l7w_1 == tmp0_other_with_cast.l7w_1))
      return false;
    return true;
  }
  static m7w(seen0, type, id, name, data, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_8().g7w_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.i7w_1 = null;
    else
      $this.i7w_1 = type;
    if (0 === (seen0 & 2))
      $this.j7w_1 = null;
    else
      $this.j7w_1 = id;
    if (0 === (seen0 & 4))
      $this.k7w_1 = null;
    else
      $this.k7w_1 = name;
    if (0 === (seen0 & 8))
      $this.l7w_1 = null;
    else
      $this.l7w_1 = data;
    return $this;
  }
}
class Delta {
  constructor(type, text, thinking, signature, partialJson) {
    type = type === VOID ? null : type;
    text = text === VOID ? null : text;
    thinking = thinking === VOID ? null : thinking;
    signature = signature === VOID ? null : signature;
    partialJson = partialJson === VOID ? null : partialJson;
    this.p7w_1 = type;
    this.q7w_1 = text;
    this.r7w_1 = thinking;
    this.s7w_1 = signature;
    this.t7w_1 = partialJson;
  }
  toString() {
    return 'Delta(type=' + this.p7w_1 + ', text=' + this.q7w_1 + ', thinking=' + this.r7w_1 + ', signature=' + this.s7w_1 + ', partialJson=' + this.t7w_1 + ')';
  }
  hashCode() {
    var result = this.p7w_1 == null ? 0 : getStringHashCode(this.p7w_1);
    result = imul(result, 31) + (this.q7w_1 == null ? 0 : getStringHashCode(this.q7w_1)) | 0;
    result = imul(result, 31) + (this.r7w_1 == null ? 0 : getStringHashCode(this.r7w_1)) | 0;
    result = imul(result, 31) + (this.s7w_1 == null ? 0 : getStringHashCode(this.s7w_1)) | 0;
    result = imul(result, 31) + (this.t7w_1 == null ? 0 : getStringHashCode(this.t7w_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Delta))
      return false;
    var tmp0_other_with_cast = other instanceof Delta ? other : THROW_CCE();
    if (!(this.p7w_1 == tmp0_other_with_cast.p7w_1))
      return false;
    if (!(this.q7w_1 == tmp0_other_with_cast.q7w_1))
      return false;
    if (!(this.r7w_1 == tmp0_other_with_cast.r7w_1))
      return false;
    if (!(this.s7w_1 == tmp0_other_with_cast.s7w_1))
      return false;
    if (!(this.t7w_1 == tmp0_other_with_cast.t7w_1))
      return false;
    return true;
  }
  static u7w(seen0, type, text, thinking, signature, partialJson, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_9().n7w_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.p7w_1 = null;
    else
      $this.p7w_1 = type;
    if (0 === (seen0 & 2))
      $this.q7w_1 = null;
    else
      $this.q7w_1 = text;
    if (0 === (seen0 & 4))
      $this.r7w_1 = null;
    else
      $this.r7w_1 = thinking;
    if (0 === (seen0 & 8))
      $this.s7w_1 = null;
    else
      $this.s7w_1 = signature;
    if (0 === (seen0 & 16))
      $this.t7w_1 = null;
    else
      $this.t7w_1 = partialJson;
    return $this;
  }
}
class Usage_0 {
  constructor(inputTokens, outputTokens) {
    inputTokens = inputTokens === VOID ? null : inputTokens;
    outputTokens = outputTokens === VOID ? null : outputTokens;
    this.x7w_1 = inputTokens;
    this.y7w_1 = outputTokens;
  }
  toString() {
    return 'Usage(inputTokens=' + this.x7w_1 + ', outputTokens=' + this.y7w_1 + ')';
  }
  hashCode() {
    var result = this.x7w_1 == null ? 0 : this.x7w_1;
    result = imul(result, 31) + (this.y7w_1 == null ? 0 : this.y7w_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Usage_0))
      return false;
    var tmp0_other_with_cast = other instanceof Usage_0 ? other : THROW_CCE();
    if (!(this.x7w_1 == tmp0_other_with_cast.x7w_1))
      return false;
    if (!(this.y7w_1 == tmp0_other_with_cast.y7w_1))
      return false;
    return true;
  }
  static z7w(seen0, inputTokens, outputTokens, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_10().v7w_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.x7w_1 = null;
    else
      $this.x7w_1 = inputTokens;
    if (0 === (seen0 & 2))
      $this.y7w_1 = null;
    else
      $this.y7w_1 = outputTokens;
    return $this;
  }
}
class ErrorOutput {
  constructor(type, message) {
    type = type === VOID ? null : type;
    message = message === VOID ? null : message;
    this.c7x_1 = type;
    this.d7x_1 = message;
  }
  toString() {
    return 'ErrorOutput(type=' + this.c7x_1 + ', message=' + this.d7x_1 + ')';
  }
  hashCode() {
    var result = this.c7x_1 == null ? 0 : getStringHashCode(this.c7x_1);
    result = imul(result, 31) + (this.d7x_1 == null ? 0 : getStringHashCode(this.d7x_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ErrorOutput))
      return false;
    var tmp0_other_with_cast = other instanceof ErrorOutput ? other : THROW_CCE();
    if (!(this.c7x_1 == tmp0_other_with_cast.c7x_1))
      return false;
    if (!(this.d7x_1 == tmp0_other_with_cast.d7x_1))
      return false;
    return true;
  }
  static e7x(seen0, type, message, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_11().a7x_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.c7x_1 = null;
    else
      $this.c7x_1 = type;
    if (0 === (seen0 & 2))
      $this.d7x_1 = null;
    else
      $this.d7x_1 = message;
    return $this;
  }
}
class Companion_13 {
  c3o() {
    return $serializer_getInstance_12();
  }
}
class $serializer_12 {
  constructor() {
    $serializer_instance_12 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse', this, 7);
    tmp0_serialDesc.f25('type', true);
    tmp0_serialDesc.f25('index', true);
    tmp0_serialDesc.f25('message', true);
    tmp0_serialDesc.f25('content_block', true);
    tmp0_serialDesc.f25('delta', true);
    tmp0_serialDesc.f25('usage', true);
    tmp0_serialDesc.f25('error', true);
    this.f7x_1 = tmp0_serialDesc;
  }
  g7x(encoder, value) {
    var tmp0_desc = this.f7x_1;
    var tmp1_output = encoder.q1x(tmp0_desc);
    if (tmp1_output.o1z(tmp0_desc, 0) ? true : !(value.h7x_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 0, StringSerializer_getInstance(), value.h7x_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 1) ? true : !(value.i7x_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 1, IntSerializer_getInstance(), value.i7x_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 2) ? true : !(value.j7x_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 2, $serializer_getInstance_7(), value.j7x_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 3) ? true : !(value.k7x_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 3, $serializer_getInstance_8(), value.k7x_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 4) ? true : !(value.l7x_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 4, $serializer_getInstance_9(), value.l7x_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 5) ? true : !(value.m7x_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 5, $serializer_getInstance_10(), value.m7x_1);
    }
    if (tmp1_output.o1z(tmp0_desc, 6) ? true : !(value.n7x_1 == null)) {
      tmp1_output.k1z(tmp0_desc, 6, $serializer_getInstance_11(), value.n7x_1);
    }
    tmp1_output.r1x(tmp0_desc);
  }
  i1t(encoder, value) {
    return this.g7x(encoder, value instanceof AnthropicChatResponse ? value : THROW_CCE());
  }
  j1t(decoder) {
    var tmp0_desc = this.f7x_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_local5 = null;
    var tmp10_local6 = null;
    var tmp11_input = decoder.q1x(tmp0_desc);
    if (tmp11_input.g1y()) {
      tmp4_local0 = tmp11_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp11_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp11_input.e1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp11_input.e1y(tmp0_desc, 3, $serializer_getInstance_8(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp11_input.e1y(tmp0_desc, 4, $serializer_getInstance_9(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp11_input.e1y(tmp0_desc, 5, $serializer_getInstance_10(), tmp9_local5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp11_input.e1y(tmp0_desc, 6, $serializer_getInstance_11(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp11_input.h1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp11_input.e1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp11_input.e1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp11_input.e1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp11_input.e1y(tmp0_desc, 3, $serializer_getInstance_8(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp11_input.e1y(tmp0_desc, 4, $serializer_getInstance_9(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp11_input.e1y(tmp0_desc, 5, $serializer_getInstance_10(), tmp9_local5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp11_input.e1y(tmp0_desc, 6, $serializer_getInstance_11(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          default:
            throw UnknownFieldException.k1v(tmp2_index);
        }
      }
    tmp11_input.r1x(tmp0_desc);
    return AnthropicChatResponse.o7x(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, null);
  }
  h1t() {
    return this.f7x_1;
  }
  u25() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable($serializer_getInstance_7()), get_nullable($serializer_getInstance_8()), get_nullable($serializer_getInstance_9()), get_nullable($serializer_getInstance_10()), get_nullable($serializer_getInstance_11())];
  }
}
class AnthropicChatResponse {
  constructor(type, index, message, contentBlock, delta, usage, error) {
    type = type === VOID ? null : type;
    index = index === VOID ? null : index;
    message = message === VOID ? null : message;
    contentBlock = contentBlock === VOID ? null : contentBlock;
    delta = delta === VOID ? null : delta;
    usage = usage === VOID ? null : usage;
    error = error === VOID ? null : error;
    this.h7x_1 = type;
    this.i7x_1 = index;
    this.j7x_1 = message;
    this.k7x_1 = contentBlock;
    this.l7x_1 = delta;
    this.m7x_1 = usage;
    this.n7x_1 = error;
  }
  toString() {
    return 'AnthropicChatResponse(type=' + this.h7x_1 + ', index=' + this.i7x_1 + ', message=' + toString(this.j7x_1) + ', contentBlock=' + toString(this.k7x_1) + ', delta=' + toString(this.l7x_1) + ', usage=' + toString(this.m7x_1) + ', error=' + toString(this.n7x_1) + ')';
  }
  hashCode() {
    var result = this.h7x_1 == null ? 0 : getStringHashCode(this.h7x_1);
    result = imul(result, 31) + (this.i7x_1 == null ? 0 : this.i7x_1) | 0;
    result = imul(result, 31) + (this.j7x_1 == null ? 0 : this.j7x_1.hashCode()) | 0;
    result = imul(result, 31) + (this.k7x_1 == null ? 0 : this.k7x_1.hashCode()) | 0;
    result = imul(result, 31) + (this.l7x_1 == null ? 0 : this.l7x_1.hashCode()) | 0;
    result = imul(result, 31) + (this.m7x_1 == null ? 0 : this.m7x_1.hashCode()) | 0;
    result = imul(result, 31) + (this.n7x_1 == null ? 0 : this.n7x_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicChatResponse))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicChatResponse ? other : THROW_CCE();
    if (!(this.h7x_1 == tmp0_other_with_cast.h7x_1))
      return false;
    if (!(this.i7x_1 == tmp0_other_with_cast.i7x_1))
      return false;
    if (!equals(this.j7x_1, tmp0_other_with_cast.j7x_1))
      return false;
    if (!equals(this.k7x_1, tmp0_other_with_cast.k7x_1))
      return false;
    if (!equals(this.l7x_1, tmp0_other_with_cast.l7x_1))
      return false;
    if (!equals(this.m7x_1, tmp0_other_with_cast.m7x_1))
      return false;
    if (!equals(this.n7x_1, tmp0_other_with_cast.n7x_1))
      return false;
    return true;
  }
  static o7x(seen0, type, index, message, contentBlock, delta, usage, error, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_12().f7x_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.h7x_1 = null;
    else
      $this.h7x_1 = type;
    if (0 === (seen0 & 2))
      $this.i7x_1 = null;
    else
      $this.i7x_1 = index;
    if (0 === (seen0 & 4))
      $this.j7x_1 = null;
    else
      $this.j7x_1 = message;
    if (0 === (seen0 & 8))
      $this.k7x_1 = null;
    else
      $this.k7x_1 = contentBlock;
    if (0 === (seen0 & 16))
      $this.l7x_1 = null;
    else
      $this.l7x_1 = delta;
    if (0 === (seen0 & 32))
      $this.m7x_1 = null;
    else
      $this.m7x_1 = usage;
    if (0 === (seen0 & 64))
      $this.n7x_1 = null;
    else
      $this.n7x_1 = error;
    return $this;
  }
}
class AnthropicConfig {
  constructor(baseUrl, apiKey, modelName) {
    this.p7x_1 = baseUrl;
    this.q7x_1 = apiKey;
    this.r7x_1 = modelName;
    this.s7x_1 = 4096;
    this.t7x_1 = null;
    this.u7x_1 = null;
    this.v7x_1 = null;
    this.w7x_1 = null;
    this.x7x_1 = null;
    this.y7x_1 = '2023-06-01';
    this.z7x_1 = new Long(60000, 0);
    this.a7y_1 = new ModelCapabilities(VOID, VOID, Support_Unsupported_getInstance(), VOID, Support_Supported_getInstance());
  }
  e7y(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new AnthropicCapabilitiesScope(this.a7y_1);
    block(this_0);
    tmp.a7y_1 = this_0.j7y();
  }
  b7y() {
    return new ModelConfig(normalizeAnthropicMessagesUrl(this.p7x_1), this.q7x_1, this.r7x_1, new Header('x-api-key'), mapOf(to('anthropic-version', this.y7x_1)), VOID, VOID, VOID, this.z7x_1);
  }
  c7y() {
    return new AnthropicParams(this.s7x_1, this.t7x_1, this.u7x_1, this.v7x_1, this.w7x_1, this.x7x_1);
  }
  d7y() {
    return this.a7y_1;
  }
}
class AnthropicCapabilitiesScope {
  constructor(initial) {
    this.f7y_1 = initial.i5o_1.equals(Support_Supported_getInstance());
    this.g7y_1 = initial.j5o_1.equals(Support_Supported_getInstance());
    this.h7y_1 = initial.k5o_1.equals(Support_Supported_getInstance());
    this.i7y_1 = initial.m5o_1.equals(Support_Supported_getInstance());
  }
  j7y() {
    return new ModelCapabilities(this.f7y_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), this.g7y_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.h7y_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), VOID, this.i7y_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance());
  }
}
class ToolAcc {
  constructor(id, name, args, ref) {
    args = args === VOID ? StringBuilder.v() : args;
    ref = ref === VOID ? Companion_instance.f61('call') : ref;
    this.k7y_1 = id;
    this.l7y_1 = name;
    this.m7y_1 = args;
    this.n7y_1 = ref;
  }
}
class ThinkingAcc {
  constructor(text, signature, redacted, kind, ref) {
    text = text === VOID ? StringBuilder.v() : text;
    signature = signature === VOID ? StringBuilder.v() : signature;
    redacted = redacted === VOID ? null : redacted;
    ref = ref === VOID ? Companion_instance.f61('think') : ref;
    this.o7y_1 = text;
    this.p7y_1 = signature;
    this.q7y_1 = redacted;
    this.r7y_1 = kind;
    this.s7y_1 = ref;
  }
}
class sam$kotlin_Comparator$0 {
  constructor(function_0) {
    this.f7z_1 = function_0;
  }
  vi(a, b) {
    return this.f7z_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.f7z_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class AnthropicWireDecoder {
  constructor(eventDetail) {
    eventDetail = eventDetail === VOID ? EventDetail_SEMANTIC_getInstance() : eventDetail;
    this.t7y_1 = eventDetail;
    this.u7y_1 = LinkedHashMap.hc();
    this.v7y_1 = LinkedHashMap.hc();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.w7y_1 = ArrayList.k();
    this.x7y_1 = StringBuilder.v();
    this.y7y_1 = Companion_instance.f61('msg');
    this.z7y_1 = 0;
    this.a7z_1 = 0;
    this.b7z_1 = 0;
    this.c7z_1 = null;
    this.d7z_1 = false;
    this.e7z_1 = false;
  }
  i6h(frame) {
    var raw = this.t7y_1.equals(EventDetail_LOSSLESS_getInstance()) ? listOf(providerEvent(this, frame)) : emptyList();
    var tmp;
    if (frame instanceof Sse) {
      tmp = frame.y6n_1;
    } else {
      if (frame instanceof Body) {
        tmp = frame.b6o_1;
      } else {
        if (frame instanceof Ndjson) {
          tmp = frame.c6o_1;
        } else {
          if (frame instanceof HttpError) {
            this.c7z_1 = new ModelError('HTTP ' + frame.c6n_1 + ': ' + frame.e6n_1, frame.c6n_1 >= 500);
            return plus(raw, finishFailed(this));
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
    var json = tmp;
    if (isBlank(json))
      return raw;
    // Inline function 'kotlin.runCatching' call
    var tmp_0;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = JsonUtil_getInstance().n6g(json, Companion_instance_16.c3o());
      tmp_0 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_1;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    // Inline function 'kotlin.getOrElse' call
    var this_0 = tmp_0;
    var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
    var tmp_2;
    if (exception == null) {
      var tmp_3 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_2 = (tmp_3 == null ? true : !(tmp_3 == null)) ? tmp_3 : THROW_CCE();
    } else {
      return raw;
    }
    var chunk = tmp_2;
    return plus(raw, this.g7z(chunk));
  }
  g7z(chunk) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    if (!this.e7z_1) {
      this.e7z_1 = true;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = new Started(null);
      events.l(element);
    }
    switch (chunk.h7x_1) {
      case 'error':
        var tmp = this;
        var tmp1_safe_receiver = chunk.n7x_1;
        var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.d7x_1;
        var tmp_0;
        if (tmp2_elvis_lhs == null) {
          var tmp3_safe_receiver = chunk.n7x_1;
          tmp_0 = 'anthropic error ' + (tmp3_safe_receiver == null ? null : tmp3_safe_receiver.c7x_1);
        } else {
          tmp_0 = tmp2_elvis_lhs;
        }

        tmp.c7z_1 = new ModelError(tmp_0, false);
        return plus(events, finishFailed(this));
      case 'message_start':
        var tmp4_safe_receiver = chunk.j7x_1;
        var tmp5_safe_receiver = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.d7w_1;
        if (tmp5_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          var tmp_1 = firstOrNull(events);
          if (tmp_1 instanceof Started) {
            events.c3(0, new Started(tmp5_safe_receiver));
          }
        }

        var tmp6_safe_receiver = chunk.j7x_1;
        var tmp7_safe_receiver = tmp6_safe_receiver == null ? null : tmp6_safe_receiver.e7w_1;
        var tmp8_safe_receiver = tmp7_safe_receiver == null ? null : tmp7_safe_receiver.x7w_1;
        if (tmp8_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          this.z7y_1 = tmp8_safe_receiver;
        }

        break;
      case 'content_block_start':
        var block = chunk.k7x_1;
        var tmp9_elvis_lhs = chunk.i7x_1;
        var index = tmp9_elvis_lhs == null ? 0 : tmp9_elvis_lhs;
        switch (block == null ? null : block.i7w_1) {
          case 'tool_use':
            var tmp6 = this.u7y_1;
            var tmp12_elvis_lhs = block.j7w_1;
            var tmp_2 = tmp12_elvis_lhs == null ? '' : tmp12_elvis_lhs;
            var tmp13_elvis_lhs = block.k7w_1;
            // Inline function 'kotlin.collections.set' call

            var value = new ToolAcc(tmp_2, tmp13_elvis_lhs == null ? '' : tmp13_elvis_lhs);
            tmp6.k3(index, value);
            break;
          case 'thinking':
            var tmp9 = this.v7y_1;
            // Inline function 'kotlin.collections.set' call

            var value_0 = new ThinkingAcc(VOID, VOID, VOID, 'thinking');
            tmp9.k3(index, value_0);
            break;
          case 'redacted_thinking':
            var tmp12 = this.v7y_1;
            var tmp14_redacted = block.l7w_1;
            // Inline function 'kotlin.collections.set' call

            var value_1 = new ThinkingAcc(VOID, VOID, tmp14_redacted, 'redacted_thinking');
            tmp12.k3(index, value_1);
            break;
        }

        break;
      case 'content_block_delta':
        var delta = chunk.l7x_1;
        switch (delta == null ? null : delta.p7w_1) {
          case 'text_delta':
            var tmp17_safe_receiver = delta.q7w_1;
            if (tmp17_safe_receiver == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              // Inline function 'kotlin.text.isNotEmpty' call
              if (charSequenceLength(tmp17_safe_receiver) > 0) {
                this.x7y_1.tb(tmp17_safe_receiver);
                // Inline function 'kotlin.collections.plusAssign' call
                var element_0 = new TextDelta(tmp17_safe_receiver, this.y7y_1);
                events.l(element_0);
              }
            }

            break;
          case 'thinking_delta':
            var tmp18_safe_receiver = delta.r7w_1;
            if (tmp18_safe_receiver == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              var tmp0_elvis_lhs = chunk.i7x_1;
              var index_0 = tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
              // Inline function 'kotlin.collections.getOrPut' call
              var this_0 = this.v7y_1;
              var value_2 = this_0.h3(index_0);
              var tmp_3;
              if (value_2 == null) {
                var answer = new ThinkingAcc(VOID, VOID, VOID, 'thinking');
                this_0.k3(index_0, answer);
                tmp_3 = answer;
              } else {
                tmp_3 = value_2;
              }
              var acc = tmp_3;
              acc.o7y_1.tb(tmp18_safe_receiver);
              // Inline function 'kotlin.text.isNotEmpty' call
              if (charSequenceLength(tmp18_safe_receiver) > 0) {
                // Inline function 'kotlin.collections.plusAssign' call
                var element_1 = new ReasoningDelta(tmp18_safe_receiver, acc.s7y_1, ReasoningKind_RAW_getInstance());
                events.l(element_1);
              }
            }

            break;
          case 'signature_delta':
            var tmp19_safe_receiver = delta.s7w_1;
            if (tmp19_safe_receiver == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              var tmp0_safe_receiver = chunk.i7x_1;
              var tmp_4;
              if (tmp0_safe_receiver == null) {
                tmp_4 = null;
              } else {
                // Inline function 'kotlin.let' call
                var tmp0_safe_receiver_0 = this.v7y_1.h3(tmp0_safe_receiver);
                var tmp1_safe_receiver_0 = tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.p7y_1;
                tmp_4 = tmp1_safe_receiver_0 == null ? null : tmp1_safe_receiver_0.tb(tmp19_safe_receiver);
              }
            }

            break;
          case 'input_json_delta':
            var tmp20_elvis_lhs = chunk.i7x_1;
            var tmp_5;
            if (tmp20_elvis_lhs == null) {
              return events;
            } else {
              tmp_5 = tmp20_elvis_lhs;
            }

            var index_1 = tmp_5;
            var tmp21_elvis_lhs = this.u7y_1.h3(index_1);
            var tmp_6;
            if (tmp21_elvis_lhs == null) {
              return events;
            } else {
              tmp_6 = tmp21_elvis_lhs;
            }

            var acc_0 = tmp_6;
            var tmp22_elvis_lhs = delta.t7w_1;
            var tmp_7;
            if (tmp22_elvis_lhs == null) {
              return events;
            } else {
              tmp_7 = tmp22_elvis_lhs;
            }

            var fragment = tmp_7;
            acc_0.m7y_1.tb(fragment);
            // Inline function 'kotlin.collections.plusAssign' call

            var element_2 = new ToolCallDelta(acc_0.k7y_1, index_1, VOID, fragment, acc_0.n7y_1);
            events.l(element_2);
            break;
        }

        break;
      case 'content_block_stop':
        var tmp23_elvis_lhs = chunk.i7x_1;
        var tmp_8;
        if (tmp23_elvis_lhs == null) {
          return events;
        } else {
          tmp_8 = tmp23_elvis_lhs;
        }

        var index_2 = tmp_8;
        var tmp24_safe_receiver = this.v7y_1.l3(index_2);
        if (tmp24_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          var tmp_9;
          if (tmp24_safe_receiver.r7y_1 === 'redacted_thinking') {
            var tmp0_elvis_lhs_0 = tmp24_safe_receiver.q7y_1;
            tmp_9 = new RedactedThinking(tmp0_elvis_lhs_0 == null ? '' : tmp0_elvis_lhs_0);
          } else {
            var tmp_10 = tmp24_safe_receiver.o7y_1.toString();
            // Inline function 'kotlin.text.ifBlank' call
            var this_1 = tmp24_safe_receiver.p7y_1.toString();
            var tmp_11;
            if (isBlank(this_1)) {
              tmp_11 = null;
            } else {
              tmp_11 = this_1;
            }
            var tmp$ret$25 = tmp_11;
            tmp_9 = new Thinking(tmp_10, tmp$ret$25);
          }
          var block_0 = tmp_9;
          var tmp_12 = Companion_getInstance().s6d_1;
          // Inline function 'kotlin.text.ifBlank' call
          var this_2 = tmp24_safe_receiver.o7y_1.toString();
          var tmp_13;
          if (isBlank(this_2)) {
            tmp_13 = '[redacted thinking]';
          } else {
            tmp_13 = this_2;
          }
          var tmp$ret$27 = tmp_13;
          var item = new ProviderItem(tmp24_safe_receiver.s7y_1, VOID, tmp_12, tmp24_safe_receiver.r7y_1, tmp$ret$27, ReplayPolicy_Required_getInstance(), Companion_getInstance_1().o3z(JsonUtil_getInstance().m6g(block_0, Companion_instance_10.c3o())));
          // Inline function 'kotlin.collections.plusAssign' call
          this.w7y_1.l(item);
          // Inline function 'kotlin.collections.plusAssign' call
          var element_3 = new ItemAdded(item);
          events.l(element_3);
        }

        break;
      case 'message_delta':
        var tmp25_safe_receiver = chunk.m7x_1;
        var tmp26_safe_receiver = tmp25_safe_receiver == null ? null : tmp25_safe_receiver.y7w_1;
        if (tmp26_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          this.a7z_1 = tmp26_safe_receiver;
        }

        break;
    }
    return events;
  }
  p6h() {
    if (this.d7z_1)
      return emptyList();
    if (!(this.c7z_1 == null))
      return finishFailed(this);
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    // Inline function 'kotlin.text.isNotEmpty' call
    var this_0 = this.x7y_1;
    if (charSequenceLength(this_0) > 0) {
      var tmp1 = this.w7y_1;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = Companion_instance_0.u5t(this.x7y_1.toString(), this.y7y_1);
      tmp1.l(element);
    }
    // Inline function 'kotlin.collections.sortedBy' call
    var this_1 = this.u7y_1.l1();
    // Inline function 'kotlin.comparisons.compareBy' call
    var tmp = AnthropicWireDecoder$finish$lambda;
    var tmp$ret$3 = new sam$kotlin_Comparator$0(tmp);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = sortedWith(this_1, tmp$ret$3).y();
    while (_iterator__ex2g4s.z()) {
      var element_0 = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component2' call
      var acc = element_0.n1();
      var tmp_0 = _ItemRef___get_value__impl__fpjuyb(acc.n7y_1);
      // Inline function 'kotlin.text.ifBlank' call
      var this_2 = acc.m7y_1.toString();
      var tmp_1;
      if (isBlank(this_2)) {
        tmp_1 = '{}';
      } else {
        tmp_1 = this_2;
      }
      var tmp$ret$7 = tmp_1;
      var call = new ToolCall_0(tmp_0, acc.l7y_1, tmp$ret$7, new ProviderScopedId(Companion_getInstance().s6d_1, acc.k7y_1));
      var tmp2 = this.w7y_1;
      // Inline function 'kotlin.collections.plusAssign' call
      var element_1 = call.j61();
      tmp2.l(element_1);
      // Inline function 'kotlin.collections.plusAssign' call
      var element_2 = new ToolCallCompleted(call);
      events.l(element_2);
    }
    this.d7z_1 = true;
    // Inline function 'kotlin.collections.plusAssign' call
    var element_3 = new Finished(new Completed(VOID, toList(this.w7y_1), new Usage(this.z7y_1, this.a7z_1, this.z7y_1 + this.a7z_1 | 0, this.b7z_1)));
    events.l(element_3);
    return events;
  }
}
//endregion
function toAnthropicMessages(items) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var out = ArrayList.k();
  // Inline function 'kotlin.collections.filterNot' call
  // Inline function 'kotlin.collections.filterNotTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = items.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp;
    if (element instanceof Message) {
      tmp = element.e5o_1.equals(Role_SYSTEM_getInstance());
    } else {
      tmp = false;
    }
    if (!tmp) {
      destination.l(element);
    }
  }
  var nonSystem = destination;
  var i = 0;
  while (i < nonSystem.b1()) {
    var item = nonSystem.f1(i);
    if (item instanceof ToolResult) {
      // Inline function 'kotlin.collections.mutableListOf' call
      var blocks = ArrayList.k();
      $l$loop: while (true) {
        var tmp_0;
        if (i < nonSystem.b1()) {
          var tmp_1 = nonSystem.f1(i);
          tmp_0 = tmp_1 instanceof ToolResult;
        } else {
          tmp_0 = false;
        }
        if (!tmp_0) {
          break $l$loop;
        }
        var tmp_2 = nonSystem.f1(i);
        var result = tmp_2 instanceof ToolResult ? tmp_2 : THROW_CCE();
        // Inline function 'kotlin.collections.filterIsInstance' call
        // Inline function 'kotlin.collections.filterIsInstanceTo' call
        var destination_0 = ArrayList.k();
        var _iterator__ex2g4s_0 = items.y();
        while (_iterator__ex2g4s_0.z()) {
          var element_0 = _iterator__ex2g4s_0.a1();
          if (element_0 instanceof ToolCall) {
            destination_0.l(element_0);
          }
        }
        var tmp$ret$8;
        $l$block: {
          // Inline function 'kotlin.collections.firstOrNull' call
          var _iterator__ex2g4s_1 = destination_0.y();
          while (_iterator__ex2g4s_1.z()) {
            var element_1 = _iterator__ex2g4s_1.a1();
            if (element_1.s69_1 === result.p69_1) {
              tmp$ret$8 = element_1;
              break $l$block;
            }
          }
          tmp$ret$8 = null;
        }
        var call = tmp$ret$8;
        var tmp1_elvis_lhs = rawFor(call == null ? null : call.t69_1, Companion_getInstance().s6d_1);
        var toolUseId = tmp1_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(result.p69_1) : tmp1_elvis_lhs;
        // Inline function 'kotlin.collections.plusAssign' call
        var element_2 = new ToolResult_0(toolUseId, result.q69_1, result.r69_1);
        blocks.l(element_2);
        i = i + 1 | 0;
      }
      // Inline function 'kotlin.collections.plusAssign' call
      var element_3 = new AnthropicMessage('user', blocks);
      out.l(element_3);
    } else {
      if (item instanceof Message)
        if (item.e5o_1.equals(Role_USER_getInstance())) {
          // Inline function 'kotlin.collections.mutableListOf' call
          var blocks_0 = ArrayList.k();
          // Inline function 'kotlin.collections.filterIsInstance' call
          var tmp0 = item.f5o_1;
          // Inline function 'kotlin.collections.filterIsInstanceTo' call
          var destination_1 = ArrayList.k();
          var _iterator__ex2g4s_2 = tmp0.y();
          while (_iterator__ex2g4s_2.z()) {
            var element_4 = _iterator__ex2g4s_2.a1();
            if (element_4 instanceof Text) {
              destination_1.l(element_4);
            }
          }
          // Inline function 'kotlin.collections.forEach' call
          var _iterator__ex2g4s_3 = destination_1.y();
          while (_iterator__ex2g4s_3.z()) {
            var element_5 = _iterator__ex2g4s_3.a1();
            // Inline function 'kotlin.collections.plusAssign' call
            var element_6 = new Text_0(element_5.l6c_1);
            blocks_0.l(element_6);
          }
          if (blocks_0.h1()) {
            // Inline function 'kotlin.collections.plusAssign' call
            var element_7 = new Text_0(item.n5t());
            blocks_0.l(element_7);
          }
          // Inline function 'kotlin.collections.plusAssign' call
          var element_8 = new AnthropicMessage('user', blocks_0);
          out.l(element_8);
          i = i + 1 | 0;
        } else {
          i = consumeAssistantTurn(nonSystem, i, out);
        }
       else {
        var tmp_3;
        if (item instanceof ToolCall) {
          tmp_3 = true;
        } else {
          var tmp_4;
          if (item instanceof ProviderItem) {
            tmp_4 = true;
          } else {
            tmp_4 = item instanceof ReasoningSummary;
          }
          tmp_3 = tmp_4;
        }
        if (tmp_3) {
          i = consumeAssistantTurn(nonSystem, i, out);
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  return out;
}
function consumeAssistantTurn(items, start, out) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var blocks = ArrayList.k();
  var i = start;
  $l$loop_0: while (i < items.b1()) {
    var item = items.f1(i);
    if (item instanceof ProviderItem) {
      if (item.p5z_1 === Companion_getInstance().s6d_1 && (item.q5z_1 === 'thinking' || item.q5z_1 === 'redacted_thinking')) {
        var json = item.t5z_1.d42();
        // Inline function 'kotlin.runCatching' call
        var tmp;
        try {
          // Inline function 'kotlin.Companion.success' call
          var value = JsonUtil_getInstance().n6g(json, Companion_instance_10.c3o());
          tmp = _Result___init__impl__xyqfz8(value);
        } catch ($p) {
          var tmp_0;
          if ($p instanceof Error) {
            var e = $p;
            // Inline function 'kotlin.Companion.failure' call
            tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
          } else {
            throw $p;
          }
          tmp = tmp_0;
        }
        // Inline function 'kotlin.getOrElse' call
        var this_0 = tmp;
        var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
        var tmp_1;
        if (exception == null) {
          var tmp_2 = _Result___get_value__impl__bjfvqg(this_0);
          tmp_1 = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
        } else {
          throw AgentFrameworkException.j5t(new PreparationError('anthropic', 'failed to replay ' + item.q5z_1 + ' block', exception));
        }
        var block = tmp_1;
        // Inline function 'kotlin.collections.plusAssign' call
        blocks.l(block);
      } else {
        ensureDroppable(item, 'anthropic');
      }
      i = i + 1 | 0;
    } else {
      if (item instanceof Message) {
        if (!item.e5o_1.equals(Role_ASSISTANT_getInstance()))
          break $l$loop_0;
        // Inline function 'kotlin.text.isNotEmpty' call
        var this_1 = item.n5t();
        if (charSequenceLength(this_1) > 0) {
          // Inline function 'kotlin.collections.plusAssign' call
          var element = new Text_0(item.n5t());
          blocks.l(element);
        }
        i = i + 1 | 0;
      } else {
        if (item instanceof ToolCall) {
          var tmp0_elvis_lhs = rawFor(item.t69_1, Companion_getInstance().s6d_1);
          var tmp_3 = tmp0_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(item.s69_1) : tmp0_elvis_lhs;
          var tmp_4 = JsonUtil_getInstance().l6g_1;
          // Inline function 'kotlin.text.ifBlank' call
          var this_2 = item.v69_1;
          var tmp_5;
          if (isBlank(this_2)) {
            tmp_5 = '{}';
          } else {
            tmp_5 = this_2;
          }
          var tmp$ret$10 = tmp_5;
          // Inline function 'kotlin.collections.plusAssign' call
          var element_0 = new ToolUse(tmp_3, item.u69_1, tmp_4.b3m(tmp$ret$10));
          blocks.l(element_0);
          i = i + 1 | 0;
        } else {
          if (item instanceof ReasoningSummary) {
            i = i + 1 | 0;
          } else {
            if (item instanceof ToolResult)
              break $l$loop_0;
            else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
  }
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!blocks.h1()) {
    // Inline function 'kotlin.collections.plusAssign' call
    var element_1 = new AnthropicMessage('assistant', blocks);
    out.l(element_1);
  }
  return i;
}
function AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r() {
  return new ArrayListSerializer($serializer_getInstance_0());
}
function AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r_0() {
  return new ArrayListSerializer($serializer_getInstance_1());
}
function AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r_1() {
  return new ArrayListSerializer(StringSerializer_getInstance());
}
var Companion_instance_2;
function Companion_getInstance_2() {
  if (Companion_instance_2 === VOID)
    new Companion();
  return Companion_instance_2;
}
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance === VOID)
    new $serializer();
  return $serializer_instance;
}
function AnthropicMessage$Companion$$childSerializers$_anonymous__qndbyp() {
  var tmp = getKClass(AnthropicContentBlock);
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_0 = [getKClass(RedactedThinking), getKClass(Text_0), getKClass(Thinking), getKClass(ToolResult_0), getKClass(ToolUse)];
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_1 = [$serializer_getInstance_3(), $serializer_getInstance_4(), $serializer_getInstance_2(), $serializer_getInstance_6(), $serializer_getInstance_5()];
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$8 = [];
  return new ArrayListSerializer(SealedClassSerializer.n1u('org.koaks.provider.anthropic.AnthropicContentBlock', tmp, tmp_0, tmp_1, tmp$ret$8));
}
var Companion_instance_3;
function Companion_getInstance_3() {
  if (Companion_instance_3 === VOID)
    new Companion_0();
  return Companion_instance_3;
}
var $serializer_instance_0;
function $serializer_getInstance_0() {
  if ($serializer_instance_0 === VOID)
    new $serializer_0();
  return $serializer_instance_0;
}
var Companion_instance_4;
function Companion_getInstance_4() {
  return Companion_instance_4;
}
var $serializer_instance_1;
function $serializer_getInstance_1() {
  if ($serializer_instance_1 === VOID)
    new $serializer_1();
  return $serializer_instance_1;
}
var Companion_instance_5;
function Companion_getInstance_5() {
  return Companion_instance_5;
}
var $serializer_instance_2;
function $serializer_getInstance_2() {
  if ($serializer_instance_2 === VOID)
    new $serializer_2();
  return $serializer_instance_2;
}
var Companion_instance_6;
function Companion_getInstance_6() {
  return Companion_instance_6;
}
var $serializer_instance_3;
function $serializer_getInstance_3() {
  if ($serializer_instance_3 === VOID)
    new $serializer_3();
  return $serializer_instance_3;
}
var Companion_instance_7;
function Companion_getInstance_7() {
  return Companion_instance_7;
}
var $serializer_instance_4;
function $serializer_getInstance_4() {
  if ($serializer_instance_4 === VOID)
    new $serializer_4();
  return $serializer_instance_4;
}
var Companion_instance_8;
function Companion_getInstance_8() {
  return Companion_instance_8;
}
var $serializer_instance_5;
function $serializer_getInstance_5() {
  if ($serializer_instance_5 === VOID)
    new $serializer_5();
  return $serializer_instance_5;
}
var Companion_instance_9;
function Companion_getInstance_9() {
  return Companion_instance_9;
}
var $serializer_instance_6;
function $serializer_getInstance_6() {
  if ($serializer_instance_6 === VOID)
    new $serializer_6();
  return $serializer_instance_6;
}
var Companion_instance_10;
function Companion_getInstance_10() {
  return Companion_instance_10;
}
var Companion_instance_11;
function Companion_getInstance_11() {
  return Companion_instance_11;
}
var $serializer_instance_7;
function $serializer_getInstance_7() {
  if ($serializer_instance_7 === VOID)
    new $serializer_7();
  return $serializer_instance_7;
}
var Companion_instance_12;
function Companion_getInstance_12() {
  return Companion_instance_12;
}
var $serializer_instance_8;
function $serializer_getInstance_8() {
  if ($serializer_instance_8 === VOID)
    new $serializer_8();
  return $serializer_instance_8;
}
var Companion_instance_13;
function Companion_getInstance_13() {
  return Companion_instance_13;
}
var $serializer_instance_9;
function $serializer_getInstance_9() {
  if ($serializer_instance_9 === VOID)
    new $serializer_9();
  return $serializer_instance_9;
}
var Companion_instance_14;
function Companion_getInstance_14() {
  return Companion_instance_14;
}
var $serializer_instance_10;
function $serializer_getInstance_10() {
  if ($serializer_instance_10 === VOID)
    new $serializer_10();
  return $serializer_instance_10;
}
var Companion_instance_15;
function Companion_getInstance_15() {
  return Companion_instance_15;
}
var $serializer_instance_11;
function $serializer_getInstance_11() {
  if ($serializer_instance_11 === VOID)
    new $serializer_11();
  return $serializer_instance_11;
}
var Companion_instance_16;
function Companion_getInstance_16() {
  return Companion_instance_16;
}
var $serializer_instance_12;
function $serializer_getInstance_12() {
  if ($serializer_instance_12 === VOID)
    new $serializer_12();
  return $serializer_instance_12;
}
function anthropic(_this__u8e3s4, baseUrl, apiKey, modelName, block) {
  baseUrl = baseUrl === VOID ? 'https://api.anthropic.com/v1/messages' : baseUrl;
  var tmp;
  if (block === VOID) {
    tmp = anthropic$lambda;
  } else {
    tmp = block;
  }
  block = tmp;
  // Inline function 'kotlin.apply' call
  var this_0 = new AnthropicConfig(baseUrl, apiKey, modelName);
  block(this_0);
  var cfg = this_0;
  return _this__u8e3s4.o60(new AnthropicChatModel(cfg.b7y(), _this__u8e3s4.q60(), cfg.c7y(), cfg.d7y()));
}
function normalizeAnthropicMessagesUrl(baseUrl) {
  // Inline function 'kotlin.text.trim' call
  var tmp$ret$0 = toString_0(trim(isCharSequence(baseUrl) ? baseUrl : THROW_CCE()));
  var trimmed = trimEnd(tmp$ret$0, charArrayOf([_Char___init__impl__6a9atx(47)]));
  return endsWith(trimmed, '/messages') ? trimmed : trimmed + '/v1/messages';
}
function anthropic$lambda(_this__u8e3s4) {
  return Unit_instance;
}
function finishFailed($this) {
  if ($this.d7z_1)
    return emptyList();
  $this.d7z_1 = true;
  return listOf(new Finished(new Failed(ensureNotNull($this.c7z_1), VOID, VOID, new Usage($this.z7y_1, $this.a7z_1, $this.z7y_1 + $this.a7z_1 | 0))));
}
function providerEvent($this, frame) {
  var tmp;
  if (frame instanceof Sse) {
    tmp = frame.y6n_1;
  } else {
    if (frame instanceof Body) {
      tmp = frame.b6o_1;
    } else {
      if (frame instanceof Ndjson) {
        tmp = frame.c6o_1;
      } else {
        if (frame instanceof HttpError) {
          tmp = frame.e6n_1;
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  var payload = tmp;
  // Inline function 'kotlin.takeUnless' call
  var tmp_0;
  if (!isBlank(payload)) {
    tmp_0 = payload;
  } else {
    tmp_0 = null;
  }
  var tmp1_safe_receiver = tmp_0;
  var tmp_1;
  if (tmp1_safe_receiver == null) {
    tmp_1 = null;
  } else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.runCatching' call
    var tmp_2;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = get_jsonObject(JsonUtil_getInstance().l6g_1.b3m(tmp1_safe_receiver));
      tmp_2 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_3;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_3 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_2 = tmp_3;
    }
    // Inline function 'kotlin.Result.getOrNull' call
    var this_0 = tmp_2;
    var tmp_4;
    if (_Result___get_isFailure__impl__jpiriv(this_0)) {
      tmp_4 = null;
    } else {
      var tmp_5 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_4 = (tmp_5 == null ? true : !(tmp_5 == null)) ? tmp_5 : THROW_CCE();
    }
    tmp_1 = tmp_4;
  }
  var parsed = tmp_1;
  var tmp11_providerId = Companion_getInstance().s6d_1;
  var tmp12_protocolId = Companion_getInstance_0().b6e_1;
  var tmp_6;
  if (frame instanceof Sse) {
    var tmp3_elvis_lhs = frame.x6n_1;
    var tmp4_elvis_lhs = tmp3_elvis_lhs == null ? str(parsed, 'type') : tmp3_elvis_lhs;
    tmp_6 = tmp4_elvis_lhs == null ? 'unknown' : tmp4_elvis_lhs;
  } else {
    if (frame instanceof Body) {
      var tmp5_elvis_lhs = str(parsed, 'type');
      tmp_6 = tmp5_elvis_lhs == null ? 'unknown' : tmp5_elvis_lhs;
    } else {
      if (frame instanceof Ndjson) {
        var tmp6_elvis_lhs = str(parsed, 'type');
        tmp_6 = tmp6_elvis_lhs == null ? 'unknown' : tmp6_elvis_lhs;
      } else {
        if (frame instanceof HttpError) {
          tmp_6 = 'http.error';
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  var tmp13_type = tmp_6;
  var tmp_7;
  if (frame instanceof Sse) {
    tmp_7 = ProviderEventSource_SSE_getInstance();
  } else {
    if (frame instanceof Body) {
      tmp_7 = ProviderEventSource_BODY_getInstance();
    } else {
      if (frame instanceof Ndjson) {
        tmp_7 = ProviderEventSource_NDJSON_getInstance();
      } else {
        if (frame instanceof HttpError) {
          tmp_7 = ProviderEventSource_HTTP_ERROR_getInstance();
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  var tmp14_source = tmp_7;
  var tmp8_safe_receiver = frame instanceof Sse ? frame : null;
  var tmp15_eventId = tmp8_safe_receiver == null ? null : tmp8_safe_receiver.z6n_1;
  var tmp16_sequenceNumber = long(parsed, 'sequence_number');
  var tmp9_safe_receiver = frame instanceof HttpError ? frame : null;
  var tmp17_statusCode = tmp9_safe_receiver == null ? null : tmp9_safe_receiver.c6n_1;
  var tmp_8;
  if (frame instanceof Body) {
    tmp_8 = frame.a6o_1;
  } else {
    if (frame instanceof HttpError) {
      tmp_8 = frame.d6n_1;
    } else {
      tmp_8 = null;
    }
  }
  var tmp18_contentType = tmp_8;
  return new ProviderEvent(tmp11_providerId, tmp13_type, payload, tmp12_protocolId, tmp14_source, tmp15_eventId, tmp16_sequenceNumber, tmp17_statusCode, tmp18_contentType);
}
function AnthropicWireDecoder$finish$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = a.m1();
  var tmp$ret$1 = b.m1();
  return compareValues(tmp, tmp$ret$1);
}
function str(_this__u8e3s4, key) {
  var tmp1_safe_receiver = _this__u8e3s4 == null ? null : _this__u8e3s4.w2f(key);
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_safe_receiver = tmp1_safe_receiver instanceof JsonPrimitive ? tmp1_safe_receiver : null;
    tmp = tmp0_safe_receiver == null ? null : get_contentOrNull(tmp0_safe_receiver);
  }
  return tmp;
}
function long(_this__u8e3s4, key) {
  var tmp1_safe_receiver = _this__u8e3s4 == null ? null : _this__u8e3s4.w2f(key);
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_safe_receiver = tmp1_safe_receiver instanceof JsonPrimitive ? tmp1_safe_receiver : null;
    tmp = tmp0_safe_receiver == null ? null : get_longOrNull(tmp0_safe_receiver);
  }
  return tmp;
}
//region block: post-declaration
initMetadataForClass(AnthropicChatModel, 'AnthropicChatModel', VOID, VOID, VOID, [1]);
initMetadataForClass(AnthropicParams, 'AnthropicParams', AnthropicParams);
initMetadataForCompanion(Companion);
protoOf($serializer).v25 = typeParametersSerializers;
initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(AnthropicChatRequest, 'AnthropicChatRequest', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
initMetadataForCompanion(Companion_0);
protoOf($serializer_0).v25 = typeParametersSerializers;
initMetadataForObject($serializer_0, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(AnthropicMessage, 'AnthropicMessage', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
initMetadataForCompanion(Companion_1);
protoOf($serializer_1).v25 = typeParametersSerializers;
initMetadataForObject($serializer_1, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(AnthropicTool, 'AnthropicTool', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_1});
initMetadataForCompanion(Companion_2);
protoOf($serializer_2).v25 = typeParametersSerializers;
initMetadataForObject($serializer_2, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_3);
protoOf($serializer_3).v25 = typeParametersSerializers;
initMetadataForObject($serializer_3, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_4);
protoOf($serializer_4).v25 = typeParametersSerializers;
initMetadataForObject($serializer_4, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_5);
protoOf($serializer_5).v25 = typeParametersSerializers;
initMetadataForObject($serializer_5, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_6);
protoOf($serializer_6).v25 = typeParametersSerializers;
initMetadataForObject($serializer_6, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForInterface(AnthropicContentBlock, 'AnthropicContentBlock', VOID, VOID, VOID, VOID, VOID, {0: Companion_getInstance_10});
initMetadataForClass(Thinking, 'Thinking', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_2});
initMetadataForClass(RedactedThinking, 'RedactedThinking', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_3});
initMetadataForClass(Text_0, 'Text', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_4});
initMetadataForClass(ToolUse, 'ToolUse', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_5});
initMetadataForClass(ToolResult_0, 'ToolResult', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_6});
initMetadataForCompanion(Companion_7, VOID, [SerializerFactory]);
initMetadataForCompanion(Companion_8);
protoOf($serializer_7).v25 = typeParametersSerializers;
initMetadataForObject($serializer_7, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_9);
protoOf($serializer_8).v25 = typeParametersSerializers;
initMetadataForObject($serializer_8, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_10);
protoOf($serializer_9).v25 = typeParametersSerializers;
initMetadataForObject($serializer_9, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_11);
protoOf($serializer_10).v25 = typeParametersSerializers;
initMetadataForObject($serializer_10, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_12);
protoOf($serializer_11).v25 = typeParametersSerializers;
initMetadataForObject($serializer_11, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(Message_0, 'Message', Message_0, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_7});
initMetadataForClass(ContentBlock, 'ContentBlock', ContentBlock, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_8});
initMetadataForClass(Delta, 'Delta', Delta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_9});
initMetadataForClass(Usage_0, 'Usage', Usage_0, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_10});
initMetadataForClass(ErrorOutput, 'ErrorOutput', ErrorOutput, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_11});
initMetadataForCompanion(Companion_13);
protoOf($serializer_12).v25 = typeParametersSerializers;
initMetadataForObject($serializer_12, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(AnthropicChatResponse, 'AnthropicChatResponse', AnthropicChatResponse, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_12});
initMetadataForClass(AnthropicConfig, 'AnthropicConfig');
initMetadataForClass(AnthropicCapabilitiesScope, 'AnthropicCapabilitiesScope');
initMetadataForClass(ToolAcc, 'ToolAcc');
initMetadataForClass(ThinkingAcc, 'ThinkingAcc');
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(AnthropicWireDecoder, 'AnthropicWireDecoder', AnthropicWireDecoder);
//endregion
//region block: init
Companion_instance_4 = new Companion_1();
Companion_instance_5 = new Companion_2();
Companion_instance_6 = new Companion_3();
Companion_instance_7 = new Companion_4();
Companion_instance_8 = new Companion_5();
Companion_instance_9 = new Companion_6();
Companion_instance_10 = new Companion_7();
Companion_instance_11 = new Companion_8();
Companion_instance_12 = new Companion_9();
Companion_instance_13 = new Companion_10();
Companion_instance_14 = new Companion_11();
Companion_instance_15 = new Companion_12();
Companion_instance_16 = new Companion_13();
//endregion
//region block: exports
export {
  anthropic as anthropic200c8euko87qc,
};
//endregion

//# sourceMappingURL=koaks-model-provider-anthropic.mjs.map
