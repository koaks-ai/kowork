import {
  VOID7hggqo3abtya as VOID,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  Unit_instance104q5opgivhr8 as Unit_instance,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  protoOf180f3jzyo7rfj as protoOf,
} from './kotlin-kotlin-stdlib.mjs';
import {
  TurnRetention_Interrupted_getInstance1clj3n1yfuiga as TurnRetention_Interrupted_getInstance,
  turnHasSideEffects1mpwjsroa3ywe as turnHasSideEffects,
  shouldRetain150nlxe0gzy8j as shouldRetain,
  _ThreadId___get_value__impl__tytyxcp6hybs6mx9vr as _ThreadId___get_value__impl__tytyxc,
  displayText2pp0s33rxlm2 as displayText,
  MemoryView36zuxzo826bia as MemoryView,
  closeca18uc43m2gy as close,
  ThreadMemory1dswgl9efn3yf as ThreadMemory,
} from './koaks-core.mjs';
//region block: imports
//endregion
//region block: pre-declaration
class VectorMemoryProvider {
  constructor(id, store, topK, retention) {
    topK = topK === VOID ? 8 : topK;
    retention = retention === VOID ? TurnRetention_Interrupted_getInstance() : retention;
    this.f81_1 = id;
    this.g81_1 = store;
    this.h81_1 = topK;
    this.i81_1 = retention;
  }
  c5r() {
    return this.f81_1;
  }
  e69(thread, $completion) {
    return new VectorMemory(this.g81_1, thread, this.h81_1, this.i81_1);
  }
}
class VectorMemory {
  constructor(store, thread, topK, retention) {
    topK = topK === VOID ? 8 : topK;
    retention = retention === VOID ? TurnRetention_Interrupted_getInstance() : retention;
    this.j81_1 = store;
    this.k81_1 = thread;
    this.l81_1 = topK;
    this.m81_1 = retention;
  }
  h69() {
    return this.m81_1;
  }
  j69(turn, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_commit__is9lbl.bind(VOID, this, turn), $completion);
  }
  i69(query, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda.bind(VOID, this, query), $completion);
  }
}
//endregion
function *_generator_commit__is9lbl($this, turn, $completion) {
  if (!shouldRetain(turn, $this.m81_1, turnHasSideEffects(turn)))
    return Unit_instance;
  var tmp = $this.j81_1.n81(_ThreadId___get_value__impl__tytyxc($this.k81_1), turn.q68_1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_load__qllgda($this, query, $completion) {
  var tmp0_safe_receiver = lastOrNull(query);
  // Inline function 'kotlin.text.orEmpty' call
  var tmp0_elvis_lhs = tmp0_safe_receiver == null ? null : displayText(tmp0_safe_receiver);
  var text = tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs;
  var tmp = $this.j81_1.o81(_ThreadId___get_value__impl__tytyxc($this.k81_1), text, $this.l81_1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return new MemoryView(tmp, null);
}
//region block: post-declaration
initMetadataForClass(VectorMemoryProvider, 'VectorMemoryProvider', VOID, VOID, VOID, [1]);
protoOf(VectorMemory).a6 = close;
initMetadataForClass(VectorMemory, 'VectorMemory', VOID, VOID, [ThreadMemory], [1]);
//endregion
//region block: exports
export {
  VectorMemoryProvider as VectorMemoryProvider3fzzdfryhom7q,
};
//endregion

//# sourceMappingURL=koaks-koaks-memory-vector.mjs.map
