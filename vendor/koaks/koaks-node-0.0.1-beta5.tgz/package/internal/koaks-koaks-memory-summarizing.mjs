import { Mutex16li1l0asjv17 as Mutex } from './kotlinx-coroutines-core.mjs';
import {
  LinkedHashSet2tkztfx86kyx2 as LinkedHashSet,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  Unit_instance104q5opgivhr8 as Unit_instance,
  equals2au1ep9vhcato as equals,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  isInterface3d6p8outrmvmk as isInterface,
  hashCodeq5arwsb9dgti as hashCode,
  VOID7hggqo3abtya as VOID,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  emptyList1g2z5xcrvp2zy as emptyList,
  ArrayList3it5z8td81qkl as ArrayList,
  addAll1k27qatfgp3k5 as addAll,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  Collection1k04j3hzsbod0 as Collection,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  drop3na99dw9feawf as drop,
  dropLast1vpiyky649o34 as dropLast,
  flatten2dh4kibw1u0qq as flatten,
  plus310ted5e4i90h as plus,
  take3onnpy6q7ctcz as take,
  plus20p0vtfmu0596 as plus_0,
  joinToString1cxrrlmo0chqs as joinToString,
  listOfvhqybd2zx248 as listOf,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  isBlank1dvkhjjvox3p0 as isBlank,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  last1vo29oleiqj36 as last,
  mutableListOf6oorvk2mtdmp as mutableListOf,
} from './kotlin-kotlin-stdlib.mjs';
import {
  ThreadId21scpc0nj57qc as ThreadId,
  TurnRetention_Interrupted_getInstance1clj3n1yfuiga as TurnRetention_Interrupted_getInstance,
  MemoryView36zuxzo826bia as MemoryView,
  closeca18uc43m2gy as close,
  ThreadMemory1dswgl9efn3yf as ThreadMemory,
  _MemoryProviderId___init__impl__vkxutoeycvcgh355zg as _MemoryProviderId___init__impl__vkxuto,
  ThreadId__toString_impl_tri2rgo3ztqbcb7oi1 as ThreadId__toString_impl_tri2rg,
  ThreadId__hashCode_impl_80c5yl3g51hyor3y6mh as ThreadId__hashCode_impl_80c5yl,
  isSystem5q4g7p85h8y2 as isSystem,
  Companion_instance3119tbznr6ao7 as Companion_instance_0,
  Companion_instancelgypg95btxw8 as Companion_instance_1,
  ProviderItem17hp0vuxmlwze as ProviderItem,
  ReplayPolicy_Required_getInstance1o7kby0tmyj43 as ReplayPolicy_Required_getInstance,
  newIdempotencyKey3adur2bjpedyg as newIdempotencyKey,
  ModelRequest2fvlnwc92shgb as ModelRequest,
  generate290swdgdwvcq1 as generate,
  Completedf7bahq5rqxjz as Completed,
  Message1x6kaj8ypdoee as Message,
  isUserTurnBoundary3tbzs28fwfq04 as isUserTurnBoundary,
  displayText2pp0s33rxlm2 as displayText,
} from './koaks-core.mjs';
import { System_instance3bcuv0kn0rmcj as System_instance } from './Kotlin-DateTime-library-kotlinx-datetime.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class ThreadCoordinator {
  constructor() {
    this.h7z_1 = Mutex();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableSetOf' call
    tmp.i7z_1 = LinkedHashSet.g1();
  }
}
class CompactionObserver {}
class sam$org_koaks_memory_summarizing_CompactionObserver$0 {
  constructor(function_0) {
    this.t7z_1 = function_0;
  }
  u7z(event) {
    return this.t7z_1(event);
  }
  n4() {
    return this.t7z_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, CompactionObserver) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class SummarizingMemoryProvider {
  constructor(id, delegate, stateStore, model, maxTokens, keepRecentTurns, retention, observer) {
    keepRecentTurns = keepRecentTurns === VOID ? 2 : keepRecentTurns;
    retention = retention === VOID ? TurnRetention_Interrupted_getInstance() : retention;
    var tmp;
    if (observer === VOID) {
      var tmp_0 = SummarizingMemoryProvider$_init_$lambda_mcnmzf;
      tmp = new sam$org_koaks_memory_summarizing_CompactionObserver$0(tmp_0);
    } else {
      tmp = observer;
    }
    observer = tmp;
    this.j7z_1 = id;
    this.k7z_1 = delegate;
    this.l7z_1 = stateStore;
    this.m7z_1 = model;
    this.n7z_1 = maxTokens;
    this.o7z_1 = keepRecentTurns;
    this.p7z_1 = retention;
    this.q7z_1 = observer;
    this.r7z_1 = Mutex();
    var tmp_1 = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp_1.s7z_1 = LinkedHashMap.hc();
    // Inline function 'kotlin.require' call
    if (!(this.n7z_1 > 0)) {
      var message = 'maxTokens must be positive';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.o7z_1 >= 1)) {
      var message_0 = 'keepRecentTurns must be at least one';
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
  c5r() {
    return this.j7z_1;
  }
  e69(thread, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_open__qjxcea.bind(VOID, this, thread), $completion);
  }
}
class InMemoryAppendMemoryProvider$open$2 {
  constructor(this$0, $thread) {
    this.a80_1 = this$0;
    this.b80_1 = $thread;
    this.z7z_1 = this$0.w7z_1;
  }
  h69() {
    return this.z7z_1;
  }
  i69(query, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda.bind(VOID, this, query), $completion);
  }
  j69(turn, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_commit__is9lbl.bind(VOID, this, turn), $completion);
  }
}
class InMemoryAppendMemoryProvider {
  constructor(id, retention) {
    id = id === VOID ? _MemoryProviderId___init__impl__vkxuto('summarizing-raw-memory') : id;
    retention = retention === VOID ? TurnRetention_Interrupted_getInstance() : retention;
    this.v7z_1 = id;
    this.w7z_1 = retention;
    this.x7z_1 = Mutex();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.y7z_1 = LinkedHashMap.hc();
  }
  c5r() {
    return this.v7z_1;
  }
  e69(thread, $completion) {
    return new InMemoryAppendMemoryProvider$open$2(this, thread);
  }
}
class InMemorySummaryStateStore {
  constructor() {
    this.c80_1 = Mutex();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.d80_1 = LinkedHashMap.hc();
  }
  e80(threadId, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda_0.bind(VOID, this, threadId), $completion);
  }
  f80(threadId, checkpoint, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_save__qhzefp.bind(VOID, this, threadId, checkpoint), $completion);
  }
  g80(threadId, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_delete__spiywt.bind(VOID, this, threadId), $completion);
  }
}
class Started {
  constructor(threadId, sourceTurnId, basis) {
    this.h80_1 = threadId;
    this.i80_1 = sourceTurnId;
    this.j80_1 = basis;
  }
  c6w() {
    return this.h80_1;
  }
  k80() {
    return this.i80_1;
  }
  toString() {
    return 'Started(threadId=' + ThreadId__toString_impl_tri2rg(this.h80_1) + ', sourceTurnId=' + this.i80_1 + ', basis=' + this.j80_1.toString() + ')';
  }
  hashCode() {
    var result = ThreadId__hashCode_impl_80c5yl(this.h80_1);
    result = imul(result, 31) + getStringHashCode(this.i80_1) | 0;
    result = imul(result, 31) + this.j80_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Started))
      return false;
    var tmp0_other_with_cast = other instanceof Started ? other : THROW_CCE();
    if (!(this.h80_1 === tmp0_other_with_cast.h80_1))
      return false;
    if (!(this.i80_1 === tmp0_other_with_cast.i80_1))
      return false;
    if (!this.j80_1.equals(tmp0_other_with_cast.j80_1))
      return false;
    return true;
  }
}
class Completed_0 {
  constructor(threadId, sourceTurnId, checkpoint) {
    this.l80_1 = threadId;
    this.m80_1 = sourceTurnId;
    this.n80_1 = checkpoint;
  }
  c6w() {
    return this.l80_1;
  }
  k80() {
    return this.m80_1;
  }
  toString() {
    return 'Completed(threadId=' + ThreadId__toString_impl_tri2rg(this.l80_1) + ', sourceTurnId=' + this.m80_1 + ', checkpoint=' + this.n80_1.toString() + ')';
  }
  hashCode() {
    var result = ThreadId__hashCode_impl_80c5yl(this.l80_1);
    result = imul(result, 31) + getStringHashCode(this.m80_1) | 0;
    result = imul(result, 31) + this.n80_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Completed_0))
      return false;
    var tmp0_other_with_cast = other instanceof Completed_0 ? other : THROW_CCE();
    if (!(this.l80_1 === tmp0_other_with_cast.l80_1))
      return false;
    if (!(this.m80_1 === tmp0_other_with_cast.m80_1))
      return false;
    if (!this.n80_1.equals(tmp0_other_with_cast.n80_1))
      return false;
    return true;
  }
}
class Failed {
  constructor(threadId, sourceTurnId, message) {
    this.o80_1 = threadId;
    this.p80_1 = sourceTurnId;
    this.q80_1 = message;
  }
  c6w() {
    return this.o80_1;
  }
  k80() {
    return this.p80_1;
  }
  toString() {
    return 'Failed(threadId=' + ThreadId__toString_impl_tri2rg(this.o80_1) + ', sourceTurnId=' + this.p80_1 + ', message=' + this.q80_1 + ')';
  }
  hashCode() {
    var result = ThreadId__hashCode_impl_80c5yl(this.o80_1);
    result = imul(result, 31) + getStringHashCode(this.p80_1) | 0;
    result = imul(result, 31) + getStringHashCode(this.q80_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Failed))
      return false;
    var tmp0_other_with_cast = other instanceof Failed ? other : THROW_CCE();
    if (!(this.o80_1 === tmp0_other_with_cast.o80_1))
      return false;
    if (!(this.p80_1 === tmp0_other_with_cast.p80_1))
      return false;
    if (!(this.q80_1 === tmp0_other_with_cast.q80_1))
      return false;
    return true;
  }
}
class SummaryCheckpoint {
  constructor(basis, summary, sourceTurnId, createdAtEpochMillis) {
    this.r80_1 = basis;
    this.s80_1 = summary;
    this.t80_1 = sourceTurnId;
    this.u80_1 = createdAtEpochMillis;
  }
  toString() {
    return 'SummaryCheckpoint(basis=' + this.r80_1.toString() + ', summary=' + this.s80_1.toString() + ', sourceTurnId=' + this.t80_1 + ', createdAtEpochMillis=' + this.u80_1.toString() + ')';
  }
  hashCode() {
    var result = this.r80_1.hashCode();
    result = imul(result, 31) + this.s80_1.hashCode() | 0;
    result = imul(result, 31) + getStringHashCode(this.t80_1) | 0;
    result = imul(result, 31) + this.u80_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SummaryCheckpoint))
      return false;
    var tmp0_other_with_cast = other instanceof SummaryCheckpoint ? other : THROW_CCE();
    if (!this.r80_1.equals(tmp0_other_with_cast.r80_1))
      return false;
    if (!this.s80_1.equals(tmp0_other_with_cast.s80_1))
      return false;
    if (!(this.t80_1 === tmp0_other_with_cast.t80_1))
      return false;
    if (!this.u80_1.equals(tmp0_other_with_cast.u80_1))
      return false;
    return true;
  }
}
class CompactingThreadMemory {
  constructor(threadId, delegate, stateStore, model, maxTokens, keepRecentTurns, retention, observer, mutex, committedTurnIds) {
    this.v80_1 = threadId;
    this.w80_1 = delegate;
    this.x80_1 = stateStore;
    this.y80_1 = model;
    this.z80_1 = maxTokens;
    this.a81_1 = keepRecentTurns;
    this.b81_1 = retention;
    this.c81_1 = observer;
    this.d81_1 = mutex;
    this.e81_1 = committedTurnIds;
  }
  h69() {
    return this.b81_1;
  }
  i69(query, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda_1.bind(VOID, this, query), $completion);
  }
  j69(turn, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_commit__is9lbl_0.bind(VOID, this, turn), $completion);
  }
  a6() {
    return this.w80_1.a6();
  }
}
//endregion
function *_generator_open__qjxcea($this, thread, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.r7z_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    var tmp0 = $this.s7z_1;
    // Inline function 'kotlin.collections.getOrPut' call
    var key = new ThreadId(thread);
    var value = tmp0.h3(key);
    var tmp_1;
    if (value == null) {
      var answer = new ThreadCoordinator();
      tmp0.k3(key, answer);
      tmp_1 = answer;
    } else {
      tmp_1 = value;
    }
    tmp_0 = tmp_1;
  }finally {
    this_0.n1h(null);
  }
  var coordinator = tmp_0;
  var tmp_2 = $this.k7z_1.e69(thread, $completion);
  if (tmp_2 === get_COROUTINE_SUSPENDED())
    tmp_2 = yield tmp_2;
  return new CompactingThreadMemory(thread, tmp_2, $this.l7z_1, $this.m7z_1, $this.n7z_1, $this.o7z_1, $this.p7z_1, $this.q7z_1, coordinator.h7z_1, coordinator.i7z_1);
}
function SummarizingMemoryProvider$_init_$lambda_mcnmzf(it) {
  return Unit_instance;
}
function *_generator_load__qllgda($this, query, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.a80_1.x7z_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    // Inline function 'kotlin.collections.orEmpty' call
    var tmp0_elvis_lhs = $this.a80_1.y7z_1.h3(new ThreadId($this.b80_1));
    var turns = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
    // Inline function 'kotlin.collections.flatMap' call
    // Inline function 'kotlin.collections.flatMapTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = turns.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var list = element.q68_1;
      addAll(destination, list);
    }
    var tmp_1 = destination;
    var tmp0_safe_receiver = lastOrNull(turns);
    tmp_0 = new MemoryView(tmp_1, tmp0_safe_receiver == null ? null : tmp0_safe_receiver.r68_1);
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function *_generator_commit__is9lbl($this, turn, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.a80_1.x7z_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    var tmp0 = $this.a80_1.y7z_1;
    // Inline function 'kotlin.collections.getOrPut' call
    var key = new ThreadId($this.b80_1);
    var value = tmp0.h3(key);
    var tmp_0;
    if (value == null) {
      // Inline function 'kotlin.collections.mutableListOf' call
      var answer = ArrayList.k();
      tmp0.k3(key, answer);
      tmp_0 = answer;
    } else {
      tmp_0 = value;
    }
    var turns = tmp_0;
    var tmp$ret$3;
    $l$block_0: {
      // Inline function 'kotlin.collections.none' call
      var tmp_1;
      if (isInterface(turns, Collection)) {
        tmp_1 = turns.h1();
      } else {
        tmp_1 = false;
      }
      if (tmp_1) {
        tmp$ret$3 = true;
        break $l$block_0;
      }
      var _iterator__ex2g4s = turns.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (element.o68_1 === turn.o68_1) {
          tmp$ret$3 = false;
          break $l$block_0;
        }
      }
      tmp$ret$3 = true;
    }
    if (tmp$ret$3) {
      turns.l(turn);
    }
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_load__qllgda_0($this, threadId, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.c80_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    tmp_0 = $this.d80_1.h3(new ThreadId(threadId));
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function *_generator_save__qhzefp($this, threadId, checkpoint, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.c80_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    var tmp0 = $this.d80_1;
    // Inline function 'kotlin.collections.set' call
    var key = new ThreadId(threadId);
    tmp0.k3(key, checkpoint);
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_delete__spiywt($this, threadId, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.c80_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    tmp_0 = $this.d80_1.l3(new ThreadId(threadId));
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_load__qllgda_1($this, query, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.d81_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    var tmp_1 = $this.w80_1.i69(query, $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    var tmp_2 = project($this, tmp_1, $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    tmp_0 = tmp_2;
  }finally {
    this_0.n1h(null);
  }
  return tmp_0;
}
function *_generator_commit__is9lbl_0($this, turn, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.d81_1;
  var tmp = this_0.c1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  try {
    $l$block_1: {
      if ($this.e81_1.v2(turn.o68_1)) {
        break $l$block_1;
      }
      var tmp_0 = $this.w80_1.j69(turn, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      var tmp0 = $this.e81_1;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = turn.o68_1;
      tmp0.l(element);
      if (turn.s68_1.c5z_1 <= $this.z80_1) {
        break $l$block_1;
      }
      var tmp_1 = $this.w80_1.i69(emptyList(), $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
      var raw = tmp_1;
      // Inline function 'kotlin.collections.takeWhile' call
      var this_1 = raw.k69_1;
      var list = ArrayList.k();
      var _iterator__ex2g4s = this_1.y();
      $l$loop: while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        if (!isSystem(item))
          break $l$loop;
        list.l(item);
      }
      var system = list;
      var turns = groupIntoTurns($this, drop(raw.k69_1, system.b1()));
      if (turns.b1() <= $this.a81_1) {
        break $l$block_1;
      }
      var prefix = plus(system, flatten(dropLast(turns, $this.a81_1)));
      var basis = Companion_instance_0.q6b(prefix);
      notify($this, new Started($this.v80_1, turn.o68_1, basis));
      try {
        var tmp_2 = summarize($this, drop(prefix, system.b1()), $completion);
        if (tmp_2 === get_COROUTINE_SUSPENDED())
          tmp_2 = yield tmp_2;
        var summary = tmp_2;
        var checkpoint = new SummaryCheckpoint(basis, Companion_instance_1.d6f('Summary of earlier conversation:\n' + summary), turn.o68_1, System_instance.p53().k5k());
        var tmp_3 = $this.x80_1.f80($this.v80_1, checkpoint, $completion);
        if (tmp_3 === get_COROUTINE_SUSPENDED())
          tmp_3 = yield tmp_3;
        notify($this, new Completed_0($this.v80_1, turn.o68_1, checkpoint));
      } catch ($p) {
        if ($p instanceof Error) {
          var failure = $p;
          var tmp0_elvis_lhs = failure.message;
          notify($this, new Failed($this.v80_1, turn.o68_1, tmp0_elvis_lhs == null ? 'compaction failed' : tmp0_elvis_lhs));
          throw failure;
        } else {
          throw $p;
        }
      }
    }
  }finally {
    this_0.n1h(null);
  }
  return Unit_instance;
}
function *_generator_project__7jclkr($this, raw, $completion) {
  var tmp = $this.x80_1.e80($this.v80_1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp0_elvis_lhs = tmp;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return raw;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var state = tmp_0;
  var count = state.r80_1.r6b_1;
  if (raw.k69_1.b1() < count) {
    var tmp_1 = $this.x80_1.g80($this.v80_1, $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    return raw;
  }
  var prefix = take(raw.k69_1, count);
  if (!Companion_instance_0.q6b(prefix).equals(state.r80_1)) {
    var tmp_2 = $this.x80_1.g80($this.v80_1, $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    return raw;
  }
  // Inline function 'kotlin.collections.takeWhile' call
  var list = ArrayList.k();
  var _iterator__ex2g4s = prefix.y();
  $l$loop: while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    if (!isSystem(item))
      break $l$loop;
    list.l(item);
  }
  var system = list;
  // Inline function 'kotlin.collections.filterIsInstance' call
  var tmp0 = drop(prefix, system.b1());
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s_0 = tmp0.y();
  while (_iterator__ex2g4s_0.z()) {
    var element = _iterator__ex2g4s_0.a1();
    if (element instanceof ProviderItem) {
      destination.l(element);
    }
  }
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination_0 = ArrayList.k();
  var _iterator__ex2g4s_1 = destination.y();
  while (_iterator__ex2g4s_1.z()) {
    var element_0 = _iterator__ex2g4s_1.a1();
    if (element_0.s5z_1.equals(ReplayPolicy_Required_getInstance())) {
      destination_0.l(element_0);
    }
  }
  var required = destination_0;
  return new MemoryView(plus(plus(plus_0(system, state.s80_1), required), drop(raw.k69_1, count)), null);
}
function project($this, raw, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_project__7jclkr.bind(VOID, $this, raw), $completion);
}
function *_generator_summarize__pql4lv($this, items, $completion) {
  var tmp = Companion_instance_1;
  var request = new ModelRequest('Summarize the following conversation concisely, preserving facts, decisions, and open questions.', listOf(tmp.b5o(joinToString(items, '\n', VOID, VOID, VOID, VOID, CompactingThreadMemory$summarize$lambda))), VOID, VOID, VOID, newIdempotencyKey());
  var tmp_0 = generate($this.y80_1, request, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var response = tmp_0;
  // Inline function 'kotlin.check' call
  if (!(response instanceof Completed)) {
    var message = 'summary model did not complete: ' + toString(response);
    throw IllegalStateException.t4(toString(message));
  }
  // Inline function 'kotlin.collections.filterIsInstance' call
  var tmp0 = response.i6f_1;
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = tmp0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element instanceof Message) {
      destination.l(element);
    }
  }
  var tmp_1 = destination;
  // Inline function 'kotlin.text.trim' call
  var this_0 = joinToString(tmp_1, '', VOID, VOID, VOID, VOID, CompactingThreadMemory$summarize$lambda_0);
  // Inline function 'kotlin.text.ifBlank' call
  var this_1 = toString(trim(isCharSequence(this_0) ? this_0 : THROW_CCE()));
  var tmp_2;
  if (isBlank(this_1)) {
    var message_0 = 'summary model returned empty output';
    throw IllegalStateException.t4(toString(message_0));
  } else {
    tmp_2 = this_1;
  }
  return tmp_2;
}
function summarize($this, items, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_summarize__pql4lv.bind(VOID, $this, items), $completion);
}
function notify($this, event) {
  // Inline function 'kotlin.runCatching' call
  var tmp;
  try {
    $this.c81_1.u7z(event);
    // Inline function 'kotlin.Companion.success' call
    tmp = _Result___init__impl__xyqfz8(Unit_instance);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var e = $p;
      // Inline function 'kotlin.Companion.failure' call
      tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
}
function groupIntoTurns($this, items) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var turns = ArrayList.k();
  var _iterator__ex2g4s = items.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    if (isUserTurnBoundary(item) || turns.h1()) {
      // Inline function 'kotlin.collections.plusAssign' call
      var element = mutableListOf([item]);
      turns.l(element);
    } else {
      // Inline function 'kotlin.collections.plusAssign' call
      last(turns).l(item);
    }
  }
  return turns;
}
function CompactingThreadMemory$summarize$lambda(it) {
  return displayText(it);
}
function CompactingThreadMemory$summarize$lambda_0(it) {
  return it.n5t();
}
//region block: post-declaration
initMetadataForClass(ThreadCoordinator, 'ThreadCoordinator', ThreadCoordinator);
initMetadataForInterface(CompactionObserver, 'CompactionObserver');
initMetadataForClass(sam$org_koaks_memory_summarizing_CompactionObserver$0, 'sam$org_koaks_memory_summarizing_CompactionObserver$0', VOID, VOID, [CompactionObserver, FunctionAdapter]);
initMetadataForClass(SummarizingMemoryProvider, 'SummarizingMemoryProvider', VOID, VOID, VOID, [1]);
protoOf(InMemoryAppendMemoryProvider$open$2).a6 = close;
initMetadataForClass(InMemoryAppendMemoryProvider$open$2, VOID, VOID, VOID, [ThreadMemory], [1]);
initMetadataForClass(InMemoryAppendMemoryProvider, 'InMemoryAppendMemoryProvider', InMemoryAppendMemoryProvider, VOID, VOID, [1]);
initMetadataForClass(InMemorySummaryStateStore, 'InMemorySummaryStateStore', InMemorySummaryStateStore, VOID, VOID, [1, 2]);
initMetadataForClass(Started, 'Started');
initMetadataForClass(Completed_0, 'Completed');
initMetadataForClass(Failed, 'Failed');
initMetadataForClass(SummaryCheckpoint, 'SummaryCheckpoint');
initMetadataForClass(CompactingThreadMemory, 'CompactingThreadMemory', VOID, VOID, [ThreadMemory], [1]);
//endregion
//region block: exports
export {
  Completed_0 as Completed2mtbtu49gr00m,
  Failed as Failed1jq287m0zrctq,
  Started as Started1ko4w51qve81z,
  CompactionObserver as CompactionObserver30xzoxxaw78du,
  InMemoryAppendMemoryProvider as InMemoryAppendMemoryProvider36fa6bv0tgc8o,
  InMemorySummaryStateStore as InMemorySummaryStateStore2chhijrm1nln0,
  SummarizingMemoryProvider as SummarizingMemoryProvider29b3hnp93xy7,
  SummaryCheckpoint as SummaryCheckpointbdrwa4y2hyh1,
};
//endregion

//# sourceMappingURL=koaks-koaks-memory-summarizing.mjs.map
