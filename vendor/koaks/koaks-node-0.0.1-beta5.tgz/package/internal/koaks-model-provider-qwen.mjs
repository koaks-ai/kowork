import {
  ChatCompletionsModel2rl4figp5zhty as ChatCompletionsModel,
  ChatCompletionsParams2phuyy1p28jz5 as ChatCompletionsParams,
  normalizeChatCompletionsUrlbu0jml6vp44x as normalizeChatCompletionsUrl,
} from './koaks-model-provider-chat-completions.mjs';
import {
  VOID7hggqo3abtya as VOID,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  toString30pk9tzaqopn as toString,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  equals2au1ep9vhcato as equals,
  Long2qws0ah9gnpki as Long,
  Unit_instance104q5opgivhr8 as Unit_instance,
} from './kotlin-kotlin-stdlib.mjs';
import {
  ModelCapabilities1z2n3zkdibnvb as ModelCapabilities,
  Companion_getInstance3ot1bqjky10hu as Companion_getInstance,
  ModelConfig4o28u6uqe7xk as ModelConfig,
  Support_Supported_getInstance2iy50h3ebt6qe as Support_Supported_getInstance,
  Support_Unsupported_getInstance2l560r5zg87nd as Support_Unsupported_getInstance,
  Support_Unknown_getInstance3blv79i14mlk4 as Support_Unknown_getInstance,
} from './koaks-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class QwenChatModel extends ChatCompletionsModel {
  constructor(config, transport, params, capabilities) {
    params = params === VOID ? new QwenParams() : params;
    capabilities = capabilities === VOID ? new ModelCapabilities() : capabilities;
    super(config, transport, Companion_getInstance().u6d_1, new ChatCompletionsParams(params.y7h_1, params.z7h_1, VOID, params.a7i_1, params.b7i_1, params.c7i_1, params.d7i_1, VOID, params.e7i_1), capabilities);
  }
}
class QwenParams {
  constructor(temperature, maxTokens, topP, stop, presencePenalty, frequencyPenalty, enableThinking) {
    temperature = temperature === VOID ? null : temperature;
    maxTokens = maxTokens === VOID ? null : maxTokens;
    topP = topP === VOID ? null : topP;
    stop = stop === VOID ? null : stop;
    presencePenalty = presencePenalty === VOID ? null : presencePenalty;
    frequencyPenalty = frequencyPenalty === VOID ? null : frequencyPenalty;
    enableThinking = enableThinking === VOID ? null : enableThinking;
    this.y7h_1 = temperature;
    this.z7h_1 = maxTokens;
    this.a7i_1 = topP;
    this.b7i_1 = stop;
    this.c7i_1 = presencePenalty;
    this.d7i_1 = frequencyPenalty;
    this.e7i_1 = enableThinking;
  }
  toString() {
    return 'QwenParams(temperature=' + this.y7h_1 + ', maxTokens=' + this.z7h_1 + ', topP=' + this.a7i_1 + ', stop=' + toString(this.b7i_1) + ', presencePenalty=' + this.c7i_1 + ', frequencyPenalty=' + this.d7i_1 + ', enableThinking=' + this.e7i_1 + ')';
  }
  hashCode() {
    var result = this.y7h_1 == null ? 0 : getNumberHashCode(this.y7h_1);
    result = imul(result, 31) + (this.z7h_1 == null ? 0 : this.z7h_1) | 0;
    result = imul(result, 31) + (this.a7i_1 == null ? 0 : getNumberHashCode(this.a7i_1)) | 0;
    result = imul(result, 31) + (this.b7i_1 == null ? 0 : hashCode(this.b7i_1)) | 0;
    result = imul(result, 31) + (this.c7i_1 == null ? 0 : getNumberHashCode(this.c7i_1)) | 0;
    result = imul(result, 31) + (this.d7i_1 == null ? 0 : getNumberHashCode(this.d7i_1)) | 0;
    result = imul(result, 31) + (this.e7i_1 == null ? 0 : getBooleanHashCode(this.e7i_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof QwenParams))
      return false;
    var tmp0_other_with_cast = other instanceof QwenParams ? other : THROW_CCE();
    if (!equals(this.y7h_1, tmp0_other_with_cast.y7h_1))
      return false;
    if (!(this.z7h_1 == tmp0_other_with_cast.z7h_1))
      return false;
    if (!equals(this.a7i_1, tmp0_other_with_cast.a7i_1))
      return false;
    if (!equals(this.b7i_1, tmp0_other_with_cast.b7i_1))
      return false;
    if (!equals(this.c7i_1, tmp0_other_with_cast.c7i_1))
      return false;
    if (!equals(this.d7i_1, tmp0_other_with_cast.d7i_1))
      return false;
    if (!(this.e7i_1 == tmp0_other_with_cast.e7i_1))
      return false;
    return true;
  }
}
class QwenConfig {
  constructor(baseUrl, apiKey, modelName) {
    this.f7i_1 = baseUrl;
    this.g7i_1 = apiKey;
    this.h7i_1 = modelName;
    this.i7i_1 = null;
    this.j7i_1 = null;
    this.k7i_1 = null;
    this.l7i_1 = null;
    this.m7i_1 = null;
    this.n7i_1 = null;
    this.o7i_1 = null;
    this.p7i_1 = new Long(60000, 0);
    this.q7i_1 = new ModelCapabilities();
  }
  u7i(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new CapabilitiesScope(this.q7i_1);
    block(this_0);
    tmp.q7i_1 = this_0.y7i();
  }
  r7i() {
    return new ModelConfig(normalizeChatCompletionsUrl(this.f7i_1), this.g7i_1, this.h7i_1, VOID, VOID, VOID, VOID, VOID, this.p7i_1);
  }
  s7i() {
    return new QwenParams(this.i7i_1, this.j7i_1, this.k7i_1, this.l7i_1, this.m7i_1, this.n7i_1, this.o7i_1);
  }
  t7i() {
    return this.q7i_1;
  }
}
class CapabilitiesScope {
  constructor(initial) {
    this.v7i_1 = initial.i5o_1.equals(Support_Supported_getInstance());
    this.w7i_1 = initial.j5o_1.equals(Support_Supported_getInstance());
    this.x7i_1 = initial.k5o_1.equals(Support_Supported_getInstance());
  }
  y7i() {
    return new ModelCapabilities(this.v7i_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), this.w7i_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.x7i_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance());
  }
}
//endregion
function qwen(_this__u8e3s4, baseUrl, apiKey, modelName, block) {
  baseUrl = baseUrl === VOID ? 'https://dashscope.aliyuncs.com/compatible-mode' : baseUrl;
  var tmp;
  if (block === VOID) {
    tmp = qwen$lambda;
  } else {
    tmp = block;
  }
  block = tmp;
  // Inline function 'kotlin.apply' call
  var this_0 = new QwenConfig(baseUrl, apiKey, modelName);
  block(this_0);
  var cfg = this_0;
  return _this__u8e3s4.o60(new QwenChatModel(cfg.r7i(), _this__u8e3s4.q60(), cfg.s7i(), cfg.t7i()));
}
function qwen$lambda(_this__u8e3s4) {
  return Unit_instance;
}
//region block: post-declaration
initMetadataForClass(QwenChatModel, 'QwenChatModel', VOID, VOID, VOID, [1]);
initMetadataForClass(QwenParams, 'QwenParams', QwenParams);
initMetadataForClass(QwenConfig, 'QwenConfig');
initMetadataForClass(CapabilitiesScope, 'CapabilitiesScope');
//endregion
//region block: exports
export {
  qwen as qwen3m5zqusvdcxsm,
};
//endregion

//# sourceMappingURL=koaks-model-provider-qwen.mjs.map
