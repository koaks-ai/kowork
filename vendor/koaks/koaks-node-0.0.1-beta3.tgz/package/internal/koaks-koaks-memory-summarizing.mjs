import {
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  Unit_instance104q5opgivhr8 as Unit_instance,
  toList3jhuyej2anx2q as toList,
  to2cs3ny02qtbcb as to,
  ArrayList3it5z8td81qkl as ArrayList,
  drop3na99dw9feawf as drop,
  dropLast1vpiyky649o34 as dropLast,
  flatten2dh4kibw1u0qq as flatten,
  takeLasttm5u17ojwaaq as takeLast,
  listOfvhqybd2zx248 as listOf,
  plus310ted5e4i90h as plus,
  toMutableList20rdgwi7d3cwi as toMutableList,
  VOID7hggqo3abtya as VOID,
  joinToString1cxrrlmo0chqs as joinToString,
  isBlank1dvkhjjvox3p0 as isBlank,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  last1vo29oleiqj36 as last,
  mutableListOf6oorvk2mtdmp as mutableListOf,
  Long2qws0ah9gnpki as Long,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
} from './kotlin-kotlin-stdlib.mjs';
import {
  turnHasSideEffects1mpwjsroa3ywe as turnHasSideEffects,
  shouldRetain150nlxe0gzy8j as shouldRetain,
  isSystem5q4g7p85h8y2 as isSystem,
  ProviderItem17hp0vuxmlwze as ProviderItem,
  ReplayPolicy_Required_getInstance1o7kby0tmyj43 as ReplayPolicy_Required_getInstance,
  Companion_instancelgypg95btxw8 as Companion_instance,
  MemoryView36zuxzo826bia as MemoryView,
  newIdempotencyKey3adur2bjpedyg as newIdempotencyKey,
  ModelRequest2fvlnwc92shgb as ModelRequest,
  generate290swdgdwvcq1 as generate,
  Message1x6kaj8ypdoee as Message,
  isUserTurnBoundary3tbzs28fwfq04 as isUserTurnBoundary,
  displayText2pp0s33rxlm2 as displayText,
  TurnRetention_Interrupted_getInstance1clj3n1yfuiga as TurnRetention_Interrupted_getInstance,
  closeca18uc43m2gy as close,
  ThreadMemory1dswgl9efn3yf as ThreadMemory,
} from './koaks-core.mjs';
import { Mutex16li1l0asjv17 as Mutex } from './kotlinx-coroutines-core.mjs';
//region block: imports
//endregion
//region block: pre-declaration
class SummarizingMemory {
  constructor(maxTokens, model, keepRecentTurns, retention) {
    keepRecentTurns = keepRecentTurns === VOID ? 2 : keepRecentTurns;
    retention = retention === VOID ? TurnRetention_Interrupted_getInstance() : retention;
    this.p7u_1 = maxTokens;
    this.q7u_1 = model;
    this.r7u_1 = keepRecentTurns;
    this.s7u_1 = retention;
    this.t7u_1 = Mutex();
    this.u7u_1 = new Long(0, 0);
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.v7u_1 = ArrayList.k();
    this.w7u_1 = null;
  }
  m68() {
    return this.s7u_1;
  }
  o68(turn, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_commit__is9lbl.bind(VOID, this, turn), $completion);
  }
  n68(query, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_load__qllgda.bind(VOID, this, query), $completion);
  }
}
//endregion
function *_generator_commit__is9lbl($this, turn, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.t7u_1;
  var tmp = this_0.r1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    if (!shouldRetain(turn, $this.s7u_1, turnHasSideEffects(turn))) {
      return Unit_instance;
    }
    $this.v7u_1.c1(turn.v67_1);
    if (!(turn.w67_1 == null))
      $this.w7u_1 = turn.w67_1;
    $this.u7u_1 = $this.u7u_1.z3();
    tmp_0 = to($this.u7u_1, toList($this.v7u_1));
  }finally {
    this_0.c1i(null);
  }
  var snapshotVersion = tmp_0.tl();
  var snapshot = tmp_0.ul();
  if (turn.x67_1.i5y_1 <= $this.p7u_1)
    return Unit_instance;
  // Inline function 'kotlin.collections.takeWhile' call
  var list = ArrayList.k();
  var _iterator__ex2g4s = snapshot.y();
  $l$loop: while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    if (!isSystem(item))
      break $l$loop;
    list.l(item);
  }
  var system = list;
  var rest = drop(snapshot, system.b1());
  var turns = groupIntoTurns($this, rest);
  if (turns.b1() <= $this.r7u_1)
    return Unit_instance;
  var toSummarize = flatten(dropLast(turns, $this.r7u_1));
  var recent = flatten(takeLast(turns, $this.r7u_1));
  // Inline function 'kotlin.collections.filterIsInstance' call
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s_0 = toSummarize.y();
  while (_iterator__ex2g4s_0.z()) {
    var element = _iterator__ex2g4s_0.a1();
    if (element instanceof ProviderItem) {
      destination.l(element);
    }
  }
  // Inline function 'kotlin.collections.filter' call
  // Inline function 'kotlin.collections.filterTo' call
  var destination_0 = ArrayList.k();
  var _iterator__ex2g4s_1 = destination.y();
  while (_iterator__ex2g4s_1.z()) {
    var element_0 = _iterator__ex2g4s_1.a1();
    if (element_0.y5y_1.equals(ReplayPolicy_Required_getInstance())) {
      destination_0.l(element_0);
    }
  }
  var required = destination_0;
  var tmp_1 = summarize($this, toSummarize, $completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  var summary = tmp_1;
  var compacted = plus(plus(plus(system, listOf(Companion_instance.u6d('Summary of earlier conversation:\n' + summary))), required), recent);
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_1 = $this.t7u_1;
  var tmp_2 = this_1.r1i(null, $completion);
  if (tmp_2 === get_COROUTINE_SUSPENDED())
    tmp_2 = yield tmp_2;
  try {
    if ($this.u7u_1.equals(snapshotVersion)) {
      $this.v7u_1 = toMutableList(compacted);
      $this.w7u_1 = null;
      $this.u7u_1 = $this.u7u_1.z3();
    }
  }finally {
    this_1.c1i(null);
  }
  return Unit_instance;
}
function *_generator_load__qllgda($this, query, $completion) {
  // Inline function 'kotlinx.coroutines.sync.withLock' call
  var this_0 = $this.t7u_1;
  var tmp = this_0.r1i(null, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0;
  try {
    tmp_0 = new MemoryView(toList($this.v7u_1), $this.w7u_1);
  }finally {
    this_0.c1i(null);
  }
  return tmp_0;
}
function *_generator_summarize__pql4lv($this, items, $completion) {
  var transcript = joinToString(items, '\n', VOID, VOID, VOID, VOID, SummarizingMemory$summarize$lambda);
  var request = new ModelRequest('Summarize the following conversation concisely, preserving facts, decisions, and open questions.', listOf(Companion_instance.o5o(transcript)), VOID, VOID, VOID, newIdempotencyKey());
  var tmp = generate($this.q7u_1, request, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var response = tmp;
  // Inline function 'kotlin.collections.filterIsInstance' call
  var tmp0 = response.l60();
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = tmp0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element instanceof Message) {
      destination.l(element);
    }
  }
  var tmp_0 = destination;
  // Inline function 'kotlin.text.ifBlank' call
  var this_0 = joinToString(tmp_0, '', VOID, VOID, VOID, VOID, SummarizingMemory$summarize$lambda_0);
  var tmp_1;
  if (isBlank(this_0)) {
    // Inline function 'kotlin.collections.filterIsInstance' call
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination_0 = ArrayList.k();
    var _iterator__ex2g4s_0 = items.y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      if (element_0 instanceof Message) {
        destination_0.l(element_0);
      }
    }
    var tmp_2 = destination_0;
    tmp_1 = joinToString(tmp_2, '', VOID, VOID, VOID, VOID, SummarizingMemory$summarize$lambda_1);
  } else {
    tmp_1 = this_0;
  }
  var text = tmp_1;
  // Inline function 'kotlin.text.ifBlank' call
  var tmp_3;
  if (isBlank(text)) {
    tmp_3 = '(summary unavailable)';
  } else {
    tmp_3 = text;
  }
  return tmp_3;
}
function summarize($this, items, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_summarize__pql4lv.bind(VOID, $this, items), $completion);
}
function groupIntoTurns($this, items) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var turns = ArrayList.k();
  var _iterator__ex2g4s = items.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    if (isUserTurnBoundary(item) || turns.h1()) {
      // Inline function 'kotlin.collections.plusAssign' call
      var element = mutableListOf([item]);
      turns.l(element);
    } else {
      // Inline function 'kotlin.collections.plusAssign' call
      last(turns).l(item);
    }
  }
  return turns;
}
function SummarizingMemory$summarize$lambda(it) {
  return displayText(it);
}
function SummarizingMemory$summarize$lambda_0(it) {
  return it.m5t();
}
function SummarizingMemory$summarize$lambda_1(it) {
  return it.m5t();
}
//region block: post-declaration
protoOf(SummarizingMemory).a6 = close;
initMetadataForClass(SummarizingMemory, 'SummarizingMemory', VOID, VOID, [ThreadMemory], [1]);
//endregion
//region block: exports
export {
  SummarizingMemory as SummarizingMemory2rp0rxquacaz1,
};
//endregion

//# sourceMappingURL=koaks-koaks-memory-summarizing.mjs.map
