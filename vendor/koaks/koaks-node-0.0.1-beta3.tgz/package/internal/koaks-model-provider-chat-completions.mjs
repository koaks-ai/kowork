import {
  VOID7hggqo3abtya as VOID,
  StringBuildermazzzhj6kkai as StringBuilder,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  emptyList1g2z5xcrvp2zy as emptyList,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  listOfvhqybd2zx248 as listOf,
  equals2au1ep9vhcato as equals,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  isInterface3d6p8outrmvmk as isInterface,
  Comparator2b3maoeh98xtg as Comparator,
  hashCodeq5arwsb9dgti as hashCode,
  compareValues1n2ayl87ihzfk as compareValues,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  ArrayList3it5z8td81qkl as ArrayList,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  isBlank1dvkhjjvox3p0 as isBlank,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  Unit_instance104q5opgivhr8 as Unit_instance,
  plus310ted5e4i90h as plus,
  firstOrNull1982767dljvdy as firstOrNull,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  sortedWith2csnbbb21k0lg as sortedWith,
  toList3jhuyej2anx2q as toList,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  toString1pkumu07cwy4m as toString,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  trimEndvvzjdhan75g as trimEnd,
  endsWith3cq61xxngobwh as endsWith,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  toString30pk9tzaqopn as toString_0,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  get_lastIndex1yw0x4k50k51w as get_lastIndex,
  plus20p0vtfmu0596 as plus_0,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  createThis2j2avj17cvnv2 as createThis,
} from './kotlin-kotlin-stdlib.mjs';
import {
  Companion_instance13097inxmcdi as Companion_instance_0,
  Failed2mkg32d93x5tt as Failed,
  Finished4z9e5g7v1wyk as Finished,
  Companion_getInstance2m4xts4fuklfa as Companion_getInstance,
  ModelErrori9ofbqyilwwf as ModelError,
  HttpError1wj82nej166el as HttpError,
  Body2ccosqk3y8ycb as Body,
  Ndjson1kkk3x9modr28 as Ndjson,
  Sset7uvtqde4kyu as Sse,
  JsonUtil_getInstance3itlrleq4m1cs as JsonUtil_getInstance,
  Started1sf5a44qjgp0u as Started,
  _ProviderId___get_value__impl__xo1tux1l8qcslmantkx as _ProviderId___get_value__impl__xo1tux,
  Usage3sdv1daz6y20z as Usage,
  ReasoningDeltaytmmln995w27 as ReasoningDelta,
  TextDeltaq9h7728thclc as TextDelta,
  _ItemRef___get_value__impl__fpjuyb3vqbahagzpip9 as _ItemRef___get_value__impl__fpjuyb,
  ToolCallDelta1owom9vbem28s as ToolCallDelta,
  Companion_instancelgypg95btxw8 as Companion_instance_1,
  ProviderScopedId2kn7so5x8kdlf as ProviderScopedId,
  ToolCallsfyoaxshhyk as ToolCall,
  ToolCallCompleted225u0jsfjmco7 as ToolCallCompleted,
  Completedf7bahq5rqxjz as Completed,
  ChatModel1ekuxcd3gk3yy as ChatModel,
  ModelCapabilities1z2n3zkdibnvb as ModelCapabilities,
  HttpMethod_POST_getInstance2vunzl2e30rwd as HttpMethod_POST_getInstance,
  authHeaders3pbiyo76b6dd9 as authHeaders,
  Framing_Sse_getInstance1id84wnv2jikt as Framing_Sse_getInstance,
  timeoutsvuf8aepeqg28 as timeouts,
  WireCall3namx761k5vmg as WireCall,
  ensureDroppable3mu5lhcnsp146 as ensureDroppable,
  ProviderItem17hp0vuxmlwze as ProviderItem,
  ReasoningSummary2dl0lxzty5z0 as ReasoningSummary,
  ToolCall27jatgdodcelb as ToolCall_0,
  rawFor3526oyw9fazp7 as rawFor,
  ToolResult2fndzcq38kgpy as ToolResult,
  Message1x6kaj8ypdoee as Message,
  JsonSchema1bzd59uqo2uv as JsonSchema,
  JsonObject_instance30hvkp8z8mfx9 as JsonObject_instance,
  Text_instance936fuxqirkv3 as Text_instance,
} from './koaks-core.mjs';
import {
  JsonObjectBuilder2nl6rv6vdayuk as JsonObjectBuilder,
  JsonPrimitiveolttw629wj53 as JsonPrimitive,
  JsonPrimitive1xkjzc5d7ihuv as JsonPrimitive_0,
  JsonObjectSerializer_getInstance197qdg6ernwdp as JsonObjectSerializer_getInstance,
} from './kotlinx-serialization-kotlinx-serialization-json.mjs';
import {
  ArrayListSerializer7k5wnrulb3y6 as ArrayListSerializer,
  StringSerializer_getInstance1k1oz5j50sfik as StringSerializer_getInstance,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  BooleanSerializer_getInstancet3wtk7fl7i4f as BooleanSerializer_getInstance,
  DoubleSerializer_getInstance2avi1jm48x8le as DoubleSerializer_getInstance,
  IntSerializer_getInstance9scrtcljaiv6 as IntSerializer_getInstance,
  UnknownFieldExceptiona60e3a6v1xqo as UnknownFieldException,
  get_nullable197rfua9r7fsz as get_nullable,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class ToolAcc {
  constructor(id, name, args, ref) {
    id = id === VOID ? null : id;
    name = name === VOID ? StringBuilder.v() : name;
    args = args === VOID ? StringBuilder.v() : args;
    ref = ref === VOID ? Companion_instance_0.k60('call') : ref;
    this.u77_1 = id;
    this.v77_1 = name;
    this.w77_1 = args;
    this.x77_1 = ref;
  }
}
class sam$kotlin_Comparator$0 {
  constructor(function_0) {
    this.i78_1 = function_0;
  }
  vi(a, b) {
    return this.i78_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.i78_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class ChatCompletionsDecoder {
  constructor(providerId) {
    this.y77_1 = providerId;
    this.z77_1 = LinkedHashMap.hc();
    this.a78_1 = StringBuilder.v();
    this.b78_1 = Companion_instance_0.k60('msg');
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.c78_1 = ArrayList.k();
    this.d78_1 = Companion_getInstance().g5s_1;
    this.e78_1 = null;
    this.f78_1 = null;
    this.g78_1 = false;
    this.h78_1 = false;
  }
  z6f(frame) {
    var tmp;
    if (frame instanceof Sse) {
      tmp = frame.e6m_1;
    } else {
      if (frame instanceof Ndjson) {
        tmp = frame.i6m_1;
      } else {
        if (frame instanceof Body) {
          tmp = frame.h6m_1;
        } else {
          if (frame instanceof HttpError) {
            this.f78_1 = new ModelError('HTTP ' + frame.i6l_1 + ': ' + frame.k6l_1, frame.i6l_1 === 429 || frame.i6l_1 >= 500);
            return finishFailed(this);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
    var json = tmp;
    if (isBlank(json) || json === '[DONE]')
      return emptyList();
    // Inline function 'kotlin.runCatching' call
    var tmp_0;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = JsonUtil_getInstance().e6f(json, Companion_getInstance_15().r3o());
      tmp_0 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_1;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    // Inline function 'kotlin.getOrElse' call
    var this_0 = tmp_0;
    var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
    var tmp_2;
    if (exception == null) {
      var tmp_3 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_2 = (tmp_3 == null ? true : !(tmp_3 == null)) ? tmp_3 : THROW_CCE();
    } else {
      return emptyList();
    }
    var chunk = tmp_2;
    return this.k78(chunk);
  }
  k78(chunk) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    var tmp0_safe_receiver = chunk.l78_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.e78_1 = tmp0_safe_receiver;
    }
    if (!this.h78_1 && !(this.e78_1 == null)) {
      this.h78_1 = true;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = new Started(this.e78_1);
      events.l(element);
    }
    var tmp1_safe_receiver = chunk.p78_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var tmp = this;
      var tmp0_elvis_lhs = tmp1_safe_receiver.s78_1;
      tmp.f78_1 = new ModelError(tmp0_elvis_lhs == null ? _ProviderId___get_value__impl__xo1tux(this.y77_1) + ' error ' + tmp1_safe_receiver.q78_1 : tmp0_elvis_lhs, false);
      return plus(events, finishFailed(this));
    }
    var tmp2_safe_receiver = chunk.o78_1;
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      var tmp_0 = this;
      var tmp0_elvis_lhs_0 = tmp2_safe_receiver.u78_1;
      var tmp_1 = tmp0_elvis_lhs_0 == null ? 0 : tmp0_elvis_lhs_0;
      var tmp1_elvis_lhs = tmp2_safe_receiver.v78_1;
      var tmp_2 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
      var tmp2_elvis_lhs = tmp2_safe_receiver.w78_1;
      var tmp_3 = tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs;
      var tmp3_safe_receiver = tmp2_safe_receiver.x78_1;
      var tmp4_elvis_lhs = tmp3_safe_receiver == null ? null : tmp3_safe_receiver.z78_1;
      var tmp_4 = tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs;
      var tmp5_safe_receiver = tmp2_safe_receiver.y78_1;
      var tmp6_elvis_lhs = tmp5_safe_receiver == null ? null : tmp5_safe_receiver.a79_1;
      tmp_0.d78_1 = new Usage(tmp_1, tmp_2, tmp_3, tmp_4, tmp6_elvis_lhs == null ? 0 : tmp6_elvis_lhs);
    }
    var tmp3_safe_receiver_0 = chunk.n78_1;
    var tmp4_safe_receiver = tmp3_safe_receiver_0 == null ? null : firstOrNull(tmp3_safe_receiver_0);
    var tmp5_elvis_lhs = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.f79();
    var tmp_5;
    if (tmp5_elvis_lhs == null) {
      return events;
    } else {
      tmp_5 = tmp5_elvis_lhs;
    }
    var payload = tmp_5;
    var tmp6_safe_receiver = payload.i79_1;
    if (tmp6_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.text.isNotEmpty' call
      if (charSequenceLength(tmp6_safe_receiver) > 0) {
        // Inline function 'kotlin.collections.plusAssign' call
        var element_0 = new ReasoningDelta(tmp6_safe_receiver);
        events.l(element_0);
      }
    }
    var tmp7_safe_receiver = payload.h79_1;
    if (tmp7_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.text.isNotEmpty' call
      if (charSequenceLength(tmp7_safe_receiver) > 0) {
        this.a78_1.tb(tmp7_safe_receiver);
        // Inline function 'kotlin.collections.plusAssign' call
        var element_1 = new TextDelta(tmp7_safe_receiver, this.b78_1);
        events.l(element_1);
      }
    }
    var tmp8_safe_receiver = payload.j79_1;
    if (tmp8_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = tmp8_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var element_2 = _iterator__ex2g4s.a1();
        var tmp0 = this.z77_1;
        // Inline function 'kotlin.collections.getOrPut' call
        var key = element_2.l79_1;
        var value = tmp0.h3(key);
        var tmp_6;
        if (value == null) {
          var answer = new ToolAcc();
          tmp0.k3(key, answer);
          tmp_6 = answer;
        } else {
          tmp_6 = value;
        }
        var acc = tmp_6;
        var tmp0_safe_receiver_0 = element_2.m79_1;
        if (tmp0_safe_receiver_0 == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          if (acc.u77_1 == null)
            acc.u77_1 = tmp0_safe_receiver_0;
        }
        var tmp1_safe_receiver_0 = element_2.o79_1;
        var tmp2_safe_receiver_0 = tmp1_safe_receiver_0 == null ? null : tmp1_safe_receiver_0.p79_1;
        if (tmp2_safe_receiver_0 == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          acc.v77_1.tb(tmp2_safe_receiver_0);
        }
        var tmp3_safe_receiver_1 = element_2.o79_1;
        var tmp4_safe_receiver_0 = tmp3_safe_receiver_1 == null ? null : tmp3_safe_receiver_1.q79_1;
        if (tmp4_safe_receiver_0 == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          acc.w77_1.tb(tmp4_safe_receiver_0);
        }
        var tmp5_elvis_lhs_0 = element_2.m79_1;
        var tmp6_elvis_lhs_0 = tmp5_elvis_lhs_0 == null ? acc.u77_1 : tmp5_elvis_lhs_0;
        var tmp_7 = tmp6_elvis_lhs_0 == null ? _ItemRef___get_value__impl__fpjuyb(acc.x77_1) : tmp6_elvis_lhs_0;
        var tmp7_safe_receiver_0 = element_2.o79_1;
        var tmp_8 = tmp7_safe_receiver_0 == null ? null : tmp7_safe_receiver_0.p79_1;
        var tmp8_safe_receiver_0 = element_2.o79_1;
        // Inline function 'kotlin.collections.plusAssign' call
        var element_3 = new ToolCallDelta(tmp_7, element_2.l79_1, tmp_8, tmp8_safe_receiver_0 == null ? null : tmp8_safe_receiver_0.q79_1, acc.x77_1);
        events.l(element_3);
      }
    }
    return events;
  }
  g6g() {
    if (this.g78_1)
      return emptyList();
    if (!(this.f78_1 == null))
      return finishFailed(this);
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    // Inline function 'kotlin.text.isNotEmpty' call
    var this_0 = this.a78_1;
    if (charSequenceLength(this_0) > 0) {
      var tmp1 = this.c78_1;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = Companion_instance_1.t5t(this.a78_1.toString(), this.b78_1);
      tmp1.l(element);
    }
    // Inline function 'kotlin.collections.sortedBy' call
    var this_1 = this.z77_1.l1();
    // Inline function 'kotlin.comparisons.compareBy' call
    var tmp = ChatCompletionsDecoder$finish$lambda;
    var tmp$ret$3 = new sam$kotlin_Comparator$0(tmp);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = sortedWith(this_1, tmp$ret$3).y();
    while (_iterator__ex2g4s.z()) {
      var element_0 = _iterator__ex2g4s.a1();
      $l$block: {
        // Inline function 'kotlin.collections.component2' call
        var acc = element_0.n1();
        var tmp_0;
        var tmp_1;
        // Inline function 'kotlin.text.isEmpty' call
        var this_2 = acc.v77_1;
        if (charSequenceLength(this_2) === 0) {
          // Inline function 'kotlin.text.isEmpty' call
          var this_3 = acc.w77_1;
          tmp_1 = charSequenceLength(this_3) === 0;
        } else {
          tmp_1 = false;
        }
        if (tmp_1) {
          tmp_0 = acc.u77_1 == null;
        } else {
          tmp_0 = false;
        }
        if (tmp_0) {
          break $l$block;
        }
        var tmp_2 = _ItemRef___get_value__impl__fpjuyb(acc.x77_1);
        var tmp_3 = acc.v77_1.toString();
        // Inline function 'kotlin.text.ifBlank' call
        var this_4 = acc.w77_1.toString();
        var tmp_4;
        if (isBlank(this_4)) {
          tmp_4 = '{}';
        } else {
          tmp_4 = this_4;
        }
        var tmp_5 = tmp_4;
        var tmp0_safe_receiver = acc.u77_1;
        var tmp_6;
        if (tmp0_safe_receiver == null) {
          tmp_6 = null;
        } else {
          // Inline function 'kotlin.let' call
          tmp_6 = new ProviderScopedId(this.y77_1, tmp0_safe_receiver);
        }
        var call = new ToolCall(tmp_2, tmp_3, tmp_5, tmp_6);
        var tmp6 = this.c78_1;
        // Inline function 'kotlin.collections.plusAssign' call
        var element_1 = call.o60();
        tmp6.l(element_1);
        // Inline function 'kotlin.collections.plusAssign' call
        var element_2 = new ToolCallCompleted(call);
        events.l(element_2);
      }
    }
    this.g78_1 = true;
    // Inline function 'kotlin.collections.plusAssign' call
    var element_3 = new Finished(new Completed(this.e78_1, toList(this.c78_1), this.d78_1));
    events.l(element_3);
    return events;
  }
}
class ChatCompletionsModel extends ChatModel {
  constructor(config, transport, providerId, params, capabilities) {
    params = params === VOID ? new ChatCompletionsParams() : params;
    capabilities = capabilities === VOID ? new ModelCapabilities() : capabilities;
    super(config, transport);
    this.t79_1 = providerId;
    this.u79_1 = params;
    this.v79_1 = capabilities;
  }
  a5p() {
    return this.v79_1;
  }
  y1s() {
    return new ChatCompletionsDecoder(this.t79_1);
  }
  j6g(req) {
    var body = JsonUtil_getInstance().d6f(this.w79(req), Companion_getInstance_0().r3o());
    return new WireCall(HttpMethod_POST_getInstance(), this.c6g_1.n6g_1, authHeaders(this.c6g_1), body, Framing_Sse_getInstance(), req.g5y_1, timeouts(this.c6g_1), this.c6g_1.w6g_1, this.c6g_1.x6g_1);
  }
  w79(req) {
    var tmp;
    switch (this.a5p().v5o_1.o3_1) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        tmp = null;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    var parallel = tmp;
    var tmp_0 = toChatMessages(req, this.t79_1);
    // Inline function 'kotlin.takeIf' call
    var this_0 = req.d5y_1;
    var tmp_1;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this_0.h1()) {
      tmp_1 = this_0;
    } else {
      tmp_1 = null;
    }
    var tmp1_safe_receiver = tmp_1;
    var tmp_2;
    if (tmp1_safe_receiver == null) {
      tmp_2 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(tmp1_safe_receiver, 10));
      var _iterator__ex2g4s = tmp1_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$3 = toChatTool(item);
        destination.l(tmp$ret$3);
      }
      tmp_2 = destination;
    }
    var tmp_3 = tmp_2;
    var tmp_4;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!req.d5y_1.h1()) {
      tmp_4 = parallel;
    } else {
      tmp_4 = null;
    }
    return new ChatCompletionsRequest(this.c6g_1.p6g_1, tmp_0, tmp_3, tmp_4, true, new ChatStreamOptions(true), this.u79_1.y79_1, this.u79_1.z79_1, this.u79_1.a7a_1, this.u79_1.b7a_1, this.u79_1.c7a_1, this.u79_1.d7a_1, this.u79_1.e7a_1, this.u79_1.f7a_1, this.u79_1.g7a_1, toResponseFormat(req.e5y_1));
  }
}
class ChatCompletionsParams {
  constructor(temperature, maxTokens, maxCompletionTokens, topP, stop, presencePenalty, frequencyPenalty, reasoningEffort, enableThinking) {
    temperature = temperature === VOID ? null : temperature;
    maxTokens = maxTokens === VOID ? null : maxTokens;
    maxCompletionTokens = maxCompletionTokens === VOID ? null : maxCompletionTokens;
    topP = topP === VOID ? null : topP;
    stop = stop === VOID ? null : stop;
    presencePenalty = presencePenalty === VOID ? null : presencePenalty;
    frequencyPenalty = frequencyPenalty === VOID ? null : frequencyPenalty;
    reasoningEffort = reasoningEffort === VOID ? null : reasoningEffort;
    enableThinking = enableThinking === VOID ? null : enableThinking;
    this.y79_1 = temperature;
    this.z79_1 = maxTokens;
    this.a7a_1 = maxCompletionTokens;
    this.b7a_1 = topP;
    this.c7a_1 = stop;
    this.d7a_1 = presencePenalty;
    this.e7a_1 = frequencyPenalty;
    this.f7a_1 = reasoningEffort;
    this.g7a_1 = enableThinking;
  }
  toString() {
    return 'ChatCompletionsParams(temperature=' + this.y79_1 + ', maxTokens=' + this.z79_1 + ', maxCompletionTokens=' + this.a7a_1 + ', topP=' + this.b7a_1 + ', stop=' + toString_0(this.c7a_1) + ', presencePenalty=' + this.d7a_1 + ', frequencyPenalty=' + this.e7a_1 + ', reasoningEffort=' + this.f7a_1 + ', enableThinking=' + this.g7a_1 + ')';
  }
  hashCode() {
    var result = this.y79_1 == null ? 0 : getNumberHashCode(this.y79_1);
    result = imul(result, 31) + (this.z79_1 == null ? 0 : this.z79_1) | 0;
    result = imul(result, 31) + (this.a7a_1 == null ? 0 : this.a7a_1) | 0;
    result = imul(result, 31) + (this.b7a_1 == null ? 0 : getNumberHashCode(this.b7a_1)) | 0;
    result = imul(result, 31) + (this.c7a_1 == null ? 0 : hashCode(this.c7a_1)) | 0;
    result = imul(result, 31) + (this.d7a_1 == null ? 0 : getNumberHashCode(this.d7a_1)) | 0;
    result = imul(result, 31) + (this.e7a_1 == null ? 0 : getNumberHashCode(this.e7a_1)) | 0;
    result = imul(result, 31) + (this.f7a_1 == null ? 0 : getStringHashCode(this.f7a_1)) | 0;
    result = imul(result, 31) + (this.g7a_1 == null ? 0 : getBooleanHashCode(this.g7a_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatCompletionsParams))
      return false;
    var tmp0_other_with_cast = other instanceof ChatCompletionsParams ? other : THROW_CCE();
    if (!equals(this.y79_1, tmp0_other_with_cast.y79_1))
      return false;
    if (!(this.z79_1 == tmp0_other_with_cast.z79_1))
      return false;
    if (!(this.a7a_1 == tmp0_other_with_cast.a7a_1))
      return false;
    if (!equals(this.b7a_1, tmp0_other_with_cast.b7a_1))
      return false;
    if (!equals(this.c7a_1, tmp0_other_with_cast.c7a_1))
      return false;
    if (!equals(this.d7a_1, tmp0_other_with_cast.d7a_1))
      return false;
    if (!equals(this.e7a_1, tmp0_other_with_cast.e7a_1))
      return false;
    if (!(this.f7a_1 == tmp0_other_with_cast.f7a_1))
      return false;
    if (!(this.g7a_1 == tmp0_other_with_cast.g7a_1))
      return false;
    return true;
  }
}
class Companion {
  constructor() {
    Companion_instance_2 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_1 = lazy(tmp_0, ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba);
    var tmp_2 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_3 = lazy(tmp_2, ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba_0);
    var tmp_4 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.x79_1 = [null, tmp_1, tmp_3, null, null, null, null, null, null, null, lazy(tmp_4, ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba_1), null, null, null, null, null];
  }
  r3o() {
    return $serializer_getInstance();
  }
}
class $serializer {
  constructor() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsRequest', this, 16);
    tmp0_serialDesc.u25('model', false);
    tmp0_serialDesc.u25('messages', false);
    tmp0_serialDesc.u25('tools', true);
    tmp0_serialDesc.u25('parallel_tool_calls', true);
    tmp0_serialDesc.u25('stream', true);
    tmp0_serialDesc.u25('stream_options', true);
    tmp0_serialDesc.u25('temperature', true);
    tmp0_serialDesc.u25('max_tokens', true);
    tmp0_serialDesc.u25('max_completion_tokens', true);
    tmp0_serialDesc.u25('top_p', true);
    tmp0_serialDesc.u25('stop', true);
    tmp0_serialDesc.u25('presence_penalty', true);
    tmp0_serialDesc.u25('frequency_penalty', true);
    tmp0_serialDesc.u25('reasoning_effort', true);
    tmp0_serialDesc.u25('enable_thinking', true);
    tmp0_serialDesc.u25('response_format', true);
    this.m7a_1 = tmp0_serialDesc;
  }
  n7a(encoder, value) {
    var tmp0_desc = this.m7a_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_0().x79_1;
    tmp1_output.v1z(tmp0_desc, 0, value.o7a_1);
    tmp1_output.x1z(tmp0_desc, 1, tmp2_cached[1].n1(), value.p7a_1);
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.q7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.q7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.r7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, BooleanSerializer_getInstance(), value.r7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.s7a_1 === true)) {
      tmp1_output.n1z(tmp0_desc, 4, value.s7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 5) ? true : !(value.t7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 5, $serializer_getInstance_2(), value.t7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 6) ? true : !(value.u7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 6, DoubleSerializer_getInstance(), value.u7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 7) ? true : !(value.v7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 7, IntSerializer_getInstance(), value.v7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 8) ? true : !(value.w7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 8, IntSerializer_getInstance(), value.w7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 9) ? true : !(value.x7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 9, DoubleSerializer_getInstance(), value.x7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 10) ? true : !(value.y7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 10, tmp2_cached[10].n1(), value.y7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 11) ? true : !(value.z7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 11, DoubleSerializer_getInstance(), value.z7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 12) ? true : !(value.a7b_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 12, DoubleSerializer_getInstance(), value.a7b_1);
    }
    if (tmp1_output.d20(tmp0_desc, 13) ? true : !(value.b7b_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 13, StringSerializer_getInstance(), value.b7b_1);
    }
    if (tmp1_output.d20(tmp0_desc, 14) ? true : !(value.c7b_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 14, BooleanSerializer_getInstance(), value.c7b_1);
    }
    if (tmp1_output.d20(tmp0_desc, 15) ? true : !(value.d7b_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 15, JsonObjectSerializer_getInstance(), value.d7b_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.n7a(encoder, value instanceof ChatCompletionsRequest ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.m7a_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = false;
    var tmp9_local5 = null;
    var tmp10_local6 = null;
    var tmp11_local7 = null;
    var tmp12_local8 = null;
    var tmp13_local9 = null;
    var tmp14_local10 = null;
    var tmp15_local11 = null;
    var tmp16_local12 = null;
    var tmp17_local13 = null;
    var tmp18_local14 = null;
    var tmp19_local15 = null;
    var tmp20_input = decoder.f1y(tmp0_desc);
    var tmp21_cached = Companion_getInstance_0().x79_1;
    if (tmp20_input.v1y()) {
      tmp4_local0 = tmp20_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp20_input.r1y(tmp0_desc, 1, tmp21_cached[1].n1(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp20_input.t1y(tmp0_desc, 2, tmp21_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp20_input.t1y(tmp0_desc, 3, BooleanSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp20_input.h1y(tmp0_desc, 4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp20_input.t1y(tmp0_desc, 5, $serializer_getInstance_2(), tmp9_local5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp20_input.t1y(tmp0_desc, 6, DoubleSerializer_getInstance(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
      tmp11_local7 = tmp20_input.t1y(tmp0_desc, 7, IntSerializer_getInstance(), tmp11_local7);
      tmp3_bitMask0 = tmp3_bitMask0 | 128;
      tmp12_local8 = tmp20_input.t1y(tmp0_desc, 8, IntSerializer_getInstance(), tmp12_local8);
      tmp3_bitMask0 = tmp3_bitMask0 | 256;
      tmp13_local9 = tmp20_input.t1y(tmp0_desc, 9, DoubleSerializer_getInstance(), tmp13_local9);
      tmp3_bitMask0 = tmp3_bitMask0 | 512;
      tmp14_local10 = tmp20_input.t1y(tmp0_desc, 10, tmp21_cached[10].n1(), tmp14_local10);
      tmp3_bitMask0 = tmp3_bitMask0 | 1024;
      tmp15_local11 = tmp20_input.t1y(tmp0_desc, 11, DoubleSerializer_getInstance(), tmp15_local11);
      tmp3_bitMask0 = tmp3_bitMask0 | 2048;
      tmp16_local12 = tmp20_input.t1y(tmp0_desc, 12, DoubleSerializer_getInstance(), tmp16_local12);
      tmp3_bitMask0 = tmp3_bitMask0 | 4096;
      tmp17_local13 = tmp20_input.t1y(tmp0_desc, 13, StringSerializer_getInstance(), tmp17_local13);
      tmp3_bitMask0 = tmp3_bitMask0 | 8192;
      tmp18_local14 = tmp20_input.t1y(tmp0_desc, 14, BooleanSerializer_getInstance(), tmp18_local14);
      tmp3_bitMask0 = tmp3_bitMask0 | 16384;
      tmp19_local15 = tmp20_input.t1y(tmp0_desc, 15, JsonObjectSerializer_getInstance(), tmp19_local15);
      tmp3_bitMask0 = tmp3_bitMask0 | 32768;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp20_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp20_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp20_input.r1y(tmp0_desc, 1, tmp21_cached[1].n1(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp20_input.t1y(tmp0_desc, 2, tmp21_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp20_input.t1y(tmp0_desc, 3, BooleanSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp20_input.h1y(tmp0_desc, 4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp20_input.t1y(tmp0_desc, 5, $serializer_getInstance_2(), tmp9_local5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp20_input.t1y(tmp0_desc, 6, DoubleSerializer_getInstance(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          case 7:
            tmp11_local7 = tmp20_input.t1y(tmp0_desc, 7, IntSerializer_getInstance(), tmp11_local7);
            tmp3_bitMask0 = tmp3_bitMask0 | 128;
            break;
          case 8:
            tmp12_local8 = tmp20_input.t1y(tmp0_desc, 8, IntSerializer_getInstance(), tmp12_local8);
            tmp3_bitMask0 = tmp3_bitMask0 | 256;
            break;
          case 9:
            tmp13_local9 = tmp20_input.t1y(tmp0_desc, 9, DoubleSerializer_getInstance(), tmp13_local9);
            tmp3_bitMask0 = tmp3_bitMask0 | 512;
            break;
          case 10:
            tmp14_local10 = tmp20_input.t1y(tmp0_desc, 10, tmp21_cached[10].n1(), tmp14_local10);
            tmp3_bitMask0 = tmp3_bitMask0 | 1024;
            break;
          case 11:
            tmp15_local11 = tmp20_input.t1y(tmp0_desc, 11, DoubleSerializer_getInstance(), tmp15_local11);
            tmp3_bitMask0 = tmp3_bitMask0 | 2048;
            break;
          case 12:
            tmp16_local12 = tmp20_input.t1y(tmp0_desc, 12, DoubleSerializer_getInstance(), tmp16_local12);
            tmp3_bitMask0 = tmp3_bitMask0 | 4096;
            break;
          case 13:
            tmp17_local13 = tmp20_input.t1y(tmp0_desc, 13, StringSerializer_getInstance(), tmp17_local13);
            tmp3_bitMask0 = tmp3_bitMask0 | 8192;
            break;
          case 14:
            tmp18_local14 = tmp20_input.t1y(tmp0_desc, 14, BooleanSerializer_getInstance(), tmp18_local14);
            tmp3_bitMask0 = tmp3_bitMask0 | 16384;
            break;
          case 15:
            tmp19_local15 = tmp20_input.t1y(tmp0_desc, 15, JsonObjectSerializer_getInstance(), tmp19_local15);
            tmp3_bitMask0 = tmp3_bitMask0 | 32768;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp20_input.g1y(tmp0_desc);
    return ChatCompletionsRequest.e7b(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, tmp12_local8, tmp13_local9, tmp14_local10, tmp15_local11, tmp16_local12, tmp17_local13, tmp18_local14, tmp19_local15, null);
  }
  w1t() {
    return this.m7a_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_0().x79_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), tmp0_cached[1].n1(), get_nullable(tmp0_cached[2].n1()), get_nullable(BooleanSerializer_getInstance()), BooleanSerializer_getInstance(), get_nullable($serializer_getInstance_2()), get_nullable(DoubleSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(tmp0_cached[10].n1()), get_nullable(DoubleSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(BooleanSerializer_getInstance()), get_nullable(JsonObjectSerializer_getInstance())];
  }
}
class ChatCompletionsRequest {
  constructor(model, messages, tools, parallelToolCalls, stream, streamOptions, temperature, maxTokens, maxCompletionTokens, topP, stop, presencePenalty, frequencyPenalty, reasoningEffort, enableThinking, responseFormat) {
    Companion_getInstance_0();
    tools = tools === VOID ? null : tools;
    parallelToolCalls = parallelToolCalls === VOID ? null : parallelToolCalls;
    stream = stream === VOID ? true : stream;
    streamOptions = streamOptions === VOID ? null : streamOptions;
    temperature = temperature === VOID ? null : temperature;
    maxTokens = maxTokens === VOID ? null : maxTokens;
    maxCompletionTokens = maxCompletionTokens === VOID ? null : maxCompletionTokens;
    topP = topP === VOID ? null : topP;
    stop = stop === VOID ? null : stop;
    presencePenalty = presencePenalty === VOID ? null : presencePenalty;
    frequencyPenalty = frequencyPenalty === VOID ? null : frequencyPenalty;
    reasoningEffort = reasoningEffort === VOID ? null : reasoningEffort;
    enableThinking = enableThinking === VOID ? null : enableThinking;
    responseFormat = responseFormat === VOID ? null : responseFormat;
    this.o7a_1 = model;
    this.p7a_1 = messages;
    this.q7a_1 = tools;
    this.r7a_1 = parallelToolCalls;
    this.s7a_1 = stream;
    this.t7a_1 = streamOptions;
    this.u7a_1 = temperature;
    this.v7a_1 = maxTokens;
    this.w7a_1 = maxCompletionTokens;
    this.x7a_1 = topP;
    this.y7a_1 = stop;
    this.z7a_1 = presencePenalty;
    this.a7b_1 = frequencyPenalty;
    this.b7b_1 = reasoningEffort;
    this.c7b_1 = enableThinking;
    this.d7b_1 = responseFormat;
  }
  toString() {
    return 'ChatCompletionsRequest(model=' + this.o7a_1 + ', messages=' + toString(this.p7a_1) + ', tools=' + toString_0(this.q7a_1) + ', parallelToolCalls=' + this.r7a_1 + ', stream=' + this.s7a_1 + ', streamOptions=' + toString_0(this.t7a_1) + ', temperature=' + this.u7a_1 + ', maxTokens=' + this.v7a_1 + ', maxCompletionTokens=' + this.w7a_1 + ', topP=' + this.x7a_1 + ', stop=' + toString_0(this.y7a_1) + ', presencePenalty=' + this.z7a_1 + ', frequencyPenalty=' + this.a7b_1 + ', reasoningEffort=' + this.b7b_1 + ', enableThinking=' + this.c7b_1 + ', responseFormat=' + toString_0(this.d7b_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.o7a_1);
    result = imul(result, 31) + hashCode(this.p7a_1) | 0;
    result = imul(result, 31) + (this.q7a_1 == null ? 0 : hashCode(this.q7a_1)) | 0;
    result = imul(result, 31) + (this.r7a_1 == null ? 0 : getBooleanHashCode(this.r7a_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.s7a_1) | 0;
    result = imul(result, 31) + (this.t7a_1 == null ? 0 : this.t7a_1.hashCode()) | 0;
    result = imul(result, 31) + (this.u7a_1 == null ? 0 : getNumberHashCode(this.u7a_1)) | 0;
    result = imul(result, 31) + (this.v7a_1 == null ? 0 : this.v7a_1) | 0;
    result = imul(result, 31) + (this.w7a_1 == null ? 0 : this.w7a_1) | 0;
    result = imul(result, 31) + (this.x7a_1 == null ? 0 : getNumberHashCode(this.x7a_1)) | 0;
    result = imul(result, 31) + (this.y7a_1 == null ? 0 : hashCode(this.y7a_1)) | 0;
    result = imul(result, 31) + (this.z7a_1 == null ? 0 : getNumberHashCode(this.z7a_1)) | 0;
    result = imul(result, 31) + (this.a7b_1 == null ? 0 : getNumberHashCode(this.a7b_1)) | 0;
    result = imul(result, 31) + (this.b7b_1 == null ? 0 : getStringHashCode(this.b7b_1)) | 0;
    result = imul(result, 31) + (this.c7b_1 == null ? 0 : getBooleanHashCode(this.c7b_1)) | 0;
    result = imul(result, 31) + (this.d7b_1 == null ? 0 : this.d7b_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatCompletionsRequest))
      return false;
    var tmp0_other_with_cast = other instanceof ChatCompletionsRequest ? other : THROW_CCE();
    if (!(this.o7a_1 === tmp0_other_with_cast.o7a_1))
      return false;
    if (!equals(this.p7a_1, tmp0_other_with_cast.p7a_1))
      return false;
    if (!equals(this.q7a_1, tmp0_other_with_cast.q7a_1))
      return false;
    if (!(this.r7a_1 == tmp0_other_with_cast.r7a_1))
      return false;
    if (!(this.s7a_1 === tmp0_other_with_cast.s7a_1))
      return false;
    if (!equals(this.t7a_1, tmp0_other_with_cast.t7a_1))
      return false;
    if (!equals(this.u7a_1, tmp0_other_with_cast.u7a_1))
      return false;
    if (!(this.v7a_1 == tmp0_other_with_cast.v7a_1))
      return false;
    if (!(this.w7a_1 == tmp0_other_with_cast.w7a_1))
      return false;
    if (!equals(this.x7a_1, tmp0_other_with_cast.x7a_1))
      return false;
    if (!equals(this.y7a_1, tmp0_other_with_cast.y7a_1))
      return false;
    if (!equals(this.z7a_1, tmp0_other_with_cast.z7a_1))
      return false;
    if (!equals(this.a7b_1, tmp0_other_with_cast.a7b_1))
      return false;
    if (!(this.b7b_1 == tmp0_other_with_cast.b7b_1))
      return false;
    if (!(this.c7b_1 == tmp0_other_with_cast.c7b_1))
      return false;
    if (!equals(this.d7b_1, tmp0_other_with_cast.d7b_1))
      return false;
    return true;
  }
  static e7b(seen0, model, messages, tools, parallelToolCalls, stream, streamOptions, temperature, maxTokens, maxCompletionTokens, topP, stop, presencePenalty, frequencyPenalty, reasoningEffort, enableThinking, responseFormat, serializationConstructorMarker) {
    Companion_getInstance_0();
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance().m7a_1);
    }
    var $this = createThis(this);
    $this.o7a_1 = model;
    $this.p7a_1 = messages;
    if (0 === (seen0 & 4))
      $this.q7a_1 = null;
    else
      $this.q7a_1 = tools;
    if (0 === (seen0 & 8))
      $this.r7a_1 = null;
    else
      $this.r7a_1 = parallelToolCalls;
    if (0 === (seen0 & 16))
      $this.s7a_1 = true;
    else
      $this.s7a_1 = stream;
    if (0 === (seen0 & 32))
      $this.t7a_1 = null;
    else
      $this.t7a_1 = streamOptions;
    if (0 === (seen0 & 64))
      $this.u7a_1 = null;
    else
      $this.u7a_1 = temperature;
    if (0 === (seen0 & 128))
      $this.v7a_1 = null;
    else
      $this.v7a_1 = maxTokens;
    if (0 === (seen0 & 256))
      $this.w7a_1 = null;
    else
      $this.w7a_1 = maxCompletionTokens;
    if (0 === (seen0 & 512))
      $this.x7a_1 = null;
    else
      $this.x7a_1 = topP;
    if (0 === (seen0 & 1024))
      $this.y7a_1 = null;
    else
      $this.y7a_1 = stop;
    if (0 === (seen0 & 2048))
      $this.z7a_1 = null;
    else
      $this.z7a_1 = presencePenalty;
    if (0 === (seen0 & 4096))
      $this.a7b_1 = null;
    else
      $this.a7b_1 = frequencyPenalty;
    if (0 === (seen0 & 8192))
      $this.b7b_1 = null;
    else
      $this.b7b_1 = reasoningEffort;
    if (0 === (seen0 & 16384))
      $this.c7b_1 = null;
    else
      $this.c7b_1 = enableThinking;
    if (0 === (seen0 & 32768))
      $this.d7b_1 = null;
    else
      $this.d7b_1 = responseFormat;
    return $this;
  }
}
class Companion_0 {
  constructor() {
    Companion_instance_3 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.f7b_1 = [null, null, lazy(tmp_0, ChatMessage$Companion$$childSerializers$_anonymous__qywqat), null];
  }
}
class $serializer_0 {
  constructor() {
    $serializer_instance_0 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatMessage', this, 4);
    tmp0_serialDesc.u25('role', false);
    tmp0_serialDesc.u25('content', true);
    tmp0_serialDesc.u25('tool_calls', true);
    tmp0_serialDesc.u25('tool_call_id', true);
    this.g7b_1 = tmp0_serialDesc;
  }
  h7b(encoder, value) {
    var tmp0_desc = this.g7b_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_1().f7b_1;
    tmp1_output.v1z(tmp0_desc, 0, value.h7a_1);
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.i7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.i7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.j7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.j7a_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.k7a_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, StringSerializer_getInstance(), value.k7a_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.h7b(encoder, value instanceof ChatMessage ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.g7b_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.f1y(tmp0_desc);
    var tmp9_cached = Companion_getInstance_1().f7b_1;
    if (tmp8_input.v1y()) {
      tmp4_local0 = tmp8_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, tmp9_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, tmp9_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp8_input.g1y(tmp0_desc);
    return ChatMessage.i7b(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  w1t() {
    return this.g7b_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_1().f7b_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[2].n1()), get_nullable(StringSerializer_getInstance())];
  }
}
class ChatMessage {
  constructor(role, content, toolCalls, toolCallId) {
    Companion_getInstance_1();
    content = content === VOID ? null : content;
    toolCalls = toolCalls === VOID ? null : toolCalls;
    toolCallId = toolCallId === VOID ? null : toolCallId;
    this.h7a_1 = role;
    this.i7a_1 = content;
    this.j7a_1 = toolCalls;
    this.k7a_1 = toolCallId;
  }
  j7b(role, content, toolCalls, toolCallId) {
    return new ChatMessage(role, content, toolCalls, toolCallId);
  }
  l7a(role, content, toolCalls, toolCallId, $super) {
    role = role === VOID ? this.h7a_1 : role;
    content = content === VOID ? this.i7a_1 : content;
    toolCalls = toolCalls === VOID ? this.j7a_1 : toolCalls;
    toolCallId = toolCallId === VOID ? this.k7a_1 : toolCallId;
    return $super === VOID ? this.j7b(role, content, toolCalls, toolCallId) : $super.j7b.call(this, role, content, toolCalls, toolCallId);
  }
  toString() {
    return 'ChatMessage(role=' + this.h7a_1 + ', content=' + this.i7a_1 + ', toolCalls=' + toString_0(this.j7a_1) + ', toolCallId=' + this.k7a_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.h7a_1);
    result = imul(result, 31) + (this.i7a_1 == null ? 0 : getStringHashCode(this.i7a_1)) | 0;
    result = imul(result, 31) + (this.j7a_1 == null ? 0 : hashCode(this.j7a_1)) | 0;
    result = imul(result, 31) + (this.k7a_1 == null ? 0 : getStringHashCode(this.k7a_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatMessage))
      return false;
    var tmp0_other_with_cast = other instanceof ChatMessage ? other : THROW_CCE();
    if (!(this.h7a_1 === tmp0_other_with_cast.h7a_1))
      return false;
    if (!(this.i7a_1 == tmp0_other_with_cast.i7a_1))
      return false;
    if (!equals(this.j7a_1, tmp0_other_with_cast.j7a_1))
      return false;
    if (!(this.k7a_1 == tmp0_other_with_cast.k7a_1))
      return false;
    return true;
  }
  static i7b(seen0, role, content, toolCalls, toolCallId, serializationConstructorMarker) {
    Companion_getInstance_1();
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_0().g7b_1);
    }
    var $this = createThis(this);
    $this.h7a_1 = role;
    if (0 === (seen0 & 2))
      $this.i7a_1 = null;
    else
      $this.i7a_1 = content;
    if (0 === (seen0 & 4))
      $this.j7a_1 = null;
    else
      $this.j7a_1 = toolCalls;
    if (0 === (seen0 & 8))
      $this.k7a_1 = null;
    else
      $this.k7a_1 = toolCallId;
    return $this;
  }
}
class Companion_1 {}
class $serializer_1 {
  constructor() {
    $serializer_instance_1 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatTool', this, 2);
    tmp0_serialDesc.u25('type', true);
    tmp0_serialDesc.u25('function', false);
    this.k7b_1 = tmp0_serialDesc;
  }
  l7b(encoder, value) {
    var tmp0_desc = this.k7b_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.m7b_1 === 'function')) {
      tmp1_output.v1z(tmp0_desc, 0, value.m7b_1);
    }
    tmp1_output.x1z(tmp0_desc, 1, $serializer_getInstance_5(), value.n7b_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.l7b(encoder, value instanceof ChatTool ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.k7b_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, $serializer_getInstance_5(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, $serializer_getInstance_5(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return ChatTool.o7b(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.k7b_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), $serializer_getInstance_5()];
  }
}
class ChatTool {
  constructor(type, function_0) {
    type = type === VOID ? 'function' : type;
    this.m7b_1 = type;
    this.n7b_1 = function_0;
  }
  toString() {
    return 'ChatTool(type=' + this.m7b_1 + ', function=' + this.n7b_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.m7b_1);
    result = imul(result, 31) + this.n7b_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatTool))
      return false;
    var tmp0_other_with_cast = other instanceof ChatTool ? other : THROW_CCE();
    if (!(this.m7b_1 === tmp0_other_with_cast.m7b_1))
      return false;
    if (!this.n7b_1.equals(tmp0_other_with_cast.n7b_1))
      return false;
    return true;
  }
  static o7b(seen0, type, function_0, serializationConstructorMarker) {
    if (!(2 === (2 & seen0))) {
      throwMissingFieldException(seen0, 2, $serializer_getInstance_1().k7b_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.m7b_1 = 'function';
    else
      $this.m7b_1 = type;
    $this.n7b_1 = function_0;
    return $this;
  }
}
class Companion_2 {}
class $serializer_2 {
  constructor() {
    $serializer_instance_2 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatStreamOptions', this, 1);
    tmp0_serialDesc.u25('include_usage', true);
    this.p7b_1 = tmp0_serialDesc;
  }
  q7b(encoder, value) {
    var tmp0_desc = this.p7b_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.r7b_1 === true)) {
      tmp1_output.n1z(tmp0_desc, 0, value.r7b_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.q7b(encoder, value instanceof ChatStreamOptions ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.p7b_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = false;
    var tmp5_input = decoder.f1y(tmp0_desc);
    if (tmp5_input.v1y()) {
      tmp4_local0 = tmp5_input.h1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.h1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp5_input.g1y(tmp0_desc);
    return ChatStreamOptions.s7b(tmp3_bitMask0, tmp4_local0, null);
  }
  w1t() {
    return this.p7b_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [BooleanSerializer_getInstance()];
  }
}
class ChatStreamOptions {
  constructor(includeUsage) {
    includeUsage = includeUsage === VOID ? true : includeUsage;
    this.r7b_1 = includeUsage;
  }
  toString() {
    return 'ChatStreamOptions(includeUsage=' + this.r7b_1 + ')';
  }
  hashCode() {
    return getBooleanHashCode(this.r7b_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatStreamOptions))
      return false;
    var tmp0_other_with_cast = other instanceof ChatStreamOptions ? other : THROW_CCE();
    if (!(this.r7b_1 === tmp0_other_with_cast.r7b_1))
      return false;
    return true;
  }
  static s7b(seen0, includeUsage, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_2().p7b_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.r7b_1 = true;
    else
      $this.r7b_1 = includeUsage;
    return $this;
  }
}
class Companion_3 {}
class $serializer_3 {
  constructor() {
    $serializer_instance_3 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatReqToolCall', this, 3);
    tmp0_serialDesc.u25('id', false);
    tmp0_serialDesc.u25('type', true);
    tmp0_serialDesc.u25('function', false);
    this.t7b_1 = tmp0_serialDesc;
  }
  u7b(encoder, value) {
    var tmp0_desc = this.t7b_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.v7b_1);
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.w7b_1 === 'function')) {
      tmp1_output.v1z(tmp0_desc, 1, value.w7b_1);
    }
    tmp1_output.x1z(tmp0_desc, 2, $serializer_getInstance_4(), value.x7b_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.u7b(encoder, value instanceof ChatReqToolCall ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.t7b_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.f1y(tmp0_desc);
    if (tmp7_input.v1y()) {
      tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, $serializer_getInstance_4(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, $serializer_getInstance_4(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp7_input.g1y(tmp0_desc);
    return ChatReqToolCall.y7b(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  w1t() {
    return this.t7b_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), $serializer_getInstance_4()];
  }
}
class ChatReqToolCall {
  constructor(id, type, function_0) {
    type = type === VOID ? 'function' : type;
    this.v7b_1 = id;
    this.w7b_1 = type;
    this.x7b_1 = function_0;
  }
  toString() {
    return 'ChatReqToolCall(id=' + this.v7b_1 + ', type=' + this.w7b_1 + ', function=' + this.x7b_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.v7b_1);
    result = imul(result, 31) + getStringHashCode(this.w7b_1) | 0;
    result = imul(result, 31) + this.x7b_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatReqToolCall))
      return false;
    var tmp0_other_with_cast = other instanceof ChatReqToolCall ? other : THROW_CCE();
    if (!(this.v7b_1 === tmp0_other_with_cast.v7b_1))
      return false;
    if (!(this.w7b_1 === tmp0_other_with_cast.w7b_1))
      return false;
    if (!this.x7b_1.equals(tmp0_other_with_cast.x7b_1))
      return false;
    return true;
  }
  static y7b(seen0, id, type, function_0, serializationConstructorMarker) {
    if (!(5 === (5 & seen0))) {
      throwMissingFieldException(seen0, 5, $serializer_getInstance_3().t7b_1);
    }
    var $this = createThis(this);
    $this.v7b_1 = id;
    if (0 === (seen0 & 2))
      $this.w7b_1 = 'function';
    else
      $this.w7b_1 = type;
    $this.x7b_1 = function_0;
    return $this;
  }
}
class Companion_4 {}
class $serializer_4 {
  constructor() {
    $serializer_instance_4 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatReqFunction', this, 2);
    tmp0_serialDesc.u25('name', false);
    tmp0_serialDesc.u25('arguments', false);
    this.z7b_1 = tmp0_serialDesc;
  }
  a7c(encoder, value) {
    var tmp0_desc = this.z7b_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.b7c_1);
    tmp1_output.v1z(tmp0_desc, 1, value.c7c_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.a7c(encoder, value instanceof ChatReqFunction ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.z7b_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return ChatReqFunction.d7c(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.z7b_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance()];
  }
}
class ChatReqFunction {
  constructor(name, arguments_0) {
    this.b7c_1 = name;
    this.c7c_1 = arguments_0;
  }
  toString() {
    return 'ChatReqFunction(name=' + this.b7c_1 + ', arguments=' + this.c7c_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.b7c_1);
    result = imul(result, 31) + getStringHashCode(this.c7c_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatReqFunction))
      return false;
    var tmp0_other_with_cast = other instanceof ChatReqFunction ? other : THROW_CCE();
    if (!(this.b7c_1 === tmp0_other_with_cast.b7c_1))
      return false;
    if (!(this.c7c_1 === tmp0_other_with_cast.c7c_1))
      return false;
    return true;
  }
  static d7c(seen0, name, arguments_0, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_4().z7b_1);
    }
    var $this = createThis(this);
    $this.b7c_1 = name;
    $this.c7c_1 = arguments_0;
    return $this;
  }
}
class Companion_5 {}
class $serializer_5 {
  constructor() {
    $serializer_instance_5 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatFunctionDef', this, 3);
    tmp0_serialDesc.u25('name', false);
    tmp0_serialDesc.u25('description', false);
    tmp0_serialDesc.u25('parameters', false);
    this.e7c_1 = tmp0_serialDesc;
  }
  f7c(encoder, value) {
    var tmp0_desc = this.e7c_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.g7c_1);
    tmp1_output.v1z(tmp0_desc, 1, value.h7c_1);
    tmp1_output.x1z(tmp0_desc, 2, JsonObjectSerializer_getInstance(), value.i7c_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.f7c(encoder, value instanceof ChatFunctionDef ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.e7c_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.f1y(tmp0_desc);
    if (tmp7_input.v1y()) {
      tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp7_input.g1y(tmp0_desc);
    return ChatFunctionDef.j7c(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  w1t() {
    return this.e7c_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), JsonObjectSerializer_getInstance()];
  }
}
class ChatFunctionDef {
  constructor(name, description, parameters) {
    this.g7c_1 = name;
    this.h7c_1 = description;
    this.i7c_1 = parameters;
  }
  toString() {
    return 'ChatFunctionDef(name=' + this.g7c_1 + ', description=' + this.h7c_1 + ', parameters=' + this.i7c_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.g7c_1);
    result = imul(result, 31) + getStringHashCode(this.h7c_1) | 0;
    result = imul(result, 31) + this.i7c_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatFunctionDef))
      return false;
    var tmp0_other_with_cast = other instanceof ChatFunctionDef ? other : THROW_CCE();
    if (!(this.g7c_1 === tmp0_other_with_cast.g7c_1))
      return false;
    if (!(this.h7c_1 === tmp0_other_with_cast.h7c_1))
      return false;
    if (!this.i7c_1.equals(tmp0_other_with_cast.i7c_1))
      return false;
    return true;
  }
  static j7c(seen0, name, description, parameters, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_5().e7c_1);
    }
    var $this = createThis(this);
    $this.g7c_1 = name;
    $this.h7c_1 = description;
    $this.i7c_1 = parameters;
    return $this;
  }
}
class Companion_6 {}
class $serializer_6 {
  constructor() {
    $serializer_instance_6 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.Choice', this, 4);
    tmp0_serialDesc.u25('index', true);
    tmp0_serialDesc.u25('delta', true);
    tmp0_serialDesc.u25('message', true);
    tmp0_serialDesc.u25('finish_reason', true);
    this.k7c_1 = tmp0_serialDesc;
  }
  l7c(encoder, value) {
    var tmp0_desc = this.k7c_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.b79_1 === 0)) {
      tmp1_output.q1z(tmp0_desc, 0, value.b79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.c79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, $serializer_getInstance_7(), value.c79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.d79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, $serializer_getInstance_7(), value.d79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.e79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, StringSerializer_getInstance(), value.e79_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.l7c(encoder, value instanceof Choice ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.k7c_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = 0;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.f1y(tmp0_desc);
    if (tmp8_input.v1y()) {
      tmp4_local0 = tmp8_input.k1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, $serializer_getInstance_7(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.k1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, $serializer_getInstance_7(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp8_input.g1y(tmp0_desc);
    return Choice.m7c(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  w1t() {
    return this.k7c_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [IntSerializer_getInstance(), get_nullable($serializer_getInstance_7()), get_nullable($serializer_getInstance_7()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_7 {
  constructor() {
    Companion_instance_10 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.n7c_1 = [null, null, null, lazy(tmp_0, ChatCompletionsResponse$Delta$Companion$$childSerializers$_anonymous__fygqye), null];
  }
}
class $serializer_7 {
  constructor() {
    $serializer_instance_7 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.Delta', this, 5);
    tmp0_serialDesc.u25('role', true);
    tmp0_serialDesc.u25('content', true);
    tmp0_serialDesc.u25('reasoning_content', true);
    tmp0_serialDesc.u25('tool_calls', true);
    tmp0_serialDesc.u25('refusal', true);
    this.o7c_1 = tmp0_serialDesc;
  }
  p7c(encoder, value) {
    var tmp0_desc = this.o7c_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_8().n7c_1;
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.g79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.g79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.h79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.h79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.i79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, StringSerializer_getInstance(), value.i79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.j79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, tmp2_cached[3].n1(), value.j79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.k79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 4, StringSerializer_getInstance(), value.k79_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.p7c(encoder, value instanceof Delta ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.o7c_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.f1y(tmp0_desc);
    var tmp10_cached = Companion_getInstance_8().n7c_1;
    if (tmp9_input.v1y()) {
      tmp4_local0 = tmp9_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.t1y(tmp0_desc, 3, tmp10_cached[3].n1(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.t1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.t1y(tmp0_desc, 3, tmp10_cached[3].n1(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.t1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp9_input.g1y(tmp0_desc);
    return Delta.q7c(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  w1t() {
    return this.o7c_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_8().n7c_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[3].n1()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_8 {}
class $serializer_8 {
  constructor() {
    $serializer_instance_8 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.ToolCallChunk', this, 4);
    tmp0_serialDesc.u25('index', true);
    tmp0_serialDesc.u25('id', true);
    tmp0_serialDesc.u25('type', true);
    tmp0_serialDesc.u25('function', true);
    this.r7c_1 = tmp0_serialDesc;
  }
  s7c(encoder, value) {
    var tmp0_desc = this.r7c_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.l79_1 === 0)) {
      tmp1_output.q1z(tmp0_desc, 0, value.l79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.m79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.m79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.n79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, StringSerializer_getInstance(), value.n79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.o79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, $serializer_getInstance_9(), value.o79_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.s7c(encoder, value instanceof ToolCallChunk ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.r7c_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = 0;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.f1y(tmp0_desc);
    if (tmp8_input.v1y()) {
      tmp4_local0 = tmp8_input.k1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, $serializer_getInstance_9(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.k1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, $serializer_getInstance_9(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp8_input.g1y(tmp0_desc);
    return ToolCallChunk.t7c(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  w1t() {
    return this.r7c_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [IntSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable($serializer_getInstance_9())];
  }
}
class Companion_9 {}
class $serializer_9 {
  constructor() {
    $serializer_instance_9 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.FunctionChunk', this, 2);
    tmp0_serialDesc.u25('name', true);
    tmp0_serialDesc.u25('arguments', true);
    this.u7c_1 = tmp0_serialDesc;
  }
  v7c(encoder, value) {
    var tmp0_desc = this.u7c_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.p79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.p79_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.q79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.q79_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.v7c(encoder, value instanceof FunctionChunk ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.u7c_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return FunctionChunk.w7c(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.u7c_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_10 {}
class $serializer_10 {
  constructor() {
    $serializer_instance_10 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.Usage', this, 5);
    tmp0_serialDesc.u25('prompt_tokens', true);
    tmp0_serialDesc.u25('completion_tokens', true);
    tmp0_serialDesc.u25('total_tokens', true);
    tmp0_serialDesc.u25('prompt_tokens_details', true);
    tmp0_serialDesc.u25('completion_tokens_details', true);
    this.x7c_1 = tmp0_serialDesc;
  }
  y7c(encoder, value) {
    var tmp0_desc = this.x7c_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.u78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, IntSerializer_getInstance(), value.u78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.v78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, IntSerializer_getInstance(), value.v78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.w78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, IntSerializer_getInstance(), value.w78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.x78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, $serializer_getInstance_11(), value.x78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.y78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 4, $serializer_getInstance_12(), value.y78_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.y7c(encoder, value instanceof Usage_0 ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.x7c_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.f1y(tmp0_desc);
    if (tmp9_input.v1y()) {
      tmp4_local0 = tmp9_input.t1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.t1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.t1y(tmp0_desc, 2, IntSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.t1y(tmp0_desc, 3, $serializer_getInstance_11(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.t1y(tmp0_desc, 4, $serializer_getInstance_12(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.t1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.t1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.t1y(tmp0_desc, 2, IntSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.t1y(tmp0_desc, 3, $serializer_getInstance_11(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.t1y(tmp0_desc, 4, $serializer_getInstance_12(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp9_input.g1y(tmp0_desc);
    return Usage_0.z7c(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  w1t() {
    return this.x7c_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable($serializer_getInstance_11()), get_nullable($serializer_getInstance_12())];
  }
}
class Companion_11 {}
class $serializer_11 {
  constructor() {
    $serializer_instance_11 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.PromptDetails', this, 1);
    tmp0_serialDesc.u25('cached_tokens', true);
    this.a7d_1 = tmp0_serialDesc;
  }
  b7d(encoder, value) {
    var tmp0_desc = this.a7d_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.z78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, IntSerializer_getInstance(), value.z78_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.b7d(encoder, value instanceof PromptDetails ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.a7d_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.f1y(tmp0_desc);
    if (tmp5_input.v1y()) {
      tmp4_local0 = tmp5_input.t1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.t1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp5_input.g1y(tmp0_desc);
    return PromptDetails.c7d(tmp3_bitMask0, tmp4_local0, null);
  }
  w1t() {
    return this.a7d_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(IntSerializer_getInstance())];
  }
}
class Companion_12 {}
class $serializer_12 {
  constructor() {
    $serializer_instance_12 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.CompletionDetails', this, 1);
    tmp0_serialDesc.u25('reasoning_tokens', true);
    this.d7d_1 = tmp0_serialDesc;
  }
  e7d(encoder, value) {
    var tmp0_desc = this.d7d_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.a79_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, IntSerializer_getInstance(), value.a79_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.e7d(encoder, value instanceof CompletionDetails ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.d7d_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.f1y(tmp0_desc);
    if (tmp5_input.v1y()) {
      tmp4_local0 = tmp5_input.t1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.t1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp5_input.g1y(tmp0_desc);
    return CompletionDetails.f7d(tmp3_bitMask0, tmp4_local0, null);
  }
  w1t() {
    return this.d7d_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(IntSerializer_getInstance())];
  }
}
class Companion_13 {}
class $serializer_13 {
  constructor() {
    $serializer_instance_13 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse.ErrorOutput', this, 4);
    tmp0_serialDesc.u25('code', true);
    tmp0_serialDesc.u25('param', true);
    tmp0_serialDesc.u25('message', true);
    tmp0_serialDesc.u25('type', true);
    this.g7d_1 = tmp0_serialDesc;
  }
  h7d(encoder, value) {
    var tmp0_desc = this.g7d_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.q78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.q78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.r78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.r78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.s78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, StringSerializer_getInstance(), value.s78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.t78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, StringSerializer_getInstance(), value.t78_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.h7d(encoder, value instanceof ErrorOutput ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.g7d_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.f1y(tmp0_desc);
    if (tmp8_input.v1y()) {
      tmp4_local0 = tmp8_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp8_input.g1y(tmp0_desc);
    return ErrorOutput.i7d(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  w1t() {
    return this.g7d_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Choice {
  constructor(index, delta, message, finishReason) {
    index = index === VOID ? 0 : index;
    delta = delta === VOID ? null : delta;
    message = message === VOID ? null : message;
    finishReason = finishReason === VOID ? null : finishReason;
    this.b79_1 = index;
    this.c79_1 = delta;
    this.d79_1 = message;
    this.e79_1 = finishReason;
  }
  f79() {
    var tmp0_elvis_lhs = this.c79_1;
    return tmp0_elvis_lhs == null ? this.d79_1 : tmp0_elvis_lhs;
  }
  toString() {
    return 'Choice(index=' + this.b79_1 + ', delta=' + toString_0(this.c79_1) + ', message=' + toString_0(this.d79_1) + ', finishReason=' + this.e79_1 + ')';
  }
  hashCode() {
    var result = this.b79_1;
    result = imul(result, 31) + (this.c79_1 == null ? 0 : this.c79_1.hashCode()) | 0;
    result = imul(result, 31) + (this.d79_1 == null ? 0 : this.d79_1.hashCode()) | 0;
    result = imul(result, 31) + (this.e79_1 == null ? 0 : getStringHashCode(this.e79_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Choice))
      return false;
    var tmp0_other_with_cast = other instanceof Choice ? other : THROW_CCE();
    if (!(this.b79_1 === tmp0_other_with_cast.b79_1))
      return false;
    if (!equals(this.c79_1, tmp0_other_with_cast.c79_1))
      return false;
    if (!equals(this.d79_1, tmp0_other_with_cast.d79_1))
      return false;
    if (!(this.e79_1 == tmp0_other_with_cast.e79_1))
      return false;
    return true;
  }
  static m7c(seen0, index, delta, message, finishReason, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_6().k7c_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.b79_1 = 0;
    else
      $this.b79_1 = index;
    if (0 === (seen0 & 2))
      $this.c79_1 = null;
    else
      $this.c79_1 = delta;
    if (0 === (seen0 & 4))
      $this.d79_1 = null;
    else
      $this.d79_1 = message;
    if (0 === (seen0 & 8))
      $this.e79_1 = null;
    else
      $this.e79_1 = finishReason;
    return $this;
  }
}
class Delta {
  constructor(role, content, reasoningContent, toolCalls, refusal) {
    Companion_getInstance_8();
    role = role === VOID ? null : role;
    content = content === VOID ? null : content;
    reasoningContent = reasoningContent === VOID ? null : reasoningContent;
    toolCalls = toolCalls === VOID ? null : toolCalls;
    refusal = refusal === VOID ? null : refusal;
    this.g79_1 = role;
    this.h79_1 = content;
    this.i79_1 = reasoningContent;
    this.j79_1 = toolCalls;
    this.k79_1 = refusal;
  }
  toString() {
    return 'Delta(role=' + this.g79_1 + ', content=' + this.h79_1 + ', reasoningContent=' + this.i79_1 + ', toolCalls=' + toString_0(this.j79_1) + ', refusal=' + this.k79_1 + ')';
  }
  hashCode() {
    var result = this.g79_1 == null ? 0 : getStringHashCode(this.g79_1);
    result = imul(result, 31) + (this.h79_1 == null ? 0 : getStringHashCode(this.h79_1)) | 0;
    result = imul(result, 31) + (this.i79_1 == null ? 0 : getStringHashCode(this.i79_1)) | 0;
    result = imul(result, 31) + (this.j79_1 == null ? 0 : hashCode(this.j79_1)) | 0;
    result = imul(result, 31) + (this.k79_1 == null ? 0 : getStringHashCode(this.k79_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Delta))
      return false;
    var tmp0_other_with_cast = other instanceof Delta ? other : THROW_CCE();
    if (!(this.g79_1 == tmp0_other_with_cast.g79_1))
      return false;
    if (!(this.h79_1 == tmp0_other_with_cast.h79_1))
      return false;
    if (!(this.i79_1 == tmp0_other_with_cast.i79_1))
      return false;
    if (!equals(this.j79_1, tmp0_other_with_cast.j79_1))
      return false;
    if (!(this.k79_1 == tmp0_other_with_cast.k79_1))
      return false;
    return true;
  }
  static q7c(seen0, role, content, reasoningContent, toolCalls, refusal, serializationConstructorMarker) {
    Companion_getInstance_8();
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_7().o7c_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.g79_1 = null;
    else
      $this.g79_1 = role;
    if (0 === (seen0 & 2))
      $this.h79_1 = null;
    else
      $this.h79_1 = content;
    if (0 === (seen0 & 4))
      $this.i79_1 = null;
    else
      $this.i79_1 = reasoningContent;
    if (0 === (seen0 & 8))
      $this.j79_1 = null;
    else
      $this.j79_1 = toolCalls;
    if (0 === (seen0 & 16))
      $this.k79_1 = null;
    else
      $this.k79_1 = refusal;
    return $this;
  }
}
class ToolCallChunk {
  constructor(index, id, type, function_0) {
    index = index === VOID ? 0 : index;
    id = id === VOID ? null : id;
    type = type === VOID ? null : type;
    function_0 = function_0 === VOID ? null : function_0;
    this.l79_1 = index;
    this.m79_1 = id;
    this.n79_1 = type;
    this.o79_1 = function_0;
  }
  toString() {
    return 'ToolCallChunk(index=' + this.l79_1 + ', id=' + this.m79_1 + ', type=' + this.n79_1 + ', function=' + toString_0(this.o79_1) + ')';
  }
  hashCode() {
    var result = this.l79_1;
    result = imul(result, 31) + (this.m79_1 == null ? 0 : getStringHashCode(this.m79_1)) | 0;
    result = imul(result, 31) + (this.n79_1 == null ? 0 : getStringHashCode(this.n79_1)) | 0;
    result = imul(result, 31) + (this.o79_1 == null ? 0 : this.o79_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolCallChunk))
      return false;
    var tmp0_other_with_cast = other instanceof ToolCallChunk ? other : THROW_CCE();
    if (!(this.l79_1 === tmp0_other_with_cast.l79_1))
      return false;
    if (!(this.m79_1 == tmp0_other_with_cast.m79_1))
      return false;
    if (!(this.n79_1 == tmp0_other_with_cast.n79_1))
      return false;
    if (!equals(this.o79_1, tmp0_other_with_cast.o79_1))
      return false;
    return true;
  }
  static t7c(seen0, index, id, type, function_0, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_8().r7c_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.l79_1 = 0;
    else
      $this.l79_1 = index;
    if (0 === (seen0 & 2))
      $this.m79_1 = null;
    else
      $this.m79_1 = id;
    if (0 === (seen0 & 4))
      $this.n79_1 = null;
    else
      $this.n79_1 = type;
    if (0 === (seen0 & 8))
      $this.o79_1 = null;
    else
      $this.o79_1 = function_0;
    return $this;
  }
}
class FunctionChunk {
  constructor(name, arguments_0) {
    name = name === VOID ? null : name;
    arguments_0 = arguments_0 === VOID ? null : arguments_0;
    this.p79_1 = name;
    this.q79_1 = arguments_0;
  }
  toString() {
    return 'FunctionChunk(name=' + this.p79_1 + ', arguments=' + this.q79_1 + ')';
  }
  hashCode() {
    var result = this.p79_1 == null ? 0 : getStringHashCode(this.p79_1);
    result = imul(result, 31) + (this.q79_1 == null ? 0 : getStringHashCode(this.q79_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof FunctionChunk))
      return false;
    var tmp0_other_with_cast = other instanceof FunctionChunk ? other : THROW_CCE();
    if (!(this.p79_1 == tmp0_other_with_cast.p79_1))
      return false;
    if (!(this.q79_1 == tmp0_other_with_cast.q79_1))
      return false;
    return true;
  }
  static w7c(seen0, name, arguments_0, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_9().u7c_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.p79_1 = null;
    else
      $this.p79_1 = name;
    if (0 === (seen0 & 2))
      $this.q79_1 = null;
    else
      $this.q79_1 = arguments_0;
    return $this;
  }
}
class Usage_0 {
  constructor(promptTokens, completionTokens, totalTokens, promptDetails, completionDetails) {
    promptTokens = promptTokens === VOID ? null : promptTokens;
    completionTokens = completionTokens === VOID ? null : completionTokens;
    totalTokens = totalTokens === VOID ? null : totalTokens;
    promptDetails = promptDetails === VOID ? null : promptDetails;
    completionDetails = completionDetails === VOID ? null : completionDetails;
    this.u78_1 = promptTokens;
    this.v78_1 = completionTokens;
    this.w78_1 = totalTokens;
    this.x78_1 = promptDetails;
    this.y78_1 = completionDetails;
  }
  toString() {
    return 'Usage(promptTokens=' + this.u78_1 + ', completionTokens=' + this.v78_1 + ', totalTokens=' + this.w78_1 + ', promptDetails=' + toString_0(this.x78_1) + ', completionDetails=' + toString_0(this.y78_1) + ')';
  }
  hashCode() {
    var result = this.u78_1 == null ? 0 : this.u78_1;
    result = imul(result, 31) + (this.v78_1 == null ? 0 : this.v78_1) | 0;
    result = imul(result, 31) + (this.w78_1 == null ? 0 : this.w78_1) | 0;
    result = imul(result, 31) + (this.x78_1 == null ? 0 : this.x78_1.hashCode()) | 0;
    result = imul(result, 31) + (this.y78_1 == null ? 0 : this.y78_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Usage_0))
      return false;
    var tmp0_other_with_cast = other instanceof Usage_0 ? other : THROW_CCE();
    if (!(this.u78_1 == tmp0_other_with_cast.u78_1))
      return false;
    if (!(this.v78_1 == tmp0_other_with_cast.v78_1))
      return false;
    if (!(this.w78_1 == tmp0_other_with_cast.w78_1))
      return false;
    if (!equals(this.x78_1, tmp0_other_with_cast.x78_1))
      return false;
    if (!equals(this.y78_1, tmp0_other_with_cast.y78_1))
      return false;
    return true;
  }
  static z7c(seen0, promptTokens, completionTokens, totalTokens, promptDetails, completionDetails, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_10().x7c_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.u78_1 = null;
    else
      $this.u78_1 = promptTokens;
    if (0 === (seen0 & 2))
      $this.v78_1 = null;
    else
      $this.v78_1 = completionTokens;
    if (0 === (seen0 & 4))
      $this.w78_1 = null;
    else
      $this.w78_1 = totalTokens;
    if (0 === (seen0 & 8))
      $this.x78_1 = null;
    else
      $this.x78_1 = promptDetails;
    if (0 === (seen0 & 16))
      $this.y78_1 = null;
    else
      $this.y78_1 = completionDetails;
    return $this;
  }
}
class PromptDetails {
  constructor(cachedTokens) {
    cachedTokens = cachedTokens === VOID ? null : cachedTokens;
    this.z78_1 = cachedTokens;
  }
  toString() {
    return 'PromptDetails(cachedTokens=' + this.z78_1 + ')';
  }
  hashCode() {
    return this.z78_1 == null ? 0 : this.z78_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof PromptDetails))
      return false;
    var tmp0_other_with_cast = other instanceof PromptDetails ? other : THROW_CCE();
    if (!(this.z78_1 == tmp0_other_with_cast.z78_1))
      return false;
    return true;
  }
  static c7d(seen0, cachedTokens, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_11().a7d_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.z78_1 = null;
    else
      $this.z78_1 = cachedTokens;
    return $this;
  }
}
class CompletionDetails {
  constructor(reasoningTokens) {
    reasoningTokens = reasoningTokens === VOID ? null : reasoningTokens;
    this.a79_1 = reasoningTokens;
  }
  toString() {
    return 'CompletionDetails(reasoningTokens=' + this.a79_1 + ')';
  }
  hashCode() {
    return this.a79_1 == null ? 0 : this.a79_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CompletionDetails))
      return false;
    var tmp0_other_with_cast = other instanceof CompletionDetails ? other : THROW_CCE();
    if (!(this.a79_1 == tmp0_other_with_cast.a79_1))
      return false;
    return true;
  }
  static f7d(seen0, reasoningTokens, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_12().d7d_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.a79_1 = null;
    else
      $this.a79_1 = reasoningTokens;
    return $this;
  }
}
class ErrorOutput {
  constructor(code, param, message, type) {
    code = code === VOID ? null : code;
    param = param === VOID ? null : param;
    message = message === VOID ? null : message;
    type = type === VOID ? null : type;
    this.q78_1 = code;
    this.r78_1 = param;
    this.s78_1 = message;
    this.t78_1 = type;
  }
  toString() {
    return 'ErrorOutput(code=' + this.q78_1 + ', param=' + this.r78_1 + ', message=' + this.s78_1 + ', type=' + this.t78_1 + ')';
  }
  hashCode() {
    var result = this.q78_1 == null ? 0 : getStringHashCode(this.q78_1);
    result = imul(result, 31) + (this.r78_1 == null ? 0 : getStringHashCode(this.r78_1)) | 0;
    result = imul(result, 31) + (this.s78_1 == null ? 0 : getStringHashCode(this.s78_1)) | 0;
    result = imul(result, 31) + (this.t78_1 == null ? 0 : getStringHashCode(this.t78_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ErrorOutput))
      return false;
    var tmp0_other_with_cast = other instanceof ErrorOutput ? other : THROW_CCE();
    if (!(this.q78_1 == tmp0_other_with_cast.q78_1))
      return false;
    if (!(this.r78_1 == tmp0_other_with_cast.r78_1))
      return false;
    if (!(this.s78_1 == tmp0_other_with_cast.s78_1))
      return false;
    if (!(this.t78_1 == tmp0_other_with_cast.t78_1))
      return false;
    return true;
  }
  static i7d(seen0, code, param, message, type, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_13().g7d_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.q78_1 = null;
    else
      $this.q78_1 = code;
    if (0 === (seen0 & 2))
      $this.r78_1 = null;
    else
      $this.r78_1 = param;
    if (0 === (seen0 & 4))
      $this.s78_1 = null;
    else
      $this.s78_1 = message;
    if (0 === (seen0 & 8))
      $this.t78_1 = null;
    else
      $this.t78_1 = type;
    return $this;
  }
}
class Companion_14 {
  constructor() {
    Companion_instance_17 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.j78_1 = [null, null, lazy(tmp_0, ChatCompletionsResponse$Companion$$childSerializers$_anonymous__8hhtau), null, null];
  }
  r3o() {
    return $serializer_getInstance_14();
  }
}
class $serializer_14 {
  constructor() {
    $serializer_instance_14 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.chatcompletions.ChatCompletionsResponse', this, 5);
    tmp0_serialDesc.u25('id', true);
    tmp0_serialDesc.u25('model', true);
    tmp0_serialDesc.u25('choices', true);
    tmp0_serialDesc.u25('usage', true);
    tmp0_serialDesc.u25('error', true);
    this.j7d_1 = tmp0_serialDesc;
  }
  k7d(encoder, value) {
    var tmp0_desc = this.j7d_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_15().j78_1;
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.l78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.l78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.m78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.m78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.n78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.n78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.o78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, $serializer_getInstance_10(), value.o78_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.p78_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 4, $serializer_getInstance_13(), value.p78_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.k7d(encoder, value instanceof ChatCompletionsResponse ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.j7d_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.f1y(tmp0_desc);
    var tmp10_cached = Companion_getInstance_15().j78_1;
    if (tmp9_input.v1y()) {
      tmp4_local0 = tmp9_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.t1y(tmp0_desc, 2, tmp10_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.t1y(tmp0_desc, 3, $serializer_getInstance_10(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.t1y(tmp0_desc, 4, $serializer_getInstance_13(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.t1y(tmp0_desc, 2, tmp10_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.t1y(tmp0_desc, 3, $serializer_getInstance_10(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.t1y(tmp0_desc, 4, $serializer_getInstance_13(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp9_input.g1y(tmp0_desc);
    return ChatCompletionsResponse.l7d(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  w1t() {
    return this.j7d_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_15().j78_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[2].n1()), get_nullable($serializer_getInstance_10()), get_nullable($serializer_getInstance_13())];
  }
}
class ChatCompletionsResponse {
  constructor(id, model, choices, usage, error) {
    Companion_getInstance_15();
    id = id === VOID ? null : id;
    model = model === VOID ? null : model;
    choices = choices === VOID ? null : choices;
    usage = usage === VOID ? null : usage;
    error = error === VOID ? null : error;
    this.l78_1 = id;
    this.m78_1 = model;
    this.n78_1 = choices;
    this.o78_1 = usage;
    this.p78_1 = error;
  }
  toString() {
    return 'ChatCompletionsResponse(id=' + this.l78_1 + ', model=' + this.m78_1 + ', choices=' + toString_0(this.n78_1) + ', usage=' + toString_0(this.o78_1) + ', error=' + toString_0(this.p78_1) + ')';
  }
  hashCode() {
    var result = this.l78_1 == null ? 0 : getStringHashCode(this.l78_1);
    result = imul(result, 31) + (this.m78_1 == null ? 0 : getStringHashCode(this.m78_1)) | 0;
    result = imul(result, 31) + (this.n78_1 == null ? 0 : hashCode(this.n78_1)) | 0;
    result = imul(result, 31) + (this.o78_1 == null ? 0 : this.o78_1.hashCode()) | 0;
    result = imul(result, 31) + (this.p78_1 == null ? 0 : this.p78_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ChatCompletionsResponse))
      return false;
    var tmp0_other_with_cast = other instanceof ChatCompletionsResponse ? other : THROW_CCE();
    if (!(this.l78_1 == tmp0_other_with_cast.l78_1))
      return false;
    if (!(this.m78_1 == tmp0_other_with_cast.m78_1))
      return false;
    if (!equals(this.n78_1, tmp0_other_with_cast.n78_1))
      return false;
    if (!equals(this.o78_1, tmp0_other_with_cast.o78_1))
      return false;
    if (!equals(this.p78_1, tmp0_other_with_cast.p78_1))
      return false;
    return true;
  }
  static l7d(seen0, id, model, choices, usage, error, serializationConstructorMarker) {
    Companion_getInstance_15();
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_14().j7d_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.l78_1 = null;
    else
      $this.l78_1 = id;
    if (0 === (seen0 & 2))
      $this.m78_1 = null;
    else
      $this.m78_1 = model;
    if (0 === (seen0 & 4))
      $this.n78_1 = null;
    else
      $this.n78_1 = choices;
    if (0 === (seen0 & 8))
      $this.o78_1 = null;
    else
      $this.o78_1 = usage;
    if (0 === (seen0 & 16))
      $this.p78_1 = null;
    else
      $this.p78_1 = error;
    return $this;
  }
}
//endregion
function finishFailed($this) {
  if ($this.g78_1)
    return emptyList();
  $this.g78_1 = true;
  return listOf(new Finished(new Failed(ensureNotNull($this.f78_1), $this.e78_1, VOID, $this.d78_1)));
}
function ChatCompletionsDecoder$finish$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = a.m1();
  var tmp$ret$1 = b.m1();
  return compareValues(tmp, tmp$ret$1);
}
function normalizeChatCompletionsUrl(baseUrl) {
  // Inline function 'kotlin.text.trim' call
  var tmp$ret$0 = toString(trim(isCharSequence(baseUrl) ? baseUrl : THROW_CCE()));
  var trimmed = trimEnd(tmp$ret$0, charArrayOf([_Char___init__impl__6a9atx(47)]));
  return endsWith(trimmed, '/chat/completions') ? trimmed : endsWith(trimmed, '/v1') ? trimmed + '/chat/completions' : trimmed + '/v1/chat/completions';
}
function toChatMessages(_this__u8e3s4, providerId) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var out = ArrayList.k();
  var tmp0_safe_receiver = _this__u8e3s4.b5y_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.takeIf' call
    var tmp_0;
    // Inline function 'kotlin.text.isNotBlank' call
    if (!isBlank(tmp0_safe_receiver)) {
      tmp_0 = tmp0_safe_receiver;
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  var tmp1_safe_receiver = tmp;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.collections.plusAssign' call
    var element = new ChatMessage('system', tmp1_safe_receiver);
    out.l(element);
  }
  var _iterator__ex2g4s = _this__u8e3s4.c5y_1.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    if (item instanceof Message) {
      switch (item.r5o_1.o3_1) {
        case 0:
          // Inline function 'kotlin.collections.plusAssign' call

          var element_0 = new ChatMessage('system', item.m5t());
          out.l(element_0);
          break;
        case 1:
          // Inline function 'kotlin.text.ifEmpty' call

          var this_0 = item.m5t();
          var tmp_1;
          // Inline function 'kotlin.text.isEmpty' call

          if (charSequenceLength(this_0) === 0) {
            tmp_1 = null;
          } else {
            tmp_1 = this_0;
          }

          var tmp$ret$10 = tmp_1;
          // Inline function 'kotlin.collections.plusAssign' call

          var element_1 = new ChatMessage('user', tmp$ret$10);
          out.l(element_1);
          break;
        case 2:
          var calls = emptyList();
          // Inline function 'kotlin.text.ifEmpty' call

          var this_1 = item.m5t();
          var tmp_2;
          // Inline function 'kotlin.text.isEmpty' call

          if (charSequenceLength(this_1) === 0) {
            tmp_2 = null;
          } else {
            tmp_2 = this_1;
          }

          var tmp_3 = tmp_2;
          // Inline function 'kotlin.takeIf' call

          var tmp_4;
          // Inline function 'kotlin.collections.isNotEmpty' call

          if (!calls.h1()) {
            tmp_4 = calls;
          } else {
            tmp_4 = null;
          }

          var tmp$ret$17 = tmp_4;
          // Inline function 'kotlin.collections.plusAssign' call

          var element_2 = new ChatMessage('assistant', tmp_3, tmp$ret$17);
          out.l(element_2);
          break;
        case 3:
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
    } else {
      if (item instanceof ToolCall_0) {
        var last = lastOrNull(out);
        var tmp4_elvis_lhs = rawFor(item.y68_1, providerId);
        var native = tmp4_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(item.x68_1) : tmp4_elvis_lhs;
        var call = new ChatReqToolCall(native, VOID, new ChatReqFunction(item.z68_1, item.a69_1));
        if (!(last == null) && last.h7a_1 === 'assistant') {
          var tmp_5 = get_lastIndex(out);
          var tmp5_elvis_lhs = last.j7a_1;
          out.c3(tmp_5, last.l7a(VOID, VOID, plus_0(tmp5_elvis_lhs == null ? emptyList() : tmp5_elvis_lhs, call)));
        } else {
          // Inline function 'kotlin.collections.plusAssign' call
          var element_3 = new ChatMessage('assistant', VOID, listOf(call));
          out.l(element_3);
        }
      } else {
        if (item instanceof ToolResult) {
          // Inline function 'kotlin.collections.filterIsInstance' call
          var tmp0 = _this__u8e3s4.c5y_1;
          // Inline function 'kotlin.collections.filterIsInstanceTo' call
          var destination = ArrayList.k();
          var _iterator__ex2g4s_0 = tmp0.y();
          while (_iterator__ex2g4s_0.z()) {
            var element_4 = _iterator__ex2g4s_0.a1();
            if (element_4 instanceof ToolCall_0) {
              destination.l(element_4);
            }
          }
          var tmp$ret$23;
          $l$block: {
            // Inline function 'kotlin.collections.firstOrNull' call
            var _iterator__ex2g4s_1 = destination.y();
            while (_iterator__ex2g4s_1.z()) {
              var element_5 = _iterator__ex2g4s_1.a1();
              if (element_5.x68_1 === item.u68_1) {
                tmp$ret$23 = element_5;
                break $l$block;
              }
            }
            tmp$ret$23 = null;
          }
          var tmp6_safe_receiver = tmp$ret$23;
          var tmp_6;
          if (tmp6_safe_receiver == null) {
            tmp_6 = null;
          } else {
            // Inline function 'kotlin.let' call
            var tmp0_elvis_lhs = rawFor(tmp6_safe_receiver.y68_1, providerId);
            tmp_6 = tmp0_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(tmp6_safe_receiver.x68_1) : tmp0_elvis_lhs;
          }
          var tmp7_elvis_lhs = tmp_6;
          var callId = tmp7_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(item.u68_1) : tmp7_elvis_lhs;
          // Inline function 'kotlin.collections.plusAssign' call
          var element_6 = new ChatMessage('tool', item.v68_1, VOID, callId);
          out.l(element_6);
        } else {
          if (!(item instanceof ReasoningSummary)) {
            if (item instanceof ProviderItem) {
              ensureDroppable(item, 'chat-completions');
            } else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
  }
  return out;
}
function toChatTool(_this__u8e3s4) {
  return new ChatTool(VOID, new ChatFunctionDef(_this__u8e3s4.c6k_1, _this__u8e3s4.d6k_1, _this__u8e3s4.e6k_1));
}
function toResponseFormat(_this__u8e3s4) {
  var tmp;
  if (equals(_this__u8e3s4, Text_instance)) {
    tmp = null;
  } else {
    if (equals(_this__u8e3s4, JsonObject_instance)) {
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder = new JsonObjectBuilder();
      builder.g3p('type', JsonPrimitive('json_object'));
      tmp = builder.x3n();
    } else {
      if (_this__u8e3s4 instanceof JsonSchema) {
        // Inline function 'kotlinx.serialization.json.buildJsonObject' call
        var builder_0 = new JsonObjectBuilder();
        builder_0.g3p('type', JsonPrimitive('json_schema'));
        // Inline function 'kotlinx.serialization.json.buildJsonObject' call
        var builder_1 = new JsonObjectBuilder();
        builder_1.g3p('name', JsonPrimitive(_this__u8e3s4.d6e_1));
        builder_1.g3p('schema', _this__u8e3s4.e6e_1);
        builder_1.g3p('strict', JsonPrimitive_0(_this__u8e3s4.f6e_1));
        var tmp$ret$3 = builder_1.x3n();
        builder_0.g3p('json_schema', tmp$ret$3);
        tmp = builder_0.x3n();
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return tmp;
}
function ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba() {
  return new ArrayListSerializer($serializer_getInstance_0());
}
function ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba_0() {
  return new ArrayListSerializer($serializer_getInstance_1());
}
function ChatCompletionsRequest$Companion$$childSerializers$_anonymous__fslfba_1() {
  return new ArrayListSerializer(StringSerializer_getInstance());
}
var Companion_instance_2;
function Companion_getInstance_0() {
  if (Companion_instance_2 === VOID)
    new Companion();
  return Companion_instance_2;
}
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance === VOID)
    new $serializer();
  return $serializer_instance;
}
function ChatMessage$Companion$$childSerializers$_anonymous__qywqat() {
  return new ArrayListSerializer($serializer_getInstance_3());
}
var Companion_instance_3;
function Companion_getInstance_1() {
  if (Companion_instance_3 === VOID)
    new Companion_0();
  return Companion_instance_3;
}
var $serializer_instance_0;
function $serializer_getInstance_0() {
  if ($serializer_instance_0 === VOID)
    new $serializer_0();
  return $serializer_instance_0;
}
var Companion_instance_4;
function Companion_getInstance_2() {
  return Companion_instance_4;
}
var $serializer_instance_1;
function $serializer_getInstance_1() {
  if ($serializer_instance_1 === VOID)
    new $serializer_1();
  return $serializer_instance_1;
}
var Companion_instance_5;
function Companion_getInstance_3() {
  return Companion_instance_5;
}
var $serializer_instance_2;
function $serializer_getInstance_2() {
  if ($serializer_instance_2 === VOID)
    new $serializer_2();
  return $serializer_instance_2;
}
var Companion_instance_6;
function Companion_getInstance_4() {
  return Companion_instance_6;
}
var $serializer_instance_3;
function $serializer_getInstance_3() {
  if ($serializer_instance_3 === VOID)
    new $serializer_3();
  return $serializer_instance_3;
}
var Companion_instance_7;
function Companion_getInstance_5() {
  return Companion_instance_7;
}
var $serializer_instance_4;
function $serializer_getInstance_4() {
  if ($serializer_instance_4 === VOID)
    new $serializer_4();
  return $serializer_instance_4;
}
var Companion_instance_8;
function Companion_getInstance_6() {
  return Companion_instance_8;
}
var $serializer_instance_5;
function $serializer_getInstance_5() {
  if ($serializer_instance_5 === VOID)
    new $serializer_5();
  return $serializer_instance_5;
}
var Companion_instance_9;
function Companion_getInstance_7() {
  return Companion_instance_9;
}
var $serializer_instance_6;
function $serializer_getInstance_6() {
  if ($serializer_instance_6 === VOID)
    new $serializer_6();
  return $serializer_instance_6;
}
function ChatCompletionsResponse$Delta$Companion$$childSerializers$_anonymous__fygqye() {
  return new ArrayListSerializer($serializer_getInstance_8());
}
var Companion_instance_10;
function Companion_getInstance_8() {
  if (Companion_instance_10 === VOID)
    new Companion_7();
  return Companion_instance_10;
}
var $serializer_instance_7;
function $serializer_getInstance_7() {
  if ($serializer_instance_7 === VOID)
    new $serializer_7();
  return $serializer_instance_7;
}
var Companion_instance_11;
function Companion_getInstance_9() {
  return Companion_instance_11;
}
var $serializer_instance_8;
function $serializer_getInstance_8() {
  if ($serializer_instance_8 === VOID)
    new $serializer_8();
  return $serializer_instance_8;
}
var Companion_instance_12;
function Companion_getInstance_10() {
  return Companion_instance_12;
}
var $serializer_instance_9;
function $serializer_getInstance_9() {
  if ($serializer_instance_9 === VOID)
    new $serializer_9();
  return $serializer_instance_9;
}
var Companion_instance_13;
function Companion_getInstance_11() {
  return Companion_instance_13;
}
var $serializer_instance_10;
function $serializer_getInstance_10() {
  if ($serializer_instance_10 === VOID)
    new $serializer_10();
  return $serializer_instance_10;
}
var Companion_instance_14;
function Companion_getInstance_12() {
  return Companion_instance_14;
}
var $serializer_instance_11;
function $serializer_getInstance_11() {
  if ($serializer_instance_11 === VOID)
    new $serializer_11();
  return $serializer_instance_11;
}
var Companion_instance_15;
function Companion_getInstance_13() {
  return Companion_instance_15;
}
var $serializer_instance_12;
function $serializer_getInstance_12() {
  if ($serializer_instance_12 === VOID)
    new $serializer_12();
  return $serializer_instance_12;
}
var Companion_instance_16;
function Companion_getInstance_14() {
  return Companion_instance_16;
}
var $serializer_instance_13;
function $serializer_getInstance_13() {
  if ($serializer_instance_13 === VOID)
    new $serializer_13();
  return $serializer_instance_13;
}
function ChatCompletionsResponse$Companion$$childSerializers$_anonymous__8hhtau() {
  return new ArrayListSerializer($serializer_getInstance_6());
}
var Companion_instance_17;
function Companion_getInstance_15() {
  if (Companion_instance_17 === VOID)
    new Companion_14();
  return Companion_instance_17;
}
var $serializer_instance_14;
function $serializer_getInstance_14() {
  if ($serializer_instance_14 === VOID)
    new $serializer_14();
  return $serializer_instance_14;
}
//region block: post-declaration
initMetadataForClass(ToolAcc, 'ToolAcc', ToolAcc);
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(ChatCompletionsDecoder, 'ChatCompletionsDecoder');
initMetadataForClass(ChatCompletionsModel, 'ChatCompletionsModel', VOID, VOID, VOID, [1]);
initMetadataForClass(ChatCompletionsParams, 'ChatCompletionsParams', ChatCompletionsParams);
initMetadataForCompanion(Companion);
protoOf($serializer).k26 = typeParametersSerializers;
initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatCompletionsRequest, 'ChatCompletionsRequest', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
initMetadataForCompanion(Companion_0);
protoOf($serializer_0).k26 = typeParametersSerializers;
initMetadataForObject($serializer_0, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatMessage, 'ChatMessage', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
initMetadataForCompanion(Companion_1);
protoOf($serializer_1).k26 = typeParametersSerializers;
initMetadataForObject($serializer_1, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatTool, 'ChatTool', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_1});
initMetadataForCompanion(Companion_2);
protoOf($serializer_2).k26 = typeParametersSerializers;
initMetadataForObject($serializer_2, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatStreamOptions, 'ChatStreamOptions', ChatStreamOptions, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_2});
initMetadataForCompanion(Companion_3);
protoOf($serializer_3).k26 = typeParametersSerializers;
initMetadataForObject($serializer_3, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatReqToolCall, 'ChatReqToolCall', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_3});
initMetadataForCompanion(Companion_4);
protoOf($serializer_4).k26 = typeParametersSerializers;
initMetadataForObject($serializer_4, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatReqFunction, 'ChatReqFunction', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_4});
initMetadataForCompanion(Companion_5);
protoOf($serializer_5).k26 = typeParametersSerializers;
initMetadataForObject($serializer_5, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatFunctionDef, 'ChatFunctionDef', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_5});
initMetadataForCompanion(Companion_6);
protoOf($serializer_6).k26 = typeParametersSerializers;
initMetadataForObject($serializer_6, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_7);
protoOf($serializer_7).k26 = typeParametersSerializers;
initMetadataForObject($serializer_7, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_8);
protoOf($serializer_8).k26 = typeParametersSerializers;
initMetadataForObject($serializer_8, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_9);
protoOf($serializer_9).k26 = typeParametersSerializers;
initMetadataForObject($serializer_9, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_10);
protoOf($serializer_10).k26 = typeParametersSerializers;
initMetadataForObject($serializer_10, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_11);
protoOf($serializer_11).k26 = typeParametersSerializers;
initMetadataForObject($serializer_11, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_12);
protoOf($serializer_12).k26 = typeParametersSerializers;
initMetadataForObject($serializer_12, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_13);
protoOf($serializer_13).k26 = typeParametersSerializers;
initMetadataForObject($serializer_13, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(Choice, 'Choice', Choice, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_6});
initMetadataForClass(Delta, 'Delta', Delta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_7});
initMetadataForClass(ToolCallChunk, 'ToolCallChunk', ToolCallChunk, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_8});
initMetadataForClass(FunctionChunk, 'FunctionChunk', FunctionChunk, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_9});
initMetadataForClass(Usage_0, 'Usage', Usage_0, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_10});
initMetadataForClass(PromptDetails, 'PromptDetails', PromptDetails, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_11});
initMetadataForClass(CompletionDetails, 'CompletionDetails', CompletionDetails, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_12});
initMetadataForClass(ErrorOutput, 'ErrorOutput', ErrorOutput, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_13});
initMetadataForCompanion(Companion_14);
protoOf($serializer_14).k26 = typeParametersSerializers;
initMetadataForObject($serializer_14, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ChatCompletionsResponse, 'ChatCompletionsResponse', ChatCompletionsResponse, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_14});
//endregion
//region block: init
Companion_instance_4 = new Companion_1();
Companion_instance_5 = new Companion_2();
Companion_instance_6 = new Companion_3();
Companion_instance_7 = new Companion_4();
Companion_instance_8 = new Companion_5();
Companion_instance_9 = new Companion_6();
Companion_instance_11 = new Companion_8();
Companion_instance_12 = new Companion_9();
Companion_instance_13 = new Companion_10();
Companion_instance_14 = new Companion_11();
Companion_instance_15 = new Companion_12();
Companion_instance_16 = new Companion_13();
//endregion
//region block: exports
export {
  ChatCompletionsModel as ChatCompletionsModel2rl4figp5zhty,
  ChatCompletionsParams as ChatCompletionsParams2phuyy1p28jz5,
  normalizeChatCompletionsUrl as normalizeChatCompletionsUrlbu0jml6vp44x,
};
//endregion

//# sourceMappingURL=koaks-model-provider-chat-completions.mjs.map
