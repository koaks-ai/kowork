import {
  EmptySerializersModule991ju6pz9b79 as EmptySerializersModule,
  Decoder23nde051s631g as Decoder,
  CompositeDecoder2tzm7wpwkr0og as CompositeDecoder,
  SerializerFactory1qv9hivitncuv as SerializerFactory,
  serializer1x79l67jvwntn as serializer,
  InlinePrimitiveDescriptor3i6ccn1a4fw94 as InlinePrimitiveDescriptor,
  SEALED_getInstance15u0wl5f5h4qk as SEALED_getInstance,
  buildSerialDescriptor2873qmkp8r2ib as buildSerialDescriptor,
  KSerializerzf77vz1967fq as KSerializer,
  MapSerializer11kmegt3g5c1g as MapSerializer,
  SerialDescriptor2pelqekb5ic3a as SerialDescriptor,
  ListSerializer1hxuk9dx5n9du as ListSerializer,
  ENUM_getInstance3doea03ve3rgg as ENUM_getInstance,
  STRING_getInstance2gbamclnmtzqa as STRING_getInstance,
  PrimitiveSerialDescriptor3egfp53lutxj2 as PrimitiveSerialDescriptor,
  serializer2lw83vwvpnyms as serializer_0,
  get_isNullable36pbikm8xb7bz as get_isNullable,
  get_isInline5x26qrhi9qs6 as get_isInline,
  get_annotationshjxdbdcl8kmv as get_annotations,
  Encoderqvmrpqtq8hnu as Encoder,
  CompositeEncoderknecpkexzn3v as CompositeEncoder,
  ElementMarker33ojvsajwmzts as ElementMarker,
  SerializationExceptioneqrdve3ts2n9 as SerializationException,
  CLASS_getInstance1ss90e870vddp as CLASS_getInstance,
  LIST_getInstance3iji3zetpdcxm as LIST_getInstance,
  CONTEXTUAL_getInstance40twmib99zqv as CONTEXTUAL_getInstance,
  PolymorphicKindla9gurooefwb as PolymorphicKind,
  PrimitiveKindndgbuh6is7ze as PrimitiveKind,
  MAP_getInstance2l4ulrz8ljw5i as MAP_getInstance,
  ENUMlmq49cvwy4ow as ENUM,
  contextual3hpp1gupsu4al as contextual,
  SerializersModuleCollector3dddz14wd7brg as SerializersModuleCollector,
  SealedClassSerializeriwipiibk55zc as SealedClassSerializer,
  jsonCachedSerialNameslxufy2gu43jt as jsonCachedSerialNames,
  AbstractDecoder35guh02ubh2hm as AbstractDecoder,
  AbstractPolymorphicSerializer1ccxwp48nfy58 as AbstractPolymorphicSerializer,
  DeserializationStrategy1z3z5pj9f7zc8 as DeserializationStrategy,
  findPolymorphicSerializer1nm87hvemahcj as findPolymorphicSerializer,
  MissingFieldException24tqif29emcmi as MissingFieldException,
  AbstractEncoder2gxtu3xmy3f8j as AbstractEncoder,
  OBJECT_getInstancee89a3hlgr5ys as OBJECT_getInstance,
  findPolymorphicSerializerk638ixyjovk5 as findPolymorphicSerializer_0,
  SerializationStrategyh6ouydnm6hci as SerializationStrategy,
  serializer3ikrxnm8b29d6 as serializer_1,
  serializer36584sjyg5661 as serializer_2,
  serializer1q7c5q67ysppr as serializer_3,
  NamedValueDecoderzk26ztf92xbq as NamedValueDecoder,
  NamedValueEncoder1lca9edk1lf89 as NamedValueEncoder,
  getContextualDescriptor2n1gf3b895yb8 as getContextualDescriptor,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  VOID7hggqo3abtya as VOID,
  Unit_instance104q5opgivhr8 as Unit_instance,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  equals2au1ep9vhcato as equals,
  toString30pk9tzaqopn as toString_0,
  Enum3alwj03lh1n41 as Enum,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  StringBuildermazzzhj6kkai as StringBuilder,
  hashCodeq5arwsb9dgti as hashCode,
  joinToString1cxrrlmo0chqs as joinToString,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  KtMap140uvy3s5zad8 as KtMap,
  KtList3hktaavzmj137 as KtList,
  numberRangeToNumber25vse2rgp6rs8 as numberRangeToNumber,
  ClosedRangehokgr73im9z3 as ClosedRange,
  isInterface3d6p8outrmvmk as isInterface,
  contains2c50nlxg7en7o as contains,
  toDoubleOrNullkxwozihadygj as toDoubleOrNull,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  toDouble1kn912gjoizjp as toDouble,
  StringCompanionObject_instance2odz3s3zbrixa as StringCompanionObject_instance,
  ArrayList3it5z8td81qkl as ArrayList,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  toLongOrNullutqivezb0wx1 as toLongOrNull,
  toULongOrNullojoyxi0i9tgj as toULongOrNull,
  ULong3f9k7s38t3rfp as ULong,
  Companion_getInstance1poxudqc1ru3p as Companion_getInstance,
  _ULong___get_data__impl__fggpzb1jl4xe0gulani as _ULong___get_data__impl__fggpzb,
  toBooleanStrictOrNull2j0md398tkvbj as toBooleanStrictOrNull,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  lazy2hsh8ze7j6ikd as lazy,
  protoOf180f3jzyo7rfj as protoOf,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  toLongw1zpgk99d84b as toLong,
  _UInt___init__impl__l7qpdl1vpobek1e692 as _UInt___init__impl__l7qpdl,
  UInt__toString_impl_dbgl212oeqkp5cl059g as UInt__toString_impl_dbgl21,
  _ULong___init__impl__c78o9k2uqxdjm6b0lbg as _ULong___init__impl__c78o9k,
  ULong__toString_impl_f9au7k2b7ohj6omvcs4 as ULong__toString_impl_f9au7k,
  _UByte___init__impl__g9hnc415bxbmye0j11o as _UByte___init__impl__g9hnc4,
  UByte__toString_impl_v72jgd49yaowf0kue as UByte__toString_impl_v72jg,
  _UShort___init__impl__jigrne3h2nm35iaibum as _UShort___init__impl__jigrne,
  UShort__toString_impl_edaoee1aumkcln5sauo as UShort__toString_impl_edaoee,
  captureStack1fzi4aczwc4hg as captureStack,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  coerceAtMost322komnqp70ag as coerceAtMost,
  Collection1k04j3hzsbod0 as Collection,
  singleOrNullrknfaxokm1sl as singleOrNull,
  emptyMapr06gerzljqtm as emptyMap,
  getValue48kllevslyh6 as getValue,
  copyOf2ng0t8oizk6it as copyOf,
  copyOf3rutauicler23 as copyOf_0,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  DeepRecursiveFunction3r49v8igsve1g as DeepRecursiveFunction,
  invoke246lvi6tzooz1 as invoke,
  DeepRecursiveScope1pqaydvh4vdcu as DeepRecursiveScope,
  Unitkvevlwgzwiuc as Unit,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  getKClass1s3j9wy1cofik as getKClass,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  substringBefore3n7kj60w69hju as substringBefore,
  removeSuffix3d61x5lsuvuho as removeSuffix,
  substringAfter1hku067gwr5ve as substringAfter,
  contains3ue2qo8xhmpf1 as contains_0,
  plus17rl43at52ays as plus,
  isFinite1tx0gn65nl9tj as isFinite,
  isFinite2t9l5a275mxm6 as isFinite_0,
  toUInt21lx0mz8wkp7c as toUInt,
  _UInt___get_data__impl__f0vqqw9xdox7iecbly as _UInt___get_data__impl__f0vqqw,
  toULong266mnyksbttkw as toULong,
  toUByteh6p4wmqswkrs as toUByte,
  _UByte___get_data__impl__jof9qrfj1ch8mjizvj as _UByte___get_data__impl__jof9qr,
  toUShort7yqspfnhrot4 as toUShort,
  _UShort___get_data__impl__g02459z5yfs6z0kj0 as _UShort___get_data__impl__g0245,
  toString35i91qxh73cps as toString_1,
  Companion_getInstance1z323tr26bmxd as Companion_getInstance_0,
  Companion_getInstance374brtr06v94p as Companion_getInstance_1,
  Companion_getInstanceojp2cj59jqir as Companion_getInstance_2,
  setOf45ia9pnfhe90 as setOf,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  numberToChar93r9buh19yek as numberToChar,
  equals2v6cggk171b6e as equals_0,
  toByte4i43936u611k as toByte,
  startsWith26w8qjqapeeq6 as startsWith,
  single29ec4rh52687r as single,
  Char19o2r8palgjof as Char,
  emptySetcxexqki71qfa as emptySet,
  plus1ogy4liedzq5j as plus_0,
  toInt2q8uldh7sc951 as toInt,
  toList3jhuyej2anx2q as toList,
  throwUninitializedPropertyAccessExceptionyynx7gkm73wd as throwUninitializedPropertyAccessException,
  enumEntries20mr21zbe3az4 as enumEntries,
  last1vo29oleiqj36 as last,
  removeLast3759euu1xvfa3 as removeLast,
  lastIndexOf2d52xhix5ymjr as lastIndexOf,
  Long2qws0ah9gnpki as Long,
  Char__minus_impl_a2frrhem8aw2sny2of as Char__minus_impl_a2frrh,
  numberToLong1a4cndvg6c52s as numberToLong,
  charArray2ujmm1qusno00 as charArray,
  indexOfwa4w6635jewi as indexOf,
  indexOf1xbs558u7wr52 as indexOf_0,
  HashMap1a0ld5kgwhmhv as HashMap,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class Json {
  constructor(configuration, serializersModule) {
    Default_getInstance();
    this.k3m_1 = configuration;
    this.l3m_1 = serializersModule;
    this.m3m_1 = new DescriptorSchemaCache();
  }
  u1y() {
    return this.l3m_1;
  }
  n3m(serializer, value) {
    var result = new JsonToStringWriter();
    try {
      encodeByWriter(this, result, serializer, value);
      return result.toString();
    }finally {
      result.s1i();
    }
  }
  o3m(deserializer, string) {
    var lexer = StringJsonLexer_0(this, string);
    var input = new StreamingJsonDecoder(this, WriteMode_OBJ_getInstance(), lexer, deserializer.w1t(), null);
    var result = input.e1y(deserializer);
    lexer.e3n();
    return result;
  }
  p3m(serializer, value) {
    return writeJson(this, value, serializer);
  }
  q3m(string) {
    return this.o3m(JsonElementSerializer_getInstance(), string);
  }
}
class Default extends Json {
  constructor() {
    Default_instance = null;
    super(new JsonConfiguration(), EmptySerializersModule());
    Default_instance = this;
  }
}
class JsonBuilder {
  constructor(json) {
    this.f3n_1 = json.k3m_1.y3n_1;
    this.g3n_1 = json.k3m_1.d3o_1;
    this.h3n_1 = json.k3m_1.z3n_1;
    this.i3n_1 = json.k3m_1.a3o_1;
    this.j3n_1 = json.k3m_1.c3o_1;
    this.k3n_1 = json.k3m_1.e3o_1;
    this.l3n_1 = json.k3m_1.f3o_1;
    this.m3n_1 = json.k3m_1.h3o_1;
    this.n3n_1 = json.k3m_1.o3o_1;
    this.o3n_1 = json.k3m_1.j3o_1;
    this.p3n_1 = json.k3m_1.k3o_1;
    this.q3n_1 = json.k3m_1.l3o_1;
    this.r3n_1 = json.k3m_1.m3o_1;
    this.s3n_1 = json.k3m_1.n3o_1;
    this.t3n_1 = json.k3m_1.i3o_1;
    this.u3n_1 = json.k3m_1.b3o_1;
    this.v3n_1 = json.k3m_1.g3o_1;
    this.w3n_1 = json.u1y();
  }
  x3n() {
    if (this.v3n_1) {
      // Inline function 'kotlin.require' call
      if (!(this.m3n_1 === 'type')) {
        var message = 'Class discriminator should not be specified when array polymorphism is specified';
        throw IllegalArgumentException.t(toString(message));
      }
      // Inline function 'kotlin.require' call
      if (!this.n3n_1.equals(ClassDiscriminatorMode_POLYMORPHIC_getInstance())) {
        var message_0 = 'useArrayPolymorphism option can only be used if classDiscriminatorMode in a default POLYMORPHIC state.';
        throw IllegalArgumentException.t(toString(message_0));
      }
    }
    if (!this.j3n_1) {
      // Inline function 'kotlin.require' call
      if (!(this.k3n_1 === '    ')) {
        var message_1 = 'Indent should not be specified when default printing mode is used';
        throw IllegalArgumentException.t(toString(message_1));
      }
    } else if (!(this.k3n_1 === '    ')) {
      var tmp3 = this.k3n_1;
      var tmp$ret$7;
      $l$block: {
        // Inline function 'kotlin.text.all' call
        var inductionVariable = 0;
        while (inductionVariable < charSequenceLength(tmp3)) {
          var element = charSequenceGet(tmp3, inductionVariable);
          inductionVariable = inductionVariable + 1 | 0;
          if (!(element === _Char___init__impl__6a9atx(32) || element === _Char___init__impl__6a9atx(9) || element === _Char___init__impl__6a9atx(13) || element === _Char___init__impl__6a9atx(10))) {
            tmp$ret$7 = false;
            break $l$block;
          }
        }
        tmp$ret$7 = true;
      }
      var allWhitespaces = tmp$ret$7;
      // Inline function 'kotlin.require' call
      if (!allWhitespaces) {
        var message_2 = 'Only whitespace, tab, newline and carriage return are allowed as pretty print symbols. Had ' + this.k3n_1;
        throw IllegalArgumentException.t(toString(message_2));
      }
    }
    return new JsonConfiguration(this.f3n_1, this.h3n_1, this.i3n_1, this.u3n_1, this.j3n_1, this.g3n_1, this.k3n_1, this.l3n_1, this.v3n_1, this.m3n_1, this.t3n_1, this.o3n_1, this.p3n_1, this.q3n_1, this.r3n_1, this.s3n_1, this.n3n_1);
  }
}
class JsonImpl extends Json {
  constructor(configuration, module_0) {
    super(configuration, module_0);
    validateConfiguration(this);
  }
}
class JsonClassDiscriminator {}
class JsonIgnoreUnknownKeys {}
class JsonNames {}
class JsonConfiguration {
  constructor(encodeDefaults, ignoreUnknownKeys, isLenient, allowStructuredMapKeys, prettyPrint, explicitNulls, prettyPrintIndent, coerceInputValues, useArrayPolymorphism, classDiscriminator, allowSpecialFloatingPointValues, useAlternativeNames, namingStrategy, decodeEnumsCaseInsensitive, allowTrailingComma, allowComments, classDiscriminatorMode) {
    encodeDefaults = encodeDefaults === VOID ? false : encodeDefaults;
    ignoreUnknownKeys = ignoreUnknownKeys === VOID ? false : ignoreUnknownKeys;
    isLenient = isLenient === VOID ? false : isLenient;
    allowStructuredMapKeys = allowStructuredMapKeys === VOID ? false : allowStructuredMapKeys;
    prettyPrint = prettyPrint === VOID ? false : prettyPrint;
    explicitNulls = explicitNulls === VOID ? true : explicitNulls;
    prettyPrintIndent = prettyPrintIndent === VOID ? '    ' : prettyPrintIndent;
    coerceInputValues = coerceInputValues === VOID ? false : coerceInputValues;
    useArrayPolymorphism = useArrayPolymorphism === VOID ? false : useArrayPolymorphism;
    classDiscriminator = classDiscriminator === VOID ? 'type' : classDiscriminator;
    allowSpecialFloatingPointValues = allowSpecialFloatingPointValues === VOID ? false : allowSpecialFloatingPointValues;
    useAlternativeNames = useAlternativeNames === VOID ? true : useAlternativeNames;
    namingStrategy = namingStrategy === VOID ? null : namingStrategy;
    decodeEnumsCaseInsensitive = decodeEnumsCaseInsensitive === VOID ? false : decodeEnumsCaseInsensitive;
    allowTrailingComma = allowTrailingComma === VOID ? false : allowTrailingComma;
    allowComments = allowComments === VOID ? false : allowComments;
    classDiscriminatorMode = classDiscriminatorMode === VOID ? ClassDiscriminatorMode_POLYMORPHIC_getInstance() : classDiscriminatorMode;
    this.y3n_1 = encodeDefaults;
    this.z3n_1 = ignoreUnknownKeys;
    this.a3o_1 = isLenient;
    this.b3o_1 = allowStructuredMapKeys;
    this.c3o_1 = prettyPrint;
    this.d3o_1 = explicitNulls;
    this.e3o_1 = prettyPrintIndent;
    this.f3o_1 = coerceInputValues;
    this.g3o_1 = useArrayPolymorphism;
    this.h3o_1 = classDiscriminator;
    this.i3o_1 = allowSpecialFloatingPointValues;
    this.j3o_1 = useAlternativeNames;
    this.k3o_1 = namingStrategy;
    this.l3o_1 = decodeEnumsCaseInsensitive;
    this.m3o_1 = allowTrailingComma;
    this.n3o_1 = allowComments;
    this.o3o_1 = classDiscriminatorMode;
  }
  toString() {
    return 'JsonConfiguration(encodeDefaults=' + this.y3n_1 + ', ignoreUnknownKeys=' + this.z3n_1 + ', isLenient=' + this.a3o_1 + ', ' + ('allowStructuredMapKeys=' + this.b3o_1 + ', prettyPrint=' + this.c3o_1 + ', explicitNulls=' + this.d3o_1 + ', ') + ("prettyPrintIndent='" + this.e3o_1 + "', coerceInputValues=" + this.f3o_1 + ', useArrayPolymorphism=' + this.g3o_1 + ', ') + ("classDiscriminator='" + this.h3o_1 + "', allowSpecialFloatingPointValues=" + this.i3o_1 + ', ') + ('useAlternativeNames=' + this.j3o_1 + ', namingStrategy=' + toString_0(this.k3o_1) + ', decodeEnumsCaseInsensitive=' + this.l3o_1 + ', ') + ('allowTrailingComma=' + this.m3o_1 + ', allowComments=' + this.n3o_1 + ', classDiscriminatorMode=' + this.o3o_1.toString() + ')');
  }
}
class ClassDiscriminatorMode extends Enum {}
class JsonDecoder {}
class Companion {
  r3o() {
    return JsonObjectSerializer_getInstance();
  }
}
class JsonElement {}
class JsonObject extends JsonElement {
  constructor(content) {
    super();
    this.s3o_1 = content;
  }
  equals(other) {
    return equals(this.s3o_1, other);
  }
  hashCode() {
    return hashCode(this.s3o_1);
  }
  toString() {
    var tmp = this.s3o_1.l1();
    return joinToString(tmp, ',', '{', '}', VOID, VOID, JsonObject$toString$lambda);
  }
  h1() {
    return this.s3o_1.h1();
  }
  k2g(key) {
    return this.s3o_1.f3(key);
  }
  f3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return false;
    return this.k2g((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  l2g(key) {
    return this.s3o_1.h3(key);
  }
  h3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return null;
    return this.l2g((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  b1() {
    return this.s3o_1.b1();
  }
  i3() {
    return this.s3o_1.i3();
  }
  j3() {
    return this.s3o_1.j3();
  }
  l1() {
    return this.s3o_1.l1();
  }
}
class Companion_0 {
  r3o() {
    return JsonElementSerializer_getInstance();
  }
}
class Companion_1 {}
class JsonArray extends JsonElement {
  constructor(content) {
    super();
    this.t3o_1 = content;
  }
  equals(other) {
    return equals(this.t3o_1, other);
  }
  hashCode() {
    return hashCode(this.t3o_1);
  }
  toString() {
    return joinToString(this.t3o_1, ',', '[', ']');
  }
  h1() {
    return this.t3o_1.h1();
  }
  u3o(element) {
    return this.t3o_1.v2(element);
  }
  v2(element) {
    if (!(element instanceof JsonElement))
      return false;
    return this.u3o(element instanceof JsonElement ? element : THROW_CCE());
  }
  y() {
    return this.t3o_1.y();
  }
  v3o(elements) {
    return this.t3o_1.w2(elements);
  }
  w2(elements) {
    return this.v3o(elements);
  }
  f1(index) {
    return this.t3o_1.f1(index);
  }
  w3o(element) {
    return this.t3o_1.x2(element);
  }
  x2(element) {
    if (!(element instanceof JsonElement))
      return -1;
    return this.w3o(element instanceof JsonElement ? element : THROW_CCE());
  }
  i1(index) {
    return this.t3o_1.i1(index);
  }
  y2(fromIndex, toIndex) {
    return this.t3o_1.y2(fromIndex, toIndex);
  }
  b1() {
    return this.t3o_1.b1();
  }
}
class JsonPrimitive extends JsonElement {
  toString() {
    return this.y3o();
  }
}
class JsonNull extends JsonPrimitive {
  constructor() {
    JsonNull_instance = null;
    super();
    JsonNull_instance = this;
    this.x3o_1 = 'null';
  }
  y3o() {
    return this.x3o_1;
  }
  r3o() {
    return JsonNullSerializer_getInstance();
  }
  v26(typeParamsSerializers) {
    return this.r3o();
  }
}
class Companion_2 {}
class JsonLiteral extends JsonPrimitive {
  constructor(body, isString, coerceToInlineType) {
    coerceToInlineType = coerceToInlineType === VOID ? null : coerceToInlineType;
    super();
    this.z3o_1 = isString;
    this.a3p_1 = coerceToInlineType;
    this.b3p_1 = toString(body);
    if (!(this.a3p_1 == null)) {
      // Inline function 'kotlin.require' call
      // Inline function 'kotlin.require' call
      if (!this.a3p_1.k1w()) {
        var message = 'Failed requirement.';
        throw IllegalArgumentException.t(toString(message));
      }
    }
  }
  y3o() {
    return this.b3p_1;
  }
  toString() {
    var tmp;
    if (this.z3o_1) {
      // Inline function 'kotlin.text.buildString' call
      // Inline function 'kotlin.apply' call
      var this_0 = StringBuilder.v();
      printQuoted(this_0, this.b3p_1);
      tmp = this_0.toString();
    } else {
      tmp = this.b3p_1;
    }
    return tmp;
  }
  equals(other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof JsonLiteral))
      THROW_CCE();
    if (!(this.z3o_1 === other.z3o_1))
      return false;
    if (!(this.b3p_1 === other.b3p_1))
      return false;
    return true;
  }
  hashCode() {
    var result = getBooleanHashCode(this.z3o_1);
    result = imul(31, result) + getStringHashCode(this.b3p_1) | 0;
    return result;
  }
}
class JsonArrayBuilder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.d3p_1 = ArrayList.k();
  }
  e3p(element) {
    // Inline function 'kotlin.collections.plusAssign' call
    this.d3p_1.l(element);
    return true;
  }
  x3n() {
    return new JsonArray(this.d3p_1);
  }
}
class JsonObjectBuilder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.linkedMapOf' call
    tmp.f3p_1 = LinkedHashMap.hc();
  }
  g3p(key, element) {
    return this.f3p_1.k3(key, element);
  }
  x3n() {
    return new JsonObject(this.f3p_1);
  }
}
class JsonElementSerializer {
  constructor() {
    JsonElementSerializer_instance = this;
    var tmp = this;
    var tmp_0 = SEALED_getInstance();
    tmp.m3p_1 = buildSerialDescriptor('kotlinx.serialization.json.JsonElement', tmp_0, [], JsonElementSerializer$descriptor$lambda);
  }
  w1t() {
    return this.m3p_1;
  }
  n3p(encoder, value) {
    verify(encoder);
    if (value instanceof JsonPrimitive) {
      encoder.y1z(JsonPrimitiveSerializer_getInstance(), value);
    } else {
      if (value instanceof JsonObject) {
        encoder.y1z(JsonObjectSerializer_getInstance(), value);
      } else {
        if (value instanceof JsonArray) {
          encoder.y1z(JsonArraySerializer_getInstance(), value);
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  x1t(encoder, value) {
    return this.n3p(encoder, value instanceof JsonElement ? value : THROW_CCE());
  }
  y1t(decoder) {
    var input = asJsonDecoder(decoder);
    return input.q3o();
  }
}
class JsonObjectDescriptor {
  constructor() {
    JsonObjectDescriptor_instance = this;
    this.o3p_1 = MapSerializer(serializer(StringCompanionObject_instance), JsonElementSerializer_getInstance()).w1t();
    this.p3p_1 = 'kotlinx.serialization.json.JsonObject';
  }
  z1u() {
    return this.p3p_1;
  }
  n1w(index) {
    return this.o3p_1.n1w(index);
  }
  o1w(name) {
    return this.o3p_1.o1w(name);
  }
  p1w(index) {
    return this.o3p_1.p1w(index);
  }
  q1w(index) {
    return this.o3p_1.q1w(index);
  }
  r1w(index) {
    return this.o3p_1.r1w(index);
  }
  j1w() {
    return this.o3p_1.j1w();
  }
  f1w() {
    return this.o3p_1.f1w();
  }
  k1w() {
    return this.o3p_1.k1w();
  }
  l1w() {
    return this.o3p_1.l1w();
  }
  m1w() {
    return this.o3p_1.m1w();
  }
}
class JsonObjectSerializer {
  constructor() {
    JsonObjectSerializer_instance = this;
    this.k3p_1 = JsonObjectDescriptor_getInstance();
  }
  w1t() {
    return this.k3p_1;
  }
  q3p(encoder, value) {
    verify(encoder);
    MapSerializer(serializer(StringCompanionObject_instance), JsonElementSerializer_getInstance()).x1t(encoder, value);
  }
  x1t(encoder, value) {
    return this.q3p(encoder, value instanceof JsonObject ? value : THROW_CCE());
  }
  y1t(decoder) {
    verify_0(decoder);
    return new JsonObject(MapSerializer(serializer(StringCompanionObject_instance), JsonElementSerializer_getInstance()).y1t(decoder));
  }
}
class JsonArrayDescriptor {
  constructor() {
    JsonArrayDescriptor_instance = this;
    this.r3p_1 = ListSerializer(JsonElementSerializer_getInstance()).w1t();
    this.s3p_1 = 'kotlinx.serialization.json.JsonArray';
  }
  z1u() {
    return this.s3p_1;
  }
  n1w(index) {
    return this.r3p_1.n1w(index);
  }
  o1w(name) {
    return this.r3p_1.o1w(name);
  }
  p1w(index) {
    return this.r3p_1.p1w(index);
  }
  q1w(index) {
    return this.r3p_1.q1w(index);
  }
  r1w(index) {
    return this.r3p_1.r1w(index);
  }
  j1w() {
    return this.r3p_1.j1w();
  }
  f1w() {
    return this.r3p_1.f1w();
  }
  k1w() {
    return this.r3p_1.k1w();
  }
  l1w() {
    return this.r3p_1.l1w();
  }
  m1w() {
    return this.r3p_1.m1w();
  }
}
class JsonArraySerializer {
  constructor() {
    JsonArraySerializer_instance = this;
    this.l3p_1 = JsonArrayDescriptor_getInstance();
  }
  w1t() {
    return this.l3p_1;
  }
  t3p(encoder, value) {
    verify(encoder);
    ListSerializer(JsonElementSerializer_getInstance()).x1t(encoder, value);
  }
  x1t(encoder, value) {
    return this.t3p(encoder, value instanceof JsonArray ? value : THROW_CCE());
  }
  y1t(decoder) {
    verify_0(decoder);
    return new JsonArray(ListSerializer(JsonElementSerializer_getInstance()).y1t(decoder));
  }
}
class JsonNullSerializer {
  constructor() {
    JsonNullSerializer_instance = this;
    this.i3p_1 = buildSerialDescriptor('kotlinx.serialization.json.JsonNull', ENUM_getInstance(), []);
  }
  w1t() {
    return this.i3p_1;
  }
  u3p(encoder, value) {
    verify(encoder);
    encoder.b1z();
  }
  x1t(encoder, value) {
    return this.u3p(encoder, value instanceof JsonNull ? value : THROW_CCE());
  }
  y1t(decoder) {
    verify_0(decoder);
    if (decoder.q1x()) {
      throw JsonDecodingException.b3q("Expected 'null' literal");
    }
    decoder.r1x();
    return JsonNull_getInstance();
  }
}
class JsonPrimitiveSerializer {
  constructor() {
    JsonPrimitiveSerializer_instance = this;
    this.h3p_1 = buildSerialDescriptor('kotlinx.serialization.json.JsonPrimitive', STRING_getInstance(), []);
  }
  w1t() {
    return this.h3p_1;
  }
  c3q(encoder, value) {
    verify(encoder);
    var tmp;
    if (value instanceof JsonNull) {
      encoder.y1z(JsonNullSerializer_getInstance(), JsonNull_getInstance());
      tmp = Unit_instance;
    } else {
      var tmp_0 = JsonLiteralSerializer_getInstance();
      encoder.y1z(tmp_0, value instanceof JsonLiteral ? value : THROW_CCE());
      tmp = Unit_instance;
    }
    return tmp;
  }
  x1t(encoder, value) {
    return this.c3q(encoder, value instanceof JsonPrimitive ? value : THROW_CCE());
  }
  y1t(decoder) {
    var result = asJsonDecoder(decoder).q3o();
    if (!(result instanceof JsonPrimitive))
      throw JsonDecodingException_0(-1, 'Unexpected JSON element, expected JsonPrimitive, had ' + toString(getKClassFromExpression(result)), toString(result));
    return result;
  }
}
class JsonLiteralSerializer {
  constructor() {
    JsonLiteralSerializer_instance = this;
    this.j3p_1 = PrimitiveSerialDescriptor('kotlinx.serialization.json.JsonLiteral', STRING_getInstance());
  }
  w1t() {
    return this.j3p_1;
  }
  d3q(encoder, value) {
    verify(encoder);
    if (value.z3o_1) {
      return encoder.k1z(value.b3p_1);
    }
    if (!(value.a3p_1 == null)) {
      return encoder.m1z(value.a3p_1).k1z(value.b3p_1);
    }
    var tmp0_safe_receiver = toLongOrNull(value.b3p_1);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return encoder.g1z(tmp0_safe_receiver);
    }
    var tmp1_safe_receiver = toULongOrNull(value.b3p_1);
    var tmp = tmp1_safe_receiver;
    if ((tmp == null ? null : new ULong(tmp)) == null)
      null;
    else {
      var tmp_0 = tmp1_safe_receiver;
      // Inline function 'kotlin.let' call
      var it = (tmp_0 == null ? null : new ULong(tmp_0)).dt_1;
      var tmp_1 = encoder.m1z(serializer_0(Companion_getInstance()).w1t());
      // Inline function 'kotlin.ULong.toLong' call
      var tmp$ret$1 = _ULong___get_data__impl__fggpzb(it);
      tmp_1.g1z(tmp$ret$1);
      return Unit_instance;
    }
    var tmp2_safe_receiver = toDoubleOrNull(value.b3p_1);
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return encoder.i1z(tmp2_safe_receiver);
    }
    var tmp3_safe_receiver = toBooleanStrictOrNull(value.b3p_1);
    if (tmp3_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return encoder.c1z(tmp3_safe_receiver);
    }
    encoder.k1z(value.b3p_1);
  }
  x1t(encoder, value) {
    return this.d3q(encoder, value instanceof JsonLiteral ? value : THROW_CCE());
  }
  y1t(decoder) {
    var result = asJsonDecoder(decoder).q3o();
    if (!(result instanceof JsonLiteral))
      throw JsonDecodingException_0(-1, 'Unexpected JSON element, expected JsonLiteral, had ' + toString(getKClassFromExpression(result)), toString(result));
    return result;
  }
}
class defer$1 {
  constructor($deferred) {
    this.e3q_1 = lazy($deferred);
  }
  z1u() {
    return _get_original__l7ku1m(this).z1u();
  }
  j1w() {
    return _get_original__l7ku1m(this).j1w();
  }
  l1w() {
    return _get_original__l7ku1m(this).l1w();
  }
  n1w(index) {
    return _get_original__l7ku1m(this).n1w(index);
  }
  o1w(name) {
    return _get_original__l7ku1m(this).o1w(name);
  }
  p1w(index) {
    return _get_original__l7ku1m(this).p1w(index);
  }
  q1w(index) {
    return _get_original__l7ku1m(this).q1w(index);
  }
  r1w(index) {
    return _get_original__l7ku1m(this).r1w(index);
  }
}
class JsonEncoder {}
class Composer {
  constructor(writer) {
    this.f3q_1 = writer;
    this.g3q_1 = true;
  }
  h3q() {
    this.g3q_1 = true;
  }
  i3q() {
    return Unit_instance;
  }
  j3q() {
    this.g3q_1 = false;
  }
  k3q() {
    this.g3q_1 = false;
  }
  l3q() {
    return Unit_instance;
  }
  m3q(v) {
    return this.f3q_1.n3q(v);
  }
  o3q(v) {
    return this.f3q_1.p3q(v);
  }
  q3q(v) {
    return this.f3q_1.p3q(v.toString());
  }
  r3q(v) {
    return this.f3q_1.p3q(v.toString());
  }
  s3q(v) {
    return this.f3q_1.t3q(toLong(v));
  }
  u3q(v) {
    return this.f3q_1.t3q(toLong(v));
  }
  v3q(v) {
    return this.f3q_1.t3q(toLong(v));
  }
  w3q(v) {
    return this.f3q_1.t3q(v);
  }
  x3q(v) {
    return this.f3q_1.p3q(v.toString());
  }
  y3q(value) {
    return this.f3q_1.z3q(value);
  }
}
class ComposerForUnsignedNumbers extends Composer {
  constructor(writer, forceQuoting) {
    super(writer);
    this.c3r_1 = forceQuoting;
  }
  v3q(v) {
    if (this.c3r_1) {
      // Inline function 'kotlin.toUInt' call
      var tmp$ret$0 = _UInt___init__impl__l7qpdl(v);
      this.y3q(UInt__toString_impl_dbgl21(tmp$ret$0));
    } else {
      // Inline function 'kotlin.toUInt' call
      var tmp$ret$1 = _UInt___init__impl__l7qpdl(v);
      this.o3q(UInt__toString_impl_dbgl21(tmp$ret$1));
    }
  }
  w3q(v) {
    if (this.c3r_1) {
      // Inline function 'kotlin.toULong' call
      var tmp$ret$0 = _ULong___init__impl__c78o9k(v);
      this.y3q(ULong__toString_impl_f9au7k(tmp$ret$0));
    } else {
      // Inline function 'kotlin.toULong' call
      var tmp$ret$1 = _ULong___init__impl__c78o9k(v);
      this.o3q(ULong__toString_impl_f9au7k(tmp$ret$1));
    }
  }
  s3q(v) {
    if (this.c3r_1) {
      // Inline function 'kotlin.toUByte' call
      var tmp$ret$0 = _UByte___init__impl__g9hnc4(v);
      this.y3q(UByte__toString_impl_v72jg(tmp$ret$0));
    } else {
      // Inline function 'kotlin.toUByte' call
      var tmp$ret$1 = _UByte___init__impl__g9hnc4(v);
      this.o3q(UByte__toString_impl_v72jg(tmp$ret$1));
    }
  }
  u3q(v) {
    if (this.c3r_1) {
      // Inline function 'kotlin.toUShort' call
      var tmp$ret$0 = _UShort___init__impl__jigrne(v);
      this.y3q(UShort__toString_impl_edaoee(tmp$ret$0));
    } else {
      // Inline function 'kotlin.toUShort' call
      var tmp$ret$1 = _UShort___init__impl__jigrne(v);
      this.o3q(UShort__toString_impl_edaoee(tmp$ret$1));
    }
  }
}
class ComposerForUnquotedLiterals extends Composer {
  constructor(writer, forceQuoting) {
    super(writer);
    this.f3r_1 = forceQuoting;
  }
  y3q(value) {
    if (this.f3r_1) {
      super.y3q(value);
    } else {
      super.o3q(value);
    }
  }
}
class ComposerWithPrettyPrint extends Composer {
  constructor(writer, json) {
    super(writer);
    this.i3r_1 = json;
    this.j3r_1 = 0;
  }
  h3q() {
    this.g3q_1 = true;
    this.j3r_1 = this.j3r_1 + 1 | 0;
  }
  i3q() {
    this.j3r_1 = this.j3r_1 - 1 | 0;
  }
  j3q() {
    this.g3q_1 = false;
    this.o3q('\n');
    // Inline function 'kotlin.repeat' call
    var times = this.j3r_1;
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.o3q(this.i3r_1.k3m_1.e3o_1);
      }
       while (inductionVariable < times);
  }
  k3q() {
    if (this.g3q_1)
      this.g3q_1 = false;
    else {
      this.j3q();
    }
  }
  l3q() {
    this.m3q(_Char___init__impl__6a9atx(32));
  }
}
class JsonElementMarker {
  constructor(descriptor) {
    var tmp = this;
    tmp.k3r_1 = new ElementMarker(descriptor, JsonElementMarker$readIfAbsent$ref(this));
    this.l3r_1 = false;
  }
  m3r(index) {
    this.k3r_1.m24(index);
  }
  n3r() {
    return this.k3r_1.n24();
  }
}
class JsonException extends SerializationException {
  static t3r(message) {
    var $this = this.i1v(message);
    captureStack($this, $this.s3r_1);
    return $this;
  }
}
class JsonDecodingException extends JsonException {
  static b3q(message) {
    var $this = this.t3r(message);
    captureStack($this, $this.a3q_1);
    return $this;
  }
}
class JsonEncodingException extends JsonException {
  static c3s(message) {
    var $this = this.t3r(message);
    captureStack($this, $this.b3s_1);
    return $this;
  }
}
class Tombstone {}
class JsonPath {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.arrayOfNulls' call
    tmp.h3s_1 = Array(8);
    var tmp_0 = this;
    var tmp_1 = 0;
    var tmp_2 = new Int32Array(8);
    while (tmp_1 < 8) {
      tmp_2[tmp_1] = -1;
      tmp_1 = tmp_1 + 1 | 0;
    }
    tmp_0.i3s_1 = tmp_2;
    this.j3s_1 = -1;
  }
  k3s(sd) {
    this.j3s_1 = this.j3s_1 + 1 | 0;
    var depth = this.j3s_1;
    if (depth === this.h3s_1.length) {
      resize(this);
    }
    this.h3s_1[depth] = sd;
  }
  l3s(index) {
    this.i3s_1[this.j3s_1] = index;
  }
  m3s(key) {
    var tmp;
    if (!(this.i3s_1[this.j3s_1] === -2)) {
      this.j3s_1 = this.j3s_1 + 1 | 0;
      tmp = this.j3s_1 === this.h3s_1.length;
    } else {
      tmp = false;
    }
    if (tmp) {
      resize(this);
    }
    this.h3s_1[this.j3s_1] = key;
    this.i3s_1[this.j3s_1] = -2;
  }
  n3s() {
    if (this.i3s_1[this.j3s_1] === -2) {
      this.h3s_1[this.j3s_1] = Tombstone_instance;
    }
  }
  o3s() {
    var depth = this.j3s_1;
    if (this.i3s_1[depth] === -2) {
      this.i3s_1[depth] = -1;
      this.j3s_1 = this.j3s_1 - 1 | 0;
    }
    if (!(this.j3s_1 === -1)) {
      this.j3s_1 = this.j3s_1 - 1 | 0;
    }
  }
  p3s() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb('$');
    // Inline function 'kotlin.repeat' call
    var times = this.j3s_1 + 1 | 0;
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var element = this.h3s_1[index];
        if (!(element == null) ? isInterface(element, SerialDescriptor) : false) {
          if (equals(element.j1w(), LIST_getInstance())) {
            if (!(this.i3s_1[index] === -1)) {
              this_0.tb('[');
              this_0.fh(this.i3s_1[index]);
              this_0.tb(']');
            }
          } else {
            var idx = this.i3s_1[index];
            if (idx >= 0) {
              this_0.tb('.');
              this_0.tb(element.n1w(idx));
            }
          }
        } else {
          if (!(element === Tombstone_instance)) {
            this_0.tb('[');
            this_0.tb("'");
            this_0.sb(element);
            this_0.tb("'");
            this_0.tb(']');
          }
        }
      }
       while (inductionVariable < times);
    return this_0.toString();
  }
  toString() {
    return this.p3s();
  }
}
class JsonSerializersModuleValidator {
  constructor(configuration) {
    this.q3s_1 = configuration.h3o_1;
    this.r3s_1 = configuration.g3o_1;
    this.s3s_1 = !configuration.o3o_1.equals(ClassDiscriminatorMode_NONE_getInstance());
  }
  p2f(kClass, provider) {
  }
  s2f(baseClass, actualClass, actualSerializer) {
    var descriptor = actualSerializer.w1t();
    checkKind(this, descriptor, actualClass);
    if (!this.r3s_1 && this.s3s_1) {
      checkDiscriminatorCollisions(this, descriptor, actualClass);
    }
  }
  t2f(baseClass, defaultSerializerProvider) {
  }
  u2f(baseClass, defaultDeserializerProvider) {
  }
}
class JsonTreeReader$readDeepRecursive$slambda {
  constructor(this$0) {
    this.h3t_1 = this$0;
  }
  p3t($this$DeepRecursiveFunction, it, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8.bind(VOID, this, $this$DeepRecursiveFunction, it), $completion);
  }
  ud(p1, p2, $completion) {
    var tmp = p1 instanceof DeepRecursiveScope ? p1 : THROW_CCE();
    return this.p3t(tmp, p2 instanceof Unit ? p2 : THROW_CCE(), $completion);
  }
}
class JsonTreeReader {
  constructor(configuration, lexer) {
    this.d3t_1 = lexer;
    this.e3t_1 = configuration.a3o_1;
    this.f3t_1 = configuration.m3o_1;
    this.g3t_1 = 0;
  }
  n3t() {
    var token = this.d3t_1.i3t();
    var tmp;
    if (token === 1) {
      tmp = readValue(this, true);
    } else if (token === 0) {
      tmp = readValue(this, false);
    } else if (token === 6) {
      var tmp_0;
      this.g3t_1 = this.g3t_1 + 1 | 0;
      if (this.g3t_1 === 200) {
        tmp_0 = readDeepRecursive(this);
      } else {
        tmp_0 = readObject(this);
      }
      var result = tmp_0;
      this.g3t_1 = this.g3t_1 - 1 | 0;
      tmp = result;
    } else if (token === 8) {
      tmp = readArray(this);
    } else {
      this.d3t_1.v3r('Cannot read Json element because of unexpected ' + tokenDescription(token));
    }
    return tmp;
  }
}
class Key {}
class DescriptorSchemaCache {
  constructor() {
    this.d3s_1 = createMapForCache(16);
  }
  r3t(descriptor, key, value) {
    // Inline function 'kotlin.collections.getOrPut' call
    var this_0 = this.d3s_1;
    var value_0 = this_0.h3(descriptor);
    var tmp;
    if (value_0 == null) {
      var answer = createMapForCache(2);
      this_0.k3(descriptor, answer);
      tmp = answer;
    } else {
      tmp = value_0;
    }
    var tmp2 = tmp;
    var tmp3 = key instanceof Key ? key : THROW_CCE();
    // Inline function 'kotlin.collections.set' call
    var value_1 = !(value == null) ? value : THROW_CCE();
    tmp2.k3(tmp3, value_1);
  }
  e3s(descriptor, key, defaultValue) {
    var tmp0_safe_receiver = this.s3t(descriptor, key);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var value = defaultValue();
    this.r3t(descriptor, key, value);
    return value;
  }
  s3t(descriptor, key) {
    var tmp0_safe_receiver = this.d3s_1.h3(descriptor);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      tmp = tmp0_safe_receiver.h3(key instanceof Key ? key : THROW_CCE());
    }
    var tmp_0 = tmp;
    return !(tmp_0 == null) ? tmp_0 : null;
  }
}
class DiscriminatorHolder {
  constructor(discriminatorToSkip) {
    this.t3t_1 = discriminatorToSkip;
  }
}
class StreamingJsonDecoder extends AbstractDecoder {
  constructor(json, mode, lexer, descriptor, discriminatorHolder) {
    super();
    this.s3m_1 = json;
    this.t3m_1 = mode;
    this.u3m_1 = lexer;
    this.v3m_1 = this.s3m_1.u1y();
    this.w3m_1 = -1;
    this.x3m_1 = discriminatorHolder;
    this.y3m_1 = this.s3m_1.k3m_1;
    this.z3m_1 = this.y3m_1.d3o_1 ? null : new JsonElementMarker(descriptor);
  }
  p3o() {
    return this.s3m_1;
  }
  u1y() {
    return this.v3m_1;
  }
  q3o() {
    return (new JsonTreeReader(this.s3m_1.k3m_1, this.u3m_1)).n3t();
  }
  e1y(deserializer) {
    try {
      var tmp;
      if (!(deserializer instanceof AbstractPolymorphicSerializer)) {
        tmp = true;
      } else {
        tmp = this.s3m_1.k3m_1.g3o_1;
      }
      if (tmp) {
        return deserializer.y1t(this);
      }
      var discriminator = classDiscriminator(deserializer.w1t(), this.s3m_1);
      var tmp0_elvis_lhs = this.u3m_1.c3u(discriminator, this.y3m_1.a3o_1);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        var tmp1 = isInterface(deserializer, DeserializationStrategy) ? deserializer : THROW_CCE();
        var tmp$ret$0;
        $l$block: {
          // Inline function 'kotlinx.serialization.json.internal.decodeSerializableValuePolymorphic' call
          var tmp_1;
          if (!(tmp1 instanceof AbstractPolymorphicSerializer)) {
            tmp_1 = true;
          } else {
            tmp_1 = this.p3o().k3m_1.g3o_1;
          }
          if (tmp_1) {
            tmp$ret$0 = tmp1.y1t(this);
            break $l$block;
          }
          var discriminator_0 = classDiscriminator(tmp1.w1t(), this.p3o());
          var tmp0 = this.q3o();
          // Inline function 'kotlinx.serialization.json.internal.cast' call
          var serialName = tmp1.w1t().z1u();
          if (!(tmp0 instanceof JsonObject)) {
            var tmp_2 = getKClass(JsonObject).hf();
            var tmp_3 = getKClassFromExpression(tmp0).hf();
            var tmp$ret$1 = this.u3m_1.b3n_1.p3s();
            throw JsonDecodingException_0(-1, 'Expected ' + tmp_2 + ', but had ' + tmp_3 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$1, toString(tmp0));
          }
          var jsonTree = tmp0;
          var tmp0_safe_receiver = jsonTree.l2g(discriminator_0);
          var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
          var type = tmp1_safe_receiver == null ? null : get_contentOrNull(tmp1_safe_receiver);
          var tmp_4;
          try {
            tmp_4 = findPolymorphicSerializer(tmp1, this, type);
          } catch ($p) {
            var tmp_5;
            if ($p instanceof SerializationException) {
              var it = $p;
              throw JsonDecodingException_0(-1, ensureNotNull(it.message), jsonTree.toString());
            } else {
              throw $p;
            }
          }
          var tmp_6 = tmp_4;
          var actualSerializer = isInterface(tmp_6, DeserializationStrategy) ? tmp_6 : THROW_CCE();
          tmp$ret$0 = readPolymorphicJson(this.p3o(), discriminator_0, jsonTree, actualSerializer);
        }
        return tmp$ret$0;
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      var type_0 = tmp_0;
      var tmp_7;
      try {
        tmp_7 = findPolymorphicSerializer(deserializer, this, type_0);
      } catch ($p) {
        var tmp_8;
        if ($p instanceof SerializationException) {
          var it_0 = $p;
          var message = removeSuffix(substringBefore(ensureNotNull(it_0.message), _Char___init__impl__6a9atx(10)), '.');
          var hint = substringAfter(ensureNotNull(it_0.message), _Char___init__impl__6a9atx(10), '');
          this.u3m_1.v3r(message, VOID, hint);
        } else {
          throw $p;
        }
        tmp_7 = tmp_8;
      }
      var tmp_9 = tmp_7;
      var actualSerializer_0 = isInterface(tmp_9, DeserializationStrategy) ? tmp_9 : THROW_CCE();
      this.x3m_1 = new DiscriminatorHolder(discriminator);
      return actualSerializer_0.y1t(this);
    } catch ($p) {
      if ($p instanceof MissingFieldException) {
        var e = $p;
        if (contains_0(ensureNotNull(e.message), 'at path'))
          throw e;
        throw MissingFieldException.q1v(e.o1v_1, plus(e.message, ' at path: ') + this.u3m_1.b3n_1.p3s(), e);
      } else {
        throw $p;
      }
    }
  }
  f1y(descriptor) {
    var newMode = switchMode(this.s3m_1, descriptor);
    this.u3m_1.b3n_1.k3s(descriptor);
    this.u3m_1.u3t(newMode.f3u_1);
    checkLeadingComma(this);
    var tmp;
    switch (newMode.o3_1) {
      case 1:
      case 2:
      case 3:
        tmp = new StreamingJsonDecoder(this.s3m_1, newMode, this.u3m_1, descriptor, this.x3m_1);
        break;
      default:
        var tmp_0;
        if (this.t3m_1.equals(newMode) && this.s3m_1.k3m_1.d3o_1) {
          tmp_0 = this;
        } else {
          tmp_0 = new StreamingJsonDecoder(this.s3m_1, newMode, this.u3m_1, descriptor, this.x3m_1);
        }

        tmp = tmp_0;
        break;
    }
    return tmp;
  }
  g1y(descriptor) {
    if (descriptor.l1w() === 0 && ignoreUnknownKeys(descriptor, this.s3m_1)) {
      skipLeftoverElements(this, descriptor);
    }
    if (this.u3m_1.v3t() && !this.s3m_1.k3m_1.m3o_1) {
      invalidTrailingComma(this.u3m_1, '');
    }
    this.u3m_1.u3t(this.t3m_1.g3u_1);
    this.u3m_1.b3n_1.o3s();
  }
  q1x() {
    var tmp;
    var tmp0_safe_receiver = this.z3m_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.l3r_1;
    if (!(tmp1_elvis_lhs == null ? false : tmp1_elvis_lhs)) {
      tmp = !this.u3m_1.h3u();
    } else {
      tmp = false;
    }
    return tmp;
  }
  r1x() {
    return null;
  }
  r1y(descriptor, index, deserializer, previousValue) {
    var isMapKey = this.t3m_1.equals(WriteMode_MAP_getInstance()) && (index & 1) === 0;
    if (isMapKey) {
      this.u3m_1.b3n_1.n3s();
    }
    var value = super.r1y(descriptor, index, deserializer, previousValue);
    if (isMapKey) {
      this.u3m_1.b3n_1.m3s(value);
    }
    return value;
  }
  w1y(descriptor) {
    var index;
    switch (this.t3m_1.o3_1) {
      case 0:
        index = decodeObjectIndex(this, descriptor);
        break;
      case 2:
        index = decodeMapIndex(this);
        break;
      default:
        index = decodeListIndex(this);
        break;
    }
    if (!this.t3m_1.equals(WriteMode_MAP_getInstance())) {
      this.u3m_1.b3n_1.l3s(index);
    }
    return index;
  }
  s1x() {
    return this.u3m_1.i3u();
  }
  t1x() {
    var value = this.u3m_1.j3u();
    if (!value.equals(toLong(value.k4()))) {
      this.u3m_1.v3r("Failed to parse byte for input '" + value.toString() + "'");
    }
    return value.k4();
  }
  u1x() {
    var value = this.u3m_1.j3u();
    if (!value.equals(toLong(value.l4()))) {
      this.u3m_1.v3r("Failed to parse short for input '" + value.toString() + "'");
    }
    return value.l4();
  }
  v1x() {
    var value = this.u3m_1.j3u();
    if (!value.equals(toLong(value.x1()))) {
      this.u3m_1.v3r("Failed to parse int for input '" + value.toString() + "'");
    }
    return value.x1();
  }
  w1x() {
    return this.u3m_1.j3u();
  }
  x1x() {
    var tmp0 = this.u3m_1;
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.m3t();
      try {
        // Inline function 'kotlin.text.toFloat' call
        // Inline function 'kotlin.js.unsafeCast' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp$ret$4 = toDouble(input);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.v3r("Failed to parse type '" + 'float' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    var result = tmp$ret$4;
    var specialFp = this.s3m_1.k3m_1.i3o_1;
    if (specialFp || isFinite(result))
      return result;
    throwInvalidFloatingPointDecoded(this.u3m_1, result);
  }
  y1x() {
    var tmp0 = this.u3m_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.m3t();
      try {
        tmp$ret$1 = toDouble(input);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.v3r("Failed to parse type '" + 'double' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    var result = tmp$ret$1;
    var specialFp = this.s3m_1.k3m_1.i3o_1;
    if (specialFp || isFinite_0(result))
      return result;
    throwInvalidFloatingPointDecoded(this.u3m_1, result);
  }
  z1x() {
    var string = this.u3m_1.m3t();
    if (!(string.length === 1)) {
      this.u3m_1.v3r("Expected single char, but got '" + string + "'");
    }
    return charSequenceGet(string, 0);
  }
  a1y() {
    var tmp;
    if (this.y3m_1.a3o_1) {
      tmp = this.u3m_1.b3u();
    } else {
      tmp = this.u3m_1.l3t();
    }
    return tmp;
  }
  c1y(descriptor) {
    return get_isUnsignedNumber(descriptor) ? new JsonDecoderForUnsignedTypes(this.u3m_1, this.s3m_1) : super.c1y(descriptor);
  }
  b1y(enumDescriptor) {
    return getJsonNameIndexOrThrow(enumDescriptor, this.s3m_1, this.a1y(), ' at path ' + this.u3m_1.b3n_1.p3s());
  }
}
class JsonDecoderForUnsignedTypes extends AbstractDecoder {
  constructor(lexer, json) {
    super();
    this.k3u_1 = lexer;
    this.l3u_1 = json.u1y();
  }
  u1y() {
    return this.l3u_1;
  }
  w1y(descriptor) {
    var message = 'unsupported';
    throw IllegalStateException.t4(toString(message));
  }
  v1x() {
    var tmp0 = this.k3u_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.m3t();
      try {
        // Inline function 'kotlin.UInt.toInt' call
        var this_0 = toUInt(input);
        tmp$ret$2 = _UInt___get_data__impl__f0vqqw(this_0);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.v3r("Failed to parse type '" + 'UInt' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$2;
  }
  w1x() {
    var tmp0 = this.k3u_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.m3t();
      try {
        // Inline function 'kotlin.ULong.toLong' call
        var this_0 = toULong(input);
        tmp$ret$2 = _ULong___get_data__impl__fggpzb(this_0);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.v3r("Failed to parse type '" + 'ULong' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$2;
  }
  t1x() {
    var tmp0 = this.k3u_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.m3t();
      try {
        // Inline function 'kotlin.UByte.toByte' call
        var this_0 = toUByte(input);
        tmp$ret$2 = _UByte___get_data__impl__jof9qr(this_0);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.v3r("Failed to parse type '" + 'UByte' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$2;
  }
  u1x() {
    var tmp0 = this.k3u_1;
    var tmp$ret$2;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.parseString' call
      var input = tmp0.m3t();
      try {
        // Inline function 'kotlin.UShort.toShort' call
        var this_0 = toUShort(input);
        tmp$ret$2 = _UShort___get_data__impl__g0245(this_0);
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          tmp0.v3r("Failed to parse type '" + 'UShort' + "' for input '" + input + "'");
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$2;
  }
}
class StreamingJsonEncoder extends AbstractEncoder {
  static m3u(composer, json, mode, modeReuseCache) {
    var $this = this.y1y();
    $this.t3s_1 = composer;
    $this.u3s_1 = json;
    $this.v3s_1 = mode;
    $this.w3s_1 = modeReuseCache;
    $this.x3s_1 = $this.u3s_1.u1y();
    $this.y3s_1 = $this.u3s_1.k3m_1;
    $this.z3s_1 = false;
    $this.a3t_1 = null;
    $this.b3t_1 = null;
    var i = $this.v3s_1.o3_1;
    if (!($this.w3s_1 == null)) {
      if (!($this.w3s_1[i] === null) || !($this.w3s_1[i] === $this)) {
        $this.w3s_1[i] = $this;
      }
    }
    return $this;
  }
  p3o() {
    return this.u3s_1;
  }
  static c3t(output, json, mode, modeReuseCache) {
    return this.m3u(Composer_0(output, json), json, mode, modeReuseCache);
  }
  u1y() {
    return this.x3s_1;
  }
  d20(descriptor, index) {
    return this.y3s_1.y3n_1;
  }
  y1z(serializer, value) {
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically' call
      if (this.p3o().k3m_1.g3o_1) {
        serializer.x1t(this, value);
        break $l$block;
      }
      var isPolymorphicSerializer = serializer instanceof AbstractPolymorphicSerializer;
      var tmp;
      if (isPolymorphicSerializer) {
        tmp = !this.p3o().k3m_1.o3o_1.equals(ClassDiscriminatorMode_NONE_getInstance());
      } else {
        var tmp_0;
        switch (this.p3o().k3m_1.o3o_1.o3_1) {
          case 0:
          case 2:
            tmp_0 = false;
            break;
          case 1:
            // Inline function 'kotlin.let' call

            var it = serializer.w1t().j1w();
            tmp_0 = equals(it, CLASS_getInstance()) || equals(it, OBJECT_getInstance());
            break;
          default:
            noWhenBranchMatchedException();
            break;
        }
        tmp = tmp_0;
      }
      var needDiscriminator = tmp;
      var baseClassDiscriminator = needDiscriminator ? classDiscriminator(serializer.w1t(), this.p3o()) : null;
      var tmp_1;
      if (isPolymorphicSerializer) {
        var casted = serializer instanceof AbstractPolymorphicSerializer ? serializer : THROW_CCE();
        $l$block_0: {
          // Inline function 'kotlin.requireNotNull' call
          if (value == null) {
            var message = 'Value for serializer ' + toString(serializer.w1t()) + ' should always be non-null. Please report issue to the kotlinx.serialization tracker.';
            throw IllegalArgumentException.t(toString(message));
          } else {
            break $l$block_0;
          }
        }
        var actual = findPolymorphicSerializer_0(casted, this, value);
        if (!(baseClassDiscriminator == null)) {
          access$validateIfSealed$tPolymorphicKt(serializer, actual, baseClassDiscriminator);
          checkKind_0(actual.w1t().j1w());
        }
        tmp_1 = isInterface(actual, SerializationStrategy) ? actual : THROW_CCE();
      } else {
        tmp_1 = serializer;
      }
      var actualSerializer = tmp_1;
      if (!(baseClassDiscriminator == null)) {
        var serialName = actualSerializer.w1t().z1u();
        this.a3t_1 = baseClassDiscriminator;
        this.b3t_1 = serialName;
      }
      actualSerializer.x1t(this, value);
    }
  }
  f1y(descriptor) {
    var newMode = switchMode(this.u3s_1, descriptor);
    if (!(newMode.f3u_1 === _Char___init__impl__6a9atx(0))) {
      this.t3s_1.m3q(newMode.f3u_1);
      this.t3s_1.h3q();
    }
    var discriminator = this.a3t_1;
    if (!(discriminator == null)) {
      var tmp0_elvis_lhs = this.b3t_1;
      encodeTypeInfo(this, discriminator, tmp0_elvis_lhs == null ? descriptor.z1u() : tmp0_elvis_lhs);
      this.a3t_1 = null;
      this.b3t_1 = null;
    }
    if (this.v3s_1.equals(newMode)) {
      return this;
    }
    var tmp1_safe_receiver = this.w3s_1;
    var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver[newMode.o3_1];
    return tmp2_elvis_lhs == null ? StreamingJsonEncoder.m3u(this.t3s_1, this.u3s_1, newMode, this.w3s_1) : tmp2_elvis_lhs;
  }
  g1y(descriptor) {
    if (!(this.v3s_1.g3u_1 === _Char___init__impl__6a9atx(0))) {
      this.t3s_1.i3q();
      this.t3s_1.k3q();
      this.t3s_1.m3q(this.v3s_1.g3u_1);
    }
  }
  z1y(descriptor, index) {
    switch (this.v3s_1.o3_1) {
      case 1:
        if (!this.t3s_1.g3q_1) {
          this.t3s_1.m3q(_Char___init__impl__6a9atx(44));
        }

        this.t3s_1.j3q();
        break;
      case 2:
        if (!this.t3s_1.g3q_1) {
          var tmp = this;
          var tmp_0;
          if ((index % 2 | 0) === 0) {
            this.t3s_1.m3q(_Char___init__impl__6a9atx(44));
            this.t3s_1.j3q();
            tmp_0 = true;
          } else {
            this.t3s_1.m3q(_Char___init__impl__6a9atx(58));
            this.t3s_1.l3q();
            tmp_0 = false;
          }
          tmp.z3s_1 = tmp_0;
        } else {
          this.z3s_1 = true;
          this.t3s_1.j3q();
        }

        break;
      case 3:
        if (index === 0)
          this.z3s_1 = true;
        if (index === 1) {
          this.t3s_1.m3q(_Char___init__impl__6a9atx(44));
          this.t3s_1.l3q();
          this.z3s_1 = false;
        }

        break;
      default:
        if (!this.t3s_1.g3q_1) {
          this.t3s_1.m3q(_Char___init__impl__6a9atx(44));
        }

        this.t3s_1.j3q();
        this.k1z(getJsonElementName(descriptor, this.u3s_1, index));
        this.t3s_1.m3q(_Char___init__impl__6a9atx(58));
        this.t3s_1.l3q();
        break;
    }
    return true;
  }
  z1z(descriptor, index, serializer, value) {
    if (!(value == null) || this.y3s_1.d3o_1) {
      super.z1z(descriptor, index, serializer, value);
    }
  }
  m1z(descriptor) {
    var tmp;
    if (get_isUnsignedNumber(descriptor)) {
      // Inline function 'kotlinx.serialization.json.internal.StreamingJsonEncoder.composerAs' call
      var tmp_0;
      var tmp_1 = this.t3s_1;
      if (tmp_1 instanceof ComposerForUnsignedNumbers) {
        tmp_0 = this.t3s_1;
      } else {
        var tmp1 = this.t3s_1.f3q_1;
        var p1 = this.z3s_1;
        tmp_0 = new ComposerForUnsignedNumbers(tmp1, p1);
      }
      var tmp$ret$1 = tmp_0;
      tmp = StreamingJsonEncoder.m3u(tmp$ret$1, this.u3s_1, this.v3s_1, null);
    } else if (get_isUnquotedLiteral(descriptor)) {
      // Inline function 'kotlinx.serialization.json.internal.StreamingJsonEncoder.composerAs' call
      var tmp_2;
      var tmp_3 = this.t3s_1;
      if (tmp_3 instanceof ComposerForUnquotedLiterals) {
        tmp_2 = this.t3s_1;
      } else {
        var tmp4 = this.t3s_1.f3q_1;
        var p1_0 = this.z3s_1;
        tmp_2 = new ComposerForUnquotedLiterals(tmp4, p1_0);
      }
      var tmp$ret$3 = tmp_2;
      tmp = StreamingJsonEncoder.m3u(tmp$ret$3, this.u3s_1, this.v3s_1, null);
    } else if (!(this.a3t_1 == null)) {
      // Inline function 'kotlin.apply' call
      this.b3t_1 = descriptor.z1u();
      tmp = this;
    } else {
      tmp = super.m1z(descriptor);
    }
    return tmp;
  }
  b1z() {
    this.t3s_1.o3q('null');
  }
  c1z(value) {
    if (this.z3s_1) {
      this.k1z(value.toString());
    } else {
      this.t3s_1.x3q(value);
    }
  }
  d1z(value) {
    if (this.z3s_1) {
      this.k1z(value.toString());
    } else {
      this.t3s_1.s3q(value);
    }
  }
  e1z(value) {
    if (this.z3s_1) {
      this.k1z(value.toString());
    } else {
      this.t3s_1.u3q(value);
    }
  }
  f1z(value) {
    if (this.z3s_1) {
      this.k1z(value.toString());
    } else {
      this.t3s_1.v3q(value);
    }
  }
  g1z(value) {
    if (this.z3s_1) {
      this.k1z(value.toString());
    } else {
      this.t3s_1.w3q(value);
    }
  }
  h1z(value) {
    if (this.z3s_1) {
      this.k1z(value.toString());
    } else {
      this.t3s_1.q3q(value);
    }
    if (!this.y3s_1.i3o_1 && !isFinite(value)) {
      throw InvalidFloatingPointEncoded_0(value, toString(this.t3s_1.f3q_1));
    }
  }
  i1z(value) {
    if (this.z3s_1) {
      this.k1z(value.toString());
    } else {
      this.t3s_1.r3q(value);
    }
    if (!this.y3s_1.i3o_1 && !isFinite_0(value)) {
      throw InvalidFloatingPointEncoded_0(value, toString(this.t3s_1.f3q_1));
    }
  }
  j1z(value) {
    this.k1z(toString_1(value));
  }
  k1z(value) {
    return this.t3s_1.y3q(value);
  }
  l1z(enumDescriptor, index) {
    this.k1z(enumDescriptor.n1w(index));
  }
}
class AbstractJsonTreeDecoder extends NamedValueDecoder {
  constructor(json, value, polymorphicDiscriminator) {
    polymorphicDiscriminator = polymorphicDiscriminator === VOID ? null : polymorphicDiscriminator;
    super();
    this.p3u_1 = json;
    this.q3u_1 = value;
    this.r3u_1 = polymorphicDiscriminator;
    this.s3u_1 = this.p3o().k3m_1;
  }
  p3o() {
    return this.p3u_1;
  }
  n1() {
    return this.q3u_1;
  }
  u1y() {
    return this.p3o().u1y();
  }
  u3u() {
    var tmp0_safe_receiver = this.l2c();
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = this.v3u(tmp0_safe_receiver);
    }
    var tmp1_elvis_lhs = tmp;
    return tmp1_elvis_lhs == null ? this.n1() : tmp1_elvis_lhs;
  }
  t3u(currentTag) {
    return this.j2d() + ('.' + currentTag);
  }
  q3o() {
    return this.u3u();
  }
  e1y(deserializer) {
    var tmp$ret$0;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.decodeSerializableValuePolymorphic' call
      var tmp;
      if (!(deserializer instanceof AbstractPolymorphicSerializer)) {
        tmp = true;
      } else {
        tmp = this.p3o().k3m_1.g3o_1;
      }
      if (tmp) {
        tmp$ret$0 = deserializer.y1t(this);
        break $l$block;
      }
      var discriminator = classDiscriminator(deserializer.w1t(), this.p3o());
      var tmp0 = this.q3o();
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var serialName = deserializer.w1t().z1u();
      if (!(tmp0 instanceof JsonObject)) {
        var tmp_0 = getKClass(JsonObject).hf();
        var tmp_1 = getKClassFromExpression(tmp0).hf();
        var tmp$ret$1 = this.j2d();
        throw JsonDecodingException_0(-1, 'Expected ' + tmp_0 + ', but had ' + tmp_1 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$1, toString(tmp0));
      }
      var jsonTree = tmp0;
      var tmp0_safe_receiver = jsonTree.l2g(discriminator);
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_jsonPrimitive(tmp0_safe_receiver);
      var type = tmp1_safe_receiver == null ? null : get_contentOrNull(tmp1_safe_receiver);
      var tmp_2;
      try {
        tmp_2 = findPolymorphicSerializer(deserializer, this, type);
      } catch ($p) {
        var tmp_3;
        if ($p instanceof SerializationException) {
          var it = $p;
          throw JsonDecodingException_0(-1, ensureNotNull(it.message), jsonTree.toString());
        } else {
          throw $p;
        }
      }
      var tmp_4 = tmp_2;
      var actualSerializer = isInterface(tmp_4, DeserializationStrategy) ? tmp_4 : THROW_CCE();
      tmp$ret$0 = readPolymorphicJson(this.p3o(), discriminator, jsonTree, actualSerializer);
    }
    return tmp$ret$0;
  }
  m2c(parentName, childName) {
    return childName;
  }
  f1y(descriptor) {
    var currentObject = this.u3u();
    var tmp0_subject = descriptor.j1w();
    var tmp;
    var tmp_0;
    if (equals(tmp0_subject, LIST_getInstance())) {
      tmp_0 = true;
    } else {
      tmp_0 = tmp0_subject instanceof PolymorphicKind;
    }
    if (tmp_0) {
      var tmp_1 = this.p3o();
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var serialName = descriptor.z1u();
      if (!(currentObject instanceof JsonArray)) {
        var tmp_2 = getKClass(JsonArray).hf();
        var tmp_3 = getKClassFromExpression(currentObject).hf();
        var tmp$ret$0 = this.j2d();
        throw JsonDecodingException_0(-1, 'Expected ' + tmp_2 + ', but had ' + tmp_3 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$0, toString(currentObject));
      }
      tmp = new JsonTreeListDecoder(tmp_1, currentObject);
    } else {
      if (equals(tmp0_subject, MAP_getInstance())) {
        // Inline function 'kotlinx.serialization.json.internal.selectMapMode' call
        var this_0 = this.p3o();
        var keyDescriptor = carrierDescriptor(descriptor.q1w(0), this_0.u1y());
        var keyKind = keyDescriptor.j1w();
        var tmp_4;
        var tmp_5;
        if (keyKind instanceof PrimitiveKind) {
          tmp_5 = true;
        } else {
          tmp_5 = equals(keyKind, ENUM_getInstance());
        }
        if (tmp_5) {
          var tmp_6 = this.p3o();
          // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
          // Inline function 'kotlinx.serialization.json.internal.cast' call
          var serialName_0 = descriptor.z1u();
          if (!(currentObject instanceof JsonObject)) {
            var tmp_7 = getKClass(JsonObject).hf();
            var tmp_8 = getKClassFromExpression(currentObject).hf();
            var tmp$ret$3 = this.j2d();
            throw JsonDecodingException_0(-1, 'Expected ' + tmp_7 + ', but had ' + tmp_8 + ' as the serialized body of ' + serialName_0 + ' at element: ' + tmp$ret$3, toString(currentObject));
          }
          tmp_4 = new JsonTreeMapDecoder(tmp_6, currentObject);
        } else {
          if (this_0.k3m_1.b3o_1) {
            var tmp_9 = this.p3o();
            // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
            // Inline function 'kotlinx.serialization.json.internal.cast' call
            var serialName_1 = descriptor.z1u();
            if (!(currentObject instanceof JsonArray)) {
              var tmp_10 = getKClass(JsonArray).hf();
              var tmp_11 = getKClassFromExpression(currentObject).hf();
              var tmp$ret$7 = this.j2d();
              throw JsonDecodingException_0(-1, 'Expected ' + tmp_10 + ', but had ' + tmp_11 + ' as the serialized body of ' + serialName_1 + ' at element: ' + tmp$ret$7, toString(currentObject));
            }
            tmp_4 = new JsonTreeListDecoder(tmp_9, currentObject);
          } else {
            throw InvalidKeyKindException(keyDescriptor);
          }
        }
        tmp = tmp_4;
      } else {
        var tmp_12 = this.p3o();
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
        // Inline function 'kotlinx.serialization.json.internal.cast' call
        var serialName_2 = descriptor.z1u();
        if (!(currentObject instanceof JsonObject)) {
          var tmp_13 = getKClass(JsonObject).hf();
          var tmp_14 = getKClassFromExpression(currentObject).hf();
          var tmp$ret$12 = this.j2d();
          throw JsonDecodingException_0(-1, 'Expected ' + tmp_13 + ', but had ' + tmp_14 + ' as the serialized body of ' + serialName_2 + ' at element: ' + tmp$ret$12, toString(currentObject));
        }
        tmp = new JsonTreeDecoder(tmp_12, currentObject, this.r3u_1);
      }
    }
    return tmp;
  }
  g1y(descriptor) {
  }
  q1x() {
    var tmp = this.u3u();
    return !(tmp instanceof JsonNull);
  }
  w3u(tag, enumDescriptor) {
    var tmp = this.p3o();
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
    var tmp1 = this.v3u(tag);
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
    // Inline function 'kotlinx.serialization.json.internal.cast' call
    var serialName = enumDescriptor.z1u();
    if (!(tmp1 instanceof JsonPrimitive)) {
      var tmp_0 = getKClass(JsonPrimitive).hf();
      var tmp_1 = getKClassFromExpression(tmp1).hf();
      var tmp$ret$0 = this.t3u(tag);
      throw JsonDecodingException_0(-1, 'Expected ' + tmp_0 + ', but had ' + tmp_1 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$0, toString(tmp1));
    }
    return getJsonNameIndexOrThrow(enumDescriptor, tmp, tmp1.y3o());
  }
  v2d(tag, enumDescriptor) {
    return this.w3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), enumDescriptor);
  }
  x3u(tag) {
    return !(this.v3u(tag) === JsonNull_getInstance());
  }
  l2d(tag) {
    return this.x3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  y3u(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.v3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.t3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'boolean' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = get_booleanOrNull(literal);
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'boolean', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'boolean', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$4;
  }
  m2d(tag) {
    return this.y3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  z3u(tag) {
    var tmp$ret$5;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.v3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.t3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'byte' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var result = parseLongImpl(literal);
        var tmp_1;
        // Inline function 'kotlin.ranges.contains' call
        var this_0 = numberRangeToNumber(-128, 127);
        if (contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), result)) {
          tmp_1 = result.k4();
        } else {
          tmp_1 = null;
        }
        var tmp0_elvis_lhs = tmp_1;
        var tmp_2;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'byte', tag);
        } else {
          tmp_2 = tmp0_elvis_lhs;
        }
        tmp$ret$5 = tmp_2;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'byte', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$5;
  }
  n2d(tag) {
    return this.z3u((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  a3v(tag) {
    var tmp$ret$5;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.v3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.t3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'short' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var result = parseLongImpl(literal);
        var tmp_1;
        // Inline function 'kotlin.ranges.contains' call
        var this_0 = numberRangeToNumber(-32768, 32767);
        if (contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), result)) {
          tmp_1 = result.l4();
        } else {
          tmp_1 = null;
        }
        var tmp0_elvis_lhs = tmp_1;
        var tmp_2;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'short', tag);
        } else {
          tmp_2 = tmp0_elvis_lhs;
        }
        tmp$ret$5 = tmp_2;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'short', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$5;
  }
  o2d(tag) {
    return this.a3v((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  b3v(tag) {
    var tmp$ret$5;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.v3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.t3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'int' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var result = parseLongImpl(literal);
        var tmp_1;
        // Inline function 'kotlin.ranges.contains' call
        var this_0 = numberRangeToNumber(-2147483648, 2147483647);
        if (contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), result)) {
          tmp_1 = result.x1();
        } else {
          tmp_1 = null;
        }
        var tmp0_elvis_lhs = tmp_1;
        var tmp_2;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'int', tag);
        } else {
          tmp_2 = tmp0_elvis_lhs;
        }
        tmp$ret$5 = tmp_2;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'int', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$5;
  }
  p2d(tag) {
    return this.b3v((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  c3v(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.v3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.t3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'long' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = parseLongImpl(literal);
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'long', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'long', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$4;
  }
  q2d(tag) {
    return this.c3v((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  d3v(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.v3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.t3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'float' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = get_float(literal);
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'float', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'float', tag);
        } else {
          throw $p;
        }
      }
    }
    var result = tmp$ret$4;
    var specialFp = this.p3o().k3m_1.i3o_1;
    if (specialFp || isFinite(result))
      return result;
    throw InvalidFloatingPointDecoded(result, tag, toString(this.u3u()));
  }
  r2d(tag) {
    return this.d3v((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  e3v(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.v3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.t3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'double' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = get_double(literal);
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'double', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'double', tag);
        } else {
          throw $p;
        }
      }
    }
    var result = tmp$ret$4;
    var specialFp = this.p3o().k3m_1.i3o_1;
    if (specialFp || isFinite_0(result))
      return result;
    throw InvalidFloatingPointDecoded(result, tag, toString(this.u3u()));
  }
  s2d(tag) {
    return this.e3v((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  f3v(tag) {
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var value = this.v3u(tag);
      if (!(value instanceof JsonPrimitive)) {
        var tmp = getKClass(JsonPrimitive).hf();
        var tmp_0 = getKClassFromExpression(value).hf();
        var tmp$ret$0 = this.t3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'char' + ' at element: ' + tmp$ret$0, toString(value));
      }
      var literal = value;
      try {
        var tmp0_elvis_lhs = new Char(single(literal.y3o()));
        var tmp_1;
        if (tmp0_elvis_lhs == null) {
          unparsedPrimitive(this, literal, 'char', tag);
        } else {
          tmp_1 = tmp0_elvis_lhs;
        }
        tmp$ret$4 = tmp_1.j2_1;
        break $l$block;
      } catch ($p) {
        if ($p instanceof IllegalArgumentException) {
          var e = $p;
          unparsedPrimitive(this, literal, 'char', tag);
        } else {
          throw $p;
        }
      }
    }
    return tmp$ret$4;
  }
  t2d(tag) {
    return this.f3v((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  g3v(tag) {
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
    // Inline function 'kotlinx.serialization.json.internal.cast' call
    var value = this.v3u(tag);
    if (!(value instanceof JsonPrimitive)) {
      var tmp = getKClass(JsonPrimitive).hf();
      var tmp_0 = getKClassFromExpression(value).hf();
      var tmp$ret$0 = this.t3u(tag);
      throw JsonDecodingException_0(-1, 'Expected ' + tmp + ', but had ' + tmp_0 + ' as the serialized body of ' + 'string' + ' at element: ' + tmp$ret$0, toString(value));
    }
    var value_0 = value;
    if (!(value_0 instanceof JsonLiteral))
      throw JsonDecodingException_0(-1, "Expected string value for a non-null key '" + tag + "', got null literal instead at element: " + this.t3u(tag), toString(this.u3u()));
    if (!value_0.z3o_1 && !this.p3o().k3m_1.a3o_1) {
      throw JsonDecodingException_0(-1, "String literal for key '" + tag + "' should be quoted at element: " + this.t3u(tag) + ".\nUse 'isLenient = true' in 'Json {}' builder to accept non-compliant JSON.", toString(this.u3u()));
    }
    return value_0.b3p_1;
  }
  u2d(tag) {
    return this.g3v((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  h3v(tag, inlineDescriptor) {
    var tmp;
    if (get_isUnsignedNumber(inlineDescriptor)) {
      var tmp_0 = this.p3o();
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.getPrimitiveValue' call
      var tmp1 = this.v3u(tag);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var serialName = inlineDescriptor.z1u();
      if (!(tmp1 instanceof JsonPrimitive)) {
        var tmp_1 = getKClass(JsonPrimitive).hf();
        var tmp_2 = getKClassFromExpression(tmp1).hf();
        var tmp$ret$0 = this.t3u(tag);
        throw JsonDecodingException_0(-1, 'Expected ' + tmp_1 + ', but had ' + tmp_2 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$0, toString(tmp1));
      }
      var lexer = StringJsonLexer_0(tmp_0, tmp1.y3o());
      tmp = new JsonDecoderForUnsignedTypes(lexer, this.p3o());
    } else {
      tmp = super.w2d(tag, inlineDescriptor);
    }
    return tmp;
  }
  w2d(tag, inlineDescriptor) {
    return this.h3v((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), inlineDescriptor);
  }
  c1y(descriptor) {
    return !(this.l2c() == null) ? super.c1y(descriptor) : (new JsonPrimitiveDecoder(this.p3o(), this.n1(), this.r3u_1)).c1y(descriptor);
  }
}
class JsonTreeDecoder extends AbstractJsonTreeDecoder {
  constructor(json, value, polymorphicDiscriminator, polyDescriptor) {
    polymorphicDiscriminator = polymorphicDiscriminator === VOID ? null : polymorphicDiscriminator;
    polyDescriptor = polyDescriptor === VOID ? null : polyDescriptor;
    super(json, value, polymorphicDiscriminator);
    this.o3v_1 = value;
    this.p3v_1 = polyDescriptor;
    this.q3v_1 = 0;
    this.r3v_1 = false;
  }
  n1() {
    return this.o3v_1;
  }
  w1y(descriptor) {
    $l$loop: while (this.q3v_1 < descriptor.l1w()) {
      var _unary__edvuaz = this.q3v_1;
      this.q3v_1 = _unary__edvuaz + 1 | 0;
      var name = this.h2c(descriptor, _unary__edvuaz);
      var index = this.q3v_1 - 1 | 0;
      this.r3v_1 = false;
      var tmp;
      // Inline function 'kotlin.collections.contains' call
      // Inline function 'kotlin.collections.containsKey' call
      var this_0 = this.n1();
      if ((isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).f3(name)) {
        tmp = true;
      } else {
        tmp = setForceNull(this, descriptor, index);
      }
      if (tmp) {
        if (!this.s3u_1.f3o_1)
          return index;
        var tmp2 = this.p3o();
        var tmp$ret$3;
        $l$block_2: {
          // Inline function 'kotlinx.serialization.json.internal.tryCoerceValue' call
          var isOptional = descriptor.r1w(index);
          var elementDescriptor = descriptor.q1w(index);
          var tmp_0;
          if (isOptional && !elementDescriptor.f1w()) {
            var tmp_1 = this.s3v(name);
            tmp_0 = tmp_1 instanceof JsonNull;
          } else {
            tmp_0 = false;
          }
          if (tmp_0) {
            tmp$ret$3 = true;
            break $l$block_2;
          }
          if (equals(elementDescriptor.j1w(), ENUM_getInstance())) {
            var tmp_2;
            if (elementDescriptor.f1w()) {
              var tmp_3 = this.s3v(name);
              tmp_2 = tmp_3 instanceof JsonNull;
            } else {
              tmp_2 = false;
            }
            if (tmp_2) {
              tmp$ret$3 = false;
              break $l$block_2;
            }
            var tmp_4 = this.s3v(name);
            var tmp0_safe_receiver = tmp_4 instanceof JsonPrimitive ? tmp_4 : null;
            var tmp0_elvis_lhs = tmp0_safe_receiver == null ? null : get_contentOrNull(tmp0_safe_receiver);
            var tmp_5;
            if (tmp0_elvis_lhs == null) {
              tmp$ret$3 = false;
              break $l$block_2;
            } else {
              tmp_5 = tmp0_elvis_lhs;
            }
            var enumValue = tmp_5;
            var enumIndex = getJsonNameIndex(elementDescriptor, tmp2, enumValue);
            var coerceToNull = !tmp2.k3m_1.d3o_1 && elementDescriptor.f1w();
            if (enumIndex === -3 && (isOptional || coerceToNull)) {
              if (setForceNull(this, descriptor, index))
                return index;
              tmp$ret$3 = true;
              break $l$block_2;
            }
          }
          tmp$ret$3 = false;
        }
        if (tmp$ret$3)
          continue $l$loop;
        return index;
      }
    }
    return -1;
  }
  q1x() {
    return !this.r3v_1 && super.q1x();
  }
  i2c(descriptor, index) {
    var strategy = namingStrategy(descriptor, this.p3o());
    var baseName = descriptor.n1w(index);
    if (strategy == null) {
      if (!this.s3u_1.j3o_1)
        return baseName;
      if (this.n1().i3().v2(baseName))
        return baseName;
    }
    var deserializationNamesMap_0 = deserializationNamesMap(this.p3o(), descriptor);
    // Inline function 'kotlin.collections.find' call
    var tmp0 = this.n1().i3();
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (deserializationNamesMap_0.h3(element) === index) {
          tmp$ret$1 = element;
          break $l$block;
        }
      }
      tmp$ret$1 = null;
    }
    var tmp0_safe_receiver = tmp$ret$1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return tmp0_safe_receiver;
    }
    var fallbackName = strategy == null ? null : strategy.g3s(descriptor, index, baseName);
    return fallbackName == null ? baseName : fallbackName;
  }
  v3u(tag) {
    return getValue(this.n1(), tag);
  }
  s3v(tag) {
    return this.n1().l2g(tag);
  }
  f1y(descriptor) {
    if (descriptor === this.p3v_1) {
      var tmp = this.p3o();
      var tmp1 = this.u3u();
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonTreeDecoder.cast' call
      // Inline function 'kotlinx.serialization.json.internal.cast' call
      var serialName = this.p3v_1.z1u();
      if (!(tmp1 instanceof JsonObject)) {
        var tmp_0 = getKClass(JsonObject).hf();
        var tmp_1 = getKClassFromExpression(tmp1).hf();
        var tmp$ret$0 = this.j2d();
        throw JsonDecodingException_0(-1, 'Expected ' + tmp_0 + ', but had ' + tmp_1 + ' as the serialized body of ' + serialName + ' at element: ' + tmp$ret$0, toString(tmp1));
      }
      return new JsonTreeDecoder(tmp, tmp1, this.r3u_1, this.p3v_1);
    }
    return super.f1y(descriptor);
  }
  g1y(descriptor) {
    var tmp;
    if (ignoreUnknownKeys(descriptor, this.p3o())) {
      tmp = true;
    } else {
      var tmp_0 = descriptor.j1w();
      tmp = tmp_0 instanceof PolymorphicKind;
    }
    if (tmp)
      return Unit_instance;
    var strategy = namingStrategy(descriptor, this.p3o());
    var tmp_1;
    if (strategy == null && !this.s3u_1.j3o_1) {
      tmp_1 = jsonCachedSerialNames(descriptor);
    } else if (!(strategy == null)) {
      tmp_1 = deserializationNamesMap(this.p3o(), descriptor).i3();
    } else {
      var tmp_2 = jsonCachedSerialNames(descriptor);
      var tmp0_safe_receiver = get_schemaCache(this.p3o()).s3t(descriptor, get_JsonDeserializationNamesKey());
      // Inline function 'kotlin.collections.orEmpty' call
      var tmp0_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.i3();
      var tmp$ret$0 = tmp0_elvis_lhs == null ? emptySet() : tmp0_elvis_lhs;
      tmp_1 = plus_0(tmp_2, tmp$ret$0);
    }
    var names = tmp_1;
    var _iterator__ex2g4s = this.n1().i3().y();
    while (_iterator__ex2g4s.z()) {
      var key = _iterator__ex2g4s.a1();
      if (!names.v2(key) && !(key === this.r3u_1)) {
        throw JsonDecodingException_1(-1, "Encountered an unknown key '" + key + "' at element: " + this.j2d() + '\n' + "Use 'ignoreUnknownKeys = true' in 'Json {}' builder or '@JsonIgnoreUnknownKeys' annotation to ignore unknown keys.\n" + ('JSON input: ' + toString(minify(this.n1().toString()))));
      }
    }
  }
}
class JsonTreeListDecoder extends AbstractJsonTreeDecoder {
  constructor(json, value) {
    super(json, value);
    this.z3v_1 = value;
    this.a3w_1 = this.z3v_1.b1();
    this.b3w_1 = -1;
  }
  n1() {
    return this.z3v_1;
  }
  i2c(descriptor, index) {
    return index.toString();
  }
  v3u(tag) {
    return this.z3v_1.f1(toInt(tag));
  }
  w1y(descriptor) {
    while (this.b3w_1 < (this.a3w_1 - 1 | 0)) {
      this.b3w_1 = this.b3w_1 + 1 | 0;
      return this.b3w_1;
    }
    return -1;
  }
}
class JsonPrimitiveDecoder extends AbstractJsonTreeDecoder {
  constructor(json, value, polymorphicDiscriminator) {
    polymorphicDiscriminator = polymorphicDiscriminator === VOID ? null : polymorphicDiscriminator;
    super(json, value, polymorphicDiscriminator);
    this.i3w_1 = value;
    this.d2d('primitive');
  }
  n1() {
    return this.i3w_1;
  }
  w1y(descriptor) {
    return 0;
  }
  v3u(tag) {
    // Inline function 'kotlin.require' call
    if (!(tag === 'primitive')) {
      var message = "This input can only handle primitives with 'primitive' tag";
      throw IllegalArgumentException.t(toString(message));
    }
    return this.i3w_1;
  }
}
class JsonTreeMapDecoder extends JsonTreeDecoder {
  constructor(json, value) {
    super(json, value);
    this.t3w_1 = value;
    this.u3w_1 = toList(this.t3w_1.i3());
    this.v3w_1 = imul(this.u3w_1.b1(), 2);
    this.w3w_1 = -1;
  }
  n1() {
    return this.t3w_1;
  }
  i2c(descriptor, index) {
    var i = index / 2 | 0;
    return this.u3w_1.f1(i);
  }
  w1y(descriptor) {
    while (this.w3w_1 < (this.v3w_1 - 1 | 0)) {
      this.w3w_1 = this.w3w_1 + 1 | 0;
      return this.w3w_1;
    }
    return -1;
  }
  v3u(tag) {
    return (this.w3w_1 % 2 | 0) === 0 ? JsonPrimitive_1(tag) : getValue(this.t3w_1, tag);
  }
  g1y(descriptor) {
  }
}
class AbstractJsonTreeEncoder extends NamedValueEncoder {
  constructor(json, nodeConsumer) {
    super();
    this.y3w_1 = json;
    this.z3w_1 = nodeConsumer;
    this.a3x_1 = this.y3w_1.k3m_1;
    this.b3x_1 = null;
    this.c3x_1 = null;
  }
  p3o() {
    return this.y3w_1;
  }
  u1y() {
    return this.y3w_1.u1y();
  }
  i2c(descriptor, index) {
    return getJsonElementName(descriptor, this.y3w_1, index);
  }
  d20(descriptor, index) {
    return this.a3x_1.y3n_1;
  }
  m2c(parentName, childName) {
    return childName;
  }
  b20() {
  }
  b1z() {
    var tmp0_elvis_lhs = this.l2c();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return this.z3w_1(JsonNull_getInstance());
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var tag = tmp;
    this.m3x(tag);
  }
  m3x(tag) {
    return this.k3x(tag, JsonNull_getInstance());
  }
  p2c(tag) {
    return this.m3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE());
  }
  n3x(tag, value) {
    return this.k3x(tag, JsonPrimitive_0(value));
  }
  q2c(tag, value) {
    return this.n3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  o3x(tag, value) {
    return this.k3x(tag, JsonPrimitive_0(value));
  }
  r2c(tag, value) {
    return this.o3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  p3x(tag, value) {
    return this.k3x(tag, JsonPrimitive_0(value));
  }
  s2c(tag, value) {
    return this.p3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  q3x(tag, value) {
    return this.k3x(tag, JsonPrimitive_0(value));
  }
  t2c(tag, value) {
    return this.q3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  r3x(tag, value) {
    this.k3x(tag, JsonPrimitive_0(value));
    if (!this.a3x_1.i3o_1 && !isFinite(value)) {
      throw InvalidFloatingPointEncoded(value, tag, toString(this.l3x()));
    }
  }
  u2c(tag, value) {
    return this.r3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  y1z(serializer, value) {
    if (!(this.l2c() == null) || !get_requiresTopLevelTag(carrierDescriptor(serializer.w1t(), this.u1y()))) {
      $l$block: {
        // Inline function 'kotlinx.serialization.json.internal.encodePolymorphically' call
        if (this.p3o().k3m_1.g3o_1) {
          serializer.x1t(this, value);
          break $l$block;
        }
        var isPolymorphicSerializer = serializer instanceof AbstractPolymorphicSerializer;
        var tmp;
        if (isPolymorphicSerializer) {
          tmp = !this.p3o().k3m_1.o3o_1.equals(ClassDiscriminatorMode_NONE_getInstance());
        } else {
          var tmp_0;
          switch (this.p3o().k3m_1.o3o_1.o3_1) {
            case 0:
            case 2:
              tmp_0 = false;
              break;
            case 1:
              // Inline function 'kotlin.let' call

              var it = serializer.w1t().j1w();
              tmp_0 = equals(it, CLASS_getInstance()) || equals(it, OBJECT_getInstance());
              break;
            default:
              noWhenBranchMatchedException();
              break;
          }
          tmp = tmp_0;
        }
        var needDiscriminator = tmp;
        var baseClassDiscriminator = needDiscriminator ? classDiscriminator(serializer.w1t(), this.p3o()) : null;
        var tmp_1;
        if (isPolymorphicSerializer) {
          var casted = serializer instanceof AbstractPolymorphicSerializer ? serializer : THROW_CCE();
          $l$block_0: {
            // Inline function 'kotlin.requireNotNull' call
            if (value == null) {
              var message = 'Value for serializer ' + toString(serializer.w1t()) + ' should always be non-null. Please report issue to the kotlinx.serialization tracker.';
              throw IllegalArgumentException.t(toString(message));
            } else {
              break $l$block_0;
            }
          }
          var actual = findPolymorphicSerializer_0(casted, this, value);
          if (!(baseClassDiscriminator == null)) {
            access$validateIfSealed$tPolymorphicKt(serializer, actual, baseClassDiscriminator);
            checkKind_0(actual.w1t().j1w());
          }
          tmp_1 = isInterface(actual, SerializationStrategy) ? actual : THROW_CCE();
        } else {
          tmp_1 = serializer;
        }
        var actualSerializer = tmp_1;
        if (!(baseClassDiscriminator == null)) {
          var serialName = actualSerializer.w1t().z1u();
          this.b3x_1 = baseClassDiscriminator;
          this.c3x_1 = serialName;
        }
        actualSerializer.x1t(this, value);
      }
    } else {
      // Inline function 'kotlin.apply' call
      (new JsonPrimitiveEncoder(this.y3w_1, this.z3w_1)).y1z(serializer, value);
    }
  }
  s3x(tag, value) {
    this.k3x(tag, JsonPrimitive_0(value));
    if (!this.a3x_1.i3o_1 && !isFinite_0(value)) {
      throw InvalidFloatingPointEncoded(value, tag, toString(this.l3x()));
    }
  }
  v2c(tag, value) {
    return this.s3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  t3x(tag, value) {
    return this.k3x(tag, JsonPrimitive_2(value));
  }
  w2c(tag, value) {
    return this.t3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  u3x(tag, value) {
    return this.k3x(tag, JsonPrimitive_1(toString_1(value)));
  }
  x2c(tag, value) {
    return this.u3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  v3x(tag, value) {
    return this.k3x(tag, JsonPrimitive_1(value));
  }
  y2c(tag, value) {
    return this.v3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  w3x(tag, enumDescriptor, ordinal) {
    return this.k3x(tag, JsonPrimitive_1(enumDescriptor.n1w(ordinal)));
  }
  z2c(tag, enumDescriptor, ordinal) {
    return this.w3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), enumDescriptor, ordinal);
  }
  x3x(tag, value) {
    this.k3x(tag, JsonPrimitive_1(toString(value)));
  }
  n2c(tag, value) {
    return this.x3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), value);
  }
  y3x(tag, inlineDescriptor) {
    return get_isUnsignedNumber(inlineDescriptor) ? inlineUnsignedNumberEncoder(this, tag) : get_isUnquotedLiteral(inlineDescriptor) ? inlineUnquotedLiteralEncoder(this, tag, inlineDescriptor) : super.a2d(tag, inlineDescriptor);
  }
  a2d(tag, inlineDescriptor) {
    return this.y3x((!(tag == null) ? typeof tag === 'string' : false) ? tag : THROW_CCE(), inlineDescriptor);
  }
  m1z(descriptor) {
    var tmp;
    if (!(this.l2c() == null)) {
      if (!(this.b3x_1 == null))
        this.c3x_1 = descriptor.z1u();
      tmp = super.m1z(descriptor);
    } else {
      tmp = (new JsonPrimitiveEncoder(this.y3w_1, this.z3w_1)).m1z(descriptor);
    }
    return tmp;
  }
  f1y(descriptor) {
    var tmp;
    if (this.l2c() == null) {
      tmp = this.z3w_1;
    } else {
      tmp = AbstractJsonTreeEncoder$beginStructure$lambda(this);
    }
    var consumer = tmp;
    var tmp0_subject = descriptor.j1w();
    var tmp_0;
    var tmp_1;
    if (equals(tmp0_subject, LIST_getInstance())) {
      tmp_1 = true;
    } else {
      tmp_1 = tmp0_subject instanceof PolymorphicKind;
    }
    if (tmp_1) {
      tmp_0 = new JsonTreeListEncoder(this.y3w_1, consumer);
    } else {
      if (equals(tmp0_subject, MAP_getInstance())) {
        // Inline function 'kotlinx.serialization.json.internal.selectMapMode' call
        var this_0 = this.y3w_1;
        var keyDescriptor = carrierDescriptor(descriptor.q1w(0), this_0.u1y());
        var keyKind = keyDescriptor.j1w();
        var tmp_2;
        var tmp_3;
        if (keyKind instanceof PrimitiveKind) {
          tmp_3 = true;
        } else {
          tmp_3 = equals(keyKind, ENUM_getInstance());
        }
        if (tmp_3) {
          tmp_2 = new JsonTreeMapEncoder(this.y3w_1, consumer);
        } else {
          if (this_0.k3m_1.b3o_1) {
            tmp_2 = new JsonTreeListEncoder(this.y3w_1, consumer);
          } else {
            throw InvalidKeyKindException(keyDescriptor);
          }
        }
        tmp_0 = tmp_2;
      } else {
        tmp_0 = new JsonTreeEncoder(this.y3w_1, consumer);
      }
    }
    var encoder = tmp_0;
    var discriminator = this.b3x_1;
    if (!(discriminator == null)) {
      if (encoder instanceof JsonTreeMapEncoder) {
        encoder.k3x('key', JsonPrimitive_1(discriminator));
        var tmp1_elvis_lhs = this.c3x_1;
        encoder.k3x('value', JsonPrimitive_1(tmp1_elvis_lhs == null ? descriptor.z1u() : tmp1_elvis_lhs));
      } else {
        var tmp2_elvis_lhs = this.c3x_1;
        encoder.k3x(discriminator, JsonPrimitive_1(tmp2_elvis_lhs == null ? descriptor.z1u() : tmp2_elvis_lhs));
      }
      this.b3x_1 = null;
      this.c3x_1 = null;
    }
    return encoder;
  }
  b2d(descriptor) {
    this.z3w_1(this.l3x());
  }
}
class JsonTreeEncoder extends AbstractJsonTreeEncoder {
  constructor(json, nodeConsumer) {
    super(json, nodeConsumer);
    var tmp = this;
    // Inline function 'kotlin.collections.linkedMapOf' call
    tmp.j3x_1 = LinkedHashMap.hc();
  }
  k3x(key, element) {
    // Inline function 'kotlin.collections.set' call
    this.j3x_1.k3(key, element);
  }
  z1z(descriptor, index, serializer, value) {
    if (!(value == null) || this.a3x_1.d3o_1) {
      super.z1z(descriptor, index, serializer, value);
    }
  }
  l3x() {
    return new JsonObject(this.j3x_1);
  }
}
class AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1 extends AbstractEncoder {
  static c3y(this$0, $tag, $box) {
    if ($box === VOID)
      $box = {};
    $box.a3y_1 = this$0;
    $box.b3y_1 = $tag;
    var $this = this.y1y($box);
    $this.z3x_1 = this$0.y3w_1.u1y();
    return $this;
  }
  u1y() {
    return this.z3x_1;
  }
  h3y(s) {
    return this.a3y_1.k3x(this.b3y_1, new JsonLiteral(s, false));
  }
  f1z(value) {
    // Inline function 'kotlin.toUInt' call
    var tmp$ret$0 = _UInt___init__impl__l7qpdl(value);
    return this.h3y(UInt__toString_impl_dbgl21(tmp$ret$0));
  }
  g1z(value) {
    // Inline function 'kotlin.toULong' call
    var tmp$ret$0 = _ULong___init__impl__c78o9k(value);
    return this.h3y(ULong__toString_impl_f9au7k(tmp$ret$0));
  }
  d1z(value) {
    // Inline function 'kotlin.toUByte' call
    var tmp$ret$0 = _UByte___init__impl__g9hnc4(value);
    return this.h3y(UByte__toString_impl_v72jg(tmp$ret$0));
  }
  e1z(value) {
    // Inline function 'kotlin.toUShort' call
    var tmp$ret$0 = _UShort___init__impl__jigrne(value);
    return this.h3y(UShort__toString_impl_edaoee(tmp$ret$0));
  }
}
class AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1 extends AbstractEncoder {
  static g3y(this$0, $tag, $inlineDescriptor, $box) {
    if ($box === VOID)
      $box = {};
    $box.d3y_1 = this$0;
    $box.e3y_1 = $tag;
    $box.f3y_1 = $inlineDescriptor;
    return this.y1y($box);
  }
  u1y() {
    return this.d3y_1.y3w_1.u1y();
  }
  k1z(value) {
    return this.d3y_1.k3x(this.e3y_1, new JsonLiteral(value, false, this.f3y_1));
  }
}
class JsonPrimitiveEncoder extends AbstractJsonTreeEncoder {
  constructor(json, nodeConsumer) {
    super(json, nodeConsumer);
    this.x3y_1 = null;
    this.d2d('primitive');
  }
  k3x(key, element) {
    // Inline function 'kotlin.require' call
    if (!(key === 'primitive')) {
      var message = "This output can only consume primitives with 'primitive' tag";
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.x3y_1 == null)) {
      var message_0 = 'Primitive element was already recorded. Does call to .encodeXxx happen more than once?';
      throw IllegalArgumentException.t(toString(message_0));
    }
    this.x3y_1 = element;
    this.z3w_1(element);
  }
  l3x() {
    var tmp0 = this.x3y_1;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.requireNotNull' call
      if (tmp0 == null) {
        var message = 'Primitive element has not been recorded. Is call to .encodeXxx is missing in serializer?';
        throw IllegalArgumentException.t(toString(message));
      } else {
        tmp$ret$1 = tmp0;
        break $l$block;
      }
    }
    return tmp$ret$1;
  }
}
class JsonTreeListEncoder extends AbstractJsonTreeEncoder {
  constructor(json, nodeConsumer) {
    super(json, nodeConsumer);
    var tmp = this;
    // Inline function 'kotlin.collections.arrayListOf' call
    tmp.e3z_1 = ArrayList.k();
  }
  i2c(descriptor, index) {
    return index.toString();
  }
  k3x(key, element) {
    var idx = toInt(key);
    this.e3z_1.d3(idx, element);
  }
  l3x() {
    return new JsonArray(this.e3z_1);
  }
}
class JsonTreeMapEncoder extends JsonTreeEncoder {
  constructor(json, nodeConsumer) {
    super(json, nodeConsumer);
    this.q3y_1 = true;
  }
  k3x(key, element) {
    if (this.q3y_1) {
      var tmp = this;
      var tmp_0;
      if (element instanceof JsonPrimitive) {
        tmp_0 = element.y3o();
      } else {
        if (element instanceof JsonObject) {
          throw InvalidKeyKindException(JsonObjectSerializer_getInstance().k3p_1);
        } else {
          if (element instanceof JsonArray) {
            throw InvalidKeyKindException(JsonArraySerializer_getInstance().l3p_1);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
      tmp.p3y_1 = tmp_0;
      this.q3y_1 = false;
    } else {
      var tmp0 = this.j3x_1;
      // Inline function 'kotlin.collections.set' call
      var key_0 = _get_tag__e6h4qf(this);
      tmp0.k3(key_0, element);
      this.q3y_1 = true;
    }
  }
  l3x() {
    return new JsonObject(this.j3x_1);
  }
}
class WriteMode extends Enum {
  constructor(name, ordinal, begin, end) {
    super(name, ordinal);
    this.f3u_1 = begin;
    this.g3u_1 = end;
  }
}
class AbstractJsonLexer {
  constructor() {
    this.a3n_1 = 0;
    this.b3n_1 = new JsonPath();
    this.c3n_1 = null;
    this.d3n_1 = StringBuilder.v();
  }
  i3z() {
  }
  v3t() {
    var current = this.j3z();
    var source = this.g3z();
    if (current >= charSequenceLength(source) || current === -1)
      return false;
    if (charSequenceGet(source, current) === _Char___init__impl__6a9atx(44)) {
      this.a3n_1 = this.a3n_1 + 1 | 0;
      return true;
    }
    return false;
  }
  k3z(c) {
    return c === _Char___init__impl__6a9atx(125) || c === _Char___init__impl__6a9atx(93) || (c === _Char___init__impl__6a9atx(58) || c === _Char___init__impl__6a9atx(44)) ? false : true;
  }
  e3n() {
    var nextToken = this.o3t();
    if (!(nextToken === 10)) {
      this.v3r('Expected EOF after parsing, but had ' + toString_1(charSequenceGet(this.g3z(), this.a3n_1 - 1 | 0)) + ' instead');
    }
  }
  j3t(expected) {
    var token = this.o3t();
    if (!(token === expected)) {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.fail' call
      var expected_0 = tokenDescription(expected);
      var position = true ? this.a3n_1 - 1 | 0 : this.a3n_1;
      var s = this.a3n_1 === charSequenceLength(this.g3z()) || position < 0 ? 'EOF' : toString_1(charSequenceGet(this.g3z(), position));
      var tmp$ret$0 = 'Expected ' + expected_0 + ", but had '" + s + "' instead";
      this.v3r(tmp$ret$0, position);
    }
    return token;
  }
  l3z(expected) {
    if (this.a3n_1 > 0 && expected === _Char___init__impl__6a9atx(34)) {
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.withPositionRollback' call
        var snapshot = this.a3n_1;
        try {
          this.a3n_1 = this.a3n_1 - 1 | 0;
          tmp$ret$1 = this.m3t();
          break $l$block;
        }finally {
          this.a3n_1 = snapshot;
        }
      }
      var inputLiteral = tmp$ret$1;
      if (inputLiteral === 'null') {
        this.u3r("Expected string literal but 'null' literal was found", this.a3n_1 - 1 | 0, "Use 'coerceInputValues = true' in 'Json {}' builder to coerce nulls if property has a default value.");
      }
    }
    // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.fail' call
    var expectedToken = charToTokenClass(expected);
    var expected_0 = tokenDescription(expectedToken);
    var position = true ? this.a3n_1 - 1 | 0 : this.a3n_1;
    var s = this.a3n_1 === charSequenceLength(this.g3z()) || position < 0 ? 'EOF' : toString_1(charSequenceGet(this.g3z(), position));
    var tmp$ret$2 = 'Expected ' + expected_0 + ", but had '" + s + "' instead";
    this.v3r(tmp$ret$2, position);
  }
  i3t() {
    var source = this.g3z();
    var cpos = this.a3n_1;
    $l$loop_0: while (true) {
      cpos = this.h3z(cpos);
      if (cpos === -1)
        break $l$loop_0;
      var ch = charSequenceGet(source, cpos);
      if (ch === _Char___init__impl__6a9atx(32) || ch === _Char___init__impl__6a9atx(10) || ch === _Char___init__impl__6a9atx(13) || ch === _Char___init__impl__6a9atx(9)) {
        cpos = cpos + 1 | 0;
        continue $l$loop_0;
      }
      this.a3n_1 = cpos;
      return charToTokenClass(ch);
    }
    this.a3n_1 = cpos;
    return 10;
  }
  w3t(doConsume) {
    var current = this.j3z();
    current = this.h3z(current);
    var len = charSequenceLength(this.g3z()) - current | 0;
    if (len < 4 || current === -1)
      return false;
    var inductionVariable = 0;
    if (inductionVariable <= 3)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (!(charSequenceGet('null', i) === charSequenceGet(this.g3z(), current + i | 0)))
          return false;
      }
       while (inductionVariable <= 3);
    if (len > 4 && charToTokenClass(charSequenceGet(this.g3z(), current + 4 | 0)) === 0)
      return false;
    if (doConsume) {
      this.a3n_1 = current + 4 | 0;
    }
    return true;
  }
  h3u(doConsume, $super) {
    doConsume = doConsume === VOID ? true : doConsume;
    return $super === VOID ? this.w3t(doConsume) : $super.w3t.call(this, doConsume);
  }
  x3t(isLenient) {
    var token = this.i3t();
    var tmp;
    if (isLenient) {
      if (!(token === 1) && !(token === 0))
        return null;
      tmp = this.m3t();
    } else {
      if (!(token === 1))
        return null;
      tmp = this.l3t();
    }
    var string = tmp;
    this.c3n_1 = string;
    return string;
  }
  m3z() {
    this.c3n_1 = null;
  }
  j1l(startPos, endPos) {
    // Inline function 'kotlin.text.substring' call
    var this_0 = this.g3z();
    return toString(charSequenceSubSequence(this_0, startPos, endPos));
  }
  l3t() {
    if (!(this.c3n_1 == null)) {
      return takePeeked(this);
    }
    return this.a3u();
  }
  consumeString2(source, startPosition, current) {
    var currentPosition = current;
    var lastPosition = startPosition;
    var char = charSequenceGet(source, currentPosition);
    var usedAppend = false;
    while (!(char === _Char___init__impl__6a9atx(34))) {
      if (char === _Char___init__impl__6a9atx(92)) {
        usedAppend = true;
        currentPosition = this.h3z(appendEscape(this, lastPosition, currentPosition));
        if (currentPosition === -1) {
          this.v3r('Unexpected EOF', currentPosition);
        }
        lastPosition = currentPosition;
      } else {
        currentPosition = currentPosition + 1 | 0;
        if (currentPosition >= charSequenceLength(source)) {
          usedAppend = true;
          this.f3z(lastPosition, currentPosition);
          currentPosition = this.h3z(currentPosition);
          if (currentPosition === -1) {
            this.v3r('Unexpected EOF', currentPosition);
          }
          lastPosition = currentPosition;
        }
      }
      char = charSequenceGet(source, currentPosition);
    }
    var tmp;
    if (!usedAppend) {
      tmp = this.j1l(lastPosition, currentPosition);
    } else {
      tmp = decodedString(this, lastPosition, currentPosition);
    }
    var string = tmp;
    this.a3n_1 = currentPosition + 1 | 0;
    return string;
  }
  b3u() {
    var result = this.m3t();
    if (result === 'null' && wasUnquotedString(this)) {
      this.v3r("Unexpected 'null' value instead of string literal");
    }
    return result;
  }
  m3t() {
    if (!(this.c3n_1 == null)) {
      return takePeeked(this);
    }
    var current = this.j3z();
    if (current >= charSequenceLength(this.g3z()) || current === -1) {
      this.v3r('EOF', current);
    }
    var token = charToTokenClass(charSequenceGet(this.g3z(), current));
    if (token === 1) {
      return this.l3t();
    }
    if (!(token === 0)) {
      this.v3r('Expected beginning of the string, but got ' + toString_1(charSequenceGet(this.g3z(), current)));
    }
    var usedAppend = false;
    while (charToTokenClass(charSequenceGet(this.g3z(), current)) === 0) {
      current = current + 1 | 0;
      if (current >= charSequenceLength(this.g3z())) {
        usedAppend = true;
        this.f3z(this.a3n_1, current);
        var eof = this.h3z(current);
        if (eof === -1) {
          this.a3n_1 = current;
          return decodedString(this, 0, 0);
        } else {
          current = eof;
        }
      }
    }
    var tmp;
    if (!usedAppend) {
      tmp = this.j1l(this.a3n_1, current);
    } else {
      tmp = decodedString(this, this.a3n_1, current);
    }
    var result = tmp;
    this.a3n_1 = current;
    return result;
  }
  f3z(fromIndex, toIndex) {
    this.d3n_1.ch(this.g3z(), fromIndex, toIndex);
  }
  z3t(allowLenientStrings) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var tokenStack = ArrayList.k();
    var lastToken = this.i3t();
    if (!(lastToken === 8) && !(lastToken === 6)) {
      this.m3t();
      return Unit_instance;
    }
    $l$loop: while (true) {
      lastToken = this.i3t();
      if (lastToken === 1) {
        if (allowLenientStrings)
          this.m3t();
        else
          this.a3u();
        continue $l$loop;
      }
      var tmp0_subject = lastToken;
      if (tmp0_subject === 8 || tmp0_subject === 6) {
        tokenStack.l(lastToken);
      } else if (tmp0_subject === 9) {
        if (!(last(tokenStack) === 8))
          throw JsonDecodingException_0(this.a3n_1, 'found ] instead of } at path: ' + this.b3n_1.toString(), this.g3z());
        removeLast(tokenStack);
      } else if (tmp0_subject === 7) {
        if (!(last(tokenStack) === 6))
          throw JsonDecodingException_0(this.a3n_1, 'found } instead of ] at path: ' + this.b3n_1.toString(), this.g3z());
        removeLast(tokenStack);
      } else if (tmp0_subject === 10) {
        this.v3r('Unexpected end of input due to malformed JSON during ignoring unknown keys');
      }
      this.o3t();
      if (tokenStack.b1() === 0)
        return Unit_instance;
    }
  }
  toString() {
    return "JsonReader(source='" + toString(this.g3z()) + "', currentPosition=" + this.a3n_1 + ')';
  }
  y3t(key) {
    var processed = this.j1l(0, this.a3n_1);
    var lastIndexOf_0 = lastIndexOf(processed, key);
    throw JsonDecodingException.b3q("Encountered an unknown key '" + key + "' at offset " + lastIndexOf_0 + ' at path: ' + this.b3n_1.p3s() + "\nUse 'ignoreUnknownKeys = true' in 'Json {}' builder or '@JsonIgnoreUnknownKeys' annotation to ignore unknown keys.\n" + ('JSON input: ' + toString(minify(this.g3z(), lastIndexOf_0))));
  }
  u3r(message, position, hint) {
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(hint) === 0) {
      tmp = '';
    } else {
      tmp = '\n' + hint;
    }
    var hintMessage = tmp;
    throw JsonDecodingException_0(position, message + ' at path: ' + this.b3n_1.p3s() + hintMessage, this.g3z());
  }
  v3r(message, position, hint, $super) {
    position = position === VOID ? this.a3n_1 : position;
    hint = hint === VOID ? '' : hint;
    return $super === VOID ? this.u3r(message, position, hint) : $super.u3r.call(this, message, position, hint);
  }
  j3u() {
    var current = this.j3z();
    current = this.h3z(current);
    if (current >= charSequenceLength(this.g3z()) || current === -1) {
      this.v3r('EOF');
    }
    var tmp;
    if (charSequenceGet(this.g3z(), current) === _Char___init__impl__6a9atx(34)) {
      current = current + 1 | 0;
      if (current === charSequenceLength(this.g3z())) {
        this.v3r('EOF');
      }
      tmp = true;
    } else {
      tmp = false;
    }
    var hasQuotation = tmp;
    var accumulator = new Long(0, 0);
    var exponentAccumulator = new Long(0, 0);
    var isNegative = false;
    var isExponentPositive = false;
    var hasExponent = false;
    var start = current;
    $l$loop_4: while (!(current === charSequenceLength(this.g3z()))) {
      var ch = charSequenceGet(this.g3z(), current);
      if ((ch === _Char___init__impl__6a9atx(101) || ch === _Char___init__impl__6a9atx(69)) && !hasExponent) {
        if (current === start) {
          this.v3r('Unexpected symbol ' + toString_1(ch) + ' in numeric literal');
        }
        isExponentPositive = true;
        hasExponent = true;
        current = current + 1 | 0;
        continue $l$loop_4;
      }
      if (ch === _Char___init__impl__6a9atx(45) && hasExponent) {
        if (current === start) {
          this.v3r("Unexpected symbol '-' in numeric literal");
        }
        isExponentPositive = false;
        current = current + 1 | 0;
        continue $l$loop_4;
      }
      if (ch === _Char___init__impl__6a9atx(43) && hasExponent) {
        if (current === start) {
          this.v3r("Unexpected symbol '+' in numeric literal");
        }
        isExponentPositive = true;
        current = current + 1 | 0;
        continue $l$loop_4;
      }
      if (ch === _Char___init__impl__6a9atx(45)) {
        if (!(current === start)) {
          this.v3r("Unexpected symbol '-' in numeric literal");
        }
        isNegative = true;
        current = current + 1 | 0;
        continue $l$loop_4;
      }
      var token = charToTokenClass(ch);
      if (!(token === 0))
        break $l$loop_4;
      current = current + 1 | 0;
      var digit = Char__minus_impl_a2frrh(ch, _Char___init__impl__6a9atx(48));
      if (!(0 <= digit ? digit <= 9 : false)) {
        this.v3r("Unexpected symbol '" + toString_1(ch) + "' in numeric literal");
      }
      if (hasExponent) {
        // Inline function 'kotlin.Long.times' call
        // Inline function 'kotlin.Long.plus' call
        exponentAccumulator = exponentAccumulator.w3(toLong(10)).u3(toLong(digit));
        continue $l$loop_4;
      }
      // Inline function 'kotlin.Long.times' call
      // Inline function 'kotlin.Long.minus' call
      accumulator = accumulator.w3(toLong(10)).v3(toLong(digit));
      if (accumulator.s1(new Long(0, 0)) > 0) {
        this.v3r('Numeric value overflow');
      }
    }
    var hasChars = !(current === start);
    if (start === current || (isNegative && start === (current - 1 | 0))) {
      this.v3r('Expected numeric literal');
    }
    if (hasQuotation) {
      if (!hasChars) {
        this.v3r('EOF');
      }
      if (!(charSequenceGet(this.g3z(), current) === _Char___init__impl__6a9atx(34))) {
        this.v3r('Expected closing quotation mark');
      }
      current = current + 1 | 0;
    }
    this.a3n_1 = current;
    if (hasExponent) {
      var doubleAccumulator = accumulator.m4() * consumeNumericLiteral$calculateExponent(exponentAccumulator, isExponentPositive);
      if (doubleAccumulator > (new Long(-1, 2147483647)).m4() || doubleAccumulator < (new Long(0, -2147483648)).m4()) {
        this.v3r('Numeric value overflow');
      }
      // Inline function 'kotlin.math.floor' call
      if (!(Math.floor(doubleAccumulator) === doubleAccumulator)) {
        this.v3r("Can't convert " + doubleAccumulator + ' to Long');
      }
      accumulator = numberToLong(doubleAccumulator);
    }
    var tmp_0;
    if (isNegative) {
      tmp_0 = accumulator;
    } else if (!accumulator.equals(new Long(0, -2147483648))) {
      tmp_0 = accumulator.b4();
    } else {
      this.v3r('Numeric value overflow');
    }
    return tmp_0;
  }
  c3p() {
    var result = this.j3u();
    var next = this.o3t();
    if (!(next === 10)) {
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.fail' call
      var expected = tokenDescription(10);
      var position = true ? this.a3n_1 - 1 | 0 : this.a3n_1;
      var s = this.a3n_1 === charSequenceLength(this.g3z()) || position < 0 ? 'EOF' : toString_1(charSequenceGet(this.g3z(), position));
      var tmp$ret$0 = "Expected input to contain a single valid number, but got '" + s + "' after it";
      this.v3r(tmp$ret$0, position);
    }
    return result;
  }
  i3u() {
    var current = this.j3z();
    if (current === charSequenceLength(this.g3z())) {
      this.v3r('EOF');
    }
    var tmp;
    if (charSequenceGet(this.g3z(), current) === _Char___init__impl__6a9atx(34)) {
      current = current + 1 | 0;
      tmp = true;
    } else {
      tmp = false;
    }
    var hasQuotation = tmp;
    var result = consumeBoolean2(this, current);
    if (hasQuotation) {
      if (this.a3n_1 === charSequenceLength(this.g3z())) {
        this.v3r('EOF');
      }
      if (!(charSequenceGet(this.g3z(), this.a3n_1) === _Char___init__impl__6a9atx(34))) {
        this.v3r('Expected closing quotation mark');
      }
      this.a3n_1 = this.a3n_1 + 1 | 0;
    }
    return result;
  }
}
class CharMappings {
  constructor() {
    CharMappings_instance = this;
    this.n3z_1 = charArray(117);
    this.o3z_1 = new Int8Array(126);
    initEscape(this);
    initCharToToken(this);
  }
}
class StringJsonLexer extends AbstractJsonLexer {
  constructor(source) {
    super();
    this.y3z_1 = source;
  }
  g3z() {
    return this.y3z_1;
  }
  h3z(position) {
    return position < this.g3z().length ? position : -1;
  }
  o3t() {
    var source = this.g3z();
    var cpos = this.a3n_1;
    $l$loop: while (!(cpos === -1) && cpos < source.length) {
      var _unary__edvuaz = cpos;
      cpos = _unary__edvuaz + 1 | 0;
      var c = charSequenceGet(source, _unary__edvuaz);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9))
        continue $l$loop;
      this.a3n_1 = cpos;
      return charToTokenClass(c);
    }
    this.a3n_1 = source.length;
    return 10;
  }
  k3t() {
    var current = this.a3n_1;
    if (current === -1)
      return false;
    var source = this.g3z();
    $l$loop: while (current < source.length) {
      var c = charSequenceGet(source, current);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9)) {
        current = current + 1 | 0;
        continue $l$loop;
      }
      this.a3n_1 = current;
      return this.k3z(c);
    }
    this.a3n_1 = current;
    return false;
  }
  j3z() {
    var current = this.a3n_1;
    if (current === -1)
      return current;
    var source = this.g3z();
    $l$loop: while (current < source.length) {
      var c = charSequenceGet(source, current);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9)) {
        current = current + 1 | 0;
      } else {
        break $l$loop;
      }
    }
    this.a3n_1 = current;
    return current;
  }
  u3t(expected) {
    if (this.a3n_1 === -1) {
      this.l3z(expected);
    }
    var source = this.g3z();
    var cpos = this.a3n_1;
    $l$loop: while (cpos < source.length) {
      var _unary__edvuaz = cpos;
      cpos = _unary__edvuaz + 1 | 0;
      var c = charSequenceGet(source, _unary__edvuaz);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9))
        continue $l$loop;
      this.a3n_1 = cpos;
      if (c === expected)
        return Unit_instance;
      this.l3z(expected);
    }
    this.a3n_1 = -1;
    this.l3z(expected);
  }
  a3u() {
    this.u3t(_Char___init__impl__6a9atx(34));
    var current = this.a3n_1;
    var closingQuote = indexOf_0(this.g3z(), _Char___init__impl__6a9atx(34), current);
    if (closingQuote === -1) {
      this.m3t();
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.fail' call
      var expected = tokenDescription(1);
      var position = false ? this.a3n_1 - 1 | 0 : this.a3n_1;
      var s = this.a3n_1 === charSequenceLength(this.g3z()) || position < 0 ? 'EOF' : toString_1(charSequenceGet(this.g3z(), position));
      var tmp$ret$0 = 'Expected ' + expected + ", but had '" + s + "' instead";
      this.v3r(tmp$ret$0, position);
    }
    var inductionVariable = current;
    if (inductionVariable < closingQuote)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        if (charSequenceGet(this.g3z(), i) === _Char___init__impl__6a9atx(92)) {
          return this.consumeString2(this.g3z(), this.a3n_1, i);
        }
      }
       while (inductionVariable < closingQuote);
    this.a3n_1 = closingQuote + 1 | 0;
    // Inline function 'kotlin.text.substring' call
    // Inline function 'kotlin.js.asDynamic' call
    return this.g3z().substring(current, closingQuote);
  }
  c3u(keyToMatch, isLenient) {
    var positionSnapshot = this.a3n_1;
    try {
      if (!(this.o3t() === 6))
        return null;
      var firstKey = this.x3t(isLenient);
      if (!(firstKey === keyToMatch))
        return null;
      this.m3z();
      if (!(this.o3t() === 5))
        return null;
      return this.x3t(isLenient);
    }finally {
      this.a3n_1 = positionSnapshot;
      this.m3z();
    }
  }
}
class StringJsonLexerWithComments extends StringJsonLexer {
  o3t() {
    var source = this.g3z();
    var cpos = this.j3z();
    if (cpos >= source.length || cpos === -1)
      return 10;
    this.a3n_1 = cpos + 1 | 0;
    return charToTokenClass(charSequenceGet(source, cpos));
  }
  k3t() {
    var current = this.j3z();
    if (current >= this.g3z().length || current === -1)
      return false;
    return this.k3z(charSequenceGet(this.g3z(), current));
  }
  u3t(expected) {
    var source = this.g3z();
    var current = this.j3z();
    if (current >= source.length || current === -1) {
      this.a3n_1 = -1;
      this.l3z(expected);
    }
    var c = charSequenceGet(source, current);
    this.a3n_1 = current + 1 | 0;
    if (c === expected)
      return Unit_instance;
    else {
      this.l3z(expected);
    }
  }
  i3t() {
    var source = this.g3z();
    var cpos = this.j3z();
    if (cpos >= source.length || cpos === -1)
      return 10;
    this.a3n_1 = cpos;
    return charToTokenClass(charSequenceGet(source, cpos));
  }
  j3z() {
    var current = this.a3n_1;
    if (current === -1)
      return current;
    var source = this.g3z();
    $l$loop_1: while (current < source.length) {
      var c = charSequenceGet(source, current);
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.isWs' call
      if (c === _Char___init__impl__6a9atx(32) || c === _Char___init__impl__6a9atx(10) || c === _Char___init__impl__6a9atx(13) || c === _Char___init__impl__6a9atx(9)) {
        current = current + 1 | 0;
        continue $l$loop_1;
      }
      if (c === _Char___init__impl__6a9atx(47) && (current + 1 | 0) < source.length) {
        var tmp0_subject = charSequenceGet(source, current + 1 | 0);
        if (tmp0_subject === _Char___init__impl__6a9atx(47)) {
          current = indexOf_0(source, _Char___init__impl__6a9atx(10), current + 2 | 0);
          if (current === -1) {
            current = source.length;
          } else {
            current = current + 1 | 0;
          }
          continue $l$loop_1;
        } else if (tmp0_subject === _Char___init__impl__6a9atx(42)) {
          current = indexOf(source, '*/', current + 2 | 0);
          if (current === -1) {
            this.a3n_1 = source.length;
            this.v3r('Expected end of the block comment: "*/", but had EOF instead');
          } else {
            current = current + 2 | 0;
          }
          continue $l$loop_1;
        }
      }
      break $l$loop_1;
    }
    this.a3n_1 = current;
    return current;
  }
}
class JsonToStringWriter {
  constructor() {
    this.r3m_1 = StringBuilder.xb(128);
  }
  t3q(value) {
    this.r3m_1.gh(value);
  }
  n3q(char) {
    this.r3m_1.ub(char);
  }
  p3q(text) {
    this.r3m_1.tb(text);
  }
  z3q(text) {
    printQuoted(this.r3m_1, text);
  }
  s1i() {
    this.r3m_1.jh();
  }
  toString() {
    return this.r3m_1.toString();
  }
}
//endregion
var Default_instance;
function Default_getInstance() {
  if (Default_instance === VOID)
    new Default();
  return Default_instance;
}
function Json_0(from, builderAction) {
  from = from === VOID ? Default_getInstance() : from;
  var builder = new JsonBuilder(from);
  builderAction(builder);
  var conf = builder.x3n();
  return new JsonImpl(conf, builder.w3n_1);
}
function validateConfiguration($this) {
  if (equals($this.u1y(), EmptySerializersModule()))
    return Unit_instance;
  var collector = new JsonSerializersModuleValidator($this.k3m_1);
  $this.u1y().g2f(collector);
}
var ClassDiscriminatorMode_NONE_instance;
var ClassDiscriminatorMode_ALL_JSON_OBJECTS_instance;
var ClassDiscriminatorMode_POLYMORPHIC_instance;
var ClassDiscriminatorMode_entriesInitialized;
function ClassDiscriminatorMode_initEntries() {
  if (ClassDiscriminatorMode_entriesInitialized)
    return Unit_instance;
  ClassDiscriminatorMode_entriesInitialized = true;
  ClassDiscriminatorMode_NONE_instance = new ClassDiscriminatorMode('NONE', 0);
  ClassDiscriminatorMode_ALL_JSON_OBJECTS_instance = new ClassDiscriminatorMode('ALL_JSON_OBJECTS', 1);
  ClassDiscriminatorMode_POLYMORPHIC_instance = new ClassDiscriminatorMode('POLYMORPHIC', 2);
}
function ClassDiscriminatorMode_NONE_getInstance() {
  ClassDiscriminatorMode_initEntries();
  return ClassDiscriminatorMode_NONE_instance;
}
function ClassDiscriminatorMode_POLYMORPHIC_getInstance() {
  ClassDiscriminatorMode_initEntries();
  return ClassDiscriminatorMode_POLYMORPHIC_instance;
}
function get_jsonUnquotedLiteralDescriptor() {
  _init_properties_JsonElement_kt__7cbdc2();
  return jsonUnquotedLiteralDescriptor;
}
var jsonUnquotedLiteralDescriptor;
var Companion_instance;
function Companion_getInstance_3() {
  return Companion_instance;
}
function JsonObject$toString$lambda(_destruct__k2r9zo) {
  // Inline function 'kotlin.collections.component1' call
  var k = _destruct__k2r9zo.m1();
  // Inline function 'kotlin.collections.component2' call
  var v = _destruct__k2r9zo.n1();
  // Inline function 'kotlin.text.buildString' call
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.v();
  printQuoted(this_0, k);
  this_0.ub(_Char___init__impl__6a9atx(58));
  this_0.sb(v);
  return this_0.toString();
}
var Companion_instance_0;
function Companion_getInstance_4() {
  return Companion_instance_0;
}
var Companion_instance_1;
function Companion_getInstance_5() {
  return Companion_instance_1;
}
var JsonNull_instance;
function JsonNull_getInstance() {
  if (JsonNull_instance === VOID)
    new JsonNull();
  return JsonNull_instance;
}
var Companion_instance_2;
function Companion_getInstance_6() {
  return Companion_instance_2;
}
function get_jsonObject(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof JsonObject ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    error(_this__u8e3s4, 'JsonObject');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function get_jsonPrimitive(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  var tmp0_elvis_lhs = _this__u8e3s4 instanceof JsonPrimitive ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    error(_this__u8e3s4, 'JsonPrimitive');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function JsonPrimitive_0(value) {
  _init_properties_JsonElement_kt__7cbdc2();
  if (value == null)
    return JsonNull_getInstance();
  return new JsonLiteral(value, false);
}
function JsonPrimitive_1(value) {
  _init_properties_JsonElement_kt__7cbdc2();
  if (value == null)
    return JsonNull_getInstance();
  return new JsonLiteral(value, true);
}
function JsonPrimitive_2(value) {
  _init_properties_JsonElement_kt__7cbdc2();
  if (value == null)
    return JsonNull_getInstance();
  return new JsonLiteral(value, false);
}
function get_contentOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  var tmp;
  if (_this__u8e3s4 instanceof JsonNull) {
    tmp = null;
  } else {
    tmp = _this__u8e3s4.y3o();
  }
  return tmp;
}
function get_intOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  // Inline function 'kotlinx.serialization.json.exceptionToNull' call
  var tmp;
  try {
    tmp = parseLongImpl(_this__u8e3s4);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof JsonDecodingException) {
      var e = $p;
      tmp_0 = null;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  var tmp0_elvis_lhs = tmp;
  var tmp_1;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp_1 = tmp0_elvis_lhs;
  }
  var result = tmp_1;
  // Inline function 'kotlin.ranges.contains' call
  var this_0 = numberRangeToNumber(-2147483648, 2147483647);
  if (!contains(isInterface(this_0, ClosedRange) ? this_0 : THROW_CCE(), result))
    return null;
  return result.x1();
}
function get_longOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  // Inline function 'kotlinx.serialization.json.exceptionToNull' call
  var tmp;
  try {
    tmp = parseLongImpl(_this__u8e3s4);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof JsonDecodingException) {
      var e = $p;
      tmp_0 = null;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function get_doubleOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return toDoubleOrNull(_this__u8e3s4.y3o());
}
function get_booleanOrNull(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return toBooleanStrictOrNull_0(_this__u8e3s4.y3o());
}
function error(_this__u8e3s4, element) {
  _init_properties_JsonElement_kt__7cbdc2();
  throw IllegalArgumentException.t('Element ' + toString(getKClassFromExpression(_this__u8e3s4)) + ' is not a ' + element);
}
function parseLongImpl(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return (new StringJsonLexer(_this__u8e3s4.y3o())).c3p();
}
function get_float(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  // Inline function 'kotlin.text.toFloat' call
  var this_0 = _this__u8e3s4.y3o();
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  return toDouble(this_0);
}
function get_double(_this__u8e3s4) {
  _init_properties_JsonElement_kt__7cbdc2();
  return toDouble(_this__u8e3s4.y3o());
}
var properties_initialized_JsonElement_kt_abxy8s;
function _init_properties_JsonElement_kt__7cbdc2() {
  if (!properties_initialized_JsonElement_kt_abxy8s) {
    properties_initialized_JsonElement_kt_abxy8s = true;
    jsonUnquotedLiteralDescriptor = InlinePrimitiveDescriptor('kotlinx.serialization.json.JsonUnquotedLiteral', serializer(StringCompanionObject_instance));
  }
}
function JsonElementSerializer$descriptor$lambda($this$buildSerialDescriptor) {
  $this$buildSerialDescriptor.h1u('JsonPrimitive', defer(JsonElementSerializer$descriptor$lambda$lambda));
  $this$buildSerialDescriptor.h1u('JsonNull', defer(JsonElementSerializer$descriptor$lambda$lambda_0));
  $this$buildSerialDescriptor.h1u('JsonLiteral', defer(JsonElementSerializer$descriptor$lambda$lambda_1));
  $this$buildSerialDescriptor.h1u('JsonObject', defer(JsonElementSerializer$descriptor$lambda$lambda_2));
  $this$buildSerialDescriptor.h1u('JsonArray', defer(JsonElementSerializer$descriptor$lambda$lambda_3));
  return Unit_instance;
}
function JsonElementSerializer$descriptor$lambda$lambda() {
  return JsonPrimitiveSerializer_getInstance().h3p_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_0() {
  return JsonNullSerializer_getInstance().i3p_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_1() {
  return JsonLiteralSerializer_getInstance().j3p_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_2() {
  return JsonObjectSerializer_getInstance().k3p_1;
}
function JsonElementSerializer$descriptor$lambda$lambda_3() {
  return JsonArraySerializer_getInstance().l3p_1;
}
var JsonElementSerializer_instance;
function JsonElementSerializer_getInstance() {
  if (JsonElementSerializer_instance === VOID)
    new JsonElementSerializer();
  return JsonElementSerializer_instance;
}
var JsonObjectDescriptor_instance;
function JsonObjectDescriptor_getInstance() {
  if (JsonObjectDescriptor_instance === VOID)
    new JsonObjectDescriptor();
  return JsonObjectDescriptor_instance;
}
var JsonObjectSerializer_instance;
function JsonObjectSerializer_getInstance() {
  if (JsonObjectSerializer_instance === VOID)
    new JsonObjectSerializer();
  return JsonObjectSerializer_instance;
}
var JsonArrayDescriptor_instance;
function JsonArrayDescriptor_getInstance() {
  if (JsonArrayDescriptor_instance === VOID)
    new JsonArrayDescriptor();
  return JsonArrayDescriptor_instance;
}
var JsonArraySerializer_instance;
function JsonArraySerializer_getInstance() {
  if (JsonArraySerializer_instance === VOID)
    new JsonArraySerializer();
  return JsonArraySerializer_instance;
}
var JsonNullSerializer_instance;
function JsonNullSerializer_getInstance() {
  if (JsonNullSerializer_instance === VOID)
    new JsonNullSerializer();
  return JsonNullSerializer_instance;
}
var JsonPrimitiveSerializer_instance;
function JsonPrimitiveSerializer_getInstance() {
  if (JsonPrimitiveSerializer_instance === VOID)
    new JsonPrimitiveSerializer();
  return JsonPrimitiveSerializer_instance;
}
function defer(deferred) {
  return new defer$1(deferred);
}
var JsonLiteralSerializer_instance;
function JsonLiteralSerializer_getInstance() {
  if (JsonLiteralSerializer_instance === VOID)
    new JsonLiteralSerializer();
  return JsonLiteralSerializer_instance;
}
function verify(encoder) {
  asJsonEncoder(encoder);
}
function asJsonDecoder(_this__u8e3s4) {
  var tmp0_elvis_lhs = isInterface(_this__u8e3s4, JsonDecoder) ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException.t4('This serializer can be used only with Json format.' + ('Expected Decoder to be JsonDecoder, got ' + toString(getKClassFromExpression(_this__u8e3s4))));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function verify_0(decoder) {
  asJsonDecoder(decoder);
}
function asJsonEncoder(_this__u8e3s4) {
  var tmp0_elvis_lhs = isInterface(_this__u8e3s4, JsonEncoder) ? _this__u8e3s4 : null;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException.t4('This serializer can be used only with Json format.' + ('Expected Encoder to be JsonEncoder, got ' + toString(getKClassFromExpression(_this__u8e3s4))));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function _get_original__l7ku1m($this) {
  var tmp0 = $this.e3q_1;
  // Inline function 'kotlin.getValue' call
  original$factory();
  return tmp0.n1();
}
function original$factory() {
  return getPropertyCallableRef('original', 1, KProperty1, (receiver) => _get_original__l7ku1m(receiver), null);
}
function Composer_0(sb, json) {
  return json.k3m_1.c3o_1 ? new ComposerWithPrettyPrint(sb, json) : new Composer(sb);
}
function readIfAbsent($this, descriptor, index) {
  $this.l3r_1 = (!descriptor.r1w(index) && descriptor.q1w(index).f1w());
  return $this.l3r_1;
}
function JsonElementMarker$readIfAbsent$ref($boundThis) {
  var l = (p0, p1) => readIfAbsent($boundThis, p0, p1);
  l.callableName = 'readIfAbsent';
  return l;
}
function invalidTrailingComma(_this__u8e3s4, entity) {
  entity = entity === VOID ? 'object' : entity;
  _this__u8e3s4.u3r('Trailing comma before the end of JSON ' + entity, _this__u8e3s4.a3n_1 - 1 | 0, "Trailing commas are non-complaint JSON and not allowed by default. Use 'allowTrailingComma = true' in 'Json {}' builder to support them.");
}
function throwInvalidFloatingPointDecoded(_this__u8e3s4, result) {
  _this__u8e3s4.v3r('Unexpected special floating-point value ' + toString(result) + '. By default, ' + 'non-finite floating point values are prohibited because they do not conform JSON specification', VOID, "It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'");
}
function InvalidKeyKindException(keyDescriptor) {
  return JsonEncodingException.c3s("Value of type '" + keyDescriptor.z1u() + "' can't be used in JSON as a key in the map. " + ("It should have either primitive or enum kind, but its kind is '" + keyDescriptor.j1w().toString() + "'.\n") + "Use 'allowStructuredMapKeys = true' in 'Json {}' builder to convert such maps to [key1, value1, key2, value2,...] arrays.");
}
function InvalidFloatingPointEncoded(value, key, output) {
  return JsonEncodingException.c3s(unexpectedFpErrorMessage(value, key, output));
}
function JsonDecodingException_0(offset, message, input) {
  return JsonDecodingException_1(offset, message + '\nJSON input: ' + toString(minify(input, offset)));
}
function InvalidFloatingPointDecoded(value, key, output) {
  return JsonDecodingException_1(-1, unexpectedFpErrorMessage(value, key, output));
}
function JsonDecodingException_1(offset, message) {
  return JsonDecodingException.b3q(offset >= 0 ? 'Unexpected JSON token at offset ' + offset + ': ' + message : message);
}
function minify(_this__u8e3s4, offset) {
  offset = offset === VOID ? -1 : offset;
  if (charSequenceLength(_this__u8e3s4) < 200)
    return _this__u8e3s4;
  if (offset === -1) {
    var start = charSequenceLength(_this__u8e3s4) - 60 | 0;
    if (start <= 0)
      return _this__u8e3s4;
    // Inline function 'kotlin.text.substring' call
    var endIndex = charSequenceLength(_this__u8e3s4);
    return '.....' + toString(charSequenceSubSequence(_this__u8e3s4, start, endIndex));
  }
  var start_0 = offset - 30 | 0;
  var end = offset + 30 | 0;
  var prefix = start_0 <= 0 ? '' : '.....';
  var suffix = end >= charSequenceLength(_this__u8e3s4) ? '' : '.....';
  var tmp4 = coerceAtLeast(start_0, 0);
  // Inline function 'kotlin.text.substring' call
  var endIndex_0 = coerceAtMost(end, charSequenceLength(_this__u8e3s4));
  return prefix + toString(charSequenceSubSequence(_this__u8e3s4, tmp4, endIndex_0)) + suffix;
}
function unexpectedFpErrorMessage(value, key, output) {
  return 'Unexpected special floating-point value ' + toString(value) + ' with key ' + key + '. By default, ' + "non-finite floating point values are prohibited because they do not conform JSON specification. It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'\n" + ('Current output: ' + toString(minify(output)));
}
function InvalidFloatingPointEncoded_0(value, output) {
  return JsonEncodingException.c3s('Unexpected special floating-point value ' + toString(value) + '. By default, ' + "non-finite floating point values are prohibited because they do not conform JSON specification. It is possible to deserialize them using 'JsonBuilder.allowSpecialFloatingPointValues = true'\n" + ('Current output: ' + toString(minify(output))));
}
function get_JsonDeserializationNamesKey() {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return JsonDeserializationNamesKey;
}
var JsonDeserializationNamesKey;
function get_JsonSerializationNamesKey() {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return JsonSerializationNamesKey;
}
var JsonSerializationNamesKey;
function ignoreUnknownKeys(_this__u8e3s4, json) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp;
  if (json.k3m_1.z3n_1) {
    tmp = true;
  } else {
    var tmp0 = _this__u8e3s4.m1w();
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.any' call
      var tmp_0;
      if (isInterface(tmp0, Collection)) {
        tmp_0 = tmp0.h1();
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$0 = false;
        break $l$block_0;
      }
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (element instanceof JsonIgnoreUnknownKeys) {
          tmp$ret$0 = true;
          break $l$block_0;
        }
      }
      tmp$ret$0 = false;
    }
    tmp = tmp$ret$0;
  }
  return tmp;
}
function getJsonNameIndex(_this__u8e3s4, json, name) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  if (decodeCaseInsensitive(json, _this__u8e3s4)) {
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$1 = name.toLowerCase();
    return getJsonNameIndexSlowPath(_this__u8e3s4, json, tmp$ret$1);
  }
  var strategy = namingStrategy(_this__u8e3s4, json);
  if (!(strategy == null))
    return getJsonNameIndexSlowPath(_this__u8e3s4, json, name);
  var index = _this__u8e3s4.o1w(name);
  if (!(index === -3))
    return index;
  if (!json.k3m_1.j3o_1)
    return index;
  return getJsonNameIndexSlowPath(_this__u8e3s4, json, name);
}
function getJsonNameIndexOrThrow(_this__u8e3s4, json, name, suffix) {
  suffix = suffix === VOID ? '' : suffix;
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var index = getJsonNameIndex(_this__u8e3s4, json, name);
  if (index === -3)
    throw SerializationException.i1v(_this__u8e3s4.z1u() + " does not contain element with name '" + name + "'" + suffix);
  return index;
}
function getJsonElementName(_this__u8e3s4, json, index) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var strategy = namingStrategy(_this__u8e3s4, json);
  return strategy == null ? _this__u8e3s4.n1w(index) : serializationNamesIndices(_this__u8e3s4, json, strategy)[index];
}
function namingStrategy(_this__u8e3s4, json) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return equals(_this__u8e3s4.j1w(), CLASS_getInstance()) ? json.k3m_1.k3o_1 : null;
}
function deserializationNamesMap(_this__u8e3s4, descriptor) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp = get_schemaCache(_this__u8e3s4);
  var tmp_0 = get_JsonDeserializationNamesKey();
  return tmp.e3s(descriptor, tmp_0, deserializationNamesMap$lambda(descriptor, _this__u8e3s4));
}
function decodeCaseInsensitive(_this__u8e3s4, descriptor) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  return _this__u8e3s4.k3m_1.l3o_1 && equals(descriptor.j1w(), ENUM_getInstance());
}
function getJsonNameIndexSlowPath(_this__u8e3s4, json, name) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp0_elvis_lhs = deserializationNamesMap(json, _this__u8e3s4).h3(name);
  return tmp0_elvis_lhs == null ? -3 : tmp0_elvis_lhs;
}
function serializationNamesIndices(_this__u8e3s4, json, strategy) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  var tmp = get_schemaCache(json);
  var tmp_0 = get_JsonSerializationNamesKey();
  return tmp.e3s(_this__u8e3s4, tmp_0, serializationNamesIndices$lambda(_this__u8e3s4, strategy));
}
function buildDeserializationNamesMap(_this__u8e3s4, json) {
  _init_properties_JsonNamesMap_kt__cbbp0k();
  // Inline function 'kotlin.collections.mutableMapOf' call
  var builder = LinkedHashMap.hc();
  var useLowercaseEnums = decodeCaseInsensitive(json, _this__u8e3s4);
  var strategyForClasses = namingStrategy(_this__u8e3s4, json);
  var inductionVariable = 0;
  var last = _this__u8e3s4.l1w();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.collections.filterIsInstance' call
      var tmp0 = _this__u8e3s4.p1w(i);
      // Inline function 'kotlin.collections.filterIsInstanceTo' call
      var destination = ArrayList.k();
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (element instanceof JsonNames) {
          destination.l(element);
        }
      }
      var tmp0_safe_receiver = singleOrNull(destination);
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.f3s_1;
      if (tmp1_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var inductionVariable_0 = 0;
        var last_0 = tmp1_safe_receiver.length;
        while (inductionVariable_0 < last_0) {
          var element_0 = tmp1_safe_receiver[inductionVariable_0];
          inductionVariable_0 = inductionVariable_0 + 1 | 0;
          var tmp;
          if (useLowercaseEnums) {
            // Inline function 'kotlin.text.lowercase' call
            // Inline function 'kotlin.js.asDynamic' call
            tmp = element_0.toLowerCase();
          } else {
            tmp = element_0;
          }
          buildDeserializationNamesMap$putOrThrow(builder, _this__u8e3s4, tmp, i);
        }
      }
      var tmp_0;
      if (useLowercaseEnums) {
        // Inline function 'kotlin.text.lowercase' call
        // Inline function 'kotlin.js.asDynamic' call
        tmp_0 = _this__u8e3s4.n1w(i).toLowerCase();
      } else if (!(strategyForClasses == null)) {
        tmp_0 = strategyForClasses.g3s(_this__u8e3s4, i, _this__u8e3s4.n1w(i));
      } else {
        tmp_0 = null;
      }
      var nameToPut = tmp_0;
      if (nameToPut == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        buildDeserializationNamesMap$putOrThrow(builder, _this__u8e3s4, nameToPut, i);
      }
    }
     while (inductionVariable < last);
  // Inline function 'kotlin.collections.ifEmpty' call
  var tmp_1;
  if (builder.h1()) {
    tmp_1 = emptyMap();
  } else {
    tmp_1 = builder;
  }
  return tmp_1;
}
function buildDeserializationNamesMap$putOrThrow(_this__u8e3s4, $this_buildDeserializationNamesMap, name, index) {
  var entity = equals($this_buildDeserializationNamesMap.j1w(), ENUM_getInstance()) ? 'enum value' : 'property';
  // Inline function 'kotlin.collections.contains' call
  // Inline function 'kotlin.collections.containsKey' call
  if ((isInterface(_this__u8e3s4, KtMap) ? _this__u8e3s4 : THROW_CCE()).f3(name)) {
    throw JsonException.t3r("The suggested name '" + name + "' for " + entity + ' ' + $this_buildDeserializationNamesMap.n1w(index) + ' is already one of the names for ' + entity + ' ' + ($this_buildDeserializationNamesMap.n1w(getValue(_this__u8e3s4, name)) + ' in ' + toString($this_buildDeserializationNamesMap)));
  }
  // Inline function 'kotlin.collections.set' call
  _this__u8e3s4.k3(name, index);
}
function deserializationNamesMap$lambda($descriptor, $this_deserializationNamesMap) {
  return () => buildDeserializationNamesMap($descriptor, $this_deserializationNamesMap);
}
function serializationNamesIndices$lambda($this_serializationNamesIndices, $strategy) {
  return () => {
    var tmp = 0;
    var tmp_0 = $this_serializationNamesIndices.l1w();
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      var baseName = $this_serializationNamesIndices.n1w(tmp_2);
      tmp_1[tmp_2] = $strategy.g3s($this_serializationNamesIndices, tmp_2, baseName);
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  };
}
var properties_initialized_JsonNamesMap_kt_ljpf42;
function _init_properties_JsonNamesMap_kt__cbbp0k() {
  if (!properties_initialized_JsonNamesMap_kt_ljpf42) {
    properties_initialized_JsonNamesMap_kt_ljpf42 = true;
    JsonDeserializationNamesKey = new Key();
    JsonSerializationNamesKey = new Key();
  }
}
var Tombstone_instance;
function Tombstone_getInstance() {
  return Tombstone_instance;
}
function resize($this) {
  var newSize = imul($this.j3s_1, 2);
  $this.h3s_1 = copyOf($this.h3s_1, newSize);
  $this.i3s_1 = copyOf_0($this.i3s_1, newSize);
}
function checkKind($this, descriptor, actualClass) {
  var kind = descriptor.j1w();
  var tmp;
  if (kind instanceof PolymorphicKind) {
    tmp = true;
  } else {
    tmp = equals(kind, CONTEXTUAL_getInstance());
  }
  if (tmp) {
    throw IllegalArgumentException.t('Serializer for ' + actualClass.hf() + " can't be registered as a subclass for polymorphic serialization " + ('because its kind ' + kind.toString() + ' is not concrete. To work with multiple hierarchies, register it as a base class.'));
  }
  if ($this.r3s_1)
    return Unit_instance;
  if (!$this.s3s_1)
    return Unit_instance;
  var tmp_0;
  var tmp_1;
  if (equals(kind, LIST_getInstance()) || equals(kind, MAP_getInstance())) {
    tmp_1 = true;
  } else {
    tmp_1 = kind instanceof PrimitiveKind;
  }
  if (tmp_1) {
    tmp_0 = true;
  } else {
    tmp_0 = kind instanceof ENUM;
  }
  if (tmp_0) {
    throw IllegalArgumentException.t('Serializer for ' + actualClass.hf() + ' of kind ' + kind.toString() + ' cannot be serialized polymorphically with class discriminator.');
  }
}
function checkDiscriminatorCollisions($this, descriptor, actualClass) {
  var inductionVariable = 0;
  var last = descriptor.l1w();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var name = descriptor.n1w(i);
      if (name === $this.q3s_1) {
        throw IllegalArgumentException.t('Polymorphic serializer for ' + toString(actualClass) + " has property '" + name + "' that conflicts " + 'with JSON class discriminator. You can either change class discriminator in JsonConfiguration, rename property with @SerialName annotation or fall back to array polymorphism');
      }
    }
     while (inductionVariable < last);
}
function encodeByWriter(json, writer, serializer, value) {
  var tmp = WriteMode_OBJ_getInstance();
  // Inline function 'kotlin.arrayOfNulls' call
  var size = get_entries().b1();
  var tmp$ret$0 = Array(size);
  var encoder = StreamingJsonEncoder.c3t(writer, json, tmp, tmp$ret$0);
  encoder.y1z(serializer, value);
}
function *_generator_invoke__zhh2q8($this, $this$DeepRecursiveFunction, it, $completion) {
  var tmp0_subject = $this.h3t_1.d3t_1.i3t();
  var tmp;
  if (tmp0_subject === 1) {
    tmp = readValue($this.h3t_1, true);
  } else if (tmp0_subject === 0) {
    tmp = readValue($this.h3t_1, false);
  } else if (tmp0_subject === 6) {
    var tmp_0 = readObject_0($this.h3t_1, $this$DeepRecursiveFunction, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } else if (tmp0_subject === 8) {
    tmp = readArray($this.h3t_1);
  } else {
    $this.h3t_1.d3t_1.v3r("Can't begin reading element, unexpected token");
  }
  return tmp;
}
function readObject($this) {
  // Inline function 'kotlinx.serialization.json.internal.JsonTreeReader.readObjectImpl' call
  var lastToken = $this.d3t_1.j3t(6);
  if ($this.d3t_1.i3t() === 4) {
    $this.d3t_1.v3r('Unexpected leading comma');
  }
  // Inline function 'kotlin.collections.linkedMapOf' call
  var result = LinkedHashMap.hc();
  $l$loop: while ($this.d3t_1.k3t()) {
    var key = $this.e3t_1 ? $this.d3t_1.m3t() : $this.d3t_1.l3t();
    $this.d3t_1.j3t(5);
    var element = $this.n3t();
    // Inline function 'kotlin.collections.set' call
    result.k3(key, element);
    lastToken = $this.d3t_1.o3t();
    var tmp0_subject = lastToken;
    if (tmp0_subject !== 4)
      if (tmp0_subject === 7)
        break $l$loop;
      else {
        $this.d3t_1.v3r('Expected end of the object or comma');
      }
  }
  if (lastToken === 6) {
    $this.d3t_1.j3t(7);
  } else if (lastToken === 4) {
    if (!$this.f3t_1) {
      invalidTrailingComma($this.d3t_1);
    }
    $this.d3t_1.j3t(7);
  }
  return new JsonObject(result);
}
function *_generator_readObject__361wel($this, _this__u8e3s4, $completion) {
  // Inline function 'kotlinx.serialization.json.internal.JsonTreeReader.readObjectImpl' call
  var lastToken = $this.d3t_1.j3t(6);
  if ($this.d3t_1.i3t() === 4) {
    $this.d3t_1.v3r('Unexpected leading comma');
  }
  // Inline function 'kotlin.collections.linkedMapOf' call
  var result = LinkedHashMap.hc();
  $l$loop: while ($this.d3t_1.k3t()) {
    var key = $this.e3t_1 ? $this.d3t_1.m3t() : $this.d3t_1.l3t();
    $this.d3t_1.j3t(5);
    var tmp = _this__u8e3s4.hr(Unit_instance, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var element = tmp;
    // Inline function 'kotlin.collections.set' call
    result.k3(key, element);
    lastToken = $this.d3t_1.o3t();
    var tmp0_subject = lastToken;
    if (tmp0_subject !== 4)
      if (tmp0_subject === 7)
        break $l$loop;
      else {
        $this.d3t_1.v3r('Expected end of the object or comma');
      }
  }
  if (lastToken === 6) {
    $this.d3t_1.j3t(7);
  } else if (lastToken === 4) {
    if (!$this.f3t_1) {
      invalidTrailingComma($this.d3t_1);
    }
    $this.d3t_1.j3t(7);
  }
  return new JsonObject(result);
}
function readObject_0($this, _this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_readObject__361wel.bind(VOID, $this, _this__u8e3s4), $completion);
}
function readArray($this) {
  var lastToken = $this.d3t_1.o3t();
  if ($this.d3t_1.i3t() === 4) {
    $this.d3t_1.v3r('Unexpected leading comma');
  }
  // Inline function 'kotlin.collections.arrayListOf' call
  var result = ArrayList.k();
  while ($this.d3t_1.k3t()) {
    var element = $this.n3t();
    result.l(element);
    lastToken = $this.d3t_1.o3t();
    if (!(lastToken === 4)) {
      var tmp0 = $this.d3t_1;
      // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.require' call
      var condition = lastToken === 9;
      var position = tmp0.a3n_1;
      if (!condition) {
        var tmp$ret$1 = 'Expected end of the array or comma';
        tmp0.v3r(tmp$ret$1, position);
      }
    }
  }
  if (lastToken === 8) {
    $this.d3t_1.j3t(9);
  } else if (lastToken === 4) {
    if (!$this.f3t_1) {
      invalidTrailingComma($this.d3t_1, 'array');
    }
    $this.d3t_1.j3t(9);
  }
  return new JsonArray(result);
}
function readValue($this, isString) {
  var tmp;
  if ($this.e3t_1 || !isString) {
    tmp = $this.d3t_1.m3t();
  } else {
    tmp = $this.d3t_1.l3t();
  }
  var string = tmp;
  if (!isString && string === 'null')
    return JsonNull_getInstance();
  return new JsonLiteral(string, isString);
}
function readDeepRecursive($this) {
  return invoke(new DeepRecursiveFunction(JsonTreeReader$readDeepRecursive$slambda_0($this)), Unit_instance);
}
function JsonTreeReader$readDeepRecursive$slambda_0(this$0) {
  var i = new JsonTreeReader$readDeepRecursive$slambda(this$0);
  var l = ($this$DeepRecursiveFunction, it, $completion) => i.p3t($this$DeepRecursiveFunction, it, $completion);
  l.$arity = 2;
  return l;
}
function classDiscriminator(_this__u8e3s4, json) {
  var _iterator__ex2g4s = _this__u8e3s4.m1w().y();
  while (_iterator__ex2g4s.z()) {
    var annotation = _iterator__ex2g4s.a1();
    if (annotation instanceof JsonClassDiscriminator)
      return annotation.q3t_1;
  }
  return json.k3m_1.h3o_1;
}
function validateIfSealed(serializer, actualSerializer, classDiscriminator) {
  if (!(serializer instanceof SealedClassSerializer))
    return Unit_instance;
  if (jsonCachedSerialNames(actualSerializer.w1t()).v2(classDiscriminator)) {
    var baseName = serializer.w1t().z1u();
    var actualName = actualSerializer.w1t().z1u();
    // Inline function 'kotlin.error' call
    var message = "Sealed class '" + actualName + "' cannot be serialized as base class '" + baseName + "' because" + (" it has property name that conflicts with JSON class discriminator '" + classDiscriminator + "'. ") + 'You can either change class discriminator in JsonConfiguration, rename property with @SerialName annotation or fall back to array polymorphism';
    throw IllegalStateException.t4(toString(message));
  }
}
function checkKind_0(kind) {
  if (kind instanceof ENUM) {
    // Inline function 'kotlin.error' call
    var message = "Enums cannot be serialized polymorphically with 'type' parameter. You can use 'JsonBuilder.useArrayPolymorphism' instead";
    throw IllegalStateException.t4(toString(message));
  }
  if (kind instanceof PrimitiveKind) {
    // Inline function 'kotlin.error' call
    var message_0 = "Primitives cannot be serialized polymorphically with 'type' parameter. You can use 'JsonBuilder.useArrayPolymorphism' instead";
    throw IllegalStateException.t4(toString(message_0));
  }
  if (kind instanceof PolymorphicKind) {
    // Inline function 'kotlin.error' call
    var message_1 = 'Actual serializer for polymorphic cannot be polymorphic itself';
    throw IllegalStateException.t4(toString(message_1));
  }
}
function access$validateIfSealed$tPolymorphicKt(serializer, actualSerializer, classDiscriminator) {
  return validateIfSealed(serializer, actualSerializer, classDiscriminator);
}
function trySkip($this, _this__u8e3s4, unknownKey) {
  if (_this__u8e3s4 == null)
    return false;
  if (_this__u8e3s4.t3t_1 === unknownKey) {
    _this__u8e3s4.t3t_1 = null;
    return true;
  }
  return false;
}
function skipLeftoverElements($this, descriptor) {
  while (!($this.w1y(descriptor) === -1)) {
  }
}
function checkLeadingComma($this) {
  if ($this.u3m_1.i3t() === 4) {
    $this.u3m_1.v3r('Unexpected leading comma');
  }
}
function decodeMapIndex($this) {
  var hasComma = false;
  var decodingKey = !(($this.w3m_1 % 2 | 0) === 0);
  if (decodingKey) {
    if (!($this.w3m_1 === -1)) {
      hasComma = $this.u3m_1.v3t();
    }
  } else {
    $this.u3m_1.u3t(_Char___init__impl__6a9atx(58));
  }
  var tmp;
  if ($this.u3m_1.k3t()) {
    if (decodingKey) {
      if ($this.w3m_1 === -1) {
        var tmp0 = $this.u3m_1;
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.require' call
        var condition = !hasComma;
        var position = tmp0.a3n_1;
        if (!condition) {
          var tmp$ret$0 = 'Unexpected leading comma';
          tmp0.v3r(tmp$ret$0, position);
        }
      } else {
        var tmp3 = $this.u3m_1;
        // Inline function 'kotlinx.serialization.json.internal.AbstractJsonLexer.require' call
        var condition_0 = hasComma;
        var position_0 = tmp3.a3n_1;
        if (!condition_0) {
          var tmp$ret$2 = 'Expected comma after the key-value pair';
          tmp3.v3r(tmp$ret$2, position_0);
        }
      }
    }
    $this.w3m_1 = $this.w3m_1 + 1 | 0;
    tmp = $this.w3m_1;
  } else {
    if (hasComma && !$this.s3m_1.k3m_1.m3o_1) {
      invalidTrailingComma($this.u3m_1);
    }
    tmp = -1;
  }
  return tmp;
}
function coerceInputValue($this, descriptor, index) {
  var tmp0 = $this.s3m_1;
  var tmp$ret$1;
  $l$block_2: {
    // Inline function 'kotlinx.serialization.json.internal.tryCoerceValue' call
    var isOptional = descriptor.r1w(index);
    var elementDescriptor = descriptor.q1w(index);
    var tmp;
    if (isOptional && !elementDescriptor.f1w()) {
      tmp = $this.u3m_1.w3t(true);
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$1 = true;
      break $l$block_2;
    }
    if (equals(elementDescriptor.j1w(), ENUM_getInstance())) {
      var tmp_0;
      if (elementDescriptor.f1w()) {
        tmp_0 = $this.u3m_1.w3t(false);
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        tmp$ret$1 = false;
        break $l$block_2;
      }
      var tmp0_elvis_lhs = $this.u3m_1.x3t($this.y3m_1.a3o_1);
      var tmp_1;
      if (tmp0_elvis_lhs == null) {
        tmp$ret$1 = false;
        break $l$block_2;
      } else {
        tmp_1 = tmp0_elvis_lhs;
      }
      var enumValue = tmp_1;
      var enumIndex = getJsonNameIndex(elementDescriptor, tmp0, enumValue);
      var coerceToNull = !tmp0.k3m_1.d3o_1 && elementDescriptor.f1w();
      if (enumIndex === -3 && (isOptional || coerceToNull)) {
        $this.u3m_1.l3t();
        tmp$ret$1 = true;
        break $l$block_2;
      }
    }
    tmp$ret$1 = false;
  }
  return tmp$ret$1;
}
function decodeObjectIndex($this, descriptor) {
  var hasComma = $this.u3m_1.v3t();
  while ($this.u3m_1.k3t()) {
    hasComma = false;
    var key = decodeStringKey($this);
    $this.u3m_1.u3t(_Char___init__impl__6a9atx(58));
    var index = getJsonNameIndex(descriptor, $this.s3m_1, key);
    var tmp;
    if (!(index === -3)) {
      var tmp_0;
      if ($this.y3m_1.f3o_1 && coerceInputValue($this, descriptor, index)) {
        hasComma = $this.u3m_1.v3t();
        tmp_0 = false;
      } else {
        var tmp0_safe_receiver = $this.z3m_1;
        if (tmp0_safe_receiver == null)
          null;
        else {
          tmp0_safe_receiver.m3r(index);
        }
        return index;
      }
      tmp = tmp_0;
    } else {
      tmp = true;
    }
    var isUnknown = tmp;
    if (isUnknown) {
      hasComma = handleUnknown($this, descriptor, key);
    }
  }
  if (hasComma && !$this.s3m_1.k3m_1.m3o_1) {
    invalidTrailingComma($this.u3m_1);
  }
  var tmp1_safe_receiver = $this.z3m_1;
  var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.n3r();
  return tmp2_elvis_lhs == null ? -1 : tmp2_elvis_lhs;
}
function handleUnknown($this, descriptor, key) {
  if (ignoreUnknownKeys(descriptor, $this.s3m_1) || trySkip($this, $this.x3m_1, key)) {
    $this.u3m_1.z3t($this.y3m_1.a3o_1);
  } else {
    $this.u3m_1.b3n_1.o3s();
    $this.u3m_1.y3t(key);
  }
  return $this.u3m_1.v3t();
}
function decodeListIndex($this) {
  var hasComma = $this.u3m_1.v3t();
  var tmp;
  if ($this.u3m_1.k3t()) {
    if (!($this.w3m_1 === -1) && !hasComma) {
      $this.u3m_1.v3r('Expected end of the array or comma');
    }
    $this.w3m_1 = $this.w3m_1 + 1 | 0;
    tmp = $this.w3m_1;
  } else {
    if (hasComma && !$this.s3m_1.k3m_1.m3o_1) {
      invalidTrailingComma($this.u3m_1, 'array');
    }
    tmp = -1;
  }
  return tmp;
}
function decodeStringKey($this) {
  var tmp;
  if ($this.y3m_1.a3o_1) {
    tmp = $this.u3m_1.b3u();
  } else {
    tmp = $this.u3m_1.a3u();
  }
  return tmp;
}
function get_unsignedNumberDescriptors() {
  _init_properties_StreamingJsonEncoder_kt__pn1bsi();
  return unsignedNumberDescriptors;
}
var unsignedNumberDescriptors;
function encodeTypeInfo($this, discriminator, serialName) {
  $this.t3s_1.j3q();
  $this.k1z(discriminator);
  $this.t3s_1.m3q(_Char___init__impl__6a9atx(58));
  $this.t3s_1.l3q();
  $this.k1z(serialName);
}
function get_isUnsignedNumber(_this__u8e3s4) {
  _init_properties_StreamingJsonEncoder_kt__pn1bsi();
  return _this__u8e3s4.k1w() && get_unsignedNumberDescriptors().v2(_this__u8e3s4);
}
function get_isUnquotedLiteral(_this__u8e3s4) {
  _init_properties_StreamingJsonEncoder_kt__pn1bsi();
  return _this__u8e3s4.k1w() && equals(_this__u8e3s4, get_jsonUnquotedLiteralDescriptor());
}
var properties_initialized_StreamingJsonEncoder_kt_6ifwwk;
function _init_properties_StreamingJsonEncoder_kt__pn1bsi() {
  if (!properties_initialized_StreamingJsonEncoder_kt_6ifwwk) {
    properties_initialized_StreamingJsonEncoder_kt_6ifwwk = true;
    unsignedNumberDescriptors = setOf([serializer_1(Companion_getInstance_0()).w1t(), serializer_0(Companion_getInstance()).w1t(), serializer_2(Companion_getInstance_1()).w1t(), serializer_3(Companion_getInstance_2()).w1t()]);
  }
}
function get_ESCAPE_STRINGS() {
  _init_properties_StringOps_kt__fcy1db();
  return ESCAPE_STRINGS;
}
var ESCAPE_STRINGS;
var ESCAPE_MARKERS;
function toHexChar(i) {
  _init_properties_StringOps_kt__fcy1db();
  var d = i & 15;
  var tmp;
  if (d < 10) {
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(48);
    var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
    tmp = numberToChar(d + tmp$ret$0 | 0);
  } else {
    var tmp_0 = d - 10 | 0;
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(97);
    var tmp$ret$1 = Char__toInt_impl_vasixd(this_1);
    tmp = numberToChar(tmp_0 + tmp$ret$1 | 0);
  }
  return tmp;
}
function printQuoted(_this__u8e3s4, value) {
  _init_properties_StringOps_kt__fcy1db();
  _this__u8e3s4.ub(_Char___init__impl__6a9atx(34));
  var lastPos = 0;
  var inductionVariable = 0;
  var last = charSequenceLength(value) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(value, i);
      var c = Char__toInt_impl_vasixd(this_0);
      if (c < get_ESCAPE_STRINGS().length && !(get_ESCAPE_STRINGS()[c] == null)) {
        _this__u8e3s4.ch(value, lastPos, i);
        _this__u8e3s4.tb(get_ESCAPE_STRINGS()[c]);
        lastPos = i + 1 | 0;
      }
    }
     while (inductionVariable <= last);
  if (!(lastPos === 0))
    _this__u8e3s4.ch(value, lastPos, value.length);
  else
    _this__u8e3s4.tb(value);
  _this__u8e3s4.ub(_Char___init__impl__6a9atx(34));
}
function toBooleanStrictOrNull_0(_this__u8e3s4) {
  _init_properties_StringOps_kt__fcy1db();
  return equals_0(_this__u8e3s4, 'true', true) ? true : equals_0(_this__u8e3s4, 'false', true) ? false : null;
}
var properties_initialized_StringOps_kt_wzaea7;
function _init_properties_StringOps_kt__fcy1db() {
  if (!properties_initialized_StringOps_kt_wzaea7) {
    properties_initialized_StringOps_kt_wzaea7 = true;
    // Inline function 'kotlin.arrayOfNulls' call
    // Inline function 'kotlin.apply' call
    var this_0 = Array(93);
    var inductionVariable = 0;
    if (inductionVariable <= 31)
      do {
        var c = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var c1 = toHexChar(c >> 12);
        var c2 = toHexChar(c >> 8);
        var c3 = toHexChar(c >> 4);
        var c4 = toHexChar(c);
        this_0[c] = '\\u' + toString_1(c1) + toString_1(c2) + toString_1(c3) + toString_1(c4);
      }
       while (inductionVariable <= 31);
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(34);
    this_0[Char__toInt_impl_vasixd(this_1)] = '\\"';
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(92);
    this_0[Char__toInt_impl_vasixd(this_2)] = '\\\\';
    // Inline function 'kotlin.code' call
    var this_3 = _Char___init__impl__6a9atx(9);
    this_0[Char__toInt_impl_vasixd(this_3)] = '\\t';
    // Inline function 'kotlin.code' call
    var this_4 = _Char___init__impl__6a9atx(8);
    this_0[Char__toInt_impl_vasixd(this_4)] = '\\b';
    // Inline function 'kotlin.code' call
    var this_5 = _Char___init__impl__6a9atx(10);
    this_0[Char__toInt_impl_vasixd(this_5)] = '\\n';
    // Inline function 'kotlin.code' call
    var this_6 = _Char___init__impl__6a9atx(13);
    this_0[Char__toInt_impl_vasixd(this_6)] = '\\r';
    this_0[12] = '\\f';
    ESCAPE_STRINGS = this_0;
    // Inline function 'kotlin.apply' call
    var this_7 = new Int8Array(93);
    var inductionVariable_0 = 0;
    if (inductionVariable_0 <= 31)
      do {
        var c_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        this_7[c_0] = 1;
      }
       while (inductionVariable_0 <= 31);
    // Inline function 'kotlin.code' call
    var this_8 = _Char___init__impl__6a9atx(34);
    var tmp = Char__toInt_impl_vasixd(this_8);
    // Inline function 'kotlin.code' call
    var this_9 = _Char___init__impl__6a9atx(34);
    var tmp$ret$1 = Char__toInt_impl_vasixd(this_9);
    this_7[tmp] = toByte(tmp$ret$1);
    // Inline function 'kotlin.code' call
    var this_10 = _Char___init__impl__6a9atx(92);
    var tmp_0 = Char__toInt_impl_vasixd(this_10);
    // Inline function 'kotlin.code' call
    var this_11 = _Char___init__impl__6a9atx(92);
    var tmp$ret$3 = Char__toInt_impl_vasixd(this_11);
    this_7[tmp_0] = toByte(tmp$ret$3);
    // Inline function 'kotlin.code' call
    var this_12 = _Char___init__impl__6a9atx(9);
    var tmp_1 = Char__toInt_impl_vasixd(this_12);
    // Inline function 'kotlin.code' call
    var this_13 = _Char___init__impl__6a9atx(116);
    var tmp$ret$5 = Char__toInt_impl_vasixd(this_13);
    this_7[tmp_1] = toByte(tmp$ret$5);
    // Inline function 'kotlin.code' call
    var this_14 = _Char___init__impl__6a9atx(8);
    var tmp_2 = Char__toInt_impl_vasixd(this_14);
    // Inline function 'kotlin.code' call
    var this_15 = _Char___init__impl__6a9atx(98);
    var tmp$ret$7 = Char__toInt_impl_vasixd(this_15);
    this_7[tmp_2] = toByte(tmp$ret$7);
    // Inline function 'kotlin.code' call
    var this_16 = _Char___init__impl__6a9atx(10);
    var tmp_3 = Char__toInt_impl_vasixd(this_16);
    // Inline function 'kotlin.code' call
    var this_17 = _Char___init__impl__6a9atx(110);
    var tmp$ret$9 = Char__toInt_impl_vasixd(this_17);
    this_7[tmp_3] = toByte(tmp$ret$9);
    // Inline function 'kotlin.code' call
    var this_18 = _Char___init__impl__6a9atx(13);
    var tmp_4 = Char__toInt_impl_vasixd(this_18);
    // Inline function 'kotlin.code' call
    var this_19 = _Char___init__impl__6a9atx(114);
    var tmp$ret$11 = Char__toInt_impl_vasixd(this_19);
    this_7[tmp_4] = toByte(tmp$ret$11);
    // Inline function 'kotlin.code' call
    var this_20 = _Char___init__impl__6a9atx(102);
    var tmp$ret$12 = Char__toInt_impl_vasixd(this_20);
    this_7[12] = toByte(tmp$ret$12);
    ESCAPE_MARKERS = this_7;
  }
}
function unparsedPrimitive($this, literal, primitive, tag) {
  var type = startsWith(primitive, 'i') ? 'an ' + primitive : 'a ' + primitive;
  throw JsonDecodingException_0(-1, "Failed to parse literal '" + literal.toString() + "' as " + type + ' value at element: ' + $this.t3u(tag), toString($this.u3u()));
}
function setForceNull($this, descriptor, index) {
  $this.r3v_1 = (!$this.p3o().k3m_1.d3o_1 && !descriptor.r1w(index) && descriptor.q1w(index).f1w());
  return $this.r3v_1;
}
function readPolymorphicJson(_this__u8e3s4, discriminator, element, deserializer) {
  return (new JsonTreeDecoder(_this__u8e3s4, element, discriminator, deserializer.w1t())).e1y(deserializer);
}
function writeJson(json, value, serializer) {
  var result = {_v: null};
  var encoder = new JsonTreeEncoder(json, writeJson$lambda(result));
  encoder.y1z(serializer, value);
  var tmp;
  if (result._v == null) {
    throwUninitializedPropertyAccessException('result');
  } else {
    tmp = result._v;
  }
  return tmp;
}
function inlineUnsignedNumberEncoder($this, tag) {
  return AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1.c3y($this, tag);
}
function inlineUnquotedLiteralEncoder($this, tag, inlineDescriptor) {
  return AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1.g3y($this, tag, inlineDescriptor);
}
function AbstractJsonTreeEncoder$beginStructure$lambda(this$0) {
  return (node) => {
    this$0.k3x(this$0.c2d(), node);
    return Unit_instance;
  };
}
function get_requiresTopLevelTag(_this__u8e3s4) {
  var tmp;
  var tmp_0 = _this__u8e3s4.j1w();
  if (tmp_0 instanceof PrimitiveKind) {
    tmp = true;
  } else {
    tmp = _this__u8e3s4.j1w() === ENUM_getInstance();
  }
  return tmp;
}
function _get_tag__e6h4qf($this) {
  var tmp = $this.p3y_1;
  if (!(tmp == null))
    return tmp;
  else {
    throwUninitializedPropertyAccessException('tag');
  }
}
function writeJson$lambda($result) {
  return (it) => {
    $result._v = it;
    return Unit_instance;
  };
}
var WriteMode_OBJ_instance;
var WriteMode_LIST_instance;
var WriteMode_MAP_instance;
var WriteMode_POLY_OBJ_instance;
function values() {
  return [WriteMode_OBJ_getInstance(), WriteMode_LIST_getInstance(), WriteMode_MAP_getInstance(), WriteMode_POLY_OBJ_getInstance()];
}
function get_entries() {
  if ($ENTRIES == null)
    $ENTRIES = enumEntries(values());
  return $ENTRIES;
}
var WriteMode_entriesInitialized;
function WriteMode_initEntries() {
  if (WriteMode_entriesInitialized)
    return Unit_instance;
  WriteMode_entriesInitialized = true;
  WriteMode_OBJ_instance = new WriteMode('OBJ', 0, _Char___init__impl__6a9atx(123), _Char___init__impl__6a9atx(125));
  WriteMode_LIST_instance = new WriteMode('LIST', 1, _Char___init__impl__6a9atx(91), _Char___init__impl__6a9atx(93));
  WriteMode_MAP_instance = new WriteMode('MAP', 2, _Char___init__impl__6a9atx(123), _Char___init__impl__6a9atx(125));
  WriteMode_POLY_OBJ_instance = new WriteMode('POLY_OBJ', 3, _Char___init__impl__6a9atx(91), _Char___init__impl__6a9atx(93));
}
var $ENTRIES;
function switchMode(_this__u8e3s4, desc) {
  var tmp0_subject = desc.j1w();
  var tmp;
  if (tmp0_subject instanceof PolymorphicKind) {
    tmp = WriteMode_POLY_OBJ_getInstance();
  } else {
    if (equals(tmp0_subject, LIST_getInstance())) {
      tmp = WriteMode_LIST_getInstance();
    } else {
      if (equals(tmp0_subject, MAP_getInstance())) {
        // Inline function 'kotlinx.serialization.json.internal.selectMapMode' call
        var keyDescriptor = carrierDescriptor(desc.q1w(0), _this__u8e3s4.u1y());
        var keyKind = keyDescriptor.j1w();
        var tmp_0;
        var tmp_1;
        if (keyKind instanceof PrimitiveKind) {
          tmp_1 = true;
        } else {
          tmp_1 = equals(keyKind, ENUM_getInstance());
        }
        if (tmp_1) {
          tmp_0 = WriteMode_MAP_getInstance();
        } else {
          if (_this__u8e3s4.k3m_1.b3o_1) {
            tmp_0 = WriteMode_LIST_getInstance();
          } else {
            throw InvalidKeyKindException(keyDescriptor);
          }
        }
        tmp = tmp_0;
      } else {
        tmp = WriteMode_OBJ_getInstance();
      }
    }
  }
  return tmp;
}
function carrierDescriptor(_this__u8e3s4, module_0) {
  var tmp;
  if (equals(_this__u8e3s4.j1w(), CONTEXTUAL_getInstance())) {
    var tmp0_safe_receiver = getContextualDescriptor(module_0, _this__u8e3s4);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : carrierDescriptor(tmp0_safe_receiver, module_0);
    tmp = tmp1_elvis_lhs == null ? _this__u8e3s4 : tmp1_elvis_lhs;
  } else if (_this__u8e3s4.k1w()) {
    tmp = carrierDescriptor(_this__u8e3s4.q1w(0), module_0);
  } else {
    tmp = _this__u8e3s4;
  }
  return tmp;
}
function WriteMode_OBJ_getInstance() {
  WriteMode_initEntries();
  return WriteMode_OBJ_instance;
}
function WriteMode_LIST_getInstance() {
  WriteMode_initEntries();
  return WriteMode_LIST_instance;
}
function WriteMode_MAP_getInstance() {
  WriteMode_initEntries();
  return WriteMode_MAP_instance;
}
function WriteMode_POLY_OBJ_getInstance() {
  WriteMode_initEntries();
  return WriteMode_POLY_OBJ_instance;
}
function appendEscape($this, lastPosition, current) {
  $this.f3z(lastPosition, current);
  return appendEsc($this, current + 1 | 0);
}
function decodedString($this, lastPosition, currentPosition) {
  $this.f3z(lastPosition, currentPosition);
  var result = $this.d3n_1.toString();
  $this.d3n_1.ih(0);
  return result;
}
function takePeeked($this) {
  // Inline function 'kotlin.also' call
  var this_0 = ensureNotNull($this.c3n_1);
  $this.c3n_1 = null;
  return this_0;
}
function wasUnquotedString($this) {
  return !(charSequenceGet($this.g3z(), $this.a3n_1 - 1 | 0) === _Char___init__impl__6a9atx(34));
}
function appendEsc($this, startPosition) {
  var currentPosition = startPosition;
  currentPosition = $this.h3z(currentPosition);
  if (currentPosition === -1) {
    $this.v3r('Expected escape sequence to continue, got EOF');
  }
  var tmp = $this.g3z();
  var _unary__edvuaz = currentPosition;
  currentPosition = _unary__edvuaz + 1 | 0;
  var currentChar = charSequenceGet(tmp, _unary__edvuaz);
  if (currentChar === _Char___init__impl__6a9atx(117)) {
    return appendHex($this, $this.g3z(), currentPosition);
  }
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(currentChar);
  var c = escapeToChar(tmp$ret$0);
  if (c === _Char___init__impl__6a9atx(0)) {
    $this.v3r("Invalid escaped char '" + toString_1(currentChar) + "'");
  }
  $this.d3n_1.ub(c);
  return currentPosition;
}
function appendHex($this, source, startPos) {
  if ((startPos + 4 | 0) >= charSequenceLength(source)) {
    $this.a3n_1 = startPos;
    $this.i3z();
    if (($this.a3n_1 + 4 | 0) >= charSequenceLength(source)) {
      $this.v3r('Unexpected EOF during unicode escape');
    }
    return appendHex($this, source, $this.a3n_1);
  }
  $this.d3n_1.ub(numberToChar((((fromHexChar($this, source, startPos) << 12) + (fromHexChar($this, source, startPos + 1 | 0) << 8) | 0) + (fromHexChar($this, source, startPos + 2 | 0) << 4) | 0) + fromHexChar($this, source, startPos + 3 | 0) | 0));
  return startPos + 4 | 0;
}
function fromHexChar($this, source, currentPosition) {
  var character = charSequenceGet(source, currentPosition);
  var tmp;
  if (_Char___init__impl__6a9atx(48) <= character ? character <= _Char___init__impl__6a9atx(57) : false) {
    // Inline function 'kotlin.code' call
    var tmp_0 = Char__toInt_impl_vasixd(character);
    // Inline function 'kotlin.code' call
    var this_0 = _Char___init__impl__6a9atx(48);
    tmp = tmp_0 - Char__toInt_impl_vasixd(this_0) | 0;
  } else if (_Char___init__impl__6a9atx(97) <= character ? character <= _Char___init__impl__6a9atx(102) : false) {
    // Inline function 'kotlin.code' call
    var tmp_1 = Char__toInt_impl_vasixd(character);
    // Inline function 'kotlin.code' call
    var this_1 = _Char___init__impl__6a9atx(97);
    tmp = (tmp_1 - Char__toInt_impl_vasixd(this_1) | 0) + 10 | 0;
  } else if (_Char___init__impl__6a9atx(65) <= character ? character <= _Char___init__impl__6a9atx(70) : false) {
    // Inline function 'kotlin.code' call
    var tmp_2 = Char__toInt_impl_vasixd(character);
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(65);
    tmp = (tmp_2 - Char__toInt_impl_vasixd(this_2) | 0) + 10 | 0;
  } else {
    $this.v3r("Invalid toHexChar char '" + toString_1(character) + "' in unicode escape");
  }
  return tmp;
}
function consumeBoolean2($this, start) {
  var current = $this.h3z(start);
  if (current >= charSequenceLength($this.g3z()) || current === -1) {
    $this.v3r('EOF');
  }
  var tmp = $this.g3z();
  var _unary__edvuaz = current;
  current = _unary__edvuaz + 1 | 0;
  // Inline function 'kotlin.code' call
  var this_0 = charSequenceGet(tmp, _unary__edvuaz);
  var tmp0_subject = Char__toInt_impl_vasixd(this_0) | 32;
  var tmp_0;
  // Inline function 'kotlin.code' call
  var this_1 = _Char___init__impl__6a9atx(116);
  if (tmp0_subject === Char__toInt_impl_vasixd(this_1)) {
    consumeBooleanLiteral($this, 'rue', current);
    tmp_0 = true;
  } else {
    // Inline function 'kotlin.code' call
    var this_2 = _Char___init__impl__6a9atx(102);
    if (tmp0_subject === Char__toInt_impl_vasixd(this_2)) {
      consumeBooleanLiteral($this, 'alse', current);
      tmp_0 = false;
    } else {
      $this.v3r("Expected valid boolean literal prefix, but had '" + $this.m3t() + "'");
    }
  }
  return tmp_0;
}
function consumeBooleanLiteral($this, literalSuffix, current) {
  if ((charSequenceLength($this.g3z()) - current | 0) < literalSuffix.length) {
    $this.v3r('Unexpected end of boolean literal');
  }
  var inductionVariable = 0;
  var last = charSequenceLength(literalSuffix) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var expected = charSequenceGet(literalSuffix, i);
      var actual = charSequenceGet($this.g3z(), current + i | 0);
      // Inline function 'kotlin.code' call
      var tmp = Char__toInt_impl_vasixd(expected);
      // Inline function 'kotlin.code' call
      if (!(tmp === (Char__toInt_impl_vasixd(actual) | 32))) {
        $this.v3r("Expected valid boolean literal prefix, but had '" + $this.m3t() + "'");
      }
    }
     while (inductionVariable <= last);
  $this.a3n_1 = current + literalSuffix.length | 0;
}
function consumeNumericLiteral$calculateExponent(exponentAccumulator, isExponentPositive) {
  var tmp;
  switch (isExponentPositive) {
    case false:
      // Inline function 'kotlin.math.pow' call

      var x = -exponentAccumulator.m4();
      tmp = Math.pow(10.0, x);
      break;
    case true:
      // Inline function 'kotlin.math.pow' call

      var x_0 = exponentAccumulator.m4();
      tmp = Math.pow(10.0, x_0);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function charToTokenClass(c) {
  var tmp;
  // Inline function 'kotlin.code' call
  if (Char__toInt_impl_vasixd(c) < 126) {
    var tmp_0 = CharMappings_getInstance().o3z_1;
    // Inline function 'kotlin.code' call
    tmp = tmp_0[Char__toInt_impl_vasixd(c)];
  } else {
    tmp = 0;
  }
  return tmp;
}
function tokenDescription(token) {
  return token === 1 ? "quotation mark '\"'" : token === 2 ? "string escape sequence '\\'" : token === 4 ? "comma ','" : token === 5 ? "colon ':'" : token === 6 ? "start of the object '{'" : token === 7 ? "end of the object '}'" : token === 8 ? "start of the array '['" : token === 9 ? "end of the array ']'" : token === 10 ? 'end of the input' : token === 127 ? 'invalid token' : 'valid token';
}
function escapeToChar(c) {
  return c < 117 ? CharMappings_getInstance().n3z_1[c] : _Char___init__impl__6a9atx(0);
}
function initEscape($this) {
  var inductionVariable = 0;
  if (inductionVariable <= 31)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      initC2ESC($this, i, _Char___init__impl__6a9atx(117));
    }
     while (inductionVariable <= 31);
  initC2ESC($this, 8, _Char___init__impl__6a9atx(98));
  initC2ESC($this, 9, _Char___init__impl__6a9atx(116));
  initC2ESC($this, 10, _Char___init__impl__6a9atx(110));
  initC2ESC($this, 12, _Char___init__impl__6a9atx(102));
  initC2ESC($this, 13, _Char___init__impl__6a9atx(114));
  initC2ESC_0($this, _Char___init__impl__6a9atx(47), _Char___init__impl__6a9atx(47));
  initC2ESC_0($this, _Char___init__impl__6a9atx(34), _Char___init__impl__6a9atx(34));
  initC2ESC_0($this, _Char___init__impl__6a9atx(92), _Char___init__impl__6a9atx(92));
}
function initCharToToken($this) {
  var inductionVariable = 0;
  if (inductionVariable <= 32)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      initC2TC($this, i, 127);
    }
     while (inductionVariable <= 32);
  initC2TC($this, 9, 3);
  initC2TC($this, 10, 3);
  initC2TC($this, 13, 3);
  initC2TC($this, 32, 3);
  initC2TC_0($this, _Char___init__impl__6a9atx(44), 4);
  initC2TC_0($this, _Char___init__impl__6a9atx(58), 5);
  initC2TC_0($this, _Char___init__impl__6a9atx(123), 6);
  initC2TC_0($this, _Char___init__impl__6a9atx(125), 7);
  initC2TC_0($this, _Char___init__impl__6a9atx(91), 8);
  initC2TC_0($this, _Char___init__impl__6a9atx(93), 9);
  initC2TC_0($this, _Char___init__impl__6a9atx(34), 1);
  initC2TC_0($this, _Char___init__impl__6a9atx(92), 2);
}
function initC2ESC($this, c, esc) {
  if (!(esc === _Char___init__impl__6a9atx(117))) {
    // Inline function 'kotlin.code' call
    var tmp$ret$0 = Char__toInt_impl_vasixd(esc);
    $this.n3z_1[tmp$ret$0] = numberToChar(c);
  }
}
function initC2ESC_0($this, c, esc) {
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(c);
  return initC2ESC($this, tmp$ret$0, esc);
}
function initC2TC($this, c, cl) {
  $this.o3z_1[c] = cl;
}
function initC2TC_0($this, c, cl) {
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(c);
  return initC2TC($this, tmp$ret$0, cl);
}
var CharMappings_instance;
function CharMappings_getInstance() {
  if (CharMappings_instance === VOID)
    new CharMappings();
  return CharMappings_instance;
}
function StringJsonLexer_0(json, source) {
  return !json.k3m_1.n3o_1 ? new StringJsonLexer(source) : new StringJsonLexerWithComments(source);
}
function get_schemaCache(_this__u8e3s4) {
  return _this__u8e3s4.m3m_1;
}
function createMapForCache(initialCapacity) {
  return HashMap.z8(initialCapacity);
}
//region block: post-declaration
initMetadataForClass(Json, 'Json');
initMetadataForObject(Default, 'Default');
initMetadataForClass(JsonBuilder, 'JsonBuilder');
initMetadataForClass(JsonImpl, 'JsonImpl');
initMetadataForClass(JsonClassDiscriminator, 'JsonClassDiscriminator');
initMetadataForClass(JsonIgnoreUnknownKeys, 'JsonIgnoreUnknownKeys');
initMetadataForClass(JsonNames, 'JsonNames');
initMetadataForClass(JsonConfiguration, 'JsonConfiguration');
initMetadataForClass(ClassDiscriminatorMode, 'ClassDiscriminatorMode');
initMetadataForInterface(JsonDecoder, 'JsonDecoder', VOID, VOID, [Decoder, CompositeDecoder]);
initMetadataForCompanion(Companion);
initMetadataForClass(JsonElement, 'JsonElement', VOID, VOID, VOID, VOID, VOID, {0: JsonElementSerializer_getInstance});
initMetadataForClass(JsonObject, 'JsonObject', VOID, VOID, [JsonElement, KtMap], VOID, VOID, {0: JsonObjectSerializer_getInstance});
initMetadataForCompanion(Companion_0);
initMetadataForCompanion(Companion_1);
initMetadataForClass(JsonArray, 'JsonArray', VOID, VOID, [JsonElement, KtList], VOID, VOID, {0: JsonArraySerializer_getInstance});
initMetadataForClass(JsonPrimitive, 'JsonPrimitive', VOID, VOID, VOID, VOID, VOID, {0: JsonPrimitiveSerializer_getInstance});
initMetadataForObject(JsonNull, 'JsonNull', VOID, VOID, [JsonPrimitive, SerializerFactory], VOID, VOID, {0: JsonNullSerializer_getInstance});
initMetadataForCompanion(Companion_2);
initMetadataForClass(JsonLiteral, 'JsonLiteral');
initMetadataForClass(JsonArrayBuilder, 'JsonArrayBuilder');
initMetadataForClass(JsonObjectBuilder, 'JsonObjectBuilder');
initMetadataForObject(JsonElementSerializer, 'JsonElementSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonObjectDescriptor, 'JsonObjectDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForObject(JsonObjectSerializer, 'JsonObjectSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonArrayDescriptor, 'JsonArrayDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForObject(JsonArraySerializer, 'JsonArraySerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonNullSerializer, 'JsonNullSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonPrimitiveSerializer, 'JsonPrimitiveSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(JsonLiteralSerializer, 'JsonLiteralSerializer', VOID, VOID, [KSerializer]);
protoOf(defer$1).f1w = get_isNullable;
protoOf(defer$1).k1w = get_isInline;
protoOf(defer$1).m1w = get_annotations;
initMetadataForClass(defer$1, VOID, VOID, VOID, [SerialDescriptor]);
initMetadataForInterface(JsonEncoder, 'JsonEncoder', VOID, VOID, [Encoder, CompositeEncoder]);
initMetadataForClass(Composer, 'Composer');
initMetadataForClass(ComposerForUnsignedNumbers, 'ComposerForUnsignedNumbers');
initMetadataForClass(ComposerForUnquotedLiterals, 'ComposerForUnquotedLiterals');
initMetadataForClass(ComposerWithPrettyPrint, 'ComposerWithPrettyPrint');
initMetadataForClass(JsonElementMarker, 'JsonElementMarker');
initMetadataForClass(JsonException, 'JsonException');
initMetadataForClass(JsonDecodingException, 'JsonDecodingException');
initMetadataForClass(JsonEncodingException, 'JsonEncodingException');
initMetadataForObject(Tombstone, 'Tombstone');
initMetadataForClass(JsonPath, 'JsonPath', JsonPath);
protoOf(JsonSerializersModuleValidator).r2f = contextual;
initMetadataForClass(JsonSerializersModuleValidator, 'JsonSerializersModuleValidator', VOID, VOID, [SerializersModuleCollector]);
initMetadataForLambda(JsonTreeReader$readDeepRecursive$slambda, VOID, VOID, [2]);
initMetadataForClass(JsonTreeReader, 'JsonTreeReader', VOID, VOID, VOID, [0]);
initMetadataForClass(Key, 'Key', Key);
initMetadataForClass(DescriptorSchemaCache, 'DescriptorSchemaCache', DescriptorSchemaCache);
initMetadataForClass(DiscriminatorHolder, 'DiscriminatorHolder');
initMetadataForClass(StreamingJsonDecoder, 'StreamingJsonDecoder', VOID, VOID, [JsonDecoder, AbstractDecoder]);
initMetadataForClass(JsonDecoderForUnsignedTypes, 'JsonDecoderForUnsignedTypes');
initMetadataForClass(StreamingJsonEncoder, 'StreamingJsonEncoder', VOID, VOID, [JsonEncoder, AbstractEncoder]);
initMetadataForClass(AbstractJsonTreeDecoder, 'AbstractJsonTreeDecoder', VOID, VOID, [NamedValueDecoder, JsonDecoder]);
initMetadataForClass(JsonTreeDecoder, 'JsonTreeDecoder');
initMetadataForClass(JsonTreeListDecoder, 'JsonTreeListDecoder');
initMetadataForClass(JsonPrimitiveDecoder, 'JsonPrimitiveDecoder');
initMetadataForClass(JsonTreeMapDecoder, 'JsonTreeMapDecoder');
initMetadataForClass(AbstractJsonTreeEncoder, 'AbstractJsonTreeEncoder', VOID, VOID, [NamedValueEncoder, JsonEncoder]);
initMetadataForClass(JsonTreeEncoder, 'JsonTreeEncoder');
initMetadataForClass(AbstractJsonTreeEncoder$inlineUnsignedNumberEncoder$1);
initMetadataForClass(AbstractJsonTreeEncoder$inlineUnquotedLiteralEncoder$1);
initMetadataForClass(JsonPrimitiveEncoder, 'JsonPrimitiveEncoder');
initMetadataForClass(JsonTreeListEncoder, 'JsonTreeListEncoder');
initMetadataForClass(JsonTreeMapEncoder, 'JsonTreeMapEncoder');
initMetadataForClass(WriteMode, 'WriteMode');
initMetadataForClass(AbstractJsonLexer, 'AbstractJsonLexer');
initMetadataForObject(CharMappings, 'CharMappings');
initMetadataForClass(StringJsonLexer, 'StringJsonLexer');
initMetadataForClass(StringJsonLexerWithComments, 'StringJsonLexerWithComments');
initMetadataForClass(JsonToStringWriter, 'JsonToStringWriter', JsonToStringWriter);
//endregion
//region block: init
Companion_instance = new Companion();
Companion_instance_0 = new Companion_0();
Companion_instance_1 = new Companion_1();
Companion_instance_2 = new Companion_2();
Tombstone_instance = new Tombstone();
//endregion
//region block: exports
export {
  Companion_instance_0 as Companion_instance20spzcd6u6icp,
  JsonElementSerializer_getInstance as JsonElementSerializer_getInstance1rgo1giz8g15y,
  JsonNull_getInstance as JsonNull_getInstance1q6cansbfp6ip,
  Companion_instance as Companion_instance2xnbmyqibbp8t,
  JsonObjectSerializer_getInstance as JsonObjectSerializer_getInstance197qdg6ernwdp,
  JsonArrayBuilder as JsonArrayBuilderu8edol6ui3pj,
  JsonArray as JsonArray2urf8ey7u44sd,
  JsonNull as JsonNull2liwjj96vm0w2,
  JsonObjectBuilder as JsonObjectBuilder2nl6rv6vdayuk,
  JsonObject as JsonObjectee06ihoeeiqj,
  JsonPrimitive_1 as JsonPrimitiveolttw629wj53,
  JsonPrimitive_0 as JsonPrimitive2fp8648nd60dn,
  JsonPrimitive_2 as JsonPrimitive1xkjzc5d7ihuv,
  JsonPrimitive as JsonPrimitive3ttzjh2ft5dnx,
  Json_0 as Jsonsmkyu9xjl7fv,
  get_booleanOrNull as get_booleanOrNull376axlcpdhkmo,
  get_contentOrNull as get_contentOrNull35s97cgi8z9eo,
  get_doubleOrNull as get_doubleOrNull2fo14gjg922um,
  get_intOrNull as get_intOrNulld29i64b3udf,
  get_jsonObject as get_jsonObject2u4z2ch1uuca9,
  get_jsonPrimitive as get_jsonPrimitivez17tyd5rw1ql,
  get_longOrNull as get_longOrNull1kg1ha9scz5pa,
};
//endregion

//# sourceMappingURL=kotlinx-serialization-kotlinx-serialization-json.mjs.map
