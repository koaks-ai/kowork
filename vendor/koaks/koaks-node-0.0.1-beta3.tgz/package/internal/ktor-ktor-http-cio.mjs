import {
  Long2qws0ah9gnpki as Long,
  VOID7hggqo3abtya as VOID,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  Unit_instance104q5opgivhr8 as Unit_instance,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  SequenceScope1coiso86pqzq2 as SequenceScope,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  ArrayList3it5z8td81qkl as ArrayList,
  sequence2vgswtrxvqoa7 as sequence,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString,
  abs1kdzbjes1idip as abs,
  StringBuildermazzzhj6kkai as StringBuilder,
  fill2542d4m9l93pn as fill,
  protoOf180f3jzyo7rfj as protoOf,
  isIntArrayeijsubfngq38 as isIntArray,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  endsWith1a79dp5rc3sfv as endsWith,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  Char19o2r8palgjof as Char,
  Char__compareTo_impl_ypi4mb3fw4vcbfqkuba as Char__compareTo_impl_ypi4mb,
  contains2el4s70rdq4ld as contains,
  charSequenceSubSequence1iwpdba8s3jc7 as charSequenceSubSequence,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  captureStack1fzi4aczwc4hg as captureStack,
  setOf45ia9pnfhe90 as setOf,
  listOf1jh22dvmctj1r as listOf,
  toString1h6jjoch8cjt8 as toString_0,
  toByte4i43936u611k as toByte,
  copyOfRange3alro60z4hhf8 as copyOfRange,
  startsWith641pyr7vf687 as startsWith,
  toLongw1zpgk99d84b as toLong,
  CancellationException3b36o9qz53rgr as CancellationException,
  isInterface3d6p8outrmvmk as isInterface,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  compareTo3ankvs086tmwq as compareTo,
  NoSuchElementException679xzhnp5bpj as NoSuchElementException,
  Collection1k04j3hzsbod0 as Collection,
  emptyList1g2z5xcrvp2zy as emptyList,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  CharSequence1ceii1xorfwh7 as CharSequence,
  IndexOutOfBoundsException1qfr429iumro0 as IndexOutOfBoundsException,
  charArray2ujmm1qusno00 as charArray,
  NumberFormatException3bgsm2s9o4t55 as NumberFormatException,
  toString35i91qxh73cps as toString_1,
  numberRangeToNumber25vse2rgp6rs8 as numberRangeToNumber,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  numberToLong1a4cndvg6c52s as numberToLong,
  toLongArray23ixicpzp5r3w as toLongArray,
  Char__plus_impl_qi7pgj1zq2c0uiotg93 as Char__plus_impl_qi7pgj,
  Char__minus_impl_a2frrhe8uo2lu35qi1 as Char__minus_impl_a2frrh,
  toByteArray3caw0hip00os as toByteArray,
  isWhitespace25occ8z1ed1s9 as isWhitespace,
} from './kotlin-kotlin-stdlib.mjs';
import {
  MultiPartData57syw40llxls as MultiPartData,
  HttpHeaders_getInstancekqele34vb34f as HttpHeaders_getInstance,
  MultiPart_getInstance2x0sgwr24mfqp as MultiPart_getInstance,
  Companion_getInstancepumzx9q4106p as Companion_getInstance,
} from './ktor-ktor-http.mjs';
import {
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
  produce1iljho2c8bp6o as produce,
  CompletableDeferred2lnqvsbvx74d3 as CompletableDeferred,
  ProducerScopeb3mmhvfa6ll7 as ProducerScope,
} from './kotlinx-coroutines-core.mjs';
import {
  DefaultPool2gb1fm4epwgu9 as DefaultPool,
  readUTF8LineTo2rqyj2iri7j7e as readUTF8LineTo,
  Companion_getInstance2golwmcx6d471 as Companion_getInstance_0,
  LineEndingMode__plus_impl_ttpz2j1fo728zjvbdzc as LineEndingMode__plus_impl_ttpz2j,
  readUntilqaod88ylrtua as readUntil,
  copyTo2bqjr21is71ky as copyTo,
  skipIfFound2s927ggnjlzu8 as skipIfFound,
  counted3iniv3aql3f9n as counted,
  writer1eia5its2a1fh as writer,
  readRemaining33cdmbznvdvtg as readRemaining,
  get_remaining1lapv95kcmm0y as get_remaining,
  ByteChannel3cxdguezl3lu7 as ByteChannel,
  close3semq7pafb42g as close,
  readPacket12c3kakna35tv as readPacket,
  WriterScope3b0bo1enaee6b as WriterScope,
  toByteArray1i3ns5jnoqlv6 as toByteArray_0,
  NoPoolImplgos9n8jphzjp as NoPoolImpl,
} from './ktor-ktor-io.mjs';
import {
  ByteString10sanmoo66key as ByteString,
  ByteString3c9fk8lsh3lvs as ByteString_0,
} from './kotlinx-io-kotlinx-io-bytestring.mjs';
import {
  IOException1wyutdmfe71nu as IOException,
  EOFExceptionh831u25jcq9n as EOFException,
} from './kotlinx-io-kotlinx-io-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class CIOMultipartDataBase {
  constructor(coroutineContext, channel, contentType, contentLength, formFieldLimit) {
    formFieldLimit = formFieldLimit === VOID ? new Long(65536, 0) : formFieldLimit;
    this.u2z_1 = coroutineContext;
    this.v2z_1 = null;
    this.w2z_1 = parseMultipart(this, channel, contentType, contentLength, formFieldLimit);
  }
  ku() {
    return this.u2z_1;
  }
}
class HeadersData$headersStarts$slambda {
  constructor(this$0) {
    this.y2z_1 = this$0;
  }
  a30($this$sequence, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8.bind(VOID, this, $this$sequence), $completion);
  }
  td(p1, $completion) {
    return this.a30(p1 instanceof SequenceScope ? p1 : THROW_CCE(), $completion);
  }
}
class HeadersData {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.x2z_1 = ArrayList.k();
  }
  b30() {
    return this.x2z_1.b1();
  }
  c30(subArraysCount) {
    // Inline function 'kotlin.repeat' call
    var inductionVariable = 0;
    if (inductionVariable < subArraysCount)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.x2z_1.l(get_IntArrayPool().j1t());
      }
       while (inductionVariable < subArraysCount);
  }
  z2z(index) {
    return this.x2z_1.f1(index / 768 | 0)[index % 768 | 0];
  }
  d30(index, value) {
    this.x2z_1.f1(index / 768 | 0)[index % 768 | 0] = value;
  }
  e30() {
    return sequence(HeadersData$headersStarts$slambda_0(this));
  }
  s1i() {
    var _iterator__ex2g4s = this.x2z_1.y();
    while (_iterator__ex2g4s.z()) {
      var array = _iterator__ex2g4s.a1();
      get_IntArrayPool().k1t(array);
    }
    this.x2z_1.b3();
  }
}
class HttpHeadersMap {
  constructor(builder) {
    this.f30_1 = builder;
    this.g30_1 = 0;
    this.h30_1 = 0;
    this.i30_1 = get_HeadersDataPool().j1t();
  }
  l2g(name) {
    if (this.g30_1 === 0)
      return null;
    // Inline function 'kotlin.math.absoluteValue' call
    var this_0 = hashCodeLowerCase(name);
    var hash = abs(this_0);
    var headerIndex = hash % this.h30_1 | 0;
    while (!(this.i30_1.z2z(imul(headerIndex, 6) + 0 | 0) === -1)) {
      if (headerHasName(this, name, imul(headerIndex, 6))) {
        return this.k30(imul(headerIndex, 6));
      }
      headerIndex = (headerIndex + 1 | 0) % this.h30_1 | 0;
    }
    return null;
  }
  l30() {
    return this.i30_1.e30();
  }
  j30(nameStartIndex, nameEndIndex, valueStartIndex, valueEndIndex) {
    if (thresholdReached(this)) {
      resize(this);
    }
    // Inline function 'kotlin.math.absoluteValue' call
    var this_0 = hashCodeLowerCase(this.f30_1, nameStartIndex, nameEndIndex);
    var hash = abs(this_0);
    var name = this.f30_1.c(nameStartIndex, nameEndIndex);
    var headerIndex = hash % this.h30_1 | 0;
    var sameNameHeaderIndex = -1;
    while (!(this.i30_1.z2z(imul(headerIndex, 6) + 0 | 0) === -1)) {
      if (headerHasName(this, name, imul(headerIndex, 6))) {
        sameNameHeaderIndex = headerIndex;
      }
      headerIndex = (headerIndex + 1 | 0) % this.h30_1 | 0;
    }
    var headerOffset = imul(headerIndex, 6);
    this.i30_1.d30(headerOffset + 0 | 0, hash);
    this.i30_1.d30(headerOffset + 1 | 0, nameStartIndex);
    this.i30_1.d30(headerOffset + 2 | 0, nameEndIndex);
    this.i30_1.d30(headerOffset + 3 | 0, valueStartIndex);
    this.i30_1.d30(headerOffset + 4 | 0, valueEndIndex);
    this.i30_1.d30(headerOffset + 5 | 0, -1);
    if (!(sameNameHeaderIndex === -1)) {
      this.i30_1.d30(imul(sameNameHeaderIndex, 6) + 5 | 0, headerIndex);
    }
    this.g30_1 = this.g30_1 + 1 | 0;
  }
  t30(headerOffset) {
    var nameStartIndex = this.i30_1.z2z(headerOffset + 1 | 0);
    var nameEndIndex = this.i30_1.z2z(headerOffset + 2 | 0);
    return this.f30_1.c(nameStartIndex, nameEndIndex);
  }
  k30(headerOffset) {
    var valueStartIndex = this.i30_1.z2z(headerOffset + 3 | 0);
    var valueEndIndex = this.i30_1.z2z(headerOffset + 4 | 0);
    return this.f30_1.c(valueStartIndex, valueEndIndex);
  }
  s1i() {
    this.g30_1 = 0;
    this.h30_1 = 0;
    get_HeadersDataPool().k1t(this.i30_1);
    this.i30_1 = get_HeadersDataPool().j1t();
  }
  toString() {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    dumpTo(this, '', this_0);
    return this_0.toString();
  }
}
class IntArrayPool$1 extends DefaultPool {
  constructor() {
    super(1000);
  }
  c1t() {
    var tmp = 0;
    var tmp_0 = new Int32Array(768);
    while (tmp < 768) {
      tmp_0[tmp] = -1;
      tmp = tmp + 1 | 0;
    }
    return tmp_0;
  }
  x30(instance) {
    fill(instance, -1);
    return protoOf(DefaultPool).h1t.call(this, instance);
  }
  h1t(instance) {
    return this.x30(isIntArray(instance) ? instance : THROW_CCE());
  }
}
class HeadersDataPool$1 extends DefaultPool {
  constructor() {
    super(1000);
  }
  c1t() {
    return new HeadersData();
  }
  b31(instance) {
    instance.s1i();
    return protoOf(DefaultPool).h1t.call(this, instance);
  }
  h1t(instance) {
    return this.b31(instance instanceof HeadersData ? instance : THROW_CCE());
  }
}
class ParserException extends IllegalStateException {
  static i31(message) {
    var $this = this.t4(message);
    captureStack($this, $this.h31_1);
    return $this;
  }
}
class MultipartEvent {}
class Preamble extends MultipartEvent {
  constructor(body) {
    super();
    this.k31_1 = body;
  }
}
class MultipartPart extends MultipartEvent {
  constructor(headers, body) {
    super();
    this.l31_1 = headers;
    this.m31_1 = body;
  }
}
class Epilogue extends MultipartEvent {
  constructor(body) {
    super();
    this.n31_1 = body;
  }
}
class parseMultipart$slambda$slambda {
  constructor($firstBoundary, $countedInput) {
    this.s31_1 = $firstBoundary;
    this.t31_1 = $countedInput;
  }
  y31($this$writer, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_0.bind(VOID, this, $this$writer), $completion);
  }
  td(p1, $completion) {
    return this.y31(p1 instanceof WriterScope ? p1 : THROW_CCE(), $completion);
  }
}
class parseMultipart$slambda {
  constructor($input, $boundaryPrefixed, $maxPartSize, $totalLength) {
    this.u31_1 = $input;
    this.v31_1 = $boundaryPrefixed;
    this.w31_1 = $maxPartSize;
    this.x31_1 = $totalLength;
  }
  z31($this$produce, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_1.bind(VOID, this, $this$produce), $completion);
  }
  td(p1, $completion) {
    return this.z31((!(p1 == null) ? isInterface(p1, ProducerScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class Node {
  constructor(ch, exact, children) {
    this.a32_1 = ch;
    this.b32_1 = exact;
    this.c32_1 = children;
    var tmp = this;
    var tmp_0 = 0;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(256);
    while (tmp_0 < 256) {
      var tmp_2 = tmp_0;
      var tmp1 = this.c32_1;
      var tmp$ret$3;
      $l$block_0: {
        // Inline function 'kotlin.collections.singleOrNull' call
        var single = null;
        var found = false;
        var _iterator__ex2g4s = tmp1.y();
        while (_iterator__ex2g4s.z()) {
          var element = _iterator__ex2g4s.a1();
          // Inline function 'kotlin.code' call
          var this_0 = element.a32_1;
          if (Char__toInt_impl_vasixd(this_0) === tmp_2) {
            if (found) {
              tmp$ret$3 = null;
              break $l$block_0;
            }
            single = element;
            found = true;
          }
        }
        if (!found) {
          tmp$ret$3 = null;
          break $l$block_0;
        }
        tmp$ret$3 = single;
      }
      tmp_1[tmp_2] = tmp$ret$3;
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.d32_1 = tmp_1;
  }
}
class Companion {
  j31(from) {
    var tmp = AsciiCharTree$Companion$build$lambda;
    return this.e32(from, tmp, AsciiCharTree$Companion$build$lambda_0);
  }
  e32(from, length, charAt) {
    var tmp$ret$0;
    $l$block_0: {
      // Inline function 'kotlin.collections.maxByOrNull' call
      var iterator = from.y();
      if (!iterator.z()) {
        tmp$ret$0 = null;
        break $l$block_0;
      }
      var maxElem = iterator.a1();
      if (!iterator.z()) {
        tmp$ret$0 = maxElem;
        break $l$block_0;
      }
      var maxValue = length(maxElem);
      do {
        var e = iterator.a1();
        var v = length(e);
        if (compareTo(maxValue, v) < 0) {
          maxElem = e;
          maxValue = v;
        }
      }
       while (iterator.z());
      tmp$ret$0 = maxElem;
    }
    var tmp0_safe_receiver = tmp$ret$0;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = length(tmp0_safe_receiver);
    }
    var tmp1_elvis_lhs = tmp;
    var tmp_0;
    if (tmp1_elvis_lhs == null) {
      throw NoSuchElementException.p('Unable to build char tree from an empty list');
    } else {
      tmp_0 = tmp1_elvis_lhs;
    }
    var maxLen = tmp_0;
    var tmp$ret$2;
    $l$block_2: {
      // Inline function 'kotlin.collections.any' call
      var tmp_1;
      if (isInterface(from, Collection)) {
        tmp_1 = from.h1();
      } else {
        tmp_1 = false;
      }
      if (tmp_1) {
        tmp$ret$2 = false;
        break $l$block_2;
      }
      var _iterator__ex2g4s = from.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (length(element) === 0) {
          tmp$ret$2 = true;
          break $l$block_2;
        }
      }
      tmp$ret$2 = false;
    }
    if (tmp$ret$2)
      throw IllegalArgumentException.t('There should be no empty entries');
    var root = ArrayList.k();
    build(this, root, from, maxLen, 0, length, charAt);
    root.x7();
    return new AsciiCharTree(new Node(_Char___init__impl__6a9atx(0), emptyList(), root));
  }
}
class AsciiCharTree {
  constructor(root) {
    this.f32_1 = root;
  }
}
class SubSequenceImpl {
  constructor($outer, start, end) {
    this.j32_1 = $outer;
    this.g32_1 = start;
    this.h32_1 = end;
    this.i32_1 = null;
  }
  a() {
    return this.h32_1 - this.g32_1 | 0;
  }
  b(index) {
    var withOffset = index + this.g32_1 | 0;
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'index is negative: ' + index;
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(withOffset < this.h32_1)) {
      var message_0 = 'index (' + index + ') should be less than length (' + this.a() + ')';
      throw IllegalArgumentException.t(toString(message_0));
    }
    return getImpl(this.j32_1, withOffset);
  }
  c(startIndex, endIndex) {
    // Inline function 'kotlin.require' call
    if (!(startIndex >= 0)) {
      var message = 'start is negative: ' + startIndex;
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(startIndex <= endIndex)) {
      var message_0 = 'start (' + startIndex + ') should be less or equal to end (' + endIndex + ')';
      throw IllegalArgumentException.t(toString(message_0));
    }
    // Inline function 'kotlin.require' call
    if (!(endIndex <= (this.h32_1 - this.g32_1 | 0))) {
      var message_1 = 'end should be less than length (' + this.a() + ')';
      throw IllegalArgumentException.t(toString(message_1));
    }
    if (startIndex === endIndex)
      return '';
    return new SubSequenceImpl(this.j32_1, this.g32_1 + startIndex | 0, this.g32_1 + endIndex | 0);
  }
  toString() {
    var tmp0_elvis_lhs = this.i32_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_0 = toString(copy(this.j32_1, this.g32_1, this.h32_1));
      this.i32_1 = this_0;
      tmp = this_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  equals(other) {
    if (!(!(other == null) ? isCharSequence(other) : false))
      return false;
    if (!(charSequenceLength(other) === this.a()))
      return false;
    return rangeEqualsImpl(this.j32_1, this.g32_1, other, 0, this.a());
  }
  hashCode() {
    var tmp0_safe_receiver = this.i32_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : getStringHashCode(tmp0_safe_receiver);
    return tmp1_elvis_lhs == null ? hashCodeImpl(this.j32_1, this.g32_1, this.h32_1) : tmp1_elvis_lhs;
  }
}
class CharArrayBuilder {
  constructor(pool) {
    pool = pool === VOID ? get_CharArrayPool() : pool;
    this.m30_1 = pool;
    this.n30_1 = null;
    this.o30_1 = null;
    this.p30_1 = null;
    this.q30_1 = false;
    this.r30_1 = 0;
    this.s30_1 = 0;
  }
  a() {
    return this.s30_1;
  }
  b(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'index is negative: ' + index;
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(index < this.s30_1)) {
      var message_0 = 'index ' + index + ' is not in range [0, ' + this.s30_1 + ')';
      throw IllegalArgumentException.t(toString(message_0));
    }
    return getImpl(this, index);
  }
  c(startIndex, endIndex) {
    // Inline function 'kotlin.require' call
    if (!(startIndex <= endIndex)) {
      var message = 'startIndex (' + startIndex + ') should be less or equal to endIndex (' + endIndex + ')';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(startIndex >= 0)) {
      var message_0 = 'startIndex is negative: ' + startIndex;
      throw IllegalArgumentException.t(toString(message_0));
    }
    // Inline function 'kotlin.require' call
    if (!(endIndex <= this.s30_1)) {
      var message_1 = 'endIndex (' + endIndex + ') is greater than length (' + this.s30_1 + ')';
      throw IllegalArgumentException.t(toString(message_1));
    }
    return new SubSequenceImpl(this, startIndex, endIndex);
  }
  toString() {
    var tmp0_elvis_lhs = this.p30_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_0 = toString(copy(this, 0, this.s30_1));
      this.p30_1 = this_0;
      tmp = this_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  equals(other) {
    if (!(!(other == null) ? isCharSequence(other) : false))
      return false;
    if (!(this.s30_1 === charSequenceLength(other)))
      return false;
    return rangeEqualsImpl(this, 0, other, 0, this.s30_1);
  }
  hashCode() {
    var tmp0_safe_receiver = this.p30_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : getStringHashCode(tmp0_safe_receiver);
    return tmp1_elvis_lhs == null ? hashCodeImpl(this, 0, this.s30_1) : tmp1_elvis_lhs;
  }
  ub(value) {
    nonFullBuffer(this)[ensureNotNull(this.o30_1).length - this.r30_1 | 0] = value;
    this.p30_1 = null;
    this.r30_1 = this.r30_1 - 1 | 0;
    this.s30_1 = this.s30_1 + 1 | 0;
    return this;
  }
  ch(value, startIndex, endIndex) {
    if (value == null)
      return this;
    var current = startIndex;
    while (current < endIndex) {
      var buffer = nonFullBuffer(this);
      var offset = buffer.length - this.r30_1 | 0;
      var tmp0 = endIndex - current | 0;
      // Inline function 'kotlin.math.min' call
      var b = this.r30_1;
      var bytesToCopy = Math.min(tmp0, b);
      var inductionVariable = 0;
      if (inductionVariable < bytesToCopy)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          buffer[offset + i | 0] = charSequenceGet(value, current + i | 0);
        }
         while (inductionVariable < bytesToCopy);
      current = current + bytesToCopy | 0;
      this.r30_1 = this.r30_1 - bytesToCopy | 0;
    }
    this.p30_1 = null;
    this.s30_1 = this.s30_1 + (endIndex - startIndex | 0) | 0;
    return this;
  }
  w(value) {
    if (value == null)
      return this;
    return this.ch(value, 0, charSequenceLength(value));
  }
  s1i() {
    var list = this.n30_1;
    if (!(list == null)) {
      this.o30_1 = null;
      var inductionVariable = 0;
      var last = list.b1();
      if (inductionVariable < last)
        do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          this.m30_1.k1t(list.f1(i));
        }
         while (inductionVariable < last);
    } else {
      var tmp0_safe_receiver = this.o30_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        this.m30_1.k1t(tmp0_safe_receiver);
      }
      this.o30_1 = null;
    }
    this.q30_1 = true;
    this.n30_1 = null;
    this.p30_1 = null;
    this.s30_1 = 0;
    this.r30_1 = 0;
  }
}
class CharArrayPool$1 extends NoPoolImpl {
  j1t() {
    return charArray(2048);
  }
}
class CharArrayPool$2 extends DefaultPool {
  constructor() {
    super(4096);
  }
  c1t() {
    return charArray(2048);
  }
}
class UnsupportedMediaTypeExceptionCIO extends IOException {
  static r31(message) {
    var $this = this.y1o(message);
    captureStack($this, $this.q31_1);
    return $this;
  }
}
class MutableRange {
  constructor(start, end) {
    this.c31_1 = start;
    this.d31_1 = end;
  }
  toString() {
    return 'MutableRange(start=' + this.c31_1 + ', end=' + this.d31_1 + ')';
  }
}
//endregion
function get_IntArrayPool() {
  _init_properties_HttpHeadersMap_kt__hwatby();
  return IntArrayPool;
}
var IntArrayPool;
function get_HeadersDataPool() {
  _init_properties_HttpHeadersMap_kt__hwatby();
  return HeadersDataPool;
}
var HeadersDataPool;
function *_generator_invoke__zhh2q8($this, $this$sequence, $completion) {
  var joinedIndex = 0;
  var _iterator__ex2g4s = $this.y2z_1.x2z_1.y();
  while (_iterator__ex2g4s.z()) {
    var arr = _iterator__ex2g4s.a1();
    var localIndex = 0;
    while (localIndex < arr.length) {
      if (!($this.y2z_1.z2z(joinedIndex + 0 | 0) === -1)) {
        var tmp = $this$sequence.km(joinedIndex, $completion);
        if (tmp === get_COROUTINE_SUSPENDED())
          tmp = yield tmp;
      }
      localIndex = localIndex + 6 | 0;
      joinedIndex = joinedIndex + 6 | 0;
    }
  }
  return Unit_instance;
}
function HeadersData$headersStarts$slambda_0(this$0) {
  var i = new HeadersData$headersStarts$slambda(this$0);
  var l = ($this$sequence, $completion) => i.a30($this$sequence, $completion);
  l.$arity = 1;
  return l;
}
function thresholdReached($this) {
  return $this.g30_1 >= $this.h30_1 * 0.75;
}
function resize($this) {
  var prevSize = $this.g30_1;
  var prevData = $this.i30_1;
  $this.g30_1 = 0;
  $this.h30_1 = imul($this.h30_1, 2) | 128;
  var tmp = $this;
  // Inline function 'kotlin.apply' call
  var this_0 = get_HeadersDataPool().j1t();
  this_0.c30(imul(prevData.b30(), 2) | 1);
  tmp.i30_1 = this_0;
  var _iterator__ex2g4s = prevData.e30().y();
  while (_iterator__ex2g4s.z()) {
    var headerOffset = _iterator__ex2g4s.a1();
    $this.j30(prevData.z2z(headerOffset + 1 | 0), prevData.z2z(headerOffset + 2 | 0), prevData.z2z(headerOffset + 3 | 0), prevData.z2z(headerOffset + 4 | 0));
  }
  get_HeadersDataPool().k1t(prevData);
  // Inline function 'kotlin.require' call
  // Inline function 'kotlin.require' call
  if (!(prevSize === $this.g30_1)) {
    var message = 'Failed requirement.';
    throw IllegalArgumentException.t(toString(message));
  }
}
function headerHasName($this, name, headerOffset) {
  var nameStartIndex = $this.i30_1.z2z(headerOffset + 1 | 0);
  var nameEndIndex = $this.i30_1.z2z(headerOffset + 2 | 0);
  return equalsLowerCase($this.f30_1, nameStartIndex, nameEndIndex, name);
}
function dumpTo(_this__u8e3s4, indent, out) {
  _init_properties_HttpHeadersMap_kt__hwatby();
  var _iterator__ex2g4s = _this__u8e3s4.l30().y();
  while (_iterator__ex2g4s.z()) {
    var offset = _iterator__ex2g4s.a1();
    out.w(indent);
    out.w(_this__u8e3s4.t30(offset));
    out.w(' => ');
    out.w(_this__u8e3s4.k30(offset));
    out.w('\n');
  }
}
var properties_initialized_HttpHeadersMap_kt_kotj4w;
function _init_properties_HttpHeadersMap_kt__hwatby() {
  if (!properties_initialized_HttpHeadersMap_kt_kotj4w) {
    properties_initialized_HttpHeadersMap_kt_kotj4w = true;
    IntArrayPool = new IntArrayPool$1();
    HeadersDataPool = new HeadersDataPool$1();
  }
}
function get_hostForbiddenSymbols() {
  _init_properties_HttpParser_kt__gbdom1();
  return hostForbiddenSymbols;
}
var hostForbiddenSymbols;
function get_httpLineEndings() {
  _init_properties_HttpParser_kt__gbdom1();
  return httpLineEndings;
}
var httpLineEndings;
var versions;
function *_generator_parseHeaders__yk88b9(input, builder, range, $completion) {
  range = range === VOID ? new MutableRange(0, 0) : range;
  var headers = new HttpHeadersMap(builder);
  try {
    $l$loop: while (true) {
      var tmp = readUTF8LineTo(input, builder, 8192, get_httpLineEndings(), $completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
      if (!tmp) {
        headers.s1i();
        return null;
      }
      range.d31_1 = builder.s30_1;
      var rangeLength = range.d31_1 - range.c31_1 | 0;
      if (rangeLength === 0)
        break $l$loop;
      if (rangeLength >= 8192) {
        // Inline function 'kotlin.error' call
        var message = 'Header line length limit exceeded';
        throw IllegalStateException.t4(toString(message));
      }
      var nameStart = range.c31_1;
      var nameEnd = parseHeaderName(builder, range);
      var headerEnd = range.d31_1;
      parseHeaderValue(builder, range);
      var valueStart = range.c31_1;
      var valueEnd = range.d31_1;
      range.c31_1 = headerEnd;
      headers.j30(nameStart, nameEnd, valueStart, valueEnd);
    }
    var host = headers.l2g(HttpHeaders_getInstance().b2q_1);
    if (!(host == null)) {
      validateHostHeader(host);
    }
    return headers;
  } catch ($p) {
    if ($p instanceof Error) {
      var t = $p;
      headers.s1i();
      throw t;
    } else {
      throw $p;
    }
  }
}
function parseHeaders(input, builder, range, $completion) {
  range = range === VOID ? new MutableRange(0, 0) : range;
  return suspendOrReturn(/*#__NOINLINE__*/_generator_parseHeaders__yk88b9.bind(VOID, input, builder, range), $completion);
}
function parseHeaderName(text, range) {
  _init_properties_HttpParser_kt__gbdom1();
  var index = range.c31_1;
  var end = range.d31_1;
  while (index < end) {
    var ch = text.b(index);
    if (ch === _Char___init__impl__6a9atx(58) && !(index === range.c31_1)) {
      range.c31_1 = index + 1 | 0;
      return index;
    }
    if (isDelimiter(ch)) {
      parseHeaderNameFailed(text, index, range.c31_1, ch);
    }
    index = index + 1 | 0;
  }
  noColonFound(text, range);
}
function parseHeaderValue(text, range) {
  _init_properties_HttpParser_kt__gbdom1();
  var start = range.c31_1;
  var end = range.d31_1;
  var index = start;
  index = skipSpacesAndHorizontalTabs(text, index, end);
  if (index >= end) {
    range.c31_1 = end;
    return Unit_instance;
  }
  var valueStart = index;
  var valueLastIndex = index;
  while (index < end) {
    var ch = text.b(index);
    if (ch !== _Char___init__impl__6a9atx(9) && ch !== _Char___init__impl__6a9atx(32))
      if (ch === _Char___init__impl__6a9atx(13) || ch === _Char___init__impl__6a9atx(10)) {
        characterIsNotAllowed(text, ch);
      } else
        valueLastIndex = index;
    index = index + 1 | 0;
  }
  range.c31_1 = valueStart;
  range.d31_1 = valueLastIndex + 1 | 0;
}
function validateHostHeader(host) {
  _init_properties_HttpParser_kt__gbdom1();
  if (endsWith(host, ':')) {
    throw ParserException.i31("Host header with ':' should contains port: " + toString(host));
  }
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.text.any' call
    var inductionVariable = 0;
    while (inductionVariable < charSequenceLength(host)) {
      var element = charSequenceGet(host, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      if (get_hostForbiddenSymbols().v2(new Char(element))) {
        tmp$ret$1 = true;
        break $l$block;
      }
    }
    tmp$ret$1 = false;
  }
  if (tmp$ret$1) {
    throw ParserException.i31('Host cannot contain any of the following symbols: ' + toString(get_hostForbiddenSymbols()));
  }
}
function isDelimiter(ch) {
  _init_properties_HttpParser_kt__gbdom1();
  return Char__compareTo_impl_ypi4mb(ch, _Char___init__impl__6a9atx(32)) <= 0 || contains('"(),/:;<=>?@[\\]{}', ch);
}
function parseHeaderNameFailed(text, index, start, ch) {
  _init_properties_HttpParser_kt__gbdom1();
  if (ch === _Char___init__impl__6a9atx(58)) {
    throw ParserException.i31('Empty header names are not allowed as per RFC7230.');
  }
  if (index === start) {
    throw ParserException.i31('Multiline headers via line folding is not supported since it is deprecated as per RFC7230.');
  }
  characterIsNotAllowed(text, ch);
}
function noColonFound(text, range) {
  _init_properties_HttpParser_kt__gbdom1();
  var tmp1 = range.c31_1;
  // Inline function 'kotlin.text.substring' call
  var endIndex = range.d31_1;
  var tmp$ret$0 = toString(charSequenceSubSequence(text, tmp1, endIndex));
  throw ParserException.i31('No colon in HTTP header in ' + tmp$ret$0 + ' in builder: \n' + toString(text));
}
function characterIsNotAllowed(text, ch) {
  _init_properties_HttpParser_kt__gbdom1();
  // Inline function 'kotlin.code' call
  var tmp$ret$0 = Char__toInt_impl_vasixd(ch);
  throw ParserException.i31('Character with code ' + (tmp$ret$0 & 255) + ' is not allowed in header names, \n' + toString(text));
}
var properties_initialized_HttpParser_kt_uedryv;
function _init_properties_HttpParser_kt__gbdom1() {
  if (!properties_initialized_HttpParser_kt_uedryv) {
    properties_initialized_HttpParser_kt_uedryv = true;
    hostForbiddenSymbols = setOf([new Char(_Char___init__impl__6a9atx(47)), new Char(_Char___init__impl__6a9atx(63)), new Char(_Char___init__impl__6a9atx(35)), new Char(_Char___init__impl__6a9atx(64))]);
    httpLineEndings = LineEndingMode__plus_impl_ttpz2j(Companion_getInstance_0().n1r_1, Companion_getInstance_0().m1r_1);
    versions = Companion_instance.j31(listOf(['HTTP/1.0', 'HTTP/1.1']));
  }
}
function get_CrLf() {
  _init_properties_Multipart_kt__ato98a();
  return CrLf;
}
var CrLf;
function get_PrefixString() {
  _init_properties_Multipart_kt__ato98a();
  return PrefixString;
}
var PrefixString;
function parseMultipart(_this__u8e3s4, input, contentType, contentLength, maxPartSize) {
  maxPartSize = maxPartSize === VOID ? new Long(-1, 2147483647) : maxPartSize;
  _init_properties_Multipart_kt__ato98a();
  if (!MultiPart_getInstance().c2o(contentType)) {
    throw UnsupportedMediaTypeExceptionCIO.r31('Failed to parse multipart: Content-Type should be multipart/* but it is ' + toString(contentType));
  }
  var boundaryByteBuffer = parseBoundaryInternal(contentType);
  var boundaryBytes = ByteString.i1l(boundaryByteBuffer);
  return parseMultipart_0(_this__u8e3s4, boundaryBytes, input, contentLength, maxPartSize);
}
function parseBoundaryInternal(contentType) {
  _init_properties_Multipart_kt__ato98a();
  var boundaryParameter = findBoundary(contentType);
  if (boundaryParameter === -1) {
    throw IOException.y1o("Failed to parse multipart: Content-Type's boundary parameter is missing");
  }
  var boundaryStart = boundaryParameter + 9 | 0;
  var boundaryBytes = new Int8Array(74);
  var position = {_v: 0};
  parseBoundaryInternal$put(position, boundaryBytes, 13);
  parseBoundaryInternal$put(position, boundaryBytes, 10);
  parseBoundaryInternal$put(position, boundaryBytes, 45);
  parseBoundaryInternal$put(position, boundaryBytes, 45);
  var state = 0;
  var inductionVariable = boundaryStart;
  var last = charSequenceLength(contentType);
  if (inductionVariable < last)
    loop: do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var ch = charSequenceGet(contentType, i);
      // Inline function 'kotlin.code' call
      var v = Char__toInt_impl_vasixd(ch) & 65535;
      if ((v & 65535) > 127) {
        throw IOException.y1o('Failed to parse multipart: wrong boundary byte 0x' + toString_0(v, 16) + ' - should be 7bit character');
      }
      switch (state) {
        case 0:
          if (ch !== _Char___init__impl__6a9atx(32))
            if (ch === _Char___init__impl__6a9atx(34)) {
              state = 2;
            } else if (ch === _Char___init__impl__6a9atx(59) || ch === _Char___init__impl__6a9atx(44)) {
              break loop;
            } else {
              state = 1;
              parseBoundaryInternal$put(position, boundaryBytes, toByte(v));
            }

          break;
        case 1:
          if (ch === _Char___init__impl__6a9atx(32) || ch === _Char___init__impl__6a9atx(44) || ch === _Char___init__impl__6a9atx(59)) {
            break loop;
          } else {
            parseBoundaryInternal$put(position, boundaryBytes, toByte(v));
          }

          break;
        case 2:
          if (ch === _Char___init__impl__6a9atx(92)) {
            state = 3;
          } else if (ch === _Char___init__impl__6a9atx(34)) {
            break loop;
          } else {
            parseBoundaryInternal$put(position, boundaryBytes, toByte(v));
          }

          break;
        case 3:
          parseBoundaryInternal$put(position, boundaryBytes, toByte(v));
          state = 2;
          break;
      }
    }
     while (inductionVariable < last);
  if (position._v === 4) {
    throw IOException.y1o('Empty multipart boundary is not allowed');
  }
  return copyOfRange(boundaryBytes, 0, position._v);
}
function parseMultipart_0(_this__u8e3s4, boundaryPrefixed, input, totalLength, maxPartSize) {
  _init_properties_Multipart_kt__ato98a();
  return produce(_this__u8e3s4, VOID, VOID, parseMultipart$slambda_0(input, boundaryPrefixed, maxPartSize, totalLength));
}
function findBoundary(contentType) {
  _init_properties_Multipart_kt__ato98a();
  var state = 0;
  var paramNameCount = 0;
  var inductionVariable = 0;
  var last = charSequenceLength(contentType) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var ch = charSequenceGet(contentType, i);
      switch (state) {
        case 0:
          if (ch === _Char___init__impl__6a9atx(59)) {
            state = 1;
            paramNameCount = 0;
          }

          break;
        case 1:
          if (ch === _Char___init__impl__6a9atx(61)) {
            state = 2;
          } else if (ch === _Char___init__impl__6a9atx(59)) {
            paramNameCount = 0;
          } else if (ch === _Char___init__impl__6a9atx(44)) {
            state = 0;
          } else if (ch !== _Char___init__impl__6a9atx(32))
            if (paramNameCount === 0 && startsWith(contentType, 'boundary=', i, true)) {
              return i;
            } else {
              paramNameCount = paramNameCount + 1 | 0;
            }

          break;
        case 2:
          if (ch === _Char___init__impl__6a9atx(34))
            state = 3;
          else if (ch === _Char___init__impl__6a9atx(44))
            state = 0;
          else if (ch === _Char___init__impl__6a9atx(59)) {
            state = 1;
            paramNameCount = 0;
          }

          break;
        case 3:
          if (ch === _Char___init__impl__6a9atx(34)) {
            state = 1;
            paramNameCount = 0;
          } else if (ch === _Char___init__impl__6a9atx(92)) {
            state = 4;
          }

          break;
        case 4:
          state = 3;
          break;
      }
    }
     while (inductionVariable <= last);
  return -1;
}
function parsePreambleImpl(boundary, input, output, limit, $completion) {
  limit = limit === VOID ? new Long(-1, 2147483647) : limit;
  return readUntil(input, boundary, output, limit, true, $completion);
}
function *_generator_parsePartHeadersImpl__ngvtk8(input, $completion) {
  var builder = new CharArrayBuilder();
  try {
    var tmp = parseHeaders(input, builder, VOID, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var tmp0_elvis_lhs = tmp;
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      throw EOFException.u1l('Failed to parse multipart headers: unexpected end of stream');
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    return tmp_0;
  } catch ($p) {
    if ($p instanceof Error) {
      var t = $p;
      builder.s1i();
      throw t;
    } else {
      throw $p;
    }
  }
}
function parsePartHeadersImpl(input, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_parsePartHeadersImpl__ngvtk8.bind(VOID, input), $completion);
}
function *_generator_parsePartBodyImpl__8tyvmc(boundaryPrefixed, input, output, headers, limit, $completion) {
  var tmp0_safe_receiver = headers.l2g('Content-Length');
  var contentLength = tmp0_safe_receiver == null ? null : parseDecLong(tmp0_safe_receiver);
  var tmp;
  if (contentLength == null) {
    var tmp_0 = readUntil(input, boundaryPrefixed, output, limit, true, $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  } else if ((new Long(0, 0)).d4(limit).mo(contentLength)) {
    var tmp_1 = copyTo(input, output, contentLength, $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    var tmp_2 = skipIfFoundReadCount(input, boundaryPrefixed, $completion);
    if (tmp_2 === get_COROUTINE_SUSPENDED())
      tmp_2 = yield tmp_2;
    tmp = tmp_1.u3(tmp_2);
  } else {
    throwLimitExceeded(contentLength, limit);
  }
  var byteCount = tmp;
  var tmp_3 = output.b1q($completion);
  if (tmp_3 === get_COROUTINE_SUSPENDED())
    tmp_3 = yield tmp_3;
  return byteCount;
}
function parsePartBodyImpl(boundaryPrefixed, input, output, headers, limit, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_parsePartBodyImpl__8tyvmc.bind(VOID, boundaryPrefixed, input, output, headers, limit), $completion);
}
function *_generator_skipIfFoundReadCount__pli0t1(_this__u8e3s4, prefix, $completion) {
  var tmp;
  var tmp_0 = skipIfFound(_this__u8e3s4, prefix, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  if (tmp_0) {
    tmp = toLong(prefix.b1());
  } else {
    tmp = new Long(0, 0);
  }
  return tmp;
}
function skipIfFoundReadCount(_this__u8e3s4, prefix, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_skipIfFoundReadCount__pli0t1.bind(VOID, _this__u8e3s4, prefix), $completion);
}
function throwLimitExceeded(actual, limit) {
  _init_properties_Multipart_kt__ato98a();
  throw IOException.y1o('Multipart content length exceeds limit ' + actual.toString() + ' > ' + limit.toString() + '; ' + "limit is defined using 'formFieldLimit' argument");
}
function parseBoundaryInternal$put(position, boundaryBytes, value) {
  if (position._v >= boundaryBytes.length) {
    throw IOException.y1o("Failed to parse multipart: boundary shouldn't be longer than 70 characters");
  }
  var _unary__edvuaz = position._v;
  position._v = _unary__edvuaz + 1 | 0;
  boundaryBytes[_unary__edvuaz] = value;
}
function *_generator_invoke__zhh2q8_0($this, $this$writer, $completion) {
  var tmp = parsePreambleImpl($this.s31_1, $this.t31_1, $this$writer.x1r_1, new Long(8193, 0), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0 = $this$writer.x1r_1.w1q($completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_1($this, $this$produce, $completion) {
  var countedInput = counted($this.u31_1);
  var readBeforeParse = countedInput.m1s();
  var firstBoundary = $this.v31_1.k1l(get_PrefixString().b1());
  var tmp = readRemaining(writer($this$produce, VOID, VOID, parseMultipart$slambda$slambda_0(firstBoundary, countedInput)).v1r_1, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var preambleData = tmp;
  if (get_remaining(preambleData).s1(new Long(0, 0)) > 0) {
    var tmp_0 = $this$produce.c1a(new Preamble(preambleData), $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
  }
  $l$loop_0: while (true) {
    var tmp_1;
    if (!countedInput.t1q()) {
      var tmp_2 = skipIfFound(countedInput, get_PrefixString(), $completion);
      if (tmp_2 === get_COROUTINE_SUSPENDED())
        tmp_2 = yield tmp_2;
      tmp_1 = !tmp_2;
    } else {
      tmp_1 = false;
    }
    if (!tmp_1) {
      break $l$loop_0;
    }
    var tmp_3 = skipIfFound(countedInput, get_CrLf(), $completion);
    if (tmp_3 === get_COROUTINE_SUSPENDED())
      tmp_3 = yield tmp_3;
    var tmp_4 = skipIfFound(countedInput, firstBoundary, $completion);
    if (tmp_4 === get_COROUTINE_SUSPENDED())
      tmp_4 = yield tmp_4;
    if (tmp_4) {
      continue $l$loop_0;
    }
    var body = new ByteChannel();
    var headers = CompletableDeferred();
    var part = new MultipartPart(headers, body);
    var tmp_5 = $this$produce.c1a(part, $completion);
    if (tmp_5 === get_COROUTINE_SUSPENDED())
      tmp_5 = yield tmp_5;
    var headersMap = null;
    try {
      var tmp_6 = parsePartHeadersImpl(countedInput, $completion);
      if (tmp_6 === get_COROUTINE_SUSPENDED())
        tmp_6 = yield tmp_6;
      headersMap = tmp_6;
      if (!headers.s11(headersMap)) {
        headersMap.s1i();
        throw CancellationException.nd('Multipart processing has been cancelled');
      }
      var tmp_7 = parsePartBodyImpl($this.v31_1, countedInput, body, headersMap, $this.w31_1, $completion);
      if (tmp_7 === get_COROUTINE_SUSPENDED())
        tmp_7 = yield tmp_7;
      body.a6();
    } catch ($p) {
      if ($p instanceof Error) {
        var cause = $p;
        if (headers.t11(cause)) {
          var tmp0_safe_receiver = headersMap;
          if (tmp0_safe_receiver == null)
            null;
          else {
            tmp0_safe_receiver.s1i();
          }
        }
        close(body, cause);
        throw cause;
      } else {
        throw $p;
      }
    }
  }
  var tmp_8 = skipIfFound(countedInput, get_CrLf(), $completion);
  if (tmp_8 === get_COROUTINE_SUSPENDED())
    tmp_8 = yield tmp_8;
  var tmp_9 = skipIfFound(countedInput, get_CrLf(), $completion);
  if (tmp_9 === get_COROUTINE_SUSPENDED())
    tmp_9 = yield tmp_9;
  if (!($this.x31_1 == null)) {
    var consumedExceptEpilogue = countedInput.m1s().v3(readBeforeParse);
    var size = $this.x31_1.v3(consumedExceptEpilogue);
    if (size.s1(new Long(2147483647, 0)) > 0)
      throw IOException.y1o('Failed to parse multipart: prologue is too long');
    if (size.s1(new Long(0, 0)) > 0) {
      var tmp_10 = readPacket(countedInput, size.x1(), $completion);
      if (tmp_10 === get_COROUTINE_SUSPENDED())
        tmp_10 = yield tmp_10;
      var tmp_11 = $this$produce.c1a(new Epilogue(tmp_10), $completion);
      if (tmp_11 === get_COROUTINE_SUSPENDED())
        tmp_11 = yield tmp_11;
    }
  } else {
    var tmp_12 = readRemaining(countedInput, $completion);
    if (tmp_12 === get_COROUTINE_SUSPENDED())
      tmp_12 = yield tmp_12;
    var epilogueContent = tmp_12;
    if (!epilogueContent.w1l()) {
      var tmp_13 = $this$produce.c1a(new Epilogue(epilogueContent), $completion);
      if (tmp_13 === get_COROUTINE_SUSPENDED())
        tmp_13 = yield tmp_13;
    }
  }
  return Unit_instance;
}
function parseMultipart$slambda$slambda_0($firstBoundary, $countedInput) {
  var i = new parseMultipart$slambda$slambda($firstBoundary, $countedInput);
  var l = ($this$writer, $completion) => i.y31($this$writer, $completion);
  l.$arity = 1;
  return l;
}
function parseMultipart$slambda_0($input, $boundaryPrefixed, $maxPartSize, $totalLength) {
  var i = new parseMultipart$slambda($input, $boundaryPrefixed, $maxPartSize, $totalLength);
  var l = ($this$produce, $completion) => i.z31($this$produce, $completion);
  l.$arity = 1;
  return l;
}
var properties_initialized_Multipart_kt_wu0sh0;
function _init_properties_Multipart_kt__ato98a() {
  if (!properties_initialized_Multipart_kt_wu0sh0) {
    properties_initialized_Multipart_kt_wu0sh0 = true;
    CrLf = ByteString.i1l(toByteArray_0('\r\n'));
    PrefixString = ByteString_0(new Int8Array([45, 45]));
  }
}
function build($this, resultList, from, maxLength, idx, length, charAt) {
  // Inline function 'kotlin.collections.groupBy' call
  // Inline function 'kotlin.collections.groupByTo' call
  var destination = LinkedHashMap.hc();
  var _iterator__ex2g4s = from.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var key = charAt(element, idx);
    // Inline function 'kotlin.collections.getOrPut' call
    var value = destination.h3(key);
    var tmp;
    if (value == null) {
      var answer = ArrayList.k();
      destination.k3(key, answer);
      tmp = answer;
    } else {
      tmp = value;
    }
    var list = tmp;
    list.l(element);
  }
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s_0 = destination.l1().y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    // Inline function 'kotlin.collections.component1' call
    var ch = element_0.m1().j2_1;
    // Inline function 'kotlin.collections.component2' call
    var list_0 = element_0.n1();
    var nextIdx = idx + 1 | 0;
    var children = ArrayList.k();
    var tmp_0 = Companion_instance;
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination_0 = ArrayList.k();
    var _iterator__ex2g4s_1 = list_0.y();
    while (_iterator__ex2g4s_1.z()) {
      var element_1 = _iterator__ex2g4s_1.a1();
      if (length(element_1) > nextIdx) {
        destination_0.l(element_1);
      }
    }
    build(tmp_0, children, destination_0, maxLength, nextIdx, length, charAt);
    children.x7();
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination_1 = ArrayList.k();
    var _iterator__ex2g4s_2 = list_0.y();
    while (_iterator__ex2g4s_2.z()) {
      var element_2 = _iterator__ex2g4s_2.a1();
      if (length(element_2) === nextIdx) {
        destination_1.l(element_2);
      }
    }
    resultList.l(new Node(ch, destination_1, children));
  }
}
function AsciiCharTree$Companion$build$lambda(it) {
  return charSequenceLength(it);
}
function AsciiCharTree$Companion$build$lambda_0(s, idx) {
  return new Char(charSequenceGet(s, idx));
}
var Companion_instance;
function Companion_getInstance_1() {
  return Companion_instance;
}
function getImpl($this, index) {
  return bufferForIndex($this, index)[index % ensureNotNull($this.o30_1).length | 0];
}
function copy($this, startIndex, endIndex) {
  if (startIndex === endIndex)
    return '';
  var builder = StringBuilder.xb(endIndex - startIndex | 0);
  var buffer;
  var base = startIndex - (startIndex % 2048 | 0) | 0;
  while (base < endIndex) {
    buffer = bufferForIndex($this, base);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b = startIndex - base | 0;
    var innerStartIndex = Math.max(0, b);
    // Inline function 'kotlin.comparisons.minOf' call
    var a = endIndex - base | 0;
    var innerEndIndex = Math.min(a, 2048);
    var inductionVariable = innerStartIndex;
    if (inductionVariable < innerEndIndex)
      do {
        var innerIndex = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        builder.ub(buffer[innerIndex]);
      }
       while (inductionVariable < innerEndIndex);
    base = base + 2048 | 0;
  }
  return builder;
}
function bufferForIndex($this, index) {
  var list = $this.n30_1;
  if (list == null) {
    if (index >= 2048) {
      throwSingleBuffer($this, index);
    }
    var tmp0_elvis_lhs = $this.o30_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throwSingleBuffer($this, index);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  return list.f1(index / ensureNotNull($this.o30_1).length | 0);
}
function throwSingleBuffer($this, index) {
  if ($this.q30_1)
    throw IllegalStateException.t4('Buffer is already released');
  throw IndexOutOfBoundsException.me('' + index + ' is not in range [0; ' + currentPosition($this) + ')');
}
function nonFullBuffer($this) {
  return $this.r30_1 === 0 ? appendNewArray($this) : ensureNotNull($this.o30_1);
}
function appendNewArray($this) {
  var newBuffer = $this.m30_1.j1t();
  var existing = $this.o30_1;
  $this.o30_1 = newBuffer;
  $this.r30_1 = newBuffer.length;
  $this.q30_1 = false;
  if (!(existing == null)) {
    var tmp0_elvis_lhs = $this.n30_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_0 = ArrayList.k();
      $this.n30_1 = this_0;
      this_0.l(existing);
      tmp = this_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var list = tmp;
    list.l(newBuffer);
  }
  return newBuffer;
}
function rangeEqualsImpl($this, start, other, otherStart, length) {
  var inductionVariable = 0;
  if (inductionVariable < length)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (!(getImpl($this, start + i | 0) === charSequenceGet(other, otherStart + i | 0)))
        return false;
    }
     while (inductionVariable < length);
  return true;
}
function hashCodeImpl($this, start, end) {
  var hc = 0;
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = imul(31, hc);
      // Inline function 'kotlin.code' call
      var this_0 = getImpl($this, i);
      hc = tmp + Char__toInt_impl_vasixd(this_0) | 0;
    }
     while (inductionVariable < end);
  return hc;
}
function currentPosition($this) {
  return ensureNotNull($this.o30_1).length - $this.r30_1 | 0;
}
function get_CharArrayPool() {
  _init_properties_CharArrayPool_kt__u4nq0d();
  return CharArrayPool;
}
var CharArrayPool;
var properties_initialized_CharArrayPool_kt_aq0u0f;
function _init_properties_CharArrayPool_kt__u4nq0d() {
  if (!properties_initialized_CharArrayPool_kt_aq0u0f) {
    properties_initialized_CharArrayPool_kt_aq0u0f = true;
    var tmp;
    if (isPoolingDisabled()) {
      tmp = new CharArrayPool$1();
    } else {
      tmp = new CharArrayPool$2();
    }
    CharArrayPool = tmp;
  }
}
var DefaultHttpMethods;
var HexTable;
var HexLetterTable;
function parseDecLong(_this__u8e3s4) {
  _init_properties_Chars_kt__d3i39x();
  var length = charSequenceLength(_this__u8e3s4);
  if (length > 19) {
    numberFormatException(_this__u8e3s4);
  }
  if (length === 19)
    return parseDecLongWithCheck(_this__u8e3s4);
  var result = new Long(0, 0);
  var inductionVariable = 0;
  if (inductionVariable < length)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(_this__u8e3s4, i);
      var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
      var digit = toLong(tmp$ret$0).v3(new Long(48, 0));
      if (digit.s1(new Long(0, 0)) < 0 || digit.s1(new Long(9, 0)) > 0) {
        numberFormatException_0(_this__u8e3s4, i);
      }
      result = result.e4(3).u3(result.e4(1)).u3(digit);
    }
     while (inductionVariable < length);
  return result;
}
function hashCodeLowerCase(_this__u8e3s4, start, end) {
  start = start === VOID ? 0 : start;
  end = end === VOID ? charSequenceLength(_this__u8e3s4) : end;
  _init_properties_Chars_kt__d3i39x();
  var hashCode = 0;
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var pos = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(_this__u8e3s4, pos);
      // Inline function 'io.ktor.http.cio.internals.toLowerCase' call
      var this_1 = Char__toInt_impl_vasixd(this_0);
      var tmp;
      // Inline function 'kotlin.code' call
      var this_2 = _Char___init__impl__6a9atx(65);
      var containsLower = Char__toInt_impl_vasixd(this_2);
      var tmp_0;
      // Inline function 'kotlin.code' call
      var this_3 = _Char___init__impl__6a9atx(90);
      if (this_1 <= Char__toInt_impl_vasixd(this_3)) {
        tmp_0 = containsLower <= this_1;
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        // Inline function 'kotlin.code' call
        var this_4 = _Char___init__impl__6a9atx(97);
        var tmp_1 = Char__toInt_impl_vasixd(this_4);
        // Inline function 'kotlin.code' call
        var this_5 = _Char___init__impl__6a9atx(65);
        tmp = tmp_1 + (this_1 - Char__toInt_impl_vasixd(this_5) | 0) | 0;
      } else {
        tmp = this_1;
      }
      var v = tmp;
      hashCode = imul(31, hashCode) + v | 0;
    }
     while (inductionVariable < end);
  return hashCode;
}
function equalsLowerCase(_this__u8e3s4, start, end, other) {
  start = start === VOID ? 0 : start;
  end = end === VOID ? charSequenceLength(_this__u8e3s4) : end;
  _init_properties_Chars_kt__d3i39x();
  if (!((end - start | 0) === charSequenceLength(other)))
    return false;
  var inductionVariable = start;
  if (inductionVariable < end)
    do {
      var pos = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(_this__u8e3s4, pos);
      // Inline function 'io.ktor.http.cio.internals.toLowerCase' call
      var this_1 = Char__toInt_impl_vasixd(this_0);
      var tmp;
      // Inline function 'kotlin.code' call
      var this_2 = _Char___init__impl__6a9atx(65);
      var containsLower = Char__toInt_impl_vasixd(this_2);
      var tmp_0;
      // Inline function 'kotlin.code' call
      var this_3 = _Char___init__impl__6a9atx(90);
      if (this_1 <= Char__toInt_impl_vasixd(this_3)) {
        tmp_0 = containsLower <= this_1;
      } else {
        tmp_0 = false;
      }
      if (tmp_0) {
        // Inline function 'kotlin.code' call
        var this_4 = _Char___init__impl__6a9atx(97);
        var tmp_1 = Char__toInt_impl_vasixd(this_4);
        // Inline function 'kotlin.code' call
        var this_5 = _Char___init__impl__6a9atx(65);
        tmp = tmp_1 + (this_1 - Char__toInt_impl_vasixd(this_5) | 0) | 0;
      } else {
        tmp = this_1;
      }
      var tmp_2 = tmp;
      // Inline function 'kotlin.code' call
      var this_6 = charSequenceGet(other, pos - start | 0);
      // Inline function 'io.ktor.http.cio.internals.toLowerCase' call
      var this_7 = Char__toInt_impl_vasixd(this_6);
      var tmp_3;
      // Inline function 'kotlin.code' call
      var this_8 = _Char___init__impl__6a9atx(65);
      var containsLower_0 = Char__toInt_impl_vasixd(this_8);
      var tmp_4;
      // Inline function 'kotlin.code' call
      var this_9 = _Char___init__impl__6a9atx(90);
      if (this_7 <= Char__toInt_impl_vasixd(this_9)) {
        tmp_4 = containsLower_0 <= this_7;
      } else {
        tmp_4 = false;
      }
      if (tmp_4) {
        // Inline function 'kotlin.code' call
        var this_10 = _Char___init__impl__6a9atx(97);
        var tmp_5 = Char__toInt_impl_vasixd(this_10);
        // Inline function 'kotlin.code' call
        var this_11 = _Char___init__impl__6a9atx(65);
        tmp_3 = tmp_5 + (this_7 - Char__toInt_impl_vasixd(this_11) | 0) | 0;
      } else {
        tmp_3 = this_7;
      }
      if (!(tmp_2 === tmp_3))
        return false;
    }
     while (inductionVariable < end);
  return true;
}
function numberFormatException(cs) {
  _init_properties_Chars_kt__d3i39x();
  throw NumberFormatException.se('Invalid number ' + toString(cs) + ': too large for Long type');
}
function parseDecLongWithCheck(_this__u8e3s4) {
  _init_properties_Chars_kt__d3i39x();
  var result = new Long(0, 0);
  var inductionVariable = 0;
  var last = charSequenceLength(_this__u8e3s4) - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(_this__u8e3s4, i);
      var tmp$ret$0 = Char__toInt_impl_vasixd(this_0);
      var digit = toLong(tmp$ret$0).v3(new Long(48, 0));
      if (digit.s1(new Long(0, 0)) < 0 || digit.s1(new Long(9, 0)) > 0) {
        numberFormatException_0(_this__u8e3s4, i);
      }
      result = result.e4(3).u3(result.e4(1)).u3(digit);
      if (result.s1(new Long(0, 0)) < 0) {
        numberFormatException(_this__u8e3s4);
      }
    }
     while (inductionVariable <= last);
  return result;
}
function numberFormatException_0(cs, idx) {
  _init_properties_Chars_kt__d3i39x();
  throw NumberFormatException.se('Invalid number: ' + toString(cs) + ', wrong digit: ' + toString_1(charSequenceGet(cs, idx)) + ' at position ' + idx);
}
function DefaultHttpMethods$lambda(it) {
  _init_properties_Chars_kt__d3i39x();
  return it.y2t_1.length;
}
function DefaultHttpMethods$lambda_0(m, idx) {
  _init_properties_Chars_kt__d3i39x();
  return new Char(charSequenceGet(m.y2t_1, idx));
}
var properties_initialized_Chars_kt_phjfhp;
function _init_properties_Chars_kt__d3i39x() {
  if (!properties_initialized_Chars_kt_phjfhp) {
    properties_initialized_Chars_kt_phjfhp = true;
    var tmp = Companion_instance;
    var tmp_0 = Companion_getInstance().x2t_1;
    var tmp_1 = DefaultHttpMethods$lambda;
    DefaultHttpMethods = tmp.e32(tmp_0, tmp_1, DefaultHttpMethods$lambda_0);
    // Inline function 'kotlin.collections.map' call
    var this_0 = numberRangeToNumber(0, 255);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var inductionVariable = this_0.t1_1;
    var last = this_0.u1_1;
    if (inductionVariable <= last)
      do {
        var item = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var v = item;
        var tmp_2;
        if (48 <= v ? v <= 57 : false) {
          tmp_2 = numberToLong(v).v3(new Long(48, 0));
        } else {
          var tmp_3;
          var tmp_4 = toLong(v);
          // Inline function 'kotlin.code' call
          var this_1 = _Char___init__impl__6a9atx(97);
          var tmp$ret$0 = Char__toInt_impl_vasixd(this_1);
          if (tmp_4.s1(toLong(tmp$ret$0)) >= 0) {
            var tmp_5 = toLong(v);
            // Inline function 'kotlin.code' call
            var this_2 = _Char___init__impl__6a9atx(102);
            var tmp$ret$1 = Char__toInt_impl_vasixd(this_2);
            tmp_3 = tmp_5.s1(toLong(tmp$ret$1)) <= 0;
          } else {
            tmp_3 = false;
          }
          if (tmp_3) {
            // Inline function 'kotlin.code' call
            var this_3 = _Char___init__impl__6a9atx(97);
            var tmp$ret$2 = Char__toInt_impl_vasixd(this_3);
            // Inline function 'kotlin.Long.plus' call
            tmp_2 = numberToLong(v).v3(toLong(tmp$ret$2)).u3(toLong(10));
          } else {
            var tmp_6;
            var tmp_7 = toLong(v);
            // Inline function 'kotlin.code' call
            var this_4 = _Char___init__impl__6a9atx(65);
            var tmp$ret$4 = Char__toInt_impl_vasixd(this_4);
            if (tmp_7.s1(toLong(tmp$ret$4)) >= 0) {
              var tmp_8 = toLong(v);
              // Inline function 'kotlin.code' call
              var this_5 = _Char___init__impl__6a9atx(70);
              var tmp$ret$5 = Char__toInt_impl_vasixd(this_5);
              tmp_6 = tmp_8.s1(toLong(tmp$ret$5)) <= 0;
            } else {
              tmp_6 = false;
            }
            if (tmp_6) {
              // Inline function 'kotlin.code' call
              var this_6 = _Char___init__impl__6a9atx(65);
              var tmp$ret$6 = Char__toInt_impl_vasixd(this_6);
              // Inline function 'kotlin.Long.plus' call
              tmp_2 = numberToLong(v).v3(toLong(tmp$ret$6)).u3(toLong(10));
            } else {
              tmp_2 = new Long(-1, -1);
            }
          }
        }
        var tmp$ret$8 = tmp_2;
        destination.l(tmp$ret$8);
      }
       while (!(item === last));
    HexTable = toLongArray(destination);
    // Inline function 'kotlin.collections.map' call
    var this_7 = numberRangeToNumber(0, 15);
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(this_7, 10));
    var inductionVariable_0 = this_7.t1_1;
    var last_0 = this_7.u1_1;
    if (inductionVariable_0 <= last_0)
      do {
        var item_0 = inductionVariable_0;
        inductionVariable_0 = inductionVariable_0 + 1 | 0;
        var it = item_0;
        var tmp_9;
        if (it < 10) {
          tmp_9 = toByte(48 + it | 0);
        } else {
          // Inline function 'kotlin.code' call
          var this_8 = Char__minus_impl_a2frrh(Char__plus_impl_qi7pgj(_Char___init__impl__6a9atx(97), it), 10);
          var tmp$ret$0_0 = Char__toInt_impl_vasixd(this_8);
          tmp_9 = toByte(tmp$ret$0_0);
        }
        var tmp$ret$1_0 = tmp_9;
        destination_0.l(tmp$ret$1_0);
      }
       while (!(item_0 === last_0));
    HexLetterTable = toByteArray(destination_0);
  }
}
function skipSpacesAndHorizontalTabs(text, start, end) {
  var index = start;
  $l$loop: while (index < end) {
    var ch = text.b(index);
    if (!isWhitespace(ch) && !(ch === _Char___init__impl__6a9atx(9)))
      break $l$loop;
    index = index + 1 | 0;
  }
  return index;
}
function isPoolingDisabled() {
  return false;
}
//region block: post-declaration
initMetadataForClass(CIOMultipartDataBase, 'CIOMultipartDataBase', VOID, VOID, [MultiPartData, CoroutineScope], [0, 1]);
initMetadataForLambda(HeadersData$headersStarts$slambda, VOID, VOID, [1]);
initMetadataForClass(HeadersData, 'HeadersData', HeadersData);
initMetadataForClass(HttpHeadersMap, 'HttpHeadersMap');
initMetadataForClass(IntArrayPool$1);
initMetadataForClass(HeadersDataPool$1);
initMetadataForClass(ParserException, 'ParserException');
initMetadataForClass(MultipartEvent, 'MultipartEvent');
initMetadataForClass(Preamble, 'Preamble');
initMetadataForClass(MultipartPart, 'MultipartPart');
initMetadataForClass(Epilogue, 'Epilogue');
initMetadataForLambda(parseMultipart$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(parseMultipart$slambda, VOID, VOID, [1]);
initMetadataForClass(Node, 'Node');
initMetadataForCompanion(Companion);
initMetadataForClass(AsciiCharTree, 'AsciiCharTree');
initMetadataForClass(SubSequenceImpl, 'SubSequenceImpl', VOID, VOID, [CharSequence]);
initMetadataForClass(CharArrayBuilder, 'CharArrayBuilder', CharArrayBuilder, VOID, [CharSequence]);
initMetadataForClass(CharArrayPool$1);
initMetadataForClass(CharArrayPool$2);
initMetadataForClass(UnsupportedMediaTypeExceptionCIO, 'UnsupportedMediaTypeExceptionCIO');
initMetadataForClass(MutableRange, 'MutableRange');
//endregion
//region block: init
Companion_instance = new Companion();
//endregion
//region block: exports
export {
  CIOMultipartDataBase as CIOMultipartDataBase3o5u8w437tq5s,
};
//endregion

//# sourceMappingURL=ktor-ktor-http-cio.mjs.map
