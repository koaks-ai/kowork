import {
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  VOID7hggqo3abtya as VOID,
  toString1pkumu07cwy4m as toString,
  toString30pk9tzaqopn as toString_0,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  equals2au1ep9vhcato as equals,
  _UInt___init__impl__l7qpdl1vpobek1e692 as _UInt___init__impl__l7qpdl,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  Unit_instance104q5opgivhr8 as Unit_instance,
  Enum3alwj03lh1n41 as Enum,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  Char19o2r8palgjof as Char,
  captureStack1fzi4aczwc4hg as captureStack,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  sorted354mfsiv4s7x5 as sorted,
  joinToString1cxrrlmo0chqs as joinToString,
  getKClass1s3j9wy1cofik as getKClass,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  Collection1k04j3hzsbod0 as Collection,
  isInterface3d6p8outrmvmk as isInterface,
  Regexxgw0gjiagf4z as Regex,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  throwUninitializedPropertyAccessExceptionyynx7gkm73wd as throwUninitializedPropertyAccessException,
  toList3jhuyej2anx2q as toList,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  Comparator2b3maoeh98xtg as Comparator,
  compareTo3ankvs086tmwq as compareTo,
  sortedWith2csnbbb21k0lg as sortedWith,
  ArrayList3it5z8td81qkl as ArrayList,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  StringBuildermazzzhj6kkai as StringBuilder,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  lines3g90sq0zeq43v as lines,
  trimEnd17pt8cbotbalj as trimEnd,
  drop3na99dw9feawf as drop,
  plus310ted5e4i90h as plus,
  startsWith26w8qjqapeeq6 as startsWith,
  NumberFormatException3bgsm2s9o4t55 as NumberFormatException,
  toByte8i5slur4dl5l as toByte,
  toShort1p4eva4kktrqr as toShort,
  toInt5qdj874w69jh as toInt,
  toLong3pjhmef5dakl7 as toLong,
  toLongOrNull12l1gfztrukv1 as toLongOrNull,
  toDouble1kn912gjoizjp as toDouble,
  IndexOutOfBoundsException1qfr429iumro0 as IndexOutOfBoundsException,
  singleOrNull2irkcw0xgriv8 as singleOrNull,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  checkIndexOverflow3frtmheghr0th as checkIndexOverflow,
  UInt1hthisrv6cndi as UInt,
  to2cs3ny02qtbcb as to,
  _UInt___get_data__impl__f0vqqw9xdox7iecbly as _UInt___get_data__impl__f0vqqw,
  singleo93pzdgfc557 as single,
  listOfvhqybd2zx248 as listOf,
  uintCompare18k97xs29243i as uintCompare,
  first58ocm7j58k3q as first,
  UInt__hashCode_impl_z2mhuw88re3pchfde7 as UInt__hashCode_impl_z2mhuw,
  plus20p0vtfmu0596 as plus_0,
  StringCompanionObject_instance2odz3s3zbrixa as StringCompanionObject_instance,
  until1jbpn0z3f8lbg as until,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  AutoCloseable1l5p57f9lp7kv as AutoCloseable,
  trimMarginhyd3fsmh8iev as trimMargin,
  createThis2j2avj17cvnv2 as createThis,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  last1vo29oleiqj36 as last,
  toList383f556t1dixk as toList_0,
  get_lastIndex1yw0x4k50k51w as get_lastIndex,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  toSet2orjxp16sotqu as toSet,
  LinkedHashSet2tkztfx86kyx2 as LinkedHashSet,
  UnsupportedOperationException2tkumpmhredt3 as UnsupportedOperationException,
  protoOf180f3jzyo7rfj as protoOf,
  asSequence2phdjljfh9jhx as asSequence,
  mapsbvh18eqox7a as map,
  equals2v6cggk171b6e as equals_0,
  sorted31ui2j3f69okh as sorted_0,
  joinToStringooja5rkatz3u as joinToString_0,
} from './kotlin-kotlin-stdlib.mjs';
import {
  EmptySerializersModule991ju6pz9b79 as EmptySerializersModule,
  SerializationExceptioneqrdve3ts2n9 as SerializationException,
  getContextualDescriptor2n1gf3b895yb8 as getContextualDescriptor,
  PolymorphicKindla9gurooefwb as PolymorphicKind,
  OBJECT_getInstancee89a3hlgr5ys as OBJECT_getInstance,
  CLASS3e32wwn6b97hz as CLASS,
  CONTEXTUAL2e1gz2tojnpmj as CONTEXTUAL,
  MAPtg3mcyan4256 as MAP,
  LIST2gzos3vzn3slg as LIST,
  ENUMlmq49cvwy4ow as ENUM,
  PrimitiveKindndgbuh6is7ze as PrimitiveKind,
  AbstractDecoder35guh02ubh2hm as AbstractDecoder,
  LONG2pk1o9ze1il7c as LONG,
  SHORTo7q5gsuxaxs as SHORT,
  INT3fyso8r94fmo5 as INT,
  FLOAT2bpqq59z4fuiu as FLOAT,
  DOUBLExcx7tue0m1mu as DOUBLE,
  CHARm37y40it075g as CHAR,
  BYTE3998jn8in9237 as BYTE,
  BOOLEANwrdyi6z6g9t5 as BOOLEAN,
  STRINGrrr0wq2m1c2f as STRING,
  OBJECT2nknkrqb4pf7m as OBJECT,
  MapSerializer11kmegt3g5c1g as MapSerializer,
  SerialDescriptor2pelqekb5ic3a as SerialDescriptor,
  KSerializerzf77vz1967fq as KSerializer,
  SEALED_getInstance15u0wl5f5h4qk as SEALED_getInstance,
  buildSerialDescriptor2873qmkp8r2ib as buildSerialDescriptor,
  get_nullable1xmxlk8ba6b4f as get_nullable,
  STRING_getInstance2gbamclnmtzqa as STRING_getInstance,
  PrimitiveSerialDescriptor3egfp53lutxj2 as PrimitiveSerialDescriptor,
  ListSerializer1hxuk9dx5n9du as ListSerializer,
  ENUM_getInstance3doea03ve3rgg as ENUM_getInstance,
  serializer1x79l67jvwntn as serializer,
  OPEN_getInstance1ppfglhtdde20 as OPEN_getInstance,
  AbstractEncoder2gxtu3xmy3f8j as AbstractEncoder,
  get_elementNamesl5b6t976dltd as get_elementNames,
  contextual3hpp1gupsu4al as contextual,
  SerializersModuleCollector3dddz14wd7brg as SerializersModuleCollector,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  AliasEvent18arfb3x5sd0q as AliasEvent,
  NodeEvent1xqamwd0s6axm as NodeEvent,
  MappingStartEvent1lr1mcqmcpbry as MappingStartEvent,
  SequenceStartEvent27qj1ypmim9wn as SequenceStartEvent,
  ScalarEvent1tfmd4lt1nu9c as ScalarEvent,
  ID_SequenceEnd_getInstanceaarfjmfxap0t as ID_SequenceEnd_getInstance,
  ID_MappingEnd_getInstance1a5lsxz9wd5fg as ID_MappingEnd_getInstance,
  ID_Scalar_getInstance2s7932vtifxcy as ID_Scalar_getInstance,
  ScalarStyle_PLAIN_getInstance1obdwln5ua0w3 as ScalarStyle_PLAIN_getInstance,
  ImplicitTuple2t3yly3nn5jjs as ImplicitTuple,
  MarkedYamlEngineExceptionra3nsv6mim88 as MarkedYamlEngineException,
  Companion_instance1ilxrpxzdyjh5 as Companion_instance,
  StreamReader2jtln3s95380r as StreamReader,
  ParserImpl2xms7a4twiiy as ParserImpl,
  ID_StreamStart_getInstance29csm9f9x17rl as ID_StreamStart_getInstance,
  ID_StreamEnd_getInstance1robf3bbs8brr as ID_StreamEnd_getInstance,
  ID_DocumentStart_getInstanceczzq2c0g00no as ID_DocumentStart_getInstance,
  ID_DocumentEnd_getInstancex65d9aiwrrbl as ID_DocumentEnd_getInstance,
} from './snakeyaml-engine-kmp.mjs';
import {
  Buffer3384y49aj0pxr as Buffer,
  Companion_getInstance3n3majy04gpy as Companion_getInstance,
} from './okio-parent-okio.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class Location {
  constructor(line, column) {
    this.y4n_1 = line;
    this.z4n_1 = column;
  }
  toString() {
    return 'Location(line=' + this.y4n_1 + ', column=' + this.z4n_1 + ')';
  }
  hashCode() {
    var result = this.y4n_1;
    result = imul(result, 31) + this.z4n_1 | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Location))
      return false;
    var tmp0_other_with_cast = other instanceof Location ? other : THROW_CCE();
    if (!(this.y4n_1 === tmp0_other_with_cast.y4n_1))
      return false;
    if (!(this.z4n_1 === tmp0_other_with_cast.z4n_1))
      return false;
    return true;
  }
}
class Companion {
  constructor() {
    Companion_instance_0 = this;
    this.a4o_1 = new Yaml();
  }
}
class Yaml {
  constructor(serializersModule, configuration) {
    Companion_getInstance_0();
    serializersModule = serializersModule === VOID ? EmptySerializersModule() : serializersModule;
    configuration = configuration === VOID ? new YamlConfiguration() : configuration;
    this.b4o_1 = serializersModule;
    this.c4o_1 = configuration;
  }
  d4o(string) {
    return this.e4o(bufferedSource(string));
  }
  e4o(source) {
    var parser = new YamlParser(source, this.c4o_1.t4o_1);
    var reader = new YamlNodeReader(parser, this.c4o_1.h4o_1, this.c4o_1.r4o_1.v4o());
    var node = reader.n3t();
    parser.f4p();
    return node;
  }
}
class YamlConfiguration {
  constructor(encodeDefaults, strictMode, extensionDefinitionPrefix, polymorphismStyle, polymorphismPropertyName, encodingIndentationSize, breakScalarsAt, sequenceStyle, singleLineStringStyle, multiLineStringStyle, ambiguousQuoteStyle, sequenceBlockIndent, anchorsAndAliases, yamlNamingStrategy, codePointLimit, decodeEnumCaseInsensitive) {
    encodeDefaults = encodeDefaults === VOID ? true : encodeDefaults;
    strictMode = strictMode === VOID ? true : strictMode;
    extensionDefinitionPrefix = extensionDefinitionPrefix === VOID ? null : extensionDefinitionPrefix;
    polymorphismStyle = polymorphismStyle === VOID ? PolymorphismStyle_Tag_getInstance() : polymorphismStyle;
    polymorphismPropertyName = polymorphismPropertyName === VOID ? 'type' : polymorphismPropertyName;
    encodingIndentationSize = encodingIndentationSize === VOID ? 2 : encodingIndentationSize;
    breakScalarsAt = breakScalarsAt === VOID ? 80 : breakScalarsAt;
    sequenceStyle = sequenceStyle === VOID ? SequenceStyle_Block_getInstance() : sequenceStyle;
    singleLineStringStyle = singleLineStringStyle === VOID ? SingleLineStringStyle_DoubleQuoted_getInstance() : singleLineStringStyle;
    multiLineStringStyle = multiLineStringStyle === VOID ? singleLineStringStyle.i4p() : multiLineStringStyle;
    ambiguousQuoteStyle = ambiguousQuoteStyle === VOID ? AmbiguousQuoteStyle_DoubleQuoted_getInstance() : ambiguousQuoteStyle;
    sequenceBlockIndent = sequenceBlockIndent === VOID ? 0 : sequenceBlockIndent;
    anchorsAndAliases = anchorsAndAliases === VOID ? Forbidden_getInstance() : anchorsAndAliases;
    yamlNamingStrategy = yamlNamingStrategy === VOID ? null : yamlNamingStrategy;
    codePointLimit = codePointLimit === VOID ? null : codePointLimit;
    decodeEnumCaseInsensitive = decodeEnumCaseInsensitive === VOID ? false : decodeEnumCaseInsensitive;
    this.f4o_1 = encodeDefaults;
    this.g4o_1 = strictMode;
    this.h4o_1 = extensionDefinitionPrefix;
    this.i4o_1 = polymorphismStyle;
    this.j4o_1 = polymorphismPropertyName;
    this.k4o_1 = encodingIndentationSize;
    this.l4o_1 = breakScalarsAt;
    this.m4o_1 = sequenceStyle;
    this.n4o_1 = singleLineStringStyle;
    this.o4o_1 = multiLineStringStyle;
    this.p4o_1 = ambiguousQuoteStyle;
    this.q4o_1 = sequenceBlockIndent;
    this.r4o_1 = anchorsAndAliases;
    this.s4o_1 = yamlNamingStrategy;
    this.t4o_1 = codePointLimit;
    this.u4o_1 = decodeEnumCaseInsensitive;
  }
  toString() {
    return 'YamlConfiguration(encodeDefaults=' + this.f4o_1 + ', strictMode=' + this.g4o_1 + ', extensionDefinitionPrefix=' + this.h4o_1 + ', polymorphismStyle=' + this.i4o_1.toString() + ', polymorphismPropertyName=' + this.j4o_1 + ', encodingIndentationSize=' + this.k4o_1 + ', breakScalarsAt=' + this.l4o_1 + ', sequenceStyle=' + this.m4o_1.toString() + ', singleLineStringStyle=' + this.n4o_1.toString() + ', multiLineStringStyle=' + this.o4o_1.toString() + ', ambiguousQuoteStyle=' + this.p4o_1.toString() + ', sequenceBlockIndent=' + this.q4o_1 + ', anchorsAndAliases=' + toString(this.r4o_1) + ', yamlNamingStrategy=' + toString_0(this.s4o_1) + ', codePointLimit=' + this.t4o_1 + ', decodeEnumCaseInsensitive=' + this.u4o_1 + ')';
  }
  hashCode() {
    var result = getBooleanHashCode(this.f4o_1);
    result = imul(result, 31) + getBooleanHashCode(this.g4o_1) | 0;
    result = imul(result, 31) + (this.h4o_1 == null ? 0 : getStringHashCode(this.h4o_1)) | 0;
    result = imul(result, 31) + this.i4o_1.hashCode() | 0;
    result = imul(result, 31) + getStringHashCode(this.j4o_1) | 0;
    result = imul(result, 31) + this.k4o_1 | 0;
    result = imul(result, 31) + this.l4o_1 | 0;
    result = imul(result, 31) + this.m4o_1.hashCode() | 0;
    result = imul(result, 31) + this.n4o_1.hashCode() | 0;
    result = imul(result, 31) + this.o4o_1.hashCode() | 0;
    result = imul(result, 31) + this.p4o_1.hashCode() | 0;
    result = imul(result, 31) + this.q4o_1 | 0;
    result = imul(result, 31) + hashCode(this.r4o_1) | 0;
    result = imul(result, 31) + (this.s4o_1 == null ? 0 : hashCode(this.s4o_1)) | 0;
    result = imul(result, 31) + (this.t4o_1 == null ? 0 : this.t4o_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.u4o_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof YamlConfiguration))
      return false;
    var tmp0_other_with_cast = other instanceof YamlConfiguration ? other : THROW_CCE();
    if (!(this.f4o_1 === tmp0_other_with_cast.f4o_1))
      return false;
    if (!(this.g4o_1 === tmp0_other_with_cast.g4o_1))
      return false;
    if (!(this.h4o_1 == tmp0_other_with_cast.h4o_1))
      return false;
    if (!this.i4o_1.equals(tmp0_other_with_cast.i4o_1))
      return false;
    if (!(this.j4o_1 === tmp0_other_with_cast.j4o_1))
      return false;
    if (!(this.k4o_1 === tmp0_other_with_cast.k4o_1))
      return false;
    if (!(this.l4o_1 === tmp0_other_with_cast.l4o_1))
      return false;
    if (!this.m4o_1.equals(tmp0_other_with_cast.m4o_1))
      return false;
    if (!this.n4o_1.equals(tmp0_other_with_cast.n4o_1))
      return false;
    if (!this.o4o_1.equals(tmp0_other_with_cast.o4o_1))
      return false;
    if (!this.p4o_1.equals(tmp0_other_with_cast.p4o_1))
      return false;
    if (!(this.q4o_1 === tmp0_other_with_cast.q4o_1))
      return false;
    if (!equals(this.r4o_1, tmp0_other_with_cast.r4o_1))
      return false;
    if (!equals(this.s4o_1, tmp0_other_with_cast.s4o_1))
      return false;
    if (!(this.t4o_1 == tmp0_other_with_cast.t4o_1))
      return false;
    if (!(this.u4o_1 === tmp0_other_with_cast.u4o_1))
      return false;
    return true;
  }
}
class AnchorsAndAliases {}
class Forbidden extends AnchorsAndAliases {
  constructor() {
    Forbidden_instance = null;
    super();
    Forbidden_instance = this;
    this.j4p_1 = _UInt___init__impl__l7qpdl(0);
  }
  k4p() {
    return this.j4p_1;
  }
  v4o() {
    return this.k4p();
  }
  toString() {
    return 'Forbidden';
  }
  hashCode() {
    return 1233813646;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Forbidden))
      return false;
    other instanceof Forbidden || THROW_CCE();
    return true;
  }
}
class PolymorphismStyle extends Enum {}
class SequenceStyle extends Enum {}
class SingleLineStringStyle extends Enum {
  i4p() {
    var tmp;
    switch (this.o3_1) {
      case 0:
        tmp = MultiLineStringStyle_DoubleQuoted_getInstance();
        break;
      case 1:
        tmp = MultiLineStringStyle_SingleQuoted_getInstance();
        break;
      case 2:
        tmp = MultiLineStringStyle_Plain_getInstance();
        break;
      case 3:
        tmp = MultiLineStringStyle_Plain_getInstance();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
}
class MultiLineStringStyle extends Enum {}
class AmbiguousQuoteStyle extends Enum {}
class Marker {
  equals(other) {
    if (!(other instanceof Marker))
      return false;
    other instanceof Marker || THROW_CCE();
    return true;
  }
  hashCode() {
    return 0;
  }
  toString() {
    return '@com.charleskorn.kaml.YamlContentPolymorphicSerializer.Marker(' + ')';
  }
}
class YamlInput extends AbstractDecoder {
  constructor(node, yaml, serializersModule, configuration) {
    Companion_getInstance_1();
    super();
    this.p4p_1 = node;
    this.q4p_1 = yaml;
    this.r4p_1 = serializersModule;
    this.s4p_1 = configuration;
  }
  u1y() {
    return this.r4p_1;
  }
  e1y(deserializer) {
    try {
      return super.e1y(deserializer);
    } catch ($p) {
      if ($p instanceof SerializationException) {
        var e = $p;
        throwIfMissingRequiredPropertyException(this, e);
        throw e;
      } else {
        throw $p;
      }
    }
  }
}
class YamlContextualInput extends YamlInput {
  a1y() {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      tmp = (new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1)).a1y();
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp;
  }
  v1x() {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      tmp = (new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1)).v1x();
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp;
  }
  w1x() {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      tmp = (new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1)).w1x();
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp;
  }
  u1x() {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      tmp = (new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1)).u1x();
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp;
  }
  t1x() {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      tmp = (new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1)).t1x();
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp;
  }
  y1x() {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      tmp = (new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1)).y1x();
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp;
  }
  x1x() {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      tmp = (new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1)).x1x();
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp;
  }
  s1x() {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      tmp = (new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1)).s1x();
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp;
  }
  z1x() {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      var $this$delegateToYamlScalarInput = new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1);
      tmp = new Char($this$delegateToYamlScalarInput.z1x());
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp.j2_1;
  }
  b1y(enumDescriptor) {
    // Inline function 'com.charleskorn.kaml.YamlContextualInput.delegateToYamlScalarInput' call
    var tmp0_subject = this.p4p_1;
    var tmp;
    if (tmp0_subject instanceof YamlScalar) {
      tmp = (new YamlScalarInput(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1)).b1y(enumDescriptor);
    } else {
      if (tmp0_subject instanceof YamlNull) {
        throw UnexpectedNullValueException.h4q(this.p4p_1.u4p_1);
      } else {
        throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
      }
    }
    return tmp;
  }
  w1y(descriptor) {
    throw IllegalStateException.t4('Must call beginStructure() and use returned Decoder');
  }
  f1y(descriptor) {
    return Companion_getInstance_1().o4q(this.p4p_1, this.q4p_1, this.u1y(), this.s4p_1, descriptor);
  }
}
class YamlException extends SerializationException {
  static u4r(message, path, cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.j1v(message, cause);
    captureStack($this, $this.t4r_1);
    $this.n4r_1 = message;
    $this.o4r_1 = path;
    $this.p4r_1 = cause;
    $this.q4r_1 = $this.o4r_1.i4r_1;
    $this.r4r_1 = $this.q4r_1.y4n_1;
    $this.s4r_1 = $this.q4r_1.z4n_1;
    return $this;
  }
  h2() {
    return this.n4r_1;
  }
  i2() {
    return this.p4r_1;
  }
  toString() {
    return '' + getKClassFromExpression(this).hf() + ' at ' + this.o4r_1.w4s() + ' on line ' + this.r4r_1 + ', column ' + this.s4r_1 + ': ' + this.h2();
  }
  get message() {
    return this.h2();
  }
  get cause() {
    return this.i2();
  }
}
class DuplicateKeyException extends YamlException {
  static g4r(originalPath, duplicatePath, key) {
    var $this = this.u4r('Duplicate key ' + key + '. It was previously given at line ' + originalPath.i4r_1.y4n_1 + ', column ' + originalPath.i4r_1.z4n_1 + '.', duplicatePath);
    captureStack($this, $this.f4r_1);
    $this.a4r_1 = originalPath;
    $this.b4r_1 = duplicatePath;
    $this.c4r_1 = key;
    $this.d4r_1 = $this.a4r_1.i4r_1;
    $this.e4r_1 = $this.b4r_1.i4r_1;
    return $this;
  }
}
class IncorrectTypeException extends YamlException {
  static h4s(message, path) {
    var $this = this.u4r(message, path);
    captureStack($this, $this.g4s_1);
    return $this;
  }
}
class YamlScalarFormatException extends YamlException {
  static v4s(message, path, originalValue) {
    var $this = this.u4r(message, path);
    captureStack($this, $this.u4s_1);
    $this.t4s_1 = originalValue;
    return $this;
  }
}
class MissingTypeTagException extends IncorrectTypeException {
  static k4t(path) {
    var $this = this.h4s('Value is missing a type tag (eg. !<type>)', path);
    captureStack($this, $this.j4t_1);
    return $this;
  }
}
class InvalidPropertyValueException extends YamlException {
  static z4t(propertyName, reason, path, cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.u4r("Value for '" + propertyName + "' is invalid: " + reason, path, cause);
    captureStack($this, $this.y4t_1);
    $this.w4t_1 = propertyName;
    $this.x4t_1 = reason;
    return $this;
  }
}
class MissingRequiredPropertyException extends YamlException {
  static n4u(propertyName, path, cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.u4r("Property '" + propertyName + "' is required but it is missing.", path, cause);
    captureStack($this, $this.m4u_1);
    $this.l4u_1 = propertyName;
    return $this;
  }
}
class EmptyYamlDocumentException extends YamlException {
  static a4v(message, path) {
    var $this = this.u4r(message, path);
    captureStack($this, $this.z4u_1);
    return $this;
  }
}
class MalformedYamlException extends YamlException {
  static n4v(message, path) {
    var $this = this.u4r(message, path);
    captureStack($this, $this.m4v_1);
    return $this;
  }
}
class ForbiddenAnchorOrAliasException extends YamlException {
  static a4w(message, path) {
    var $this = this.u4r(message, path);
    captureStack($this, $this.z4v_1);
    return $this;
  }
}
class NoAnchorForExtensionException extends YamlException {
  static p4w(key, extensionDefinitionPrefix, path) {
    var $this = this.u4r("The key '" + key + "' starts with the extension definition prefix '" + extensionDefinitionPrefix + "' but does not define an anchor.", path);
    captureStack($this, $this.o4w_1);
    $this.m4w_1 = key;
    $this.n4w_1 = extensionDefinitionPrefix;
    return $this;
  }
}
class UnknownAnchorException extends YamlException {
  static d4x(anchorName, path) {
    var $this = this.u4r("Unknown anchor '" + anchorName + "'.", path);
    captureStack($this, $this.c4x_1);
    $this.b4x_1 = anchorName;
    return $this;
  }
}
class UnknownPolymorphicTypeException extends YamlException {
  static s4x(typeName, validTypeNames, path, cause) {
    cause = cause === VOID ? null : cause;
    var $this = this.u4r("Unknown type '" + typeName + "'. Known types are: " + joinToString(sorted(validTypeNames), ', '), path, cause);
    captureStack($this, $this.r4x_1);
    $this.p4x_1 = typeName;
    $this.q4x_1 = validTypeNames;
    return $this;
  }
}
class UnexpectedNullValueException extends YamlException {
  static h4q(path) {
    var $this = this.u4r('Unexpected null or empty value for non-null field.', path);
    captureStack($this, $this.g4q_1);
    return $this;
  }
}
class UnknownPropertyException extends YamlException {
  static h4y(propertyName, validPropertyNames, path) {
    var $this = this.u4r("Unknown property '" + propertyName + "'. Known properties are: " + joinToString(sorted(validPropertyNames), ', '), path);
    captureStack($this, $this.g4y_1);
    $this.e4y_1 = propertyName;
    $this.f4y_1 = validPropertyNames;
    return $this;
  }
}
class Companion_0 {
  constructor() {
    Companion_instance_1 = this;
    var tmp = this;
    // Inline function 'kotlin.text.toRegex' call
    var this_0 = "^Field '(.*)' is required for type with serial name '.*', but it was missing$";
    tmp.n4q_1 = Regex.xh(this_0);
  }
  o4q(node, yaml, context, configuration, descriptor) {
    if (descriptor.k1w()) {
      return this.o4q(node, yaml, context, configuration, descriptor.q1w(0));
    }
    var tmp;
    if (node instanceof YamlNull) {
      var tmp_0;
      var tmp_1;
      var tmp_2 = descriptor.j1w();
      if (tmp_2 instanceof PolymorphicKind) {
        tmp_1 = !descriptor.f1w();
      } else {
        tmp_1 = false;
      }
      if (tmp_1) {
        throw MissingTypeTagException.k4t(node.u4p_1);
      } else {
        tmp_0 = new YamlNullInput(node, yaml, context, configuration);
      }
      tmp = tmp_0;
    } else {
      if (node instanceof YamlScalar) {
        var tmp_3;
        var tmp_4;
        var tmp_5 = descriptor.j1w();
        if (tmp_5 instanceof PrimitiveKind) {
          tmp_4 = true;
        } else {
          var tmp_6 = descriptor.j1w();
          tmp_4 = tmp_6 instanceof ENUM;
        }
        if (tmp_4) {
          tmp_3 = new YamlScalarInput(node, yaml, context, configuration);
        } else {
          var tmp_7 = descriptor.j1w();
          if (tmp_7 instanceof CONTEXTUAL) {
            tmp_3 = createContextual(this, node, yaml, context, configuration, descriptor);
          } else {
            var tmp_8 = descriptor.j1w();
            if (tmp_8 instanceof PolymorphicKind) {
              var tmp_9;
              if (_get_isContentBasedPolymorphic__goffbz(this, descriptor)) {
                tmp_9 = createContextual(this, node, yaml, context, configuration, descriptor);
              } else {
                throw MissingTypeTagException.k4t(node.k4y_1);
              }
              tmp_3 = tmp_9;
            } else {
              throw IncorrectTypeException.h4s('Expected ' + get_friendlyDescription(descriptor.j1w()) + ', but got a scalar value', node.k4y_1);
            }
          }
        }
        tmp = tmp_3;
      } else {
        if (node instanceof YamlList) {
          var tmp1_subject = descriptor.j1w();
          var tmp_10;
          if (tmp1_subject instanceof LIST) {
            tmp_10 = new YamlListInput(node, yaml, context, configuration);
          } else {
            if (tmp1_subject instanceof CONTEXTUAL) {
              tmp_10 = createContextual(this, node, yaml, context, configuration, descriptor);
            } else {
              if (tmp1_subject instanceof PolymorphicKind) {
                var tmp_11;
                if (_get_isContentBasedPolymorphic__goffbz(this, descriptor)) {
                  tmp_11 = createContextual(this, node, yaml, context, configuration, descriptor);
                } else {
                  throw MissingTypeTagException.k4t(node.s4y_1);
                }
                tmp_10 = tmp_11;
              } else {
                throw IncorrectTypeException.h4s('Expected ' + get_friendlyDescription(descriptor.j1w()) + ', but got a list', node.s4y_1);
              }
            }
          }
          tmp = tmp_10;
        } else {
          if (node instanceof YamlMap) {
            var tmp2_subject = descriptor.j1w();
            var tmp_12;
            var tmp_13;
            if (tmp2_subject instanceof CLASS) {
              tmp_13 = true;
            } else {
              tmp_13 = equals(tmp2_subject, OBJECT_getInstance());
            }
            if (tmp_13) {
              tmp_12 = new YamlObjectInput(node, yaml, context, configuration);
            } else {
              if (tmp2_subject instanceof MAP) {
                tmp_12 = new YamlMapInput(node, yaml, context, configuration);
              } else {
                if (tmp2_subject instanceof CONTEXTUAL) {
                  tmp_12 = createContextual(this, node, yaml, context, configuration, descriptor);
                } else {
                  if (tmp2_subject instanceof PolymorphicKind) {
                    var tmp_14;
                    if (_get_isContentBasedPolymorphic__goffbz(this, descriptor)) {
                      tmp_14 = createContextual(this, node, yaml, context, configuration, descriptor);
                    } else {
                      var tmp_15;
                      switch (configuration.i4o_1.o3_1) {
                        case 2:
                          throw IncorrectTypeException.h4s("Encountered a polymorphic map descriptor but PolymorphismStyle is 'None'", node.p4y_1);
                        case 0:
                          throw MissingTypeTagException.k4t(node.p4y_1);
                        case 1:
                          tmp_15 = createPolymorphicMapDeserializer(this, node, yaml, context, configuration);
                          break;
                        default:
                          noWhenBranchMatchedException();
                          break;
                      }
                      tmp_14 = tmp_15;
                    }
                    tmp_12 = tmp_14;
                  } else {
                    throw IncorrectTypeException.h4s('Expected ' + get_friendlyDescription(descriptor.j1w()) + ', but got a map', node.p4y_1);
                  }
                }
              }
            }
            tmp = tmp_12;
          } else {
            if (node instanceof YamlTaggedNode) {
              var tmp_16;
              var tmp_17;
              var tmp_18 = descriptor.j1w();
              if (tmp_18 instanceof PolymorphicKind) {
                tmp_17 = configuration.i4o_1.equals(PolymorphismStyle_None_getInstance());
              } else {
                tmp_17 = false;
              }
              if (tmp_17) {
                throw IncorrectTypeException.h4s("Encountered a tagged polymorphic descriptor but PolymorphismStyle is 'None'", node.m4y());
              } else {
                var tmp_19;
                var tmp_20 = descriptor.j1w();
                if (tmp_20 instanceof PolymorphicKind) {
                  tmp_19 = configuration.i4o_1.equals(PolymorphismStyle_Tag_getInstance());
                } else {
                  tmp_19 = false;
                }
                if (tmp_19) {
                  tmp_16 = new YamlPolymorphicInput(node.v4y_1, node.m4y(), node.w4y_1, yaml, context, configuration);
                } else {
                  tmp_16 = this.o4q(node.w4y_1, yaml, context, configuration, descriptor);
                }
              }
              tmp = tmp_16;
            } else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
    return tmp;
  }
}
class YamlListInput extends YamlInput {
  constructor(list, yaml, context, configuration) {
    super(list, yaml, context, configuration);
    this.b4z_1 = list;
    this.c4z_1 = 0;
  }
  x1y(descriptor) {
    return this.b4z_1.r4y_1.b1();
  }
  w1y(descriptor) {
    if (this.c4z_1 === this.b4z_1.r4y_1.b1()) {
      return -1;
    }
    this.d4z_1 = Companion_getInstance_1().o4q(this.b4z_1.r4y_1.f1(this.c4z_1), this.q4p_1, this.u1y(), this.s4p_1, descriptor.q1w(0));
    var _unary__edvuaz = this.c4z_1;
    this.c4z_1 = _unary__edvuaz + 1 | 0;
    return _unary__edvuaz;
  }
  q1x() {
    if (!_get_haveStartedReadingElements__wj0go1(this)) {
      return true;
    }
    return _get_currentElementDecoder__u73r00(this).q1x();
  }
  a1y() {
    return _get_currentElementDecoder__u73r00(this).a1y();
  }
  v1x() {
    return _get_currentElementDecoder__u73r00(this).v1x();
  }
  w1x() {
    return _get_currentElementDecoder__u73r00(this).w1x();
  }
  u1x() {
    return _get_currentElementDecoder__u73r00(this).u1x();
  }
  t1x() {
    return _get_currentElementDecoder__u73r00(this).t1x();
  }
  y1x() {
    return _get_currentElementDecoder__u73r00(this).y1x();
  }
  x1x() {
    return _get_currentElementDecoder__u73r00(this).x1x();
  }
  s1x() {
    return _get_currentElementDecoder__u73r00(this).s1x();
  }
  z1x() {
    return _get_currentElementDecoder__u73r00(this).z1x();
  }
  b1y(enumDescriptor) {
    return _get_currentElementDecoder__u73r00(this).b1y(enumDescriptor);
  }
  e1y(deserializer) {
    if (!_get_haveStartedReadingElements__wj0go1(this)) {
      return super.e1y(deserializer);
    }
    return _get_currentElementDecoder__u73r00(this).e1y(deserializer);
  }
  f1y(descriptor) {
    if (_get_haveStartedReadingElements__wj0go1(this)) {
      return _get_currentElementDecoder__u73r00(this);
    }
    return super.f1y(descriptor);
  }
}
class YamlMapLikeInputBase extends YamlInput {
  constructor(map, yaml, context, configuration) {
    super(map, yaml, context, configuration);
    this.u4z_1 = false;
  }
  z4z() {
    var tmp = this.s4z_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('currentValueDecoder');
    }
  }
  w4z() {
    var tmp = this.t4z_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('currentKey');
    }
  }
  q1x() {
    if (!this.y4z()) {
      return true;
    }
    return this.x4z(YamlMapLikeInputBase$decodeNotNullMark$lambda);
  }
  a1y() {
    return this.x4z(YamlMapLikeInputBase$decodeString$lambda);
  }
  v1x() {
    return this.x4z(YamlMapLikeInputBase$decodeInt$lambda);
  }
  w1x() {
    return this.x4z(YamlMapLikeInputBase$decodeLong$lambda);
  }
  u1x() {
    return this.x4z(YamlMapLikeInputBase$decodeShort$lambda);
  }
  t1x() {
    return this.x4z(YamlMapLikeInputBase$decodeByte$lambda);
  }
  y1x() {
    return this.x4z(YamlMapLikeInputBase$decodeDouble$lambda);
  }
  x1x() {
    return this.x4z(YamlMapLikeInputBase$decodeFloat$lambda);
  }
  s1x() {
    return this.x4z(YamlMapLikeInputBase$decodeBoolean$lambda);
  }
  z1x() {
    return this.x4z(YamlMapLikeInputBase$decodeChar$lambda).j2_1;
  }
  b1y(enumDescriptor) {
    return this.x4z(YamlMapLikeInputBase$decodeEnum$lambda(enumDescriptor));
  }
  e1y(deserializer) {
    if (!this.y4z()) {
      return super.e1y(deserializer);
    }
    return this.x4z(YamlMapLikeInputBase$decodeSerializableValue$lambda(deserializer));
  }
  x4z(action) {
    try {
      return action(this.z4z());
    } catch ($p) {
      if ($p instanceof YamlException) {
        var e = $p;
        if (this.u4z_1) {
          throw InvalidPropertyValueException.z4t(this.v4z(), e.h2(), e.o4r_1, e);
        } else {
          throw e;
        }
      } else {
        throw $p;
      }
    }
  }
  y4z() {
    return !(this.s4z_1 == null);
  }
  v4z() {
    return this.w4z().j4y_1;
  }
}
class YamlMapInput extends YamlMapLikeInputBase {
  constructor(map, yaml, context, configuration) {
    super(map, yaml, context, configuration);
    this.l4z_1 = toList(map.o4y_1.l1());
    this.m4z_1 = 0;
  }
  w1y(descriptor) {
    if (this.m4z_1 === imul(this.l4z_1.b1(), 2)) {
      return -1;
    }
    var entryIndex = this.m4z_1 / 2 | 0;
    this.n4z_1 = this.l4z_1.f1(entryIndex);
    this.t4z_1 = _get_currentEntry__q2u5ma(this).m1();
    this.u4z_1 = !((this.m4z_1 % 2 | 0) === 0);
    var tmp = this;
    var tmp_0;
    switch (this.u4z_1) {
      case true:
        var tmp_1;
        try {
          tmp_1 = Companion_getInstance_1().o4q(_get_currentEntry__q2u5ma(this).n1(), this.q4p_1, this.u1y(), this.s4p_1, descriptor.q1w(1));
        } catch ($p) {
          var tmp_2;
          if ($p instanceof IncorrectTypeException) {
            var e = $p;
            throw InvalidPropertyValueException.z4t(this.v4z(), e.h2(), e.o4r_1, e);
          } else {
            throw $p;
          }
        }

        tmp_0 = tmp_1;
        break;
      case false:
        tmp_0 = Companion_getInstance_1().o4q(this.w4z(), this.q4p_1, this.u1y(), this.s4p_1, descriptor.q1w(0));
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    tmp.s4z_1 = tmp_0;
    var _unary__edvuaz = this.m4z_1;
    this.m4z_1 = _unary__edvuaz + 1 | 0;
    return _unary__edvuaz;
  }
  f1y(descriptor) {
    if (this.y4z()) {
      return this.x4z(YamlMapInput$beginStructure$lambda(descriptor));
    }
    return super.f1y(descriptor);
  }
}
class Companion_1 {}
class sam$kotlin_Comparator$0 {
  constructor(function_0) {
    this.a50_1 = function_0;
  }
  vi(a, b) {
    return this.a50_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.a50_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class YamlNode {
  constructor(path) {
    this.l4y_1 = path;
  }
  m4y() {
    return this.l4y_1;
  }
  b50() {
    return this.m4y().i4r_1;
  }
  f50(child, newParentPath) {
    return YamlPath.h50(plus(newParentPath.h4r_1, drop(child.m4y().h4r_1, this.m4y().h4r_1.b1())));
  }
}
class YamlMap extends YamlNode {
  constructor(entries, path) {
    super(path);
    this.o4y_1 = entries;
    this.p4y_1 = path;
    var tmp = this.o4y_1.i3();
    var tmp_0 = YamlMap$lambda;
    var keys = sortedWith(tmp, new sam$kotlin_Comparator$0(tmp_0));
    // Inline function 'kotlin.collections.mutableMapOf' call
    var encounteredKeys = LinkedHashMap.hc();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = keys.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var duplicate = encounteredKeys.h3(element.j4y_1);
      if (!(duplicate == null)) {
        throw DuplicateKeyException.g4r(duplicate.k4y_1, element.k4y_1, element.c50());
      }
      // Inline function 'kotlin.collections.set' call
      var key = element.j4y_1;
      encounteredKeys.k3(key, element);
    }
  }
  m4y() {
    return this.p4y_1;
  }
  c50() {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.o4y_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(this_0.b1());
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = this_0.l1().y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var key = item.m1();
      // Inline function 'kotlin.collections.component2' call
      var value = item.n1();
      var tmp$ret$3 = key.c50() + ': ' + value.c50();
      destination.l(tmp$ret$3);
    }
    return '{' + joinToString(destination, ', ') + '}';
  }
  d50(key) {
    var tmp$ret$2;
    $l$block_0: {
      // Inline function 'com.charleskorn.kaml.YamlMap.get' call
      var tmp0 = this.o4y_1.l1();
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.collections.firstOrNull' call
        var _iterator__ex2g4s = tmp0.y();
        while (_iterator__ex2g4s.z()) {
          var element = _iterator__ex2g4s.a1();
          if (element.m1().j4y_1 === key) {
            tmp$ret$1 = element;
            break $l$block;
          }
        }
        tmp$ret$1 = null;
      }
      var tmp0_safe_receiver = tmp$ret$1;
      var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.n1();
      var tmp;
      if (tmp1_elvis_lhs == null) {
        tmp$ret$2 = null;
        break $l$block_0;
      } else {
        tmp = tmp1_elvis_lhs;
      }
      var node = tmp;
      var tmp2_elvis_lhs = node instanceof YamlNode ? node : null;
      var tmp_0;
      if (tmp2_elvis_lhs == null) {
        throw IncorrectTypeException.h4s('Expected element to be ' + getKClass(YamlNode).hf() + ' but is ' + getKClassFromExpression(node).hf(), node.m4y());
      } else {
        tmp_0 = tmp2_elvis_lhs;
      }
      tmp$ret$2 = tmp_0;
    }
    var node_0 = tmp$ret$2;
    var tmp_1;
    if (node_0 == null) {
      tmp_1 = null;
    } else {
      if (node_0 instanceof YamlScalar) {
        tmp_1 = node_0;
      } else {
        throw IncorrectTypeException.h4s("Value for '" + key + "' is not a scalar.", node_0.m4y());
      }
    }
    return tmp_1;
  }
  e50(newPath) {
    // Inline function 'kotlin.collections.mapKeys' call
    var this_0 = this.o4y_1;
    // Inline function 'kotlin.collections.mapKeysTo' call
    var destination = LinkedHashMap.ic(mapCapacity(this_0.b1()));
    // Inline function 'kotlin.collections.associateByTo' call
    var _iterator__ex2g4s = this_0.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var k = element.m1();
      var tmp = k.e50(this.f50(k, newPath));
      var tmp$ret$2 = element.n1();
      destination.k3(tmp, tmp$ret$2);
    }
    // Inline function 'kotlin.collections.mapValues' call
    // Inline function 'kotlin.collections.mapValuesTo' call
    var destination_0 = LinkedHashMap.ic(mapCapacity(destination.b1()));
    // Inline function 'kotlin.collections.associateByTo' call
    var _iterator__ex2g4s_0 = destination.l1().y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      var tmp_0 = element_0.m1();
      // Inline function 'kotlin.collections.component2' call
      var v = element_0.n1();
      var tmp$ret$8 = v.e50(this.f50(v, newPath));
      destination_0.k3(tmp_0, tmp$ret$8);
    }
    var updatedEntries = destination_0;
    return new YamlMap(updatedEntries, newPath);
  }
  toString() {
    var builder = StringBuilder.v();
    // Inline function 'kotlin.text.appendLine' call
    var value = 'map @ ' + this.p4y_1.toString() + ' (size: ' + this.o4y_1.b1() + ')';
    // Inline function 'kotlin.text.appendLine' call
    builder.tb(value).ub(_Char___init__impl__6a9atx(10));
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = this.o4y_1.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var key = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var value_0 = element.n1();
      // Inline function 'kotlin.text.appendLine' call
      // Inline function 'kotlin.text.appendLine' call
      builder.tb('- key:').ub(_Char___init__impl__6a9atx(10));
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = lines(key.toString()).y();
      while (_iterator__ex2g4s_0.z()) {
        var element_0 = _iterator__ex2g4s_0.a1();
        builder.tb('    ');
        // Inline function 'kotlin.text.appendLine' call
        // Inline function 'kotlin.text.appendLine' call
        builder.tb(element_0).ub(_Char___init__impl__6a9atx(10));
      }
      // Inline function 'kotlin.text.appendLine' call
      var value_1 = '  value:';
      // Inline function 'kotlin.text.appendLine' call
      builder.tb(value_1).ub(_Char___init__impl__6a9atx(10));
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_1 = lines(toString(value_0)).y();
      while (_iterator__ex2g4s_1.z()) {
        var element_1 = _iterator__ex2g4s_1.a1();
        builder.tb('    ');
        // Inline function 'kotlin.text.appendLine' call
        // Inline function 'kotlin.text.appendLine' call
        builder.tb(element_1).ub(_Char___init__impl__6a9atx(10));
      }
    }
    return toString(trimEnd(builder));
  }
  g50(entries, path) {
    return new YamlMap(entries, path);
  }
  t4y(entries, path, $super) {
    entries = entries === VOID ? this.o4y_1 : entries;
    path = path === VOID ? this.p4y_1 : path;
    return $super === VOID ? this.g50(entries, path) : $super.g50.call(this, entries, path);
  }
  hashCode() {
    var result = hashCode(this.o4y_1);
    result = imul(result, 31) + this.p4y_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof YamlMap))
      return false;
    var tmp0_other_with_cast = other instanceof YamlMap ? other : THROW_CCE();
    if (!equals(this.o4y_1, tmp0_other_with_cast.o4y_1))
      return false;
    if (!this.p4y_1.equals(tmp0_other_with_cast.p4y_1))
      return false;
    return true;
  }
}
class Companion_2 {}
class Companion_3 {}
class YamlScalar extends YamlNode {
  constructor(content, path) {
    super(path);
    this.j4y_1 = content;
    this.k4y_1 = path;
  }
  m4y() {
    return this.k4y_1;
  }
  i50(other) {
    var tmp;
    if (other instanceof YamlScalar) {
      tmp = this.j4y_1 === other.j4y_1;
    } else {
      tmp = false;
    }
    return tmp;
  }
  c50() {
    return "'" + this.j4y_1 + "'";
  }
  k4() {
    return convertToIntegerLikeValue(this, toByte$ref(), 'byte');
  }
  l4() {
    return convertToIntegerLikeValue(this, toShort$ref(), 'short');
  }
  x1() {
    return convertToIntegerLikeValue(this, toInt$ref(), 'integer');
  }
  j50() {
    return convertToIntegerLikeValue(this, toLong$ref(), 'long');
  }
  k50() {
    return convertToIntegerLikeValueOrNull(this, toLongOrNull$ref());
  }
  l50() {
    var tmp;
    switch (this.j4y_1) {
      case '.inf':
      case '.Inf':
      case '.INF':
        tmp = Infinity;
        break;
      case '-.inf':
      case '-.Inf':
      case '-.INF':
        tmp = -Infinity;
        break;
      case '.nan':
      case '.NaN':
      case '.NAN':
        tmp = NaN;
        break;
      default:
        var tmp_0;
        try {
          // Inline function 'kotlin.text.toFloat' call
          var this_0 = this.j4y_1;
          // Inline function 'kotlin.js.unsafeCast' call
          // Inline function 'kotlin.js.asDynamic' call
          tmp_0 = toDouble(this_0);
        } catch ($p) {
          var tmp_1;
          if ($p instanceof NumberFormatException) {
            var e = $p;
            throw YamlScalarFormatException.v4s("Value '" + this.j4y_1 + "' is not a valid floating point value.", this.k4y_1, this.j4y_1);
          } else {
            if ($p instanceof IndexOutOfBoundsException) {
              var e_0 = $p;
              throw YamlScalarFormatException.v4s("Value '" + this.j4y_1 + "' is not a valid floating point value.", this.k4y_1, this.j4y_1);
            } else {
              throw $p;
            }
          }
        }

        tmp = tmp_0;
        break;
    }
    return tmp;
  }
  m4() {
    var tmp0_elvis_lhs = this.m50();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw YamlScalarFormatException.v4s("Value '" + this.j4y_1 + "' is not a valid floating point value.", this.k4y_1, this.j4y_1);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  m50() {
    var tmp;
    switch (this.j4y_1) {
      case '.inf':
      case '.Inf':
      case '.INF':
        tmp = Infinity;
        break;
      case '-.inf':
      case '-.Inf':
      case '-.INF':
        tmp = -Infinity;
        break;
      case '.nan':
      case '.NaN':
      case '.NAN':
        tmp = NaN;
        break;
      default:
        var tmp_0;
        try {
          tmp_0 = toDouble(this.j4y_1);
        } catch ($p) {
          var tmp_1;
          if ($p instanceof NumberFormatException) {
            var e = $p;
            tmp_1 = null;
          } else {
            if ($p instanceof IndexOutOfBoundsException) {
              var e_0 = $p;
              tmp_1 = null;
            } else {
              throw $p;
            }
          }
          tmp_0 = tmp_1;
        }

        tmp = tmp_0;
        break;
    }
    return tmp;
  }
  n50() {
    var tmp0_elvis_lhs = this.o50();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw YamlScalarFormatException.v4s("Value '" + this.j4y_1 + "' is not a valid boolean, permitted choices are: true or false", this.k4y_1, this.j4y_1);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  o50() {
    switch (this.j4y_1) {
      case 'true':
      case 'True':
      case 'TRUE':
        return true;
      case 'false':
      case 'False':
      case 'FALSE':
        return false;
      default:
        return null;
    }
  }
  p50() {
    var tmp0_elvis_lhs = this.q50();
    var tmp;
    var tmp_0 = tmp0_elvis_lhs;
    if ((tmp_0 == null ? null : new Char(tmp_0)) == null) {
      throw YamlScalarFormatException.v4s("Value '" + this.j4y_1 + "' is not a valid character value.", this.k4y_1, this.j4y_1);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  q50() {
    return singleOrNull(this.j4y_1);
  }
  e50(newPath) {
    return this.r50(VOID, newPath);
  }
  toString() {
    return 'scalar @ ' + this.k4y_1.toString() + ' : ' + this.j4y_1;
  }
  s50(content, path) {
    return new YamlScalar(content, path);
  }
  r50(content, path, $super) {
    content = content === VOID ? this.j4y_1 : content;
    path = path === VOID ? this.k4y_1 : path;
    return $super === VOID ? this.s50(content, path) : $super.s50.call(this, content, path);
  }
  hashCode() {
    var result = getStringHashCode(this.j4y_1);
    result = imul(result, 31) + this.k4y_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof YamlScalar))
      return false;
    var tmp0_other_with_cast = other instanceof YamlScalar ? other : THROW_CCE();
    if (!(this.j4y_1 === tmp0_other_with_cast.j4y_1))
      return false;
    if (!this.k4y_1.equals(tmp0_other_with_cast.k4y_1))
      return false;
    return true;
  }
}
class Companion_4 {}
class YamlList extends YamlNode {
  constructor(items, path) {
    super(path);
    this.r4y_1 = items;
    this.s4y_1 = path;
  }
  m4y() {
    return this.s4y_1;
  }
  c50() {
    return '[' + joinToString(this.r4y_1, ', ', VOID, VOID, VOID, VOID, YamlList$contentToString$lambda) + ']';
  }
  e50(newPath) {
    // Inline function 'kotlin.collections.map' call
    var this_0 = this.r4y_1;
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
    var _iterator__ex2g4s = this_0.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = item.e50(this.f50(item, newPath));
      destination.l(tmp$ret$0);
    }
    var updatedItems = destination;
    return new YamlList(updatedItems, newPath);
  }
  toString() {
    var builder = StringBuilder.v();
    // Inline function 'kotlin.text.appendLine' call
    var value = 'list @ ' + this.s4y_1.toString() + ' (size: ' + this.r4y_1.b1() + ')';
    // Inline function 'kotlin.text.appendLine' call
    builder.tb(value).ub(_Char___init__impl__6a9atx(10));
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var _iterator__ex2g4s = this.r4y_1.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      // Inline function 'kotlin.text.appendLine' call
      var value_0 = '- item ' + checkIndexOverflow(_unary__edvuaz) + ':';
      // Inline function 'kotlin.text.appendLine' call
      builder.tb(value_0).ub(_Char___init__impl__6a9atx(10));
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = lines(toString(item)).y();
      while (_iterator__ex2g4s_0.z()) {
        var element = _iterator__ex2g4s_0.a1();
        builder.tb('  ');
        // Inline function 'kotlin.text.appendLine' call
        // Inline function 'kotlin.text.appendLine' call
        builder.tb(element).ub(_Char___init__impl__6a9atx(10));
      }
    }
    return toString(trimEnd(builder));
  }
  hashCode() {
    var result = hashCode(this.r4y_1);
    result = imul(result, 31) + this.s4y_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof YamlList))
      return false;
    var tmp0_other_with_cast = other instanceof YamlList ? other : THROW_CCE();
    if (!equals(this.r4y_1, tmp0_other_with_cast.r4y_1))
      return false;
    if (!this.s4y_1.equals(tmp0_other_with_cast.s4y_1))
      return false;
    return true;
  }
}
class Companion_5 {}
class YamlNull extends YamlNode {
  constructor(path) {
    super(path);
    this.u4p_1 = path;
  }
  m4y() {
    return this.u4p_1;
  }
  c50() {
    return 'null';
  }
  e50(newPath) {
    return new YamlNull(newPath);
  }
  toString() {
    return 'null @ ' + this.u4p_1.toString();
  }
  hashCode() {
    return this.u4p_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof YamlNull))
      return false;
    var tmp0_other_with_cast = other instanceof YamlNull ? other : THROW_CCE();
    if (!this.u4p_1.equals(tmp0_other_with_cast.u4p_1))
      return false;
    return true;
  }
}
class Companion_6 {}
class YamlTaggedNode extends YamlNode {
  constructor(tag, innerNode) {
    super(innerNode.m4y());
    this.v4y_1 = tag;
    this.w4y_1 = innerNode;
  }
  c50() {
    return '!' + this.v4y_1 + ' ' + this.w4y_1.c50();
  }
  e50(newPath) {
    return this.t50(VOID, this.w4y_1.e50(newPath));
  }
  toString() {
    return "tagged '" + this.v4y_1 + "': " + toString(this.w4y_1);
  }
  u50(tag, innerNode) {
    return new YamlTaggedNode(tag, innerNode);
  }
  t50(tag, innerNode, $super) {
    tag = tag === VOID ? this.v4y_1 : tag;
    innerNode = innerNode === VOID ? this.w4y_1 : innerNode;
    return $super === VOID ? this.u50(tag, innerNode) : $super.u50.call(this, tag, innerNode);
  }
  hashCode() {
    var result = getStringHashCode(this.v4y_1);
    result = imul(result, 31) + hashCode(this.w4y_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof YamlTaggedNode))
      return false;
    var tmp0_other_with_cast = other instanceof YamlTaggedNode ? other : THROW_CCE();
    if (!(this.v4y_1 === tmp0_other_with_cast.v4y_1))
      return false;
    if (!equals(this.w4y_1, tmp0_other_with_cast.w4y_1))
      return false;
    return true;
  }
}
class YamlNodeReader {
  constructor(parser, extensionDefinitionPrefix, maxAliasCount) {
    extensionDefinitionPrefix = extensionDefinitionPrefix === VOID ? null : extensionDefinitionPrefix;
    maxAliasCount = maxAliasCount === VOID ? _UInt___init__impl__l7qpdl(0) : maxAliasCount;
    this.w4o_1 = parser;
    this.x4o_1 = extensionDefinitionPrefix;
    this.y4o_1 = maxAliasCount;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.z4o_1 = LinkedHashMap.hc();
    this.a4p_1 = _UInt___init__impl__l7qpdl(0);
  }
  n3t() {
    return readNode(this, Companion_getInstance_9().z50_1).w50_1;
  }
}
class WeightedNode {
  constructor(node, weight) {
    this.w50_1 = node;
    this.x50_1 = weight;
  }
  tl() {
    return this.w50_1;
  }
  y50() {
    return this.x50_1;
  }
  l51(node, weight) {
    return new WeightedNode(node, weight);
  }
  c51(node, weight, $super) {
    node = node === VOID ? this.w50_1 : node;
    weight = weight === VOID ? this.x50_1 : weight;
    return $super === VOID ? this.l51(node, weight) : $super.l51.call(this, node, new UInt(weight));
  }
  toString() {
    return 'WeightedNode(node=' + toString(this.w50_1) + ', weight=' + new UInt(this.x50_1) + ')';
  }
  hashCode() {
    var result = hashCode(this.w50_1);
    result = imul(result, 31) + UInt__hashCode_impl_z2mhuw(this.x50_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof WeightedNode))
      return false;
    var tmp0_other_with_cast = other instanceof WeightedNode ? other : THROW_CCE();
    if (!equals(this.w50_1, tmp0_other_with_cast.w50_1))
      return false;
    if (!(this.x50_1 === tmp0_other_with_cast.x50_1))
      return false;
    return true;
  }
}
class YamlMapDescriptor {
  constructor() {
    YamlMapDescriptor_instance = this;
    this.m51_1 = MapSerializer(YamlScalarSerializer_getInstance(), YamlNodeSerializer_getInstance()).w1t();
    this.n51_1 = 'com.charleskorn.kaml.YamlMap';
  }
  z1u() {
    return this.n51_1;
  }
  n1w(index) {
    return this.m51_1.n1w(index);
  }
  o1w(name) {
    return this.m51_1.o1w(name);
  }
  p1w(index) {
    return this.m51_1.p1w(index);
  }
  q1w(index) {
    return this.m51_1.q1w(index);
  }
  r1w(index) {
    return this.m51_1.r1w(index);
  }
  j1w() {
    return this.m51_1.j1w();
  }
  f1w() {
    return this.m51_1.f1w();
  }
  k1w() {
    return this.m51_1.k1w();
  }
  l1w() {
    return this.m51_1.l1w();
  }
  m1w() {
    return this.m51_1.m1w();
  }
}
class YamlMapSerializer {
  constructor() {
    YamlMapSerializer_instance = this;
    this.o51_1 = YamlMapDescriptor_getInstance();
  }
  w1t() {
    return this.o51_1;
  }
  p51(encoder, value) {
    asYamlOutput(encoder);
    MapSerializer(YamlScalarSerializer_getInstance(), YamlNodeSerializer_getInstance()).x1t(encoder, value.o4y_1);
  }
  x1t(encoder, value) {
    return this.p51(encoder, value instanceof YamlMap ? value : THROW_CCE());
  }
  y1t(decoder) {
    // Inline function 'com.charleskorn.kaml.asYamlInput' call
    var tmp0 = decoder instanceof YamlMapInput ? decoder : null;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (tmp0 == null) {
        var message = 'This serializer can be used only with Yaml format. Expected Decoder to be ' + getKClass(YamlMapInput).hf() + ', got ' + toString(getKClassFromExpression(decoder));
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp$ret$1 = tmp0;
        break $l$block;
      }
    }
    var input = tmp$ret$1;
    var tmp = input.p4p_1;
    return tmp instanceof YamlMap ? tmp : THROW_CCE();
  }
}
class YamlNodeSerializer {
  constructor() {
    YamlNodeSerializer_instance = this;
    var tmp = this;
    var tmp_0 = SEALED_getInstance();
    tmp.q51_1 = get_nullable(buildSerialDescriptor('com.charleskorn.kaml.YamlNode', tmp_0, [], YamlNodeSerializer$descriptor$lambda));
  }
  w1t() {
    return this.q51_1;
  }
  r51(encoder, value) {
    asYamlOutput(encoder);
    if (value instanceof YamlList) {
      encoder.y1z(YamlListSerializer_getInstance(), value);
    } else {
      if (value instanceof YamlMap) {
        encoder.y1z(YamlMapSerializer_getInstance(), value);
      } else {
        if (value instanceof YamlNull) {
          encoder.y1z(YamlNullSerializer_getInstance(), value);
        } else {
          if (value instanceof YamlScalar) {
            encoder.y1z(YamlScalarSerializer_getInstance(), value);
          } else {
            if (value instanceof YamlTaggedNode) {
              encoder.y1z(YamlTaggedNodeSerializer_getInstance(), value);
            } else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
  }
  x1t(encoder, value) {
    return this.r51(encoder, value instanceof YamlNode ? value : THROW_CCE());
  }
  y1t(decoder) {
    // Inline function 'com.charleskorn.kaml.asYamlInput' call
    var tmp0 = decoder instanceof YamlInput ? decoder : null;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (tmp0 == null) {
        var message = 'This serializer can be used only with Yaml format. Expected Decoder to be ' + getKClass(YamlInput).hf() + ', got ' + toString(getKClassFromExpression(decoder));
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp$ret$1 = tmp0;
        break $l$block;
      }
    }
    var input = tmp$ret$1;
    var tmp;
    if (input instanceof YamlPolymorphicInput) {
      tmp = new YamlTaggedNode(input.w51_1, input.p4p_1);
    } else {
      tmp = input.p4p_1;
    }
    return tmp;
  }
}
class YamlScalarSerializer {
  constructor() {
    YamlScalarSerializer_instance = this;
    this.b52_1 = PrimitiveSerialDescriptor('com.charleskorn.kaml.YamlScalar', STRING_getInstance());
  }
  w1t() {
    return this.b52_1;
  }
  c52(encoder, value) {
    asYamlOutput(encoder);
    var tmp0_safe_receiver = value.o50();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.also' call
      return encoder.c1z(tmp0_safe_receiver);
    }
    var tmp1_safe_receiver = value.k50();
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.also' call
      return encoder.g1z(tmp1_safe_receiver);
    }
    var tmp2_safe_receiver = value.m50();
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.also' call
      return encoder.i1z(tmp2_safe_receiver);
    }
    var tmp3_safe_receiver = value.q50();
    var tmp = tmp3_safe_receiver;
    if ((tmp == null ? null : new Char(tmp)) == null)
      null;
    else {
      var tmp_0 = tmp3_safe_receiver;
      // Inline function 'kotlin.also' call
      var it = (tmp_0 == null ? null : new Char(tmp_0)).j2_1;
      return encoder.j1z(it);
    }
    encoder.k1z(value.j4y_1);
  }
  x1t(encoder, value) {
    return this.c52(encoder, value instanceof YamlScalar ? value : THROW_CCE());
  }
  y1t(decoder) {
    // Inline function 'com.charleskorn.kaml.asYamlInput' call
    var tmp0 = decoder instanceof YamlScalarInput ? decoder : null;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (tmp0 == null) {
        var message = 'This serializer can be used only with Yaml format. Expected Decoder to be ' + getKClass(YamlScalarInput).hf() + ', got ' + toString(getKClassFromExpression(decoder));
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp$ret$1 = tmp0;
        break $l$block;
      }
    }
    var result = tmp$ret$1;
    return result.m4q_1;
  }
}
class YamlListDescriptor {
  constructor() {
    YamlListDescriptor_instance = this;
    this.d52_1 = ListSerializer(YamlNodeSerializer_getInstance()).w1t();
    this.e52_1 = 'com.charleskorn.kaml.YamlList';
  }
  z1u() {
    return this.e52_1;
  }
  n1w(index) {
    return this.d52_1.n1w(index);
  }
  o1w(name) {
    return this.d52_1.o1w(name);
  }
  p1w(index) {
    return this.d52_1.p1w(index);
  }
  q1w(index) {
    return this.d52_1.q1w(index);
  }
  r1w(index) {
    return this.d52_1.r1w(index);
  }
  j1w() {
    return this.d52_1.j1w();
  }
  f1w() {
    return this.d52_1.f1w();
  }
  k1w() {
    return this.d52_1.k1w();
  }
  l1w() {
    return this.d52_1.l1w();
  }
  m1w() {
    return this.d52_1.m1w();
  }
}
class YamlListSerializer {
  constructor() {
    YamlListSerializer_instance = this;
    this.f52_1 = YamlListDescriptor_getInstance();
  }
  w1t() {
    return this.f52_1;
  }
  g52(encoder, value) {
    asYamlOutput(encoder);
    ListSerializer(YamlNodeSerializer_getInstance()).x1t(encoder, value.r4y_1);
  }
  x1t(encoder, value) {
    return this.g52(encoder, value instanceof YamlList ? value : THROW_CCE());
  }
  y1t(decoder) {
    // Inline function 'com.charleskorn.kaml.asYamlInput' call
    var tmp0 = decoder instanceof YamlListInput ? decoder : null;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (tmp0 == null) {
        var message = 'This serializer can be used only with Yaml format. Expected Decoder to be ' + getKClass(YamlListInput).hf() + ', got ' + toString(getKClassFromExpression(decoder));
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp$ret$1 = tmp0;
        break $l$block;
      }
    }
    var input = tmp$ret$1;
    return input.b4z_1;
  }
}
class YamlNullSerializer {
  constructor() {
    YamlNullSerializer_instance = this;
    this.h52_1 = buildSerialDescriptor('com.charleskorn.kaml.YamlNull', ENUM_getInstance(), []);
  }
  w1t() {
    return this.h52_1;
  }
  i52(encoder, value) {
    asYamlOutput(encoder).b1z();
  }
  x1t(encoder, value) {
    return this.i52(encoder, value instanceof YamlNull ? value : THROW_CCE());
  }
  y1t(decoder) {
    // Inline function 'com.charleskorn.kaml.asYamlInput' call
    var tmp0 = decoder instanceof YamlNullInput ? decoder : null;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (tmp0 == null) {
        var message = 'This serializer can be used only with Yaml format. Expected Decoder to be ' + getKClass(YamlNullInput).hf() + ', got ' + toString(getKClassFromExpression(decoder));
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp$ret$1 = tmp0;
        break $l$block;
      }
    }
    var input = tmp$ret$1;
    return input.q52_1;
  }
}
class YamlTaggedNodeSerializer {
  constructor() {
    YamlTaggedNodeSerializer_instance = this;
    var tmp = this;
    var tmp_0 = OPEN_getInstance();
    tmp.r52_1 = buildSerialDescriptor('com.charleskorn.kaml.YamlTaggedNode', tmp_0, [], YamlTaggedNodeSerializer$descriptor$lambda);
  }
  w1t() {
    return this.r52_1;
  }
  s52(encoder, value) {
    var tmp0 = asYamlOutput(encoder);
    // Inline function 'kotlinx.serialization.encoding.encodeStructure' call
    var descriptor = this.r52_1;
    var composite = tmp0.f1y(descriptor);
    composite.v1z(YamlTaggedNodeSerializer_getInstance().r52_1, 0, value.v4y_1);
    composite.x1z(YamlTaggedNodeSerializer_getInstance().r52_1, 1, YamlNodeSerializer_getInstance(), value.w4y_1);
    composite.g1y(descriptor);
  }
  x1t(encoder, value) {
    return this.s52(encoder, value instanceof YamlTaggedNode ? value : THROW_CCE());
  }
  y1t(decoder) {
    // Inline function 'com.charleskorn.kaml.asYamlInput' call
    var tmp0 = decoder instanceof YamlPolymorphicInput ? decoder : null;
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.checkNotNull' call
      if (tmp0 == null) {
        var message = 'This serializer can be used only with Yaml format. Expected Decoder to be ' + getKClass(YamlPolymorphicInput).hf() + ', got ' + toString(getKClassFromExpression(decoder));
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp$ret$1 = tmp0;
        break $l$block;
      }
    }
    var input = tmp$ret$1;
    return new YamlTaggedNode(input.w51_1, input.y51_1);
  }
}
class YamlNullInput extends YamlInput {
  constructor(nullValue, yaml, context, configuration) {
    super(nullValue, yaml, context, configuration);
    this.q52_1 = nullValue;
  }
  q1x() {
    return false;
  }
  p1x() {
    throw UnexpectedNullValueException.h4q(this.q52_1.u4p_1);
  }
  x1y(descriptor) {
    throw UnexpectedNullValueException.h4q(this.q52_1.u4p_1);
  }
  f1y(descriptor) {
    throw UnexpectedNullValueException.h4q(this.q52_1.u4p_1);
  }
  w1y(descriptor) {
    return -1;
  }
}
class YamlObjectInput extends YamlMapLikeInputBase {
  constructor(map, yaml, context, configuration) {
    super(map, yaml, context, configuration);
    this.a53_1 = toList(map.o4y_1.l1());
    this.b53_1 = 0;
  }
  w1y(descriptor) {
    if (!!(this.c53_1 == null)) {
      var tmp = this;
      // Inline function 'kotlin.collections.associateBy' call
      var this_0 = until(0, descriptor.l1w());
      var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(this_0, 10)), 16);
      // Inline function 'kotlin.collections.associateByTo' call
      var destination = LinkedHashMap.ic(capacity);
      var inductionVariable = this_0.t1_1;
      var last = this_0.u1_1;
      if (inductionVariable <= last)
        do {
          var element = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var index = element;
          var elementName = descriptor.n1w(index);
          var tmp0_safe_receiver = this.s4p_1.s4o_1;
          var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.d53(elementName);
          var tmp$ret$0 = tmp1_elvis_lhs == null ? elementName : tmp1_elvis_lhs;
          destination.k3(tmp$ret$0, element);
        }
         while (!(element === last));
      tmp.c53_1 = destination;
    }
    $l$loop: while (true) {
      if (this.b53_1 === this.a53_1.b1()) {
        return -1;
      }
      var currentEntry = this.a53_1.f1(this.b53_1);
      this.t4z_1 = currentEntry.m1();
      var tmp0_elvis_lhs = _get_pairedPropertyNames__11quvr(this).h3(this.v4z());
      var fieldDescriptorIndex = tmp0_elvis_lhs == null ? -3 : tmp0_elvis_lhs;
      if (fieldDescriptorIndex === -3) {
        if (this.s4p_1.g4o_1) {
          throw UnknownPropertyException.h4y(this.v4z(), _get_pairedPropertyNames__11quvr(this).i3(), this.w4z().k4y_1);
        } else {
          this.b53_1 = this.b53_1 + 1 | 0;
          continue $l$loop;
        }
      }
      try {
        this.s4z_1 = Companion_getInstance_1().o4q(this.a53_1.f1(this.b53_1).n1(), this.q4p_1, this.u1y(), this.s4p_1, descriptor.q1w(fieldDescriptorIndex));
      } catch ($p) {
        if ($p instanceof IncorrectTypeException) {
          var e = $p;
          throw InvalidPropertyValueException.z4t(this.v4z(), e.h2(), e.o4r_1, e);
        } else {
          throw $p;
        }
      }
      this.u4z_1 = true;
      this.b53_1 = this.b53_1 + 1 | 0;
      return fieldDescriptorIndex;
    }
  }
  f1y(descriptor) {
    if (this.y4z()) {
      return this.x4z(YamlObjectInput$beginStructure$lambda(descriptor));
    }
    return super.f1y(descriptor);
  }
}
class Companion_7 {
  constructor() {
    Companion_instance_8 = this;
    this.e53_1 = new ImplicitTuple(true, true);
    this.f53_1 = new ImplicitTuple(false, false);
  }
}
class YamlOutput extends AbstractEncoder {
  b1z() {
    return emitPlainScalar(this, 'null');
  }
}
class YamlParser {
  constructor(reader, codePointLimit) {
    codePointLimit = codePointLimit === VOID ? null : codePointLimit;
    this.b4p_1 = 'DUMMY_FILE_NAME';
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = Companion_instance.g21();
    if (!(codePointLimit == null)) {
      this_0.h47(codePointLimit);
    }
    this_0.g47(this.b4p_1);
    tmp.c4p_1 = this_0.w2o();
    this.d4p_1 = new StreamReader(this.c4p_1, reader);
    this.e4p_1 = ParserImpl.b4k(this.c4p_1, this.d4p_1);
    this.f51(ID_StreamStart_getInstance(), Companion_getInstance_9().z50_1);
    if (this.d51(Companion_getInstance_9().z50_1).g4b().equals(ID_StreamEnd_getInstance())) {
      throw EmptyYamlDocumentException.a4v('The YAML document is empty.', Companion_getInstance_9().z50_1);
    }
    this.f51(ID_DocumentStart_getInstance(), Companion_getInstance_9().z50_1);
  }
  f4p() {
    this.f51(ID_DocumentEnd_getInstance(), Companion_getInstance_9().z50_1);
    this.f51(ID_StreamEnd_getInstance(), Companion_getInstance_9().z50_1);
  }
  v50(path) {
    return checkEvent(this, path, YamlParser$consumeEvent$lambda(this));
  }
  d51(path) {
    return checkEvent(this, path, YamlParser$peekEvent$lambda(this));
  }
  f51(type, path) {
    var event = this.v50(path);
    if (!event.g4b().equals(type)) {
      throw MalformedYamlException.n4v('Unexpected ' + event.g4b().toString() + ', expected ' + type.toString(), path.b51(new Location(ensureNotNull(event.k4b_1).i4e_1, ensureNotNull(event.k4b_1).j4e_1)));
    }
  }
}
class Companion_8 {
  constructor() {
    Companion_instance_9 = this;
    this.z50_1 = YamlPath.h53([Root_getInstance()]);
  }
  a51(name, location) {
    return YamlPath.h53([new AliasDefinition(name, location)]);
  }
}
class YamlPath {
  static h50(segments) {
    Companion_getInstance_9();
    var $this = createThis(this);
    $this.h4r_1 = segments;
    if ($this.h4r_1.h1()) {
      throw IllegalArgumentException.t('Path must contain at least one segment.');
    }
    var tmp;
    var tmp_0 = first($this.h4r_1);
    if (!(tmp_0 instanceof Root)) {
      var tmp_1 = first($this.h4r_1);
      tmp = !(tmp_1 instanceof AliasDefinition);
    } else {
      tmp = false;
    }
    if (tmp) {
      throw IllegalArgumentException.t('First element of path must be root segment or alias definition.');
    }
    if (drop($this.h4r_1, 1).v2(Root_getInstance())) {
      throw IllegalArgumentException.t('Root segment can only be first element of path.');
    }
    $this.i4r_1 = last($this.h4r_1).b50();
    return $this;
  }
  static h53(segments) {
    Companion_getInstance_9();
    return this.h50(toList_0(segments));
  }
  b51(location) {
    return withSegment(this, new Error_0(location));
  }
  e51(index, location) {
    return withSegment(this, new ListEntry(index, location));
  }
  g51(key, location) {
    return withSegment(this, new MapElementKey(key, location));
  }
  h51(location) {
    return withSegment(this, new MapElementValue(location));
  }
  j51(name, location) {
    return withSegment(this, new AliasReference(name, location));
  }
  k51(name, location) {
    return withSegment(this, new AliasDefinition(name, location));
  }
  i51(location) {
    return withSegment(this, new Merge(location));
  }
  w4s() {
    var builder = StringBuilder.v();
    var nextSegmentIndex = 1;
    while (nextSegmentIndex <= get_lastIndex(this.h4r_1)) {
      var segmentIndex = nextSegmentIndex;
      nextSegmentIndex = nextSegmentIndex + 1 | 0;
      var segment = this.h4r_1.f1(segmentIndex);
      if (segment instanceof ListEntry) {
        builder.ub(_Char___init__impl__6a9atx(91));
        builder.fh(segment.k53_1);
        builder.ub(_Char___init__impl__6a9atx(93));
      } else {
        if (segment instanceof MapElementKey) {
          // Inline function 'kotlin.text.isNotEmpty' call
          if (charSequenceLength(builder) > 0) {
            builder.ub(_Char___init__impl__6a9atx(46));
          }
          builder.tb(segment.q53_1);
        } else {
          if (segment instanceof AliasReference) {
            builder.tb('->&');
            builder.tb(segment.n53_1);
          } else {
            if (segment instanceof Merge) {
              builder.tb('>>(merged');
              var tmp;
              if (nextSegmentIndex <= get_lastIndex(this.h4r_1)) {
                var tmp_0 = this.h4r_1.f1(nextSegmentIndex);
                tmp = tmp_0 instanceof ListEntry;
              } else {
                tmp = false;
              }
              if (tmp) {
                builder.tb(' entry ');
                var tmp_1 = this.h4r_1.f1(nextSegmentIndex);
                builder.fh((tmp_1 instanceof ListEntry ? tmp_1 : THROW_CCE()).k53_1);
                nextSegmentIndex = nextSegmentIndex + 1 | 0;
              }
              var tmp_2;
              if (nextSegmentIndex <= get_lastIndex(this.h4r_1)) {
                var tmp_3 = this.h4r_1.f1(nextSegmentIndex);
                tmp_2 = tmp_3 instanceof AliasReference;
              } else {
                tmp_2 = false;
              }
              if (tmp_2) {
                builder.tb(' &');
                var tmp_4 = this.h4r_1.f1(nextSegmentIndex);
                builder.tb((tmp_4 instanceof AliasReference ? tmp_4 : THROW_CCE()).n53_1);
                nextSegmentIndex = nextSegmentIndex + 1 | 0;
              }
              builder.tb(')');
            } else {
              var tmp_5;
              var tmp_6;
              if (segment instanceof Root) {
                tmp_6 = true;
              } else {
                tmp_6 = segment instanceof Error_0;
              }
              if (tmp_6) {
                tmp_5 = true;
              } else {
                var tmp_7;
                if (segment instanceof MapElementValue) {
                  tmp_7 = true;
                } else {
                  tmp_7 = segment instanceof AliasDefinition;
                }
                tmp_5 = tmp_7;
              }
              if (!tmp_5) {
                noWhenBranchMatchedException();
              }
            }
          }
        }
      }
    }
    // Inline function 'kotlin.text.isNotEmpty' call
    if (charSequenceLength(builder) > 0) {
      return builder.toString();
    }
    return '<root>';
  }
  toString() {
    return 'YamlPath(segments=' + toString(this.h4r_1) + ')';
  }
  hashCode() {
    return hashCode(this.h4r_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof YamlPath))
      return false;
    var tmp0_other_with_cast = other instanceof YamlPath ? other : THROW_CCE();
    if (!equals(this.h4r_1, tmp0_other_with_cast.h4r_1))
      return false;
    return true;
  }
}
class YamlPathSegment {
  constructor(location) {
    this.i53_1 = location;
  }
  b50() {
    return this.i53_1;
  }
}
class Root extends YamlPathSegment {
  constructor() {
    Root_instance = null;
    super(new Location(1, 1));
    Root_instance = this;
  }
}
class ListEntry extends YamlPathSegment {
  constructor(index, location) {
    super(location);
    this.k53_1 = index;
    this.l53_1 = location;
  }
  b50() {
    return this.l53_1;
  }
  toString() {
    return 'ListEntry(index=' + this.k53_1 + ', location=' + this.l53_1.toString() + ')';
  }
  hashCode() {
    var result = this.k53_1;
    result = imul(result, 31) + this.l53_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ListEntry))
      return false;
    var tmp0_other_with_cast = other instanceof ListEntry ? other : THROW_CCE();
    if (!(this.k53_1 === tmp0_other_with_cast.k53_1))
      return false;
    if (!this.l53_1.equals(tmp0_other_with_cast.l53_1))
      return false;
    return true;
  }
}
class MapElementKey extends YamlPathSegment {
  constructor(key, location) {
    super(location);
    this.q53_1 = key;
    this.r53_1 = location;
  }
  b50() {
    return this.r53_1;
  }
  toString() {
    return 'MapElementKey(key=' + this.q53_1 + ', location=' + this.r53_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.q53_1);
    result = imul(result, 31) + this.r53_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MapElementKey))
      return false;
    var tmp0_other_with_cast = other instanceof MapElementKey ? other : THROW_CCE();
    if (!(this.q53_1 === tmp0_other_with_cast.q53_1))
      return false;
    if (!this.r53_1.equals(tmp0_other_with_cast.r53_1))
      return false;
    return true;
  }
}
class MapElementValue extends YamlPathSegment {
  constructor(location) {
    super(location);
    this.t53_1 = location;
  }
  b50() {
    return this.t53_1;
  }
  toString() {
    return 'MapElementValue(location=' + this.t53_1.toString() + ')';
  }
  hashCode() {
    return this.t53_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MapElementValue))
      return false;
    var tmp0_other_with_cast = other instanceof MapElementValue ? other : THROW_CCE();
    if (!this.t53_1.equals(tmp0_other_with_cast.t53_1))
      return false;
    return true;
  }
}
class AliasReference extends YamlPathSegment {
  constructor(name, location) {
    super(location);
    this.n53_1 = name;
    this.o53_1 = location;
  }
  b50() {
    return this.o53_1;
  }
  toString() {
    return 'AliasReference(name=' + this.n53_1 + ', location=' + this.o53_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.n53_1);
    result = imul(result, 31) + this.o53_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AliasReference))
      return false;
    var tmp0_other_with_cast = other instanceof AliasReference ? other : THROW_CCE();
    if (!(this.n53_1 === tmp0_other_with_cast.n53_1))
      return false;
    if (!this.o53_1.equals(tmp0_other_with_cast.o53_1))
      return false;
    return true;
  }
}
class AliasDefinition extends YamlPathSegment {
  constructor(name, location) {
    super(location);
    this.v53_1 = name;
    this.w53_1 = location;
  }
  b50() {
    return this.w53_1;
  }
  toString() {
    return 'AliasDefinition(name=' + this.v53_1 + ', location=' + this.w53_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.v53_1);
    result = imul(result, 31) + this.w53_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AliasDefinition))
      return false;
    var tmp0_other_with_cast = other instanceof AliasDefinition ? other : THROW_CCE();
    if (!(this.v53_1 === tmp0_other_with_cast.v53_1))
      return false;
    if (!this.w53_1.equals(tmp0_other_with_cast.w53_1))
      return false;
    return true;
  }
}
class Merge extends YamlPathSegment {
  constructor(location) {
    super(location);
    this.y53_1 = location;
  }
  b50() {
    return this.y53_1;
  }
  toString() {
    return 'Merge(location=' + this.y53_1.toString() + ')';
  }
  hashCode() {
    return this.y53_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Merge))
      return false;
    var tmp0_other_with_cast = other instanceof Merge ? other : THROW_CCE();
    if (!this.y53_1.equals(tmp0_other_with_cast.y53_1))
      return false;
    return true;
  }
}
class Error_0 extends YamlPathSegment {
  constructor(location) {
    super(location);
    this.a54_1 = location;
  }
  b50() {
    return this.a54_1;
  }
  toString() {
    return 'Error(location=' + this.a54_1.toString() + ')';
  }
  hashCode() {
    return this.a54_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Error_0))
      return false;
    var tmp0_other_with_cast = other instanceof Error_0 ? other : THROW_CCE();
    if (!this.a54_1.equals(tmp0_other_with_cast.a54_1))
      return false;
    return true;
  }
}
class CurrentField extends Enum {}
class Companion_9 {
  constructor() {
    Companion_instance_10 = this;
    var tmp = this;
    // Inline function 'kotlin.text.toRegex' call
    var this_0 = "^Serializer for subclass '(.*)' is not found in the polymorphic scope of '(.*)'.\\n.*";
    tmp.b54_1 = Regex.xh(this_0);
  }
}
class YamlPolymorphicInput$getKnownTypesForOpenType$1 {
  constructor($className, $knownTypes) {
    this.c54_1 = $className;
    this.d54_1 = $knownTypes;
  }
  p2f(kClass, provider) {
  }
  s2f(baseClass, actualClass, actualSerializer) {
    if (baseClass.hf() === this.c54_1) {
      this.d54_1.l(actualSerializer.w1t().z1u());
    }
  }
  t2f(baseClass, defaultSerializerProvider) {
    throw UnsupportedOperationException.da('This method should never be called.');
  }
  u2f(baseClass, defaultDeserializerProvider) {
    throw UnsupportedOperationException.da('This method should never be called');
  }
}
class YamlPolymorphicInput extends YamlInput {
  constructor(typeName, typeNamePath, contentNode, yaml, context, configuration) {
    Companion_getInstance_10();
    super(contentNode, yaml, context, configuration);
    this.w51_1 = typeName;
    this.x51_1 = typeNamePath;
    this.y51_1 = contentNode;
    this.z51_1 = CurrentField_NotStarted_getInstance();
  }
  w1y(descriptor) {
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
        this.z51_1 = CurrentField_Type_getInstance();
        tmp = 0;
        break;
      case 1:
        var tmp1_subject = this.y51_1;
        if (tmp1_subject instanceof YamlScalar)
          this.a52_1 = new YamlScalarInput(this.y51_1, this.q4p_1, this.u1y(), this.s4p_1);
        else {
          if (tmp1_subject instanceof YamlNull)
            this.a52_1 = new YamlNullInput(this.y51_1, this.q4p_1, this.u1y(), this.s4p_1);
        }

        this.z51_1 = CurrentField_Content_getInstance();
        tmp = 1;
        break;
      case 2:
        tmp = -1;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  q1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        tmp = true;
        break;
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).q1x();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  r1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeNull';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).r1x();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  s1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeBoolean';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).s1x();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  t1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeByte';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).t1x();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  u1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeShort';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).u1x();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  v1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeInt';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).v1x();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  w1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeLong';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).w1x();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  x1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeFloat';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).x1x();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  y1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeDouble';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).y1x();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  z1x() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeChar';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        var tmp$ret$0 = _get_contentDecoder__ypxfj4(this).z1x();
        tmp = new Char(tmp$ret$0);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp.j2_1;
  }
  a1y() {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        tmp = this.w51_1;
        break;
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).a1y();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  b1y(enumDescriptor) {
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var functionName = 'decodeEnum';
    // Inline function 'com.charleskorn.kaml.YamlPolymorphicInput.maybeCallOnContent' call
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        throw UnsupportedOperationException.da("Can't call " + functionName + '() on type field');
      case 2:
        tmp = _get_contentDecoder__ypxfj4(this).b1y(enumDescriptor);
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  f1y(descriptor) {
    var tmp;
    switch (this.z51_1.o3_1) {
      case 0:
      case 1:
        tmp = super.f1y(descriptor);
        break;
      case 2:
        this.a52_1 = Companion_getInstance_1().o4q(this.y51_1, this.q4p_1, this.u1y(), this.s4p_1, descriptor);
        return _get_contentDecoder__ypxfj4(this);
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  e1y(deserializer) {
    try {
      return super.e1y(deserializer);
    } catch ($p) {
      if ($p instanceof SerializationException) {
        var e = $p;
        throwIfUnknownPolymorphicTypeException(this, e, deserializer);
        throw e;
      } else {
        throw $p;
      }
    }
  }
}
class YamlScalarInput extends YamlInput {
  constructor(scalar, yaml, context, configuration) {
    super(scalar, yaml, context, configuration);
    this.m4q_1 = scalar;
  }
  a1y() {
    return this.m4q_1.j4y_1;
  }
  v1x() {
    return this.m4q_1.x1();
  }
  w1x() {
    return this.m4q_1.j50();
  }
  u1x() {
    return this.m4q_1.l4();
  }
  t1x() {
    return this.m4q_1.k4();
  }
  y1x() {
    return this.m4q_1.m4();
  }
  x1x() {
    return this.m4q_1.l50();
  }
  s1x() {
    return this.m4q_1.n50();
  }
  z1x() {
    return this.m4q_1.p50();
  }
  b1y(enumDescriptor) {
    var index = enumDescriptor.o1w(this.m4q_1.j4y_1);
    if (!(index === -3)) {
      return index;
    }
    var tmp = asSequence(until(0, enumDescriptor.l1w()));
    var choices = map(tmp, YamlScalarInput$decodeEnum$lambda(enumDescriptor));
    if (this.s4p_1.u4o_1) {
      var tmp$ret$1;
      $l$block: {
        // Inline function 'kotlin.sequences.indexOfFirst' call
        var index_0 = 0;
        var _iterator__ex2g4s = choices.y();
        while (_iterator__ex2g4s.z()) {
          var item = _iterator__ex2g4s.a1();
          checkIndexOverflow(index_0);
          if (equals_0(item, this.m4q_1.j4y_1, true)) {
            tmp$ret$1 = index_0;
            break $l$block;
          }
          index_0 = index_0 + 1 | 0;
        }
        tmp$ret$1 = -1;
      }
      var idx = tmp$ret$1;
      if (!(idx === -1)) {
        return idx;
      }
    }
    throw YamlScalarFormatException.v4s('Value ' + this.m4q_1.c50() + ' is not a valid option, permitted choices are: ' + joinToString_0(sorted_0(choices), ', '), this.m4q_1.k4y_1, this.m4q_1.j4y_1);
  }
  w1y(descriptor) {
    return 0;
  }
}
//endregion
var Companion_instance_0;
function Companion_getInstance_0() {
  if (Companion_instance_0 === VOID)
    new Companion();
  return Companion_instance_0;
}
var Forbidden_instance;
function Forbidden_getInstance() {
  if (Forbidden_instance === VOID)
    new Forbidden();
  return Forbidden_instance;
}
var PolymorphismStyle_Tag_instance;
var PolymorphismStyle_Property_instance;
var PolymorphismStyle_None_instance;
var PolymorphismStyle_entriesInitialized;
function PolymorphismStyle_initEntries() {
  if (PolymorphismStyle_entriesInitialized)
    return Unit_instance;
  PolymorphismStyle_entriesInitialized = true;
  PolymorphismStyle_Tag_instance = new PolymorphismStyle('Tag', 0);
  PolymorphismStyle_Property_instance = new PolymorphismStyle('Property', 1);
  PolymorphismStyle_None_instance = new PolymorphismStyle('None', 2);
}
var SequenceStyle_Block_instance;
var SequenceStyle_Flow_instance;
var SequenceStyle_entriesInitialized;
function SequenceStyle_initEntries() {
  if (SequenceStyle_entriesInitialized)
    return Unit_instance;
  SequenceStyle_entriesInitialized = true;
  SequenceStyle_Block_instance = new SequenceStyle('Block', 0);
  SequenceStyle_Flow_instance = new SequenceStyle('Flow', 1);
}
var SingleLineStringStyle_DoubleQuoted_instance;
var SingleLineStringStyle_SingleQuoted_instance;
var SingleLineStringStyle_Plain_instance;
var SingleLineStringStyle_PlainExceptAmbiguous_instance;
var SingleLineStringStyle_entriesInitialized;
function SingleLineStringStyle_initEntries() {
  if (SingleLineStringStyle_entriesInitialized)
    return Unit_instance;
  SingleLineStringStyle_entriesInitialized = true;
  SingleLineStringStyle_DoubleQuoted_instance = new SingleLineStringStyle('DoubleQuoted', 0);
  SingleLineStringStyle_SingleQuoted_instance = new SingleLineStringStyle('SingleQuoted', 1);
  SingleLineStringStyle_Plain_instance = new SingleLineStringStyle('Plain', 2);
  SingleLineStringStyle_PlainExceptAmbiguous_instance = new SingleLineStringStyle('PlainExceptAmbiguous', 3);
}
var MultiLineStringStyle_Literal_instance;
var MultiLineStringStyle_Folded_instance;
var MultiLineStringStyle_DoubleQuoted_instance;
var MultiLineStringStyle_SingleQuoted_instance;
var MultiLineStringStyle_Plain_instance;
var MultiLineStringStyle_entriesInitialized;
function MultiLineStringStyle_initEntries() {
  if (MultiLineStringStyle_entriesInitialized)
    return Unit_instance;
  MultiLineStringStyle_entriesInitialized = true;
  MultiLineStringStyle_Literal_instance = new MultiLineStringStyle('Literal', 0);
  MultiLineStringStyle_Folded_instance = new MultiLineStringStyle('Folded', 1);
  MultiLineStringStyle_DoubleQuoted_instance = new MultiLineStringStyle('DoubleQuoted', 2);
  MultiLineStringStyle_SingleQuoted_instance = new MultiLineStringStyle('SingleQuoted', 3);
  MultiLineStringStyle_Plain_instance = new MultiLineStringStyle('Plain', 4);
}
var AmbiguousQuoteStyle_DoubleQuoted_instance;
var AmbiguousQuoteStyle_SingleQuoted_instance;
var AmbiguousQuoteStyle_entriesInitialized;
function AmbiguousQuoteStyle_initEntries() {
  if (AmbiguousQuoteStyle_entriesInitialized)
    return Unit_instance;
  AmbiguousQuoteStyle_entriesInitialized = true;
  AmbiguousQuoteStyle_DoubleQuoted_instance = new AmbiguousQuoteStyle('DoubleQuoted', 0);
  AmbiguousQuoteStyle_SingleQuoted_instance = new AmbiguousQuoteStyle('SingleQuoted', 1);
}
function PolymorphismStyle_Tag_getInstance() {
  PolymorphismStyle_initEntries();
  return PolymorphismStyle_Tag_instance;
}
function PolymorphismStyle_None_getInstance() {
  PolymorphismStyle_initEntries();
  return PolymorphismStyle_None_instance;
}
function SequenceStyle_Block_getInstance() {
  SequenceStyle_initEntries();
  return SequenceStyle_Block_instance;
}
function SingleLineStringStyle_DoubleQuoted_getInstance() {
  SingleLineStringStyle_initEntries();
  return SingleLineStringStyle_DoubleQuoted_instance;
}
function MultiLineStringStyle_DoubleQuoted_getInstance() {
  MultiLineStringStyle_initEntries();
  return MultiLineStringStyle_DoubleQuoted_instance;
}
function MultiLineStringStyle_SingleQuoted_getInstance() {
  MultiLineStringStyle_initEntries();
  return MultiLineStringStyle_SingleQuoted_instance;
}
function MultiLineStringStyle_Plain_getInstance() {
  MultiLineStringStyle_initEntries();
  return MultiLineStringStyle_Plain_instance;
}
function AmbiguousQuoteStyle_DoubleQuoted_getInstance() {
  AmbiguousQuoteStyle_initEntries();
  return AmbiguousQuoteStyle_DoubleQuoted_instance;
}
function createContextual($this, node, yaml, context, configuration, descriptor) {
  var tmp0_safe_receiver = getContextualDescriptor(context, descriptor);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = Companion_getInstance_1().o4q(node, yaml, context, configuration, tmp0_safe_receiver);
  }
  var tmp1_elvis_lhs = tmp;
  return tmp1_elvis_lhs == null ? new YamlContextualInput(node, yaml, context, configuration) : tmp1_elvis_lhs;
}
function createPolymorphicMapDeserializer($this, node, yaml, context, configuration) {
  var desiredKey = configuration.j4o_1;
  var typeName = getValue($this, node, desiredKey);
  if (typeName instanceof YamlList)
    throw InvalidPropertyValueException.z4t(desiredKey, 'expected a string, but got a list', typeName.s4y_1);
  else {
    if (typeName instanceof YamlMap)
      throw InvalidPropertyValueException.z4t(desiredKey, 'expected a string, but got a map', typeName.p4y_1);
    else {
      if (typeName instanceof YamlNull)
        throw InvalidPropertyValueException.z4t(desiredKey, 'expected a string, but got a null value', typeName.u4p_1);
      else {
        if (typeName instanceof YamlTaggedNode)
          throw InvalidPropertyValueException.z4t(desiredKey, 'expected a string, but got a tagged value', typeName.m4y());
        else {
          if (typeName instanceof YamlScalar) {
            var remainingProperties = withoutKey($this, node, desiredKey);
            return new YamlPolymorphicInput(typeName.j4y_1, typeName.k4y_1, remainingProperties, yaml, context, configuration);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
  }
}
function getValue($this, _this__u8e3s4, desiredKey) {
  var tmp$ret$2;
  $l$block_0: {
    // Inline function 'com.charleskorn.kaml.YamlMap.get' call
    var tmp0 = _this__u8e3s4.o4y_1.l1();
    var tmp$ret$1;
    $l$block: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s = tmp0.y();
      while (_iterator__ex2g4s.z()) {
        var element = _iterator__ex2g4s.a1();
        if (element.m1().j4y_1 === desiredKey) {
          tmp$ret$1 = element;
          break $l$block;
        }
      }
      tmp$ret$1 = null;
    }
    var tmp0_safe_receiver = tmp$ret$1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.n1();
    var tmp;
    if (tmp1_elvis_lhs == null) {
      tmp$ret$2 = null;
      break $l$block_0;
    } else {
      tmp = tmp1_elvis_lhs;
    }
    var node = tmp;
    var tmp2_elvis_lhs = node instanceof YamlNode ? node : null;
    var tmp_0;
    if (tmp2_elvis_lhs == null) {
      throw IncorrectTypeException.h4s('Expected element to be ' + getKClass(YamlNode).hf() + ' but is ' + getKClassFromExpression(node).hf(), node.m4y());
    } else {
      tmp_0 = tmp2_elvis_lhs;
    }
    tmp$ret$2 = tmp_0;
  }
  var tmp0_elvis_lhs = tmp$ret$2;
  var tmp_1;
  if (tmp0_elvis_lhs == null) {
    throw MissingRequiredPropertyException.n4u(desiredKey, _this__u8e3s4.p4y_1);
  } else {
    tmp_1 = tmp0_elvis_lhs;
  }
  return tmp_1;
}
function withoutKey($this, _this__u8e3s4, key) {
  // Inline function 'kotlin.collections.filterKeys' call
  var this_0 = _this__u8e3s4.o4y_1;
  var result = LinkedHashMap.hc();
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = this_0.l1().y();
  while (_iterator__ex2g4s.z()) {
    var entry = _iterator__ex2g4s.a1();
    if (!(entry.m1().j4y_1 === key)) {
      result.k3(entry.m1(), entry.n1());
    }
  }
  return _this__u8e3s4.t4y(result);
}
function _get_isContentBasedPolymorphic__goffbz($this, _this__u8e3s4) {
  var tmp0 = _this__u8e3s4.m1w();
  var tmp$ret$0;
  $l$block_0: {
    // Inline function 'kotlin.collections.any' call
    var tmp;
    if (isInterface(tmp0, Collection)) {
      tmp = tmp0.h1();
    } else {
      tmp = false;
    }
    if (tmp) {
      tmp$ret$0 = false;
      break $l$block_0;
    }
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element instanceof Marker) {
        tmp$ret$0 = true;
        break $l$block_0;
      }
    }
    tmp$ret$0 = false;
  }
  return tmp$ret$0;
}
var Companion_instance_1;
function Companion_getInstance_1() {
  if (Companion_instance_1 === VOID)
    new Companion_0();
  return Companion_instance_1;
}
function throwIfMissingRequiredPropertyException($this, e) {
  var tmp0_elvis_lhs = Companion_getInstance_1().n4q_1.ai(ensureNotNull(e.message));
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var match = tmp;
  throw MissingRequiredPropertyException.n4u(match.ti().f1(1), $this.p4p_1.m4y(), e);
}
function get_friendlyDescription(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof MAP) {
    tmp = 'a map';
  } else {
    if (_this__u8e3s4 instanceof CLASS) {
      tmp = 'an object';
    } else {
      if (_this__u8e3s4 instanceof OBJECT) {
        tmp = 'an object';
      } else {
        if (_this__u8e3s4 instanceof LIST) {
          tmp = 'a list';
        } else {
          if (_this__u8e3s4 instanceof STRING) {
            tmp = 'a string';
          } else {
            if (_this__u8e3s4 instanceof BOOLEAN) {
              tmp = 'a boolean';
            } else {
              if (_this__u8e3s4 instanceof BYTE) {
                tmp = 'a byte';
              } else {
                if (_this__u8e3s4 instanceof CHAR) {
                  tmp = 'a character';
                } else {
                  if (_this__u8e3s4 instanceof DOUBLE) {
                    tmp = 'a double';
                  } else {
                    if (_this__u8e3s4 instanceof FLOAT) {
                      tmp = 'a float';
                    } else {
                      if (_this__u8e3s4 instanceof INT) {
                        tmp = 'an integer';
                      } else {
                        if (_this__u8e3s4 instanceof SHORT) {
                          tmp = 'a short';
                        } else {
                          if (_this__u8e3s4 instanceof LONG) {
                            tmp = 'a long';
                          } else {
                            if (_this__u8e3s4 instanceof ENUM) {
                              tmp = 'an enumeration value';
                            } else {
                              tmp = 'a ' + _this__u8e3s4.toString() + ' value';
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return tmp;
}
function _get_currentElementDecoder__u73r00($this) {
  var tmp = $this.d4z_1;
  if (!(tmp == null))
    return tmp;
  else {
    throwUninitializedPropertyAccessException('currentElementDecoder');
  }
}
function _get_haveStartedReadingElements__wj0go1($this) {
  return $this.c4z_1 > 0;
}
function _get_currentEntry__q2u5ma($this) {
  var tmp = $this.n4z_1;
  if (!(tmp == null))
    return tmp;
  else {
    throwUninitializedPropertyAccessException('currentEntry');
  }
}
function YamlMapInput$beginStructure$lambda($descriptor) {
  return ($this$fromCurrentValue) => $this$fromCurrentValue.f1y($descriptor);
}
function YamlMapLikeInputBase$decodeNotNullMark$lambda($this$fromCurrentValue) {
  return $this$fromCurrentValue.q1x();
}
function YamlMapLikeInputBase$decodeString$lambda($this$fromCurrentValue) {
  return $this$fromCurrentValue.a1y();
}
function YamlMapLikeInputBase$decodeInt$lambda($this$fromCurrentValue) {
  return $this$fromCurrentValue.v1x();
}
function YamlMapLikeInputBase$decodeLong$lambda($this$fromCurrentValue) {
  return $this$fromCurrentValue.w1x();
}
function YamlMapLikeInputBase$decodeShort$lambda($this$fromCurrentValue) {
  return $this$fromCurrentValue.u1x();
}
function YamlMapLikeInputBase$decodeByte$lambda($this$fromCurrentValue) {
  return $this$fromCurrentValue.t1x();
}
function YamlMapLikeInputBase$decodeDouble$lambda($this$fromCurrentValue) {
  return $this$fromCurrentValue.y1x();
}
function YamlMapLikeInputBase$decodeFloat$lambda($this$fromCurrentValue) {
  return $this$fromCurrentValue.x1x();
}
function YamlMapLikeInputBase$decodeBoolean$lambda($this$fromCurrentValue) {
  return $this$fromCurrentValue.s1x();
}
function YamlMapLikeInputBase$decodeChar$lambda($this$fromCurrentValue) {
  return new Char($this$fromCurrentValue.z1x());
}
function YamlMapLikeInputBase$decodeEnum$lambda($enumDescriptor) {
  return ($this$fromCurrentValue) => $this$fromCurrentValue.b1y($enumDescriptor);
}
function YamlMapLikeInputBase$decodeSerializableValue$lambda($deserializer) {
  return ($this$fromCurrentValue) => $this$fromCurrentValue.e1y($deserializer);
}
var Companion_instance_2;
function Companion_getInstance_2() {
  return Companion_instance_2;
}
function YamlMap$lambda(a, b) {
  var lineComparison = compareTo(a.b50().y4n_1, b.b50().y4n_1);
  var tmp;
  if (!(lineComparison === 0)) {
    tmp = lineComparison;
  } else {
    tmp = compareTo(a.b50().z4n_1, b.b50().z4n_1);
  }
  return tmp;
}
var Companion_instance_3;
function Companion_getInstance_3() {
  return Companion_instance_3;
}
function convertToIntegerLikeValue($this, converter, description) {
  var tmp0_elvis_lhs = convertToIntegerLikeValueOrNull($this, converter);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw YamlScalarFormatException.v4s("Value '" + $this.j4y_1 + "' is not a valid " + description + ' value.', $this.k4y_1, $this.j4y_1);
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function convertToIntegerLikeValueOrNull($this, converter) {
  var tmp;
  try {
    var tmp_0;
    if (startsWith($this.j4y_1, '0x')) {
      // Inline function 'kotlin.text.substring' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp_0 = converter($this.j4y_1.substring(2), 16);
    } else if (startsWith($this.j4y_1, '-0x')) {
      // Inline function 'kotlin.text.substring' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp_0 = converter('-' + $this.j4y_1.substring(3), 16);
    } else if (startsWith($this.j4y_1, '0o')) {
      // Inline function 'kotlin.text.substring' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp_0 = converter($this.j4y_1.substring(2), 8);
    } else if (startsWith($this.j4y_1, '-0o')) {
      // Inline function 'kotlin.text.substring' call
      // Inline function 'kotlin.js.asDynamic' call
      tmp_0 = converter('-' + $this.j4y_1.substring(3), 8);
    } else {
      tmp_0 = converter($this.j4y_1, 10);
    }
    tmp = tmp_0;
  } catch ($p) {
    var tmp_1;
    if ($p instanceof NumberFormatException) {
      var e = $p;
      tmp_1 = null;
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  return tmp;
}
var Companion_instance_4;
function Companion_getInstance_4() {
  return Companion_instance_4;
}
function toByte$ref() {
  var l = (p0, p1) => toByte(p0, p1);
  l.callableName = 'toByte';
  return l;
}
function toShort$ref() {
  var l = (p0, p1) => toShort(p0, p1);
  l.callableName = 'toShort';
  return l;
}
function toInt$ref() {
  var l = (p0, p1) => toInt(p0, p1);
  l.callableName = 'toInt';
  return l;
}
function toLong$ref() {
  var l = (p0, p1) => toLong(p0, p1);
  l.callableName = 'toLong';
  return l;
}
function toLongOrNull$ref() {
  var l = (p0, p1) => toLongOrNull(p0, p1);
  l.callableName = 'toLongOrNull';
  return l;
}
var Companion_instance_5;
function Companion_getInstance_5() {
  return Companion_instance_5;
}
function YamlList$contentToString$lambda(it) {
  return it.c50();
}
var Companion_instance_6;
function Companion_getInstance_6() {
  return Companion_instance_6;
}
var Companion_instance_7;
function Companion_getInstance_7() {
  return Companion_instance_7;
}
function readNode($this, path) {
  return readNodeAndAnchor($this, path).rl_1;
}
function readNodeAndAnchor($this, path) {
  var event = $this.w4o_1.v50(path);
  var _destruct__k2r9zo = readFromEvent($this, event, path);
  var node = _destruct__k2r9zo.tl();
  var weight = _destruct__k2r9zo.y50();
  if (event instanceof NodeEvent) {
    if (!(event instanceof AliasEvent)) {
      var tmp0_safe_receiver = event.e4b_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        var tmp = $this.y4o_1;
        if (equals(tmp == null ? null : new UInt(tmp), new UInt(_UInt___init__impl__l7qpdl(0)))) {
          throw ForbiddenAnchorOrAliasException.a4w('Parsing anchors and aliases is disabled.', path);
        }
        var anchor = node.e50(Companion_getInstance_9().a51(tmp0_safe_receiver.k47_1, _get_location__4pgxiu($this, event)));
        var tmp0 = $this.z4o_1;
        // Inline function 'kotlin.collections.set' call
        var value = new WeightedNode(anchor, weight);
        tmp0.k3(tmp0_safe_receiver, value);
      }
    }
    return to(new WeightedNode(node, weight), event.e4b_1);
  }
  return to(new WeightedNode(node, _UInt___init__impl__l7qpdl(0)), null);
}
function readFromEvent($this, event, path) {
  var tmp;
  if (event instanceof ScalarEvent) {
    tmp = new WeightedNode(maybeToTaggedNode($this, readScalarOrNull($this, event, path), event.b4d_1), _UInt___init__impl__l7qpdl(0));
  } else {
    if (event instanceof SequenceStartEvent) {
      // Inline function 'kotlin.let' call
      var it = readSequence($this, path);
      tmp = it.c51(maybeToTaggedNode($this, it.w50_1, event.r4b_1));
    } else {
      if (event instanceof MappingStartEvent) {
        // Inline function 'kotlin.let' call
        var it_0 = readMapping($this, path);
        tmp = it_0.c51(maybeToTaggedNode($this, it_0.w50_1, event.r4b_1));
      } else {
        if (event instanceof AliasEvent) {
          tmp = readAlias($this, event, path);
        } else {
          throw MalformedYamlException.n4v('Unexpected ' + event.g4b().toString(), path.b51(_get_location__4pgxiu($this, event)));
        }
      }
    }
  }
  return tmp;
}
function readScalarOrNull($this, event, path) {
  if ((event.d4d_1 === 'null' || event.d4d_1 === '' || event.d4d_1 === '~') && event.g4d()) {
    return new YamlNull(path);
  } else {
    return new YamlScalar(event.d4d_1, path);
  }
}
function readSequence($this, path) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var items = ArrayList.k();
  var sequenceWeight = _UInt___init__impl__l7qpdl(0);
  while (true) {
    var event = $this.w4o_1.d51(path);
    if (event.g4b().o3_1 === 7) {
      $this.w4o_1.f51(ID_SequenceEnd_getInstance(), path);
      return new WeightedNode(new YamlList(items, path), sequenceWeight);
    } else {
      var _destruct__k2r9zo = readNode($this, path.e51(items.b1(), _get_location__4pgxiu($this, event)));
      var node = _destruct__k2r9zo.tl();
      var weight = _destruct__k2r9zo.y50();
      // Inline function 'kotlin.UInt.plus' call
      var this_0 = sequenceWeight;
      sequenceWeight = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_0) + _UInt___get_data__impl__f0vqqw(weight) | 0);
      // Inline function 'kotlin.collections.plusAssign' call
      items.l(node);
    }
  }
}
function readMapping($this, path) {
  // Inline function 'kotlin.collections.mutableMapOf' call
  var items = LinkedHashMap.hc();
  var mapWeight = _UInt___init__impl__l7qpdl(0);
  while (true) {
    var event = $this.w4o_1.d51(path);
    if (event.g4b().o3_1 === 4) {
      $this.w4o_1.f51(ID_MappingEnd_getInstance(), path);
      return new WeightedNode(new YamlMap(doMerges($this, items), path), mapWeight);
    } else {
      var keyLocation = _get_location__4pgxiu($this, $this.w4o_1.d51(path));
      var key = readMapKey($this, path);
      var keyNode = new YamlScalar(key, path.g51(key, keyLocation));
      var valueLocation = _get_location__4pgxiu($this, $this.w4o_1.d51(keyNode.k4y_1));
      var valuePath = isMerge($this, keyNode) ? path.i51(valueLocation) : keyNode.k4y_1.h51(valueLocation);
      var _destruct__k2r9zo = readNodeAndAnchor($this, valuePath);
      var weightedNode = _destruct__k2r9zo.tl();
      var anchor = _destruct__k2r9zo.ul();
      var tmp0 = mapWeight;
      // Inline function 'kotlin.UInt.plus' call
      var other = weightedNode.x50_1;
      mapWeight = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(tmp0) + _UInt___get_data__impl__f0vqqw(other) | 0);
      if (path.equals(Companion_getInstance_9().z50_1) && !($this.x4o_1 == null) && startsWith(key, $this.x4o_1)) {
        if (anchor == null) {
          throw NoAnchorForExtensionException.p4w(key, $this.x4o_1, path.b51(_get_location__4pgxiu($this, event)));
        }
      } else {
        // Inline function 'kotlin.collections.plusAssign' call
        var pair = to(keyNode, weightedNode.w50_1);
        items.k3(pair.rl_1, pair.sl_1);
      }
    }
  }
}
function readMapKey($this, path) {
  var event = $this.w4o_1.d51(path);
  if (event.g4b().o3_1 === 6) {
    $this.w4o_1.f51(ID_Scalar_getInstance(), path);
    var scalarEvent = event instanceof ScalarEvent ? event : THROW_CCE();
    var isNullKey = (scalarEvent.d4d_1 === 'null' || scalarEvent.d4d_1 === '~') && scalarEvent.g4d();
    if (!(scalarEvent.b4d_1 == null) || isNullKey) {
      throw nonScalarMapKeyException($this, path, event);
    }
    return scalarEvent.d4d_1;
  } else
    throw nonScalarMapKeyException($this, path, event);
}
function nonScalarMapKeyException($this, path, event) {
  return MalformedYamlException.n4v("Property name must not be a list, map, null or tagged value. (To use 'null' as a property name, enclose it in quotes.)", path.b51(_get_location__4pgxiu($this, event)));
}
function maybeToTaggedNode($this, _this__u8e3s4, tag) {
  var tmp;
  if (tag == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = new YamlTaggedNode(tag, _this__u8e3s4);
  }
  var tmp1_elvis_lhs = tmp;
  return tmp1_elvis_lhs == null ? _this__u8e3s4 : tmp1_elvis_lhs;
}
function doMerges($this, items) {
  // Inline function 'kotlin.collections.filter' call
  var tmp0 = items.l1();
  // Inline function 'kotlin.collections.filterTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = tmp0.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var key = element.m1();
    if (isMerge($this, key)) {
      destination.l(element);
    }
  }
  var mergeEntries = destination;
  // Inline function 'kotlin.collections.count' call
  switch (mergeEntries.b1()) {
    case 0:
      return items;
    case 1:
      var mappingsToMerge = single(mergeEntries).n1();
      if (mappingsToMerge instanceof YamlList)
        return doMerges_0($this, items, mappingsToMerge.r4y_1);
      else {
        return doMerges_0($this, items, listOf(mappingsToMerge));
      }

    default:
      throw MalformedYamlException.n4v("Cannot perform multiple '<<' merges into a map. Instead, combine all merges into a single '<<' entry.", second($this, mergeEntries).m1().k4y_1);
  }
}
function isMerge($this, key) {
  var tmp;
  if (key instanceof YamlScalar) {
    tmp = key.j4y_1 === '<<';
  } else {
    tmp = false;
  }
  return tmp;
}
function doMerges_0($this, original, others) {
  // Inline function 'kotlin.collections.mutableMapOf' call
  var merged = LinkedHashMap.hc();
  // Inline function 'kotlin.collections.filterNot' call
  // Inline function 'kotlin.collections.filterNotTo' call
  var destination = LinkedHashMap.hc();
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s = original.l1().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var key = element.m1();
    if (!isMerge($this, key)) {
      destination.k3(element.m1(), element.n1());
    }
  }
  // Inline function 'kotlin.collections.forEach' call
  // Inline function 'kotlin.collections.iterator' call
  var _iterator__ex2g4s_0 = destination.l1().y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    // Inline function 'kotlin.collections.component1' call
    var key_0 = element_0.m1();
    // Inline function 'kotlin.collections.component2' call
    var value = element_0.n1();
    merged.k3(key_0, value);
  }
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s_1 = others.y();
  while (_iterator__ex2g4s_1.z()) {
    var element_1 = _iterator__ex2g4s_1.a1();
    if (element_1 instanceof YamlNull)
      throw MalformedYamlException.n4v('Cannot merge a null value into a map.', element_1.u4p_1);
    else {
      if (element_1 instanceof YamlScalar)
        throw MalformedYamlException.n4v('Cannot merge a scalar value into a map.', element_1.k4y_1);
      else {
        if (element_1 instanceof YamlList)
          throw MalformedYamlException.n4v('Cannot merge a list value into a map.', element_1.s4y_1);
        else {
          if (element_1 instanceof YamlTaggedNode)
            throw MalformedYamlException.n4v('Cannot merge a tagged value into a map.', element_1.m4y());
          else {
            if (element_1 instanceof YamlMap) {
              // Inline function 'kotlin.collections.forEach' call
              // Inline function 'kotlin.collections.iterator' call
              var _iterator__ex2g4s_2 = element_1.o4y_1.l1().y();
              while (_iterator__ex2g4s_2.z()) {
                var element_2 = _iterator__ex2g4s_2.a1();
                // Inline function 'kotlin.collections.component1' call
                var key_1 = element_2.m1();
                // Inline function 'kotlin.collections.component2' call
                var value_0 = element_2.n1();
                var tmp2 = merged.l1();
                var tmp$ret$15;
                $l$block_0: {
                  // Inline function 'kotlin.collections.singleOrNull' call
                  var single = null;
                  var found = false;
                  var _iterator__ex2g4s_3 = tmp2.y();
                  while (_iterator__ex2g4s_3.z()) {
                    var element_3 = _iterator__ex2g4s_3.a1();
                    if (element_3.m1().i50(key_1)) {
                      if (found) {
                        tmp$ret$15 = null;
                        break $l$block_0;
                      }
                      single = element_3;
                      found = true;
                    }
                  }
                  if (!found) {
                    tmp$ret$15 = null;
                    break $l$block_0;
                  }
                  tmp$ret$15 = single;
                }
                var existingEntry = tmp$ret$15;
                if (existingEntry == null) {
                  merged.k3(key_1, value_0);
                }
              }
            } else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
  }
  return merged;
}
function readAlias($this, event, path) {
  var tmp = $this.y4o_1;
  if (equals(tmp == null ? null : new UInt(tmp), new UInt(_UInt___init__impl__l7qpdl(0)))) {
    throw ForbiddenAnchorOrAliasException.a4w('Parsing anchors and aliases is disabled.', path);
  }
  var anchor = event.a4b_1;
  // Inline function 'kotlin.collections.getOrElse' call
  var tmp0_elvis_lhs = $this.z4o_1.h3(anchor);
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    throw UnknownAnchorException.d4x(anchor.k47_1, path.b51(_get_location__4pgxiu($this, event)));
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var _destruct__k2r9zo = tmp_0;
  var resolvedNode = _destruct__k2r9zo.tl();
  var resolvedNodeWeight = _destruct__k2r9zo.y50();
  // Inline function 'kotlin.UInt.plus' call
  var other = _UInt___init__impl__l7qpdl(1);
  var resultWeight = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(resolvedNodeWeight) + _UInt___get_data__impl__f0vqqw(other) | 0);
  var tmp_1 = $this;
  // Inline function 'kotlin.UInt.plus' call
  var this_0 = $this.a4p_1;
  tmp_1.a4p_1 = _UInt___init__impl__l7qpdl(_UInt___get_data__impl__f0vqqw(this_0) + _UInt___get_data__impl__f0vqqw(resultWeight) | 0);
  var tmp_2;
  var tmp_3 = $this.y4o_1;
  if (!((tmp_3 == null ? null : new UInt(tmp_3)) == null)) {
    var tmp6 = $this.a4p_1;
    // Inline function 'kotlin.UInt.compareTo' call
    var other_0 = $this.y4o_1;
    tmp_2 = uintCompare(_UInt___get_data__impl__f0vqqw(tmp6), _UInt___get_data__impl__f0vqqw(other_0)) > 0;
  } else {
    tmp_2 = false;
  }
  if (tmp_2) {
    throw ForbiddenAnchorOrAliasException.a4w('Maximum number of aliases has been reached.', path);
  }
  return new WeightedNode(resolvedNode.e50(path.j51(anchor.k47_1, _get_location__4pgxiu($this, event)).k51(anchor.k47_1, resolvedNode.b50())), resultWeight);
}
function second($this, _this__u8e3s4) {
  return first(drop(_this__u8e3s4, 1));
}
function _get_location__4pgxiu($this, _this__u8e3s4) {
  return new Location(ensureNotNull(_this__u8e3s4.k4b_1).i4e_1 + 1 | 0, ensureNotNull(_this__u8e3s4.k4b_1).j4e_1 + 1 | 0);
}
var YamlMapDescriptor_instance;
function YamlMapDescriptor_getInstance() {
  if (YamlMapDescriptor_instance === VOID)
    new YamlMapDescriptor();
  return YamlMapDescriptor_instance;
}
var YamlMapSerializer_instance;
function YamlMapSerializer_getInstance() {
  if (YamlMapSerializer_instance === VOID)
    new YamlMapSerializer();
  return YamlMapSerializer_instance;
}
function YamlNodeSerializer$descriptor$lambda($this$buildSerialDescriptor) {
  $this$buildSerialDescriptor.b1u_1 = plus_0($this$buildSerialDescriptor.b1u_1, new Marker());
  return Unit_instance;
}
var YamlNodeSerializer_instance;
function YamlNodeSerializer_getInstance() {
  if (YamlNodeSerializer_instance === VOID)
    new YamlNodeSerializer();
  return YamlNodeSerializer_instance;
}
var YamlScalarSerializer_instance;
function YamlScalarSerializer_getInstance() {
  if (YamlScalarSerializer_instance === VOID)
    new YamlScalarSerializer();
  return YamlScalarSerializer_instance;
}
function asYamlOutput(_this__u8e3s4) {
  var tmp0 = _this__u8e3s4 instanceof YamlOutput ? _this__u8e3s4 : null;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.checkNotNull' call
    if (tmp0 == null) {
      var message = 'This serializer can be used only with Yaml format. Expected Encoder to be YamlOutput, got ' + toString(getKClassFromExpression(_this__u8e3s4));
      throw IllegalStateException.t4(toString(message));
    } else {
      tmp$ret$1 = tmp0;
      break $l$block;
    }
  }
  return tmp$ret$1;
}
var YamlListDescriptor_instance;
function YamlListDescriptor_getInstance() {
  if (YamlListDescriptor_instance === VOID)
    new YamlListDescriptor();
  return YamlListDescriptor_instance;
}
var YamlListSerializer_instance;
function YamlListSerializer_getInstance() {
  if (YamlListSerializer_instance === VOID)
    new YamlListSerializer();
  return YamlListSerializer_instance;
}
var YamlNullSerializer_instance;
function YamlNullSerializer_getInstance() {
  if (YamlNullSerializer_instance === VOID)
    new YamlNullSerializer();
  return YamlNullSerializer_instance;
}
function YamlTaggedNodeSerializer$descriptor$lambda($this$buildSerialDescriptor) {
  $this$buildSerialDescriptor.h1u('tag', serializer(StringCompanionObject_instance).w1t());
  $this$buildSerialDescriptor.h1u('node', YamlNodeSerializer_getInstance().q51_1);
  return Unit_instance;
}
var YamlTaggedNodeSerializer_instance;
function YamlTaggedNodeSerializer_getInstance() {
  if (YamlTaggedNodeSerializer_instance === VOID)
    new YamlTaggedNodeSerializer();
  return YamlTaggedNodeSerializer_instance;
}
function _get_pairedPropertyNames__11quvr($this) {
  var tmp = $this.c53_1;
  if (!(tmp == null))
    return tmp;
  else {
    throwUninitializedPropertyAccessException('pairedPropertyNames');
  }
}
function YamlObjectInput$beginStructure$lambda($descriptor) {
  return ($this$fromCurrentValue) => $this$fromCurrentValue.f1y($descriptor);
}
function emitPlainScalar($this, value) {
  return emitScalar($this, value, ScalarStyle_PLAIN_getInstance());
}
function emitScalar($this, value, style) {
  var tag = getAndClearTypeName($this);
  if (!(tag == null) && !$this.j52_1.i4o_1.equals(PolymorphismStyle_Tag_getInstance())) {
    throw IllegalStateException.t4('Cannot serialize a polymorphic value that is not a YAML object when using ' + getKClass(PolymorphismStyle).hf() + '.' + $this.j52_1.i4o_1.toString() + '.');
  }
  var implicit = !(tag == null) ? Companion_getInstance_8().f53_1 : Companion_getInstance_8().e53_1;
  $this.k52_1.g53(ScalarEvent.f4d(null, tag, implicit, value, style));
}
function getAndClearTypeName($this) {
  var typeName = $this.l52_1;
  $this.l52_1 = null;
  return typeName;
}
var Companion_instance_8;
function Companion_getInstance_8() {
  if (Companion_instance_8 === VOID)
    new Companion_7();
  return Companion_instance_8;
}
function checkEvent($this, path, retrieve) {
  try {
    return retrieve();
  } catch ($p) {
    if ($p instanceof MarkedYamlEngineException) {
      var e = $p;
      throw translateYamlEngineException($this, e, path);
    } else {
      throw $p;
    }
  }
}
function translateYamlEngineException($this, e, path) {
  var updatedMessage = StringBuilder.v();
  var context = e.r4e_1;
  var contextMark = e.s4e_1;
  if (!(context == null) && !(contextMark == null)) {
    var snippet = contextMark.m4e(4, 2147483647);
    updatedMessage.tb(trimMargin('\n                    |' + context + '\n                    | at line ' + (contextMark.i4e_1 + 1 | 0) + ', column ' + (contextMark.j4e_1 + 1 | 0) + ':\n                    |' + snippet + '\n                    |\n                '));
  }
  var problemMark = e.u4e_1;
  if (!(problemMark == null)) {
    var problem = translateYamlEngineExceptionMessage($this, e.t4e_1);
    var snippet_0 = problemMark.m4e(4, 2147483647);
    updatedMessage.tb(trimMargin('\n                    |' + problem + '\n                    | at line ' + (problemMark.i4e_1 + 1 | 0) + ', column ' + (problemMark.j4e_1 + 1 | 0) + ':\n                    |' + snippet_0 + '\n                '));
  }
  var tmp;
  if (!(problemMark == null)) {
    tmp = path.b51(new Location(problemMark.i4e_1 + 1 | 0, problemMark.j4e_1 + 1 | 0));
  } else {
    tmp = path;
  }
  var updatedPath = tmp;
  return MalformedYamlException.n4v(updatedMessage.toString(), updatedPath);
}
function translateYamlEngineExceptionMessage($this, message) {
  switch (message) {
    case 'mapping values are not allowed here':
    case "expected <block end>, but found '<block sequence start>'":
    case "expected <block end>, but found '<block mapping start>'":
      return message + ' (is the indentation level of this line or a line nearby incorrect?)';
    default:
      return message;
  }
}
function YamlParser$consumeEvent$lambda(this$0) {
  return () => this$0.e4p_1.a1();
}
function YamlParser$peekEvent$lambda(this$0) {
  return () => this$0.e4p_1.c4k();
}
function withSegment($this, segment) {
  return YamlPath.h50(plus_0($this.h4r_1, segment));
}
var Companion_instance_9;
function Companion_getInstance_9() {
  if (Companion_instance_9 === VOID)
    new Companion_8();
  return Companion_instance_9;
}
var Root_instance;
function Root_getInstance() {
  if (Root_instance === VOID)
    new Root();
  return Root_instance;
}
var CurrentField_NotStarted_instance;
var CurrentField_Type_instance;
var CurrentField_Content_instance;
var CurrentField_entriesInitialized;
function CurrentField_initEntries() {
  if (CurrentField_entriesInitialized)
    return Unit_instance;
  CurrentField_entriesInitialized = true;
  CurrentField_NotStarted_instance = new CurrentField('NotStarted', 0);
  CurrentField_Type_instance = new CurrentField('Type', 1);
  CurrentField_Content_instance = new CurrentField('Content', 2);
}
function _get_contentDecoder__ypxfj4($this) {
  var tmp = $this.a52_1;
  if (!(tmp == null))
    return tmp;
  else {
    throwUninitializedPropertyAccessException('contentDecoder');
  }
}
function throwIfUnknownPolymorphicTypeException($this, e, deserializer) {
  var tmp0_elvis_lhs = e.message;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var message = tmp;
  var tmp1_elvis_lhs = Companion_getInstance_10().b54_1.bi(message, 0);
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var match = tmp_0;
  var unknownType = match.ti().f1(1);
  var className = match.ti().f1(2);
  var tmp2_subject = deserializer.w1t().j1w();
  var tmp_1;
  if (equals(tmp2_subject, SEALED_getInstance())) {
    tmp_1 = getKnownTypesForSealedType($this, deserializer);
  } else if (equals(tmp2_subject, OPEN_getInstance())) {
    tmp_1 = getKnownTypesForOpenType($this, className);
  } else {
    throw IllegalArgumentException.t("Can't get known types for descriptor of kind " + deserializer.w1t().j1w().toString());
  }
  var knownTypes = tmp_1;
  throw UnknownPolymorphicTypeException.s4x(unknownType, knownTypes, $this.x51_1, e);
}
function getKnownTypesForSealedType($this, deserializer) {
  var typesDescriptor = deserializer.w1t().q1w(1);
  return toSet(get_elementNames(typesDescriptor));
}
function getKnownTypesForOpenType($this, className) {
  // Inline function 'kotlin.collections.mutableSetOf' call
  var knownTypes = LinkedHashSet.g1();
  var tmp = $this.u1y();
  tmp.g2f(new YamlPolymorphicInput$getKnownTypesForOpenType$1(className, knownTypes));
  return knownTypes;
}
var Companion_instance_10;
function Companion_getInstance_10() {
  if (Companion_instance_10 === VOID)
    new Companion_9();
  return Companion_instance_10;
}
function CurrentField_NotStarted_getInstance() {
  CurrentField_initEntries();
  return CurrentField_NotStarted_instance;
}
function CurrentField_Type_getInstance() {
  CurrentField_initEntries();
  return CurrentField_Type_instance;
}
function CurrentField_Content_getInstance() {
  CurrentField_initEntries();
  return CurrentField_Content_instance;
}
function YamlScalarInput$decodeEnum$lambda($enumDescriptor) {
  return (it) => $enumDescriptor.n1w(it);
}
function bufferedSource(_this__u8e3s4) {
  return (new Buffer()).l41(Companion_getInstance().d40(_this__u8e3s4));
}
//region block: post-declaration
initMetadataForClass(Location, 'Location');
initMetadataForCompanion(Companion);
initMetadataForClass(Yaml, 'Yaml', Yaml);
initMetadataForClass(YamlConfiguration, 'YamlConfiguration', YamlConfiguration);
initMetadataForClass(AnchorsAndAliases, 'AnchorsAndAliases');
initMetadataForObject(Forbidden, 'Forbidden');
initMetadataForClass(PolymorphismStyle, 'PolymorphismStyle');
initMetadataForClass(SequenceStyle, 'SequenceStyle');
initMetadataForClass(SingleLineStringStyle, 'SingleLineStringStyle');
initMetadataForClass(MultiLineStringStyle, 'MultiLineStringStyle');
initMetadataForClass(AmbiguousQuoteStyle, 'AmbiguousQuoteStyle');
initMetadataForClass(Marker, 'Marker');
initMetadataForClass(YamlInput, 'YamlInput');
initMetadataForClass(YamlContextualInput, 'YamlContextualInput');
initMetadataForClass(YamlException, 'YamlException');
initMetadataForClass(DuplicateKeyException, 'DuplicateKeyException');
initMetadataForClass(IncorrectTypeException, 'IncorrectTypeException');
initMetadataForClass(YamlScalarFormatException, 'YamlScalarFormatException');
initMetadataForClass(MissingTypeTagException, 'MissingTypeTagException');
initMetadataForClass(InvalidPropertyValueException, 'InvalidPropertyValueException');
initMetadataForClass(MissingRequiredPropertyException, 'MissingRequiredPropertyException');
initMetadataForClass(EmptyYamlDocumentException, 'EmptyYamlDocumentException');
initMetadataForClass(MalformedYamlException, 'MalformedYamlException');
initMetadataForClass(ForbiddenAnchorOrAliasException, 'ForbiddenAnchorOrAliasException');
initMetadataForClass(NoAnchorForExtensionException, 'NoAnchorForExtensionException');
initMetadataForClass(UnknownAnchorException, 'UnknownAnchorException');
initMetadataForClass(UnknownPolymorphicTypeException, 'UnknownPolymorphicTypeException');
initMetadataForClass(UnexpectedNullValueException, 'UnexpectedNullValueException');
initMetadataForClass(UnknownPropertyException, 'UnknownPropertyException');
initMetadataForCompanion(Companion_0);
initMetadataForClass(YamlListInput, 'YamlListInput');
initMetadataForClass(YamlMapLikeInputBase, 'YamlMapLikeInputBase');
initMetadataForClass(YamlMapInput, 'YamlMapInput');
initMetadataForCompanion(Companion_1);
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(YamlNode, 'YamlNode', VOID, VOID, VOID, VOID, VOID, {0: YamlNodeSerializer_getInstance});
initMetadataForClass(YamlMap, 'YamlMap', VOID, VOID, VOID, VOID, VOID, {0: YamlMapSerializer_getInstance});
initMetadataForCompanion(Companion_2);
initMetadataForCompanion(Companion_3);
initMetadataForClass(YamlScalar, 'YamlScalar', VOID, VOID, VOID, VOID, VOID, {0: YamlScalarSerializer_getInstance});
initMetadataForCompanion(Companion_4);
initMetadataForClass(YamlList, 'YamlList', VOID, VOID, VOID, VOID, VOID, {0: YamlListSerializer_getInstance});
initMetadataForCompanion(Companion_5);
initMetadataForClass(YamlNull, 'YamlNull', VOID, VOID, VOID, VOID, VOID, {0: YamlNullSerializer_getInstance});
initMetadataForCompanion(Companion_6);
initMetadataForClass(YamlTaggedNode, 'YamlTaggedNode', VOID, VOID, VOID, VOID, VOID, {0: YamlTaggedNodeSerializer_getInstance});
initMetadataForClass(YamlNodeReader, 'YamlNodeReader');
initMetadataForClass(WeightedNode, 'WeightedNode');
initMetadataForObject(YamlMapDescriptor, 'YamlMapDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForObject(YamlMapSerializer, 'YamlMapSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(YamlNodeSerializer, 'YamlNodeSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(YamlScalarSerializer, 'YamlScalarSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(YamlListDescriptor, 'YamlListDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForObject(YamlListSerializer, 'YamlListSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(YamlNullSerializer, 'YamlNullSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(YamlTaggedNodeSerializer, 'YamlTaggedNodeSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(YamlNullInput, 'YamlNullInput');
initMetadataForClass(YamlObjectInput, 'YamlObjectInput');
initMetadataForCompanion(Companion_7);
initMetadataForClass(YamlOutput, 'YamlOutput', VOID, VOID, [AbstractEncoder, AutoCloseable]);
initMetadataForClass(YamlParser, 'YamlParser');
initMetadataForCompanion(Companion_8);
initMetadataForClass(YamlPath, 'YamlPath');
initMetadataForClass(YamlPathSegment, 'YamlPathSegment');
initMetadataForObject(Root, 'Root');
initMetadataForClass(ListEntry, 'ListEntry');
initMetadataForClass(MapElementKey, 'MapElementKey');
initMetadataForClass(MapElementValue, 'MapElementValue');
initMetadataForClass(AliasReference, 'AliasReference');
initMetadataForClass(AliasDefinition, 'AliasDefinition');
initMetadataForClass(Merge, 'Merge');
initMetadataForClass(Error_0, 'Error');
initMetadataForClass(CurrentField, 'CurrentField');
initMetadataForCompanion(Companion_9);
protoOf(YamlPolymorphicInput$getKnownTypesForOpenType$1).r2f = contextual;
initMetadataForClass(YamlPolymorphicInput$getKnownTypesForOpenType$1, VOID, VOID, VOID, [SerializersModuleCollector]);
initMetadataForClass(YamlPolymorphicInput, 'YamlPolymorphicInput');
initMetadataForClass(YamlScalarInput, 'YamlScalarInput');
//endregion
//region block: init
Companion_instance_2 = new Companion_1();
Companion_instance_3 = new Companion_2();
Companion_instance_4 = new Companion_3();
Companion_instance_5 = new Companion_4();
Companion_instance_6 = new Companion_5();
Companion_instance_7 = new Companion_6();
//endregion
//region block: exports
export {
  YamlMap as YamlMapg7x473jl53e,
  YamlScalar as YamlScalar1ksv41lpvdq25,
  Companion_getInstance_0 as Companion_getInstance3kevo0bkbnsry,
};
//endregion

//# sourceMappingURL=kaml.mjs.map
