import {
  ChatCompletionsModel2rl4figp5zhty as ChatCompletionsModel,
  ChatCompletionsParams2phuyy1p28jz5 as ChatCompletionsParams,
  normalizeChatCompletionsUrlbu0jml6vp44x as normalizeChatCompletionsUrl,
} from './koaks-model-provider-chat-completions.mjs';
import {
  VOID7hggqo3abtya as VOID,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  toString30pk9tzaqopn as toString,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  equals2au1ep9vhcato as equals,
  Long2qws0ah9gnpki as Long,
  Unit_instance104q5opgivhr8 as Unit_instance,
} from './kotlin-kotlin-stdlib.mjs';
import {
  ModelCapabilities1z2n3zkdibnvb as ModelCapabilities,
  Companion_getInstance3ot1bqjky10hu as Companion_getInstance,
  ModelConfig4o28u6uqe7xk as ModelConfig,
  Support_Supported_getInstance2iy50h3ebt6qe as Support_Supported_getInstance,
  Support_Unsupported_getInstance2l560r5zg87nd as Support_Unsupported_getInstance,
  Support_Unknown_getInstance3blv79i14mlk4 as Support_Unknown_getInstance,
} from './koaks-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class QwenChatModel extends ChatCompletionsModel {
  constructor(config, transport, params, capabilities) {
    params = params === VOID ? new QwenParams() : params;
    capabilities = capabilities === VOID ? new ModelCapabilities() : capabilities;
    super(config, transport, Companion_getInstance().u6c_1, new ChatCompletionsParams(params.m7d_1, params.n7d_1, VOID, params.o7d_1, params.p7d_1, params.q7d_1, params.r7d_1, VOID, params.s7d_1), capabilities);
  }
}
class QwenParams {
  constructor(temperature, maxTokens, topP, stop, presencePenalty, frequencyPenalty, enableThinking) {
    temperature = temperature === VOID ? null : temperature;
    maxTokens = maxTokens === VOID ? null : maxTokens;
    topP = topP === VOID ? null : topP;
    stop = stop === VOID ? null : stop;
    presencePenalty = presencePenalty === VOID ? null : presencePenalty;
    frequencyPenalty = frequencyPenalty === VOID ? null : frequencyPenalty;
    enableThinking = enableThinking === VOID ? null : enableThinking;
    this.m7d_1 = temperature;
    this.n7d_1 = maxTokens;
    this.o7d_1 = topP;
    this.p7d_1 = stop;
    this.q7d_1 = presencePenalty;
    this.r7d_1 = frequencyPenalty;
    this.s7d_1 = enableThinking;
  }
  toString() {
    return 'QwenParams(temperature=' + this.m7d_1 + ', maxTokens=' + this.n7d_1 + ', topP=' + this.o7d_1 + ', stop=' + toString(this.p7d_1) + ', presencePenalty=' + this.q7d_1 + ', frequencyPenalty=' + this.r7d_1 + ', enableThinking=' + this.s7d_1 + ')';
  }
  hashCode() {
    var result = this.m7d_1 == null ? 0 : getNumberHashCode(this.m7d_1);
    result = imul(result, 31) + (this.n7d_1 == null ? 0 : this.n7d_1) | 0;
    result = imul(result, 31) + (this.o7d_1 == null ? 0 : getNumberHashCode(this.o7d_1)) | 0;
    result = imul(result, 31) + (this.p7d_1 == null ? 0 : hashCode(this.p7d_1)) | 0;
    result = imul(result, 31) + (this.q7d_1 == null ? 0 : getNumberHashCode(this.q7d_1)) | 0;
    result = imul(result, 31) + (this.r7d_1 == null ? 0 : getNumberHashCode(this.r7d_1)) | 0;
    result = imul(result, 31) + (this.s7d_1 == null ? 0 : getBooleanHashCode(this.s7d_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof QwenParams))
      return false;
    var tmp0_other_with_cast = other instanceof QwenParams ? other : THROW_CCE();
    if (!equals(this.m7d_1, tmp0_other_with_cast.m7d_1))
      return false;
    if (!(this.n7d_1 == tmp0_other_with_cast.n7d_1))
      return false;
    if (!equals(this.o7d_1, tmp0_other_with_cast.o7d_1))
      return false;
    if (!equals(this.p7d_1, tmp0_other_with_cast.p7d_1))
      return false;
    if (!equals(this.q7d_1, tmp0_other_with_cast.q7d_1))
      return false;
    if (!equals(this.r7d_1, tmp0_other_with_cast.r7d_1))
      return false;
    if (!(this.s7d_1 == tmp0_other_with_cast.s7d_1))
      return false;
    return true;
  }
}
class QwenConfig {
  constructor(baseUrl, apiKey, modelName) {
    this.t7d_1 = baseUrl;
    this.u7d_1 = apiKey;
    this.v7d_1 = modelName;
    this.w7d_1 = null;
    this.x7d_1 = null;
    this.y7d_1 = null;
    this.z7d_1 = null;
    this.a7e_1 = null;
    this.b7e_1 = null;
    this.c7e_1 = null;
    this.d7e_1 = new Long(60000, 0);
    this.e7e_1 = new ModelCapabilities();
  }
  i7e(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new CapabilitiesScope(this.e7e_1);
    block(this_0);
    tmp.e7e_1 = this_0.m7e();
  }
  f7e() {
    return new ModelConfig(normalizeChatCompletionsUrl(this.t7d_1), this.u7d_1, this.v7d_1, VOID, VOID, VOID, VOID, VOID, this.d7e_1);
  }
  g7e() {
    return new QwenParams(this.w7d_1, this.x7d_1, this.y7d_1, this.z7d_1, this.a7e_1, this.b7e_1, this.c7e_1);
  }
  h7e() {
    return this.e7e_1;
  }
}
class CapabilitiesScope {
  constructor(initial) {
    this.j7e_1 = initial.v5o_1.equals(Support_Supported_getInstance());
    this.k7e_1 = initial.w5o_1.equals(Support_Supported_getInstance());
    this.l7e_1 = initial.x5o_1.equals(Support_Supported_getInstance());
  }
  m7e() {
    return new ModelCapabilities(this.j7e_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), this.k7e_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.l7e_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance());
  }
}
//endregion
function qwen(_this__u8e3s4, baseUrl, apiKey, modelName, block) {
  baseUrl = baseUrl === VOID ? 'https://dashscope.aliyuncs.com/compatible-mode' : baseUrl;
  var tmp;
  if (block === VOID) {
    tmp = qwen$lambda;
  } else {
    tmp = block;
  }
  block = tmp;
  // Inline function 'kotlin.apply' call
  var this_0 = new QwenConfig(baseUrl, apiKey, modelName);
  block(this_0);
  var cfg = this_0;
  return _this__u8e3s4.t5z(new QwenChatModel(cfg.f7e(), _this__u8e3s4.v5z(), cfg.g7e(), cfg.h7e()));
}
function qwen$lambda(_this__u8e3s4) {
  return Unit_instance;
}
//region block: post-declaration
initMetadataForClass(QwenChatModel, 'QwenChatModel', VOID, VOID, VOID, [1]);
initMetadataForClass(QwenParams, 'QwenParams', QwenParams);
initMetadataForClass(QwenConfig, 'QwenConfig');
initMetadataForClass(CapabilitiesScope, 'CapabilitiesScope');
//endregion
//region block: exports
export {
  qwen as qwen3m5zqusvdcxsm,
};
//endregion

//# sourceMappingURL=koaks-model-provider-qwen.mjs.map
