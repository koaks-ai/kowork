import {
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  VOID7hggqo3abtya as VOID,
  StringCompanionObject_instance2odz3s3zbrixa as StringCompanionObject_instance,
  Unit_instance104q5opgivhr8 as Unit_instance,
  emptyList1g2z5xcrvp2zy as emptyList,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  toString1pkumu07cwy4m as toString,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  KProperty1ca4yb4wlo496 as KProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  zip2suipyqmdw72q as zip,
  toMap1vec9topfei08 as toMap,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  asList2ho2pewtsfvv as asList,
  KtMap140uvy3s5zad8 as KtMap,
  isInterface3d6p8outrmvmk as isInterface,
  captureStack1fzi4aczwc4hg as captureStack,
  listOfvhqybd2zx248 as listOf,
  ArrayList3it5z8td81qkl as ArrayList,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  KClass1cc9rfeybg8hs as KClass,
  Triple1vhi3d0dgpnjb as Triple,
  getKClass1s3j9wy1cofik as getKClass,
  Paire9pteg33gng7 as Pair,
  Entry2xmjmyutzoq3p as Entry,
  KtMutableMap1kqeifoi36kpz as KtMutableMap,
  HashMap1a0ld5kgwhmhv as HashMap,
  KtSetjrjc7fhfd6b9 as KtSet,
  KtMutableSetwuwn7k5m570a as KtMutableSet,
  LinkedHashSet2tkztfx86kyx2 as LinkedHashSet,
  HashSet2dzve9y63nf0v as HashSet,
  Collection1k04j3hzsbod0 as Collection,
  KtList3hktaavzmj137 as KtList,
  KtMutableList1beimitadwkna as KtMutableList,
  copyToArray2j022khrow2yi as copyToArray,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  _Result___get_isFailure__impl__jpirivzehaw445b0cy as _Result___get_isFailure__impl__jpiriv,
  Result3t1vadv16kmzk as Result,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  equals2au1ep9vhcato as equals,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  isBlank1dvkhjjvox3p0 as isBlank,
  toList383f556t1dixk as toList,
  toHashSet1qrcsl3g8ugc8 as toHashSet,
  toBooleanArray2u3qw7fjwsmuh as toBooleanArray,
  withIndex3s8q7w1g0hyfn as withIndex,
  to2cs3ny02qtbcb as to,
  lazy2hsh8ze7j6ikd as lazy_0,
  contentEqualsaf55p28mnw74 as contentEquals,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  Long2qws0ah9gnpki as Long,
  Char19o2r8palgjof as Char,
  createThis2j2avj17cvnv2 as createThis,
  Duration__toIsoString_impl_9h6wsm33t9fmb34wprd as Duration__toIsoString_impl_9h6wsm,
  Duration5ynfiptaqcrg as Duration,
  Companion_getInstance2b73c6hwbaiuw as Companion_getInstance,
  Uuid1zxgztb7abqxx as Uuid,
  Companion_getInstance3tnw2k4njrdpv as Companion_getInstance_0,
  toIntOrNull3w2d066r9pvwm as toIntOrNull,
  hashCodeq5arwsb9dgti as hashCode,
  isArray1hxjqtqy632bc as isArray,
  arrayIterator3lgwvgteckzhv as arrayIterator,
  until1jbpn0z3f8lbg as until,
  step18s9qzr5xwxat as step,
  getValue48kllevslyh6 as getValue,
  longArray288a0fctlmjmj as longArray,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  get_lastIndex1y2f6o9u8hnf7 as get_lastIndex,
  countTrailingZeroBits1k55x07cygoff as countTrailingZeroBits,
  indexOf3ic8eacwbbrog as indexOf,
  contentToString3ujacv8hqfipd as contentToString,
  Enum3alwj03lh1n41 as Enum,
  joinToString1cxrrlmo0chqs as joinToString,
  toString30pk9tzaqopn as toString_0,
  KTypeParameter1s8efufd4mbj5 as KTypeParameter,
  contentHashCode2i020q5tbeh2s as contentHashCode,
  booleanArray2jdug9b51huk7 as booleanArray,
  emptyMapr06gerzljqtm as emptyMap,
  Companion_getInstance2g172z58li19e as Companion_getInstance_1,
  isCharArray21auq5hbrg68m as isCharArray,
  charArray2ujmm1qusno00 as charArray,
  DoubleCompanionObject_instance2yqrcskeqd1tm as DoubleCompanionObject_instance,
  isDoubleArray1wyh4nyf7pjxn as isDoubleArray,
  FloatCompanionObject_instance29smzmmxq0czz as FloatCompanionObject_instance,
  isFloatArrayjjscnqphw92j as isFloatArray,
  Companion_getInstance1pxg306pnafvz as Companion_getInstance_2,
  isLongArray2fdt3z7yu3ef as isLongArray,
  Companion_getInstance1poxudqc1ru3p as Companion_getInstance_3,
  _ULongArray___get_size__impl__ju6dtr1b48sgq5mqufi as _ULongArray___get_size__impl__ju6dtr,
  ULongArray3nd0d80mdwjj8 as ULongArray,
  _ULongArray___init__impl__twm1l3w35zjgwc40e6 as _ULongArray___init__impl__twm1l3,
  _ULong___init__impl__c78o9k2uqxdjm6b0lbg as _ULong___init__impl__c78o9k,
  ULongArray__get_impl_pr71q927jt2k7w7gjei as ULongArray__get_impl_pr71q9,
  _ULong___get_data__impl__fggpzb1jl4xe0gulani as _ULong___get_data__impl__fggpzb,
  IntCompanionObject_instance2nvyd29rdzxbs as IntCompanionObject_instance,
  isIntArrayeijsubfngq38 as isIntArray,
  Companion_getInstance1z323tr26bmxd as Companion_getInstance_4,
  _UIntArray___get_size__impl__r6l8ci9njro21awxk9 as _UIntArray___get_size__impl__r6l8ci,
  UIntArrayrp6cv44n5v4y as UIntArray,
  _UIntArray___init__impl__ghjpc6p9a9ozepj5yp as _UIntArray___init__impl__ghjpc6,
  _UInt___init__impl__l7qpdl1vpobek1e692 as _UInt___init__impl__l7qpdl,
  UIntArray__get_impl_gp5kza3dxey4dpmolyb as UIntArray__get_impl_gp5kza,
  _UInt___get_data__impl__f0vqqw9xdox7iecbly as _UInt___get_data__impl__f0vqqw,
  ShortCompanionObject_instanceyg0ko6hbt9iy as ShortCompanionObject_instance,
  isShortArraywz30zxwtqi8h as isShortArray,
  Companion_getInstanceojp2cj59jqir as Companion_getInstance_5,
  _UShortArray___get_size__impl__jqto1bat9kt7h1kexu as _UShortArray___get_size__impl__jqto1b,
  UShortArray11avpmknxdgvv as UShortArray,
  _UShortArray___init__impl__9b26ef20xbmpmmmp8nr as _UShortArray___init__impl__9b26ef,
  _UShort___init__impl__jigrne3h2nm35iaibum as _UShort___init__impl__jigrne,
  UShortArray__get_impl_fnbhmx2rw6mvd6ywjjn as UShortArray__get_impl_fnbhmx,
  _UShort___get_data__impl__g02459z5yfs6z0kj0 as _UShort___get_data__impl__g0245,
  ByteCompanionObject_instancerp27gpfua1xf as ByteCompanionObject_instance,
  isByteArray4nnzfn1x4o3w as isByteArray,
  Companion_getInstance374brtr06v94p as Companion_getInstance_6,
  _UByteArray___get_size__impl__h6pkdv2ztnvvin1oejd as _UByteArray___get_size__impl__h6pkdv,
  UByteArray2qu4d6gwssdf9 as UByteArray,
  _UByteArray___init__impl__ip4y9n2yrhvr539f00i as _UByteArray___init__impl__ip4y9n,
  _UByte___init__impl__g9hnc415bxbmye0j11o as _UByte___init__impl__g9hnc4,
  UByteArray__get_impl_t5f3hv2yxdiuhsa1bkg as UByteArray__get_impl_t5f3hv,
  _UByte___get_data__impl__jof9qrfj1ch8mjizvj as _UByte___get_data__impl__jof9qr,
  BooleanCompanionObject_instance3nvf6tg77gv83 as BooleanCompanionObject_instance,
  isBooleanArray35llghle4c6w1 as isBooleanArray,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  copyOf2p23ljc5f5ea3 as copyOf,
  copyOfgossjg6lh6js as copyOf_0,
  copyOfq9pcgcgbldck as copyOf_1,
  copyOf9mbsebmgnw4t as copyOf_2,
  _ULongArray___get_storage__impl__28e64jlq4wjpcpg0xb as _ULongArray___get_storage__impl__28e64j,
  _ULongArray___init__impl__twm1l31njh1yo2fhc3d as _ULongArray___init__impl__twm1l3_0,
  ULongArray__set_impl_z19mvh3jq4upxqlu5i0 as ULongArray__set_impl_z19mvh,
  copyOf3rutauicler23 as copyOf_3,
  _UIntArray___get_storage__impl__92a0v03adro3l9nnqca as _UIntArray___get_storage__impl__92a0v0,
  _UIntArray___init__impl__ghjpc61vagysy0rvf as _UIntArray___init__impl__ghjpc6_0,
  UIntArray__set_impl_7f2zu22xxx79utmdcyl as UIntArray__set_impl_7f2zu2,
  copyOf39s58md6y6rn6 as copyOf_4,
  _UShortArray___get_storage__impl__t2jpv53ishea48wnh3x as _UShortArray___get_storage__impl__t2jpv5,
  _UShortArray___init__impl__9b26ef2p62uevidil7h as _UShortArray___init__impl__9b26ef_0,
  UShortArray__set_impl_6d8whp1v6ijtn8ethum as UShortArray__set_impl_6d8whp,
  copyOfwy6h3t5vzqpl as copyOf_5,
  _UByteArray___get_storage__impl__d4kctt24cpxlf9wdrm1 as _UByteArray___get_storage__impl__d4kctt,
  _UByteArray___init__impl__ip4y9n1d0y5mfc7d2ru as _UByteArray___init__impl__ip4y9n_0,
  UByteArray__set_impl_jvcicn17xhe4228sib8 as UByteArray__set_impl_jvcicn,
  copyOf37mht4mx7mjgh as copyOf_6,
  Unitkvevlwgzwiuc as Unit,
  trimIndent1qytc1wvt8suh as trimIndent,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  last1vo29oleiqj36 as last,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  get_lastIndex1yw0x4k50k51w as get_lastIndex_0,
  ULong3f9k7s38t3rfp as ULong,
  UInt1hthisrv6cndi as UInt,
  UShort26xnqty60t7le as UShort,
  UBytep4j7r1t64gz1 as UByte,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  PrimitiveClasses_getInstance28ukyr6i8fs0q as PrimitiveClasses_getInstance,
  mapOf1xd03cq9cnmy8 as mapOf,
  get_js1ale1wr4fbvs0 as get_js,
  findAssociatedObject1kb88g16k1goa as findAssociatedObject,
  IndexOutOfBoundsException1qfr429iumro0 as IndexOutOfBoundsException,
  get_indicesc04v40g017hw as get_indices,
  get_indices377latqcai313 as get_indices_0,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
} from './kotlin-kotlin-stdlib.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class SerializationStrategy {}
class DeserializationStrategy {}
class KSerializer {}
class AbstractPolymorphicSerializer {
  static m1u() {
    return createThis(this);
  }
  o1u(encoder, value) {
    var actualSerializer = findPolymorphicSerializer(this, encoder, value);
    // Inline function 'kotlinx.serialization.encoding.encodeStructure' call
    var descriptor = this.w1t();
    var composite = encoder.f1y(descriptor);
    composite.v1z(this.w1t(), 0, actualSerializer.w1t().z1u());
    var tmp = this.w1t();
    // Inline function 'kotlinx.serialization.internal.cast' call
    var tmp$ret$0 = isInterface(actualSerializer, SerializationStrategy) ? actualSerializer : THROW_CCE();
    composite.x1z(tmp, 1, tmp$ret$0, value);
    composite.g1y(descriptor);
  }
  x1t(encoder, value) {
    return this.o1u(encoder, !(value == null) ? value : THROW_CCE());
  }
  y1t(decoder) {
    // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
    var descriptor = this.w1t();
    var composite = decoder.f1y(descriptor);
    var tmp$ret$0;
    $l$block: {
      var klassName = null;
      var value = null;
      if (composite.v1y()) {
        tmp$ret$0 = decodeSequentially_0(this, composite);
        break $l$block;
      }
      mainLoop: while (true) {
        var index = composite.w1y(this.w1t());
        switch (index) {
          case -1:
            break mainLoop;
          case 0:
            klassName = composite.p1y(this.w1t(), index);
            break;
          case 1:
            var tmp0 = klassName;
            var tmp$ret$2;
            $l$block_0: {
              // Inline function 'kotlin.requireNotNull' call
              if (tmp0 == null) {
                var message = 'Cannot read polymorphic value before its type token';
                throw IllegalArgumentException.t(toString(message));
              } else {
                tmp$ret$2 = tmp0;
                break $l$block_0;
              }
            }

            klassName = tmp$ret$2;
            var serializer = findPolymorphicSerializer_0(this, composite, klassName);
            value = composite.s1y(this.w1t(), index, serializer);
            break;
          default:
            var tmp0_elvis_lhs = klassName;
            throw SerializationException.i1v('Invalid index in polymorphic deserialization of ' + (tmp0_elvis_lhs == null ? 'unknown class' : tmp0_elvis_lhs) + ('\n Expected 0, 1 or DECODE_DONE(-1), but found ' + index));
        }
      }
      var tmp1 = value;
      var tmp$ret$4;
      $l$block_1: {
        // Inline function 'kotlin.requireNotNull' call
        if (tmp1 == null) {
          var message_0 = 'Polymorphic value has not been read for class ' + klassName;
          throw IllegalArgumentException.t(toString(message_0));
        } else {
          tmp$ret$4 = tmp1;
          break $l$block_1;
        }
      }
      var tmp = tmp$ret$4;
      tmp$ret$0 = !(tmp == null) ? tmp : THROW_CCE();
    }
    var result = tmp$ret$0;
    composite.g1y(descriptor);
    return result;
  }
  p1u(decoder, klassName) {
    return decoder.u1y().e20(this.n1u(), klassName);
  }
  q1u(encoder, value) {
    return encoder.u1y().f20(this.n1u(), value);
  }
}
class PolymorphicSerializer extends AbstractPolymorphicSerializer {
  static l1u(baseClass) {
    var $this = this.m1u();
    $this.i1u_1 = baseClass;
    $this.j1u_1 = emptyList();
    var tmp = $this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.k1u_1 = lazy(tmp_0, PolymorphicSerializer$descriptor$delegate$lambda($this));
    return $this;
  }
  n1u() {
    return this.i1u_1;
  }
  w1t() {
    var tmp0 = this.k1u_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory();
    return tmp0.n1();
  }
  toString() {
    return 'kotlinx.serialization.PolymorphicSerializer(baseClass: ' + toString(this.i1u_1) + ')';
  }
}
class SealedClassSerializer$$inlined$groupingBy$1 {
  constructor($this) {
    this.w1u_1 = $this;
  }
  x1u() {
    return this.w1u_1.y();
  }
  y1u(element) {
    return element.n1().w1t().z1u();
  }
  a1v(element) {
    return this.y1u((element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class SealedClassSerializer extends AbstractPolymorphicSerializer {
  static b1v(serialName, baseClass, subclasses, subclassSerializers) {
    var $this = this.m1u();
    $this.r1u_1 = baseClass;
    $this.s1u_1 = emptyList();
    var tmp = $this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.t1u_1 = lazy(tmp_0, SealedClassSerializer$descriptor$delegate$lambda(serialName, $this));
    if (!(subclasses.length === subclassSerializers.length)) {
      throw IllegalArgumentException.t('All subclasses of sealed class ' + $this.r1u_1.hf() + ' should be marked @Serializable');
    }
    $this.u1u_1 = toMap(zip(subclasses, subclassSerializers));
    var tmp_1 = $this;
    // Inline function 'kotlin.collections.groupingBy' call
    var this_0 = $this.u1u_1.l1();
    // Inline function 'kotlin.collections.aggregate' call
    var tmp0 = new SealedClassSerializer$$inlined$groupingBy$1(this_0);
    // Inline function 'kotlin.collections.mutableMapOf' call
    // Inline function 'kotlin.collections.aggregateTo' call
    var destination = LinkedHashMap.hc();
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = tmp0.x1u();
    while (_iterator__ex2g4s.z()) {
      var e = _iterator__ex2g4s.a1();
      var key = tmp0.a1v(e);
      var accumulator = destination.h3(key);
      accumulator == null && !destination.f3(key);
      if (!(accumulator == null)) {
        // Inline function 'kotlin.error' call
        var message = "Multiple sealed subclasses of '" + toString($this.r1u_1) + "' have the same serial name '" + key + "':" + (" '" + toString(accumulator.m1()) + "', '" + toString(e.m1()) + "'");
        throw IllegalStateException.t4(toString(message));
      }
      // Inline function 'kotlin.collections.set' call
      destination.k3(key, e);
    }
    // Inline function 'kotlin.collections.mapValues' call
    // Inline function 'kotlin.collections.mapValuesTo' call
    var destination_0 = LinkedHashMap.ic(mapCapacity(destination.b1()));
    // Inline function 'kotlin.collections.associateByTo' call
    var _iterator__ex2g4s_0 = destination.l1().y();
    while (_iterator__ex2g4s_0.z()) {
      var element = _iterator__ex2g4s_0.a1();
      var tmp_2 = element.m1();
      var tmp$ret$8 = element.n1().n1();
      destination_0.k3(tmp_2, tmp$ret$8);
    }
    tmp_1.v1u_1 = destination_0;
    return $this;
  }
  n1u() {
    return this.r1u_1;
  }
  static c1v(serialName, baseClass, subclasses, subclassSerializers, classAnnotations) {
    var $this = this.b1v(serialName, baseClass, subclasses, subclassSerializers);
    $this.s1u_1 = asList(classAnnotations);
    return $this;
  }
  w1t() {
    var tmp0 = this.t1u_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory_0();
    return tmp0.n1();
  }
  p1u(decoder, klassName) {
    // Inline function 'kotlin.collections.get' call
    var this_0 = this.v1u_1;
    var tmp0_elvis_lhs = (isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).h3(klassName);
    return tmp0_elvis_lhs == null ? super.p1u(decoder, klassName) : tmp0_elvis_lhs;
  }
  q1u(encoder, value) {
    var tmp0_elvis_lhs = this.u1u_1.h3(getKClassFromExpression(value));
    var tmp1_safe_receiver = tmp0_elvis_lhs == null ? super.q1u(encoder, value) : tmp0_elvis_lhs;
    var tmp;
    if (tmp1_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlinx.serialization.internal.cast' call
      tmp = isInterface(tmp1_safe_receiver, SerializationStrategy) ? tmp1_safe_receiver : THROW_CCE();
    }
    return tmp;
  }
}
class SerializationException extends IllegalArgumentException {
  static h1v() {
    var $this = this.zd();
    init_kotlinx_serialization_SerializationException($this);
    return $this;
  }
  static i1v(message) {
    var $this = this.t(message);
    init_kotlinx_serialization_SerializationException($this);
    return $this;
  }
  static j1v(message, cause) {
    var $this = this.ae(message, cause);
    init_kotlinx_serialization_SerializationException($this);
    return $this;
  }
}
class MissingFieldException extends SerializationException {
  static q1v(missingFields, message, cause) {
    var $this = this.j1v(message, cause);
    captureStack($this, $this.p1v_1);
    $this.o1v_1 = missingFields;
    return $this;
  }
  static r1v(missingFields, serialName) {
    return this.q1v(missingFields, missingFields.b1() === 1 ? "Field '" + missingFields.f1(0) + "' is required for type with serial name '" + serialName + "', but it was missing" : 'Fields ' + toString(missingFields) + " are required for type with serial name '" + serialName + "', but they were missing", null);
  }
  static s1v(missingField, serialName) {
    return this.q1v(listOf(missingField), "Field '" + missingField + "' is required for type with serial name '" + serialName + "', but it was missing", null);
  }
}
class UnknownFieldException extends SerializationException {
  static y1v(message) {
    var $this = this.i1v(message);
    captureStack($this, $this.x1v_1);
    return $this;
  }
  static z1v(index) {
    return this.y1v('An unknown field for index ' + index);
  }
}
class SerialDescriptor {}
function get_isNullable() {
  return false;
}
function get_isInline() {
  return false;
}
function get_annotations() {
  return emptyList();
}
class ContextDescriptor {
  constructor(original, kClass) {
    this.g1w_1 = original;
    this.h1w_1 = kClass;
    this.i1w_1 = this.g1w_1.z1u() + '<' + this.h1w_1.hf() + '>';
  }
  z1u() {
    return this.i1w_1;
  }
  equals(other) {
    var tmp0_elvis_lhs = other instanceof ContextDescriptor ? other : null;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return false;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var another = tmp;
    return equals(this.g1w_1, another.g1w_1) && another.h1w_1.equals(this.h1w_1);
  }
  hashCode() {
    var result = this.h1w_1.hashCode();
    result = imul(31, result) + getStringHashCode(this.i1w_1) | 0;
    return result;
  }
  toString() {
    return 'ContextDescriptor(kClass: ' + toString(this.h1w_1) + ', original: ' + toString(this.g1w_1) + ')';
  }
  j1w() {
    return this.g1w_1.j1w();
  }
  f1w() {
    return this.g1w_1.f1w();
  }
  k1w() {
    return this.g1w_1.k1w();
  }
  l1w() {
    return this.g1w_1.l1w();
  }
  m1w() {
    return this.g1w_1.m1w();
  }
  n1w(index) {
    return this.g1w_1.n1w(index);
  }
  o1w(name) {
    return this.g1w_1.o1w(name);
  }
  p1w(index) {
    return this.g1w_1.p1w(index);
  }
  q1w(index) {
    return this.g1w_1.q1w(index);
  }
  r1w(index) {
    return this.g1w_1.r1w(index);
  }
}
class elementDescriptors$1 {
  constructor($this_elementDescriptors) {
    this.w1w_1 = $this_elementDescriptors;
    this.v1w_1 = $this_elementDescriptors.l1w();
  }
  z() {
    return this.v1w_1 > 0;
  }
  a1() {
    var tmp = this.w1w_1.l1w();
    var _unary__edvuaz = this.v1w_1;
    this.v1w_1 = _unary__edvuaz - 1 | 0;
    return this.w1w_1.q1w(tmp - _unary__edvuaz | 0);
  }
}
class elementDescriptors$$inlined$Iterable$1 {
  constructor($this_elementDescriptors) {
    this.x1w_1 = $this_elementDescriptors;
  }
  y() {
    return new elementDescriptors$1(this.x1w_1);
  }
}
class elementNames$1 {
  constructor($this_elementNames) {
    this.z1w_1 = $this_elementNames;
    this.y1w_1 = $this_elementNames.l1w();
  }
  z() {
    return this.y1w_1 > 0;
  }
  a1() {
    var tmp = this.z1w_1.l1w();
    var _unary__edvuaz = this.y1w_1;
    this.y1w_1 = _unary__edvuaz - 1 | 0;
    return this.z1w_1.n1w(tmp - _unary__edvuaz | 0);
  }
}
class elementNames$$inlined$Iterable$1 {
  constructor($this_elementNames) {
    this.a1x_1 = $this_elementNames;
  }
  y() {
    return new elementNames$1(this.a1x_1);
  }
}
class ClassSerialDescriptorBuilder {
  constructor(serialName) {
    this.z1t_1 = serialName;
    this.a1u_1 = false;
    this.b1u_1 = emptyList();
    this.c1u_1 = ArrayList.k();
    this.d1u_1 = HashSet.ga();
    this.e1u_1 = ArrayList.k();
    this.f1u_1 = ArrayList.k();
    this.g1u_1 = ArrayList.k();
  }
  b1x(elementName, descriptor, annotations, isOptional) {
    // Inline function 'kotlin.require' call
    if (!this.d1u_1.l(elementName)) {
      var message = "Element with name '" + elementName + "' is already registered in " + this.z1t_1;
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.collections.plusAssign' call
    this.c1u_1.l(elementName);
    // Inline function 'kotlin.collections.plusAssign' call
    this.e1u_1.l(descriptor);
    // Inline function 'kotlin.collections.plusAssign' call
    this.f1u_1.l(annotations);
    // Inline function 'kotlin.collections.plusAssign' call
    this.g1u_1.l(isOptional);
  }
  h1u(elementName, descriptor, annotations, isOptional, $super) {
    annotations = annotations === VOID ? emptyList() : annotations;
    isOptional = isOptional === VOID ? false : isOptional;
    var tmp;
    if ($super === VOID) {
      this.b1x(elementName, descriptor, annotations, isOptional);
      tmp = Unit_instance;
    } else {
      tmp = $super.b1x.call(this, elementName, descriptor, annotations, isOptional);
    }
    return tmp;
  }
}
class CachedNames {}
class SerialDescriptorImpl {
  constructor(serialName, kind, elementsCount, typeParameters, builder) {
    this.c1x_1 = serialName;
    this.d1x_1 = kind;
    this.e1x_1 = elementsCount;
    this.f1x_1 = builder.b1u_1;
    this.g1x_1 = toHashSet(builder.c1u_1);
    var tmp = this;
    // Inline function 'kotlin.collections.toTypedArray' call
    var this_0 = builder.c1u_1;
    tmp.h1x_1 = copyToArray(this_0);
    this.i1x_1 = compactArray(builder.e1u_1);
    var tmp_0 = this;
    // Inline function 'kotlin.collections.toTypedArray' call
    var this_1 = builder.f1u_1;
    tmp_0.j1x_1 = copyToArray(this_1);
    this.k1x_1 = toBooleanArray(builder.g1u_1);
    var tmp_1 = this;
    // Inline function 'kotlin.collections.map' call
    var this_2 = withIndex(this.h1x_1);
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(this_2, 10));
    var _iterator__ex2g4s = this_2.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$2 = to(item.jl_1, item.il_1);
      destination.l(tmp$ret$2);
    }
    tmp_1.l1x_1 = toMap(destination);
    this.m1x_1 = compactArray(typeParameters);
    var tmp_2 = this;
    tmp_2.n1x_1 = lazy_0(SerialDescriptorImpl$_hashCode$delegate$lambda(this));
  }
  z1u() {
    return this.c1x_1;
  }
  j1w() {
    return this.d1x_1;
  }
  l1w() {
    return this.e1x_1;
  }
  m1w() {
    return this.f1x_1;
  }
  o1x() {
    return this.g1x_1;
  }
  n1w(index) {
    return getChecked(this.h1x_1, index);
  }
  o1w(name) {
    var tmp0_elvis_lhs = this.l1x_1.h3(name);
    return tmp0_elvis_lhs == null ? -3 : tmp0_elvis_lhs;
  }
  p1w(index) {
    return getChecked(this.j1x_1, index);
  }
  q1w(index) {
    return getChecked(this.i1x_1, index);
  }
  r1w(index) {
    return getChecked_0(this.k1x_1, index);
  }
  equals(other) {
    var tmp$ret$0;
    $l$block_5: {
      // Inline function 'kotlinx.serialization.internal.equalsImpl' call
      if (this === other) {
        tmp$ret$0 = true;
        break $l$block_5;
      }
      if (!(other instanceof SerialDescriptorImpl)) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.z1u() === other.z1u())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!contentEquals(this.m1x_1, other.m1x_1)) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.l1w() === other.l1w())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      var inductionVariable = 0;
      var last = this.l1w();
      if (inductionVariable < last)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(this.q1w(index).z1u() === other.q1w(index).z1u())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
          if (!equals(this.q1w(index).j1w(), other.q1w(index).j1w())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
        }
         while (inductionVariable < last);
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  }
  hashCode() {
    return _get__hashCode__tgwhef(this);
  }
  toString() {
    return toStringImpl(this);
  }
}
class SerialKind {
  toString() {
    return ensureNotNull(getKClassFromExpression(this).hf());
  }
  hashCode() {
    return getStringHashCode(this.toString());
  }
}
class ENUM extends SerialKind {
  constructor() {
    ENUM_instance = null;
    super();
    ENUM_instance = this;
  }
}
class CONTEXTUAL extends SerialKind {
  constructor() {
    CONTEXTUAL_instance = null;
    super();
    CONTEXTUAL_instance = this;
  }
}
class PolymorphicKind extends SerialKind {}
class SEALED extends PolymorphicKind {
  constructor() {
    SEALED_instance = null;
    super();
    SEALED_instance = this;
  }
}
class OPEN extends PolymorphicKind {
  constructor() {
    OPEN_instance = null;
    super();
    OPEN_instance = this;
  }
}
class PrimitiveKind extends SerialKind {}
class BOOLEAN extends PrimitiveKind {
  constructor() {
    BOOLEAN_instance = null;
    super();
    BOOLEAN_instance = this;
  }
}
class BYTE extends PrimitiveKind {
  constructor() {
    BYTE_instance = null;
    super();
    BYTE_instance = this;
  }
}
class CHAR extends PrimitiveKind {
  constructor() {
    CHAR_instance = null;
    super();
    CHAR_instance = this;
  }
}
class SHORT extends PrimitiveKind {
  constructor() {
    SHORT_instance = null;
    super();
    SHORT_instance = this;
  }
}
class INT extends PrimitiveKind {
  constructor() {
    INT_instance = null;
    super();
    INT_instance = this;
  }
}
class LONG extends PrimitiveKind {
  constructor() {
    LONG_instance = null;
    super();
    LONG_instance = this;
  }
}
class FLOAT extends PrimitiveKind {
  constructor() {
    FLOAT_instance = null;
    super();
    FLOAT_instance = this;
  }
}
class DOUBLE extends PrimitiveKind {
  constructor() {
    DOUBLE_instance = null;
    super();
    DOUBLE_instance = this;
  }
}
class STRING extends PrimitiveKind {
  constructor() {
    STRING_instance = null;
    super();
    STRING_instance = this;
  }
}
class StructureKind extends SerialKind {}
class CLASS extends StructureKind {
  constructor() {
    CLASS_instance = null;
    super();
    CLASS_instance = this;
  }
}
class LIST extends StructureKind {
  constructor() {
    LIST_instance = null;
    super();
    LIST_instance = this;
  }
}
class MAP extends StructureKind {
  constructor() {
    MAP_instance = null;
    super();
    MAP_instance = this;
  }
}
class OBJECT extends StructureKind {
  constructor() {
    OBJECT_instance = null;
    super();
    OBJECT_instance = this;
  }
}
class Decoder {}
function decodeSerializableValue(deserializer) {
  return deserializer.y1t(this);
}
class CompositeDecoder {}
function decodeSequentially() {
  return false;
}
function decodeCollectionSize(descriptor) {
  return -1;
}
function decodeSerializableElement$default(descriptor, index, deserializer, previousValue, $super) {
  previousValue = previousValue === VOID ? null : previousValue;
  return $super === VOID ? this.r1y(descriptor, index, deserializer, previousValue) : $super.r1y.call(this, descriptor, index, deserializer, previousValue);
}
class AbstractDecoder {
  p1x() {
    throw SerializationException.i1v(toString(getKClassFromExpression(this)) + " can't retrieve untyped values");
  }
  q1x() {
    return true;
  }
  r1x() {
    return null;
  }
  s1x() {
    var tmp = this.p1x();
    return typeof tmp === 'boolean' ? tmp : THROW_CCE();
  }
  t1x() {
    var tmp = this.p1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  u1x() {
    var tmp = this.p1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  v1x() {
    var tmp = this.p1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  w1x() {
    var tmp = this.p1x();
    return tmp instanceof Long ? tmp : THROW_CCE();
  }
  x1x() {
    var tmp = this.p1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  y1x() {
    var tmp = this.p1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  z1x() {
    var tmp = this.p1x();
    return tmp instanceof Char ? tmp.j2_1 : THROW_CCE();
  }
  a1y() {
    var tmp = this.p1x();
    return typeof tmp === 'string' ? tmp : THROW_CCE();
  }
  b1y(enumDescriptor) {
    var tmp = this.p1x();
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  c1y(descriptor) {
    return this;
  }
  d1y(deserializer, previousValue) {
    return this.e1y(deserializer);
  }
  f1y(descriptor) {
    return this;
  }
  g1y(descriptor) {
  }
  h1y(descriptor, index) {
    return this.s1x();
  }
  i1y(descriptor, index) {
    return this.t1x();
  }
  j1y(descriptor, index) {
    return this.u1x();
  }
  k1y(descriptor, index) {
    return this.v1x();
  }
  l1y(descriptor, index) {
    return this.w1x();
  }
  m1y(descriptor, index) {
    return this.x1x();
  }
  n1y(descriptor, index) {
    return this.y1x();
  }
  o1y(descriptor, index) {
    return this.z1x();
  }
  p1y(descriptor, index) {
    return this.a1y();
  }
  q1y(descriptor, index) {
    return this.c1y(descriptor.q1w(index));
  }
  r1y(descriptor, index, deserializer, previousValue) {
    return this.d1y(deserializer, previousValue);
  }
  t1y(descriptor, index, deserializer, previousValue) {
    // Inline function 'kotlinx.serialization.encoding.decodeIfNullable' call
    var isNullabilitySupported = deserializer.w1t().f1w();
    var tmp;
    if (isNullabilitySupported || this.q1x()) {
      tmp = this.d1y(deserializer, previousValue);
    } else {
      tmp = this.r1x();
    }
    return tmp;
  }
}
class Encoder {}
function encodeNotNullMark() {
}
function beginCollection(descriptor, collectionSize) {
  return this.f1y(descriptor);
}
function encodeSerializableValue(serializer, value) {
  serializer.x1t(this, value);
}
function encodeNullableSerializableValue(serializer, value) {
  var isNullabilitySupported = serializer.w1t().f1w();
  if (isNullabilitySupported) {
    return this.y1z(isInterface(serializer, SerializationStrategy) ? serializer : THROW_CCE(), value);
  }
  if (value == null) {
    this.b1z();
  } else {
    this.b20();
    this.y1z(serializer, value);
  }
}
class CompositeEncoder {}
function shouldEncodeElementDefault(descriptor, index) {
  return true;
}
class AbstractEncoder {
  static y1y($box) {
    return createThis(this, $box);
  }
  f1y(descriptor) {
    return this;
  }
  g1y(descriptor) {
  }
  z1y(descriptor, index) {
    return true;
  }
  a1z(value) {
    throw SerializationException.i1v('Non-serializable ' + toString(getKClassFromExpression(value)) + ' is not supported by ' + toString(getKClassFromExpression(this)) + ' encoder');
  }
  b1z() {
    throw SerializationException.i1v("'null' is not supported by default");
  }
  c1z(value) {
    return this.a1z(value);
  }
  d1z(value) {
    return this.a1z(value);
  }
  e1z(value) {
    return this.a1z(value);
  }
  f1z(value) {
    return this.a1z(value);
  }
  g1z(value) {
    return this.a1z(value);
  }
  h1z(value) {
    return this.a1z(value);
  }
  i1z(value) {
    return this.a1z(value);
  }
  j1z(value) {
    return this.a1z(new Char(value));
  }
  k1z(value) {
    return this.a1z(value);
  }
  l1z(enumDescriptor, index) {
    return this.a1z(index);
  }
  m1z(descriptor) {
    return this;
  }
  n1z(descriptor, index, value) {
    if (this.z1y(descriptor, index)) {
      this.c1z(value);
    }
  }
  o1z(descriptor, index, value) {
    if (this.z1y(descriptor, index)) {
      this.d1z(value);
    }
  }
  p1z(descriptor, index, value) {
    if (this.z1y(descriptor, index)) {
      this.e1z(value);
    }
  }
  q1z(descriptor, index, value) {
    if (this.z1y(descriptor, index)) {
      this.f1z(value);
    }
  }
  r1z(descriptor, index, value) {
    if (this.z1y(descriptor, index)) {
      this.g1z(value);
    }
  }
  s1z(descriptor, index, value) {
    if (this.z1y(descriptor, index)) {
      this.h1z(value);
    }
  }
  t1z(descriptor, index, value) {
    if (this.z1y(descriptor, index)) {
      this.i1z(value);
    }
  }
  u1z(descriptor, index, value) {
    if (this.z1y(descriptor, index)) {
      this.j1z(value);
    }
  }
  v1z(descriptor, index, value) {
    if (this.z1y(descriptor, index)) {
      this.k1z(value);
    }
  }
  w1z(descriptor, index) {
    return this.z1y(descriptor, index) ? this.m1z(descriptor.q1w(index)) : NoOpEncoder_getInstance();
  }
  x1z(descriptor, index, serializer, value) {
    if (this.z1y(descriptor, index)) {
      this.y1z(serializer, value);
    }
  }
  z1z(descriptor, index, serializer, value) {
    if (this.z1y(descriptor, index)) {
      this.a20(serializer, value);
    }
  }
}
class NothingSerializer {
  constructor() {
    NothingSerializer_instance = this;
    this.g20_1 = NothingSerialDescriptor_getInstance();
  }
  w1t() {
    return this.g20_1;
  }
  h20(encoder, value) {
    throw SerializationException.i1v("'kotlin.Nothing' cannot be serialized");
  }
  x1t(encoder, value) {
    var tmp;
    if (false) {
      tmp = value;
    } else {
      tmp = THROW_CCE();
    }
    return this.h20(encoder, tmp);
  }
  y1t(decoder) {
    throw SerializationException.i1v("'kotlin.Nothing' does not have instances");
  }
}
class DurationSerializer {
  constructor() {
    DurationSerializer_instance = this;
    this.i20_1 = new PrimitiveSerialDescriptor('kotlin.time.Duration', STRING_getInstance());
  }
  w1t() {
    return this.i20_1;
  }
  j20(encoder, value) {
    encoder.k1z(Duration__toIsoString_impl_9h6wsm(value));
  }
  x1t(encoder, value) {
    return this.j20(encoder, value instanceof Duration ? value.lj_1 : THROW_CCE());
  }
  k20(decoder) {
    return Companion_getInstance().cr(decoder.a1y());
  }
  y1t(decoder) {
    return new Duration(this.k20(decoder));
  }
}
class UuidSerializer {
  constructor() {
    UuidSerializer_instance = this;
    this.l20_1 = new PrimitiveSerialDescriptor('kotlin.uuid.Uuid', STRING_getInstance());
  }
  w1t() {
    return this.l20_1;
  }
  m20(encoder, value) {
    encoder.k1z(value.toString());
  }
  x1t(encoder, value) {
    return this.m20(encoder, value instanceof Uuid ? value : THROW_CCE());
  }
  y1t(decoder) {
    return Companion_getInstance_0().wr(decoder.a1y());
  }
}
class ListLikeDescriptor {
  constructor(elementDescriptor) {
    this.p20_1 = elementDescriptor;
    this.q20_1 = 1;
  }
  j1w() {
    return LIST_getInstance();
  }
  l1w() {
    return this.q20_1;
  }
  n1w(index) {
    return index.toString();
  }
  o1w(name) {
    var tmp0_elvis_lhs = toIntOrNull(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException.t(name + ' is not a valid list index');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  r1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.z1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return false;
  }
  p1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.z1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return emptyList();
  }
  q1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.z1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return this.p20_1;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ListLikeDescriptor))
      return false;
    if (equals(this.p20_1, other.p20_1) && this.z1u() === other.z1u())
      return true;
    return false;
  }
  hashCode() {
    return imul(hashCode(this.p20_1), 31) + getStringHashCode(this.z1u()) | 0;
  }
  toString() {
    return this.z1u() + '(' + toString(this.p20_1) + ')';
  }
}
class ArrayListClassDesc extends ListLikeDescriptor {
  z1u() {
    return 'kotlin.collections.ArrayList';
  }
}
class HashSetClassDesc extends ListLikeDescriptor {
  z1u() {
    return 'kotlin.collections.HashSet';
  }
}
class LinkedHashSetClassDesc extends ListLikeDescriptor {
  z1u() {
    return 'kotlin.collections.LinkedHashSet';
  }
}
class MapLikeDescriptor {
  constructor(serialName, keyDescriptor, valueDescriptor) {
    this.v20_1 = serialName;
    this.w20_1 = keyDescriptor;
    this.x20_1 = valueDescriptor;
    this.y20_1 = 2;
  }
  z1u() {
    return this.v20_1;
  }
  j1w() {
    return MAP_getInstance();
  }
  l1w() {
    return this.y20_1;
  }
  n1w(index) {
    return index.toString();
  }
  o1w(name) {
    var tmp0_elvis_lhs = toIntOrNull(name);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw IllegalArgumentException.t(name + ' is not a valid map index');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  r1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.z1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return false;
  }
  p1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.z1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    return emptyList();
  }
  q1w(index) {
    // Inline function 'kotlin.require' call
    if (!(index >= 0)) {
      var message = 'Illegal index ' + index + ', ' + this.z1u() + ' expects only non-negative indices';
      throw IllegalArgumentException.t(toString(message));
    }
    var tmp;
    switch (index % 2 | 0) {
      case 0:
        tmp = this.w20_1;
        break;
      case 1:
        tmp = this.x20_1;
        break;
      default:
        var message_0 = 'Unreached';
        throw IllegalStateException.t4(toString(message_0));
    }
    return tmp;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MapLikeDescriptor))
      return false;
    if (!(this.z1u() === other.z1u()))
      return false;
    if (!equals(this.w20_1, other.w20_1))
      return false;
    if (!equals(this.x20_1, other.x20_1))
      return false;
    return true;
  }
  hashCode() {
    var result = getStringHashCode(this.z1u());
    result = imul(31, result) + hashCode(this.w20_1) | 0;
    result = imul(31, result) + hashCode(this.x20_1) | 0;
    return result;
  }
  toString() {
    return this.z1u() + '(' + toString(this.w20_1) + ', ' + toString(this.x20_1) + ')';
  }
}
class HashMapClassDesc extends MapLikeDescriptor {
  constructor(keyDesc, valueDesc) {
    super('kotlin.collections.HashMap', keyDesc, valueDesc);
  }
}
class LinkedHashMapClassDesc extends MapLikeDescriptor {
  constructor(keyDesc, valueDesc) {
    super('kotlin.collections.LinkedHashMap', keyDesc, valueDesc);
  }
}
class ArrayClassDesc extends ListLikeDescriptor {
  z1u() {
    return 'kotlin.Array';
  }
}
class PrimitiveArrayDescriptor extends ListLikeDescriptor {
  constructor(primitive) {
    super(primitive);
    this.d21_1 = primitive.z1u() + 'Array';
  }
  z1u() {
    return this.d21_1;
  }
}
class AbstractCollectionSerializer {
  z21(decoder, previous) {
    var tmp1_elvis_lhs = previous == null ? null : this.m21(previous);
    var builder = tmp1_elvis_lhs == null ? this.g21() : tmp1_elvis_lhs;
    var startIndex = this.i21(builder);
    var compositeDecoder = decoder.f1y(this.w1t());
    if (compositeDecoder.v1y()) {
      this.w21(compositeDecoder, builder, startIndex, readSize(this, compositeDecoder, builder));
    } else {
      $l$loop: while (true) {
        var index = compositeDecoder.w1y(this.w1t());
        if (index === -1)
          break $l$loop;
        this.y21(compositeDecoder, startIndex + index | 0, builder);
      }
    }
    compositeDecoder.g1y(this.w1t());
    return this.k21(builder);
  }
  y1t(decoder) {
    return this.z21(decoder, null);
  }
  y21(decoder, index, builder, checkIndex, $super) {
    checkIndex = checkIndex === VOID ? true : checkIndex;
    var tmp;
    if ($super === VOID) {
      this.x21(decoder, index, builder, checkIndex);
      tmp = Unit_instance;
    } else {
      tmp = $super.x21.call(this, decoder, index, builder, checkIndex);
    }
    return tmp;
  }
}
class CollectionLikeSerializer extends AbstractCollectionSerializer {
  constructor(elementSerializer) {
    super();
    this.u21_1 = elementSerializer;
  }
  v21(encoder, value) {
    var size = this.r22(value);
    // Inline function 'kotlinx.serialization.encoding.encodeCollection' call
    var descriptor = this.w1t();
    var composite = encoder.c20(descriptor, size);
    var iterator = this.t22(value);
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        composite.x1z(this.w1t(), index, this.u21_1, iterator.a1());
      }
       while (inductionVariable < size);
    composite.g1y(descriptor);
  }
  x1t(encoder, value) {
    return this.v21(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  w21(decoder, builder, startIndex, size) {
    // Inline function 'kotlin.require' call
    if (!(size >= 0)) {
      var message = 'Size must be known in advance when using READ_ALL';
      throw IllegalArgumentException.t(toString(message));
    }
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        this.x21(decoder, startIndex + index | 0, builder, false);
      }
       while (inductionVariable < size);
  }
  x21(decoder, index, builder, checkIndex) {
    this.q21(builder, index, decoder.s1y(this.w1t(), index, this.u21_1));
  }
}
class CollectionSerializer extends CollectionLikeSerializer {
  s21(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  r22(_this__u8e3s4) {
    return this.s21((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Collection) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  t21(_this__u8e3s4) {
    return _this__u8e3s4.y();
  }
  t22(_this__u8e3s4) {
    return this.t21((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Collection) : false) ? _this__u8e3s4 : THROW_CCE());
  }
}
class ArrayListSerializer extends CollectionSerializer {
  constructor(element) {
    super(element);
    this.f21_1 = new ArrayListClassDesc(element.w1t());
  }
  w1t() {
    return this.f21_1;
  }
  g21() {
    // Inline function 'kotlin.collections.arrayListOf' call
    return ArrayList.k();
  }
  h21(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  i21(_this__u8e3s4) {
    return this.h21(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
  }
  j21(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  k21(_this__u8e3s4) {
    return this.j21(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
  }
  l21(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? ArrayList.h(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  m21(_this__u8e3s4) {
    return this.l21((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtList) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  n21(_this__u8e3s4, size) {
    return _this__u8e3s4.y7(size);
  }
  o21(_this__u8e3s4, size) {
    return this.n21(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE(), size);
  }
  p21(_this__u8e3s4, index, element) {
    _this__u8e3s4.d3(index, element);
  }
  q21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE();
    return this.p21(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class HashSetSerializer extends CollectionSerializer {
  constructor(eSerializer) {
    super(eSerializer);
    this.b22_1 = new HashSetClassDesc(eSerializer.w1t());
  }
  w1t() {
    return this.b22_1;
  }
  g21() {
    return HashSet.ga();
  }
  c22(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  i21(_this__u8e3s4) {
    return this.c22(_this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE());
  }
  d22(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  k21(_this__u8e3s4) {
    return this.d22(_this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE());
  }
  e22(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? HashSet.ha(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  m21(_this__u8e3s4) {
    return this.e22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtSet) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  f22(_this__u8e3s4, size) {
  }
  o21(_this__u8e3s4, size) {
    return this.f22(_this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE(), size);
  }
  g22(_this__u8e3s4, index, element) {
    _this__u8e3s4.l(element);
  }
  q21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof HashSet ? _this__u8e3s4 : THROW_CCE();
    return this.g22(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class LinkedHashSetSerializer extends CollectionSerializer {
  constructor(eSerializer) {
    super(eSerializer);
    this.i22_1 = new LinkedHashSetClassDesc(eSerializer.w1t());
  }
  w1t() {
    return this.i22_1;
  }
  g21() {
    // Inline function 'kotlin.collections.linkedSetOf' call
    return LinkedHashSet.g1();
  }
  j22(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  i21(_this__u8e3s4) {
    return this.j22(_this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE());
  }
  k22(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  k21(_this__u8e3s4) {
    return this.k22(_this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE());
  }
  e22(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? LinkedHashSet.j1(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  m21(_this__u8e3s4) {
    return this.e22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtSet) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  l22(_this__u8e3s4, size) {
  }
  o21(_this__u8e3s4, size) {
    return this.l22(_this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE(), size);
  }
  m22(_this__u8e3s4, index, element) {
    _this__u8e3s4.l(element);
  }
  q21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof LinkedHashSet ? _this__u8e3s4 : THROW_CCE();
    return this.m22(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class MapLikeSerializer extends AbstractCollectionSerializer {
  constructor(keySerializer, valueSerializer) {
    super();
    this.y22_1 = keySerializer;
    this.z22_1 = valueSerializer;
  }
  a23(decoder, builder, startIndex, size) {
    // Inline function 'kotlin.require' call
    if (!(size >= 0)) {
      var message = 'Size must be known in advance when using READ_ALL';
      throw IllegalArgumentException.t(toString(message));
    }
    var progression = step(until(0, imul(size, 2)), 2);
    var inductionVariable = progression.t1_1;
    var last = progression.u1_1;
    var step_0 = progression.v1_1;
    if (step_0 > 0 && inductionVariable <= last || (step_0 < 0 && last <= inductionVariable))
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + step_0 | 0;
        this.b23(decoder, startIndex + index | 0, builder, false);
      }
       while (!(index === last));
  }
  w21(decoder, builder, startIndex, size) {
    return this.a23(decoder, (!(builder == null) ? isInterface(builder, KtMutableMap) : false) ? builder : THROW_CCE(), startIndex, size);
  }
  b23(decoder, index, builder, checkIndex) {
    var key = decoder.s1y(this.w1t(), index, this.y22_1);
    var tmp;
    if (checkIndex) {
      // Inline function 'kotlin.also' call
      var this_0 = decoder.w1y(this.w1t());
      // Inline function 'kotlin.require' call
      if (!(this_0 === (index + 1 | 0))) {
        var message = 'Value must follow key in a map, index for key: ' + index + ', returned index for value: ' + this_0;
        throw IllegalArgumentException.t(toString(message));
      }
      tmp = this_0;
    } else {
      tmp = index + 1 | 0;
    }
    var vIndex = tmp;
    var tmp_0;
    var tmp_1;
    if (builder.f3(key)) {
      var tmp_2 = this.z22_1.w1t().j1w();
      tmp_1 = !(tmp_2 instanceof PrimitiveKind);
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      tmp_0 = decoder.r1y(this.w1t(), vIndex, this.z22_1, getValue(builder, key));
    } else {
      tmp_0 = decoder.s1y(this.w1t(), vIndex, this.z22_1);
    }
    var value = tmp_0;
    // Inline function 'kotlin.collections.set' call
    builder.k3(key, value);
  }
  x21(decoder, index, builder, checkIndex) {
    return this.b23(decoder, index, (!(builder == null) ? isInterface(builder, KtMutableMap) : false) ? builder : THROW_CCE(), checkIndex);
  }
  v21(encoder, value) {
    var size = this.r22(value);
    // Inline function 'kotlinx.serialization.encoding.encodeCollection' call
    var descriptor = this.w1t();
    var composite = encoder.c20(descriptor, size);
    var iterator = this.t22(value);
    var index = 0;
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = iterator;
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var k = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var v = element.n1();
      var tmp = this.w1t();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      composite.x1z(tmp, _unary__edvuaz, this.y22_1, k);
      var tmp_0 = this.w1t();
      var _unary__edvuaz_0 = index;
      index = _unary__edvuaz_0 + 1 | 0;
      composite.x1z(tmp_0, _unary__edvuaz_0, this.z22_1, v);
    }
    composite.g1y(descriptor);
  }
  x1t(encoder, value) {
    return this.v21(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
}
class HashMapSerializer extends MapLikeSerializer {
  constructor(kSerializer, vSerializer) {
    super(kSerializer, vSerializer);
    this.p22_1 = new HashMapClassDesc(kSerializer.w1t(), vSerializer.w1t());
  }
  w1t() {
    return this.p22_1;
  }
  q22(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  r22(_this__u8e3s4) {
    return this.q22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  s22(_this__u8e3s4) {
    // Inline function 'kotlin.collections.iterator' call
    return _this__u8e3s4.l1().y();
  }
  t22(_this__u8e3s4) {
    return this.s22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  g21() {
    return HashMap.l8();
  }
  u22(_this__u8e3s4) {
    return imul(_this__u8e3s4.b1(), 2);
  }
  i21(_this__u8e3s4) {
    return this.u22(_this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : THROW_CCE());
  }
  v22(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  k21(_this__u8e3s4) {
    return this.v22(_this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : THROW_CCE());
  }
  w22(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? HashMap.a9(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  m21(_this__u8e3s4) {
    return this.w22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  x22(_this__u8e3s4, size) {
  }
  o21(_this__u8e3s4, size) {
    return this.x22(_this__u8e3s4 instanceof HashMap ? _this__u8e3s4 : THROW_CCE(), size);
  }
}
class LinkedHashMapSerializer extends MapLikeSerializer {
  constructor(kSerializer, vSerializer) {
    super(kSerializer, vSerializer);
    this.e23_1 = new LinkedHashMapClassDesc(kSerializer.w1t(), vSerializer.w1t());
  }
  w1t() {
    return this.e23_1;
  }
  q22(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  r22(_this__u8e3s4) {
    return this.q22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  s22(_this__u8e3s4) {
    // Inline function 'kotlin.collections.iterator' call
    return _this__u8e3s4.l1().y();
  }
  t22(_this__u8e3s4) {
    return this.s22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  g21() {
    return LinkedHashMap.hc();
  }
  f23(_this__u8e3s4) {
    return imul(_this__u8e3s4.b1(), 2);
  }
  i21(_this__u8e3s4) {
    return this.f23(_this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : THROW_CCE());
  }
  g23(_this__u8e3s4) {
    return _this__u8e3s4;
  }
  k21(_this__u8e3s4) {
    return this.g23(_this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : THROW_CCE());
  }
  w22(_this__u8e3s4) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : null;
    return tmp0_elvis_lhs == null ? LinkedHashMap.jc(_this__u8e3s4) : tmp0_elvis_lhs;
  }
  m21(_this__u8e3s4) {
    return this.w22((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, KtMap) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  h23(_this__u8e3s4, size) {
  }
  o21(_this__u8e3s4, size) {
    return this.h23(_this__u8e3s4 instanceof LinkedHashMap ? _this__u8e3s4 : THROW_CCE(), size);
  }
}
class ReferenceArraySerializer extends CollectionLikeSerializer {
  constructor(kClass, eSerializer) {
    super(eSerializer);
    this.j23_1 = kClass;
    this.k23_1 = new ArrayClassDesc(eSerializer.w1t());
  }
  w1t() {
    return this.k23_1;
  }
  l23(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  r22(_this__u8e3s4) {
    return this.l23((!(_this__u8e3s4 == null) ? isArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  m23(_this__u8e3s4) {
    return arrayIterator(_this__u8e3s4);
  }
  t22(_this__u8e3s4) {
    return this.m23((!(_this__u8e3s4 == null) ? isArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  g21() {
    // Inline function 'kotlin.collections.arrayListOf' call
    return ArrayList.k();
  }
  n23(_this__u8e3s4) {
    return _this__u8e3s4.b1();
  }
  i21(_this__u8e3s4) {
    return this.n23(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
  }
  o23(_this__u8e3s4) {
    return toNativeArrayImpl(_this__u8e3s4, this.j23_1);
  }
  k21(_this__u8e3s4) {
    return this.o23(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE());
  }
  p23(_this__u8e3s4) {
    return ArrayList.h(asList(_this__u8e3s4));
  }
  m21(_this__u8e3s4) {
    return this.p23((!(_this__u8e3s4 == null) ? isArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  q23(_this__u8e3s4, size) {
    return _this__u8e3s4.y7(size);
  }
  o21(_this__u8e3s4, size) {
    return this.q23(_this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE(), size);
  }
  r23(_this__u8e3s4, index, element) {
    _this__u8e3s4.d3(index, element);
  }
  q21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof ArrayList ? _this__u8e3s4 : THROW_CCE();
    return this.r23(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
}
class PrimitiveArraySerializer extends CollectionLikeSerializer {
  constructor(primitiveSerializer) {
    super(primitiveSerializer);
    this.t23_1 = new PrimitiveArrayDescriptor(primitiveSerializer.w1t());
  }
  w1t() {
    return this.t23_1;
  }
  u23(_this__u8e3s4) {
    return _this__u8e3s4.v23();
  }
  i21(_this__u8e3s4) {
    return this.u23(_this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE());
  }
  w23(_this__u8e3s4) {
    return _this__u8e3s4.x23();
  }
  k21(_this__u8e3s4) {
    return this.w23(_this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE());
  }
  y23(_this__u8e3s4, size) {
    return _this__u8e3s4.z23(size);
  }
  o21(_this__u8e3s4, size) {
    return this.y23(_this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE(), size);
  }
  a24(_this__u8e3s4) {
    var message = 'This method lead to boxing and must not be used, use writeContents instead';
    throw IllegalStateException.t4(toString(message));
  }
  t22(_this__u8e3s4) {
    return this.a24((_this__u8e3s4 == null ? true : !(_this__u8e3s4 == null)) ? _this__u8e3s4 : THROW_CCE());
  }
  b24(_this__u8e3s4, index, element) {
    var message = 'This method lead to boxing and must not be used, use Builder.append instead';
    throw IllegalStateException.t4(toString(message));
  }
  q21(_this__u8e3s4, index, element) {
    var tmp = _this__u8e3s4 instanceof PrimitiveArrayBuilder ? _this__u8e3s4 : THROW_CCE();
    return this.b24(tmp, index, (element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
  g21() {
    return this.m21(this.c24());
  }
  f24(encoder, value) {
    var size = this.r22(value);
    // Inline function 'kotlinx.serialization.encoding.encodeCollection' call
    var descriptor = this.t23_1;
    var composite = encoder.c20(descriptor, size);
    this.e24(composite, value, size);
    composite.g1y(descriptor);
  }
  x1t(encoder, value) {
    return this.f24(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  v21(encoder, value) {
    return this.f24(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  y1t(decoder) {
    return this.z21(decoder, null);
  }
}
class PrimitiveArrayBuilder {
  g24(requiredCapacity, $super) {
    requiredCapacity = requiredCapacity === VOID ? this.v23() + 1 | 0 : requiredCapacity;
    var tmp;
    if ($super === VOID) {
      this.z23(requiredCapacity);
      tmp = Unit_instance;
    } else {
      tmp = $super.z23.call(this, requiredCapacity);
    }
    return tmp;
  }
}
class Companion {
  constructor() {
    Companion_instance_0 = this;
    this.h24_1 = longArray(0);
  }
}
class ElementMarker {
  constructor(descriptor, readIfAbsent) {
    Companion_getInstance_7();
    this.i24_1 = descriptor;
    this.j24_1 = readIfAbsent;
    var elementsCount = this.i24_1.l1w();
    if (elementsCount <= 64) {
      var tmp = this;
      var tmp_0;
      if (elementsCount === 64) {
        tmp_0 = new Long(0, 0);
      } else {
        tmp_0 = (new Long(-1, -1)).e4(elementsCount);
      }
      tmp.k24_1 = tmp_0;
      this.l24_1 = Companion_getInstance_7().h24_1;
    } else {
      this.k24_1 = new Long(0, 0);
      this.l24_1 = prepareHighMarksArray(this, elementsCount);
    }
  }
  m24(index) {
    if (index < 64) {
      this.k24_1 = this.k24_1.i4((new Long(1, 0)).e4(index));
    } else {
      markHigh(this, index);
    }
  }
  n24() {
    var elementsCount = this.i24_1.l1w();
    while (!this.k24_1.equals(new Long(-1, -1))) {
      var index = countTrailingZeroBits(this.k24_1.c4());
      this.k24_1 = this.k24_1.i4((new Long(1, 0)).e4(index));
      if (this.j24_1(this.i24_1, index)) {
        return index;
      }
    }
    if (elementsCount > 64) {
      return nextUnmarkedHighIndex(this);
    }
    return -1;
  }
}
class EnumSerializer {
  constructor(serialName, values) {
    this.o24_1 = values;
    this.p24_1 = null;
    var tmp = this;
    tmp.q24_1 = lazy_0(EnumSerializer$descriptor$delegate$lambda(this, serialName));
  }
  w1t() {
    var tmp0 = this.q24_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory_1();
    return tmp0.n1();
  }
  e25(encoder, value) {
    var index = indexOf(this.o24_1, value);
    if (index === -1) {
      throw SerializationException.i1v(toString(value) + ' is not a valid enum ' + this.w1t().z1u() + ', ' + ('must be one of ' + contentToString(this.o24_1)));
    }
    encoder.l1z(this.w1t(), index);
  }
  x1t(encoder, value) {
    return this.e25(encoder, value instanceof Enum ? value : THROW_CCE());
  }
  y1t(decoder) {
    var index = decoder.b1y(this.w1t());
    if (!(0 <= index ? index <= (this.o24_1.length - 1 | 0) : false)) {
      throw SerializationException.i1v('' + index + ' is not among valid ' + this.w1t().z1u() + ' enum values, ' + ('values size is ' + this.o24_1.length));
    }
    return this.o24_1[index];
  }
  toString() {
    return 'kotlinx.serialization.internal.EnumSerializer<' + this.w1t().z1u() + '>';
  }
}
class PluginGeneratedSerialDescriptor {
  constructor(serialName, generatedSerializer, elementsCount) {
    generatedSerializer = generatedSerializer === VOID ? null : generatedSerializer;
    this.r24_1 = serialName;
    this.s24_1 = generatedSerializer;
    this.t24_1 = elementsCount;
    this.u24_1 = -1;
    var tmp = this;
    var tmp_0 = 0;
    var tmp_1 = this.t24_1;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_2 = Array(tmp_1);
    while (tmp_0 < tmp_1) {
      tmp_2[tmp_0] = '[UNINITIALIZED]';
      tmp_0 = tmp_0 + 1 | 0;
    }
    tmp.v24_1 = tmp_2;
    var tmp_3 = this;
    // Inline function 'kotlin.arrayOfNulls' call
    var size = this.t24_1;
    tmp_3.w24_1 = Array(size);
    this.x24_1 = null;
    this.y24_1 = booleanArray(this.t24_1);
    this.z24_1 = emptyMap();
    var tmp_4 = this;
    var tmp_5 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp_4.a25_1 = lazy(tmp_5, PluginGeneratedSerialDescriptor$childSerializers$delegate$lambda(this));
    var tmp_6 = this;
    var tmp_7 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp_6.b25_1 = lazy(tmp_7, PluginGeneratedSerialDescriptor$typeParameterDescriptors$delegate$lambda(this));
    var tmp_8 = this;
    var tmp_9 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp_8.c25_1 = lazy(tmp_9, PluginGeneratedSerialDescriptor$_hashCode$delegate$lambda(this));
  }
  z1u() {
    return this.r24_1;
  }
  l1w() {
    return this.t24_1;
  }
  j1w() {
    return CLASS_getInstance();
  }
  m1w() {
    var tmp0_elvis_lhs = this.x24_1;
    return tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  }
  o1x() {
    return this.z24_1.i3();
  }
  t25() {
    var tmp0 = this.b25_1;
    // Inline function 'kotlin.getValue' call
    typeParameterDescriptors$factory();
    return tmp0.n1();
  }
  u25(name, isOptional) {
    this.u24_1 = this.u24_1 + 1 | 0;
    this.v24_1[this.u24_1] = name;
    this.y24_1[this.u24_1] = isOptional;
    this.w24_1[this.u24_1] = null;
    if (this.u24_1 === (this.t24_1 - 1 | 0)) {
      this.z24_1 = buildIndices(this);
    }
  }
  d25(name, isOptional, $super) {
    isOptional = isOptional === VOID ? false : isOptional;
    var tmp;
    if ($super === VOID) {
      this.u25(name, isOptional);
      tmp = Unit_instance;
    } else {
      tmp = $super.u25.call(this, name, isOptional);
    }
    return tmp;
  }
  q1w(index) {
    return getChecked(_get_childSerializers__7vnyfa(this), index).w1t();
  }
  r1w(index) {
    return getChecked_0(this.y24_1, index);
  }
  p1w(index) {
    var tmp0_elvis_lhs = getChecked(this.w24_1, index);
    return tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
  }
  n1w(index) {
    return getChecked(this.v24_1, index);
  }
  o1w(name) {
    var tmp0_elvis_lhs = this.z24_1.h3(name);
    return tmp0_elvis_lhs == null ? -3 : tmp0_elvis_lhs;
  }
  equals(other) {
    var tmp$ret$0;
    $l$block_5: {
      // Inline function 'kotlinx.serialization.internal.equalsImpl' call
      if (this === other) {
        tmp$ret$0 = true;
        break $l$block_5;
      }
      if (!(other instanceof PluginGeneratedSerialDescriptor)) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.z1u() === other.z1u())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!contentEquals(this.t25(), other.t25())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.l1w() === other.l1w())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      var inductionVariable = 0;
      var last = this.l1w();
      if (inductionVariable < last)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(this.q1w(index).z1u() === other.q1w(index).z1u())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
          if (!equals(this.q1w(index).j1w(), other.q1w(index).j1w())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
        }
         while (inductionVariable < last);
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  }
  hashCode() {
    return _get__hashCode__tgwhef_0(this);
  }
  toString() {
    return toStringImpl(this);
  }
}
class EnumDescriptor extends PluginGeneratedSerialDescriptor {
  constructor(name, elementsCount) {
    super(name, VOID, elementsCount);
    this.r25_1 = ENUM_getInstance();
    var tmp = this;
    tmp.s25_1 = lazy_0(EnumDescriptor$elementDescriptors$delegate$lambda(elementsCount, name, this));
  }
  j1w() {
    return this.r25_1;
  }
  q1w(index) {
    return getChecked(_get_elementDescriptors__y23q9p(this), index);
  }
  equals(other) {
    if (this === other)
      return true;
    if (other == null)
      return false;
    if (!(!(other == null) ? isInterface(other, SerialDescriptor) : false))
      return false;
    if (!(other.j1w() === ENUM_getInstance()))
      return false;
    if (!(this.z1u() === other.z1u()))
      return false;
    if (!equals(cachedSerialNames(this), cachedSerialNames(other)))
      return false;
    return true;
  }
  toString() {
    return joinToString(get_elementNames(this), ', ', this.z1u() + '(', ')');
  }
  hashCode() {
    var result = getStringHashCode(this.z1u());
    // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy' call
    // Inline function 'kotlin.collections.fold' call
    var accumulator = 1;
    var _iterator__ex2g4s = get_elementNames(this).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      var hash = accumulator;
      var tmp = imul(31, hash);
      // Inline function 'kotlin.hashCode' call
      var tmp1_elvis_lhs = element == null ? null : hashCode(element);
      accumulator = tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
    }
    var elementsHashCode = accumulator;
    result = imul(31, result) + elementsHashCode | 0;
    return result;
  }
}
class InlineClassDescriptor extends PluginGeneratedSerialDescriptor {
  constructor(name, generatedSerializer) {
    super(name, generatedSerializer, 1);
    this.h26_1 = true;
  }
  k1w() {
    return this.h26_1;
  }
  hashCode() {
    return imul(super.hashCode(), 31);
  }
  equals(other) {
    var tmp$ret$0;
    $l$block_5: {
      // Inline function 'kotlinx.serialization.internal.equalsImpl' call
      if (this === other) {
        tmp$ret$0 = true;
        break $l$block_5;
      }
      if (!(other instanceof InlineClassDescriptor)) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.z1u() === other.z1u())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(other.h26_1 && contentEquals(this.t25(), other.t25()))) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      if (!(this.l1w() === other.l1w())) {
        tmp$ret$0 = false;
        break $l$block_5;
      }
      var inductionVariable = 0;
      var last = this.l1w();
      if (inductionVariable < last)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          if (!(this.q1w(index).z1u() === other.q1w(index).z1u())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
          if (!equals(this.q1w(index).j1w(), other.q1w(index).j1w())) {
            tmp$ret$0 = false;
            break $l$block_5;
          }
        }
         while (inductionVariable < last);
      tmp$ret$0 = true;
    }
    return tmp$ret$0;
  }
}
class GeneratedSerializer {}
function typeParametersSerializers() {
  return get_EMPTY_SERIALIZER_ARRAY();
}
class InlinePrimitiveDescriptor$1 {
  constructor($primitiveSerializer) {
    this.i26_1 = $primitiveSerializer;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [this.i26_1];
  }
  w1t() {
    var message = 'unsupported';
    throw IllegalStateException.t4(toString(message));
  }
  x1t(encoder, value) {
    // Inline function 'kotlin.error' call
    var message = 'unsupported';
    throw IllegalStateException.t4(toString(message));
  }
  y1t(decoder) {
    // Inline function 'kotlin.error' call
    var message = 'unsupported';
    throw IllegalStateException.t4(toString(message));
  }
}
class NoOpEncoder extends AbstractEncoder {
  static m26() {
    NoOpEncoder_instance = null;
    var $this = this.y1y();
    NoOpEncoder_instance = $this;
    $this.l26_1 = EmptySerializersModule_0();
    return $this;
  }
  u1y() {
    return this.l26_1;
  }
  a1z(value) {
    return Unit_instance;
  }
  b1z() {
    return Unit_instance;
  }
  c1z(value) {
    return Unit_instance;
  }
  d1z(value) {
    return Unit_instance;
  }
  e1z(value) {
    return Unit_instance;
  }
  f1z(value) {
    return Unit_instance;
  }
  g1z(value) {
    return Unit_instance;
  }
  h1z(value) {
    return Unit_instance;
  }
  i1z(value) {
    return Unit_instance;
  }
  j1z(value) {
    return Unit_instance;
  }
  k1z(value) {
    return Unit_instance;
  }
  l1z(enumDescriptor, index) {
    return Unit_instance;
  }
}
class NothingSerialDescriptor {
  constructor() {
    NothingSerialDescriptor_instance = this;
    this.n26_1 = OBJECT_getInstance();
    this.o26_1 = 'kotlin.Nothing';
  }
  j1w() {
    return this.n26_1;
  }
  z1u() {
    return this.o26_1;
  }
  l1w() {
    return 0;
  }
  n1w(index) {
    error(this);
  }
  o1w(name) {
    error(this);
  }
  r1w(index) {
    error(this);
  }
  q1w(index) {
    error(this);
  }
  p1w(index) {
    error(this);
  }
  toString() {
    return 'NothingSerialDescriptor';
  }
  equals(other) {
    return this === other;
  }
  hashCode() {
    return getStringHashCode(this.o26_1) + imul(31, this.n26_1.hashCode()) | 0;
  }
}
class NullableSerializer {
  constructor(serializer) {
    this.p26_1 = serializer;
    this.q26_1 = new SerialDescriptorForNullable(this.p26_1.w1t());
  }
  w1t() {
    return this.q26_1;
  }
  r26(encoder, value) {
    if (!(value == null)) {
      encoder.b20();
      encoder.y1z(this.p26_1, value);
    } else {
      encoder.b1z();
    }
  }
  x1t(encoder, value) {
    return this.r26(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  y1t(decoder) {
    return decoder.q1x() ? decoder.e1y(this.p26_1) : decoder.r1x();
  }
  equals(other) {
    if (this === other)
      return true;
    if (other == null || !getKClassFromExpression(this).equals(getKClassFromExpression(other)))
      return false;
    if (!(other instanceof NullableSerializer))
      THROW_CCE();
    if (!equals(this.p26_1, other.p26_1))
      return false;
    return true;
  }
  hashCode() {
    return hashCode(this.p26_1);
  }
}
class SerialDescriptorForNullable {
  constructor(original) {
    this.s1w_1 = original;
    this.t1w_1 = this.s1w_1.z1u() + '?';
    this.u1w_1 = cachedSerialNames(this.s1w_1);
  }
  z1u() {
    return this.t1w_1;
  }
  o1x() {
    return this.u1w_1;
  }
  f1w() {
    return true;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof SerialDescriptorForNullable))
      return false;
    if (!equals(this.s1w_1, other.s1w_1))
      return false;
    return true;
  }
  toString() {
    return toString(this.s1w_1) + '?';
  }
  hashCode() {
    return imul(hashCode(this.s1w_1), 31);
  }
  j1w() {
    return this.s1w_1.j1w();
  }
  k1w() {
    return this.s1w_1.k1w();
  }
  l1w() {
    return this.s1w_1.l1w();
  }
  m1w() {
    return this.s1w_1.m1w();
  }
  n1w(index) {
    return this.s1w_1.n1w(index);
  }
  o1w(name) {
    return this.s1w_1.o1w(name);
  }
  p1w(index) {
    return this.s1w_1.p1w(index);
  }
  q1w(index) {
    return this.s1w_1.q1w(index);
  }
  r1w(index) {
    return this.s1w_1.r1w(index);
  }
}
class ObjectSerializer {
  constructor(serialName, objectInstance) {
    this.s26_1 = objectInstance;
    this.t26_1 = emptyList();
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    tmp.u26_1 = lazy(tmp_0, ObjectSerializer$descriptor$delegate$lambda(serialName, this));
  }
  w1t() {
    var tmp0 = this.u26_1;
    // Inline function 'kotlin.getValue' call
    descriptor$factory_2();
    return tmp0.n1();
  }
  o1u(encoder, value) {
    encoder.f1y(this.w1t()).g1y(this.w1t());
  }
  x1t(encoder, value) {
    return this.o1u(encoder, !(value == null) ? value : THROW_CCE());
  }
  y1t(decoder) {
    // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
    var descriptor = this.w1t();
    var composite = decoder.f1y(descriptor);
    var tmp$ret$0;
    $l$block_0: {
      if (composite.v1y()) {
        tmp$ret$0 = Unit_instance;
        break $l$block_0;
      }
      var index = composite.w1y(this.w1t());
      if (index === -1) {
        tmp$ret$0 = Unit_instance;
        break $l$block_0;
      } else
        throw SerializationException.i1v('Unexpected index ' + index);
    }
    var result = tmp$ret$0;
    composite.g1y(descriptor);
    return this.s26_1;
  }
}
class SerializerFactory {}
class CharArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    CharArraySerializer_instance = null;
    super(serializer_2(Companion_getInstance_1()));
    CharArraySerializer_instance = this;
  }
  y26(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  r22(_this__u8e3s4) {
    return this.y26((!(_this__u8e3s4 == null) ? isCharArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  z26(_this__u8e3s4) {
    return new CharArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.z26((!(_this__u8e3s4 == null) ? isCharArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  c24() {
    return charArray(0);
  }
  a27(decoder, index, builder, checkIndex) {
    builder.d27(decoder.o1y(this.t23_1, index));
  }
  x21(decoder, index, builder, checkIndex) {
    return this.a27(decoder, index, builder instanceof CharArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.a27(decoder, index, builder instanceof CharArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  e27(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.u1z(this.t23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.e27(encoder, (!(content == null) ? isCharArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class DoubleArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    DoubleArraySerializer_instance = null;
    super(serializer_3(DoubleCompanionObject_instance));
    DoubleArraySerializer_instance = this;
  }
  h27(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  r22(_this__u8e3s4) {
    return this.h27((!(_this__u8e3s4 == null) ? isDoubleArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  i27(_this__u8e3s4) {
    return new DoubleArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.i27((!(_this__u8e3s4 == null) ? isDoubleArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  c24() {
    return new Float64Array(0);
  }
  j27(decoder, index, builder, checkIndex) {
    builder.m27(decoder.n1y(this.t23_1, index));
  }
  x21(decoder, index, builder, checkIndex) {
    return this.j27(decoder, index, builder instanceof DoubleArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.j27(decoder, index, builder instanceof DoubleArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  n27(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.t1z(this.t23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.n27(encoder, (!(content == null) ? isDoubleArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class FloatArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    FloatArraySerializer_instance = null;
    super(serializer_4(FloatCompanionObject_instance));
    FloatArraySerializer_instance = this;
  }
  q27(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  r22(_this__u8e3s4) {
    return this.q27((!(_this__u8e3s4 == null) ? isFloatArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  r27(_this__u8e3s4) {
    return new FloatArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.r27((!(_this__u8e3s4 == null) ? isFloatArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  c24() {
    return new Float32Array(0);
  }
  s27(decoder, index, builder, checkIndex) {
    builder.v27(decoder.m1y(this.t23_1, index));
  }
  x21(decoder, index, builder, checkIndex) {
    return this.s27(decoder, index, builder instanceof FloatArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.s27(decoder, index, builder instanceof FloatArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  w27(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.s1z(this.t23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.w27(encoder, (!(content == null) ? isFloatArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class LongArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    LongArraySerializer_instance = null;
    super(serializer_5(Companion_getInstance_2()));
    LongArraySerializer_instance = this;
  }
  z27(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  r22(_this__u8e3s4) {
    return this.z27((!(_this__u8e3s4 == null) ? isLongArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  a28(_this__u8e3s4) {
    return new LongArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.a28((!(_this__u8e3s4 == null) ? isLongArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  c24() {
    return longArray(0);
  }
  b28(decoder, index, builder, checkIndex) {
    builder.e28(decoder.l1y(this.t23_1, index));
  }
  x21(decoder, index, builder, checkIndex) {
    return this.b28(decoder, index, builder instanceof LongArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.b28(decoder, index, builder instanceof LongArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  f28(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.r1z(this.t23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.f28(encoder, (!(content == null) ? isLongArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class ULongArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    ULongArraySerializer_instance = null;
    super(serializer_6(Companion_getInstance_3()));
    ULongArraySerializer_instance = this;
  }
  i28(_this__u8e3s4) {
    return _ULongArray___get_size__impl__ju6dtr(_this__u8e3s4);
  }
  r22(_this__u8e3s4) {
    return this.i28(_this__u8e3s4 instanceof ULongArray ? _this__u8e3s4.it_1 : THROW_CCE());
  }
  j28(_this__u8e3s4) {
    return new ULongArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.j28(_this__u8e3s4 instanceof ULongArray ? _this__u8e3s4.it_1 : THROW_CCE());
  }
  k28() {
    return _ULongArray___init__impl__twm1l3(0);
  }
  c24() {
    return new ULongArray(this.k28());
  }
  l28(decoder, index, builder, checkIndex) {
    // Inline function 'kotlin.toULong' call
    var this_0 = decoder.q1y(this.t23_1, index).w1x();
    var tmp$ret$0 = _ULong___init__impl__c78o9k(this_0);
    builder.o28(tmp$ret$0);
  }
  x21(decoder, index, builder, checkIndex) {
    return this.l28(decoder, index, builder instanceof ULongArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.l28(decoder, index, builder instanceof ULongArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  p28(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = encoder.w1z(this.t23_1, i);
        // Inline function 'kotlin.ULong.toLong' call
        var this_0 = ULongArray__get_impl_pr71q9(content, i);
        var tmp$ret$0 = _ULong___get_data__impl__fggpzb(this_0);
        tmp.g1z(tmp$ret$0);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.p28(encoder, content instanceof ULongArray ? content.it_1 : THROW_CCE(), size);
  }
}
class IntArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    IntArraySerializer_instance = null;
    super(serializer_7(IntCompanionObject_instance));
    IntArraySerializer_instance = this;
  }
  s28(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  r22(_this__u8e3s4) {
    return this.s28((!(_this__u8e3s4 == null) ? isIntArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  t28(_this__u8e3s4) {
    return new IntArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.t28((!(_this__u8e3s4 == null) ? isIntArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  c24() {
    return new Int32Array(0);
  }
  u28(decoder, index, builder, checkIndex) {
    builder.x28(decoder.k1y(this.t23_1, index));
  }
  x21(decoder, index, builder, checkIndex) {
    return this.u28(decoder, index, builder instanceof IntArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.u28(decoder, index, builder instanceof IntArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  y28(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.q1z(this.t23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.y28(encoder, (!(content == null) ? isIntArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class UIntArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    UIntArraySerializer_instance = null;
    super(serializer_8(Companion_getInstance_4()));
    UIntArraySerializer_instance = this;
  }
  b29(_this__u8e3s4) {
    return _UIntArray___get_size__impl__r6l8ci(_this__u8e3s4);
  }
  r22(_this__u8e3s4) {
    return this.b29(_this__u8e3s4 instanceof UIntArray ? _this__u8e3s4.ws_1 : THROW_CCE());
  }
  c29(_this__u8e3s4) {
    return new UIntArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.c29(_this__u8e3s4 instanceof UIntArray ? _this__u8e3s4.ws_1 : THROW_CCE());
  }
  d29() {
    return _UIntArray___init__impl__ghjpc6(0);
  }
  c24() {
    return new UIntArray(this.d29());
  }
  e29(decoder, index, builder, checkIndex) {
    // Inline function 'kotlin.toUInt' call
    var this_0 = decoder.q1y(this.t23_1, index).v1x();
    var tmp$ret$0 = _UInt___init__impl__l7qpdl(this_0);
    builder.h29(tmp$ret$0);
  }
  x21(decoder, index, builder, checkIndex) {
    return this.e29(decoder, index, builder instanceof UIntArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.e29(decoder, index, builder instanceof UIntArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  i29(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = encoder.w1z(this.t23_1, i);
        // Inline function 'kotlin.UInt.toInt' call
        var this_0 = UIntArray__get_impl_gp5kza(content, i);
        var tmp$ret$0 = _UInt___get_data__impl__f0vqqw(this_0);
        tmp.f1z(tmp$ret$0);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.i29(encoder, content instanceof UIntArray ? content.ws_1 : THROW_CCE(), size);
  }
}
class ShortArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    ShortArraySerializer_instance = null;
    super(serializer_9(ShortCompanionObject_instance));
    ShortArraySerializer_instance = this;
  }
  l29(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  r22(_this__u8e3s4) {
    return this.l29((!(_this__u8e3s4 == null) ? isShortArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  m29(_this__u8e3s4) {
    return new ShortArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.m29((!(_this__u8e3s4 == null) ? isShortArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  c24() {
    return new Int16Array(0);
  }
  n29(decoder, index, builder, checkIndex) {
    builder.q29(decoder.j1y(this.t23_1, index));
  }
  x21(decoder, index, builder, checkIndex) {
    return this.n29(decoder, index, builder instanceof ShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.n29(decoder, index, builder instanceof ShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  r29(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.p1z(this.t23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.r29(encoder, (!(content == null) ? isShortArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class UShortArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    UShortArraySerializer_instance = null;
    super(serializer_10(Companion_getInstance_5()));
    UShortArraySerializer_instance = this;
  }
  u29(_this__u8e3s4) {
    return _UShortArray___get_size__impl__jqto1b(_this__u8e3s4);
  }
  r22(_this__u8e3s4) {
    return this.u29(_this__u8e3s4 instanceof UShortArray ? _this__u8e3s4.ut_1 : THROW_CCE());
  }
  v29(_this__u8e3s4) {
    return new UShortArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.v29(_this__u8e3s4 instanceof UShortArray ? _this__u8e3s4.ut_1 : THROW_CCE());
  }
  w29() {
    return _UShortArray___init__impl__9b26ef(0);
  }
  c24() {
    return new UShortArray(this.w29());
  }
  x29(decoder, index, builder, checkIndex) {
    // Inline function 'kotlin.toUShort' call
    var this_0 = decoder.q1y(this.t23_1, index).u1x();
    var tmp$ret$0 = _UShort___init__impl__jigrne(this_0);
    builder.a2a(tmp$ret$0);
  }
  x21(decoder, index, builder, checkIndex) {
    return this.x29(decoder, index, builder instanceof UShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.x29(decoder, index, builder instanceof UShortArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  b2a(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = encoder.w1z(this.t23_1, i);
        // Inline function 'kotlin.UShort.toShort' call
        var this_0 = UShortArray__get_impl_fnbhmx(content, i);
        var tmp$ret$0 = _UShort___get_data__impl__g0245(this_0);
        tmp.e1z(tmp$ret$0);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.b2a(encoder, content instanceof UShortArray ? content.ut_1 : THROW_CCE(), size);
  }
}
class ByteArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    ByteArraySerializer_instance = null;
    super(serializer_11(ByteCompanionObject_instance));
    ByteArraySerializer_instance = this;
  }
  e2a(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  r22(_this__u8e3s4) {
    return this.e2a((!(_this__u8e3s4 == null) ? isByteArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  f2a(_this__u8e3s4) {
    return new ByteArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.f2a((!(_this__u8e3s4 == null) ? isByteArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  c24() {
    return new Int8Array(0);
  }
  g2a(decoder, index, builder, checkIndex) {
    builder.j2a(decoder.i1y(this.t23_1, index));
  }
  x21(decoder, index, builder, checkIndex) {
    return this.g2a(decoder, index, builder instanceof ByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.g2a(decoder, index, builder instanceof ByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  k2a(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.o1z(this.t23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.k2a(encoder, (!(content == null) ? isByteArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class UByteArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    UByteArraySerializer_instance = null;
    super(serializer_12(Companion_getInstance_6()));
    UByteArraySerializer_instance = this;
  }
  n2a(_this__u8e3s4) {
    return _UByteArray___get_size__impl__h6pkdv(_this__u8e3s4);
  }
  r22(_this__u8e3s4) {
    return this.n2a(_this__u8e3s4 instanceof UByteArray ? _this__u8e3s4.ks_1 : THROW_CCE());
  }
  o2a(_this__u8e3s4) {
    return new UByteArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.o2a(_this__u8e3s4 instanceof UByteArray ? _this__u8e3s4.ks_1 : THROW_CCE());
  }
  p2a() {
    return _UByteArray___init__impl__ip4y9n(0);
  }
  c24() {
    return new UByteArray(this.p2a());
  }
  q2a(decoder, index, builder, checkIndex) {
    // Inline function 'kotlin.toUByte' call
    var this_0 = decoder.q1y(this.t23_1, index).t1x();
    var tmp$ret$0 = _UByte___init__impl__g9hnc4(this_0);
    builder.t2a(tmp$ret$0);
  }
  x21(decoder, index, builder, checkIndex) {
    return this.q2a(decoder, index, builder instanceof UByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.q2a(decoder, index, builder instanceof UByteArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  u2a(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = encoder.w1z(this.t23_1, i);
        // Inline function 'kotlin.UByte.toByte' call
        var this_0 = UByteArray__get_impl_t5f3hv(content, i);
        var tmp$ret$0 = _UByte___get_data__impl__jof9qr(this_0);
        tmp.d1z(tmp$ret$0);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.u2a(encoder, content instanceof UByteArray ? content.ks_1 : THROW_CCE(), size);
  }
}
class BooleanArraySerializer extends PrimitiveArraySerializer {
  constructor() {
    BooleanArraySerializer_instance = null;
    super(serializer_13(BooleanCompanionObject_instance));
    BooleanArraySerializer_instance = this;
  }
  x2a(_this__u8e3s4) {
    return _this__u8e3s4.length;
  }
  r22(_this__u8e3s4) {
    return this.x2a((!(_this__u8e3s4 == null) ? isBooleanArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  y2a(_this__u8e3s4) {
    return new BooleanArrayBuilder(_this__u8e3s4);
  }
  m21(_this__u8e3s4) {
    return this.y2a((!(_this__u8e3s4 == null) ? isBooleanArray(_this__u8e3s4) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  c24() {
    return booleanArray(0);
  }
  z2a(decoder, index, builder, checkIndex) {
    builder.c2b(decoder.h1y(this.t23_1, index));
  }
  x21(decoder, index, builder, checkIndex) {
    return this.z2a(decoder, index, builder instanceof BooleanArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d24(decoder, index, builder, checkIndex) {
    return this.z2a(decoder, index, builder instanceof BooleanArrayBuilder ? builder : THROW_CCE(), checkIndex);
  }
  d2b(encoder, content, size) {
    var inductionVariable = 0;
    if (inductionVariable < size)
      do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        encoder.n1z(this.t23_1, i, content[i]);
      }
       while (inductionVariable < size);
  }
  e24(encoder, content, size) {
    return this.d2b(encoder, (!(content == null) ? isBooleanArray(content) : false) ? content : THROW_CCE(), size);
  }
}
class CharArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.b27_1 = bufferWithData;
    this.c27_1 = bufferWithData.length;
    this.z23(10);
  }
  v23() {
    return this.c27_1;
  }
  z23(requiredCapacity) {
    if (this.b27_1.length < requiredCapacity)
      this.b27_1 = copyOf(this.b27_1, coerceAtLeast(requiredCapacity, imul(this.b27_1.length, 2)));
  }
  d27(c) {
    this.g24();
    var tmp = this.b27_1;
    var _unary__edvuaz = this.c27_1;
    this.c27_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  x23() {
    return copyOf(this.b27_1, this.c27_1);
  }
}
class DoubleArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.k27_1 = bufferWithData;
    this.l27_1 = bufferWithData.length;
    this.z23(10);
  }
  v23() {
    return this.l27_1;
  }
  z23(requiredCapacity) {
    if (this.k27_1.length < requiredCapacity)
      this.k27_1 = copyOf_0(this.k27_1, coerceAtLeast(requiredCapacity, imul(this.k27_1.length, 2)));
  }
  m27(c) {
    this.g24();
    var tmp = this.k27_1;
    var _unary__edvuaz = this.l27_1;
    this.l27_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  x23() {
    return copyOf_0(this.k27_1, this.l27_1);
  }
}
class FloatArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.t27_1 = bufferWithData;
    this.u27_1 = bufferWithData.length;
    this.z23(10);
  }
  v23() {
    return this.u27_1;
  }
  z23(requiredCapacity) {
    if (this.t27_1.length < requiredCapacity)
      this.t27_1 = copyOf_1(this.t27_1, coerceAtLeast(requiredCapacity, imul(this.t27_1.length, 2)));
  }
  v27(c) {
    this.g24();
    var tmp = this.t27_1;
    var _unary__edvuaz = this.u27_1;
    this.u27_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  x23() {
    return copyOf_1(this.t27_1, this.u27_1);
  }
}
class LongArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.c28_1 = bufferWithData;
    this.d28_1 = bufferWithData.length;
    this.z23(10);
  }
  v23() {
    return this.d28_1;
  }
  z23(requiredCapacity) {
    if (this.c28_1.length < requiredCapacity)
      this.c28_1 = copyOf_2(this.c28_1, coerceAtLeast(requiredCapacity, imul(this.c28_1.length, 2)));
  }
  e28(c) {
    this.g24();
    var tmp = this.c28_1;
    var _unary__edvuaz = this.d28_1;
    this.d28_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  x23() {
    return copyOf_2(this.c28_1, this.d28_1);
  }
}
class ULongArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.m28_1 = bufferWithData;
    this.n28_1 = _ULongArray___get_size__impl__ju6dtr(bufferWithData);
    this.z23(10);
  }
  v23() {
    return this.n28_1;
  }
  z23(requiredCapacity) {
    if (_ULongArray___get_size__impl__ju6dtr(this.m28_1) < requiredCapacity) {
      var tmp = this;
      var tmp0 = this.m28_1;
      // Inline function 'kotlin.collections.copyOf' call
      var newSize = coerceAtLeast(requiredCapacity, imul(_ULongArray___get_size__impl__ju6dtr(this.m28_1), 2));
      tmp.m28_1 = _ULongArray___init__impl__twm1l3_0(copyOf_2(_ULongArray___get_storage__impl__28e64j(tmp0), newSize));
    }
  }
  o28(c) {
    this.g24();
    var tmp = this.m28_1;
    var _unary__edvuaz = this.n28_1;
    this.n28_1 = _unary__edvuaz + 1 | 0;
    ULongArray__set_impl_z19mvh(tmp, _unary__edvuaz, c);
  }
  e2b() {
    var tmp0 = this.m28_1;
    // Inline function 'kotlin.collections.copyOf' call
    var newSize = this.n28_1;
    return _ULongArray___init__impl__twm1l3_0(copyOf_2(_ULongArray___get_storage__impl__28e64j(tmp0), newSize));
  }
  x23() {
    return new ULongArray(this.e2b());
  }
}
class IntArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.v28_1 = bufferWithData;
    this.w28_1 = bufferWithData.length;
    this.z23(10);
  }
  v23() {
    return this.w28_1;
  }
  z23(requiredCapacity) {
    if (this.v28_1.length < requiredCapacity)
      this.v28_1 = copyOf_3(this.v28_1, coerceAtLeast(requiredCapacity, imul(this.v28_1.length, 2)));
  }
  x28(c) {
    this.g24();
    var tmp = this.v28_1;
    var _unary__edvuaz = this.w28_1;
    this.w28_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  x23() {
    return copyOf_3(this.v28_1, this.w28_1);
  }
}
class UIntArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.f29_1 = bufferWithData;
    this.g29_1 = _UIntArray___get_size__impl__r6l8ci(bufferWithData);
    this.z23(10);
  }
  v23() {
    return this.g29_1;
  }
  z23(requiredCapacity) {
    if (_UIntArray___get_size__impl__r6l8ci(this.f29_1) < requiredCapacity) {
      var tmp = this;
      var tmp0 = this.f29_1;
      // Inline function 'kotlin.collections.copyOf' call
      var newSize = coerceAtLeast(requiredCapacity, imul(_UIntArray___get_size__impl__r6l8ci(this.f29_1), 2));
      tmp.f29_1 = _UIntArray___init__impl__ghjpc6_0(copyOf_3(_UIntArray___get_storage__impl__92a0v0(tmp0), newSize));
    }
  }
  h29(c) {
    this.g24();
    var tmp = this.f29_1;
    var _unary__edvuaz = this.g29_1;
    this.g29_1 = _unary__edvuaz + 1 | 0;
    UIntArray__set_impl_7f2zu2(tmp, _unary__edvuaz, c);
  }
  f2b() {
    var tmp0 = this.f29_1;
    // Inline function 'kotlin.collections.copyOf' call
    var newSize = this.g29_1;
    return _UIntArray___init__impl__ghjpc6_0(copyOf_3(_UIntArray___get_storage__impl__92a0v0(tmp0), newSize));
  }
  x23() {
    return new UIntArray(this.f2b());
  }
}
class ShortArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.o29_1 = bufferWithData;
    this.p29_1 = bufferWithData.length;
    this.z23(10);
  }
  v23() {
    return this.p29_1;
  }
  z23(requiredCapacity) {
    if (this.o29_1.length < requiredCapacity)
      this.o29_1 = copyOf_4(this.o29_1, coerceAtLeast(requiredCapacity, imul(this.o29_1.length, 2)));
  }
  q29(c) {
    this.g24();
    var tmp = this.o29_1;
    var _unary__edvuaz = this.p29_1;
    this.p29_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  x23() {
    return copyOf_4(this.o29_1, this.p29_1);
  }
}
class UShortArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.y29_1 = bufferWithData;
    this.z29_1 = _UShortArray___get_size__impl__jqto1b(bufferWithData);
    this.z23(10);
  }
  v23() {
    return this.z29_1;
  }
  z23(requiredCapacity) {
    if (_UShortArray___get_size__impl__jqto1b(this.y29_1) < requiredCapacity) {
      var tmp = this;
      var tmp0 = this.y29_1;
      // Inline function 'kotlin.collections.copyOf' call
      var newSize = coerceAtLeast(requiredCapacity, imul(_UShortArray___get_size__impl__jqto1b(this.y29_1), 2));
      tmp.y29_1 = _UShortArray___init__impl__9b26ef_0(copyOf_4(_UShortArray___get_storage__impl__t2jpv5(tmp0), newSize));
    }
  }
  a2a(c) {
    this.g24();
    var tmp = this.y29_1;
    var _unary__edvuaz = this.z29_1;
    this.z29_1 = _unary__edvuaz + 1 | 0;
    UShortArray__set_impl_6d8whp(tmp, _unary__edvuaz, c);
  }
  g2b() {
    var tmp0 = this.y29_1;
    // Inline function 'kotlin.collections.copyOf' call
    var newSize = this.z29_1;
    return _UShortArray___init__impl__9b26ef_0(copyOf_4(_UShortArray___get_storage__impl__t2jpv5(tmp0), newSize));
  }
  x23() {
    return new UShortArray(this.g2b());
  }
}
class ByteArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.h2a_1 = bufferWithData;
    this.i2a_1 = bufferWithData.length;
    this.z23(10);
  }
  v23() {
    return this.i2a_1;
  }
  z23(requiredCapacity) {
    if (this.h2a_1.length < requiredCapacity)
      this.h2a_1 = copyOf_5(this.h2a_1, coerceAtLeast(requiredCapacity, imul(this.h2a_1.length, 2)));
  }
  j2a(c) {
    this.g24();
    var tmp = this.h2a_1;
    var _unary__edvuaz = this.i2a_1;
    this.i2a_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  x23() {
    return copyOf_5(this.h2a_1, this.i2a_1);
  }
}
class UByteArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.r2a_1 = bufferWithData;
    this.s2a_1 = _UByteArray___get_size__impl__h6pkdv(bufferWithData);
    this.z23(10);
  }
  v23() {
    return this.s2a_1;
  }
  z23(requiredCapacity) {
    if (_UByteArray___get_size__impl__h6pkdv(this.r2a_1) < requiredCapacity) {
      var tmp = this;
      var tmp0 = this.r2a_1;
      // Inline function 'kotlin.collections.copyOf' call
      var newSize = coerceAtLeast(requiredCapacity, imul(_UByteArray___get_size__impl__h6pkdv(this.r2a_1), 2));
      tmp.r2a_1 = _UByteArray___init__impl__ip4y9n_0(copyOf_5(_UByteArray___get_storage__impl__d4kctt(tmp0), newSize));
    }
  }
  t2a(c) {
    this.g24();
    var tmp = this.r2a_1;
    var _unary__edvuaz = this.s2a_1;
    this.s2a_1 = _unary__edvuaz + 1 | 0;
    UByteArray__set_impl_jvcicn(tmp, _unary__edvuaz, c);
  }
  h2b() {
    var tmp0 = this.r2a_1;
    // Inline function 'kotlin.collections.copyOf' call
    var newSize = this.s2a_1;
    return _UByteArray___init__impl__ip4y9n_0(copyOf_5(_UByteArray___get_storage__impl__d4kctt(tmp0), newSize));
  }
  x23() {
    return new UByteArray(this.h2b());
  }
}
class BooleanArrayBuilder extends PrimitiveArrayBuilder {
  constructor(bufferWithData) {
    super();
    this.a2b_1 = bufferWithData;
    this.b2b_1 = bufferWithData.length;
    this.z23(10);
  }
  v23() {
    return this.b2b_1;
  }
  z23(requiredCapacity) {
    if (this.a2b_1.length < requiredCapacity)
      this.a2b_1 = copyOf_6(this.a2b_1, coerceAtLeast(requiredCapacity, imul(this.a2b_1.length, 2)));
  }
  c2b(c) {
    this.g24();
    var tmp = this.a2b_1;
    var _unary__edvuaz = this.b2b_1;
    this.b2b_1 = _unary__edvuaz + 1 | 0;
    tmp[_unary__edvuaz] = c;
  }
  x23() {
    return copyOf_6(this.a2b_1, this.b2b_1);
  }
}
class StringSerializer {
  constructor() {
    StringSerializer_instance = this;
    this.i2b_1 = new PrimitiveSerialDescriptor('kotlin.String', STRING_getInstance());
  }
  w1t() {
    return this.i2b_1;
  }
  j2b(encoder, value) {
    return encoder.k1z(value);
  }
  x1t(encoder, value) {
    return this.j2b(encoder, (!(value == null) ? typeof value === 'string' : false) ? value : THROW_CCE());
  }
  y1t(decoder) {
    return decoder.a1y();
  }
}
class CharSerializer {
  constructor() {
    CharSerializer_instance = this;
    this.k2b_1 = new PrimitiveSerialDescriptor('kotlin.Char', CHAR_getInstance());
  }
  w1t() {
    return this.k2b_1;
  }
  l2b(encoder, value) {
    return encoder.j1z(value);
  }
  x1t(encoder, value) {
    return this.l2b(encoder, value instanceof Char ? value.j2_1 : THROW_CCE());
  }
  m2b(decoder) {
    return decoder.z1x();
  }
  y1t(decoder) {
    return new Char(this.m2b(decoder));
  }
}
class DoubleSerializer {
  constructor() {
    DoubleSerializer_instance = this;
    this.n2b_1 = new PrimitiveSerialDescriptor('kotlin.Double', DOUBLE_getInstance());
  }
  w1t() {
    return this.n2b_1;
  }
  o2b(encoder, value) {
    return encoder.i1z(value);
  }
  x1t(encoder, value) {
    return this.o2b(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  y1t(decoder) {
    return decoder.y1x();
  }
}
class FloatSerializer {
  constructor() {
    FloatSerializer_instance = this;
    this.p2b_1 = new PrimitiveSerialDescriptor('kotlin.Float', FLOAT_getInstance());
  }
  w1t() {
    return this.p2b_1;
  }
  q2b(encoder, value) {
    return encoder.h1z(value);
  }
  x1t(encoder, value) {
    return this.q2b(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  y1t(decoder) {
    return decoder.x1x();
  }
}
class LongSerializer {
  constructor() {
    LongSerializer_instance = this;
    this.r2b_1 = new PrimitiveSerialDescriptor('kotlin.Long', LONG_getInstance());
  }
  w1t() {
    return this.r2b_1;
  }
  s2b(encoder, value) {
    return encoder.g1z(value);
  }
  x1t(encoder, value) {
    return this.s2b(encoder, value instanceof Long ? value : THROW_CCE());
  }
  y1t(decoder) {
    return decoder.w1x();
  }
}
class IntSerializer {
  constructor() {
    IntSerializer_instance = this;
    this.t2b_1 = new PrimitiveSerialDescriptor('kotlin.Int', INT_getInstance());
  }
  w1t() {
    return this.t2b_1;
  }
  u2b(encoder, value) {
    return encoder.f1z(value);
  }
  x1t(encoder, value) {
    return this.u2b(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  y1t(decoder) {
    return decoder.v1x();
  }
}
class ShortSerializer {
  constructor() {
    ShortSerializer_instance = this;
    this.v2b_1 = new PrimitiveSerialDescriptor('kotlin.Short', SHORT_getInstance());
  }
  w1t() {
    return this.v2b_1;
  }
  w2b(encoder, value) {
    return encoder.e1z(value);
  }
  x1t(encoder, value) {
    return this.w2b(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  y1t(decoder) {
    return decoder.u1x();
  }
}
class ByteSerializer {
  constructor() {
    ByteSerializer_instance = this;
    this.x2b_1 = new PrimitiveSerialDescriptor('kotlin.Byte', BYTE_getInstance());
  }
  w1t() {
    return this.x2b_1;
  }
  y2b(encoder, value) {
    return encoder.d1z(value);
  }
  x1t(encoder, value) {
    return this.y2b(encoder, (!(value == null) ? typeof value === 'number' : false) ? value : THROW_CCE());
  }
  y1t(decoder) {
    return decoder.t1x();
  }
}
class BooleanSerializer {
  constructor() {
    BooleanSerializer_instance = this;
    this.z2b_1 = new PrimitiveSerialDescriptor('kotlin.Boolean', BOOLEAN_getInstance());
  }
  w1t() {
    return this.z2b_1;
  }
  a2c(encoder, value) {
    return encoder.c1z(value);
  }
  x1t(encoder, value) {
    return this.a2c(encoder, (!(value == null) ? typeof value === 'boolean' : false) ? value : THROW_CCE());
  }
  y1t(decoder) {
    return decoder.s1x();
  }
}
class UnitSerializer {
  constructor() {
    UnitSerializer_instance = this;
    this.b2c_1 = new ObjectSerializer('kotlin.Unit', Unit_instance);
  }
  w1t() {
    return this.b2c_1.w1t();
  }
  c2c(encoder, value) {
    this.b2c_1.o1u(encoder, Unit_instance);
  }
  x1t(encoder, value) {
    return this.c2c(encoder, value instanceof Unit ? value : THROW_CCE());
  }
  d2c(decoder) {
    this.b2c_1.y1t(decoder);
  }
  y1t(decoder) {
    this.d2c(decoder);
    return Unit_instance;
  }
}
class PrimitiveSerialDescriptor {
  constructor(serialName, kind) {
    this.e2c_1 = serialName;
    this.f2c_1 = kind;
  }
  z1u() {
    return this.e2c_1;
  }
  j1w() {
    return this.f2c_1;
  }
  l1w() {
    return 0;
  }
  n1w(index) {
    error_0(this);
  }
  o1w(name) {
    error_0(this);
  }
  r1w(index) {
    error_0(this);
  }
  q1w(index) {
    error_0(this);
  }
  p1w(index) {
    error_0(this);
  }
  toString() {
    return 'PrimitiveDescriptor(' + this.e2c_1 + ')';
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof PrimitiveSerialDescriptor))
      return false;
    if (this.e2c_1 === other.e2c_1 && equals(this.f2c_1, other.f2c_1))
      return true;
    return false;
  }
  hashCode() {
    return getStringHashCode(this.e2c_1) + imul(31, this.f2c_1.hashCode()) | 0;
  }
}
class TaggedEncoder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.arrayListOf' call
    tmp.k2c_1 = ArrayList.k();
  }
  u1y() {
    return EmptySerializersModule_0();
  }
  n2c(tag, value) {
    throw SerializationException.i1v('Non-serializable ' + toString(getKClassFromExpression(value)) + ' is not supported by ' + toString(getKClassFromExpression(this)) + ' encoder');
  }
  o2c(tag) {
  }
  p2c(tag) {
    throw SerializationException.i1v('null is not supported');
  }
  q2c(tag, value) {
    return this.n2c(tag, value);
  }
  r2c(tag, value) {
    return this.n2c(tag, value);
  }
  s2c(tag, value) {
    return this.n2c(tag, value);
  }
  t2c(tag, value) {
    return this.n2c(tag, value);
  }
  u2c(tag, value) {
    return this.n2c(tag, value);
  }
  v2c(tag, value) {
    return this.n2c(tag, value);
  }
  w2c(tag, value) {
    return this.n2c(tag, value);
  }
  x2c(tag, value) {
    return this.n2c(tag, new Char(value));
  }
  y2c(tag, value) {
    return this.n2c(tag, value);
  }
  z2c(tag, enumDescriptor, ordinal) {
    return this.n2c(tag, ordinal);
  }
  a2d(tag, inlineDescriptor) {
    // Inline function 'kotlin.apply' call
    this.d2d(tag);
    return this;
  }
  m1z(descriptor) {
    return this.a2d(this.e2d(), descriptor);
  }
  b20() {
    return this.o2c(this.c2d());
  }
  b1z() {
    return this.p2c(this.e2d());
  }
  c1z(value) {
    return this.w2c(this.e2d(), value);
  }
  d1z(value) {
    return this.r2c(this.e2d(), value);
  }
  e1z(value) {
    return this.s2c(this.e2d(), value);
  }
  f1z(value) {
    return this.q2c(this.e2d(), value);
  }
  g1z(value) {
    return this.t2c(this.e2d(), value);
  }
  h1z(value) {
    return this.u2c(this.e2d(), value);
  }
  i1z(value) {
    return this.v2c(this.e2d(), value);
  }
  j1z(value) {
    return this.x2c(this.e2d(), value);
  }
  k1z(value) {
    return this.y2c(this.e2d(), value);
  }
  l1z(enumDescriptor, index) {
    return this.z2c(this.e2d(), enumDescriptor, index);
  }
  f1y(descriptor) {
    return this;
  }
  g1y(descriptor) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this.k2c_1.h1()) {
      this.e2d();
    }
    this.b2d(descriptor);
  }
  b2d(descriptor) {
  }
  n1z(descriptor, index, value) {
    return this.w2c(this.h2c(descriptor, index), value);
  }
  o1z(descriptor, index, value) {
    return this.r2c(this.h2c(descriptor, index), value);
  }
  p1z(descriptor, index, value) {
    return this.s2c(this.h2c(descriptor, index), value);
  }
  q1z(descriptor, index, value) {
    return this.q2c(this.h2c(descriptor, index), value);
  }
  r1z(descriptor, index, value) {
    return this.t2c(this.h2c(descriptor, index), value);
  }
  s1z(descriptor, index, value) {
    return this.u2c(this.h2c(descriptor, index), value);
  }
  t1z(descriptor, index, value) {
    return this.v2c(this.h2c(descriptor, index), value);
  }
  u1z(descriptor, index, value) {
    return this.x2c(this.h2c(descriptor, index), value);
  }
  v1z(descriptor, index, value) {
    return this.y2c(this.h2c(descriptor, index), value);
  }
  w1z(descriptor, index) {
    return this.a2d(this.h2c(descriptor, index), descriptor.q1w(index));
  }
  x1z(descriptor, index, serializer, value) {
    if (encodeElement(this, descriptor, index)) {
      this.y1z(serializer, value);
    }
  }
  z1z(descriptor, index, serializer, value) {
    if (encodeElement(this, descriptor, index)) {
      this.a20(serializer, value);
    }
  }
  c2d() {
    return last(this.k2c_1);
  }
  l2c() {
    return lastOrNull(this.k2c_1);
  }
  d2d(name) {
    this.k2c_1.l(name);
  }
  e2d() {
    var tmp;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this.k2c_1.h1()) {
      tmp = this.k2c_1.e3(get_lastIndex_0(this.k2c_1));
    } else {
      throw SerializationException.i1v('No tag in stack for requested element');
    }
    return tmp;
  }
}
class NamedValueEncoder extends TaggedEncoder {
  h2c(_this__u8e3s4, index) {
    return this.j2c(this.i2c(_this__u8e3s4, index));
  }
  j2c(nestedName) {
    var tmp0_elvis_lhs = this.l2c();
    return this.m2c(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs, nestedName);
  }
  i2c(descriptor, index) {
    return descriptor.n1w(index);
  }
  m2c(parentName, childName) {
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(parentName) === 0) {
      tmp = childName;
    } else {
      tmp = parentName + '.' + childName;
    }
    return tmp;
  }
}
class TaggedDecoder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.arrayListOf' call
    tmp.h2d_1 = ArrayList.k();
    this.i2d_1 = false;
  }
  u1y() {
    return EmptySerializersModule_0();
  }
  k2d(tag) {
    throw SerializationException.i1v(toString(getKClassFromExpression(this)) + " can't retrieve untyped values");
  }
  l2d(tag) {
    return true;
  }
  m2d(tag) {
    var tmp = this.k2d(tag);
    return typeof tmp === 'boolean' ? tmp : THROW_CCE();
  }
  n2d(tag) {
    var tmp = this.k2d(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  o2d(tag) {
    var tmp = this.k2d(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  p2d(tag) {
    var tmp = this.k2d(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  q2d(tag) {
    var tmp = this.k2d(tag);
    return tmp instanceof Long ? tmp : THROW_CCE();
  }
  r2d(tag) {
    var tmp = this.k2d(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  s2d(tag) {
    var tmp = this.k2d(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  t2d(tag) {
    var tmp = this.k2d(tag);
    return tmp instanceof Char ? tmp.j2_1 : THROW_CCE();
  }
  u2d(tag) {
    var tmp = this.k2d(tag);
    return typeof tmp === 'string' ? tmp : THROW_CCE();
  }
  v2d(tag, enumDescriptor) {
    var tmp = this.k2d(tag);
    return typeof tmp === 'number' ? tmp : THROW_CCE();
  }
  w2d(tag, inlineDescriptor) {
    // Inline function 'kotlin.apply' call
    this.d2d(tag);
    return this;
  }
  d1y(deserializer, previousValue) {
    return this.e1y(deserializer);
  }
  c1y(descriptor) {
    return this.w2d(this.e2d(), descriptor);
  }
  q1x() {
    var tmp0_elvis_lhs = this.l2c();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return false;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var currentTag = tmp;
    return this.l2d(currentTag);
  }
  r1x() {
    return null;
  }
  s1x() {
    return this.m2d(this.e2d());
  }
  t1x() {
    return this.n2d(this.e2d());
  }
  u1x() {
    return this.o2d(this.e2d());
  }
  v1x() {
    return this.p2d(this.e2d());
  }
  w1x() {
    return this.q2d(this.e2d());
  }
  x1x() {
    return this.r2d(this.e2d());
  }
  y1x() {
    return this.s2d(this.e2d());
  }
  z1x() {
    return this.t2d(this.e2d());
  }
  a1y() {
    return this.u2d(this.e2d());
  }
  b1y(enumDescriptor) {
    return this.v2d(this.e2d(), enumDescriptor);
  }
  f1y(descriptor) {
    return this;
  }
  g1y(descriptor) {
  }
  h1y(descriptor, index) {
    return this.m2d(this.h2c(descriptor, index));
  }
  i1y(descriptor, index) {
    return this.n2d(this.h2c(descriptor, index));
  }
  j1y(descriptor, index) {
    return this.o2d(this.h2c(descriptor, index));
  }
  k1y(descriptor, index) {
    return this.p2d(this.h2c(descriptor, index));
  }
  l1y(descriptor, index) {
    return this.q2d(this.h2c(descriptor, index));
  }
  m1y(descriptor, index) {
    return this.r2d(this.h2c(descriptor, index));
  }
  n1y(descriptor, index) {
    return this.s2d(this.h2c(descriptor, index));
  }
  o1y(descriptor, index) {
    return this.t2d(this.h2c(descriptor, index));
  }
  p1y(descriptor, index) {
    return this.u2d(this.h2c(descriptor, index));
  }
  q1y(descriptor, index) {
    return this.w2d(this.h2c(descriptor, index), descriptor.q1w(index));
  }
  r1y(descriptor, index, deserializer, previousValue) {
    var tmp = this.h2c(descriptor, index);
    return tagBlock(this, tmp, TaggedDecoder$decodeSerializableElement$lambda(this, deserializer, previousValue));
  }
  t1y(descriptor, index, deserializer, previousValue) {
    var tmp = this.h2c(descriptor, index);
    return tagBlock(this, tmp, TaggedDecoder$decodeNullableSerializableElement$lambda(this, deserializer, previousValue));
  }
  l2c() {
    return lastOrNull(this.h2d_1);
  }
  d2d(name) {
    this.h2d_1.l(name);
  }
  e2d() {
    var r = this.h2d_1.e3(get_lastIndex_0(this.h2d_1));
    this.i2d_1 = true;
    return r;
  }
}
class NamedValueDecoder extends TaggedDecoder {
  h2c(_this__u8e3s4, index) {
    return this.j2c(this.i2c(_this__u8e3s4, index));
  }
  j2c(nestedName) {
    var tmp0_elvis_lhs = this.l2c();
    return this.m2c(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs, nestedName);
  }
  i2c(descriptor, index) {
    return descriptor.n1w(index);
  }
  m2c(parentName, childName) {
    var tmp;
    // Inline function 'kotlin.text.isEmpty' call
    if (charSequenceLength(parentName) === 0) {
      tmp = childName;
    } else {
      tmp = parentName + '.' + childName;
    }
    return tmp;
  }
  j2d() {
    return this.h2d_1.h1() ? '$' : joinToString(this.h2d_1, '.', '$.');
  }
}
class MapEntry {
  constructor(key, value) {
    this.x2d_1 = key;
    this.y2d_1 = value;
  }
  m1() {
    return this.x2d_1;
  }
  n1() {
    return this.y2d_1;
  }
  toString() {
    return 'MapEntry(key=' + toString_0(this.x2d_1) + ', value=' + toString_0(this.y2d_1) + ')';
  }
  hashCode() {
    var result = this.x2d_1 == null ? 0 : hashCode(this.x2d_1);
    result = imul(result, 31) + (this.y2d_1 == null ? 0 : hashCode(this.y2d_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof MapEntry))
      return false;
    var tmp0_other_with_cast = other instanceof MapEntry ? other : THROW_CCE();
    if (!equals(this.x2d_1, tmp0_other_with_cast.x2d_1))
      return false;
    if (!equals(this.y2d_1, tmp0_other_with_cast.y2d_1))
      return false;
    return true;
  }
}
class KeyValueSerializer {
  constructor(keySerializer, valueSerializer) {
    this.h2e_1 = keySerializer;
    this.i2e_1 = valueSerializer;
  }
  j2e(encoder, value) {
    var structuredEncoder = encoder.f1y(this.w1t());
    structuredEncoder.x1z(this.w1t(), 0, this.h2e_1, this.d2e(value));
    structuredEncoder.x1z(this.w1t(), 1, this.i2e_1, this.f2e(value));
    structuredEncoder.g1y(this.w1t());
  }
  x1t(encoder, value) {
    return this.j2e(encoder, (value == null ? true : !(value == null)) ? value : THROW_CCE());
  }
  y1t(decoder) {
    // Inline function 'kotlinx.serialization.encoding.decodeStructure' call
    var descriptor = this.w1t();
    var composite = decoder.f1y(descriptor);
    var tmp$ret$0;
    $l$block: {
      if (composite.v1y()) {
        var key = composite.s1y(this.w1t(), 0, this.h2e_1);
        var value = composite.s1y(this.w1t(), 1, this.i2e_1);
        tmp$ret$0 = this.g2e(key, value);
        break $l$block;
      }
      var key_0 = get_NULL();
      var value_0 = get_NULL();
      mainLoop: while (true) {
        var idx = composite.w1y(this.w1t());
        switch (idx) {
          case -1:
            break mainLoop;
          case 0:
            key_0 = composite.s1y(this.w1t(), 0, this.h2e_1);
            break;
          case 1:
            value_0 = composite.s1y(this.w1t(), 1, this.i2e_1);
            break;
          default:
            throw SerializationException.i1v('Invalid index: ' + idx);
        }
      }
      if (key_0 === get_NULL())
        throw SerializationException.i1v("Element 'key' is missing");
      if (value_0 === get_NULL())
        throw SerializationException.i1v("Element 'value' is missing");
      var tmp = (key_0 == null ? true : !(key_0 == null)) ? key_0 : THROW_CCE();
      tmp$ret$0 = this.g2e(tmp, (value_0 == null ? true : !(value_0 == null)) ? value_0 : THROW_CCE());
    }
    var result = tmp$ret$0;
    composite.g1y(descriptor);
    return result;
  }
}
class MapEntrySerializer extends KeyValueSerializer {
  constructor(keySerializer, valueSerializer) {
    super(keySerializer, valueSerializer);
    var tmp = this;
    var tmp_0 = MAP_getInstance();
    tmp.b2e_1 = buildSerialDescriptor('kotlin.collections.Map.Entry', tmp_0, [], MapEntrySerializer$descriptor$lambda(keySerializer, valueSerializer));
  }
  w1t() {
    return this.b2e_1;
  }
  c2e(_this__u8e3s4) {
    return _this__u8e3s4.m1();
  }
  d2e(_this__u8e3s4) {
    return this.c2e((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Entry) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  e2e(_this__u8e3s4) {
    return _this__u8e3s4.n1();
  }
  f2e(_this__u8e3s4) {
    return this.e2e((!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Entry) : false) ? _this__u8e3s4 : THROW_CCE());
  }
  g2e(key, value) {
    return new MapEntry(key, value);
  }
}
class PairSerializer extends KeyValueSerializer {
  constructor(keySerializer, valueSerializer) {
    super(keySerializer, valueSerializer);
    var tmp = this;
    tmp.m2e_1 = buildClassSerialDescriptor('kotlin.Pair', [], PairSerializer$descriptor$lambda(keySerializer, valueSerializer));
  }
  w1t() {
    return this.m2e_1;
  }
  n2e(_this__u8e3s4) {
    return _this__u8e3s4.rl_1;
  }
  d2e(_this__u8e3s4) {
    return this.n2e(_this__u8e3s4 instanceof Pair ? _this__u8e3s4 : THROW_CCE());
  }
  o2e(_this__u8e3s4) {
    return _this__u8e3s4.sl_1;
  }
  f2e(_this__u8e3s4) {
    return this.o2e(_this__u8e3s4 instanceof Pair ? _this__u8e3s4 : THROW_CCE());
  }
  g2e(key, value) {
    return to(key, value);
  }
}
class TripleSerializer {
  constructor(aSerializer, bSerializer, cSerializer) {
    this.p2e_1 = aSerializer;
    this.q2e_1 = bSerializer;
    this.r2e_1 = cSerializer;
    var tmp = this;
    tmp.s2e_1 = buildClassSerialDescriptor('kotlin.Triple', [], TripleSerializer$descriptor$lambda(this));
  }
  w1t() {
    return this.s2e_1;
  }
  t2e(encoder, value) {
    var structuredEncoder = encoder.f1y(this.s2e_1);
    structuredEncoder.x1z(this.s2e_1, 0, this.p2e_1, value.tr_1);
    structuredEncoder.x1z(this.s2e_1, 1, this.q2e_1, value.ur_1);
    structuredEncoder.x1z(this.s2e_1, 2, this.r2e_1, value.vr_1);
    structuredEncoder.g1y(this.s2e_1);
  }
  x1t(encoder, value) {
    return this.t2e(encoder, value instanceof Triple ? value : THROW_CCE());
  }
  y1t(decoder) {
    var composite = decoder.f1y(this.s2e_1);
    if (composite.v1y()) {
      return decodeSequentially_1(this, composite);
    }
    return decodeStructure(this, composite);
  }
}
class ULongSerializer {
  constructor() {
    ULongSerializer_instance = this;
    this.u2e_1 = InlinePrimitiveDescriptor('kotlin.ULong', serializer_5(Companion_getInstance_2()));
  }
  w1t() {
    return this.u2e_1;
  }
  v2e(encoder, value) {
    var tmp = encoder.m1z(this.u2e_1);
    // Inline function 'kotlin.ULong.toLong' call
    var tmp$ret$0 = _ULong___get_data__impl__fggpzb(value);
    tmp.g1z(tmp$ret$0);
  }
  x1t(encoder, value) {
    return this.v2e(encoder, value instanceof ULong ? value.dt_1 : THROW_CCE());
  }
  w2e(decoder) {
    // Inline function 'kotlin.toULong' call
    var this_0 = decoder.c1y(this.u2e_1).w1x();
    return _ULong___init__impl__c78o9k(this_0);
  }
  y1t(decoder) {
    return new ULong(this.w2e(decoder));
  }
}
class UIntSerializer {
  constructor() {
    UIntSerializer_instance = this;
    this.x2e_1 = InlinePrimitiveDescriptor('kotlin.UInt', serializer_7(IntCompanionObject_instance));
  }
  w1t() {
    return this.x2e_1;
  }
  y2e(encoder, value) {
    var tmp = encoder.m1z(this.x2e_1);
    // Inline function 'kotlin.UInt.toInt' call
    var tmp$ret$0 = _UInt___get_data__impl__f0vqqw(value);
    tmp.f1z(tmp$ret$0);
  }
  x1t(encoder, value) {
    return this.y2e(encoder, value instanceof UInt ? value.rs_1 : THROW_CCE());
  }
  z2e(decoder) {
    // Inline function 'kotlin.toUInt' call
    var this_0 = decoder.c1y(this.x2e_1).v1x();
    return _UInt___init__impl__l7qpdl(this_0);
  }
  y1t(decoder) {
    return new UInt(this.z2e(decoder));
  }
}
class UShortSerializer {
  constructor() {
    UShortSerializer_instance = this;
    this.a2f_1 = InlinePrimitiveDescriptor('kotlin.UShort', serializer_9(ShortCompanionObject_instance));
  }
  w1t() {
    return this.a2f_1;
  }
  b2f(encoder, value) {
    var tmp = encoder.m1z(this.a2f_1);
    // Inline function 'kotlin.UShort.toShort' call
    var tmp$ret$0 = _UShort___get_data__impl__g0245(value);
    tmp.e1z(tmp$ret$0);
  }
  x1t(encoder, value) {
    return this.b2f(encoder, value instanceof UShort ? value.pt_1 : THROW_CCE());
  }
  c2f(decoder) {
    // Inline function 'kotlin.toUShort' call
    var this_0 = decoder.c1y(this.a2f_1).u1x();
    return _UShort___init__impl__jigrne(this_0);
  }
  y1t(decoder) {
    return new UShort(this.c2f(decoder));
  }
}
class UByteSerializer {
  constructor() {
    UByteSerializer_instance = this;
    this.d2f_1 = InlinePrimitiveDescriptor('kotlin.UByte', serializer_11(ByteCompanionObject_instance));
  }
  w1t() {
    return this.d2f_1;
  }
  e2f(encoder, value) {
    var tmp = encoder.m1z(this.d2f_1);
    // Inline function 'kotlin.UByte.toByte' call
    var tmp$ret$0 = _UByte___get_data__impl__jof9qr(value);
    tmp.d1z(tmp$ret$0);
  }
  x1t(encoder, value) {
    return this.e2f(encoder, value instanceof UByte ? value.fs_1 : THROW_CCE());
  }
  f2f(decoder) {
    // Inline function 'kotlin.toUByte' call
    var this_0 = decoder.c1y(this.d2f_1).t1x();
    return _UByte___init__impl__g9hnc4(this_0);
  }
  y1t(decoder) {
    return new UByte(this.f2f(decoder));
  }
}
class SerializersModule {
  b1w(kClass, typeArgumentsSerializers, $super) {
    typeArgumentsSerializers = typeArgumentsSerializers === VOID ? emptyList() : typeArgumentsSerializers;
    return $super === VOID ? this.c1w(kClass, typeArgumentsSerializers) : $super.c1w.call(this, kClass, typeArgumentsSerializers);
  }
}
class SerialModuleImpl extends SerializersModule {
  constructor(class2ContextualFactory, polyBase2Serializers, polyBase2DefaultSerializerProvider, polyBase2NamedSerializers, polyBase2DefaultDeserializerProvider, hasInterfaceContextualSerializers) {
    super();
    this.h2f_1 = class2ContextualFactory;
    this.i2f_1 = polyBase2Serializers;
    this.j2f_1 = polyBase2DefaultSerializerProvider;
    this.k2f_1 = polyBase2NamedSerializers;
    this.l2f_1 = polyBase2DefaultDeserializerProvider;
    this.m2f_1 = hasInterfaceContextualSerializers;
  }
  a1w() {
    return this.m2f_1;
  }
  f20(baseClass, value) {
    if (!baseClass.if(value))
      return null;
    var tmp0_safe_receiver = this.i2f_1.h3(baseClass);
    var tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.h3(getKClassFromExpression(value));
    var registered = (!(tmp == null) ? isInterface(tmp, SerializationStrategy) : false) ? tmp : null;
    if (!(registered == null))
      return registered;
    var tmp_0 = this.j2f_1.h3(baseClass);
    var tmp1_safe_receiver = (!(tmp_0 == null) ? typeof tmp_0 === 'function' : false) ? tmp_0 : null;
    return tmp1_safe_receiver == null ? null : tmp1_safe_receiver(value);
  }
  e20(baseClass, serializedClassName) {
    var tmp0_safe_receiver = this.k2f_1.h3(baseClass);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.collections.get' call
      tmp = (isInterface(tmp0_safe_receiver, KtMap) ? tmp0_safe_receiver : THROW_CCE()).h3(serializedClassName);
    }
    var tmp_0 = tmp;
    var registered = (!(tmp_0 == null) ? isInterface(tmp_0, KSerializer) : false) ? tmp_0 : null;
    if (!(registered == null))
      return registered;
    var tmp_1 = this.l2f_1.h3(baseClass);
    var tmp1_safe_receiver = (!(tmp_1 == null) ? typeof tmp_1 === 'function' : false) ? tmp_1 : null;
    return tmp1_safe_receiver == null ? null : tmp1_safe_receiver(serializedClassName);
  }
  c1w(kClass, typeArgumentsSerializers) {
    var tmp0_safe_receiver = this.h2f_1.h3(kClass);
    var tmp = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.n2f(typeArgumentsSerializers);
    return (tmp == null ? true : isInterface(tmp, KSerializer)) ? tmp : null;
  }
  g2f(collector) {
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = this.h2f_1.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var kclass = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var serial = element.n1();
      if (serial instanceof Argless) {
        var tmp = isInterface(kclass, KClass) ? kclass : THROW_CCE();
        var tmp_0 = serial.q2f_1;
        collector.r2f(tmp, isInterface(tmp_0, KSerializer) ? tmp_0 : THROW_CCE());
      } else {
        if (serial instanceof WithTypeArguments) {
          collector.p2f(kclass, serial.o2f_1);
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s_0 = this.i2f_1.l1().y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      // Inline function 'kotlin.collections.component1' call
      var baseClass = element_0.m1();
      // Inline function 'kotlin.collections.component2' call
      var classMap = element_0.n1();
      // Inline function 'kotlin.collections.forEach' call
      // Inline function 'kotlin.collections.iterator' call
      var _iterator__ex2g4s_1 = classMap.l1().y();
      while (_iterator__ex2g4s_1.z()) {
        var element_1 = _iterator__ex2g4s_1.a1();
        // Inline function 'kotlin.collections.component1' call
        var actualClass = element_1.m1();
        // Inline function 'kotlin.collections.component2' call
        var serializer = element_1.n1();
        var tmp_1 = isInterface(baseClass, KClass) ? baseClass : THROW_CCE();
        var tmp_2 = isInterface(actualClass, KClass) ? actualClass : THROW_CCE();
        // Inline function 'kotlinx.serialization.internal.cast' call
        var tmp$ret$11 = isInterface(serializer, KSerializer) ? serializer : THROW_CCE();
        collector.s2f(tmp_1, tmp_2, tmp$ret$11);
      }
    }
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s_2 = this.j2f_1.l1().y();
    while (_iterator__ex2g4s_2.z()) {
      var element_2 = _iterator__ex2g4s_2.a1();
      // Inline function 'kotlin.collections.component1' call
      var baseClass_0 = element_2.m1();
      // Inline function 'kotlin.collections.component2' call
      var provider = element_2.n1();
      var tmp_3 = isInterface(baseClass_0, KClass) ? baseClass_0 : THROW_CCE();
      collector.t2f(tmp_3, typeof provider === 'function' ? provider : THROW_CCE());
    }
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s_3 = this.l2f_1.l1().y();
    while (_iterator__ex2g4s_3.z()) {
      var element_3 = _iterator__ex2g4s_3.a1();
      // Inline function 'kotlin.collections.component1' call
      var baseClass_1 = element_3.m1();
      // Inline function 'kotlin.collections.component2' call
      var provider_0 = element_3.n1();
      var tmp_4 = isInterface(baseClass_1, KClass) ? baseClass_1 : THROW_CCE();
      collector.u2f(tmp_4, typeof provider_0 === 'function' ? provider_0 : THROW_CCE());
    }
  }
}
class ContextualProvider {}
class Argless extends ContextualProvider {}
class WithTypeArguments extends ContextualProvider {}
class SerializersModuleCollector {}
function contextual(kClass, serializer) {
  return this.p2f(kClass, SerializersModuleCollector$contextual$lambda(serializer));
}
class SerializableWith {
  constructor(serializer) {
    this.v2f_1 = serializer;
  }
  equals(other) {
    if (!(other instanceof SerializableWith))
      return false;
    var tmp0_other_with_cast = other instanceof SerializableWith ? other : THROW_CCE();
    if (!this.v2f_1.equals(tmp0_other_with_cast.v2f_1))
      return false;
    return true;
  }
  hashCode() {
    return imul(getStringHashCode('serializer'), 127) ^ this.v2f_1.hashCode();
  }
  toString() {
    return '@kotlinx.serialization.SerializableWith(' + 'serializer=' + toString(this.v2f_1) + ')';
  }
}
class createCache$1 {
  constructor($factory) {
    this.w2f_1 = $factory;
  }
  d1w(key) {
    return this.w2f_1(key);
  }
}
class createParametrizedCache$1 {
  constructor($factory) {
    this.x2f_1 = $factory;
  }
  e1w(key, types) {
    // Inline function 'kotlin.runCatching' call
    var tmp;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = this.x2f_1(key, types);
      tmp = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
}
//endregion
function PolymorphicSerializer$descriptor$delegate$lambda$lambda(this$0) {
  return ($this$buildSerialDescriptor) => {
    $this$buildSerialDescriptor.h1u('type', serializer_1(StringCompanionObject_instance).w1t());
    $this$buildSerialDescriptor.h1u('value', buildSerialDescriptor('kotlinx.serialization.Polymorphic<' + this$0.i1u_1.hf() + '>', CONTEXTUAL_getInstance(), []));
    $this$buildSerialDescriptor.b1u_1 = this$0.j1u_1;
    return Unit_instance;
  };
}
function PolymorphicSerializer$descriptor$delegate$lambda(this$0) {
  return () => {
    var tmp = OPEN_getInstance();
    return withContext(buildSerialDescriptor('kotlinx.serialization.Polymorphic', tmp, [], PolymorphicSerializer$descriptor$delegate$lambda$lambda(this$0)), this$0.i1u_1);
  };
}
function findPolymorphicSerializer(_this__u8e3s4, encoder, value) {
  var tmp0_elvis_lhs = _this__u8e3s4.q1u(encoder, value);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throwSubtypeNotRegistered(getKClassFromExpression(value), _this__u8e3s4.n1u());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function findPolymorphicSerializer_0(_this__u8e3s4, decoder, klassName) {
  var tmp0_elvis_lhs = _this__u8e3s4.p1u(decoder, klassName);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throwSubtypeNotRegistered_0(klassName, _this__u8e3s4.n1u());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function descriptor$factory() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.w1t(), null);
}
function SealedClassSerializer$descriptor$delegate$lambda$lambda$lambda(this$0) {
  return ($this$buildSerialDescriptor) => {
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = this$0.v1u_1.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var name = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var serializer = element.n1();
      $this$buildSerialDescriptor.h1u(name, serializer.w1t());
    }
    return Unit_instance;
  };
}
function SealedClassSerializer$descriptor$delegate$lambda$lambda(this$0) {
  return ($this$buildSerialDescriptor) => {
    $this$buildSerialDescriptor.h1u('type', serializer_1(StringCompanionObject_instance).w1t());
    var tmp = 'kotlinx.serialization.Sealed<' + this$0.r1u_1.hf() + '>';
    var tmp_0 = CONTEXTUAL_getInstance();
    var elementDescriptor = buildSerialDescriptor(tmp, tmp_0, [], SealedClassSerializer$descriptor$delegate$lambda$lambda$lambda(this$0));
    $this$buildSerialDescriptor.h1u('value', elementDescriptor);
    $this$buildSerialDescriptor.b1u_1 = this$0.s1u_1;
    return Unit_instance;
  };
}
function SealedClassSerializer$descriptor$delegate$lambda($serialName, this$0) {
  return () => {
    var tmp = SEALED_getInstance();
    return buildSerialDescriptor($serialName, tmp, [], SealedClassSerializer$descriptor$delegate$lambda$lambda(this$0));
  };
}
function descriptor$factory_0() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.w1t(), null);
}
function init_kotlinx_serialization_SerializationException(_this__u8e3s4) {
  captureStack(_this__u8e3s4, _this__u8e3s4.g1v_1);
}
function serializerOrNull(_this__u8e3s4) {
  var tmp0_elvis_lhs = compiledSerializerImpl(_this__u8e3s4);
  return tmp0_elvis_lhs == null ? builtinSerializerOrNull(_this__u8e3s4) : tmp0_elvis_lhs;
}
function serializersForParameters(_this__u8e3s4, typeArguments, failOnMissingTypeArgSerializer) {
  var tmp;
  if (failOnMissingTypeArgSerializer) {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(typeArguments, 10));
    var _iterator__ex2g4s = typeArguments.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = serializer(_this__u8e3s4, item);
      destination.l(tmp$ret$0);
    }
    tmp = destination;
  } else {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(typeArguments, 10));
    var _iterator__ex2g4s_0 = typeArguments.y();
    while (_iterator__ex2g4s_0.z()) {
      var item_0 = _iterator__ex2g4s_0.a1();
      var tmp0_elvis_lhs = serializerOrNull_0(_this__u8e3s4, item_0);
      var tmp_0;
      if (tmp0_elvis_lhs == null) {
        return null;
      } else {
        tmp_0 = tmp0_elvis_lhs;
      }
      var tmp$ret$3 = tmp_0;
      destination_0.l(tmp$ret$3);
    }
    tmp = destination_0;
  }
  var serializers = tmp;
  return serializers;
}
function parametrizedSerializerOrNull(_this__u8e3s4, serializers, elementClassifierIfArray) {
  var tmp0_elvis_lhs = builtinParametrizedSerializer(_this__u8e3s4, serializers, elementClassifierIfArray);
  return tmp0_elvis_lhs == null ? compiledParametrizedSerializer(_this__u8e3s4, serializers) : tmp0_elvis_lhs;
}
function serializer(_this__u8e3s4, type) {
  var tmp0_elvis_lhs = serializerByKTypeImpl(_this__u8e3s4, type, true);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    platformSpecificSerializerNotRegistered(kclass(type));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function serializerOrNull_0(_this__u8e3s4, type) {
  return serializerByKTypeImpl(_this__u8e3s4, type, false);
}
function builtinParametrizedSerializer(_this__u8e3s4, serializers, elementClassifierIfArray) {
  var tmp;
  if (_this__u8e3s4.equals(getKClass(Collection)) || _this__u8e3s4.equals(getKClass(KtList)) || (_this__u8e3s4.equals(getKClass(KtMutableList)) || _this__u8e3s4.equals(getKClass(ArrayList)))) {
    tmp = new ArrayListSerializer(serializers.f1(0));
  } else if (_this__u8e3s4.equals(getKClass(HashSet))) {
    tmp = new HashSetSerializer(serializers.f1(0));
  } else if (_this__u8e3s4.equals(getKClass(KtSet)) || (_this__u8e3s4.equals(getKClass(KtMutableSet)) || _this__u8e3s4.equals(getKClass(LinkedHashSet)))) {
    tmp = new LinkedHashSetSerializer(serializers.f1(0));
  } else if (_this__u8e3s4.equals(getKClass(HashMap))) {
    tmp = new HashMapSerializer(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(KtMap)) || (_this__u8e3s4.equals(getKClass(KtMutableMap)) || _this__u8e3s4.equals(getKClass(LinkedHashMap)))) {
    tmp = new LinkedHashMapSerializer(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(Entry))) {
    tmp = MapEntrySerializer_0(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(Pair))) {
    tmp = PairSerializer_0(serializers.f1(0), serializers.f1(1));
  } else if (_this__u8e3s4.equals(getKClass(Triple))) {
    tmp = TripleSerializer_0(serializers.f1(0), serializers.f1(1), serializers.f1(2));
  } else {
    var tmp_0;
    if (isReferenceArray(_this__u8e3s4)) {
      var tmp_1 = elementClassifierIfArray();
      tmp_0 = ArraySerializer((!(tmp_1 == null) ? isInterface(tmp_1, KClass) : false) ? tmp_1 : THROW_CCE(), serializers.f1(0));
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function compiledParametrizedSerializer(_this__u8e3s4, serializers) {
  // Inline function 'kotlin.collections.toTypedArray' call
  var tmp$ret$0 = copyToArray(serializers);
  return constructSerializerForGivenTypeArgs(_this__u8e3s4, tmp$ret$0.slice());
}
function serializerByKTypeImpl(_this__u8e3s4, type, failOnMissingTypeArgSerializer) {
  var rootClass = kclass(type);
  var isNullable = type.yf();
  // Inline function 'kotlin.collections.map' call
  var this_0 = type.xf();
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    var tmp$ret$0 = typeOrThrow(item);
    destination.l(tmp$ret$0);
  }
  var typeArguments = destination;
  var tmp;
  if (typeArguments.h1()) {
    var tmp_0;
    if (isInterface_0(rootClass) && !(_this__u8e3s4.b1w(rootClass) == null)) {
      tmp_0 = null;
    } else {
      tmp_0 = findCachedSerializer(rootClass, isNullable);
    }
    tmp = tmp_0;
  } else {
    var tmp_1;
    if (_this__u8e3s4.a1w()) {
      tmp_1 = null;
    } else {
      // Inline function 'kotlin.Result.getOrNull' call
      var this_1 = findParametrizedCachedSerializer(rootClass, typeArguments, isNullable);
      var tmp_2;
      if (_Result___get_isFailure__impl__jpiriv(this_1)) {
        tmp_2 = null;
      } else {
        var tmp_3 = _Result___get_value__impl__bjfvqg(this_1);
        tmp_2 = (tmp_3 == null ? true : !(tmp_3 == null)) ? tmp_3 : THROW_CCE();
      }
      tmp_1 = tmp_2;
    }
    tmp = tmp_1;
  }
  var cachedSerializer = tmp;
  if (!(cachedSerializer == null))
    return cachedSerializer;
  var tmp_4;
  if (typeArguments.h1()) {
    var tmp0_elvis_lhs = serializerOrNull(rootClass);
    var tmp1_elvis_lhs = tmp0_elvis_lhs == null ? _this__u8e3s4.b1w(rootClass) : tmp0_elvis_lhs;
    var tmp_5;
    if (tmp1_elvis_lhs == null) {
      // Inline function 'kotlinx.serialization.polymorphicIfInterface' call
      tmp_5 = isInterface_0(rootClass) ? PolymorphicSerializer.l1u(rootClass) : null;
    } else {
      tmp_5 = tmp1_elvis_lhs;
    }
    tmp_4 = tmp_5;
  } else {
    var tmp2_elvis_lhs = serializersForParameters(_this__u8e3s4, typeArguments, failOnMissingTypeArgSerializer);
    var tmp_6;
    if (tmp2_elvis_lhs == null) {
      return null;
    } else {
      tmp_6 = tmp2_elvis_lhs;
    }
    var serializers = tmp_6;
    var tmp3_elvis_lhs = parametrizedSerializerOrNull(rootClass, serializers, serializerByKTypeImpl$lambda(typeArguments));
    var tmp4_elvis_lhs = tmp3_elvis_lhs == null ? _this__u8e3s4.c1w(rootClass, serializers) : tmp3_elvis_lhs;
    var tmp_7;
    if (tmp4_elvis_lhs == null) {
      // Inline function 'kotlinx.serialization.polymorphicIfInterface' call
      tmp_7 = isInterface_0(rootClass) ? PolymorphicSerializer.l1u(rootClass) : null;
    } else {
      tmp_7 = tmp4_elvis_lhs;
    }
    tmp_4 = tmp_7;
  }
  var contextualSerializer = tmp_4;
  var tmp_8;
  if (contextualSerializer == null) {
    tmp_8 = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp_8 = isInterface(contextualSerializer, KSerializer) ? contextualSerializer : THROW_CCE();
  }
  var tmp6_safe_receiver = tmp_8;
  return tmp6_safe_receiver == null ? null : nullable(tmp6_safe_receiver, isNullable);
}
function nullable(_this__u8e3s4, shouldBeNullable) {
  if (shouldBeNullable)
    return get_nullable(_this__u8e3s4);
  return isInterface(_this__u8e3s4, KSerializer) ? _this__u8e3s4 : THROW_CCE();
}
function serializer_0(type) {
  return serializer(EmptySerializersModule_0(), type);
}
function serializerByKTypeImpl$lambda($typeArguments) {
  return () => $typeArguments.f1(0).wf();
}
function get_SERIALIZERS_CACHE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return SERIALIZERS_CACHE;
}
var SERIALIZERS_CACHE;
function get_SERIALIZERS_CACHE_NULLABLE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return SERIALIZERS_CACHE_NULLABLE;
}
var SERIALIZERS_CACHE_NULLABLE;
function get_PARAMETRIZED_SERIALIZERS_CACHE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return PARAMETRIZED_SERIALIZERS_CACHE;
}
var PARAMETRIZED_SERIALIZERS_CACHE;
function get_PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE() {
  _init_properties_SerializersCache_kt__hgwi2p();
  return PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE;
}
var PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE;
function findCachedSerializer(clazz, isNullable) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp;
  if (!isNullable) {
    var tmp0_safe_receiver = get_SERIALIZERS_CACHE().d1w(clazz);
    var tmp_0;
    if (tmp0_safe_receiver == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlinx.serialization.internal.cast' call
      tmp_0 = isInterface(tmp0_safe_receiver, KSerializer) ? tmp0_safe_receiver : THROW_CCE();
    }
    tmp = tmp_0;
  } else {
    tmp = get_SERIALIZERS_CACHE_NULLABLE().d1w(clazz);
  }
  return tmp;
}
function findParametrizedCachedSerializer(clazz, types, isNullable) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp;
  if (!isNullable) {
    var tmp_0 = get_PARAMETRIZED_SERIALIZERS_CACHE().e1w(clazz, types);
    tmp = new Result(tmp_0) instanceof Result ? tmp_0 : THROW_CCE();
  } else {
    tmp = get_PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE().e1w(clazz, types);
  }
  return tmp;
}
function SERIALIZERS_CACHE$lambda(it) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp0_elvis_lhs = serializerOrNull(it);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlinx.serialization.polymorphicIfInterface' call
    tmp = isInterface_0(it) ? PolymorphicSerializer.l1u(it) : null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function SERIALIZERS_CACHE_NULLABLE$lambda(it) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var tmp0_elvis_lhs = serializerOrNull(it);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlinx.serialization.polymorphicIfInterface' call
    tmp = isInterface_0(it) ? PolymorphicSerializer.l1u(it) : null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var tmp1_safe_receiver = tmp;
  var tmp2_safe_receiver = tmp1_safe_receiver == null ? null : get_nullable(tmp1_safe_receiver);
  var tmp_0;
  if (tmp2_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp_0 = isInterface(tmp2_safe_receiver, KSerializer) ? tmp2_safe_receiver : THROW_CCE();
  }
  return tmp_0;
}
function PARAMETRIZED_SERIALIZERS_CACHE$lambda(clazz, types) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var serializers = ensureNotNull(serializersForParameters(EmptySerializersModule_0(), types, true));
  return parametrizedSerializerOrNull(clazz, serializers, PARAMETRIZED_SERIALIZERS_CACHE$lambda$lambda(types));
}
function PARAMETRIZED_SERIALIZERS_CACHE$lambda$lambda($types) {
  return () => $types.f1(0).wf();
}
function PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda(clazz, types) {
  _init_properties_SerializersCache_kt__hgwi2p();
  var serializers = ensureNotNull(serializersForParameters(EmptySerializersModule_0(), types, true));
  var tmp0_safe_receiver = parametrizedSerializerOrNull(clazz, serializers, PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda$lambda(types));
  var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : get_nullable(tmp0_safe_receiver);
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlinx.serialization.internal.cast' call
    tmp = isInterface(tmp1_safe_receiver, KSerializer) ? tmp1_safe_receiver : THROW_CCE();
  }
  return tmp;
}
function PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda$lambda($types) {
  return () => $types.f1(0).wf();
}
var properties_initialized_SerializersCache_kt_q8kf25;
function _init_properties_SerializersCache_kt__hgwi2p() {
  if (!properties_initialized_SerializersCache_kt_q8kf25) {
    properties_initialized_SerializersCache_kt_q8kf25 = true;
    SERIALIZERS_CACHE = createCache(SERIALIZERS_CACHE$lambda);
    SERIALIZERS_CACHE_NULLABLE = createCache(SERIALIZERS_CACHE_NULLABLE$lambda);
    PARAMETRIZED_SERIALIZERS_CACHE = createParametrizedCache(PARAMETRIZED_SERIALIZERS_CACHE$lambda);
    PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE = createParametrizedCache(PARAMETRIZED_SERIALIZERS_CACHE_NULLABLE$lambda);
  }
}
function get_nullable(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4.w1t().f1w()) {
    tmp = isInterface(_this__u8e3s4, KSerializer) ? _this__u8e3s4 : THROW_CCE();
  } else {
    tmp = new NullableSerializer(_this__u8e3s4);
  }
  return tmp;
}
function serializer_1(_this__u8e3s4) {
  return StringSerializer_getInstance();
}
function serializer_2(_this__u8e3s4) {
  return CharSerializer_getInstance();
}
function CharArraySerializer_0() {
  return CharArraySerializer_getInstance();
}
function serializer_3(_this__u8e3s4) {
  return DoubleSerializer_getInstance();
}
function DoubleArraySerializer_0() {
  return DoubleArraySerializer_getInstance();
}
function serializer_4(_this__u8e3s4) {
  return FloatSerializer_getInstance();
}
function FloatArraySerializer_0() {
  return FloatArraySerializer_getInstance();
}
function serializer_5(_this__u8e3s4) {
  return LongSerializer_getInstance();
}
function LongArraySerializer_0() {
  return LongArraySerializer_getInstance();
}
function serializer_6(_this__u8e3s4) {
  return ULongSerializer_getInstance();
}
function ULongArraySerializer_0() {
  return ULongArraySerializer_getInstance();
}
function serializer_7(_this__u8e3s4) {
  return IntSerializer_getInstance();
}
function IntArraySerializer_0() {
  return IntArraySerializer_getInstance();
}
function serializer_8(_this__u8e3s4) {
  return UIntSerializer_getInstance();
}
function UIntArraySerializer_0() {
  return UIntArraySerializer_getInstance();
}
function serializer_9(_this__u8e3s4) {
  return ShortSerializer_getInstance();
}
function ShortArraySerializer_0() {
  return ShortArraySerializer_getInstance();
}
function serializer_10(_this__u8e3s4) {
  return UShortSerializer_getInstance();
}
function UShortArraySerializer_0() {
  return UShortArraySerializer_getInstance();
}
function serializer_11(_this__u8e3s4) {
  return ByteSerializer_getInstance();
}
function ByteArraySerializer_0() {
  return ByteArraySerializer_getInstance();
}
function serializer_12(_this__u8e3s4) {
  return UByteSerializer_getInstance();
}
function UByteArraySerializer_0() {
  return UByteArraySerializer_getInstance();
}
function serializer_13(_this__u8e3s4) {
  return BooleanSerializer_getInstance();
}
function BooleanArraySerializer_0() {
  return BooleanArraySerializer_getInstance();
}
function serializer_14(_this__u8e3s4) {
  return UnitSerializer_getInstance();
}
function NothingSerializer_0() {
  return NothingSerializer_getInstance();
}
function serializer_15(_this__u8e3s4) {
  return DurationSerializer_getInstance();
}
function serializer_16(_this__u8e3s4) {
  return UuidSerializer_getInstance();
}
function MapEntrySerializer_0(keySerializer, valueSerializer) {
  return new MapEntrySerializer(keySerializer, valueSerializer);
}
function PairSerializer_0(keySerializer, valueSerializer) {
  return new PairSerializer(keySerializer, valueSerializer);
}
function TripleSerializer_0(aSerializer, bSerializer, cSerializer) {
  return new TripleSerializer(aSerializer, bSerializer, cSerializer);
}
function ArraySerializer(kClass, elementSerializer) {
  return new ReferenceArraySerializer(kClass, elementSerializer);
}
function MapSerializer(keySerializer, valueSerializer) {
  return new LinkedHashMapSerializer(keySerializer, valueSerializer);
}
function ListSerializer(elementSerializer) {
  return new ArrayListSerializer(elementSerializer);
}
function withContext(_this__u8e3s4, context) {
  return new ContextDescriptor(_this__u8e3s4, context);
}
function getContextualDescriptor(_this__u8e3s4, descriptor) {
  var tmp0_safe_receiver = get_capturedKClass(descriptor);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_safe_receiver_0 = _this__u8e3s4.b1w(tmp0_safe_receiver);
    tmp = tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.w1t();
  }
  return tmp;
}
function get_capturedKClass(_this__u8e3s4) {
  var tmp;
  if (_this__u8e3s4 instanceof ContextDescriptor) {
    tmp = _this__u8e3s4.h1w_1;
  } else {
    if (_this__u8e3s4 instanceof SerialDescriptorForNullable) {
      tmp = get_capturedKClass(_this__u8e3s4.s1w_1);
    } else {
      tmp = null;
    }
  }
  return tmp;
}
function get_elementDescriptors(_this__u8e3s4) {
  // Inline function 'kotlin.collections.Iterable' call
  return new elementDescriptors$$inlined$Iterable$1(_this__u8e3s4);
}
function get_elementNames(_this__u8e3s4) {
  // Inline function 'kotlin.collections.Iterable' call
  return new elementNames$$inlined$Iterable$1(_this__u8e3s4);
}
function buildSerialDescriptor(serialName, kind, typeParameters, builder) {
  var tmp;
  if (builder === VOID) {
    tmp = buildSerialDescriptor$lambda;
  } else {
    tmp = builder;
  }
  builder = tmp;
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.require' call
  if (!!isBlank(serialName)) {
    var message = 'Blank serial names are prohibited';
    throw IllegalArgumentException.t(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!!equals(kind, CLASS_getInstance())) {
    var message_0 = "For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead";
    throw IllegalArgumentException.t(toString(message_0));
  }
  var sdBuilder = new ClassSerialDescriptorBuilder(serialName);
  builder(sdBuilder);
  return new SerialDescriptorImpl(serialName, kind, sdBuilder.c1u_1.b1(), toList(typeParameters), sdBuilder);
}
function _get__hashCode__tgwhef($this) {
  var tmp0 = $this.n1x_1;
  // Inline function 'kotlin.getValue' call
  _hashCode$factory();
  return tmp0.n1();
}
function SerialDescriptorImpl$_hashCode$delegate$lambda(this$0) {
  return () => hashCodeImpl(this$0, this$0.m1x_1);
}
function buildClassSerialDescriptor(serialName, typeParameters, builderAction) {
  var tmp;
  if (builderAction === VOID) {
    tmp = buildClassSerialDescriptor$lambda;
  } else {
    tmp = builderAction;
  }
  builderAction = tmp;
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.require' call
  if (!!isBlank(serialName)) {
    var message = 'Blank serial names are prohibited';
    throw IllegalArgumentException.t(toString(message));
  }
  var sdBuilder = new ClassSerialDescriptorBuilder(serialName);
  builderAction(sdBuilder);
  return new SerialDescriptorImpl(serialName, CLASS_getInstance(), sdBuilder.c1u_1.b1(), toList(typeParameters), sdBuilder);
}
function PrimitiveSerialDescriptor_0(serialName, kind) {
  // Inline function 'kotlin.text.isNotBlank' call
  // Inline function 'kotlin.require' call
  if (!!isBlank(serialName)) {
    var message = 'Blank serial names are prohibited';
    throw IllegalArgumentException.t(toString(message));
  }
  return PrimitiveDescriptorSafe(serialName, kind);
}
function get_nullable_0(_this__u8e3s4) {
  if (_this__u8e3s4.f1w())
    return _this__u8e3s4;
  return new SerialDescriptorForNullable(_this__u8e3s4);
}
function buildSerialDescriptor$lambda(_this__u8e3s4) {
  return Unit_instance;
}
function buildClassSerialDescriptor$lambda(_this__u8e3s4) {
  return Unit_instance;
}
function _hashCode$factory() {
  return getPropertyCallableRef('_hashCode', 1, KProperty1, (receiver) => _get__hashCode__tgwhef(receiver), null);
}
var ENUM_instance;
function ENUM_getInstance() {
  if (ENUM_instance === VOID)
    new ENUM();
  return ENUM_instance;
}
var CONTEXTUAL_instance;
function CONTEXTUAL_getInstance() {
  if (CONTEXTUAL_instance === VOID)
    new CONTEXTUAL();
  return CONTEXTUAL_instance;
}
var SEALED_instance;
function SEALED_getInstance() {
  if (SEALED_instance === VOID)
    new SEALED();
  return SEALED_instance;
}
var OPEN_instance;
function OPEN_getInstance() {
  if (OPEN_instance === VOID)
    new OPEN();
  return OPEN_instance;
}
var BOOLEAN_instance;
function BOOLEAN_getInstance() {
  if (BOOLEAN_instance === VOID)
    new BOOLEAN();
  return BOOLEAN_instance;
}
var BYTE_instance;
function BYTE_getInstance() {
  if (BYTE_instance === VOID)
    new BYTE();
  return BYTE_instance;
}
var CHAR_instance;
function CHAR_getInstance() {
  if (CHAR_instance === VOID)
    new CHAR();
  return CHAR_instance;
}
var SHORT_instance;
function SHORT_getInstance() {
  if (SHORT_instance === VOID)
    new SHORT();
  return SHORT_instance;
}
var INT_instance;
function INT_getInstance() {
  if (INT_instance === VOID)
    new INT();
  return INT_instance;
}
var LONG_instance;
function LONG_getInstance() {
  if (LONG_instance === VOID)
    new LONG();
  return LONG_instance;
}
var FLOAT_instance;
function FLOAT_getInstance() {
  if (FLOAT_instance === VOID)
    new FLOAT();
  return FLOAT_instance;
}
var DOUBLE_instance;
function DOUBLE_getInstance() {
  if (DOUBLE_instance === VOID)
    new DOUBLE();
  return DOUBLE_instance;
}
var STRING_instance;
function STRING_getInstance() {
  if (STRING_instance === VOID)
    new STRING();
  return STRING_instance;
}
var CLASS_instance;
function CLASS_getInstance() {
  if (CLASS_instance === VOID)
    new CLASS();
  return CLASS_instance;
}
var LIST_instance;
function LIST_getInstance() {
  if (LIST_instance === VOID)
    new LIST();
  return LIST_instance;
}
var MAP_instance;
function MAP_getInstance() {
  if (MAP_instance === VOID)
    new MAP();
  return MAP_instance;
}
var OBJECT_instance;
function OBJECT_getInstance() {
  if (OBJECT_instance === VOID)
    new OBJECT();
  return OBJECT_instance;
}
function decodeSequentially_0($this, compositeDecoder) {
  var klassName = compositeDecoder.p1y($this.w1t(), 0);
  var serializer = findPolymorphicSerializer_0($this, compositeDecoder, klassName);
  return compositeDecoder.s1y($this.w1t(), 1, serializer);
}
function throwSubtypeNotRegistered(subClass, baseClass) {
  var tmp0_elvis_lhs = subClass.hf();
  throwSubtypeNotRegistered_0(tmp0_elvis_lhs == null ? toString(subClass) : tmp0_elvis_lhs, baseClass);
}
function throwSubtypeNotRegistered_0(subClassName, baseClass) {
  var scope = "in the polymorphic scope of '" + baseClass.hf() + "'";
  throw SerializationException.i1v(subClassName == null ? 'Class discriminator was missing and no default serializers were registered ' + scope + '.' : "Serializer for subclass '" + subClassName + "' is not found " + scope + '.\n' + ("Check if class with serial name '" + subClassName + "' exists and serializer is registered in a corresponding SerializersModule.\n") + ("To be registered automatically, class '" + subClassName + "' has to be '@Serializable', and the base class '" + baseClass.hf() + "' has to be sealed and '@Serializable'."));
}
var NothingSerializer_instance;
function NothingSerializer_getInstance() {
  if (NothingSerializer_instance === VOID)
    new NothingSerializer();
  return NothingSerializer_instance;
}
var DurationSerializer_instance;
function DurationSerializer_getInstance() {
  if (DurationSerializer_instance === VOID)
    new DurationSerializer();
  return DurationSerializer_instance;
}
var UuidSerializer_instance;
function UuidSerializer_getInstance() {
  if (UuidSerializer_instance === VOID)
    new UuidSerializer();
  return UuidSerializer_instance;
}
function readSize($this, decoder, builder) {
  var size = decoder.x1y($this.w1t());
  $this.o21(builder, size);
  return size;
}
var Companion_instance_0;
function Companion_getInstance_7() {
  if (Companion_instance_0 === VOID)
    new Companion();
  return Companion_instance_0;
}
function prepareHighMarksArray($this, elementsCount) {
  var slotsCount = (elementsCount - 1 | 0) >>> 6 | 0;
  var elementsInLastSlot = elementsCount & 63;
  var highMarks = longArray(slotsCount);
  if (!(elementsInLastSlot === 0)) {
    highMarks[get_lastIndex(highMarks)] = (new Long(-1, -1)).e4(elementsCount);
  }
  return highMarks;
}
function markHigh($this, index) {
  var slot = (index >>> 6 | 0) - 1 | 0;
  var offsetInSlot = index & 63;
  $this.l24_1[slot] = $this.l24_1[slot].i4((new Long(1, 0)).e4(offsetInSlot));
}
function nextUnmarkedHighIndex($this) {
  var inductionVariable = 0;
  var last = $this.l24_1.length - 1 | 0;
  if (inductionVariable <= last)
    do {
      var slot = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var slotOffset = imul(slot + 1 | 0, 64);
      var slotMarks = $this.l24_1[slot];
      while (!slotMarks.equals(new Long(-1, -1))) {
        var indexInSlot = countTrailingZeroBits(slotMarks.c4());
        slotMarks = slotMarks.i4((new Long(1, 0)).e4(indexInSlot));
        var index = slotOffset + indexInSlot | 0;
        if ($this.j24_1($this.i24_1, index)) {
          $this.l24_1[slot] = slotMarks;
          return index;
        }
      }
      $this.l24_1[slot] = slotMarks;
    }
     while (inductionVariable <= last);
  return -1;
}
function createSimpleEnumSerializer(serialName, values) {
  return new EnumSerializer(serialName, values);
}
function createUnmarkedDescriptor($this, serialName) {
  var d = new EnumDescriptor(serialName, $this.o24_1.length);
  // Inline function 'kotlin.collections.forEach' call
  var indexedObject = $this.o24_1;
  var inductionVariable = 0;
  var last = indexedObject.length;
  while (inductionVariable < last) {
    var element = indexedObject[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    d.d25(element.n3_1);
  }
  return d;
}
function EnumSerializer$descriptor$delegate$lambda(this$0, $serialName) {
  return () => {
    var tmp0_elvis_lhs = this$0.p24_1;
    return tmp0_elvis_lhs == null ? createUnmarkedDescriptor(this$0, $serialName) : tmp0_elvis_lhs;
  };
}
function _get_elementDescriptors__y23q9p($this) {
  var tmp0 = $this.s25_1;
  // Inline function 'kotlin.getValue' call
  elementDescriptors$factory();
  return tmp0.n1();
}
function EnumDescriptor$elementDescriptors$delegate$lambda($elementsCount, $name, this$0) {
  return () => {
    var tmp = 0;
    var tmp_0 = $elementsCount;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      tmp_1[tmp_2] = buildSerialDescriptor($name + '.' + this$0.n1w(tmp_2), OBJECT_getInstance(), []);
      tmp = tmp + 1 | 0;
    }
    return tmp_1;
  };
}
function descriptor$factory_1() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.w1t(), null);
}
function elementDescriptors$factory() {
  return getPropertyCallableRef('elementDescriptors', 1, KProperty1, (receiver) => _get_elementDescriptors__y23q9p(receiver), null);
}
function InlinePrimitiveDescriptor(name, primitiveSerializer) {
  return new InlineClassDescriptor(name, new InlinePrimitiveDescriptor$1(primitiveSerializer));
}
function jsonCachedSerialNames(_this__u8e3s4) {
  return cachedSerialNames(_this__u8e3s4);
}
var NoOpEncoder_instance;
function NoOpEncoder_getInstance() {
  if (NoOpEncoder_instance === VOID)
    NoOpEncoder.m26();
  return NoOpEncoder_instance;
}
function error($this) {
  throw IllegalStateException.t4('Descriptor for type `kotlin.Nothing` does not have elements');
}
var NothingSerialDescriptor_instance;
function NothingSerialDescriptor_getInstance() {
  if (NothingSerialDescriptor_instance === VOID)
    new NothingSerialDescriptor();
  return NothingSerialDescriptor_instance;
}
function ObjectSerializer$descriptor$delegate$lambda$lambda(this$0) {
  return ($this$buildSerialDescriptor) => {
    $this$buildSerialDescriptor.b1u_1 = this$0.t26_1;
    return Unit_instance;
  };
}
function ObjectSerializer$descriptor$delegate$lambda($serialName, this$0) {
  return () => {
    var tmp = OBJECT_getInstance();
    return buildSerialDescriptor($serialName, tmp, [], ObjectSerializer$descriptor$delegate$lambda$lambda(this$0));
  };
}
function descriptor$factory_2() {
  return getPropertyCallableRef('descriptor', 1, KProperty1, (receiver) => receiver.w1t(), null);
}
function get_EMPTY_DESCRIPTOR_ARRAY() {
  _init_properties_Platform_common_kt__3qzecs();
  return EMPTY_DESCRIPTOR_ARRAY;
}
var EMPTY_DESCRIPTOR_ARRAY;
function cachedSerialNames(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  if (isInterface(_this__u8e3s4, CachedNames))
    return _this__u8e3s4.o1x();
  var result = HashSet.e1(_this__u8e3s4.l1w());
  var inductionVariable = 0;
  var last = _this__u8e3s4.l1w();
  if (inductionVariable < last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = _this__u8e3s4.n1w(i);
      result.l(element);
    }
     while (inductionVariable < last);
  return result;
}
function kclass(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  var t = _this__u8e3s4.wf();
  var tmp;
  if (!(t == null) ? isInterface(t, KClass) : false) {
    tmp = t;
  } else {
    if (!(t == null) ? isInterface(t, KTypeParameter) : false) {
      throw IllegalArgumentException.t('Captured type parameter ' + toString(t) + ' from generic non-reified function. ' + ('Such functionality cannot be supported because ' + toString(t) + ' is erased, either specify serializer explicitly or make ') + ('calling function inline with reified ' + toString(t) + '.'));
    } else {
      throw IllegalArgumentException.t('Only KClass supported as classifier, got ' + toString_0(t));
    }
  }
  var tmp_0 = tmp;
  return isInterface(tmp_0, KClass) ? tmp_0 : THROW_CCE();
}
function typeOrThrow(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  var tmp0 = _this__u8e3s4.kp_1;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.requireNotNull' call
    if (tmp0 == null) {
      var message = 'Star projections in type arguments are not allowed, but had ' + toString_0(_this__u8e3s4.kp_1);
      throw IllegalArgumentException.t(toString(message));
    } else {
      tmp$ret$1 = tmp0;
      break $l$block;
    }
  }
  return tmp$ret$1;
}
function notRegisteredMessage(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  var tmp0_elvis_lhs = _this__u8e3s4.hf();
  return notRegisteredMessage_0(tmp0_elvis_lhs == null ? '<local class name not available>' : tmp0_elvis_lhs);
}
function compactArray(_this__u8e3s4) {
  _init_properties_Platform_common_kt__3qzecs();
  // Inline function 'kotlin.takeUnless' call
  var tmp;
  // Inline function 'kotlin.collections.isNullOrEmpty' call
  if (!(_this__u8e3s4 == null || _this__u8e3s4.h1())) {
    tmp = _this__u8e3s4;
  } else {
    tmp = null;
  }
  var tmp0_safe_receiver = tmp;
  var tmp_0;
  if (tmp0_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.collections.toTypedArray' call
    tmp_0 = copyToArray(tmp0_safe_receiver);
  }
  var tmp1_elvis_lhs = tmp_0;
  return tmp1_elvis_lhs == null ? get_EMPTY_DESCRIPTOR_ARRAY() : tmp1_elvis_lhs;
}
function notRegisteredMessage_0(className) {
  _init_properties_Platform_common_kt__3qzecs();
  return "Serializer for class '" + className + "' is not found.\n" + "Please ensure that class is marked as '@Serializable' and that the serialization compiler plugin is applied.\n";
}
var properties_initialized_Platform_common_kt_i7q4ty;
function _init_properties_Platform_common_kt__3qzecs() {
  if (!properties_initialized_Platform_common_kt_i7q4ty) {
    properties_initialized_Platform_common_kt_i7q4ty = true;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    EMPTY_DESCRIPTOR_ARRAY = [];
  }
}
function throwMissingFieldException(seen, goldenMask, descriptor) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var missingFields = ArrayList.k();
  var missingFieldsBits = goldenMask & ~seen;
  var inductionVariable = 0;
  if (inductionVariable < 32)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      if (!((missingFieldsBits & 1) === 0)) {
        // Inline function 'kotlin.collections.plusAssign' call
        var element = descriptor.n1w(i);
        missingFields.l(element);
      }
      missingFieldsBits = missingFieldsBits >>> 1 | 0;
    }
     while (inductionVariable < 32);
  throw MissingFieldException.r1v(missingFields, descriptor.z1u());
}
function hashCodeImpl(_this__u8e3s4, typeParams) {
  var result = getStringHashCode(_this__u8e3s4.z1u());
  result = imul(31, result) + contentHashCode(typeParams) | 0;
  var elementDescriptors = get_elementDescriptors(_this__u8e3s4);
  // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy' call
  // Inline function 'kotlin.collections.fold' call
  var accumulator = 1;
  var _iterator__ex2g4s = elementDescriptors.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var hash = accumulator;
    var tmp = imul(31, hash);
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver = element.z1u();
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
    accumulator = tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
  }
  var namesHash = accumulator;
  // Inline function 'kotlinx.serialization.internal.elementsHashCodeBy' call
  // Inline function 'kotlin.collections.fold' call
  var accumulator_0 = 1;
  var _iterator__ex2g4s_0 = elementDescriptors.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    var hash_0 = accumulator_0;
    var tmp_0 = imul(31, hash_0);
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver_0 = element_0.j1w();
    var tmp1_elvis_lhs_0 = tmp0_safe_receiver_0 == null ? null : hashCode(tmp0_safe_receiver_0);
    accumulator_0 = tmp_0 + (tmp1_elvis_lhs_0 == null ? 0 : tmp1_elvis_lhs_0) | 0;
  }
  var kindHash = accumulator_0;
  result = imul(31, result) + namesHash | 0;
  result = imul(31, result) + kindHash | 0;
  return result;
}
function toStringImpl(_this__u8e3s4) {
  var tmp = until(0, _this__u8e3s4.l1w());
  var tmp_0 = _this__u8e3s4.z1u() + '(';
  return joinToString(tmp, ', ', tmp_0, ')', VOID, VOID, toStringImpl$lambda(_this__u8e3s4));
}
function _get_childSerializers__7vnyfa($this) {
  var tmp0 = $this.a25_1;
  // Inline function 'kotlin.getValue' call
  childSerializers$factory();
  return tmp0.n1();
}
function _get__hashCode__tgwhef_0($this) {
  var tmp0 = $this.c25_1;
  // Inline function 'kotlin.getValue' call
  _hashCode$factory_0();
  return tmp0.n1();
}
function buildIndices($this) {
  var indices = HashMap.l8();
  var inductionVariable = 0;
  var last = $this.v24_1.length - 1 | 0;
  if (inductionVariable <= last)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.collections.set' call
      var key = $this.v24_1[i];
      indices.k3(key, i);
    }
     while (inductionVariable <= last);
  return indices;
}
function PluginGeneratedSerialDescriptor$childSerializers$delegate$lambda(this$0) {
  return () => {
    var tmp0_safe_receiver = this$0.s24_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j26();
    return tmp1_elvis_lhs == null ? get_EMPTY_SERIALIZER_ARRAY() : tmp1_elvis_lhs;
  };
}
function PluginGeneratedSerialDescriptor$typeParameterDescriptors$delegate$lambda(this$0) {
  return () => {
    var tmp0_safe_receiver = this$0.s24_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.k26();
    var tmp;
    if (tmp1_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(tmp1_safe_receiver.length);
      var inductionVariable = 0;
      var last = tmp1_safe_receiver.length;
      while (inductionVariable < last) {
        var item = tmp1_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        var tmp$ret$0 = item.w1t();
        destination.l(tmp$ret$0);
      }
      tmp = destination;
    }
    return compactArray(tmp);
  };
}
function PluginGeneratedSerialDescriptor$_hashCode$delegate$lambda(this$0) {
  return () => hashCodeImpl(this$0, this$0.t25());
}
function toStringImpl$lambda($this_toStringImpl) {
  return (i) => $this_toStringImpl.n1w(i) + ': ' + $this_toStringImpl.q1w(i).z1u();
}
function childSerializers$factory() {
  return getPropertyCallableRef('childSerializers', 1, KProperty1, (receiver) => _get_childSerializers__7vnyfa(receiver), null);
}
function typeParameterDescriptors$factory() {
  return getPropertyCallableRef('typeParameterDescriptors', 1, KProperty1, (receiver) => receiver.t25(), null);
}
function _hashCode$factory_0() {
  return getPropertyCallableRef('_hashCode', 1, KProperty1, (receiver) => _get__hashCode__tgwhef_0(receiver), null);
}
function get_EMPTY_SERIALIZER_ARRAY() {
  _init_properties_PluginHelperInterfaces_kt__xgvzfp();
  return EMPTY_SERIALIZER_ARRAY;
}
var EMPTY_SERIALIZER_ARRAY;
var properties_initialized_PluginHelperInterfaces_kt_ap8in1;
function _init_properties_PluginHelperInterfaces_kt__xgvzfp() {
  if (!properties_initialized_PluginHelperInterfaces_kt_ap8in1) {
    properties_initialized_PluginHelperInterfaces_kt_ap8in1 = true;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    EMPTY_SERIALIZER_ARRAY = [];
  }
}
var CharArraySerializer_instance;
function CharArraySerializer_getInstance() {
  if (CharArraySerializer_instance === VOID)
    new CharArraySerializer();
  return CharArraySerializer_instance;
}
var DoubleArraySerializer_instance;
function DoubleArraySerializer_getInstance() {
  if (DoubleArraySerializer_instance === VOID)
    new DoubleArraySerializer();
  return DoubleArraySerializer_instance;
}
var FloatArraySerializer_instance;
function FloatArraySerializer_getInstance() {
  if (FloatArraySerializer_instance === VOID)
    new FloatArraySerializer();
  return FloatArraySerializer_instance;
}
var LongArraySerializer_instance;
function LongArraySerializer_getInstance() {
  if (LongArraySerializer_instance === VOID)
    new LongArraySerializer();
  return LongArraySerializer_instance;
}
var ULongArraySerializer_instance;
function ULongArraySerializer_getInstance() {
  if (ULongArraySerializer_instance === VOID)
    new ULongArraySerializer();
  return ULongArraySerializer_instance;
}
var IntArraySerializer_instance;
function IntArraySerializer_getInstance() {
  if (IntArraySerializer_instance === VOID)
    new IntArraySerializer();
  return IntArraySerializer_instance;
}
var UIntArraySerializer_instance;
function UIntArraySerializer_getInstance() {
  if (UIntArraySerializer_instance === VOID)
    new UIntArraySerializer();
  return UIntArraySerializer_instance;
}
var ShortArraySerializer_instance;
function ShortArraySerializer_getInstance() {
  if (ShortArraySerializer_instance === VOID)
    new ShortArraySerializer();
  return ShortArraySerializer_instance;
}
var UShortArraySerializer_instance;
function UShortArraySerializer_getInstance() {
  if (UShortArraySerializer_instance === VOID)
    new UShortArraySerializer();
  return UShortArraySerializer_instance;
}
var ByteArraySerializer_instance;
function ByteArraySerializer_getInstance() {
  if (ByteArraySerializer_instance === VOID)
    new ByteArraySerializer();
  return ByteArraySerializer_instance;
}
var UByteArraySerializer_instance;
function UByteArraySerializer_getInstance() {
  if (UByteArraySerializer_instance === VOID)
    new UByteArraySerializer();
  return UByteArraySerializer_instance;
}
var BooleanArraySerializer_instance;
function BooleanArraySerializer_getInstance() {
  if (BooleanArraySerializer_instance === VOID)
    new BooleanArraySerializer();
  return BooleanArraySerializer_instance;
}
function get_BUILTIN_SERIALIZERS() {
  _init_properties_Primitives_kt__k0eto4();
  return BUILTIN_SERIALIZERS;
}
var BUILTIN_SERIALIZERS;
function builtinSerializerOrNull(_this__u8e3s4) {
  _init_properties_Primitives_kt__k0eto4();
  var tmp = get_BUILTIN_SERIALIZERS().h3(_this__u8e3s4);
  return (tmp == null ? true : isInterface(tmp, KSerializer)) ? tmp : THROW_CCE();
}
var StringSerializer_instance;
function StringSerializer_getInstance() {
  if (StringSerializer_instance === VOID)
    new StringSerializer();
  return StringSerializer_instance;
}
var CharSerializer_instance;
function CharSerializer_getInstance() {
  if (CharSerializer_instance === VOID)
    new CharSerializer();
  return CharSerializer_instance;
}
var DoubleSerializer_instance;
function DoubleSerializer_getInstance() {
  if (DoubleSerializer_instance === VOID)
    new DoubleSerializer();
  return DoubleSerializer_instance;
}
var FloatSerializer_instance;
function FloatSerializer_getInstance() {
  if (FloatSerializer_instance === VOID)
    new FloatSerializer();
  return FloatSerializer_instance;
}
var LongSerializer_instance;
function LongSerializer_getInstance() {
  if (LongSerializer_instance === VOID)
    new LongSerializer();
  return LongSerializer_instance;
}
var IntSerializer_instance;
function IntSerializer_getInstance() {
  if (IntSerializer_instance === VOID)
    new IntSerializer();
  return IntSerializer_instance;
}
var ShortSerializer_instance;
function ShortSerializer_getInstance() {
  if (ShortSerializer_instance === VOID)
    new ShortSerializer();
  return ShortSerializer_instance;
}
var ByteSerializer_instance;
function ByteSerializer_getInstance() {
  if (ByteSerializer_instance === VOID)
    new ByteSerializer();
  return ByteSerializer_instance;
}
var BooleanSerializer_instance;
function BooleanSerializer_getInstance() {
  if (BooleanSerializer_instance === VOID)
    new BooleanSerializer();
  return BooleanSerializer_instance;
}
var UnitSerializer_instance;
function UnitSerializer_getInstance() {
  if (UnitSerializer_instance === VOID)
    new UnitSerializer();
  return UnitSerializer_instance;
}
function error_0($this) {
  throw IllegalStateException.t4('Primitive descriptor ' + $this.e2c_1 + ' does not have elements');
}
function PrimitiveDescriptorSafe(serialName, kind) {
  _init_properties_Primitives_kt__k0eto4();
  checkNameIsNotAPrimitive(serialName);
  return new PrimitiveSerialDescriptor(serialName, kind);
}
function checkNameIsNotAPrimitive(serialName) {
  _init_properties_Primitives_kt__k0eto4();
  var values = get_BUILTIN_SERIALIZERS().j3();
  var _iterator__ex2g4s = values.y();
  while (_iterator__ex2g4s.z()) {
    var primitive = _iterator__ex2g4s.a1();
    var primitiveName = primitive.w1t().z1u();
    if (serialName === primitiveName) {
      throw IllegalArgumentException.t(trimIndent('\n                The name of serial descriptor should uniquely identify associated serializer.\n                For serial name ' + serialName + ' there already exists ' + getKClassFromExpression(primitive).hf() + '.\n                Please refer to SerialDescriptor documentation for additional information.\n            '));
    }
  }
}
var properties_initialized_Primitives_kt_6dpii6;
function _init_properties_Primitives_kt__k0eto4() {
  if (!properties_initialized_Primitives_kt_6dpii6) {
    properties_initialized_Primitives_kt_6dpii6 = true;
    BUILTIN_SERIALIZERS = initBuiltins();
  }
}
function encodeElement($this, desc, index) {
  var tag = $this.h2c(desc, index);
  $this.d2d(tag);
  return true;
}
function tagBlock($this, tag, block) {
  $this.d2d(tag);
  var r = block();
  if (!$this.i2d_1) {
    $this.e2d();
  }
  $this.i2d_1 = false;
  return r;
}
function TaggedDecoder$decodeSerializableElement$lambda(this$0, $deserializer, $previousValue) {
  return () => this$0.d1y($deserializer, $previousValue);
}
function TaggedDecoder$decodeNullableSerializableElement$lambda(this$0, $deserializer, $previousValue) {
  return () => {
    var tmp0 = this$0;
    // Inline function 'kotlinx.serialization.encoding.decodeIfNullable' call
    var isNullabilitySupported = $deserializer.w1t().f1w();
    var tmp;
    if (isNullabilitySupported || tmp0.q1x()) {
      tmp = this$0.d1y($deserializer, $previousValue);
    } else {
      tmp = tmp0.r1x();
    }
    return tmp;
  };
}
function get_NULL() {
  _init_properties_Tuples_kt__dz0qyd();
  return NULL;
}
var NULL;
function MapEntrySerializer$descriptor$lambda($keySerializer, $valueSerializer) {
  return ($this$buildSerialDescriptor) => {
    $this$buildSerialDescriptor.h1u('key', $keySerializer.w1t());
    $this$buildSerialDescriptor.h1u('value', $valueSerializer.w1t());
    return Unit_instance;
  };
}
function PairSerializer$descriptor$lambda($keySerializer, $valueSerializer) {
  return ($this$buildClassSerialDescriptor) => {
    $this$buildClassSerialDescriptor.h1u('first', $keySerializer.w1t());
    $this$buildClassSerialDescriptor.h1u('second', $valueSerializer.w1t());
    return Unit_instance;
  };
}
function decodeSequentially_1($this, composite) {
  var a = composite.s1y($this.s2e_1, 0, $this.p2e_1);
  var b = composite.s1y($this.s2e_1, 1, $this.q2e_1);
  var c = composite.s1y($this.s2e_1, 2, $this.r2e_1);
  composite.g1y($this.s2e_1);
  return new Triple(a, b, c);
}
function decodeStructure($this, composite) {
  var a = get_NULL();
  var b = get_NULL();
  var c = get_NULL();
  mainLoop: while (true) {
    var index = composite.w1y($this.s2e_1);
    switch (index) {
      case -1:
        break mainLoop;
      case 0:
        a = composite.s1y($this.s2e_1, 0, $this.p2e_1);
        break;
      case 1:
        b = composite.s1y($this.s2e_1, 1, $this.q2e_1);
        break;
      case 2:
        c = composite.s1y($this.s2e_1, 2, $this.r2e_1);
        break;
      default:
        throw SerializationException.i1v('Unexpected index ' + index);
    }
  }
  composite.g1y($this.s2e_1);
  if (a === get_NULL())
    throw SerializationException.i1v("Element 'first' is missing");
  if (b === get_NULL())
    throw SerializationException.i1v("Element 'second' is missing");
  if (c === get_NULL())
    throw SerializationException.i1v("Element 'third' is missing");
  var tmp = (a == null ? true : !(a == null)) ? a : THROW_CCE();
  var tmp_0 = (b == null ? true : !(b == null)) ? b : THROW_CCE();
  return new Triple(tmp, tmp_0, (c == null ? true : !(c == null)) ? c : THROW_CCE());
}
function TripleSerializer$descriptor$lambda(this$0) {
  return ($this$buildClassSerialDescriptor) => {
    $this$buildClassSerialDescriptor.h1u('first', this$0.p2e_1.w1t());
    $this$buildClassSerialDescriptor.h1u('second', this$0.q2e_1.w1t());
    $this$buildClassSerialDescriptor.h1u('third', this$0.r2e_1.w1t());
    return Unit_instance;
  };
}
var properties_initialized_Tuples_kt_3vs7ar;
function _init_properties_Tuples_kt__dz0qyd() {
  if (!properties_initialized_Tuples_kt_3vs7ar) {
    properties_initialized_Tuples_kt_3vs7ar = true;
    NULL = new Object();
  }
}
var ULongSerializer_instance;
function ULongSerializer_getInstance() {
  if (ULongSerializer_instance === VOID)
    new ULongSerializer();
  return ULongSerializer_instance;
}
var UIntSerializer_instance;
function UIntSerializer_getInstance() {
  if (UIntSerializer_instance === VOID)
    new UIntSerializer();
  return UIntSerializer_instance;
}
var UShortSerializer_instance;
function UShortSerializer_getInstance() {
  if (UShortSerializer_instance === VOID)
    new UShortSerializer();
  return UShortSerializer_instance;
}
var UByteSerializer_instance;
function UByteSerializer_getInstance() {
  if (UByteSerializer_instance === VOID)
    new UByteSerializer();
  return UByteSerializer_instance;
}
function get_EmptySerializersModuleLegacyJs() {
  _init_properties_SerializersModule_kt__u78ha3();
  return EmptySerializersModule;
}
var EmptySerializersModule;
var properties_initialized_SerializersModule_kt_fjigjn;
function _init_properties_SerializersModule_kt__u78ha3() {
  if (!properties_initialized_SerializersModule_kt_fjigjn) {
    properties_initialized_SerializersModule_kt_fjigjn = true;
    EmptySerializersModule = new SerialModuleImpl(emptyMap(), emptyMap(), emptyMap(), emptyMap(), emptyMap(), false);
  }
}
function EmptySerializersModule_0() {
  return get_EmptySerializersModuleLegacyJs();
}
function SerializersModuleCollector$contextual$lambda($serializer) {
  return (it) => $serializer;
}
function createCache(factory) {
  return new createCache$1(factory);
}
function createParametrizedCache(factory) {
  return new createParametrizedCache$1(factory);
}
function isInterface_0(_this__u8e3s4) {
  return get_isInterface(_this__u8e3s4);
}
function initBuiltins() {
  return mapOf([to(PrimitiveClasses_getInstance().ng(), serializer_1(StringCompanionObject_instance)), to(getKClass(Char), serializer_2(Companion_getInstance_1())), to(PrimitiveClasses_getInstance().qg(), CharArraySerializer_0()), to(PrimitiveClasses_getInstance().lg(), serializer_3(DoubleCompanionObject_instance)), to(PrimitiveClasses_getInstance().wg(), DoubleArraySerializer_0()), to(PrimitiveClasses_getInstance().kg(), serializer_4(FloatCompanionObject_instance)), to(PrimitiveClasses_getInstance().vg(), FloatArraySerializer_0()), to(getKClass(Long), serializer_5(Companion_getInstance_2())), to(PrimitiveClasses_getInstance().ug(), LongArraySerializer_0()), to(getKClass(ULong), serializer_6(Companion_getInstance_3())), to(getKClass(ULongArray), ULongArraySerializer_0()), to(PrimitiveClasses_getInstance().jg(), serializer_7(IntCompanionObject_instance)), to(PrimitiveClasses_getInstance().tg(), IntArraySerializer_0()), to(getKClass(UInt), serializer_8(Companion_getInstance_4())), to(getKClass(UIntArray), UIntArraySerializer_0()), to(PrimitiveClasses_getInstance().ig(), serializer_9(ShortCompanionObject_instance)), to(PrimitiveClasses_getInstance().sg(), ShortArraySerializer_0()), to(getKClass(UShort), serializer_10(Companion_getInstance_5())), to(getKClass(UShortArray), UShortArraySerializer_0()), to(PrimitiveClasses_getInstance().hg(), serializer_11(ByteCompanionObject_instance)), to(PrimitiveClasses_getInstance().rg(), ByteArraySerializer_0()), to(getKClass(UByte), serializer_12(Companion_getInstance_6())), to(getKClass(UByteArray), UByteArraySerializer_0()), to(PrimitiveClasses_getInstance().gg(), serializer_13(BooleanCompanionObject_instance)), to(PrimitiveClasses_getInstance().pg(), BooleanArraySerializer_0()), to(getKClass(Unit), serializer_14(Unit_instance)), to(PrimitiveClasses_getInstance().fg(), NothingSerializer_0()), to(getKClass(Duration), serializer_15(Companion_getInstance())), to(getKClass(Uuid), serializer_16(Companion_getInstance_0()))]);
}
function get_isInterface(_this__u8e3s4) {
  if (_this__u8e3s4 === PrimitiveClasses_getInstance().fg())
    return false;
  // Inline function 'kotlin.js.asDynamic' call
  var tmp0_safe_receiver = get_js(_this__u8e3s4).$metadata$;
  return (tmp0_safe_receiver == null ? null : tmp0_safe_receiver.kind) == 'interface';
}
function compiledSerializerImpl(_this__u8e3s4) {
  var tmp0_elvis_lhs = constructSerializerForGivenTypeArgs(_this__u8e3s4, []);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var tmp_0;
    if (_this__u8e3s4 === PrimitiveClasses_getInstance().fg()) {
      tmp_0 = NothingSerializer_getInstance();
    } else {
      // Inline function 'kotlin.js.asDynamic' call
      var tmp1_safe_receiver = get_js(_this__u8e3s4).Companion;
      tmp_0 = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.serializer();
    }
    var tmp_1 = tmp_0;
    tmp = (!(tmp_1 == null) ? isInterface(tmp_1, KSerializer) : false) ? tmp_1 : null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function platformSpecificSerializerNotRegistered(_this__u8e3s4) {
  throw SerializationException.i1v(notRegisteredMessage(_this__u8e3s4) + 'To get enum serializer on Kotlin/JS, it should be annotated with @Serializable annotation.');
}
function isReferenceArray(rootClass) {
  return rootClass.equals(PrimitiveClasses_getInstance().mg());
}
function constructSerializerForGivenTypeArgs(_this__u8e3s4, args) {
  var tmp;
  try {
    // Inline function 'kotlin.reflect.findAssociatedObject' call
    var assocObject = findAssociatedObject(_this__u8e3s4, getKClass(SerializableWith));
    var tmp_0;
    if (!(assocObject == null) ? isInterface(assocObject, KSerializer) : false) {
      tmp_0 = isInterface(assocObject, KSerializer) ? assocObject : THROW_CCE();
    } else {
      if (!(assocObject == null) ? isInterface(assocObject, SerializerFactory) : false) {
        var tmp_1 = assocObject.v26(args.slice());
        tmp_0 = isInterface(tmp_1, KSerializer) ? tmp_1 : THROW_CCE();
      } else {
        tmp_0 = null;
      }
    }
    tmp = tmp_0;
  } catch ($p) {
    var tmp_2;
    var e = $p;
    tmp_2 = null;
    tmp = tmp_2;
  }
  return tmp;
}
function toNativeArrayImpl(_this__u8e3s4, eClass) {
  // Inline function 'kotlin.collections.toTypedArray' call
  return copyToArray(_this__u8e3s4);
}
function getChecked(_this__u8e3s4, index) {
  if (!(0 <= index ? index <= (_this__u8e3s4.length - 1 | 0) : false))
    throw IndexOutOfBoundsException.me('Index ' + index + ' out of bounds ' + get_indices(_this__u8e3s4).toString());
  return _this__u8e3s4[index];
}
function getChecked_0(_this__u8e3s4, index) {
  if (!(0 <= index ? index <= (_this__u8e3s4.length - 1 | 0) : false))
    throw IndexOutOfBoundsException.me('Index ' + index + ' out of bounds ' + get_indices_0(_this__u8e3s4).toString());
  return _this__u8e3s4[index];
}
//region block: post-declaration
initMetadataForInterface(SerializationStrategy, 'SerializationStrategy');
initMetadataForInterface(DeserializationStrategy, 'DeserializationStrategy');
initMetadataForInterface(KSerializer, 'KSerializer', VOID, VOID, [SerializationStrategy, DeserializationStrategy]);
initMetadataForClass(AbstractPolymorphicSerializer, 'AbstractPolymorphicSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(PolymorphicSerializer, 'PolymorphicSerializer');
initMetadataForClass(SealedClassSerializer$$inlined$groupingBy$1);
initMetadataForClass(SealedClassSerializer, 'SealedClassSerializer');
initMetadataForClass(SerializationException, 'SerializationException', SerializationException.h1v);
initMetadataForClass(MissingFieldException, 'MissingFieldException');
initMetadataForClass(UnknownFieldException, 'UnknownFieldException');
initMetadataForInterface(SerialDescriptor, 'SerialDescriptor');
initMetadataForClass(ContextDescriptor, 'ContextDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForClass(elementDescriptors$1);
initMetadataForClass(elementDescriptors$$inlined$Iterable$1);
initMetadataForClass(elementNames$1);
initMetadataForClass(elementNames$$inlined$Iterable$1);
initMetadataForClass(ClassSerialDescriptorBuilder, 'ClassSerialDescriptorBuilder');
initMetadataForInterface(CachedNames, 'CachedNames');
protoOf(SerialDescriptorImpl).f1w = get_isNullable;
protoOf(SerialDescriptorImpl).k1w = get_isInline;
initMetadataForClass(SerialDescriptorImpl, 'SerialDescriptorImpl', VOID, VOID, [SerialDescriptor, CachedNames]);
initMetadataForClass(SerialKind, 'SerialKind');
initMetadataForObject(ENUM, 'ENUM');
initMetadataForObject(CONTEXTUAL, 'CONTEXTUAL');
initMetadataForClass(PolymorphicKind, 'PolymorphicKind');
initMetadataForObject(SEALED, 'SEALED');
initMetadataForObject(OPEN, 'OPEN');
initMetadataForClass(PrimitiveKind, 'PrimitiveKind');
initMetadataForObject(BOOLEAN, 'BOOLEAN');
initMetadataForObject(BYTE, 'BYTE');
initMetadataForObject(CHAR, 'CHAR');
initMetadataForObject(SHORT, 'SHORT');
initMetadataForObject(INT, 'INT');
initMetadataForObject(LONG, 'LONG');
initMetadataForObject(FLOAT, 'FLOAT');
initMetadataForObject(DOUBLE, 'DOUBLE');
initMetadataForObject(STRING, 'STRING');
initMetadataForClass(StructureKind, 'StructureKind');
initMetadataForObject(CLASS, 'CLASS');
initMetadataForObject(LIST, 'LIST');
initMetadataForObject(MAP, 'MAP');
initMetadataForObject(OBJECT, 'OBJECT');
initMetadataForInterface(Decoder, 'Decoder');
initMetadataForInterface(CompositeDecoder, 'CompositeDecoder');
protoOf(AbstractDecoder).s1y = decodeSerializableElement$default;
protoOf(AbstractDecoder).e1y = decodeSerializableValue;
protoOf(AbstractDecoder).v1y = decodeSequentially;
protoOf(AbstractDecoder).x1y = decodeCollectionSize;
initMetadataForClass(AbstractDecoder, 'AbstractDecoder', VOID, VOID, [Decoder, CompositeDecoder]);
initMetadataForInterface(Encoder, 'Encoder');
initMetadataForInterface(CompositeEncoder, 'CompositeEncoder');
protoOf(AbstractEncoder).b20 = encodeNotNullMark;
protoOf(AbstractEncoder).c20 = beginCollection;
protoOf(AbstractEncoder).y1z = encodeSerializableValue;
protoOf(AbstractEncoder).a20 = encodeNullableSerializableValue;
protoOf(AbstractEncoder).d20 = shouldEncodeElementDefault;
initMetadataForClass(AbstractEncoder, 'AbstractEncoder', VOID, VOID, [Encoder, CompositeEncoder]);
initMetadataForObject(NothingSerializer, 'NothingSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(DurationSerializer, 'DurationSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UuidSerializer, 'UuidSerializer', VOID, VOID, [KSerializer]);
protoOf(ListLikeDescriptor).f1w = get_isNullable;
protoOf(ListLikeDescriptor).k1w = get_isInline;
protoOf(ListLikeDescriptor).m1w = get_annotations;
initMetadataForClass(ListLikeDescriptor, 'ListLikeDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForClass(ArrayListClassDesc, 'ArrayListClassDesc');
initMetadataForClass(HashSetClassDesc, 'HashSetClassDesc');
initMetadataForClass(LinkedHashSetClassDesc, 'LinkedHashSetClassDesc');
protoOf(MapLikeDescriptor).f1w = get_isNullable;
protoOf(MapLikeDescriptor).k1w = get_isInline;
protoOf(MapLikeDescriptor).m1w = get_annotations;
initMetadataForClass(MapLikeDescriptor, 'MapLikeDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForClass(HashMapClassDesc, 'HashMapClassDesc');
initMetadataForClass(LinkedHashMapClassDesc, 'LinkedHashMapClassDesc');
initMetadataForClass(ArrayClassDesc, 'ArrayClassDesc');
initMetadataForClass(PrimitiveArrayDescriptor, 'PrimitiveArrayDescriptor');
initMetadataForClass(AbstractCollectionSerializer, 'AbstractCollectionSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(CollectionLikeSerializer, 'CollectionLikeSerializer');
initMetadataForClass(CollectionSerializer, 'CollectionSerializer');
initMetadataForClass(ArrayListSerializer, 'ArrayListSerializer');
initMetadataForClass(HashSetSerializer, 'HashSetSerializer');
initMetadataForClass(LinkedHashSetSerializer, 'LinkedHashSetSerializer');
initMetadataForClass(MapLikeSerializer, 'MapLikeSerializer');
initMetadataForClass(HashMapSerializer, 'HashMapSerializer');
initMetadataForClass(LinkedHashMapSerializer, 'LinkedHashMapSerializer');
initMetadataForClass(ReferenceArraySerializer, 'ReferenceArraySerializer');
initMetadataForClass(PrimitiveArraySerializer, 'PrimitiveArraySerializer');
initMetadataForClass(PrimitiveArrayBuilder, 'PrimitiveArrayBuilder');
initMetadataForCompanion(Companion);
initMetadataForClass(ElementMarker, 'ElementMarker');
initMetadataForClass(EnumSerializer, 'EnumSerializer', VOID, VOID, [KSerializer]);
protoOf(PluginGeneratedSerialDescriptor).f1w = get_isNullable;
protoOf(PluginGeneratedSerialDescriptor).k1w = get_isInline;
initMetadataForClass(PluginGeneratedSerialDescriptor, 'PluginGeneratedSerialDescriptor', VOID, VOID, [SerialDescriptor, CachedNames]);
initMetadataForClass(EnumDescriptor, 'EnumDescriptor');
initMetadataForClass(InlineClassDescriptor, 'InlineClassDescriptor');
initMetadataForInterface(GeneratedSerializer, 'GeneratedSerializer', VOID, VOID, [KSerializer]);
protoOf(InlinePrimitiveDescriptor$1).k26 = typeParametersSerializers;
initMetadataForClass(InlinePrimitiveDescriptor$1, VOID, VOID, VOID, [GeneratedSerializer]);
initMetadataForObject(NoOpEncoder, 'NoOpEncoder');
protoOf(NothingSerialDescriptor).f1w = get_isNullable;
protoOf(NothingSerialDescriptor).k1w = get_isInline;
protoOf(NothingSerialDescriptor).m1w = get_annotations;
initMetadataForObject(NothingSerialDescriptor, 'NothingSerialDescriptor', VOID, VOID, [SerialDescriptor]);
initMetadataForClass(NullableSerializer, 'NullableSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(SerialDescriptorForNullable, 'SerialDescriptorForNullable', VOID, VOID, [SerialDescriptor, CachedNames]);
initMetadataForClass(ObjectSerializer, 'ObjectSerializer', VOID, VOID, [KSerializer]);
initMetadataForInterface(SerializerFactory, 'SerializerFactory');
initMetadataForObject(CharArraySerializer, 'CharArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(DoubleArraySerializer, 'DoubleArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(FloatArraySerializer, 'FloatArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(LongArraySerializer, 'LongArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(ULongArraySerializer, 'ULongArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(IntArraySerializer, 'IntArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(UIntArraySerializer, 'UIntArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(ShortArraySerializer, 'ShortArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(UShortArraySerializer, 'UShortArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(ByteArraySerializer, 'ByteArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(UByteArraySerializer, 'UByteArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForObject(BooleanArraySerializer, 'BooleanArraySerializer', VOID, VOID, [KSerializer, PrimitiveArraySerializer]);
initMetadataForClass(CharArrayBuilder, 'CharArrayBuilder');
initMetadataForClass(DoubleArrayBuilder, 'DoubleArrayBuilder');
initMetadataForClass(FloatArrayBuilder, 'FloatArrayBuilder');
initMetadataForClass(LongArrayBuilder, 'LongArrayBuilder');
initMetadataForClass(ULongArrayBuilder, 'ULongArrayBuilder');
initMetadataForClass(IntArrayBuilder, 'IntArrayBuilder');
initMetadataForClass(UIntArrayBuilder, 'UIntArrayBuilder');
initMetadataForClass(ShortArrayBuilder, 'ShortArrayBuilder');
initMetadataForClass(UShortArrayBuilder, 'UShortArrayBuilder');
initMetadataForClass(ByteArrayBuilder, 'ByteArrayBuilder');
initMetadataForClass(UByteArrayBuilder, 'UByteArrayBuilder');
initMetadataForClass(BooleanArrayBuilder, 'BooleanArrayBuilder');
initMetadataForObject(StringSerializer, 'StringSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(CharSerializer, 'CharSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(DoubleSerializer, 'DoubleSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(FloatSerializer, 'FloatSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(LongSerializer, 'LongSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(IntSerializer, 'IntSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(ShortSerializer, 'ShortSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(ByteSerializer, 'ByteSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(BooleanSerializer, 'BooleanSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UnitSerializer, 'UnitSerializer', VOID, VOID, [KSerializer]);
protoOf(PrimitiveSerialDescriptor).f1w = get_isNullable;
protoOf(PrimitiveSerialDescriptor).k1w = get_isInline;
protoOf(PrimitiveSerialDescriptor).m1w = get_annotations;
initMetadataForClass(PrimitiveSerialDescriptor, 'PrimitiveSerialDescriptor', VOID, VOID, [SerialDescriptor]);
protoOf(TaggedEncoder).c20 = beginCollection;
protoOf(TaggedEncoder).y1z = encodeSerializableValue;
protoOf(TaggedEncoder).a20 = encodeNullableSerializableValue;
protoOf(TaggedEncoder).d20 = shouldEncodeElementDefault;
initMetadataForClass(TaggedEncoder, 'TaggedEncoder', VOID, VOID, [Encoder, CompositeEncoder]);
initMetadataForClass(NamedValueEncoder, 'NamedValueEncoder');
protoOf(TaggedDecoder).s1y = decodeSerializableElement$default;
protoOf(TaggedDecoder).e1y = decodeSerializableValue;
protoOf(TaggedDecoder).v1y = decodeSequentially;
protoOf(TaggedDecoder).x1y = decodeCollectionSize;
initMetadataForClass(TaggedDecoder, 'TaggedDecoder', VOID, VOID, [Decoder, CompositeDecoder]);
initMetadataForClass(NamedValueDecoder, 'NamedValueDecoder');
initMetadataForClass(MapEntry, 'MapEntry', VOID, VOID, [Entry]);
initMetadataForClass(KeyValueSerializer, 'KeyValueSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(MapEntrySerializer, 'MapEntrySerializer');
initMetadataForClass(PairSerializer, 'PairSerializer');
initMetadataForClass(TripleSerializer, 'TripleSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(ULongSerializer, 'ULongSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UIntSerializer, 'UIntSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UShortSerializer, 'UShortSerializer', VOID, VOID, [KSerializer]);
initMetadataForObject(UByteSerializer, 'UByteSerializer', VOID, VOID, [KSerializer]);
initMetadataForClass(SerializersModule, 'SerializersModule');
initMetadataForClass(SerialModuleImpl, 'SerialModuleImpl');
initMetadataForClass(ContextualProvider, 'ContextualProvider');
initMetadataForClass(Argless, 'Argless');
initMetadataForClass(WithTypeArguments, 'WithTypeArguments');
initMetadataForInterface(SerializersModuleCollector, 'SerializersModuleCollector');
initMetadataForClass(SerializableWith, 'SerializableWith', VOID, VOID, VOID, VOID, 0);
initMetadataForClass(createCache$1);
initMetadataForClass(createParametrizedCache$1);
//endregion
//region block: exports
export {
  OPEN_getInstance as OPEN_getInstance1ppfglhtdde20,
  SEALED_getInstance as SEALED_getInstance15u0wl5f5h4qk,
  BOOLEAN_getInstance as BOOLEAN_getInstance1s8i8e2xmvmon,
  BYTE_getInstance as BYTE_getInstance3l0en7kumss35,
  CHAR_getInstance as CHAR_getInstance136x8e9sqt1t7,
  DOUBLE_getInstance as DOUBLE_getInstance3nog56dy847km,
  FLOAT_getInstance as FLOAT_getInstance1j10ivnvurzks,
  INT_getInstance as INT_getInstance3cjna3yzozsnp,
  LONG_getInstance as LONG_getInstance3ud8vh8r2ot7x,
  SHORT_getInstance as SHORT_getInstance34lbpnul1ebqc,
  STRING_getInstance as STRING_getInstance2gbamclnmtzqa,
  CONTEXTUAL_getInstance as CONTEXTUAL_getInstance40twmib99zqv,
  ENUM_getInstance as ENUM_getInstance3doea03ve3rgg,
  CLASS_getInstance as CLASS_getInstance1ss90e870vddp,
  LIST_getInstance as LIST_getInstance3iji3zetpdcxm,
  MAP_getInstance as MAP_getInstance2l4ulrz8ljw5i,
  OBJECT_getInstance as OBJECT_getInstancee89a3hlgr5ys,
  BooleanSerializer_getInstance as BooleanSerializer_getInstancet3wtk7fl7i4f,
  DoubleSerializer_getInstance as DoubleSerializer_getInstance2avi1jm48x8le,
  IntSerializer_getInstance as IntSerializer_getInstance9scrtcljaiv6,
  LongSerializer_getInstance as LongSerializer_getInstance3iic24guzegu7,
  StringSerializer_getInstance as StringSerializer_getInstance1k1oz5j50sfik,
  ListSerializer as ListSerializer1hxuk9dx5n9du,
  MapSerializer as MapSerializer11kmegt3g5c1g,
  get_nullable as get_nullable197rfua9r7fsz,
  serializer_1 as serializer1x79l67jvwntn,
  serializer_10 as serializer1q7c5q67ysppr,
  serializer_8 as serializer3ikrxnm8b29d6,
  serializer_12 as serializer36584sjyg5661,
  serializer_6 as serializer2lw83vwvpnyms,
  PolymorphicKind as PolymorphicKindla9gurooefwb,
  BOOLEAN as BOOLEANwrdyi6z6g9t5,
  BYTE as BYTE3998jn8in9237,
  CHAR as CHARm37y40it075g,
  DOUBLE as DOUBLExcx7tue0m1mu,
  FLOAT as FLOAT2bpqq59z4fuiu,
  INT as INT3fyso8r94fmo5,
  LONG as LONG2pk1o9ze1il7c,
  SHORT as SHORTo7q5gsuxaxs,
  STRING as STRINGrrr0wq2m1c2f,
  PrimitiveKind as PrimitiveKindndgbuh6is7ze,
  PrimitiveSerialDescriptor_0 as PrimitiveSerialDescriptor3egfp53lutxj2,
  get_annotations as get_annotationshjxdbdcl8kmv,
  get_isInline as get_isInline5x26qrhi9qs6,
  get_isNullable as get_isNullable36pbikm8xb7bz,
  SerialDescriptor as SerialDescriptor2pelqekb5ic3a,
  CONTEXTUAL as CONTEXTUAL2e1gz2tojnpmj,
  ENUM as ENUMlmq49cvwy4ow,
  CLASS as CLASS3e32wwn6b97hz,
  LIST as LIST2gzos3vzn3slg,
  MAP as MAPtg3mcyan4256,
  OBJECT as OBJECT2nknkrqb4pf7m,
  buildClassSerialDescriptor as buildClassSerialDescriptors2a6xdp6mrtw,
  buildSerialDescriptor as buildSerialDescriptor2873qmkp8r2ib,
  get_elementNames as get_elementNamesl5b6t976dltd,
  getContextualDescriptor as getContextualDescriptor2n1gf3b895yb8,
  get_nullable_0 as get_nullable1xmxlk8ba6b4f,
  AbstractDecoder as AbstractDecoder35guh02ubh2hm,
  AbstractEncoder as AbstractEncoder2gxtu3xmy3f8j,
  CompositeDecoder as CompositeDecoder2tzm7wpwkr0og,
  CompositeEncoder as CompositeEncoderknecpkexzn3v,
  Decoder as Decoder23nde051s631g,
  Encoder as Encoderqvmrpqtq8hnu,
  AbstractPolymorphicSerializer as AbstractPolymorphicSerializer1ccxwp48nfy58,
  ArrayListSerializer as ArrayListSerializer7k5wnrulb3y6,
  ElementMarker as ElementMarker33ojvsajwmzts,
  typeParametersSerializers as typeParametersSerializers2likxjr48tr7y,
  GeneratedSerializer as GeneratedSerializer1f7t7hssdd2ws,
  InlineClassDescriptor as InlineClassDescriptor2odlvyasjrmr0,
  InlinePrimitiveDescriptor as InlinePrimitiveDescriptor3i6ccn1a4fw94,
  NamedValueDecoder as NamedValueDecoderzk26ztf92xbq,
  NamedValueEncoder as NamedValueEncoder1lca9edk1lf89,
  PluginGeneratedSerialDescriptor as PluginGeneratedSerialDescriptorqdzeg5asqhfg,
  SerializerFactory as SerializerFactory1qv9hivitncuv,
  createSimpleEnumSerializer as createSimpleEnumSerializer2guioz11kk1m0,
  jsonCachedSerialNames as jsonCachedSerialNameslxufy2gu43jt,
  throwMissingFieldException as throwMissingFieldException2cmke0v3ynf14,
  EmptySerializersModule_0 as EmptySerializersModule991ju6pz9b79,
  contextual as contextual3hpp1gupsu4al,
  SerializersModuleCollector as SerializersModuleCollector3dddz14wd7brg,
  DeserializationStrategy as DeserializationStrategy1z3z5pj9f7zc8,
  KSerializer as KSerializerzf77vz1967fq,
  MissingFieldException as MissingFieldException24tqif29emcmi,
  SealedClassSerializer as SealedClassSerializeriwipiibk55zc,
  SerializationException as SerializationExceptioneqrdve3ts2n9,
  SerializationStrategy as SerializationStrategyh6ouydnm6hci,
  UnknownFieldException as UnknownFieldExceptiona60e3a6v1xqo,
  findPolymorphicSerializer_0 as findPolymorphicSerializer1nm87hvemahcj,
  findPolymorphicSerializer as findPolymorphicSerializerk638ixyjovk5,
  serializer_0 as serializer1hwzc6m64v1op,
};
//endregion

//# sourceMappingURL=kotlinx-serialization-kotlinx-serialization-core.mjs.map
