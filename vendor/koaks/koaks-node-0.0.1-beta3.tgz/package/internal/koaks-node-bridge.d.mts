type Nullable<T> = T | null | undefined
/** @deprecated  */
export declare const initHook: { get(): any; };
export declare class KoaksBridge {
    private constructor();
    request(method: string, paramsJson: string): Promise<string>;
    static startSubscription$default($this: KoaksBridge, agentKey: Nullable<string>, callbackId: string, events: any/* Flow<JsonObject> */, toolExecutionId?: Nullable<string>): any/* JsonPrimitive */;
}
export declare function createKoaksBridge(configJson: string, invoke: (p0: string, p1: string) => Promise<string>, notify: (p0: string, p1: string) => void): KoaksBridge;