import {
  PrimitiveClasses_getInstance28ukyr6i8fs0q as PrimitiveClasses_getInstance,
  arrayOf1akklvh2at202 as arrayOf,
  createKType1lgox3mzhchp5 as createKType,
  Unit_instance104q5opgivhr8 as Unit_instance,
  VOID7hggqo3abtya as VOID,
  isBlank1dvkhjjvox3p0 as isBlank,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  equals2au1ep9vhcato as equals,
  hashCodeq5arwsb9dgti as hashCode,
  KtMutableMap1kqeifoi36kpz as KtMutableMap,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  Entry2xmjmyutzoq3p as Entry,
  isInterface3d6p8outrmvmk as isInterface,
  toString30pk9tzaqopn as toString_0,
  charArray2ujmm1qusno00 as charArray,
  charSequenceGet1vxk1y5n17t1z as charSequenceGet,
  toString35i91qxh73cps as toString_1,
  AbstractCoroutineContextElement2rpehg0hv5szw as AbstractCoroutineContextElement,
  Element2gr7ezmxqaln7 as Element,
  ArrayList3it5z8td81qkl as ArrayList,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  toSet2orjxp16sotqu as toSet,
  KtSetjrjc7fhfd6b9 as KtSet,
  KtMutableSetwuwn7k5m570a as KtMutableSet,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  Enum3alwj03lh1n41 as Enum,
  firstOrNull1982767dljvdy as firstOrNull,
  KtMap140uvy3s5zad8 as KtMap,
  addAll1k27qatfgp3k5 as addAll,
  emptySetcxexqki71qfa as emptySet,
  emptyMapr06gerzljqtm as emptyMap,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  equals2v6cggk171b6e as equals_0,
  setOf1u3mizs95ngxo as setOf,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  StringBuildermazzzhj6kkai as StringBuilder,
  get_lastIndexld83bqhfgcdd as get_lastIndex,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  Char__plus_impl_qi7pgj1zq2c0uiotg93 as Char__plus_impl_qi7pgj,
  Char__toInt_impl_vasixd2xlaiz5u3itpv as Char__toInt_impl_vasixd,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  Long2qws0ah9gnpki as Long,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  protoOf180f3jzyo7rfj as protoOf,
  createThis2j2avj17cvnv2 as createThis,
  Comparable198qfk8pnblz0 as Comparable,
  enumEntries20mr21zbe3az4 as enumEntries,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  toMutableList20rdgwi7d3cwi as toMutableList,
  KtMutableList1beimitadwkna as KtMutableList,
  emptyList1g2z5xcrvp2zy as emptyList,
  get_lastIndex1yw0x4k50k51w as get_lastIndex_0,
  last1vo29oleiqj36 as last,
  mutableListOf6oorvk2mtdmp as mutableListOf,
  anyToString3ho3k49fc56mj as anyToString,
  KMutableProperty11e8g1gb0ecb9j as KMutableProperty1,
  getPropertyCallableRef1ajb9in178r5r as getPropertyCallableRef,
  setPropertiesToThrowableInstance1w2jjvl9y77yc as setPropertiesToThrowableInstance,
  captureStack1fzi4aczwc4hg as captureStack,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  _Result___get_isFailure__impl__jpirivzehaw445b0cy as _Result___get_isFailure__impl__jpiriv,
  Continuation1aa2oekvx7jm7 as Continuation,
  intercepted2ogpsikxxj4u0 as intercepted,
  KProperty1ca4yb4wlo496 as KProperty1,
  lazy2hsh8ze7j6ikd as lazy_0,
  isNaNymqb93xtq8w8 as isNaN_0,
  numberToLong1a4cndvg6c52s as numberToLong,
  toList3jhuyej2anx2q as toList,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
} from './kotlin-kotlin-stdlib.mjs';
import {
  SupervisorJobythnfxkr3jxc as SupervisorJob,
  Key_instancexdagtxajq561 as Key_instance,
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
  recoverStackTrace2i3si2i8nvw1k as recoverStackTrace,
} from './kotlinx-coroutines-core.mjs';
import { atomic$ref$130aurmcwdfdf1 as atomic$ref$1 } from './kotlinx-atomicfu.mjs';
import {
  createSimpleEnumSerializer2guioz11kk1m0 as createSimpleEnumSerializer,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  UnknownFieldExceptiona60e3a6v1xqo as UnknownFieldException,
  IntSerializer_getInstance9scrtcljaiv6 as IntSerializer_getInstance,
  LongSerializer_getInstance3iic24guzegu7 as LongSerializer_getInstance,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class AttributeKey {
  constructor(name, type) {
    var tmp;
    if (type === VOID) {
      // Inline function 'io.ktor.util.reflect.typeInfo' call
      var tmp_0 = PrimitiveClasses_getInstance().dg();
      // Inline function 'io.ktor.util.reflect.typeOfOrNull' call
      var tmp_1;
      try {
        tmp_1 = createKType(PrimitiveClasses_getInstance().dg(), arrayOf([]), false);
      } catch ($p) {
        var tmp_2;
        if ($p instanceof Error) {
          var _unused_var__etf5q3 = $p;
          tmp_2 = null;
        } else {
          throw $p;
        }
        tmp_1 = tmp_2;
      }
      var tmp$ret$0 = tmp_1;
      tmp = new TypeInfo(tmp_0, tmp$ret$0);
    } else {
      tmp = type;
    }
    type = tmp;
    this.y2f_1 = name;
    this.z2f_1 = type;
    // Inline function 'kotlin.text.isNotBlank' call
    var this_0 = this.y2f_1;
    // Inline function 'kotlin.require' call
    if (!!isBlank(this_0)) {
      var message = "Name can't be blank";
      throw IllegalArgumentException.t(toString(message));
    }
  }
  toString() {
    return 'AttributeKey: ' + this.y2f_1;
  }
  hashCode() {
    var result = getStringHashCode(this.y2f_1);
    result = imul(result, 31) + this.z2f_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AttributeKey))
      return false;
    var tmp0_other_with_cast = other instanceof AttributeKey ? other : THROW_CCE();
    if (!(this.y2f_1 === tmp0_other_with_cast.y2f_1))
      return false;
    if (!this.z2f_1.equals(tmp0_other_with_cast.z2f_1))
      return false;
    return true;
  }
}
class Attributes {}
function get(key) {
  var tmp0_elvis_lhs = this.b2g(key);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    throw IllegalStateException.t4('No instance for key ' + key.toString());
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
class CaseInsensitiveMap {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.j2g_1 = LinkedHashMap.hc();
  }
  b1() {
    return this.j2g_1.b1();
  }
  k2g(key) {
    return this.j2g_1.f3(new CaseInsensitiveString(key));
  }
  f3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return false;
    return this.k2g((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  l2g(key) {
    return this.j2g_1.h3(caseInsensitive(key));
  }
  h3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return null;
    return this.l2g((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  h1() {
    return this.j2g_1.h1();
  }
  b3() {
    this.j2g_1.b3();
  }
  m2g(key, value) {
    return this.j2g_1.k3(caseInsensitive(key), value);
  }
  k3(key, value) {
    var tmp = (!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE();
    return this.m2g(tmp, !(value == null) ? value : THROW_CCE());
  }
  n2g(from) {
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = from.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var key = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var value = element.n1();
      this.m2g(key, value);
    }
  }
  m3(from) {
    return this.n2g(from);
  }
  o2g(key) {
    return this.j2g_1.l3(caseInsensitive(key));
  }
  l3(key) {
    if (!(!(key == null) ? typeof key === 'string' : false))
      return null;
    return this.o2g((!(key == null) ? typeof key === 'string' : false) ? key : THROW_CCE());
  }
  i3() {
    var tmp = this.j2g_1.i3();
    var tmp_0 = CaseInsensitiveMap$_get_keys_$lambda_ptzlqj;
    return new DelegatingMutableSet(tmp, tmp_0, CaseInsensitiveMap$_get_keys_$lambda_ptzlqj_0);
  }
  l1() {
    var tmp = this.j2g_1.l1();
    var tmp_0 = CaseInsensitiveMap$_get_entries_$lambda_r32w19;
    return new DelegatingMutableSet(tmp, tmp_0, CaseInsensitiveMap$_get_entries_$lambda_r32w19_0);
  }
  j3() {
    return this.j2g_1.j3();
  }
  equals(other) {
    var tmp;
    if (other == null) {
      tmp = true;
    } else {
      tmp = !(other instanceof CaseInsensitiveMap);
    }
    if (tmp)
      return false;
    return equals(other.j2g_1, this.j2g_1);
  }
  hashCode() {
    return hashCode(this.j2g_1);
  }
}
class Entry_0 {
  constructor(key, value) {
    this.p2g_1 = key;
    this.q2g_1 = value;
  }
  m1() {
    return this.p2g_1;
  }
  n1() {
    return this.q2g_1;
  }
  hashCode() {
    return (527 + hashCode(ensureNotNull(this.p2g_1)) | 0) + hashCode(ensureNotNull(this.q2g_1)) | 0;
  }
  equals(other) {
    var tmp;
    if (other == null) {
      tmp = true;
    } else {
      tmp = !(!(other == null) ? isInterface(other, Entry) : false);
    }
    if (tmp)
      return false;
    return equals(other.m1(), this.p2g_1) && equals(other.n1(), this.q2g_1);
  }
  toString() {
    return toString_0(this.p2g_1) + '=' + toString_0(this.q2g_1);
  }
}
class SilentSupervisor$$inlined$CoroutineExceptionHandler$1 extends AbstractCoroutineContextElement {
  constructor() {
    super(Key_instance);
  }
  c12(context, exception) {
    return Unit_instance;
  }
}
class DelegatingMutableSet$iterator$1 {
  constructor(this$0) {
    this.t2g_1 = this$0;
    this.s2g_1 = this$0.u2g_1.y();
  }
  z() {
    return this.s2g_1.z();
  }
  a1() {
    return this.t2g_1.v2g_1(this.s2g_1.a1());
  }
  e6() {
    return this.s2g_1.e6();
  }
}
class DelegatingMutableSet {
  constructor(delegate, convertTo, convert) {
    this.u2g_1 = delegate;
    this.v2g_1 = convertTo;
    this.w2g_1 = convert;
    this.x2g_1 = this.u2g_1.b1();
  }
  y2g(_this__u8e3s4) {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(_this__u8e3s4, 10));
    var _iterator__ex2g4s = _this__u8e3s4.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = this.w2g_1(item);
      destination.l(tmp$ret$0);
    }
    return destination;
  }
  z2g(_this__u8e3s4) {
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination = ArrayList.x(collectionSizeOrDefault(_this__u8e3s4, 10));
    var _iterator__ex2g4s = _this__u8e3s4.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var tmp$ret$0 = this.v2g_1(item);
      destination.l(tmp$ret$0);
    }
    return destination;
  }
  b1() {
    return this.x2g_1;
  }
  a2h(element) {
    return this.u2g_1.l(this.w2g_1(element));
  }
  l(element) {
    return this.a2h((element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
  b2h(elements) {
    return this.u2g_1.c1(this.y2g(elements));
  }
  c1(elements) {
    return this.b2h(elements);
  }
  b3() {
    this.u2g_1.b3();
  }
  c2h(element) {
    return this.u2g_1.z2(this.w2g_1(element));
  }
  z2(element) {
    if (!(element == null ? true : !(element == null)))
      return false;
    return this.c2h((element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
  d2h(elements) {
    return this.u2g_1.a3(toSet(this.y2g(elements)));
  }
  a3(elements) {
    return this.d2h(elements);
  }
  e2h(element) {
    return this.u2g_1.v2(this.w2g_1(element));
  }
  v2(element) {
    if (!(element == null ? true : !(element == null)))
      return false;
    return this.e2h((element == null ? true : !(element == null)) ? element : THROW_CCE());
  }
  f2h(elements) {
    return this.u2g_1.w2(this.y2g(elements));
  }
  w2(elements) {
    return this.f2h(elements);
  }
  h1() {
    return this.u2g_1.h1();
  }
  y() {
    return new DelegatingMutableSet$iterator$1(this);
  }
  hashCode() {
    return hashCode(this.u2g_1);
  }
  equals(other) {
    var tmp;
    if (other == null) {
      tmp = true;
    } else {
      tmp = !(!(other == null) ? isInterface(other, KtSet) : false);
    }
    if (tmp)
      return false;
    var elements = this.z2g(this.u2g_1);
    var tmp_0;
    if (other.w2(elements)) {
      // Inline function 'kotlin.collections.containsAll' call
      tmp_0 = elements.w2(other);
    } else {
      tmp_0 = false;
    }
    return tmp_0;
  }
  toString() {
    return toString(this.z2g(this.u2g_1));
  }
}
class Platform {}
class Jvm extends Platform {
  constructor() {
    Jvm_instance = null;
    super();
    Jvm_instance = this;
  }
  toString() {
    return 'Jvm';
  }
  hashCode() {
    return 1051825272;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Jvm))
      return false;
    other instanceof Jvm || THROW_CCE();
    return true;
  }
}
class Native extends Platform {
  constructor() {
    Native_instance = null;
    super();
    Native_instance = this;
  }
  toString() {
    return 'Native';
  }
  hashCode() {
    return -1059277600;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Native))
      return false;
    other instanceof Native || THROW_CCE();
    return true;
  }
}
class Js extends Platform {
  constructor(jsPlatform) {
    super();
    this.g2h_1 = jsPlatform;
  }
  toString() {
    return 'Js(jsPlatform=' + this.g2h_1.toString() + ')';
  }
  hashCode() {
    return this.g2h_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Js))
      return false;
    var tmp0_other_with_cast = other instanceof Js ? other : THROW_CCE();
    if (!this.g2h_1.equals(tmp0_other_with_cast.g2h_1))
      return false;
    return true;
  }
}
class WasmJs extends Platform {}
class JsPlatform extends Enum {}
class PlatformUtils {
  constructor() {
    PlatformUtils_instance = this;
    var tmp = this;
    var platform = get_platform(this);
    var tmp_0;
    if (platform instanceof Js) {
      tmp_0 = platform.g2h_1.equals(JsPlatform_Browser_getInstance());
    } else {
      if (platform instanceof WasmJs) {
        tmp_0 = platform.h2h_1.equals(JsPlatform_Browser_getInstance());
      } else {
        tmp_0 = false;
      }
    }
    tmp.i2h_1 = tmp_0;
    var tmp_1 = this;
    var platform_0 = get_platform(this);
    var tmp_2;
    if (platform_0 instanceof Js) {
      tmp_2 = platform_0.g2h_1.equals(JsPlatform_Node_getInstance());
    } else {
      if (platform_0 instanceof WasmJs) {
        tmp_2 = platform_0.h2h_1.equals(JsPlatform_Node_getInstance());
      } else {
        tmp_2 = false;
      }
    }
    tmp_1.j2h_1 = tmp_2;
    var tmp_3 = this;
    var tmp_4 = get_platform(this);
    tmp_3.k2h_1 = tmp_4 instanceof Js;
    var tmp_5 = this;
    var tmp_6 = get_platform(this);
    tmp_5.l2h_1 = tmp_6 instanceof WasmJs;
    this.m2h_1 = equals(get_platform(this), Jvm_getInstance());
    this.n2h_1 = equals(get_platform(this), Native_getInstance());
    this.o2h_1 = get_isDevelopmentMode(this);
    this.p2h_1 = true;
  }
}
class StringValues {}
function get_0(name) {
  var tmp0_safe_receiver = this.r2h(name);
  return tmp0_safe_receiver == null ? null : firstOrNull(tmp0_safe_receiver);
}
function forEach(body) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = this.t2h().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var k = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var v = element.n1();
    body(k, v);
  }
  return Unit_instance;
}
class StringValuesBuilderImpl {
  constructor(caseInsensitiveName, size) {
    caseInsensitiveName = caseInsensitiveName === VOID ? false : caseInsensitiveName;
    size = size === VOID ? 8 : size;
    this.v2h_1 = caseInsensitiveName;
    this.w2h_1 = this.v2h_1 ? caseInsensitiveMap() : LinkedHashMap.ic(size);
  }
  q2h() {
    return this.v2h_1;
  }
  r2h(name) {
    return this.w2h_1.h3(name);
  }
  z2h(name) {
    // Inline function 'kotlin.collections.contains' call
    // Inline function 'kotlin.collections.containsKey' call
    var this_0 = this.w2h_1;
    return (isInterface(this_0, KtMap) ? this_0 : THROW_CCE()).f3(name);
  }
  s2h() {
    return this.w2h_1.i3();
  }
  h1() {
    return this.w2h_1.h1();
  }
  t2h() {
    return unmodifiable(this.w2h_1.l1());
  }
  a2i(name, value) {
    this.b2i(value);
    var list = ensureListForKey(this, name);
    list.b3();
    list.l(value);
  }
  l2g(name) {
    var tmp0_safe_receiver = this.r2h(name);
    return tmp0_safe_receiver == null ? null : firstOrNull(tmp0_safe_receiver);
  }
  c2i(name, value) {
    this.b2i(value);
    ensureListForKey(this, name).l(value);
  }
  d2i(stringValues) {
    stringValues.u2h(StringValuesBuilderImpl$appendAll$lambda(this));
  }
  y2h(name, values) {
    // Inline function 'kotlin.let' call
    var list = ensureListForKey(this, name);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = values.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      this.b2i(element);
    }
    addAll(list, values);
  }
  e2i(name, values) {
    var tmp0_safe_receiver = this.w2h_1.h3(name);
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : toSet(tmp0_safe_receiver);
    var existing = tmp1_elvis_lhs == null ? emptySet() : tmp1_elvis_lhs;
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = values.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (!existing.v2(element)) {
        destination.l(element);
      }
    }
    this.y2h(name, destination);
  }
  f2i(name) {
    this.w2h_1.l3(name);
  }
  b3() {
    this.w2h_1.b3();
  }
  x2h(name) {
  }
  b2i(value) {
  }
}
class StringValuesImpl {
  constructor(caseInsensitiveName, values) {
    caseInsensitiveName = caseInsensitiveName === VOID ? false : caseInsensitiveName;
    values = values === VOID ? emptyMap() : values;
    this.g2i_1 = caseInsensitiveName;
    var tmp;
    if (this.g2i_1) {
      tmp = caseInsensitiveMap();
    } else {
      // Inline function 'kotlin.collections.mutableMapOf' call
      tmp = LinkedHashMap.hc();
    }
    var newMap = tmp;
    // Inline function 'kotlin.collections.forEach' call
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = values.l1().y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var key = element.m1();
      // Inline function 'kotlin.collections.component2' call
      var value = element.n1();
      // Inline function 'kotlin.collections.List' call
      // Inline function 'kotlin.collections.MutableList' call
      var size = value.b1();
      var list = ArrayList.x(size);
      // Inline function 'kotlin.repeat' call
      var inductionVariable = 0;
      if (inductionVariable < size)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var tmp$ret$4 = value.f1(index);
          list.l(tmp$ret$4);
        }
         while (inductionVariable < size);
      // Inline function 'kotlin.collections.set' call
      newMap.k3(key, list);
    }
    this.h2i_1 = newMap;
  }
  q2h() {
    return this.g2i_1;
  }
  l2g(name) {
    var tmp0_safe_receiver = listForKey(this, name);
    return tmp0_safe_receiver == null ? null : firstOrNull(tmp0_safe_receiver);
  }
  r2h(name) {
    return listForKey(this, name);
  }
  s2h() {
    return unmodifiable(this.h2i_1.i3());
  }
  h1() {
    return this.h2i_1.h1();
  }
  t2h() {
    return unmodifiable(this.h2i_1.l1());
  }
  u2h(body) {
    // Inline function 'kotlin.collections.iterator' call
    var _iterator__ex2g4s = this.h2i_1.l1().y();
    while (_iterator__ex2g4s.z()) {
      var _destruct__k2r9zo = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component1' call
      var key = _destruct__k2r9zo.m1();
      // Inline function 'kotlin.collections.component2' call
      var value = _destruct__k2r9zo.n1();
      body(key, value);
    }
  }
  toString() {
    return 'StringValues(case=' + !this.g2i_1 + ') ' + toString(this.t2h());
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(!(other == null) ? isInterface(other, StringValues) : false))
      return false;
    if (!(this.g2i_1 === other.q2h()))
      return false;
    return entriesEquals(this.t2h(), other.t2h());
  }
  hashCode() {
    return entriesHashCode(this.t2h(), imul(31, getBooleanHashCode(this.g2i_1)));
  }
}
class StringValuesSingleImpl$entries$1 {
  constructor(this$0) {
    this.i2i_1 = this$0.l2i_1;
    this.j2i_1 = this$0.m2i_1;
  }
  m1() {
    return this.i2i_1;
  }
  n1() {
    return this.j2i_1;
  }
  toString() {
    return this.i2i_1 + '=' + toString(this.j2i_1);
  }
  equals(other) {
    var tmp;
    var tmp_0;
    if (!(other == null) ? isInterface(other, Entry) : false) {
      tmp_0 = equals(other.m1(), this.i2i_1);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = equals(other.n1(), this.j2i_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return getStringHashCode(this.i2i_1) ^ hashCode(this.j2i_1);
  }
}
class StringValuesSingleImpl {
  constructor(caseInsensitiveName, name, values) {
    this.k2i_1 = caseInsensitiveName;
    this.l2i_1 = name;
    this.m2i_1 = values;
  }
  q2h() {
    return this.k2i_1;
  }
  r2h(name) {
    return equals_0(this.l2i_1, name, this.q2h()) ? this.m2i_1 : null;
  }
  t2h() {
    return setOf(new StringValuesSingleImpl$entries$1(this));
  }
  s2h() {
    return setOf(this.l2i_1);
  }
  toString() {
    return 'StringValues(case=' + !this.q2h() + ') ' + toString(this.t2h());
  }
  hashCode() {
    return entriesHashCode(this.t2h(), imul(31, getBooleanHashCode(this.q2h())));
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(!(other == null) ? isInterface(other, StringValues) : false))
      return false;
    if (!(this.q2h() === other.q2h()))
      return false;
    return entriesEquals(this.t2h(), other.t2h());
  }
  u2h(body) {
    return body(this.l2i_1, this.m2i_1);
  }
  l2g(name) {
    return equals_0(name, this.l2i_1, this.q2h()) ? firstOrNull(this.m2i_1) : null;
  }
}
class CaseInsensitiveString {
  constructor(content) {
    this.h2g_1 = content;
    var temp = 0;
    var indexedObject = this.h2g_1;
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var element = charSequenceGet(indexedObject, inductionVariable);
      inductionVariable = inductionVariable + 1 | 0;
      var tmp = imul(temp, 31);
      // Inline function 'kotlin.text.lowercaseChar' call
      // Inline function 'kotlin.text.lowercase' call
      // Inline function 'kotlin.js.asDynamic' call
      // Inline function 'kotlin.js.unsafeCast' call
      var tmp$ret$2 = toString_1(element).toLowerCase();
      // Inline function 'kotlin.code' call
      var this_0 = charSequenceGet(tmp$ret$2, 0);
      temp = tmp + Char__toInt_impl_vasixd(this_0) | 0;
    }
    this.i2g_1 = temp;
  }
  equals(other) {
    var tmp0_safe_receiver = other instanceof CaseInsensitiveString ? other : null;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.h2g_1;
    return (tmp1_safe_receiver == null ? null : equals_0(tmp1_safe_receiver, this.h2g_1, true)) === true;
  }
  hashCode() {
    return this.i2g_1;
  }
  toString() {
    return this.h2g_1;
  }
}
class CopyOnWriteHashMap {
  constructor() {
    this.n2i_1 = atomic$ref$1(emptyMap());
  }
  o2i(key) {
    return this.n2i_1.kotlinx$atomicfu$value.h3(key);
  }
}
class Companion {
  constructor() {
    Companion_instance_0 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_1 = lazy(tmp_0, GMTDate$Companion$$childSerializers$_anonymous__gyfycy);
    var tmp_2 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.p2i_1 = [null, null, null, tmp_1, null, null, lazy(tmp_2, GMTDate$Companion$$childSerializers$_anonymous__gyfycy_0), null, null];
    this.q2i_1 = GMTDate_0(new Long(0, 0));
  }
}
class $serializer {
  constructor() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('io.ktor.util.date.GMTDate', this, 9);
    tmp0_serialDesc.u25('seconds', false);
    tmp0_serialDesc.u25('minutes', false);
    tmp0_serialDesc.u25('hours', false);
    tmp0_serialDesc.u25('dayOfWeek', false);
    tmp0_serialDesc.u25('dayOfMonth', false);
    tmp0_serialDesc.u25('dayOfYear', false);
    tmp0_serialDesc.u25('month', false);
    tmp0_serialDesc.u25('year', false);
    tmp0_serialDesc.u25('timestamp', false);
    this.r2i_1 = tmp0_serialDesc;
  }
  s2i(encoder, value) {
    var tmp0_desc = this.r2i_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance().p2i_1;
    tmp1_output.q1z(tmp0_desc, 0, value.t2i_1);
    tmp1_output.q1z(tmp0_desc, 1, value.u2i_1);
    tmp1_output.q1z(tmp0_desc, 2, value.v2i_1);
    tmp1_output.x1z(tmp0_desc, 3, tmp2_cached[3].n1(), value.w2i_1);
    tmp1_output.q1z(tmp0_desc, 4, value.x2i_1);
    tmp1_output.q1z(tmp0_desc, 5, value.y2i_1);
    tmp1_output.x1z(tmp0_desc, 6, tmp2_cached[6].n1(), value.z2i_1);
    tmp1_output.q1z(tmp0_desc, 7, value.a2j_1);
    tmp1_output.r1z(tmp0_desc, 8, value.b2j_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.s2i(encoder, value instanceof GMTDate ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.r2i_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = 0;
    var tmp5_local1 = 0;
    var tmp6_local2 = 0;
    var tmp7_local3 = null;
    var tmp8_local4 = 0;
    var tmp9_local5 = 0;
    var tmp10_local6 = null;
    var tmp11_local7 = 0;
    var tmp12_local8 = new Long(0, 0);
    var tmp13_input = decoder.f1y(tmp0_desc);
    var tmp14_cached = Companion_getInstance().p2i_1;
    if (tmp13_input.v1y()) {
      tmp4_local0 = tmp13_input.k1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp13_input.k1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp13_input.k1y(tmp0_desc, 2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp13_input.r1y(tmp0_desc, 3, tmp14_cached[3].n1(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp13_input.k1y(tmp0_desc, 4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp13_input.k1y(tmp0_desc, 5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp13_input.r1y(tmp0_desc, 6, tmp14_cached[6].n1(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
      tmp11_local7 = tmp13_input.k1y(tmp0_desc, 7);
      tmp3_bitMask0 = tmp3_bitMask0 | 128;
      tmp12_local8 = tmp13_input.l1y(tmp0_desc, 8);
      tmp3_bitMask0 = tmp3_bitMask0 | 256;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp13_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp13_input.k1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp13_input.k1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp13_input.k1y(tmp0_desc, 2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp13_input.r1y(tmp0_desc, 3, tmp14_cached[3].n1(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp13_input.k1y(tmp0_desc, 4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp13_input.k1y(tmp0_desc, 5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp13_input.r1y(tmp0_desc, 6, tmp14_cached[6].n1(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          case 7:
            tmp11_local7 = tmp13_input.k1y(tmp0_desc, 7);
            tmp3_bitMask0 = tmp3_bitMask0 | 128;
            break;
          case 8:
            tmp12_local8 = tmp13_input.l1y(tmp0_desc, 8);
            tmp3_bitMask0 = tmp3_bitMask0 | 256;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp13_input.g1y(tmp0_desc);
    return GMTDate.c2j(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, tmp12_local8, null);
  }
  w1t() {
    return this.r2i_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance().p2i_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [IntSerializer_getInstance(), IntSerializer_getInstance(), IntSerializer_getInstance(), tmp0_cached[3].n1(), IntSerializer_getInstance(), IntSerializer_getInstance(), tmp0_cached[6].n1(), IntSerializer_getInstance(), LongSerializer_getInstance()];
  }
}
class GMTDate {
  constructor(seconds, minutes, hours, dayOfWeek, dayOfMonth, dayOfYear, month, year, timestamp) {
    Companion_getInstance();
    this.t2i_1 = seconds;
    this.u2i_1 = minutes;
    this.v2i_1 = hours;
    this.w2i_1 = dayOfWeek;
    this.x2i_1 = dayOfMonth;
    this.y2i_1 = dayOfYear;
    this.z2i_1 = month;
    this.a2j_1 = year;
    this.b2j_1 = timestamp;
  }
  d2j(other) {
    return this.b2j_1.s1(other.b2j_1);
  }
  d(other) {
    return this.d2j(other instanceof GMTDate ? other : THROW_CCE());
  }
  toString() {
    return 'GMTDate(seconds=' + this.t2i_1 + ', minutes=' + this.u2i_1 + ', hours=' + this.v2i_1 + ', dayOfWeek=' + this.w2i_1.toString() + ', dayOfMonth=' + this.x2i_1 + ', dayOfYear=' + this.y2i_1 + ', month=' + this.z2i_1.toString() + ', year=' + this.a2j_1 + ', timestamp=' + this.b2j_1.toString() + ')';
  }
  hashCode() {
    var result = this.t2i_1;
    result = imul(result, 31) + this.u2i_1 | 0;
    result = imul(result, 31) + this.v2i_1 | 0;
    result = imul(result, 31) + this.w2i_1.hashCode() | 0;
    result = imul(result, 31) + this.x2i_1 | 0;
    result = imul(result, 31) + this.y2i_1 | 0;
    result = imul(result, 31) + this.z2i_1.hashCode() | 0;
    result = imul(result, 31) + this.a2j_1 | 0;
    result = imul(result, 31) + this.b2j_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof GMTDate))
      return false;
    var tmp0_other_with_cast = other instanceof GMTDate ? other : THROW_CCE();
    if (!(this.t2i_1 === tmp0_other_with_cast.t2i_1))
      return false;
    if (!(this.u2i_1 === tmp0_other_with_cast.u2i_1))
      return false;
    if (!(this.v2i_1 === tmp0_other_with_cast.v2i_1))
      return false;
    if (!this.w2i_1.equals(tmp0_other_with_cast.w2i_1))
      return false;
    if (!(this.x2i_1 === tmp0_other_with_cast.x2i_1))
      return false;
    if (!(this.y2i_1 === tmp0_other_with_cast.y2i_1))
      return false;
    if (!this.z2i_1.equals(tmp0_other_with_cast.z2i_1))
      return false;
    if (!(this.a2j_1 === tmp0_other_with_cast.a2j_1))
      return false;
    if (!this.b2j_1.equals(tmp0_other_with_cast.b2j_1))
      return false;
    return true;
  }
  static c2j(seen0, seconds, minutes, hours, dayOfWeek, dayOfMonth, dayOfYear, month, year, timestamp, serializationConstructorMarker) {
    Companion_getInstance();
    if (!(511 === (511 & seen0))) {
      throwMissingFieldException(seen0, 511, $serializer_getInstance().r2i_1);
    }
    var $this = createThis(this);
    $this.t2i_1 = seconds;
    $this.u2i_1 = minutes;
    $this.v2i_1 = hours;
    $this.w2i_1 = dayOfWeek;
    $this.x2i_1 = dayOfMonth;
    $this.y2i_1 = dayOfYear;
    $this.z2i_1 = month;
    $this.a2j_1 = year;
    $this.b2j_1 = timestamp;
    return $this;
  }
}
class Companion_0 {
  e2j(ordinal) {
    return get_entries().f1(ordinal);
  }
}
class WeekDay extends Enum {
  constructor(name, ordinal, value) {
    super(name, ordinal);
    this.h2j_1 = value;
  }
}
class Companion_1 {
  e2j(ordinal) {
    return get_entries_0().f1(ordinal);
  }
}
class Month extends Enum {
  constructor(name, ordinal, value) {
    super(name, ordinal);
    this.k2j_1 = value;
  }
}
class Symbol {
  constructor(symbol) {
    this.l2j_1 = symbol;
  }
  toString() {
    return this.l2j_1;
  }
}
class LockFreeLinkedListNode {
  n18() {
    // Inline function 'kotlinx.atomicfu.loop' call
    var this_0 = this.m2j_1;
    while (true) {
      var next = this_0.kotlinx$atomicfu$value;
      if (!(next instanceof OpDescriptor))
        return next;
      next.n2j(this);
    }
  }
  o2j() {
    return unwrap(this.n18());
  }
}
class Removed {}
class OpDescriptor {}
class PipelineContext {
  constructor(context) {
    this.v2k_1 = context;
  }
}
class DebugPipelineContext extends PipelineContext {
  constructor(context, interceptors, subject, coroutineContext) {
    super(context);
    this.r2j_1 = interceptors;
    this.s2j_1 = coroutineContext;
    this.t2j_1 = subject;
    this.u2j_1 = 0;
  }
  ku() {
    return this.s2j_1;
  }
  w2j() {
    return this.t2j_1;
  }
  v2j() {
    this.u2j_1 = -1;
  }
  x2j(subject, $completion) {
    this.t2j_1 = subject;
    return this.y2j($completion);
  }
  y2j($completion) {
    var index = this.u2j_1;
    if (index < 0)
      return this.t2j_1;
    if (index >= this.r2j_1.b1()) {
      this.v2j();
      return this.t2j_1;
    }
    return proceedLoop(this, $completion);
  }
  z2j(initial, $completion) {
    this.u2j_1 = 0;
    this.t2j_1 = initial;
    return this.y2j($completion);
  }
}
class Companion_2 {
  constructor() {
    Companion_instance_3 = this;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.e2k_1 = ArrayList.k();
  }
}
class PhaseContent {
  static f2k(phase, relation, interceptors) {
    Companion_getInstance_2();
    var $this = createThis(this);
    $this.a2k_1 = phase;
    $this.b2k_1 = relation;
    $this.c2k_1 = interceptors;
    $this.d2k_1 = true;
    return $this;
  }
  static g2k(phase, relation) {
    Companion_getInstance_2();
    var tmp = Companion_getInstance_2().e2k_1;
    var $this = this.f2k(phase, relation, isInterface(tmp, KtMutableList) ? tmp : THROW_CCE());
    // Inline function 'kotlin.check' call
    if (!Companion_getInstance_2().e2k_1.h1()) {
      var message = 'The shared empty array list has been modified';
      throw IllegalStateException.t4(toString(message));
    }
    return $this;
  }
  h2k() {
    return this.c2k_1.h1();
  }
  b1() {
    return this.c2k_1.b1();
  }
  i2k(interceptor) {
    if (this.d2k_1) {
      copyInterceptors(this);
    }
    this.c2k_1.l(interceptor);
  }
  j2k(destination) {
    var interceptors = this.c2k_1;
    if (destination instanceof ArrayList) {
      destination.y7(destination.b1() + interceptors.b1() | 0);
    }
    var inductionVariable = 0;
    var last = interceptors.b1();
    if (inductionVariable < last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        destination.l(interceptors.f1(index));
      }
       while (inductionVariable < last);
  }
  k2k() {
    this.d2k_1 = true;
    return this.c2k_1;
  }
  toString() {
    return 'Phase `' + this.a2k_1.l2k_1 + '`, ' + this.b1() + ' handlers';
  }
}
class Pipeline {
  constructor(phases) {
    this.m2k_1 = AttributesJsFn(true);
    this.n2k_1 = false;
    this.o2k_1 = mutableListOf(phases.slice());
    this.p2k_1 = 0;
    this.q2k_1 = atomic$ref$1(null);
    this.r2k_1 = false;
    this.s2k_1 = null;
  }
  t2k() {
    return this.n2k_1;
  }
  u2k(context, subject, $completion) {
    // Inline function 'kotlin.js.getCoroutineContext' call
    var tmp$ret$0 = $completion.lc();
    return createContext(this, context, subject, tmp$ret$0).z2j(subject, $completion);
  }
  w2k(reference, phase) {
    if (hasPhase(this, phase))
      return Unit_instance;
    var index = findPhaseIndex(this, reference);
    if (index === -1) {
      throw InvalidPhaseException.y2k('Phase ' + reference.toString() + ' was not registered for this pipeline');
    }
    var lastRelatedPhaseIndex = index;
    var inductionVariable = index + 1 | 0;
    var last = get_lastIndex_0(this.o2k_1);
    if (inductionVariable <= last)
      $l$loop_0: do {
        var i = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = this.o2k_1.f1(i);
        var tmp0_safe_receiver = tmp instanceof PhaseContent ? tmp : null;
        var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.b2k_1;
        var tmp_0;
        if (tmp1_elvis_lhs == null) {
          break $l$loop_0;
        } else {
          tmp_0 = tmp1_elvis_lhs;
        }
        var relation = tmp_0;
        var tmp2_safe_receiver = relation instanceof After ? relation : null;
        var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.z2k_1;
        var tmp_1;
        if (tmp3_elvis_lhs == null) {
          continue $l$loop_0;
        } else {
          tmp_1 = tmp3_elvis_lhs;
        }
        var relatedTo = tmp_1;
        lastRelatedPhaseIndex = equals(relatedTo, reference) ? i : lastRelatedPhaseIndex;
      }
       while (!(i === last));
    this.o2k_1.d3(lastRelatedPhaseIndex + 1 | 0, PhaseContent.g2k(phase, new After(reference)));
  }
  a2l(reference, phase) {
    if (hasPhase(this, phase))
      return Unit_instance;
    var index = findPhaseIndex(this, reference);
    if (index === -1) {
      throw InvalidPhaseException.y2k('Phase ' + reference.toString() + ' was not registered for this pipeline');
    }
    this.o2k_1.d3(index, PhaseContent.g2k(phase, new Before(reference)));
  }
  b2l(phase, block) {
    var tmp0_elvis_lhs = findPhase(this, phase);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      throw InvalidPhaseException.y2k('Phase ' + phase.toString() + ' was not registered for this pipeline');
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var phaseContent = tmp;
    if (tryAddToPhaseFastPath(this, phase, block)) {
      this.p2k_1 = this.p2k_1 + 1 | 0;
      return Unit_instance;
    }
    phaseContent.i2k(block);
    this.p2k_1 = this.p2k_1 + 1 | 0;
    resetInterceptorsList(this);
    this.c2l();
  }
  c2l() {
  }
  toString() {
    return anyToString(this);
  }
}
class PipelinePhase {
  constructor(name) {
    this.l2k_1 = name;
  }
  toString() {
    return "Phase('" + this.l2k_1 + "')";
  }
}
class InvalidPhaseException extends Error {
  static y2k(message) {
    var $this = createThis(this);
    setPropertiesToThrowableInstance($this, message);
    captureStack($this, $this.x2k_1);
    return $this;
  }
}
class PipelinePhaseRelation {}
class After extends PipelinePhaseRelation {
  constructor(relativeTo) {
    super();
    this.z2k_1 = relativeTo;
  }
}
class Before extends PipelinePhaseRelation {
  constructor(relativeTo) {
    super();
    this.d2l_1 = relativeTo;
  }
}
class Last extends PipelinePhaseRelation {
  constructor() {
    Last_instance = null;
    super();
    Last_instance = this;
  }
  toString() {
    return 'Last';
  }
  hashCode() {
    return 967869129;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Last))
      return false;
    other instanceof Last || THROW_CCE();
    return true;
  }
}
class SuspendFunctionGun$continuation$1 {
  constructor(this$0) {
    this.m2l_1 = this$0;
    this.l2l_1 = -2147483648;
  }
  lc() {
    var continuation = this.m2l_1.i2l_1[this.m2l_1.j2l_1];
    if (!(continuation === this) && !(continuation == null))
      return continuation.lc();
    var index = this.m2l_1.j2l_1 - 1 | 0;
    while (index >= 0) {
      var _unary__edvuaz = index;
      index = _unary__edvuaz - 1 | 0;
      var cont = this.m2l_1.i2l_1[_unary__edvuaz];
      if (!(cont === this) && !(cont == null))
        return cont.lc();
    }
    // Inline function 'kotlin.error' call
    var message = 'Not started';
    throw IllegalStateException.t4(toString(message));
  }
  pm(result) {
    if (_Result___get_isFailure__impl__jpiriv(result)) {
      // Inline function 'kotlin.Companion.failure' call
      var exception = ensureNotNull(Result__exceptionOrNull_impl_p6xea9(result));
      var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception));
      resumeRootWith(this.m2l_1, tmp$ret$0);
      return Unit_instance;
    }
    loop(this.m2l_1, false);
  }
  nc(result) {
    return this.pm(result);
  }
}
class SuspendFunctionGun extends PipelineContext {
  constructor(initial, context, blocks) {
    super(context);
    this.f2l_1 = blocks;
    var tmp = this;
    tmp.g2l_1 = new SuspendFunctionGun$continuation$1(this);
    this.h2l_1 = initial;
    var tmp_0 = this;
    // Inline function 'kotlin.arrayOfNulls' call
    var size = this.f2l_1.b1();
    tmp_0.i2l_1 = Array(size);
    this.j2l_1 = -1;
    this.k2l_1 = 0;
  }
  ku() {
    return this.g2l_1.lc();
  }
  w2j() {
    return this.h2l_1;
  }
  y2j($completion) {
    var tmp$ret$0;
    $l$block_0: {
      if (this.k2l_1 === this.f2l_1.b1()) {
        tmp$ret$0 = this.h2l_1;
        break $l$block_0;
      }
      this.n2l(intercepted($completion));
      if (loop(this, true)) {
        discardLastRootContinuation(this);
        tmp$ret$0 = this.h2l_1;
        break $l$block_0;
      }
      tmp$ret$0 = get_COROUTINE_SUSPENDED();
    }
    return tmp$ret$0;
  }
  x2j(subject, $completion) {
    this.h2l_1 = subject;
    return this.y2j($completion);
  }
  z2j(initial, $completion) {
    this.k2l_1 = 0;
    if (this.k2l_1 === this.f2l_1.b1())
      return initial;
    this.h2l_1 = initial;
    if (this.j2l_1 >= 0)
      throw IllegalStateException.t4('Already started');
    return this.y2j($completion);
  }
  n2l(continuation) {
    this.j2l_1 = this.j2l_1 + 1 | 0;
    this.i2l_1[this.j2l_1] = continuation;
  }
}
class TypeInfo {
  constructor(type, kotlinType) {
    kotlinType = kotlinType === VOID ? null : kotlinType;
    this.o2l_1 = type;
    this.p2l_1 = kotlinType;
  }
  hashCode() {
    var tmp0_safe_receiver = this.p2l_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
    return tmp1_elvis_lhs == null ? this.o2l_1.hashCode() : tmp1_elvis_lhs;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof TypeInfo))
      return false;
    var tmp;
    if (!(this.p2l_1 == null) || !(other.p2l_1 == null)) {
      tmp = equals(this.p2l_1, other.p2l_1);
    } else {
      tmp = this.o2l_1.equals(other.o2l_1);
    }
    return tmp;
  }
  toString() {
    var tmp0_elvis_lhs = this.p2l_1;
    return 'TypeInfo(' + toString(tmp0_elvis_lhs == null ? this.o2l_1 : tmp0_elvis_lhs) + ')';
  }
}
class InvalidTimestampException extends IllegalStateException {
  static u2l(timestamp) {
    var $this = this.t4('Invalid date timestamp exception: ' + timestamp.toString());
    captureStack($this, $this.t2l_1);
    return $this;
  }
}
class AttributesJs {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableMapOf' call
    tmp.v2l_1 = LinkedHashMap.hc();
  }
  b2g(key) {
    var tmp = this.v2l_1.h3(key);
    return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  }
  c2g(key) {
    return this.v2l_1.f3(key);
  }
  d2g(key, value) {
    // Inline function 'kotlin.collections.set' call
    this.v2l_1.k3(key, value);
  }
  e2g(key) {
    this.v2l_1.l3(key);
  }
  f2g(key, block) {
    var tmp0_safe_receiver = this.v2l_1.h3(key);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      return !(tmp0_safe_receiver == null) ? tmp0_safe_receiver : THROW_CCE();
    }
    // Inline function 'kotlin.also' call
    var this_0 = block();
    // Inline function 'kotlin.collections.set' call
    this.v2l_1.k3(key, this_0);
    return this_0;
  }
  g2g() {
    return toList(this.v2l_1.i3());
  }
}
class KtorSimpleLogger$1 {
  constructor() {
    var tmp = this;
    var tmp_0;
    switch (PlatformUtils_getInstance().j2h_1 || PlatformUtils_getInstance().i2h_1) {
      case true:
        // Inline function 'kotlin.runCatching' call

        var tmp_1;
        try {
          // Inline function 'kotlin.Companion.success' call
          var value = getKtorLogLevel();
          tmp_1 = _Result___init__impl__xyqfz8(value);
        } catch ($p) {
          var tmp_2;
          if ($p instanceof Error) {
            var e = $p;
            // Inline function 'kotlin.Companion.failure' call
            tmp_2 = _Result___init__impl__xyqfz8(createFailure(e));
          } else {
            throw $p;
          }
          tmp_1 = tmp_2;
        }

        // Inline function 'kotlin.Result.getOrNull' call

        var this_0 = tmp_1;
        var tmp_3;
        if (_Result___get_isFailure__impl__jpiriv(this_0)) {
          tmp_3 = null;
        } else {
          var tmp_4 = _Result___get_value__impl__bjfvqg(this_0);
          tmp_3 = (tmp_4 == null ? true : !(tmp_4 == null)) ? tmp_4 : THROW_CCE();
        }

        var tmp1_safe_receiver = tmp_3;
        var tmp_5;
        if (tmp1_safe_receiver == null) {
          tmp_5 = null;
        } else {
          // Inline function 'kotlin.let' call
          var tmp0 = get_entries_1();
          var tmp$ret$6;
          $l$block: {
            // Inline function 'kotlin.collections.firstOrNull' call
            var _iterator__ex2g4s = tmp0.y();
            while (_iterator__ex2g4s.z()) {
              var element = _iterator__ex2g4s.a1();
              if (element.n3_1 === tmp1_safe_receiver) {
                tmp$ret$6 = element;
                break $l$block;
              }
            }
            tmp$ret$6 = null;
          }
          tmp_5 = tmp$ret$6;
        }

        var tmp2_elvis_lhs = tmp_5;
        tmp_0 = tmp2_elvis_lhs == null ? LogLevel_INFO_getInstance() : tmp2_elvis_lhs;
        break;
      case false:
        tmp_0 = LogLevel_TRACE_getInstance();
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    tmp.w2l_1 = tmp_0;
  }
  x2l() {
    return this.w2l_1;
  }
  y2l(message) {
    if (this.w2l_1.p3(LogLevel_WARN_getInstance()) > 0)
      return Unit_instance;
    console.warn(message);
  }
  z2l(message, cause) {
    if (this.w2l_1.p3(LogLevel_DEBUG_getInstance()) > 0)
      return Unit_instance;
    console.debug('DEBUG: ' + message + ', cause: ' + cause.toString());
  }
  a2m(message) {
    if (this.w2l_1.p3(LogLevel_TRACE_getInstance()) > 0)
      return Unit_instance;
    console.debug('TRACE: ' + message);
  }
}
class LogLevel extends Enum {}
//endregion
function putAll(_this__u8e3s4, other) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = other.g2g().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    _this__u8e3s4.d2g(element instanceof AttributeKey ? element : THROW_CCE(), other.a2g(element));
  }
}
function CaseInsensitiveMap$_get_keys_$lambda_ptzlqj($this$DelegatingMutableSet) {
  return $this$DelegatingMutableSet.h2g_1;
}
function CaseInsensitiveMap$_get_keys_$lambda_ptzlqj_0($this$DelegatingMutableSet) {
  return caseInsensitive($this$DelegatingMutableSet);
}
function CaseInsensitiveMap$_get_entries_$lambda_r32w19($this$DelegatingMutableSet) {
  return new Entry_0($this$DelegatingMutableSet.m1().h2g_1, $this$DelegatingMutableSet.n1());
}
function CaseInsensitiveMap$_get_entries_$lambda_r32w19_0($this$DelegatingMutableSet) {
  return new Entry_0(caseInsensitive($this$DelegatingMutableSet.m1()), $this$DelegatingMutableSet.n1());
}
function toCharArray(_this__u8e3s4) {
  var tmp = 0;
  var tmp_0 = _this__u8e3s4.length;
  var tmp_1 = charArray(tmp_0);
  while (tmp < tmp_0) {
    var tmp_2 = tmp;
    tmp_1[tmp_2] = charSequenceGet(_this__u8e3s4, tmp_2);
    tmp = tmp + 1 | 0;
  }
  return tmp_1;
}
function isLowerCase(_this__u8e3s4) {
  // Inline function 'kotlin.text.lowercaseChar' call
  // Inline function 'kotlin.text.lowercase' call
  // Inline function 'kotlin.js.asDynamic' call
  // Inline function 'kotlin.js.unsafeCast' call
  var tmp$ret$2 = toString_1(_this__u8e3s4).toLowerCase();
  return charSequenceGet(tmp$ret$2, 0) === _this__u8e3s4;
}
function caseInsensitiveMap() {
  return new CaseInsensitiveMap();
}
function SilentSupervisor(parent) {
  parent = parent === VOID ? null : parent;
  var tmp = SupervisorJob(parent);
  // Inline function 'kotlinx.coroutines.CoroutineExceptionHandler' call
  var tmp$ret$0 = new SilentSupervisor$$inlined$CoroutineExceptionHandler$1();
  return tmp.dn(tmp$ret$0);
}
var JsPlatform_Browser_instance;
var JsPlatform_Node_instance;
var JsPlatform_entriesInitialized;
function JsPlatform_initEntries() {
  if (JsPlatform_entriesInitialized)
    return Unit_instance;
  JsPlatform_entriesInitialized = true;
  JsPlatform_Browser_instance = new JsPlatform('Browser', 0);
  JsPlatform_Node_instance = new JsPlatform('Node', 1);
}
var Jvm_instance;
function Jvm_getInstance() {
  if (Jvm_instance === VOID)
    new Jvm();
  return Jvm_instance;
}
var Native_instance;
function Native_getInstance() {
  if (Native_instance === VOID)
    new Native();
  return Native_instance;
}
function JsPlatform_Browser_getInstance() {
  JsPlatform_initEntries();
  return JsPlatform_Browser_instance;
}
function JsPlatform_Node_getInstance() {
  JsPlatform_initEntries();
  return JsPlatform_Node_instance;
}
var PlatformUtils_instance;
function PlatformUtils_getInstance() {
  if (PlatformUtils_instance === VOID)
    new PlatformUtils();
  return PlatformUtils_instance;
}
function ensureListForKey($this, name) {
  var tmp0_elvis_lhs = $this.w2h_1.h3(name);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.collections.mutableListOf' call
    // Inline function 'kotlin.also' call
    var this_0 = ArrayList.k();
    $this.x2h(name);
    // Inline function 'kotlin.collections.set' call
    $this.w2h_1.k3(name, this_0);
    tmp = this_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function StringValuesBuilderImpl$appendAll$lambda(this$0) {
  return (name, values) => {
    this$0.y2h(name, values);
    return Unit_instance;
  };
}
function listForKey($this, name) {
  return $this.h2i_1.h3(name);
}
function appendAll(_this__u8e3s4, builder) {
  // Inline function 'kotlin.apply' call
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = builder.t2h().y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    // Inline function 'kotlin.collections.component1' call
    var name = element.m1();
    // Inline function 'kotlin.collections.component2' call
    var values = element.n1();
    _this__u8e3s4.y2h(name, values);
  }
  return _this__u8e3s4;
}
function entriesEquals(a, b) {
  return equals(a, b);
}
function entriesHashCode(entries, seed) {
  return imul(seed, 31) + hashCode(entries) | 0;
}
function toLowerCasePreservingASCIIRules(_this__u8e3s4) {
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.text.indexOfFirst' call
    var inductionVariable = 0;
    var last = charSequenceLength(_this__u8e3s4) - 1 | 0;
    if (inductionVariable <= last)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var it = charSequenceGet(_this__u8e3s4, index);
        if (!(toLowerCasePreservingASCII(it) === it)) {
          tmp$ret$1 = index;
          break $l$block;
        }
      }
       while (inductionVariable <= last);
    tmp$ret$1 = -1;
  }
  var firstIndex = tmp$ret$1;
  if (firstIndex === -1) {
    return _this__u8e3s4;
  }
  var original = _this__u8e3s4;
  // Inline function 'kotlin.text.buildString' call
  var capacity = _this__u8e3s4.length;
  // Inline function 'kotlin.apply' call
  var this_0 = StringBuilder.xb(capacity);
  this_0.ch(original, 0, firstIndex);
  var inductionVariable_0 = firstIndex;
  var last_0 = get_lastIndex(original);
  if (inductionVariable_0 <= last_0)
    do {
      var index_0 = inductionVariable_0;
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      this_0.ub(toLowerCasePreservingASCII(charSequenceGet(original, index_0)));
    }
     while (!(index_0 === last_0));
  return this_0.toString();
}
function toLowerCasePreservingASCII(ch) {
  var tmp;
  if (_Char___init__impl__6a9atx(65) <= ch ? ch <= _Char___init__impl__6a9atx(90) : false) {
    tmp = Char__plus_impl_qi7pgj(ch, 32);
  } else if (_Char___init__impl__6a9atx(0) <= ch ? ch <= _Char___init__impl__6a9atx(127) : false) {
    tmp = ch;
  } else {
    // Inline function 'kotlin.text.lowercaseChar' call
    // Inline function 'kotlin.text.lowercase' call
    // Inline function 'kotlin.js.asDynamic' call
    // Inline function 'kotlin.js.unsafeCast' call
    var tmp$ret$2 = toString_1(ch).toLowerCase();
    tmp = charSequenceGet(tmp$ret$2, 0);
  }
  return tmp;
}
function caseInsensitive(_this__u8e3s4) {
  return new CaseInsensitiveString(_this__u8e3s4);
}
function GMTDate$Companion$$childSerializers$_anonymous__gyfycy() {
  return createSimpleEnumSerializer('io.ktor.util.date.WeekDay', values());
}
function GMTDate$Companion$$childSerializers$_anonymous__gyfycy_0() {
  return createSimpleEnumSerializer('io.ktor.util.date.Month', values_0());
}
var Companion_instance_0;
function Companion_getInstance() {
  if (Companion_instance_0 === VOID)
    new Companion();
  return Companion_instance_0;
}
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance === VOID)
    new $serializer();
  return $serializer_instance;
}
var WeekDay_MONDAY_instance;
var WeekDay_TUESDAY_instance;
var WeekDay_WEDNESDAY_instance;
var WeekDay_THURSDAY_instance;
var WeekDay_FRIDAY_instance;
var WeekDay_SATURDAY_instance;
var WeekDay_SUNDAY_instance;
var Companion_instance_1;
function Companion_getInstance_0() {
  return Companion_instance_1;
}
function values() {
  return [WeekDay_MONDAY_getInstance(), WeekDay_TUESDAY_getInstance(), WeekDay_WEDNESDAY_getInstance(), WeekDay_THURSDAY_getInstance(), WeekDay_FRIDAY_getInstance(), WeekDay_SATURDAY_getInstance(), WeekDay_SUNDAY_getInstance()];
}
function get_entries() {
  if ($ENTRIES == null)
    $ENTRIES = enumEntries(values());
  return $ENTRIES;
}
var WeekDay_entriesInitialized;
function WeekDay_initEntries() {
  if (WeekDay_entriesInitialized)
    return Unit_instance;
  WeekDay_entriesInitialized = true;
  WeekDay_MONDAY_instance = new WeekDay('MONDAY', 0, 'Mon');
  WeekDay_TUESDAY_instance = new WeekDay('TUESDAY', 1, 'Tue');
  WeekDay_WEDNESDAY_instance = new WeekDay('WEDNESDAY', 2, 'Wed');
  WeekDay_THURSDAY_instance = new WeekDay('THURSDAY', 3, 'Thu');
  WeekDay_FRIDAY_instance = new WeekDay('FRIDAY', 4, 'Fri');
  WeekDay_SATURDAY_instance = new WeekDay('SATURDAY', 5, 'Sat');
  WeekDay_SUNDAY_instance = new WeekDay('SUNDAY', 6, 'Sun');
}
var $ENTRIES;
var Month_JANUARY_instance;
var Month_FEBRUARY_instance;
var Month_MARCH_instance;
var Month_APRIL_instance;
var Month_MAY_instance;
var Month_JUNE_instance;
var Month_JULY_instance;
var Month_AUGUST_instance;
var Month_SEPTEMBER_instance;
var Month_OCTOBER_instance;
var Month_NOVEMBER_instance;
var Month_DECEMBER_instance;
var Companion_instance_2;
function Companion_getInstance_1() {
  return Companion_instance_2;
}
function values_0() {
  return [Month_JANUARY_getInstance(), Month_FEBRUARY_getInstance(), Month_MARCH_getInstance(), Month_APRIL_getInstance(), Month_MAY_getInstance(), Month_JUNE_getInstance(), Month_JULY_getInstance(), Month_AUGUST_getInstance(), Month_SEPTEMBER_getInstance(), Month_OCTOBER_getInstance(), Month_NOVEMBER_getInstance(), Month_DECEMBER_getInstance()];
}
function get_entries_0() {
  if ($ENTRIES_0 == null)
    $ENTRIES_0 = enumEntries(values_0());
  return $ENTRIES_0;
}
var Month_entriesInitialized;
function Month_initEntries() {
  if (Month_entriesInitialized)
    return Unit_instance;
  Month_entriesInitialized = true;
  Month_JANUARY_instance = new Month('JANUARY', 0, 'Jan');
  Month_FEBRUARY_instance = new Month('FEBRUARY', 1, 'Feb');
  Month_MARCH_instance = new Month('MARCH', 2, 'Mar');
  Month_APRIL_instance = new Month('APRIL', 3, 'Apr');
  Month_MAY_instance = new Month('MAY', 4, 'May');
  Month_JUNE_instance = new Month('JUNE', 5, 'Jun');
  Month_JULY_instance = new Month('JULY', 6, 'Jul');
  Month_AUGUST_instance = new Month('AUGUST', 7, 'Aug');
  Month_SEPTEMBER_instance = new Month('SEPTEMBER', 8, 'Sep');
  Month_OCTOBER_instance = new Month('OCTOBER', 9, 'Oct');
  Month_NOVEMBER_instance = new Month('NOVEMBER', 10, 'Nov');
  Month_DECEMBER_instance = new Month('DECEMBER', 11, 'Dec');
}
var $ENTRIES_0;
function WeekDay_MONDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_MONDAY_instance;
}
function WeekDay_TUESDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_TUESDAY_instance;
}
function WeekDay_WEDNESDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_WEDNESDAY_instance;
}
function WeekDay_THURSDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_THURSDAY_instance;
}
function WeekDay_FRIDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_FRIDAY_instance;
}
function WeekDay_SATURDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_SATURDAY_instance;
}
function WeekDay_SUNDAY_getInstance() {
  WeekDay_initEntries();
  return WeekDay_SUNDAY_instance;
}
function Month_JANUARY_getInstance() {
  Month_initEntries();
  return Month_JANUARY_instance;
}
function Month_FEBRUARY_getInstance() {
  Month_initEntries();
  return Month_FEBRUARY_instance;
}
function Month_MARCH_getInstance() {
  Month_initEntries();
  return Month_MARCH_instance;
}
function Month_APRIL_getInstance() {
  Month_initEntries();
  return Month_APRIL_instance;
}
function Month_MAY_getInstance() {
  Month_initEntries();
  return Month_MAY_instance;
}
function Month_JUNE_getInstance() {
  Month_initEntries();
  return Month_JUNE_instance;
}
function Month_JULY_getInstance() {
  Month_initEntries();
  return Month_JULY_instance;
}
function Month_AUGUST_getInstance() {
  Month_initEntries();
  return Month_AUGUST_instance;
}
function Month_SEPTEMBER_getInstance() {
  Month_initEntries();
  return Month_SEPTEMBER_instance;
}
function Month_OCTOBER_getInstance() {
  Month_initEntries();
  return Month_OCTOBER_instance;
}
function Month_NOVEMBER_getInstance() {
  Month_initEntries();
  return Month_NOVEMBER_instance;
}
function Month_DECEMBER_getInstance() {
  Month_initEntries();
  return Month_DECEMBER_instance;
}
var CONDITION_FALSE;
var ALREADY_REMOVED;
var LIST_EMPTY;
var REMOVE_PREPARED;
var NO_DECISION;
function unwrap(_this__u8e3s4) {
  _init_properties_LockFreeLinkedList_kt__wekxce();
  var tmp0_safe_receiver = _this__u8e3s4 instanceof Removed ? _this__u8e3s4 : null;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.p2j_1;
  var tmp;
  if (tmp1_elvis_lhs == null) {
    tmp = _this__u8e3s4 instanceof LockFreeLinkedListNode ? _this__u8e3s4 : THROW_CCE();
  } else {
    tmp = tmp1_elvis_lhs;
  }
  return tmp;
}
var properties_initialized_LockFreeLinkedList_kt_lnmdgw;
function _init_properties_LockFreeLinkedList_kt__wekxce() {
  if (!properties_initialized_LockFreeLinkedList_kt_lnmdgw) {
    properties_initialized_LockFreeLinkedList_kt_lnmdgw = true;
    CONDITION_FALSE = new Symbol('CONDITION_FALSE');
    ALREADY_REMOVED = new Symbol('ALREADY_REMOVED');
    LIST_EMPTY = new Symbol('LIST_EMPTY');
    REMOVE_PREPARED = new Symbol('REMOVE_PREPARED');
    NO_DECISION = new Symbol('NO_DECISION');
  }
}
function *_generator_proceedLoop__sfimma($this, $completion) {
  $l$loop_0: do {
    var index = $this.u2j_1;
    if (index === -1) {
      break $l$loop_0;
    }
    var interceptors = $this.r2j_1;
    if (index >= interceptors.b1()) {
      $this.v2j();
      break $l$loop_0;
    }
    var executeInterceptor = interceptors.f1(index);
    $this.u2j_1 = index + 1 | 0;
    var tmp = executeInterceptor($this, $this.t2j_1, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }
   while (true);
  return $this.t2j_1;
}
function proceedLoop($this, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_proceedLoop__sfimma.bind(VOID, $this), $completion);
}
function copiedInterceptors($this) {
  return toMutableList($this.c2k_1);
}
function copyInterceptors($this) {
  $this.c2k_1 = copiedInterceptors($this);
  $this.d2k_1 = false;
}
var Companion_instance_3;
function Companion_getInstance_2() {
  if (Companion_instance_3 === VOID)
    new Companion_2();
  return Companion_instance_3;
}
function _set_interceptors__wod97b($this, _set____db54di) {
  var tmp0 = $this.q2k_1;
  // Inline function 'kotlinx.atomicfu.AtomicRef.setValue' call
  interceptors$factory();
  tmp0.kotlinx$atomicfu$value = _set____db54di;
  return Unit_instance;
}
function _get_interceptors__h4min7($this) {
  var tmp0 = $this.q2k_1;
  // Inline function 'kotlinx.atomicfu.AtomicRef.getValue' call
  interceptors$factory_0();
  return tmp0.kotlinx$atomicfu$value;
}
function createContext($this, context, subject, coroutineContext) {
  return pipelineContextFor(context, sharedInterceptorsList($this), subject, coroutineContext, $this.t2k());
}
function findPhase($this, phase) {
  var phasesList = $this.o2k_1;
  var inductionVariable = 0;
  var last = phasesList.b1();
  if (inductionVariable < last)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var current = phasesList.f1(index);
      if (current === phase) {
        var content = PhaseContent.g2k(phase, Last_getInstance());
        phasesList.c3(index, content);
        return content;
      }
      var tmp;
      if (current instanceof PhaseContent) {
        tmp = current.a2k_1 === phase;
      } else {
        tmp = false;
      }
      if (tmp) {
        return current instanceof PhaseContent ? current : THROW_CCE();
      }
    }
     while (inductionVariable < last);
  return null;
}
function findPhaseIndex($this, phase) {
  var phasesList = $this.o2k_1;
  var inductionVariable = 0;
  var last = phasesList.b1();
  if (inductionVariable < last)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var current = phasesList.f1(index);
      var tmp;
      if (current === phase) {
        tmp = true;
      } else {
        var tmp_0;
        if (current instanceof PhaseContent) {
          tmp_0 = current.a2k_1 === phase;
        } else {
          tmp_0 = false;
        }
        tmp = tmp_0;
      }
      if (tmp) {
        return index;
      }
    }
     while (inductionVariable < last);
  return -1;
}
function hasPhase($this, phase) {
  var phasesList = $this.o2k_1;
  var inductionVariable = 0;
  var last = phasesList.b1();
  if (inductionVariable < last)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      var current = phasesList.f1(index);
      var tmp;
      if (current === phase) {
        tmp = true;
      } else {
        var tmp_0;
        if (current instanceof PhaseContent) {
          tmp_0 = current.a2k_1 === phase;
        } else {
          tmp_0 = false;
        }
        tmp = tmp_0;
      }
      if (tmp) {
        return true;
      }
    }
     while (inductionVariable < last);
  return false;
}
function cacheInterceptors($this) {
  var interceptorsQuantity = $this.p2k_1;
  if (interceptorsQuantity === 0) {
    notSharedInterceptorsList($this, emptyList());
    return emptyList();
  }
  var phases = $this.o2k_1;
  if (interceptorsQuantity === 1) {
    var inductionVariable = 0;
    var last = get_lastIndex_0(phases);
    if (inductionVariable <= last)
      $l$loop_0: do {
        var phaseIndex = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var tmp = phases.f1(phaseIndex);
        var tmp0_elvis_lhs = tmp instanceof PhaseContent ? tmp : null;
        var tmp_0;
        if (tmp0_elvis_lhs == null) {
          continue $l$loop_0;
        } else {
          tmp_0 = tmp0_elvis_lhs;
        }
        var phaseContent = tmp_0;
        if (phaseContent.h2k())
          continue $l$loop_0;
        var interceptors = phaseContent.k2k();
        setInterceptorsListFromPhase($this, phaseContent);
        return interceptors;
      }
       while (!(phaseIndex === last));
  }
  // Inline function 'kotlin.collections.mutableListOf' call
  var destination = ArrayList.k();
  var inductionVariable_0 = 0;
  var last_0 = get_lastIndex_0(phases);
  if (inductionVariable_0 <= last_0)
    $l$loop_1: do {
      var phaseIndex_0 = inductionVariable_0;
      inductionVariable_0 = inductionVariable_0 + 1 | 0;
      var tmp_1 = phases.f1(phaseIndex_0);
      var tmp1_elvis_lhs = tmp_1 instanceof PhaseContent ? tmp_1 : null;
      var tmp_2;
      if (tmp1_elvis_lhs == null) {
        continue $l$loop_1;
      } else {
        tmp_2 = tmp1_elvis_lhs;
      }
      var phase = tmp_2;
      phase.j2k(destination);
    }
     while (!(phaseIndex_0 === last_0));
  notSharedInterceptorsList($this, destination);
  return destination;
}
function sharedInterceptorsList($this) {
  if (_get_interceptors__h4min7($this) == null) {
    cacheInterceptors($this);
  }
  $this.r2k_1 = true;
  return ensureNotNull(_get_interceptors__h4min7($this));
}
function resetInterceptorsList($this) {
  _set_interceptors__wod97b($this, null);
  $this.r2k_1 = false;
  $this.s2k_1 = null;
}
function notSharedInterceptorsList($this, list) {
  _set_interceptors__wod97b($this, list);
  $this.r2k_1 = false;
  $this.s2k_1 = null;
}
function setInterceptorsListFromPhase($this, phaseContent) {
  _set_interceptors__wod97b($this, phaseContent.k2k());
  $this.r2k_1 = false;
  $this.s2k_1 = phaseContent.a2k_1;
}
function tryAddToPhaseFastPath($this, phase, block) {
  var currentInterceptors = _get_interceptors__h4min7($this);
  if ($this.o2k_1.h1() || currentInterceptors == null) {
    return false;
  }
  var tmp;
  if ($this.r2k_1) {
    tmp = true;
  } else {
    tmp = !(!(currentInterceptors == null) ? isInterface(currentInterceptors, KtMutableList) : false);
  }
  if (tmp) {
    return false;
  }
  if (equals($this.s2k_1, phase)) {
    currentInterceptors.l(block);
    return true;
  }
  if (equals(phase, last($this.o2k_1)) || findPhaseIndex($this, phase) === get_lastIndex_0($this.o2k_1)) {
    ensureNotNull(findPhase($this, phase)).i2k(block);
    currentInterceptors.l(block);
    return true;
  }
  return false;
}
function interceptors$factory() {
  return getPropertyCallableRef('interceptors', 1, KMutableProperty1, (receiver) => _get_interceptors__h4min7(receiver), (receiver, value) => _set_interceptors__wod97b(receiver, value));
}
function interceptors$factory_0() {
  return getPropertyCallableRef('interceptors', 1, KMutableProperty1, (receiver) => _get_interceptors__h4min7(receiver), (receiver, value) => _set_interceptors__wod97b(receiver, value));
}
function pipelineContextFor(context, interceptors, subject, coroutineContext, debugMode) {
  debugMode = debugMode === VOID ? false : debugMode;
  var tmp;
  if (get_DISABLE_SFG() || debugMode) {
    tmp = new DebugPipelineContext(context, interceptors, subject, coroutineContext);
  } else {
    tmp = new SuspendFunctionGun(subject, context, interceptors);
  }
  return tmp;
}
var Last_instance;
function Last_getInstance() {
  if (Last_instance === VOID)
    new Last();
  return Last_instance;
}
function recoverStackTraceBridge(exception, continuation) {
  var tmp;
  try {
    tmp = withCause(recoverStackTrace(exception, continuation), exception.cause);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var _unused_var__etf5q3 = $p;
      tmp_0 = exception;
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  return tmp;
}
function loop($this, direct) {
  do {
    var currentIndex = $this.k2l_1;
    if (currentIndex === $this.f2l_1.b1()) {
      if (!direct) {
        // Inline function 'kotlin.Companion.success' call
        var value = $this.h2l_1;
        var tmp$ret$0 = _Result___init__impl__xyqfz8(value);
        resumeRootWith($this, tmp$ret$0);
        return false;
      }
      return true;
    }
    $this.k2l_1 = currentIndex + 1 | 0;
    var next = $this.f2l_1.f1(currentIndex);
    try {
      var result = pipelineStartCoroutineUninterceptedOrReturn(next, $this, $this.h2l_1, $this.g2l_1);
      if (result === get_COROUTINE_SUSPENDED())
        return false;
    } catch ($p) {
      if ($p instanceof Error) {
        var cause = $p;
        // Inline function 'kotlin.Companion.failure' call
        var tmp$ret$1 = _Result___init__impl__xyqfz8(createFailure(cause));
        resumeRootWith($this, tmp$ret$1);
        return false;
      } else {
        throw $p;
      }
    }
  }
   while (true);
}
function resumeRootWith($this, result) {
  if ($this.j2l_1 < 0) {
    // Inline function 'kotlin.error' call
    var message = 'No more continuations to resume';
    throw IllegalStateException.t4(toString(message));
  }
  var next = ensureNotNull($this.i2l_1[$this.j2l_1]);
  var _unary__edvuaz = $this.j2l_1;
  $this.j2l_1 = _unary__edvuaz - 1 | 0;
  $this.i2l_1[_unary__edvuaz] = null;
  if (!_Result___get_isFailure__impl__jpiriv(result)) {
    next.nc(result);
  } else {
    var exception = recoverStackTraceBridge(ensureNotNull(Result__exceptionOrNull_impl_p6xea9(result)), next);
    // Inline function 'kotlin.coroutines.resumeWithException' call
    // Inline function 'kotlin.Companion.failure' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception));
    next.nc(tmp$ret$0);
  }
}
function discardLastRootContinuation($this) {
  if ($this.j2l_1 < 0)
    throw IllegalStateException.t4('No more continuations to resume');
  var _unary__edvuaz = $this.j2l_1;
  $this.j2l_1 = _unary__edvuaz - 1 | 0;
  $this.i2l_1[_unary__edvuaz] = null;
}
function get_platform(_this__u8e3s4) {
  _init_properties_PlatformUtils_js_kt__7rxm8p();
  var tmp0 = platform$delegate;
  // Inline function 'kotlin.getValue' call
  platform$factory();
  return tmp0.n1();
}
var platform$delegate;
function platform$delegate$lambda() {
  _init_properties_PlatformUtils_js_kt__7rxm8p();
  return new Js(hasNodeApi() ? JsPlatform_Node_getInstance() : JsPlatform_Browser_getInstance());
}
function platform$factory() {
  return getPropertyCallableRef('platform', 1, KProperty1, (receiver) => get_platform(receiver), null);
}
var properties_initialized_PlatformUtils_js_kt_8g036j;
function _init_properties_PlatformUtils_js_kt__7rxm8p() {
  if (!properties_initialized_PlatformUtils_js_kt_8g036j) {
    properties_initialized_PlatformUtils_js_kt_8g036j = true;
    platform$delegate = lazy_0(platform$delegate$lambda);
  }
}
function GMTDate_0(timestamp) {
  timestamp = timestamp === VOID ? null : timestamp;
  var tmp1_safe_receiver = timestamp == null ? null : timestamp.m4();
  var tmp;
  if (tmp1_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = new Date(tmp1_safe_receiver);
  }
  var tmp2_elvis_lhs = tmp;
  var date = tmp2_elvis_lhs == null ? new Date() : tmp2_elvis_lhs;
  if (isNaN_0(date.getTime()))
    throw InvalidTimestampException.u2l(ensureNotNull(timestamp));
  // Inline function 'kotlin.with' call
  var dayOfWeek = Companion_instance_1.e2j((date.getUTCDay() + 6 | 0) % 7 | 0);
  var month = Companion_instance_2.e2j(date.getUTCMonth());
  return new GMTDate(date.getUTCSeconds(), date.getUTCMinutes(), date.getUTCHours(), dayOfWeek, date.getUTCDate(), date.getUTCFullYear(), month, date.getUTCFullYear(), numberToLong(date.getTime()));
}
function pipelineStartCoroutineUninterceptedOrReturn(interceptor, context, subject, continuation) {
  return (typeof interceptor === 'function' ? interceptor : THROW_CCE())(context, subject, continuation);
}
function AttributesJsFn(concurrent) {
  concurrent = concurrent === VOID ? false : concurrent;
  return new AttributesJs();
}
function unmodifiable(_this__u8e3s4) {
  return _this__u8e3s4;
}
function hasNodeApi() {
  return typeof process !== 'undefined' && process.versions != null && process.versions.node != null || (typeof window !== 'undefined' && typeof window.process !== 'undefined' && window.process.versions != null && window.process.versions.node != null);
}
function get_isDevelopmentMode(_this__u8e3s4) {
  return false;
}
function KtorSimpleLogger(name) {
  return new KtorSimpleLogger$1();
}
function getKtorLogLevel() {
  return process ? process.env.KTOR_LOG_LEVEL : null;
}
var LogLevel_TRACE_instance;
var LogLevel_DEBUG_instance;
var LogLevel_INFO_instance;
var LogLevel_WARN_instance;
var LogLevel_ERROR_instance;
var LogLevel_NONE_instance;
function values_1() {
  return [LogLevel_TRACE_getInstance(), LogLevel_DEBUG_getInstance(), LogLevel_INFO_getInstance(), LogLevel_WARN_getInstance(), LogLevel_ERROR_getInstance(), LogLevel_NONE_getInstance()];
}
function get_entries_1() {
  if ($ENTRIES_1 == null)
    $ENTRIES_1 = enumEntries(values_1());
  return $ENTRIES_1;
}
var LogLevel_entriesInitialized;
function LogLevel_initEntries() {
  if (LogLevel_entriesInitialized)
    return Unit_instance;
  LogLevel_entriesInitialized = true;
  LogLevel_TRACE_instance = new LogLevel('TRACE', 0);
  LogLevel_DEBUG_instance = new LogLevel('DEBUG', 1);
  LogLevel_INFO_instance = new LogLevel('INFO', 2);
  LogLevel_WARN_instance = new LogLevel('WARN', 3);
  LogLevel_ERROR_instance = new LogLevel('ERROR', 4);
  LogLevel_NONE_instance = new LogLevel('NONE', 5);
}
var $ENTRIES_1;
function get_isTraceEnabled(_this__u8e3s4) {
  return _this__u8e3s4.x2l().p3(LogLevel_TRACE_getInstance()) <= 0;
}
function LogLevel_TRACE_getInstance() {
  LogLevel_initEntries();
  return LogLevel_TRACE_instance;
}
function LogLevel_DEBUG_getInstance() {
  LogLevel_initEntries();
  return LogLevel_DEBUG_instance;
}
function LogLevel_INFO_getInstance() {
  LogLevel_initEntries();
  return LogLevel_INFO_instance;
}
function LogLevel_WARN_getInstance() {
  LogLevel_initEntries();
  return LogLevel_WARN_instance;
}
function LogLevel_ERROR_getInstance() {
  LogLevel_initEntries();
  return LogLevel_ERROR_instance;
}
function LogLevel_NONE_getInstance() {
  LogLevel_initEntries();
  return LogLevel_NONE_instance;
}
function get_DISABLE_SFG() {
  return DISABLE_SFG;
}
var DISABLE_SFG;
function withCause(_this__u8e3s4, cause) {
  return _this__u8e3s4;
}
function instanceOf(_this__u8e3s4, type) {
  return type.if(_this__u8e3s4);
}
//region block: post-declaration
initMetadataForClass(AttributeKey, 'AttributeKey');
initMetadataForInterface(Attributes, 'Attributes');
initMetadataForClass(CaseInsensitiveMap, 'CaseInsensitiveMap', CaseInsensitiveMap, VOID, [KtMutableMap]);
initMetadataForClass(Entry_0, 'Entry', VOID, VOID, [Entry]);
initMetadataForClass(SilentSupervisor$$inlined$CoroutineExceptionHandler$1, VOID, VOID, VOID, [AbstractCoroutineContextElement, Element]);
initMetadataForClass(DelegatingMutableSet$iterator$1);
initMetadataForClass(DelegatingMutableSet, 'DelegatingMutableSet', VOID, VOID, [KtMutableSet]);
initMetadataForClass(Platform, 'Platform');
initMetadataForObject(Jvm, 'Jvm');
initMetadataForObject(Native, 'Native');
initMetadataForClass(Js, 'Js');
initMetadataForClass(WasmJs, 'WasmJs');
initMetadataForClass(JsPlatform, 'JsPlatform');
initMetadataForObject(PlatformUtils, 'PlatformUtils');
initMetadataForInterface(StringValues, 'StringValues');
initMetadataForClass(StringValuesBuilderImpl, 'StringValuesBuilderImpl', StringValuesBuilderImpl);
initMetadataForClass(StringValuesImpl, 'StringValuesImpl', StringValuesImpl, VOID, [StringValues]);
initMetadataForClass(StringValuesSingleImpl$entries$1, VOID, VOID, VOID, [Entry]);
initMetadataForClass(StringValuesSingleImpl, 'StringValuesSingleImpl', VOID, VOID, [StringValues]);
initMetadataForClass(CaseInsensitiveString, 'CaseInsensitiveString');
initMetadataForClass(CopyOnWriteHashMap, 'CopyOnWriteHashMap', CopyOnWriteHashMap);
initMetadataForCompanion(Companion);
protoOf($serializer).k26 = typeParametersSerializers;
initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(GMTDate, 'GMTDate', VOID, VOID, [Comparable], VOID, VOID, {0: $serializer_getInstance});
initMetadataForCompanion(Companion_0);
initMetadataForClass(WeekDay, 'WeekDay');
initMetadataForCompanion(Companion_1);
initMetadataForClass(Month, 'Month');
initMetadataForClass(Symbol, 'Symbol');
initMetadataForClass(LockFreeLinkedListNode, 'LockFreeLinkedListNode');
initMetadataForClass(Removed, 'Removed');
initMetadataForClass(OpDescriptor, 'OpDescriptor');
initMetadataForClass(PipelineContext, 'PipelineContext', VOID, VOID, [CoroutineScope], [1, 0]);
initMetadataForClass(DebugPipelineContext, 'DebugPipelineContext', VOID, VOID, VOID, [1, 0]);
initMetadataForCompanion(Companion_2);
initMetadataForClass(PhaseContent, 'PhaseContent');
initMetadataForClass(Pipeline, 'Pipeline', VOID, VOID, VOID, [2]);
initMetadataForClass(PipelinePhase, 'PipelinePhase');
initMetadataForClass(InvalidPhaseException, 'InvalidPhaseException');
initMetadataForClass(PipelinePhaseRelation, 'PipelinePhaseRelation');
initMetadataForClass(After, 'After');
initMetadataForClass(Before, 'Before');
initMetadataForObject(Last, 'Last');
initMetadataForClass(SuspendFunctionGun$continuation$1, VOID, VOID, VOID, [Continuation]);
initMetadataForClass(SuspendFunctionGun, 'SuspendFunctionGun', VOID, VOID, VOID, [0, 1]);
initMetadataForClass(TypeInfo, 'TypeInfo');
initMetadataForClass(InvalidTimestampException, 'InvalidTimestampException');
protoOf(AttributesJs).a2g = get;
initMetadataForClass(AttributesJs, 'AttributesJs', AttributesJs, VOID, [Attributes]);
initMetadataForClass(KtorSimpleLogger$1);
initMetadataForClass(LogLevel, 'LogLevel');
//endregion
//region block: init
Companion_instance_1 = new Companion_0();
Companion_instance_2 = new Companion_1();
DISABLE_SFG = false;
//endregion
//region block: exports
export {
  PlatformUtils_getInstance as PlatformUtils_getInstance3trl22jwg7wgb,
  CopyOnWriteHashMap as CopyOnWriteHashMap2wz01l72sexe7,
  GMTDate_0 as GMTDate36bhedawynxlf,
  LockFreeLinkedListNode as LockFreeLinkedListNode1f5fxflchw0ko,
  KtorSimpleLogger as KtorSimpleLogger1xdphsp5l4e48,
  get_isTraceEnabled as get_isTraceEnabled82xibuu04nxp,
  PipelineContext as PipelineContext34fsb0mycu471,
  PipelinePhase as PipelinePhase2q3d54imxjlma,
  Pipeline as Pipeline2vw6c5wpzxajt,
  TypeInfo as TypeInfo2nbxsuf4v8os2,
  instanceOf as instanceOf2cx3k00nj6a0p,
  AttributeKey as AttributeKey3aq8ytwgx54f7,
  AttributesJsFn as AttributesJsFn25rjfgcprgprf,
  Attributes as Attributes2dg90yv0ot9wx,
  SilentSupervisor as SilentSupervisorlzoikirj0zeo,
  forEach as forEachghjt92rkrpzo,
  get_0 as get3oezx9z3zutmm,
  StringValuesBuilderImpl as StringValuesBuilderImpl3ey9etj3bwnqf,
  StringValuesImpl as StringValuesImpl2l95y9du7b61t,
  StringValuesSingleImpl as StringValuesSingleImpl1uh7q2c2zm7va,
  StringValues as StringValuesjqid5a6cuday,
  appendAll as appendAlltwnjnu28pmtx,
  isLowerCase as isLowerCase2jodys5jo7d58,
  putAll as putAll10o0q8e6mgnzr,
  toCharArray as toCharArray1qby3f4cdahde,
  toLowerCasePreservingASCIIRules as toLowerCasePreservingASCIIRulesa2d90zyoc6kw,
};
//endregion

//# sourceMappingURL=ktor-ktor-utils.mjs.map
