import {
  ChatModel1ekuxcd3gk3yy as ChatModel,
  Support_Unsupported_getInstance2l560r5zg87nd as Support_Unsupported_getInstance,
  Support_Supported_getInstance2iy50h3ebt6qe as Support_Supported_getInstance,
  ModelCapabilities1z2n3zkdibnvb as ModelCapabilities,
  JsonUtil_getInstance3itlrleq4m1cs as JsonUtil_getInstance,
  HttpMethod_POST_getInstance2vunzl2e30rwd as HttpMethod_POST_getInstance,
  authHeaders3pbiyo76b6dd9 as authHeaders,
  Framing_Sse_getInstance1id84wnv2jikt as Framing_Sse_getInstance,
  timeoutsvuf8aepeqg28 as timeouts,
  WireCall3namx761k5vmg as WireCall,
  Message1x6kaj8ypdoee as Message,
  Role_SYSTEM_getInstance3m9lasmspf7k5 as Role_SYSTEM_getInstance,
  ReasoningSummary2dl0lxzty5z0 as ReasoningSummary,
  ProviderItem17hp0vuxmlwze as ProviderItem,
  ToolCall27jatgdodcelb as ToolCall,
  Texttoggh19xftus as Text,
  Role_USER_getInstance1gsro7tt6a7i2 as Role_USER_getInstance,
  ToolResult2fndzcq38kgpy as ToolResult,
  Companion_getInstance3ot1bqjky10hu as Companion_getInstance,
  rawFor3526oyw9fazp7 as rawFor,
  _ItemRef___get_value__impl__fpjuyb3vqbahagzpip9 as _ItemRef___get_value__impl__fpjuyb,
  Role_ASSISTANT_getInstance3m8z8upy020dy as Role_ASSISTANT_getInstance,
  ensureDroppable3mu5lhcnsp146 as ensureDroppable,
  AgentFrameworkException23juzeg1t595u as AgentFrameworkException,
  PreparationError1mrn3vyzs5xe4 as PreparationError,
  Header291p2k6if4y3m as Header,
  ModelConfig4o28u6uqe7xk as ModelConfig,
  Support_Unknown_getInstance3blv79i14mlk4 as Support_Unknown_getInstance,
  Companion_instance13097inxmcdi as Companion_instance,
  Usage3sdv1daz6y20z as Usage,
  Failed2mkg32d93x5tt as Failed,
  Finished4z9e5g7v1wyk as Finished,
  ModelErrori9ofbqyilwwf as ModelError,
  HttpError1wj82nej166el as HttpError,
  Ndjson1kkk3x9modr28 as Ndjson,
  Body2ccosqk3y8ycb as Body,
  Sset7uvtqde4kyu as Sse,
  Started1sf5a44qjgp0u as Started,
  TextDeltaq9h7728thclc as TextDelta,
  ReasoningDeltaytmmln995w27 as ReasoningDelta,
  ToolCallDelta1owom9vbem28s as ToolCallDelta,
  ReplayPolicy_Required_getInstance1o7kby0tmyj43 as ReplayPolicy_Required_getInstance,
  ItemAddede8lfykdsw28t as ItemAdded,
  Companion_instancelgypg95btxw8 as Companion_instance_0,
  ProviderScopedId2kn7so5x8kdlf as ProviderScopedId,
  ToolCallsfyoaxshhyk as ToolCall_0,
  ToolCallCompleted225u0jsfjmco7 as ToolCallCompleted,
  Completedf7bahq5rqxjz as Completed,
} from './koaks-core.mjs';
import {
  VOID7hggqo3abtya as VOID,
  listOfNotNull1v4ggfackvuny as listOfNotNull,
  ArrayList3it5z8td81qkl as ArrayList,
  Unit_instance104q5opgivhr8 as Unit_instance,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  plus310ted5e4i90h as plus,
  joinToString1cxrrlmo0chqs as joinToString,
  isBlank1dvkhjjvox3p0 as isBlank,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  toString30pk9tzaqopn as toString,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  equals2au1ep9vhcato as equals,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  Companion_instance3fplhgf4ipvld as Companion_instance_1,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  toString1pkumu07cwy4m as toString_0,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  createThis2j2avj17cvnv2 as createThis,
  getKClass1s3j9wy1cofik as getKClass,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  Long2qws0ah9gnpki as Long,
  to2cs3ny02qtbcb as to,
  mapOf2zpbbmyqk8xpf as mapOf,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  trimEndvvzjdhan75g as trimEnd,
  endsWith3cq61xxngobwh as endsWith,
  StringBuildermazzzhj6kkai as StringBuilder,
  emptyList1g2z5xcrvp2zy as emptyList,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  listOfvhqybd2zx248 as listOf,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  isInterface3d6p8outrmvmk as isInterface,
  Comparator2b3maoeh98xtg as Comparator,
  compareValues1n2ayl87ihzfk as compareValues,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  sortedWith2csnbbb21k0lg as sortedWith,
  toList3jhuyej2anx2q as toList,
} from './kotlin-kotlin-stdlib.mjs';
import {
  ArrayListSerializer7k5wnrulb3y6 as ArrayListSerializer,
  StringSerializer_getInstance1k1oz5j50sfik as StringSerializer_getInstance,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  DoubleSerializer_getInstance2avi1jm48x8le as DoubleSerializer_getInstance,
  IntSerializer_getInstance9scrtcljaiv6 as IntSerializer_getInstance,
  UnknownFieldExceptiona60e3a6v1xqo as UnknownFieldException,
  get_nullable197rfua9r7fsz as get_nullable,
  BooleanSerializer_getInstancet3wtk7fl7i4f as BooleanSerializer_getInstance,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
  SealedClassSerializeriwipiibk55zc as SealedClassSerializer,
  SerializerFactory1qv9hivitncuv as SerializerFactory,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
import {
  JsonObjectSerializer_getInstance197qdg6ernwdp as JsonObjectSerializer_getInstance,
  JsonElementSerializer_getInstance1rgo1giz8g15y as JsonElementSerializer_getInstance,
} from './kotlinx-serialization-kotlinx-serialization-json.mjs';
import { Companion_getInstance3n3majy04gpy as Companion_getInstance_0 } from './okio-parent-okio.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class AnthropicChatModel extends ChatModel {
  constructor(config, transport, params, capabilities) {
    params = params === VOID ? new AnthropicParams() : params;
    capabilities = capabilities === VOID ? new ModelCapabilities(VOID, VOID, Support_Unsupported_getInstance(), VOID, Support_Supported_getInstance()) : capabilities;
    super(config, transport);
    this.c7p_1 = params;
    this.d7p_1 = capabilities;
  }
  a5p() {
    return this.d7p_1;
  }
  y1s() {
    return new AnthropicWireDecoder();
  }
  j6g(req) {
    var body = JsonUtil_getInstance().d6f(this.e7p(req), Companion_getInstance_1().r3o());
    return new WireCall(HttpMethod_POST_getInstance(), this.c6g_1.n6g_1, authHeaders(this.c6g_1), body, Framing_Sse_getInstance(), req.g5y_1, timeouts(this.c6g_1), this.c6g_1.w6g_1, this.c6g_1.x6g_1);
  }
  e7p(req) {
    var tmp = listOfNotNull(req.b5y_1);
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = req.c5y_1;
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element instanceof Message) {
        destination.l(element);
      }
    }
    // Inline function 'kotlin.collections.filter' call
    // Inline function 'kotlin.collections.filterTo' call
    var destination_0 = ArrayList.k();
    var _iterator__ex2g4s_0 = destination.y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      if (element_0.r5o_1.equals(Role_SYSTEM_getInstance())) {
        destination_0.l(element_0);
      }
    }
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_1 = ArrayList.x(collectionSizeOrDefault(destination_0, 10));
    var _iterator__ex2g4s_1 = destination_0.y();
    while (_iterator__ex2g4s_1.z()) {
      var item = _iterator__ex2g4s_1.a1();
      var tmp$ret$5 = item.m5t();
      destination_1.l(tmp$ret$5);
    }
    // Inline function 'kotlin.text.ifBlank' call
    var this_0 = joinToString(plus(tmp, destination_1), '\n');
    var tmp_0;
    if (isBlank(this_0)) {
      tmp_0 = null;
    } else {
      tmp_0 = this_0;
    }
    var system = tmp_0;
    var tmp_1 = toAnthropicMessages(req.c5y_1);
    // Inline function 'kotlin.takeIf' call
    var this_1 = req.d5y_1;
    var tmp_2;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this_1.h1()) {
      tmp_2 = this_1;
    } else {
      tmp_2 = null;
    }
    var tmp0_safe_receiver = tmp_2;
    var tmp_3;
    if (tmp0_safe_receiver == null) {
      tmp_3 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination_2 = ArrayList.x(collectionSizeOrDefault(tmp0_safe_receiver, 10));
      var _iterator__ex2g4s_2 = tmp0_safe_receiver.y();
      while (_iterator__ex2g4s_2.z()) {
        var item_0 = _iterator__ex2g4s_2.a1();
        var tmp$ret$13 = new AnthropicTool(item_0.c6k_1, item_0.d6k_1, item_0.e6k_1);
        destination_2.l(tmp$ret$13);
      }
      tmp_3 = destination_2;
    }
    return new AnthropicChatRequest(this.c6g_1.p6g_1, this.c7p_1.g7p_1, tmp_1, system, tmp_3, true, this.c7p_1.h7p_1, this.c7p_1.i7p_1, this.c7p_1.j7p_1, this.c7p_1.k7p_1, this.c7p_1.l7p_1);
  }
}
class AnthropicParams {
  constructor(maxTokens, temperature, topP, topK, stopSequences, thinking) {
    maxTokens = maxTokens === VOID ? 4096 : maxTokens;
    temperature = temperature === VOID ? null : temperature;
    topP = topP === VOID ? null : topP;
    topK = topK === VOID ? null : topK;
    stopSequences = stopSequences === VOID ? null : stopSequences;
    thinking = thinking === VOID ? null : thinking;
    this.g7p_1 = maxTokens;
    this.h7p_1 = temperature;
    this.i7p_1 = topP;
    this.j7p_1 = topK;
    this.k7p_1 = stopSequences;
    this.l7p_1 = thinking;
  }
  toString() {
    return 'AnthropicParams(maxTokens=' + this.g7p_1 + ', temperature=' + this.h7p_1 + ', topP=' + this.i7p_1 + ', topK=' + this.j7p_1 + ', stopSequences=' + toString(this.k7p_1) + ', thinking=' + toString(this.l7p_1) + ')';
  }
  hashCode() {
    var result = this.g7p_1;
    result = imul(result, 31) + (this.h7p_1 == null ? 0 : getNumberHashCode(this.h7p_1)) | 0;
    result = imul(result, 31) + (this.i7p_1 == null ? 0 : getNumberHashCode(this.i7p_1)) | 0;
    result = imul(result, 31) + (this.j7p_1 == null ? 0 : this.j7p_1) | 0;
    result = imul(result, 31) + (this.k7p_1 == null ? 0 : hashCode(this.k7p_1)) | 0;
    result = imul(result, 31) + (this.l7p_1 == null ? 0 : this.l7p_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicParams))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicParams ? other : THROW_CCE();
    if (!(this.g7p_1 === tmp0_other_with_cast.g7p_1))
      return false;
    if (!equals(this.h7p_1, tmp0_other_with_cast.h7p_1))
      return false;
    if (!equals(this.i7p_1, tmp0_other_with_cast.i7p_1))
      return false;
    if (!(this.j7p_1 == tmp0_other_with_cast.j7p_1))
      return false;
    if (!equals(this.k7p_1, tmp0_other_with_cast.k7p_1))
      return false;
    if (!equals(this.l7p_1, tmp0_other_with_cast.l7p_1))
      return false;
    return true;
  }
}
class Companion {
  constructor() {
    Companion_instance_2 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_1 = lazy(tmp_0, AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r);
    var tmp_2 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_3 = lazy(tmp_2, AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r_0);
    var tmp_4 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.f7p_1 = [null, null, tmp_1, null, tmp_3, null, null, null, null, lazy(tmp_4, AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r_1), null];
  }
  r3o() {
    return $serializer_getInstance();
  }
}
class $serializer {
  constructor() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatRequest', this, 11);
    tmp0_serialDesc.u25('model', false);
    tmp0_serialDesc.u25('max_tokens', false);
    tmp0_serialDesc.u25('messages', false);
    tmp0_serialDesc.u25('system', true);
    tmp0_serialDesc.u25('tools', true);
    tmp0_serialDesc.u25('stream', true);
    tmp0_serialDesc.u25('temperature', true);
    tmp0_serialDesc.u25('top_p', true);
    tmp0_serialDesc.u25('top_k', true);
    tmp0_serialDesc.u25('stop_sequences', true);
    tmp0_serialDesc.u25('thinking', true);
    this.m7p_1 = tmp0_serialDesc;
  }
  n7p(encoder, value) {
    var tmp0_desc = this.m7p_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_1().f7p_1;
    tmp1_output.v1z(tmp0_desc, 0, value.o7p_1);
    tmp1_output.q1z(tmp0_desc, 1, value.p7p_1);
    tmp1_output.x1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.q7p_1);
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.r7p_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, StringSerializer_getInstance(), value.r7p_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.s7p_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 4, tmp2_cached[4].n1(), value.s7p_1);
    }
    if (tmp1_output.d20(tmp0_desc, 5) ? true : !(value.t7p_1 === true)) {
      tmp1_output.n1z(tmp0_desc, 5, value.t7p_1);
    }
    if (tmp1_output.d20(tmp0_desc, 6) ? true : !(value.u7p_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 6, DoubleSerializer_getInstance(), value.u7p_1);
    }
    if (tmp1_output.d20(tmp0_desc, 7) ? true : !(value.v7p_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 7, DoubleSerializer_getInstance(), value.v7p_1);
    }
    if (tmp1_output.d20(tmp0_desc, 8) ? true : !(value.w7p_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 8, IntSerializer_getInstance(), value.w7p_1);
    }
    if (tmp1_output.d20(tmp0_desc, 9) ? true : !(value.x7p_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 9, tmp2_cached[9].n1(), value.x7p_1);
    }
    if (tmp1_output.d20(tmp0_desc, 10) ? true : !(value.y7p_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 10, JsonObjectSerializer_getInstance(), value.y7p_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.n7p(encoder, value instanceof AnthropicChatRequest ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.m7p_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = 0;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_local5 = false;
    var tmp10_local6 = null;
    var tmp11_local7 = null;
    var tmp12_local8 = null;
    var tmp13_local9 = null;
    var tmp14_local10 = null;
    var tmp15_input = decoder.f1y(tmp0_desc);
    var tmp16_cached = Companion_getInstance_1().f7p_1;
    if (tmp15_input.v1y()) {
      tmp4_local0 = tmp15_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp15_input.k1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp15_input.r1y(tmp0_desc, 2, tmp16_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp15_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp15_input.t1y(tmp0_desc, 4, tmp16_cached[4].n1(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp15_input.h1y(tmp0_desc, 5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp15_input.t1y(tmp0_desc, 6, DoubleSerializer_getInstance(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
      tmp11_local7 = tmp15_input.t1y(tmp0_desc, 7, DoubleSerializer_getInstance(), tmp11_local7);
      tmp3_bitMask0 = tmp3_bitMask0 | 128;
      tmp12_local8 = tmp15_input.t1y(tmp0_desc, 8, IntSerializer_getInstance(), tmp12_local8);
      tmp3_bitMask0 = tmp3_bitMask0 | 256;
      tmp13_local9 = tmp15_input.t1y(tmp0_desc, 9, tmp16_cached[9].n1(), tmp13_local9);
      tmp3_bitMask0 = tmp3_bitMask0 | 512;
      tmp14_local10 = tmp15_input.t1y(tmp0_desc, 10, JsonObjectSerializer_getInstance(), tmp14_local10);
      tmp3_bitMask0 = tmp3_bitMask0 | 1024;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp15_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp15_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp15_input.k1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp15_input.r1y(tmp0_desc, 2, tmp16_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp15_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp15_input.t1y(tmp0_desc, 4, tmp16_cached[4].n1(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp15_input.h1y(tmp0_desc, 5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp15_input.t1y(tmp0_desc, 6, DoubleSerializer_getInstance(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          case 7:
            tmp11_local7 = tmp15_input.t1y(tmp0_desc, 7, DoubleSerializer_getInstance(), tmp11_local7);
            tmp3_bitMask0 = tmp3_bitMask0 | 128;
            break;
          case 8:
            tmp12_local8 = tmp15_input.t1y(tmp0_desc, 8, IntSerializer_getInstance(), tmp12_local8);
            tmp3_bitMask0 = tmp3_bitMask0 | 256;
            break;
          case 9:
            tmp13_local9 = tmp15_input.t1y(tmp0_desc, 9, tmp16_cached[9].n1(), tmp13_local9);
            tmp3_bitMask0 = tmp3_bitMask0 | 512;
            break;
          case 10:
            tmp14_local10 = tmp15_input.t1y(tmp0_desc, 10, JsonObjectSerializer_getInstance(), tmp14_local10);
            tmp3_bitMask0 = tmp3_bitMask0 | 1024;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp15_input.g1y(tmp0_desc);
    return AnthropicChatRequest.z7p(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, tmp12_local8, tmp13_local9, tmp14_local10, null);
  }
  w1t() {
    return this.m7p_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_1().f7p_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), IntSerializer_getInstance(), tmp0_cached[2].n1(), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[4].n1()), BooleanSerializer_getInstance(), get_nullable(DoubleSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(tmp0_cached[9].n1()), get_nullable(JsonObjectSerializer_getInstance())];
  }
}
class AnthropicChatRequest {
  constructor(model, maxTokens, messages, system, tools, stream, temperature, topP, topK, stopSequences, thinking) {
    Companion_getInstance_1();
    system = system === VOID ? null : system;
    tools = tools === VOID ? null : tools;
    stream = stream === VOID ? true : stream;
    temperature = temperature === VOID ? null : temperature;
    topP = topP === VOID ? null : topP;
    topK = topK === VOID ? null : topK;
    stopSequences = stopSequences === VOID ? null : stopSequences;
    thinking = thinking === VOID ? null : thinking;
    this.o7p_1 = model;
    this.p7p_1 = maxTokens;
    this.q7p_1 = messages;
    this.r7p_1 = system;
    this.s7p_1 = tools;
    this.t7p_1 = stream;
    this.u7p_1 = temperature;
    this.v7p_1 = topP;
    this.w7p_1 = topK;
    this.x7p_1 = stopSequences;
    this.y7p_1 = thinking;
  }
  toString() {
    return 'AnthropicChatRequest(model=' + this.o7p_1 + ', maxTokens=' + this.p7p_1 + ', messages=' + toString_0(this.q7p_1) + ', system=' + this.r7p_1 + ', tools=' + toString(this.s7p_1) + ', stream=' + this.t7p_1 + ', temperature=' + this.u7p_1 + ', topP=' + this.v7p_1 + ', topK=' + this.w7p_1 + ', stopSequences=' + toString(this.x7p_1) + ', thinking=' + toString(this.y7p_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.o7p_1);
    result = imul(result, 31) + this.p7p_1 | 0;
    result = imul(result, 31) + hashCode(this.q7p_1) | 0;
    result = imul(result, 31) + (this.r7p_1 == null ? 0 : getStringHashCode(this.r7p_1)) | 0;
    result = imul(result, 31) + (this.s7p_1 == null ? 0 : hashCode(this.s7p_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.t7p_1) | 0;
    result = imul(result, 31) + (this.u7p_1 == null ? 0 : getNumberHashCode(this.u7p_1)) | 0;
    result = imul(result, 31) + (this.v7p_1 == null ? 0 : getNumberHashCode(this.v7p_1)) | 0;
    result = imul(result, 31) + (this.w7p_1 == null ? 0 : this.w7p_1) | 0;
    result = imul(result, 31) + (this.x7p_1 == null ? 0 : hashCode(this.x7p_1)) | 0;
    result = imul(result, 31) + (this.y7p_1 == null ? 0 : this.y7p_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicChatRequest))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicChatRequest ? other : THROW_CCE();
    if (!(this.o7p_1 === tmp0_other_with_cast.o7p_1))
      return false;
    if (!(this.p7p_1 === tmp0_other_with_cast.p7p_1))
      return false;
    if (!equals(this.q7p_1, tmp0_other_with_cast.q7p_1))
      return false;
    if (!(this.r7p_1 == tmp0_other_with_cast.r7p_1))
      return false;
    if (!equals(this.s7p_1, tmp0_other_with_cast.s7p_1))
      return false;
    if (!(this.t7p_1 === tmp0_other_with_cast.t7p_1))
      return false;
    if (!equals(this.u7p_1, tmp0_other_with_cast.u7p_1))
      return false;
    if (!equals(this.v7p_1, tmp0_other_with_cast.v7p_1))
      return false;
    if (!(this.w7p_1 == tmp0_other_with_cast.w7p_1))
      return false;
    if (!equals(this.x7p_1, tmp0_other_with_cast.x7p_1))
      return false;
    if (!equals(this.y7p_1, tmp0_other_with_cast.y7p_1))
      return false;
    return true;
  }
  static z7p(seen0, model, maxTokens, messages, system, tools, stream, temperature, topP, topK, stopSequences, thinking, serializationConstructorMarker) {
    Companion_getInstance_1();
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance().m7p_1);
    }
    var $this = createThis(this);
    $this.o7p_1 = model;
    $this.p7p_1 = maxTokens;
    $this.q7p_1 = messages;
    if (0 === (seen0 & 8))
      $this.r7p_1 = null;
    else
      $this.r7p_1 = system;
    if (0 === (seen0 & 16))
      $this.s7p_1 = null;
    else
      $this.s7p_1 = tools;
    if (0 === (seen0 & 32))
      $this.t7p_1 = true;
    else
      $this.t7p_1 = stream;
    if (0 === (seen0 & 64))
      $this.u7p_1 = null;
    else
      $this.u7p_1 = temperature;
    if (0 === (seen0 & 128))
      $this.v7p_1 = null;
    else
      $this.v7p_1 = topP;
    if (0 === (seen0 & 256))
      $this.w7p_1 = null;
    else
      $this.w7p_1 = topK;
    if (0 === (seen0 & 512))
      $this.x7p_1 = null;
    else
      $this.x7p_1 = stopSequences;
    if (0 === (seen0 & 1024))
      $this.y7p_1 = null;
    else
      $this.y7p_1 = thinking;
    return $this;
  }
}
class Companion_0 {
  constructor() {
    Companion_instance_3 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.a7q_1 = [null, lazy(tmp_0, AnthropicMessage$Companion$$childSerializers$_anonymous__qndbyp)];
  }
}
class $serializer_0 {
  constructor() {
    $serializer_instance_0 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicMessage', this, 2);
    tmp0_serialDesc.u25('role', false);
    tmp0_serialDesc.u25('content', false);
    this.b7q_1 = tmp0_serialDesc;
  }
  c7q(encoder, value) {
    var tmp0_desc = this.b7q_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_2().a7q_1;
    tmp1_output.v1z(tmp0_desc, 0, value.d7q_1);
    tmp1_output.x1z(tmp0_desc, 1, tmp2_cached[1].n1(), value.e7q_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.c7q(encoder, value instanceof AnthropicMessage ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.b7q_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    var tmp7_cached = Companion_getInstance_2().a7q_1;
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, tmp7_cached[1].n1(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, tmp7_cached[1].n1(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return AnthropicMessage.f7q(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.b7q_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_2().a7q_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), tmp0_cached[1].n1()];
  }
}
class AnthropicMessage {
  constructor(role, content) {
    Companion_getInstance_2();
    this.d7q_1 = role;
    this.e7q_1 = content;
  }
  toString() {
    return 'AnthropicMessage(role=' + this.d7q_1 + ', content=' + toString_0(this.e7q_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.d7q_1);
    result = imul(result, 31) + hashCode(this.e7q_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicMessage))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicMessage ? other : THROW_CCE();
    if (!(this.d7q_1 === tmp0_other_with_cast.d7q_1))
      return false;
    if (!equals(this.e7q_1, tmp0_other_with_cast.e7q_1))
      return false;
    return true;
  }
  static f7q(seen0, role, content, serializationConstructorMarker) {
    Companion_getInstance_2();
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_0().b7q_1);
    }
    var $this = createThis(this);
    $this.d7q_1 = role;
    $this.e7q_1 = content;
    return $this;
  }
}
class Companion_1 {}
class $serializer_1 {
  constructor() {
    $serializer_instance_1 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicTool', this, 3);
    tmp0_serialDesc.u25('name', false);
    tmp0_serialDesc.u25('description', false);
    tmp0_serialDesc.u25('input_schema', false);
    this.g7q_1 = tmp0_serialDesc;
  }
  h7q(encoder, value) {
    var tmp0_desc = this.g7q_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.i7q_1);
    tmp1_output.v1z(tmp0_desc, 1, value.j7q_1);
    tmp1_output.x1z(tmp0_desc, 2, JsonObjectSerializer_getInstance(), value.k7q_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.h7q(encoder, value instanceof AnthropicTool ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.g7q_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.f1y(tmp0_desc);
    if (tmp7_input.v1y()) {
      tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp7_input.g1y(tmp0_desc);
    return AnthropicTool.l7q(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  w1t() {
    return this.g7q_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), JsonObjectSerializer_getInstance()];
  }
}
class AnthropicTool {
  constructor(name, description, inputSchema) {
    this.i7q_1 = name;
    this.j7q_1 = description;
    this.k7q_1 = inputSchema;
  }
  toString() {
    return 'AnthropicTool(name=' + this.i7q_1 + ', description=' + this.j7q_1 + ', inputSchema=' + this.k7q_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.i7q_1);
    result = imul(result, 31) + getStringHashCode(this.j7q_1) | 0;
    result = imul(result, 31) + this.k7q_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicTool))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicTool ? other : THROW_CCE();
    if (!(this.i7q_1 === tmp0_other_with_cast.i7q_1))
      return false;
    if (!(this.j7q_1 === tmp0_other_with_cast.j7q_1))
      return false;
    if (!this.k7q_1.equals(tmp0_other_with_cast.k7q_1))
      return false;
    return true;
  }
  static l7q(seen0, name, description, inputSchema, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_1().g7q_1);
    }
    var $this = createThis(this);
    $this.i7q_1 = name;
    $this.j7q_1 = description;
    $this.k7q_1 = inputSchema;
    return $this;
  }
}
class Companion_2 {}
class $serializer_2 {
  constructor() {
    $serializer_instance_2 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('thinking', this, 2);
    tmp0_serialDesc.u25('thinking', false);
    tmp0_serialDesc.u25('signature', true);
    this.m7q_1 = tmp0_serialDesc;
  }
  n7q(encoder, value) {
    var tmp0_desc = this.m7q_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.o7q_1);
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.p7q_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.p7q_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.n7q(encoder, value instanceof Thinking ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.m7q_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return Thinking.q7q(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.m7q_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_3 {}
class $serializer_3 {
  constructor() {
    $serializer_instance_3 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('redacted_thinking', this, 1);
    tmp0_serialDesc.u25('data', false);
    this.r7q_1 = tmp0_serialDesc;
  }
  s7q(encoder, value) {
    var tmp0_desc = this.r7q_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.t7q_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.s7q(encoder, value instanceof RedactedThinking ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.r7q_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.f1y(tmp0_desc);
    if (tmp5_input.v1y()) {
      tmp4_local0 = tmp5_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp5_input.g1y(tmp0_desc);
    return RedactedThinking.u7q(tmp3_bitMask0, tmp4_local0, null);
  }
  w1t() {
    return this.r7q_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance()];
  }
}
class Companion_4 {}
class $serializer_4 {
  constructor() {
    $serializer_instance_4 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('text', this, 1);
    tmp0_serialDesc.u25('text', false);
    this.v7q_1 = tmp0_serialDesc;
  }
  w7q(encoder, value) {
    var tmp0_desc = this.v7q_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.x7q_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.w7q(encoder, value instanceof Text_0 ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.v7q_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.f1y(tmp0_desc);
    if (tmp5_input.v1y()) {
      tmp4_local0 = tmp5_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp5_input.g1y(tmp0_desc);
    return Text_0.y7q(tmp3_bitMask0, tmp4_local0, null);
  }
  w1t() {
    return this.v7q_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance()];
  }
}
class Companion_5 {}
class $serializer_5 {
  constructor() {
    $serializer_instance_5 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('tool_use', this, 3);
    tmp0_serialDesc.u25('id', false);
    tmp0_serialDesc.u25('name', false);
    tmp0_serialDesc.u25('input', false);
    this.z7q_1 = tmp0_serialDesc;
  }
  a7r(encoder, value) {
    var tmp0_desc = this.z7q_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.b7r_1);
    tmp1_output.v1z(tmp0_desc, 1, value.c7r_1);
    tmp1_output.x1z(tmp0_desc, 2, JsonElementSerializer_getInstance(), value.d7r_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.a7r(encoder, value instanceof ToolUse ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.z7q_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.f1y(tmp0_desc);
    if (tmp7_input.v1y()) {
      tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, JsonElementSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, JsonElementSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp7_input.g1y(tmp0_desc);
    return ToolUse.e7r(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  w1t() {
    return this.z7q_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), JsonElementSerializer_getInstance()];
  }
}
class Companion_6 {}
class $serializer_6 {
  constructor() {
    $serializer_instance_6 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('tool_result', this, 3);
    tmp0_serialDesc.u25('tool_use_id', false);
    tmp0_serialDesc.u25('content', false);
    tmp0_serialDesc.u25('is_error', true);
    this.f7r_1 = tmp0_serialDesc;
  }
  g7r(encoder, value) {
    var tmp0_desc = this.f7r_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.h7r_1);
    tmp1_output.v1z(tmp0_desc, 1, value.i7r_1);
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.j7r_1 === false)) {
      tmp1_output.n1z(tmp0_desc, 2, value.j7r_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.g7r(encoder, value instanceof ToolResult_0 ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.f7r_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = false;
    var tmp7_input = decoder.f1y(tmp0_desc);
    if (tmp7_input.v1y()) {
      tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.h1y(tmp0_desc, 2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.h1y(tmp0_desc, 2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp7_input.g1y(tmp0_desc);
    return ToolResult_0.k7r(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  w1t() {
    return this.f7r_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), BooleanSerializer_getInstance()];
  }
}
class AnthropicContentBlock {}
class Thinking {
  constructor(thinking, signature) {
    signature = signature === VOID ? null : signature;
    this.o7q_1 = thinking;
    this.p7q_1 = signature;
  }
  toString() {
    return 'Thinking(thinking=' + this.o7q_1 + ', signature=' + this.p7q_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.o7q_1);
    result = imul(result, 31) + (this.p7q_1 == null ? 0 : getStringHashCode(this.p7q_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Thinking))
      return false;
    var tmp0_other_with_cast = other instanceof Thinking ? other : THROW_CCE();
    if (!(this.o7q_1 === tmp0_other_with_cast.o7q_1))
      return false;
    if (!(this.p7q_1 == tmp0_other_with_cast.p7q_1))
      return false;
    return true;
  }
  static q7q(seen0, thinking, signature, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_2().m7q_1);
    }
    var $this = createThis(this);
    $this.o7q_1 = thinking;
    if (0 === (seen0 & 2))
      $this.p7q_1 = null;
    else
      $this.p7q_1 = signature;
    return $this;
  }
}
class RedactedThinking {
  constructor(data) {
    this.t7q_1 = data;
  }
  toString() {
    return 'RedactedThinking(data=' + this.t7q_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.t7q_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof RedactedThinking))
      return false;
    var tmp0_other_with_cast = other instanceof RedactedThinking ? other : THROW_CCE();
    if (!(this.t7q_1 === tmp0_other_with_cast.t7q_1))
      return false;
    return true;
  }
  static u7q(seen0, data, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_3().r7q_1);
    }
    var $this = createThis(this);
    $this.t7q_1 = data;
    return $this;
  }
}
class Text_0 {
  constructor(text) {
    this.x7q_1 = text;
  }
  toString() {
    return 'Text(text=' + this.x7q_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.x7q_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Text_0))
      return false;
    var tmp0_other_with_cast = other instanceof Text_0 ? other : THROW_CCE();
    if (!(this.x7q_1 === tmp0_other_with_cast.x7q_1))
      return false;
    return true;
  }
  static y7q(seen0, text, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_4().v7q_1);
    }
    var $this = createThis(this);
    $this.x7q_1 = text;
    return $this;
  }
}
class ToolUse {
  constructor(id, name, input) {
    this.b7r_1 = id;
    this.c7r_1 = name;
    this.d7r_1 = input;
  }
  toString() {
    return 'ToolUse(id=' + this.b7r_1 + ', name=' + this.c7r_1 + ', input=' + toString_0(this.d7r_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.b7r_1);
    result = imul(result, 31) + getStringHashCode(this.c7r_1) | 0;
    result = imul(result, 31) + hashCode(this.d7r_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolUse))
      return false;
    var tmp0_other_with_cast = other instanceof ToolUse ? other : THROW_CCE();
    if (!(this.b7r_1 === tmp0_other_with_cast.b7r_1))
      return false;
    if (!(this.c7r_1 === tmp0_other_with_cast.c7r_1))
      return false;
    if (!equals(this.d7r_1, tmp0_other_with_cast.d7r_1))
      return false;
    return true;
  }
  static e7r(seen0, id, name, input, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_5().z7q_1);
    }
    var $this = createThis(this);
    $this.b7r_1 = id;
    $this.c7r_1 = name;
    $this.d7r_1 = input;
    return $this;
  }
}
class ToolResult_0 {
  constructor(toolUseId, content, isError) {
    isError = isError === VOID ? false : isError;
    this.h7r_1 = toolUseId;
    this.i7r_1 = content;
    this.j7r_1 = isError;
  }
  toString() {
    return 'ToolResult(toolUseId=' + this.h7r_1 + ', content=' + this.i7r_1 + ', isError=' + this.j7r_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.h7r_1);
    result = imul(result, 31) + getStringHashCode(this.i7r_1) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.j7r_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ToolResult_0))
      return false;
    var tmp0_other_with_cast = other instanceof ToolResult_0 ? other : THROW_CCE();
    if (!(this.h7r_1 === tmp0_other_with_cast.h7r_1))
      return false;
    if (!(this.i7r_1 === tmp0_other_with_cast.i7r_1))
      return false;
    if (!(this.j7r_1 === tmp0_other_with_cast.j7r_1))
      return false;
    return true;
  }
  static k7r(seen0, toolUseId, content, isError, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_6().f7r_1);
    }
    var $this = createThis(this);
    $this.h7r_1 = toolUseId;
    $this.i7r_1 = content;
    if (0 === (seen0 & 4))
      $this.j7r_1 = false;
    else
      $this.j7r_1 = isError;
    return $this;
  }
}
class Companion_7 {
  r3o() {
    var tmp = getKClass(AnthropicContentBlock);
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_0 = [getKClass(RedactedThinking), getKClass(Text_0), getKClass(Thinking), getKClass(ToolResult_0), getKClass(ToolUse)];
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp_1 = [$serializer_getInstance_3(), $serializer_getInstance_4(), $serializer_getInstance_2(), $serializer_getInstance_6(), $serializer_getInstance_5()];
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    var tmp$ret$8 = [];
    return SealedClassSerializer.c1v('org.koaks.provider.anthropic.AnthropicContentBlock', tmp, tmp_0, tmp_1, tmp$ret$8);
  }
  v26(typeParamsSerializers) {
    return this.r3o();
  }
}
class Companion_8 {}
class $serializer_7 {
  constructor() {
    $serializer_instance_7 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.Message', this, 1);
    tmp0_serialDesc.u25('usage', true);
    this.l7r_1 = tmp0_serialDesc;
  }
  m7r(encoder, value) {
    var tmp0_desc = this.l7r_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.n7r_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, $serializer_getInstance_10(), value.n7r_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.m7r(encoder, value instanceof Message_0 ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.l7r_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.f1y(tmp0_desc);
    if (tmp5_input.v1y()) {
      tmp4_local0 = tmp5_input.t1y(tmp0_desc, 0, $serializer_getInstance_10(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.t1y(tmp0_desc, 0, $serializer_getInstance_10(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp5_input.g1y(tmp0_desc);
    return Message_0.o7r(tmp3_bitMask0, tmp4_local0, null);
  }
  w1t() {
    return this.l7r_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable($serializer_getInstance_10())];
  }
}
class Companion_9 {}
class $serializer_8 {
  constructor() {
    $serializer_instance_8 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.ContentBlock', this, 4);
    tmp0_serialDesc.u25('type', true);
    tmp0_serialDesc.u25('id', true);
    tmp0_serialDesc.u25('name', true);
    tmp0_serialDesc.u25('data', true);
    this.p7r_1 = tmp0_serialDesc;
  }
  q7r(encoder, value) {
    var tmp0_desc = this.p7r_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.r7r_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.r7r_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.s7r_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.s7r_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.t7r_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, StringSerializer_getInstance(), value.t7r_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.u7r_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, StringSerializer_getInstance(), value.u7r_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.q7r(encoder, value instanceof ContentBlock ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.p7r_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.f1y(tmp0_desc);
    if (tmp8_input.v1y()) {
      tmp4_local0 = tmp8_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp8_input.g1y(tmp0_desc);
    return ContentBlock.v7r(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  w1t() {
    return this.p7r_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_10 {}
class $serializer_9 {
  constructor() {
    $serializer_instance_9 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.Delta', this, 5);
    tmp0_serialDesc.u25('type', true);
    tmp0_serialDesc.u25('text', true);
    tmp0_serialDesc.u25('thinking', true);
    tmp0_serialDesc.u25('signature', true);
    tmp0_serialDesc.u25('partial_json', true);
    this.w7r_1 = tmp0_serialDesc;
  }
  x7r(encoder, value) {
    var tmp0_desc = this.w7r_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.y7r_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.y7r_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.z7r_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.z7r_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.a7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, StringSerializer_getInstance(), value.a7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.b7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, StringSerializer_getInstance(), value.b7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.c7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 4, StringSerializer_getInstance(), value.c7s_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.x7r(encoder, value instanceof Delta ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.w7r_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_input = decoder.f1y(tmp0_desc);
    if (tmp9_input.v1y()) {
      tmp4_local0 = tmp9_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp9_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp9_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp9_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp9_input.t1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp9_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp9_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp9_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp9_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp9_input.t1y(tmp0_desc, 3, StringSerializer_getInstance(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp9_input.t1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp9_input.g1y(tmp0_desc);
    return Delta.d7s(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, null);
  }
  w1t() {
    return this.w7r_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Companion_11 {}
class $serializer_10 {
  constructor() {
    $serializer_instance_10 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.Usage', this, 2);
    tmp0_serialDesc.u25('input_tokens', true);
    tmp0_serialDesc.u25('output_tokens', true);
    this.e7s_1 = tmp0_serialDesc;
  }
  f7s(encoder, value) {
    var tmp0_desc = this.e7s_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.g7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, IntSerializer_getInstance(), value.g7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.h7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, IntSerializer_getInstance(), value.h7s_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.f7s(encoder, value instanceof Usage_0 ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.e7s_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.t1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.t1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.t1y(tmp0_desc, 0, IntSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.t1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return Usage_0.i7s(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.e7s_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance())];
  }
}
class Companion_12 {}
class $serializer_11 {
  constructor() {
    $serializer_instance_11 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse.ErrorOutput', this, 2);
    tmp0_serialDesc.u25('type', true);
    tmp0_serialDesc.u25('message', true);
    this.j7s_1 = tmp0_serialDesc;
  }
  k7s(encoder, value) {
    var tmp0_desc = this.j7s_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.l7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.l7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.m7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.m7s_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.k7s(encoder, value instanceof ErrorOutput ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.j7s_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return ErrorOutput.n7s(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.j7s_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class Message_0 {
  constructor(usage) {
    usage = usage === VOID ? null : usage;
    this.n7r_1 = usage;
  }
  toString() {
    return 'Message(usage=' + toString(this.n7r_1) + ')';
  }
  hashCode() {
    return this.n7r_1 == null ? 0 : this.n7r_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Message_0))
      return false;
    var tmp0_other_with_cast = other instanceof Message_0 ? other : THROW_CCE();
    if (!equals(this.n7r_1, tmp0_other_with_cast.n7r_1))
      return false;
    return true;
  }
  static o7r(seen0, usage, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_7().l7r_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.n7r_1 = null;
    else
      $this.n7r_1 = usage;
    return $this;
  }
}
class ContentBlock {
  constructor(type, id, name, data) {
    type = type === VOID ? null : type;
    id = id === VOID ? null : id;
    name = name === VOID ? null : name;
    data = data === VOID ? null : data;
    this.r7r_1 = type;
    this.s7r_1 = id;
    this.t7r_1 = name;
    this.u7r_1 = data;
  }
  toString() {
    return 'ContentBlock(type=' + this.r7r_1 + ', id=' + this.s7r_1 + ', name=' + this.t7r_1 + ', data=' + this.u7r_1 + ')';
  }
  hashCode() {
    var result = this.r7r_1 == null ? 0 : getStringHashCode(this.r7r_1);
    result = imul(result, 31) + (this.s7r_1 == null ? 0 : getStringHashCode(this.s7r_1)) | 0;
    result = imul(result, 31) + (this.t7r_1 == null ? 0 : getStringHashCode(this.t7r_1)) | 0;
    result = imul(result, 31) + (this.u7r_1 == null ? 0 : getStringHashCode(this.u7r_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ContentBlock))
      return false;
    var tmp0_other_with_cast = other instanceof ContentBlock ? other : THROW_CCE();
    if (!(this.r7r_1 == tmp0_other_with_cast.r7r_1))
      return false;
    if (!(this.s7r_1 == tmp0_other_with_cast.s7r_1))
      return false;
    if (!(this.t7r_1 == tmp0_other_with_cast.t7r_1))
      return false;
    if (!(this.u7r_1 == tmp0_other_with_cast.u7r_1))
      return false;
    return true;
  }
  static v7r(seen0, type, id, name, data, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_8().p7r_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.r7r_1 = null;
    else
      $this.r7r_1 = type;
    if (0 === (seen0 & 2))
      $this.s7r_1 = null;
    else
      $this.s7r_1 = id;
    if (0 === (seen0 & 4))
      $this.t7r_1 = null;
    else
      $this.t7r_1 = name;
    if (0 === (seen0 & 8))
      $this.u7r_1 = null;
    else
      $this.u7r_1 = data;
    return $this;
  }
}
class Delta {
  constructor(type, text, thinking, signature, partialJson) {
    type = type === VOID ? null : type;
    text = text === VOID ? null : text;
    thinking = thinking === VOID ? null : thinking;
    signature = signature === VOID ? null : signature;
    partialJson = partialJson === VOID ? null : partialJson;
    this.y7r_1 = type;
    this.z7r_1 = text;
    this.a7s_1 = thinking;
    this.b7s_1 = signature;
    this.c7s_1 = partialJson;
  }
  toString() {
    return 'Delta(type=' + this.y7r_1 + ', text=' + this.z7r_1 + ', thinking=' + this.a7s_1 + ', signature=' + this.b7s_1 + ', partialJson=' + this.c7s_1 + ')';
  }
  hashCode() {
    var result = this.y7r_1 == null ? 0 : getStringHashCode(this.y7r_1);
    result = imul(result, 31) + (this.z7r_1 == null ? 0 : getStringHashCode(this.z7r_1)) | 0;
    result = imul(result, 31) + (this.a7s_1 == null ? 0 : getStringHashCode(this.a7s_1)) | 0;
    result = imul(result, 31) + (this.b7s_1 == null ? 0 : getStringHashCode(this.b7s_1)) | 0;
    result = imul(result, 31) + (this.c7s_1 == null ? 0 : getStringHashCode(this.c7s_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Delta))
      return false;
    var tmp0_other_with_cast = other instanceof Delta ? other : THROW_CCE();
    if (!(this.y7r_1 == tmp0_other_with_cast.y7r_1))
      return false;
    if (!(this.z7r_1 == tmp0_other_with_cast.z7r_1))
      return false;
    if (!(this.a7s_1 == tmp0_other_with_cast.a7s_1))
      return false;
    if (!(this.b7s_1 == tmp0_other_with_cast.b7s_1))
      return false;
    if (!(this.c7s_1 == tmp0_other_with_cast.c7s_1))
      return false;
    return true;
  }
  static d7s(seen0, type, text, thinking, signature, partialJson, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_9().w7r_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.y7r_1 = null;
    else
      $this.y7r_1 = type;
    if (0 === (seen0 & 2))
      $this.z7r_1 = null;
    else
      $this.z7r_1 = text;
    if (0 === (seen0 & 4))
      $this.a7s_1 = null;
    else
      $this.a7s_1 = thinking;
    if (0 === (seen0 & 8))
      $this.b7s_1 = null;
    else
      $this.b7s_1 = signature;
    if (0 === (seen0 & 16))
      $this.c7s_1 = null;
    else
      $this.c7s_1 = partialJson;
    return $this;
  }
}
class Usage_0 {
  constructor(inputTokens, outputTokens) {
    inputTokens = inputTokens === VOID ? null : inputTokens;
    outputTokens = outputTokens === VOID ? null : outputTokens;
    this.g7s_1 = inputTokens;
    this.h7s_1 = outputTokens;
  }
  toString() {
    return 'Usage(inputTokens=' + this.g7s_1 + ', outputTokens=' + this.h7s_1 + ')';
  }
  hashCode() {
    var result = this.g7s_1 == null ? 0 : this.g7s_1;
    result = imul(result, 31) + (this.h7s_1 == null ? 0 : this.h7s_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof Usage_0))
      return false;
    var tmp0_other_with_cast = other instanceof Usage_0 ? other : THROW_CCE();
    if (!(this.g7s_1 == tmp0_other_with_cast.g7s_1))
      return false;
    if (!(this.h7s_1 == tmp0_other_with_cast.h7s_1))
      return false;
    return true;
  }
  static i7s(seen0, inputTokens, outputTokens, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_10().e7s_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.g7s_1 = null;
    else
      $this.g7s_1 = inputTokens;
    if (0 === (seen0 & 2))
      $this.h7s_1 = null;
    else
      $this.h7s_1 = outputTokens;
    return $this;
  }
}
class ErrorOutput {
  constructor(type, message) {
    type = type === VOID ? null : type;
    message = message === VOID ? null : message;
    this.l7s_1 = type;
    this.m7s_1 = message;
  }
  toString() {
    return 'ErrorOutput(type=' + this.l7s_1 + ', message=' + this.m7s_1 + ')';
  }
  hashCode() {
    var result = this.l7s_1 == null ? 0 : getStringHashCode(this.l7s_1);
    result = imul(result, 31) + (this.m7s_1 == null ? 0 : getStringHashCode(this.m7s_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ErrorOutput))
      return false;
    var tmp0_other_with_cast = other instanceof ErrorOutput ? other : THROW_CCE();
    if (!(this.l7s_1 == tmp0_other_with_cast.l7s_1))
      return false;
    if (!(this.m7s_1 == tmp0_other_with_cast.m7s_1))
      return false;
    return true;
  }
  static n7s(seen0, type, message, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_11().j7s_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.l7s_1 = null;
    else
      $this.l7s_1 = type;
    if (0 === (seen0 & 2))
      $this.m7s_1 = null;
    else
      $this.m7s_1 = message;
    return $this;
  }
}
class Companion_13 {
  r3o() {
    return $serializer_getInstance_12();
  }
}
class $serializer_12 {
  constructor() {
    $serializer_instance_12 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.anthropic.AnthropicChatResponse', this, 7);
    tmp0_serialDesc.u25('type', true);
    tmp0_serialDesc.u25('index', true);
    tmp0_serialDesc.u25('message', true);
    tmp0_serialDesc.u25('content_block', true);
    tmp0_serialDesc.u25('delta', true);
    tmp0_serialDesc.u25('usage', true);
    tmp0_serialDesc.u25('error', true);
    this.o7s_1 = tmp0_serialDesc;
  }
  p7s(encoder, value) {
    var tmp0_desc = this.o7s_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.q7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.q7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.r7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, IntSerializer_getInstance(), value.r7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.s7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, $serializer_getInstance_7(), value.s7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.t7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, $serializer_getInstance_8(), value.t7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.u7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 4, $serializer_getInstance_9(), value.u7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 5) ? true : !(value.v7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 5, $serializer_getInstance_10(), value.v7s_1);
    }
    if (tmp1_output.d20(tmp0_desc, 6) ? true : !(value.w7s_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 6, $serializer_getInstance_11(), value.w7s_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.p7s(encoder, value instanceof AnthropicChatResponse ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.o7s_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_local5 = null;
    var tmp10_local6 = null;
    var tmp11_input = decoder.f1y(tmp0_desc);
    if (tmp11_input.v1y()) {
      tmp4_local0 = tmp11_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp11_input.t1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp11_input.t1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp11_input.t1y(tmp0_desc, 3, $serializer_getInstance_8(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp11_input.t1y(tmp0_desc, 4, $serializer_getInstance_9(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp11_input.t1y(tmp0_desc, 5, $serializer_getInstance_10(), tmp9_local5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp11_input.t1y(tmp0_desc, 6, $serializer_getInstance_11(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp11_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp11_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp11_input.t1y(tmp0_desc, 1, IntSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp11_input.t1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp11_input.t1y(tmp0_desc, 3, $serializer_getInstance_8(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp11_input.t1y(tmp0_desc, 4, $serializer_getInstance_9(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp11_input.t1y(tmp0_desc, 5, $serializer_getInstance_10(), tmp9_local5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp11_input.t1y(tmp0_desc, 6, $serializer_getInstance_11(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp11_input.g1y(tmp0_desc);
    return AnthropicChatResponse.x7s(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, null);
  }
  w1t() {
    return this.o7s_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable($serializer_getInstance_7()), get_nullable($serializer_getInstance_8()), get_nullable($serializer_getInstance_9()), get_nullable($serializer_getInstance_10()), get_nullable($serializer_getInstance_11())];
  }
}
class AnthropicChatResponse {
  constructor(type, index, message, contentBlock, delta, usage, error) {
    type = type === VOID ? null : type;
    index = index === VOID ? null : index;
    message = message === VOID ? null : message;
    contentBlock = contentBlock === VOID ? null : contentBlock;
    delta = delta === VOID ? null : delta;
    usage = usage === VOID ? null : usage;
    error = error === VOID ? null : error;
    this.q7s_1 = type;
    this.r7s_1 = index;
    this.s7s_1 = message;
    this.t7s_1 = contentBlock;
    this.u7s_1 = delta;
    this.v7s_1 = usage;
    this.w7s_1 = error;
  }
  toString() {
    return 'AnthropicChatResponse(type=' + this.q7s_1 + ', index=' + this.r7s_1 + ', message=' + toString(this.s7s_1) + ', contentBlock=' + toString(this.t7s_1) + ', delta=' + toString(this.u7s_1) + ', usage=' + toString(this.v7s_1) + ', error=' + toString(this.w7s_1) + ')';
  }
  hashCode() {
    var result = this.q7s_1 == null ? 0 : getStringHashCode(this.q7s_1);
    result = imul(result, 31) + (this.r7s_1 == null ? 0 : this.r7s_1) | 0;
    result = imul(result, 31) + (this.s7s_1 == null ? 0 : this.s7s_1.hashCode()) | 0;
    result = imul(result, 31) + (this.t7s_1 == null ? 0 : this.t7s_1.hashCode()) | 0;
    result = imul(result, 31) + (this.u7s_1 == null ? 0 : this.u7s_1.hashCode()) | 0;
    result = imul(result, 31) + (this.v7s_1 == null ? 0 : this.v7s_1.hashCode()) | 0;
    result = imul(result, 31) + (this.w7s_1 == null ? 0 : this.w7s_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof AnthropicChatResponse))
      return false;
    var tmp0_other_with_cast = other instanceof AnthropicChatResponse ? other : THROW_CCE();
    if (!(this.q7s_1 == tmp0_other_with_cast.q7s_1))
      return false;
    if (!(this.r7s_1 == tmp0_other_with_cast.r7s_1))
      return false;
    if (!equals(this.s7s_1, tmp0_other_with_cast.s7s_1))
      return false;
    if (!equals(this.t7s_1, tmp0_other_with_cast.t7s_1))
      return false;
    if (!equals(this.u7s_1, tmp0_other_with_cast.u7s_1))
      return false;
    if (!equals(this.v7s_1, tmp0_other_with_cast.v7s_1))
      return false;
    if (!equals(this.w7s_1, tmp0_other_with_cast.w7s_1))
      return false;
    return true;
  }
  static x7s(seen0, type, index, message, contentBlock, delta, usage, error, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_12().o7s_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.q7s_1 = null;
    else
      $this.q7s_1 = type;
    if (0 === (seen0 & 2))
      $this.r7s_1 = null;
    else
      $this.r7s_1 = index;
    if (0 === (seen0 & 4))
      $this.s7s_1 = null;
    else
      $this.s7s_1 = message;
    if (0 === (seen0 & 8))
      $this.t7s_1 = null;
    else
      $this.t7s_1 = contentBlock;
    if (0 === (seen0 & 16))
      $this.u7s_1 = null;
    else
      $this.u7s_1 = delta;
    if (0 === (seen0 & 32))
      $this.v7s_1 = null;
    else
      $this.v7s_1 = usage;
    if (0 === (seen0 & 64))
      $this.w7s_1 = null;
    else
      $this.w7s_1 = error;
    return $this;
  }
}
class AnthropicConfig {
  constructor(baseUrl, apiKey, modelName) {
    this.y7s_1 = baseUrl;
    this.z7s_1 = apiKey;
    this.a7t_1 = modelName;
    this.b7t_1 = 4096;
    this.c7t_1 = null;
    this.d7t_1 = null;
    this.e7t_1 = null;
    this.f7t_1 = null;
    this.g7t_1 = null;
    this.h7t_1 = '2023-06-01';
    this.i7t_1 = new Long(60000, 0);
    this.j7t_1 = new ModelCapabilities(VOID, VOID, Support_Unsupported_getInstance(), VOID, Support_Supported_getInstance());
  }
  n7t(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new AnthropicCapabilitiesScope(this.j7t_1);
    block(this_0);
    tmp.j7t_1 = this_0.s7t();
  }
  k7t() {
    return new ModelConfig(normalizeAnthropicMessagesUrl(this.y7s_1), this.z7s_1, this.a7t_1, new Header('x-api-key'), mapOf(to('anthropic-version', this.h7t_1)), VOID, VOID, VOID, this.i7t_1);
  }
  l7t() {
    return new AnthropicParams(this.b7t_1, this.c7t_1, this.d7t_1, this.e7t_1, this.f7t_1, this.g7t_1);
  }
  m7t() {
    return this.j7t_1;
  }
}
class AnthropicCapabilitiesScope {
  constructor(initial) {
    this.o7t_1 = initial.v5o_1.equals(Support_Supported_getInstance());
    this.p7t_1 = initial.w5o_1.equals(Support_Supported_getInstance());
    this.q7t_1 = initial.x5o_1.equals(Support_Supported_getInstance());
    this.r7t_1 = initial.z5o_1.equals(Support_Supported_getInstance());
  }
  s7t() {
    return new ModelCapabilities(this.o7t_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), this.p7t_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.q7t_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), VOID, this.r7t_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance());
  }
}
class ToolAcc {
  constructor(id, name, args, ref) {
    args = args === VOID ? StringBuilder.v() : args;
    ref = ref === VOID ? Companion_instance.k60('call') : ref;
    this.t7t_1 = id;
    this.u7t_1 = name;
    this.v7t_1 = args;
    this.w7t_1 = ref;
  }
}
class ThinkingAcc {
  constructor(text, signature, redacted, kind, ref) {
    text = text === VOID ? StringBuilder.v() : text;
    signature = signature === VOID ? StringBuilder.v() : signature;
    redacted = redacted === VOID ? null : redacted;
    ref = ref === VOID ? Companion_instance.k60('think') : ref;
    this.x7t_1 = text;
    this.y7t_1 = signature;
    this.z7t_1 = redacted;
    this.a7u_1 = kind;
    this.b7u_1 = ref;
  }
}
class sam$kotlin_Comparator$0 {
  constructor(function_0) {
    this.n7u_1 = function_0;
  }
  vi(a, b) {
    return this.n7u_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.n7u_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class AnthropicWireDecoder {
  constructor() {
    this.c7u_1 = LinkedHashMap.hc();
    this.d7u_1 = LinkedHashMap.hc();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.e7u_1 = ArrayList.k();
    this.f7u_1 = StringBuilder.v();
    this.g7u_1 = Companion_instance.k60('msg');
    this.h7u_1 = 0;
    this.i7u_1 = 0;
    this.j7u_1 = 0;
    this.k7u_1 = null;
    this.l7u_1 = false;
    this.m7u_1 = false;
  }
  z6f(frame) {
    var tmp;
    if (frame instanceof Sse) {
      tmp = frame.e6m_1;
    } else {
      if (frame instanceof Body) {
        tmp = frame.h6m_1;
      } else {
        if (frame instanceof Ndjson) {
          tmp = frame.i6m_1;
        } else {
          if (frame instanceof HttpError) {
            this.k7u_1 = new ModelError('HTTP ' + frame.i6l_1 + ': ' + frame.k6l_1, frame.i6l_1 >= 500);
            return finishFailed(this);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
    var json = tmp;
    if (isBlank(json))
      return emptyList();
    // Inline function 'kotlin.runCatching' call
    var tmp_0;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = JsonUtil_getInstance().e6f(json, Companion_instance_16.r3o());
      tmp_0 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_1;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    // Inline function 'kotlin.getOrElse' call
    var this_0 = tmp_0;
    var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
    var tmp_2;
    if (exception == null) {
      var tmp_3 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_2 = (tmp_3 == null ? true : !(tmp_3 == null)) ? tmp_3 : THROW_CCE();
    } else {
      return emptyList();
    }
    var chunk = tmp_2;
    return this.o7u(chunk);
  }
  o7u(chunk) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    if (!this.m7u_1) {
      this.m7u_1 = true;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = new Started(null);
      events.l(element);
    }
    switch (chunk.q7s_1) {
      case 'error':
        var tmp = this;
        var tmp1_safe_receiver = chunk.w7s_1;
        var tmp2_elvis_lhs = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.m7s_1;
        var tmp_0;
        if (tmp2_elvis_lhs == null) {
          var tmp3_safe_receiver = chunk.w7s_1;
          tmp_0 = 'anthropic error ' + (tmp3_safe_receiver == null ? null : tmp3_safe_receiver.l7s_1);
        } else {
          tmp_0 = tmp2_elvis_lhs;
        }

        tmp.k7u_1 = new ModelError(tmp_0, false);
        return plus(events, finishFailed(this));
      case 'message_start':
        var tmp4_safe_receiver = chunk.s7s_1;
        var tmp5_safe_receiver = tmp4_safe_receiver == null ? null : tmp4_safe_receiver.n7r_1;
        var tmp6_safe_receiver = tmp5_safe_receiver == null ? null : tmp5_safe_receiver.g7s_1;
        if (tmp6_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          this.h7u_1 = tmp6_safe_receiver;
        }

        break;
      case 'content_block_start':
        var block = chunk.t7s_1;
        var tmp7_elvis_lhs = chunk.r7s_1;
        var index = tmp7_elvis_lhs == null ? 0 : tmp7_elvis_lhs;
        switch (block == null ? null : block.r7r_1) {
          case 'tool_use':
            var tmp4 = this.c7u_1;
            var tmp10_elvis_lhs = block.s7r_1;
            var tmp_1 = tmp10_elvis_lhs == null ? '' : tmp10_elvis_lhs;
            var tmp11_elvis_lhs = block.t7r_1;
            // Inline function 'kotlin.collections.set' call

            var value = new ToolAcc(tmp_1, tmp11_elvis_lhs == null ? '' : tmp11_elvis_lhs);
            tmp4.k3(index, value);
            break;
          case 'thinking':
            var tmp7 = this.d7u_1;
            // Inline function 'kotlin.collections.set' call

            var value_0 = new ThinkingAcc(VOID, VOID, VOID, 'thinking');
            tmp7.k3(index, value_0);
            break;
          case 'redacted_thinking':
            var tmp10 = this.d7u_1;
            var tmp12_redacted = block.u7r_1;
            // Inline function 'kotlin.collections.set' call

            var value_1 = new ThinkingAcc(VOID, VOID, tmp12_redacted, 'redacted_thinking');
            tmp10.k3(index, value_1);
            break;
        }

        break;
      case 'content_block_delta':
        var delta = chunk.u7s_1;
        switch (delta == null ? null : delta.y7r_1) {
          case 'text_delta':
            var tmp15_safe_receiver = delta.z7r_1;
            if (tmp15_safe_receiver == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              // Inline function 'kotlin.text.isNotEmpty' call
              if (charSequenceLength(tmp15_safe_receiver) > 0) {
                this.f7u_1.tb(tmp15_safe_receiver);
                // Inline function 'kotlin.collections.plusAssign' call
                var element_0 = new TextDelta(tmp15_safe_receiver, this.g7u_1);
                events.l(element_0);
              }
            }

            break;
          case 'thinking_delta':
            var tmp16_safe_receiver = delta.a7s_1;
            if (tmp16_safe_receiver == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              var tmp0_safe_receiver = chunk.r7s_1;
              if (tmp0_safe_receiver == null)
                null;
              else {
                // Inline function 'kotlin.let' call
                var tmp0_safe_receiver_0 = this.d7u_1.h3(tmp0_safe_receiver);
                var tmp1_safe_receiver_0 = tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.x7t_1;
                tmp1_safe_receiver_0 == null || tmp1_safe_receiver_0.tb(tmp16_safe_receiver);
              }
              // Inline function 'kotlin.text.isNotEmpty' call
              if (charSequenceLength(tmp16_safe_receiver) > 0) {
                // Inline function 'kotlin.collections.plusAssign' call
                var element_1 = new ReasoningDelta(tmp16_safe_receiver);
                events.l(element_1);
              }
            }

            break;
          case 'signature_delta':
            var tmp17_safe_receiver = delta.b7s_1;
            if (tmp17_safe_receiver == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              var tmp0_safe_receiver_1 = chunk.r7s_1;
              var tmp_2;
              if (tmp0_safe_receiver_1 == null) {
                tmp_2 = null;
              } else {
                // Inline function 'kotlin.let' call
                var tmp0_safe_receiver_2 = this.d7u_1.h3(tmp0_safe_receiver_1);
                var tmp1_safe_receiver_1 = tmp0_safe_receiver_2 == null ? null : tmp0_safe_receiver_2.y7t_1;
                tmp_2 = tmp1_safe_receiver_1 == null ? null : tmp1_safe_receiver_1.tb(tmp17_safe_receiver);
              }
            }

            break;
          case 'input_json_delta':
            var tmp18_elvis_lhs = chunk.r7s_1;
            var tmp_3;
            if (tmp18_elvis_lhs == null) {
              return events;
            } else {
              tmp_3 = tmp18_elvis_lhs;
            }

            var index_0 = tmp_3;
            var tmp19_elvis_lhs = this.c7u_1.h3(index_0);
            var tmp_4;
            if (tmp19_elvis_lhs == null) {
              return events;
            } else {
              tmp_4 = tmp19_elvis_lhs;
            }

            var acc = tmp_4;
            var tmp20_elvis_lhs = delta.c7s_1;
            var tmp_5;
            if (tmp20_elvis_lhs == null) {
              return events;
            } else {
              tmp_5 = tmp20_elvis_lhs;
            }

            var fragment = tmp_5;
            acc.v7t_1.tb(fragment);
            // Inline function 'kotlin.collections.plusAssign' call

            var element_2 = new ToolCallDelta(acc.t7t_1, index_0, VOID, fragment, acc.w7t_1);
            events.l(element_2);
            break;
        }

        break;
      case 'content_block_stop':
        var tmp21_elvis_lhs = chunk.r7s_1;
        var tmp_6;
        if (tmp21_elvis_lhs == null) {
          return events;
        } else {
          tmp_6 = tmp21_elvis_lhs;
        }

        var index_1 = tmp_6;
        var tmp22_safe_receiver = this.d7u_1.l3(index_1);
        if (tmp22_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          var tmp_7;
          if (tmp22_safe_receiver.a7u_1 === 'redacted_thinking') {
            var tmp0_elvis_lhs = tmp22_safe_receiver.z7t_1;
            tmp_7 = new RedactedThinking(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs);
          } else {
            var tmp_8 = tmp22_safe_receiver.x7t_1.toString();
            // Inline function 'kotlin.text.ifBlank' call
            var this_0 = tmp22_safe_receiver.y7t_1.toString();
            var tmp_9;
            if (isBlank(this_0)) {
              tmp_9 = null;
            } else {
              tmp_9 = this_0;
            }
            var tmp$ret$23 = tmp_9;
            tmp_7 = new Thinking(tmp_8, tmp$ret$23);
          }
          var block_0 = tmp_7;
          var tmp_10 = Companion_getInstance().s6c_1;
          // Inline function 'kotlin.text.ifBlank' call
          var this_1 = tmp22_safe_receiver.x7t_1.toString();
          var tmp_11;
          if (isBlank(this_1)) {
            tmp_11 = '[redacted thinking]';
          } else {
            tmp_11 = this_1;
          }
          var tmp$ret$25 = tmp_11;
          var item = new ProviderItem(tmp22_safe_receiver.b7u_1, VOID, tmp_10, tmp22_safe_receiver.a7u_1, tmp$ret$25, ReplayPolicy_Required_getInstance(), Companion_getInstance_0().d40(JsonUtil_getInstance().d6f(block_0, Companion_instance_10.r3o())));
          // Inline function 'kotlin.collections.plusAssign' call
          this.e7u_1.l(item);
          // Inline function 'kotlin.collections.plusAssign' call
          var element_3 = new ItemAdded(item);
          events.l(element_3);
        }

        break;
      case 'message_delta':
        var tmp23_safe_receiver = chunk.v7s_1;
        var tmp24_safe_receiver = tmp23_safe_receiver == null ? null : tmp23_safe_receiver.h7s_1;
        if (tmp24_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          this.i7u_1 = tmp24_safe_receiver;
        }

        break;
    }
    return events;
  }
  g6g() {
    if (this.l7u_1)
      return emptyList();
    if (!(this.k7u_1 == null))
      return finishFailed(this);
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    // Inline function 'kotlin.text.isNotEmpty' call
    var this_0 = this.f7u_1;
    if (charSequenceLength(this_0) > 0) {
      var tmp1 = this.e7u_1;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = Companion_instance_0.t5t(this.f7u_1.toString(), this.g7u_1);
      tmp1.l(element);
    }
    // Inline function 'kotlin.collections.sortedBy' call
    var this_1 = this.c7u_1.l1();
    // Inline function 'kotlin.comparisons.compareBy' call
    var tmp = AnthropicWireDecoder$finish$lambda;
    var tmp$ret$3 = new sam$kotlin_Comparator$0(tmp);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = sortedWith(this_1, tmp$ret$3).y();
    while (_iterator__ex2g4s.z()) {
      var element_0 = _iterator__ex2g4s.a1();
      // Inline function 'kotlin.collections.component2' call
      var acc = element_0.n1();
      var tmp_0 = _ItemRef___get_value__impl__fpjuyb(acc.w7t_1);
      // Inline function 'kotlin.text.ifBlank' call
      var this_2 = acc.v7t_1.toString();
      var tmp_1;
      if (isBlank(this_2)) {
        tmp_1 = '{}';
      } else {
        tmp_1 = this_2;
      }
      var tmp$ret$7 = tmp_1;
      var call = new ToolCall_0(tmp_0, acc.u7t_1, tmp$ret$7, new ProviderScopedId(Companion_getInstance().s6c_1, acc.t7t_1));
      var tmp2 = this.e7u_1;
      // Inline function 'kotlin.collections.plusAssign' call
      var element_1 = call.o60();
      tmp2.l(element_1);
      // Inline function 'kotlin.collections.plusAssign' call
      var element_2 = new ToolCallCompleted(call);
      events.l(element_2);
    }
    this.l7u_1 = true;
    // Inline function 'kotlin.collections.plusAssign' call
    var element_3 = new Finished(new Completed(VOID, toList(this.e7u_1), new Usage(this.h7u_1, this.i7u_1, this.h7u_1 + this.i7u_1 | 0, this.j7u_1)));
    events.l(element_3);
    return events;
  }
}
//endregion
function toAnthropicMessages(items) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var out = ArrayList.k();
  // Inline function 'kotlin.collections.filterNot' call
  // Inline function 'kotlin.collections.filterNotTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = items.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp;
    if (element instanceof Message) {
      tmp = element.r5o_1.equals(Role_SYSTEM_getInstance());
    } else {
      tmp = false;
    }
    if (!tmp) {
      destination.l(element);
    }
  }
  var nonSystem = destination;
  var i = 0;
  while (i < nonSystem.b1()) {
    var item = nonSystem.f1(i);
    if (item instanceof ToolResult) {
      // Inline function 'kotlin.collections.mutableListOf' call
      var blocks = ArrayList.k();
      $l$loop: while (true) {
        var tmp_0;
        if (i < nonSystem.b1()) {
          var tmp_1 = nonSystem.f1(i);
          tmp_0 = tmp_1 instanceof ToolResult;
        } else {
          tmp_0 = false;
        }
        if (!tmp_0) {
          break $l$loop;
        }
        var tmp_2 = nonSystem.f1(i);
        var result = tmp_2 instanceof ToolResult ? tmp_2 : THROW_CCE();
        // Inline function 'kotlin.collections.filterIsInstance' call
        // Inline function 'kotlin.collections.filterIsInstanceTo' call
        var destination_0 = ArrayList.k();
        var _iterator__ex2g4s_0 = items.y();
        while (_iterator__ex2g4s_0.z()) {
          var element_0 = _iterator__ex2g4s_0.a1();
          if (element_0 instanceof ToolCall) {
            destination_0.l(element_0);
          }
        }
        var tmp$ret$8;
        $l$block: {
          // Inline function 'kotlin.collections.firstOrNull' call
          var _iterator__ex2g4s_1 = destination_0.y();
          while (_iterator__ex2g4s_1.z()) {
            var element_1 = _iterator__ex2g4s_1.a1();
            if (element_1.x68_1 === result.u68_1) {
              tmp$ret$8 = element_1;
              break $l$block;
            }
          }
          tmp$ret$8 = null;
        }
        var call = tmp$ret$8;
        var tmp1_elvis_lhs = rawFor(call == null ? null : call.y68_1, Companion_getInstance().s6c_1);
        var toolUseId = tmp1_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(result.u68_1) : tmp1_elvis_lhs;
        // Inline function 'kotlin.collections.plusAssign' call
        var element_2 = new ToolResult_0(toolUseId, result.v68_1, result.w68_1);
        blocks.l(element_2);
        i = i + 1 | 0;
      }
      // Inline function 'kotlin.collections.plusAssign' call
      var element_3 = new AnthropicMessage('user', blocks);
      out.l(element_3);
    } else {
      if (item instanceof Message)
        if (item.r5o_1.equals(Role_USER_getInstance())) {
          // Inline function 'kotlin.collections.mutableListOf' call
          var blocks_0 = ArrayList.k();
          // Inline function 'kotlin.collections.filterIsInstance' call
          var tmp0 = item.s5o_1;
          // Inline function 'kotlin.collections.filterIsInstanceTo' call
          var destination_1 = ArrayList.k();
          var _iterator__ex2g4s_2 = tmp0.y();
          while (_iterator__ex2g4s_2.z()) {
            var element_4 = _iterator__ex2g4s_2.a1();
            if (element_4 instanceof Text) {
              destination_1.l(element_4);
            }
          }
          // Inline function 'kotlin.collections.forEach' call
          var _iterator__ex2g4s_3 = destination_1.y();
          while (_iterator__ex2g4s_3.z()) {
            var element_5 = _iterator__ex2g4s_3.a1();
            // Inline function 'kotlin.collections.plusAssign' call
            var element_6 = new Text_0(element_5.p6b_1);
            blocks_0.l(element_6);
          }
          if (blocks_0.h1()) {
            // Inline function 'kotlin.collections.plusAssign' call
            var element_7 = new Text_0(item.m5t());
            blocks_0.l(element_7);
          }
          // Inline function 'kotlin.collections.plusAssign' call
          var element_8 = new AnthropicMessage('user', blocks_0);
          out.l(element_8);
          i = i + 1 | 0;
        } else {
          i = consumeAssistantTurn(nonSystem, i, out);
        }
       else {
        var tmp_3;
        if (item instanceof ToolCall) {
          tmp_3 = true;
        } else {
          var tmp_4;
          if (item instanceof ProviderItem) {
            tmp_4 = true;
          } else {
            tmp_4 = item instanceof ReasoningSummary;
          }
          tmp_3 = tmp_4;
        }
        if (tmp_3) {
          i = consumeAssistantTurn(nonSystem, i, out);
        } else {
          noWhenBranchMatchedException();
        }
      }
    }
  }
  return out;
}
function consumeAssistantTurn(items, start, out) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var blocks = ArrayList.k();
  var i = start;
  $l$loop_0: while (i < items.b1()) {
    var item = items.f1(i);
    if (item instanceof ProviderItem) {
      if (item.v5y_1 === Companion_getInstance().s6c_1 && (item.w5y_1 === 'thinking' || item.w5y_1 === 'redacted_thinking')) {
        var json = item.z5y_1.s42();
        // Inline function 'kotlin.runCatching' call
        var tmp;
        try {
          // Inline function 'kotlin.Companion.success' call
          var value = JsonUtil_getInstance().e6f(json, Companion_instance_10.r3o());
          tmp = _Result___init__impl__xyqfz8(value);
        } catch ($p) {
          var tmp_0;
          if ($p instanceof Error) {
            var e = $p;
            // Inline function 'kotlin.Companion.failure' call
            tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
          } else {
            throw $p;
          }
          tmp = tmp_0;
        }
        // Inline function 'kotlin.getOrElse' call
        var this_0 = tmp;
        var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
        var tmp_1;
        if (exception == null) {
          var tmp_2 = _Result___get_value__impl__bjfvqg(this_0);
          tmp_1 = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
        } else {
          throw AgentFrameworkException.i5t(new PreparationError('anthropic', 'failed to replay ' + item.w5y_1 + ' block', exception));
        }
        var block = tmp_1;
        // Inline function 'kotlin.collections.plusAssign' call
        blocks.l(block);
      } else {
        ensureDroppable(item, 'anthropic');
      }
      i = i + 1 | 0;
    } else {
      if (item instanceof Message) {
        if (!item.r5o_1.equals(Role_ASSISTANT_getInstance()))
          break $l$loop_0;
        // Inline function 'kotlin.text.isNotEmpty' call
        var this_1 = item.m5t();
        if (charSequenceLength(this_1) > 0) {
          // Inline function 'kotlin.collections.plusAssign' call
          var element = new Text_0(item.m5t());
          blocks.l(element);
        }
        i = i + 1 | 0;
      } else {
        if (item instanceof ToolCall) {
          var tmp0_elvis_lhs = rawFor(item.y68_1, Companion_getInstance().s6c_1);
          var tmp_3 = tmp0_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(item.x68_1) : tmp0_elvis_lhs;
          var tmp_4 = JsonUtil_getInstance().c6f_1;
          // Inline function 'kotlin.text.ifBlank' call
          var this_2 = item.a69_1;
          var tmp_5;
          if (isBlank(this_2)) {
            tmp_5 = '{}';
          } else {
            tmp_5 = this_2;
          }
          var tmp$ret$10 = tmp_5;
          // Inline function 'kotlin.collections.plusAssign' call
          var element_0 = new ToolUse(tmp_3, item.z68_1, tmp_4.q3m(tmp$ret$10));
          blocks.l(element_0);
          i = i + 1 | 0;
        } else {
          if (item instanceof ReasoningSummary) {
            i = i + 1 | 0;
          } else {
            if (item instanceof ToolResult)
              break $l$loop_0;
            else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
  }
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!blocks.h1()) {
    // Inline function 'kotlin.collections.plusAssign' call
    var element_1 = new AnthropicMessage('assistant', blocks);
    out.l(element_1);
  }
  return i;
}
function AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r() {
  return new ArrayListSerializer($serializer_getInstance_0());
}
function AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r_0() {
  return new ArrayListSerializer($serializer_getInstance_1());
}
function AnthropicChatRequest$Companion$$childSerializers$_anonymous__xol89r_1() {
  return new ArrayListSerializer(StringSerializer_getInstance());
}
var Companion_instance_2;
function Companion_getInstance_1() {
  if (Companion_instance_2 === VOID)
    new Companion();
  return Companion_instance_2;
}
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance === VOID)
    new $serializer();
  return $serializer_instance;
}
function AnthropicMessage$Companion$$childSerializers$_anonymous__qndbyp() {
  var tmp = getKClass(AnthropicContentBlock);
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_0 = [getKClass(RedactedThinking), getKClass(Text_0), getKClass(Thinking), getKClass(ToolResult_0), getKClass(ToolUse)];
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp_1 = [$serializer_getInstance_3(), $serializer_getInstance_4(), $serializer_getInstance_2(), $serializer_getInstance_6(), $serializer_getInstance_5()];
  // Inline function 'kotlin.arrayOf' call
  // Inline function 'kotlin.js.unsafeCast' call
  // Inline function 'kotlin.js.asDynamic' call
  var tmp$ret$8 = [];
  return new ArrayListSerializer(SealedClassSerializer.c1v('org.koaks.provider.anthropic.AnthropicContentBlock', tmp, tmp_0, tmp_1, tmp$ret$8));
}
var Companion_instance_3;
function Companion_getInstance_2() {
  if (Companion_instance_3 === VOID)
    new Companion_0();
  return Companion_instance_3;
}
var $serializer_instance_0;
function $serializer_getInstance_0() {
  if ($serializer_instance_0 === VOID)
    new $serializer_0();
  return $serializer_instance_0;
}
var Companion_instance_4;
function Companion_getInstance_3() {
  return Companion_instance_4;
}
var $serializer_instance_1;
function $serializer_getInstance_1() {
  if ($serializer_instance_1 === VOID)
    new $serializer_1();
  return $serializer_instance_1;
}
var Companion_instance_5;
function Companion_getInstance_4() {
  return Companion_instance_5;
}
var $serializer_instance_2;
function $serializer_getInstance_2() {
  if ($serializer_instance_2 === VOID)
    new $serializer_2();
  return $serializer_instance_2;
}
var Companion_instance_6;
function Companion_getInstance_5() {
  return Companion_instance_6;
}
var $serializer_instance_3;
function $serializer_getInstance_3() {
  if ($serializer_instance_3 === VOID)
    new $serializer_3();
  return $serializer_instance_3;
}
var Companion_instance_7;
function Companion_getInstance_6() {
  return Companion_instance_7;
}
var $serializer_instance_4;
function $serializer_getInstance_4() {
  if ($serializer_instance_4 === VOID)
    new $serializer_4();
  return $serializer_instance_4;
}
var Companion_instance_8;
function Companion_getInstance_7() {
  return Companion_instance_8;
}
var $serializer_instance_5;
function $serializer_getInstance_5() {
  if ($serializer_instance_5 === VOID)
    new $serializer_5();
  return $serializer_instance_5;
}
var Companion_instance_9;
function Companion_getInstance_8() {
  return Companion_instance_9;
}
var $serializer_instance_6;
function $serializer_getInstance_6() {
  if ($serializer_instance_6 === VOID)
    new $serializer_6();
  return $serializer_instance_6;
}
var Companion_instance_10;
function Companion_getInstance_9() {
  return Companion_instance_10;
}
var Companion_instance_11;
function Companion_getInstance_10() {
  return Companion_instance_11;
}
var $serializer_instance_7;
function $serializer_getInstance_7() {
  if ($serializer_instance_7 === VOID)
    new $serializer_7();
  return $serializer_instance_7;
}
var Companion_instance_12;
function Companion_getInstance_11() {
  return Companion_instance_12;
}
var $serializer_instance_8;
function $serializer_getInstance_8() {
  if ($serializer_instance_8 === VOID)
    new $serializer_8();
  return $serializer_instance_8;
}
var Companion_instance_13;
function Companion_getInstance_12() {
  return Companion_instance_13;
}
var $serializer_instance_9;
function $serializer_getInstance_9() {
  if ($serializer_instance_9 === VOID)
    new $serializer_9();
  return $serializer_instance_9;
}
var Companion_instance_14;
function Companion_getInstance_13() {
  return Companion_instance_14;
}
var $serializer_instance_10;
function $serializer_getInstance_10() {
  if ($serializer_instance_10 === VOID)
    new $serializer_10();
  return $serializer_instance_10;
}
var Companion_instance_15;
function Companion_getInstance_14() {
  return Companion_instance_15;
}
var $serializer_instance_11;
function $serializer_getInstance_11() {
  if ($serializer_instance_11 === VOID)
    new $serializer_11();
  return $serializer_instance_11;
}
var Companion_instance_16;
function Companion_getInstance_15() {
  return Companion_instance_16;
}
var $serializer_instance_12;
function $serializer_getInstance_12() {
  if ($serializer_instance_12 === VOID)
    new $serializer_12();
  return $serializer_instance_12;
}
function anthropic(_this__u8e3s4, baseUrl, apiKey, modelName, block) {
  baseUrl = baseUrl === VOID ? 'https://api.anthropic.com/v1/messages' : baseUrl;
  var tmp;
  if (block === VOID) {
    tmp = anthropic$lambda;
  } else {
    tmp = block;
  }
  block = tmp;
  // Inline function 'kotlin.apply' call
  var this_0 = new AnthropicConfig(baseUrl, apiKey, modelName);
  block(this_0);
  var cfg = this_0;
  return _this__u8e3s4.t5z(new AnthropicChatModel(cfg.k7t(), _this__u8e3s4.v5z(), cfg.l7t(), cfg.m7t()));
}
function normalizeAnthropicMessagesUrl(baseUrl) {
  // Inline function 'kotlin.text.trim' call
  var tmp$ret$0 = toString_0(trim(isCharSequence(baseUrl) ? baseUrl : THROW_CCE()));
  var trimmed = trimEnd(tmp$ret$0, charArrayOf([_Char___init__impl__6a9atx(47)]));
  return endsWith(trimmed, '/messages') ? trimmed : trimmed + '/v1/messages';
}
function anthropic$lambda(_this__u8e3s4) {
  return Unit_instance;
}
function finishFailed($this) {
  if ($this.l7u_1)
    return emptyList();
  $this.l7u_1 = true;
  return listOf(new Finished(new Failed(ensureNotNull($this.k7u_1), VOID, VOID, new Usage($this.h7u_1, $this.i7u_1, $this.h7u_1 + $this.i7u_1 | 0))));
}
function AnthropicWireDecoder$finish$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = a.m1();
  var tmp$ret$1 = b.m1();
  return compareValues(tmp, tmp$ret$1);
}
//region block: post-declaration
initMetadataForClass(AnthropicChatModel, 'AnthropicChatModel', VOID, VOID, VOID, [1]);
initMetadataForClass(AnthropicParams, 'AnthropicParams', AnthropicParams);
initMetadataForCompanion(Companion);
protoOf($serializer).k26 = typeParametersSerializers;
initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(AnthropicChatRequest, 'AnthropicChatRequest', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
initMetadataForCompanion(Companion_0);
protoOf($serializer_0).k26 = typeParametersSerializers;
initMetadataForObject($serializer_0, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(AnthropicMessage, 'AnthropicMessage', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
initMetadataForCompanion(Companion_1);
protoOf($serializer_1).k26 = typeParametersSerializers;
initMetadataForObject($serializer_1, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(AnthropicTool, 'AnthropicTool', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_1});
initMetadataForCompanion(Companion_2);
protoOf($serializer_2).k26 = typeParametersSerializers;
initMetadataForObject($serializer_2, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_3);
protoOf($serializer_3).k26 = typeParametersSerializers;
initMetadataForObject($serializer_3, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_4);
protoOf($serializer_4).k26 = typeParametersSerializers;
initMetadataForObject($serializer_4, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_5);
protoOf($serializer_5).k26 = typeParametersSerializers;
initMetadataForObject($serializer_5, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_6);
protoOf($serializer_6).k26 = typeParametersSerializers;
initMetadataForObject($serializer_6, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForInterface(AnthropicContentBlock, 'AnthropicContentBlock', VOID, VOID, VOID, VOID, VOID, {0: Companion_getInstance_9});
initMetadataForClass(Thinking, 'Thinking', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_2});
initMetadataForClass(RedactedThinking, 'RedactedThinking', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_3});
initMetadataForClass(Text_0, 'Text', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_4});
initMetadataForClass(ToolUse, 'ToolUse', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_5});
initMetadataForClass(ToolResult_0, 'ToolResult', VOID, VOID, [AnthropicContentBlock], VOID, VOID, {0: $serializer_getInstance_6});
initMetadataForCompanion(Companion_7, VOID, [SerializerFactory]);
initMetadataForCompanion(Companion_8);
protoOf($serializer_7).k26 = typeParametersSerializers;
initMetadataForObject($serializer_7, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_9);
protoOf($serializer_8).k26 = typeParametersSerializers;
initMetadataForObject($serializer_8, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_10);
protoOf($serializer_9).k26 = typeParametersSerializers;
initMetadataForObject($serializer_9, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_11);
protoOf($serializer_10).k26 = typeParametersSerializers;
initMetadataForObject($serializer_10, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForCompanion(Companion_12);
protoOf($serializer_11).k26 = typeParametersSerializers;
initMetadataForObject($serializer_11, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(Message_0, 'Message', Message_0, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_7});
initMetadataForClass(ContentBlock, 'ContentBlock', ContentBlock, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_8});
initMetadataForClass(Delta, 'Delta', Delta, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_9});
initMetadataForClass(Usage_0, 'Usage', Usage_0, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_10});
initMetadataForClass(ErrorOutput, 'ErrorOutput', ErrorOutput, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_11});
initMetadataForCompanion(Companion_13);
protoOf($serializer_12).k26 = typeParametersSerializers;
initMetadataForObject($serializer_12, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(AnthropicChatResponse, 'AnthropicChatResponse', AnthropicChatResponse, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_12});
initMetadataForClass(AnthropicConfig, 'AnthropicConfig');
initMetadataForClass(AnthropicCapabilitiesScope, 'AnthropicCapabilitiesScope');
initMetadataForClass(ToolAcc, 'ToolAcc');
initMetadataForClass(ThinkingAcc, 'ThinkingAcc');
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(AnthropicWireDecoder, 'AnthropicWireDecoder', AnthropicWireDecoder);
//endregion
//region block: init
Companion_instance_4 = new Companion_1();
Companion_instance_5 = new Companion_2();
Companion_instance_6 = new Companion_3();
Companion_instance_7 = new Companion_4();
Companion_instance_8 = new Companion_5();
Companion_instance_9 = new Companion_6();
Companion_instance_10 = new Companion_7();
Companion_instance_11 = new Companion_8();
Companion_instance_12 = new Companion_9();
Companion_instance_13 = new Companion_10();
Companion_instance_14 = new Companion_11();
Companion_instance_15 = new Companion_12();
Companion_instance_16 = new Companion_13();
//endregion
//region block: exports
export {
  anthropic as anthropic200c8euko87qc,
};
//endregion

//# sourceMappingURL=koaks-model-provider-anthropic.mjs.map
