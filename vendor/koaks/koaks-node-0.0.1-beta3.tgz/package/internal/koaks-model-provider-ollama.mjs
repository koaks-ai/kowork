import {
  ChatModel1ekuxcd3gk3yy as ChatModel,
  Support_Unsupported_getInstance2l560r5zg87nd as Support_Unsupported_getInstance,
  ModelCapabilities1z2n3zkdibnvb as ModelCapabilities,
  JsonUtil_getInstance3itlrleq4m1cs as JsonUtil_getInstance,
  HttpMethod_POST_getInstance2vunzl2e30rwd as HttpMethod_POST_getInstance,
  authHeaders3pbiyo76b6dd9 as authHeaders,
  Framing_Ndjson_getInstance2grbeiiobprd as Framing_Ndjson_getInstance,
  timeoutsvuf8aepeqg28 as timeouts,
  WireCall3namx761k5vmg as WireCall,
  JsonSchema1bzd59uqo2uv as JsonSchema,
  JsonObject_instance30hvkp8z8mfx9 as JsonObject_instance,
  Text_instance936fuxqirkv3 as Text_instance,
  ensureDroppable3mu5lhcnsp146 as ensureDroppable,
  ProviderItem17hp0vuxmlwze as ProviderItem,
  ReasoningSummary2dl0lxzty5z0 as ReasoningSummary,
  ToolResult2fndzcq38kgpy as ToolResult,
  ToolCall27jatgdodcelb as ToolCall,
  Image2x6strlw6vlny as Image,
  Message1x6kaj8ypdoee as Message,
  ModelConfig4o28u6uqe7xk as ModelConfig,
  Support_Supported_getInstance2iy50h3ebt6qe as Support_Supported_getInstance,
  Support_Unknown_getInstance3blv79i14mlk4 as Support_Unknown_getInstance,
  Failed2mkg32d93x5tt as Failed,
  Finished4z9e5g7v1wyk as Finished,
  Companion_instance13097inxmcdi as Companion_instance,
  Companion_getInstance2m4xts4fuklfa as Companion_getInstance,
  ModelErrori9ofbqyilwwf as ModelError,
  HttpError1wj82nej166el as HttpError,
  Body2ccosqk3y8ycb as Body,
  Sset7uvtqde4kyu as Sse,
  Ndjson1kkk3x9modr28 as Ndjson,
  Started1sf5a44qjgp0u as Started,
  Usage3sdv1daz6y20z as Usage,
  ReasoningDeltaytmmln995w27 as ReasoningDelta,
  TextDeltaq9h7728thclc as TextDelta,
  _ItemRef___get_value__impl__fpjuyb3vqbahagzpip9 as _ItemRef___get_value__impl__fpjuyb,
  Companion_getInstance3ot1bqjky10hu as Companion_getInstance_0,
  ProviderScopedId2kn7so5x8kdlf as ProviderScopedId,
  ToolCallsfyoaxshhyk as ToolCall_0,
  ToolCallDelta1owom9vbem28s as ToolCallDelta,
  Companion_instancelgypg95btxw8 as Companion_instance_0,
  ToolCallCompleted225u0jsfjmco7 as ToolCallCompleted,
  Completedf7bahq5rqxjz as Completed,
} from './koaks-core.mjs';
import {
  VOID7hggqo3abtya as VOID,
  ArrayList3it5z8td81qkl as ArrayList,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  Unit_instance104q5opgivhr8 as Unit_instance,
  equals2au1ep9vhcato as equals,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  toString30pk9tzaqopn as toString,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  isBlank1dvkhjjvox3p0 as isBlank,
  lastOrNull1aq5oz189qoe1 as lastOrNull,
  listOfvhqybd2zx248 as listOf,
  get_lastIndex1yw0x4k50k51w as get_lastIndex,
  emptyList1g2z5xcrvp2zy as emptyList,
  plus20p0vtfmu0596 as plus,
  Companion_instance3fplhgf4ipvld as Companion_instance_1,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  emptyMapr06gerzljqtm as emptyMap,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  toString1pkumu07cwy4m as toString_0,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  createThis2j2avj17cvnv2 as createThis,
  Long2qws0ah9gnpki as Long,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  StringBuildermazzzhj6kkai as StringBuilder,
  plus310ted5e4i90h as plus_0,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  toList3jhuyej2anx2q as toList,
} from './kotlin-kotlin-stdlib.mjs';
import {
  get_jsonObject2u4z2ch1uuca9 as get_jsonObject,
  JsonObjectee06ihoeeiqj as JsonObject,
  Jsonsmkyu9xjl7fv as Json,
  JsonObjectSerializer_getInstance197qdg6ernwdp as JsonObjectSerializer_getInstance,
} from './kotlinx-serialization-kotlinx-serialization-json.mjs';
import {
  ArrayListSerializer7k5wnrulb3y6 as ArrayListSerializer,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  StringSerializer_getInstance1k1oz5j50sfik as StringSerializer_getInstance,
  BooleanSerializer_getInstancet3wtk7fl7i4f as BooleanSerializer_getInstance,
  UnknownFieldExceptiona60e3a6v1xqo as UnknownFieldException,
  get_nullable197rfua9r7fsz as get_nullable,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
  DoubleSerializer_getInstance2avi1jm48x8le as DoubleSerializer_getInstance,
  IntSerializer_getInstance9scrtcljaiv6 as IntSerializer_getInstance,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class OllamaChatModel extends ChatModel {
  constructor(config, transport, params, capabilities) {
    params = params === VOID ? new OllamaParams() : params;
    capabilities = capabilities === VOID ? new ModelCapabilities(Support_Unsupported_getInstance()) : capabilities;
    super(config, transport);
    this.t7k_1 = params;
    this.u7k_1 = capabilities;
  }
  a5p() {
    return this.u7k_1;
  }
  y1s() {
    return new OllamaWireDecoder();
  }
  j6g(req) {
    var body = JsonUtil_getInstance().d6f(this.v7k(req), Companion_getInstance_1().r3o());
    return new WireCall(HttpMethod_POST_getInstance(), this.c6g_1.n6g_1, authHeaders(this.c6g_1), body, Framing_Ndjson_getInstance(), req.g5y_1, timeouts(this.c6g_1), this.c6g_1.w6g_1, this.c6g_1.x6g_1);
  }
  v7k(req) {
    var options = new OllamaOptions(this.t7k_1.x7k_1, this.t7k_1.y7k_1, this.t7k_1.z7k_1, this.t7k_1.a7l_1);
    var tmp = toOllamaMessages(req);
    // Inline function 'kotlin.takeIf' call
    var this_0 = req.d5y_1;
    var tmp_0;
    // Inline function 'kotlin.collections.isNotEmpty' call
    if (!this_0.h1()) {
      tmp_0 = this_0;
    } else {
      tmp_0 = null;
    }
    var tmp0_safe_receiver = tmp_0;
    var tmp_1;
    if (tmp0_safe_receiver == null) {
      tmp_1 = null;
    } else {
      // Inline function 'kotlin.collections.map' call
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(collectionSizeOrDefault(tmp0_safe_receiver, 10));
      var _iterator__ex2g4s = tmp0_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var item = _iterator__ex2g4s.a1();
        var tmp$ret$3 = new OllamaTool(VOID, new OllamaFunctionDef(item.c6k_1, item.d6k_1, item.e6k_1));
        destination.l(tmp$ret$3);
      }
      tmp_1 = destination;
    }
    var tmp_2 = tmp_1;
    var tmp1_subject = req.e5y_1;
    var tmp_3;
    if (equals(tmp1_subject, Text_instance)) {
      tmp_3 = null;
    } else {
      var tmp_4;
      if (equals(tmp1_subject, JsonObject_instance)) {
        tmp_4 = true;
      } else {
        tmp_4 = tmp1_subject instanceof JsonSchema;
      }
      if (tmp_4) {
        tmp_3 = 'json';
      } else {
        noWhenBranchMatchedException();
      }
    }
    var tmp_5 = tmp_3;
    // Inline function 'kotlin.takeIf' call
    var tmp_6;
    if (!options.equals(new OllamaOptions())) {
      tmp_6 = options;
    } else {
      tmp_6 = null;
    }
    var tmp$ret$7 = tmp_6;
    return new OllamaChatRequest(this.c6g_1.p6g_1, tmp, tmp_2, true, tmp_5, this.t7k_1.b7l_1, tmp$ret$7);
  }
}
class OllamaParams {
  constructor(temperature, topP, maxTokens, stop, think) {
    temperature = temperature === VOID ? null : temperature;
    topP = topP === VOID ? null : topP;
    maxTokens = maxTokens === VOID ? null : maxTokens;
    stop = stop === VOID ? null : stop;
    think = think === VOID ? null : think;
    this.x7k_1 = temperature;
    this.y7k_1 = topP;
    this.z7k_1 = maxTokens;
    this.a7l_1 = stop;
    this.b7l_1 = think;
  }
  toString() {
    return 'OllamaParams(temperature=' + this.x7k_1 + ', topP=' + this.y7k_1 + ', maxTokens=' + this.z7k_1 + ', stop=' + toString(this.a7l_1) + ', think=' + this.b7l_1 + ')';
  }
  hashCode() {
    var result = this.x7k_1 == null ? 0 : getNumberHashCode(this.x7k_1);
    result = imul(result, 31) + (this.y7k_1 == null ? 0 : getNumberHashCode(this.y7k_1)) | 0;
    result = imul(result, 31) + (this.z7k_1 == null ? 0 : this.z7k_1) | 0;
    result = imul(result, 31) + (this.a7l_1 == null ? 0 : hashCode(this.a7l_1)) | 0;
    result = imul(result, 31) + (this.b7l_1 == null ? 0 : getBooleanHashCode(this.b7l_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaParams))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaParams ? other : THROW_CCE();
    if (!equals(this.x7k_1, tmp0_other_with_cast.x7k_1))
      return false;
    if (!equals(this.y7k_1, tmp0_other_with_cast.y7k_1))
      return false;
    if (!(this.z7k_1 == tmp0_other_with_cast.z7k_1))
      return false;
    if (!equals(this.a7l_1, tmp0_other_with_cast.a7l_1))
      return false;
    if (!(this.b7l_1 == tmp0_other_with_cast.b7l_1))
      return false;
    return true;
  }
}
class Companion {
  constructor() {
    Companion_instance_2 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_1 = lazy(tmp_0, OllamaChatRequest$Companion$$childSerializers$_anonymous__6xlh2f);
    var tmp_2 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.w7k_1 = [null, tmp_1, lazy(tmp_2, OllamaChatRequest$Companion$$childSerializers$_anonymous__6xlh2f_0), null, null, null, null];
  }
  r3o() {
    return $serializer_getInstance();
  }
}
class $serializer {
  constructor() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaChatRequest', this, 7);
    tmp0_serialDesc.u25('model', false);
    tmp0_serialDesc.u25('messages', false);
    tmp0_serialDesc.u25('tools', true);
    tmp0_serialDesc.u25('stream', true);
    tmp0_serialDesc.u25('format', true);
    tmp0_serialDesc.u25('think', true);
    tmp0_serialDesc.u25('options', true);
    this.h7l_1 = tmp0_serialDesc;
  }
  i7l(encoder, value) {
    var tmp0_desc = this.h7l_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_1().w7k_1;
    tmp1_output.v1z(tmp0_desc, 0, value.j7l_1);
    tmp1_output.x1z(tmp0_desc, 1, tmp2_cached[1].n1(), value.k7l_1);
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.l7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.l7l_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.m7l_1 === true)) {
      tmp1_output.n1z(tmp0_desc, 3, value.m7l_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.n7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 4, StringSerializer_getInstance(), value.n7l_1);
    }
    if (tmp1_output.d20(tmp0_desc, 5) ? true : !(value.o7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 5, BooleanSerializer_getInstance(), value.o7l_1);
    }
    if (tmp1_output.d20(tmp0_desc, 6) ? true : !(value.p7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 6, $serializer_getInstance_0(), value.p7l_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.i7l(encoder, value instanceof OllamaChatRequest ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.h7l_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = false;
    var tmp8_local4 = null;
    var tmp9_local5 = null;
    var tmp10_local6 = null;
    var tmp11_input = decoder.f1y(tmp0_desc);
    var tmp12_cached = Companion_getInstance_1().w7k_1;
    if (tmp11_input.v1y()) {
      tmp4_local0 = tmp11_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp11_input.r1y(tmp0_desc, 1, tmp12_cached[1].n1(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp11_input.t1y(tmp0_desc, 2, tmp12_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp11_input.h1y(tmp0_desc, 3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp11_input.t1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp11_input.t1y(tmp0_desc, 5, BooleanSerializer_getInstance(), tmp9_local5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp11_input.t1y(tmp0_desc, 6, $serializer_getInstance_0(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp11_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp11_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp11_input.r1y(tmp0_desc, 1, tmp12_cached[1].n1(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp11_input.t1y(tmp0_desc, 2, tmp12_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp11_input.h1y(tmp0_desc, 3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp11_input.t1y(tmp0_desc, 4, StringSerializer_getInstance(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp11_input.t1y(tmp0_desc, 5, BooleanSerializer_getInstance(), tmp9_local5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp11_input.t1y(tmp0_desc, 6, $serializer_getInstance_0(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp11_input.g1y(tmp0_desc);
    return OllamaChatRequest.q7l(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, null);
  }
  w1t() {
    return this.h7l_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_1().w7k_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), tmp0_cached[1].n1(), get_nullable(tmp0_cached[2].n1()), BooleanSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(BooleanSerializer_getInstance()), get_nullable($serializer_getInstance_0())];
  }
}
class OllamaChatRequest {
  constructor(model, messages, tools, stream, format, think, options) {
    Companion_getInstance_1();
    tools = tools === VOID ? null : tools;
    stream = stream === VOID ? true : stream;
    format = format === VOID ? null : format;
    think = think === VOID ? null : think;
    options = options === VOID ? null : options;
    this.j7l_1 = model;
    this.k7l_1 = messages;
    this.l7l_1 = tools;
    this.m7l_1 = stream;
    this.n7l_1 = format;
    this.o7l_1 = think;
    this.p7l_1 = options;
  }
  toString() {
    return 'OllamaChatRequest(model=' + this.j7l_1 + ', messages=' + toString_0(this.k7l_1) + ', tools=' + toString(this.l7l_1) + ', stream=' + this.m7l_1 + ', format=' + this.n7l_1 + ', think=' + this.o7l_1 + ', options=' + toString(this.p7l_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.j7l_1);
    result = imul(result, 31) + hashCode(this.k7l_1) | 0;
    result = imul(result, 31) + (this.l7l_1 == null ? 0 : hashCode(this.l7l_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.m7l_1) | 0;
    result = imul(result, 31) + (this.n7l_1 == null ? 0 : getStringHashCode(this.n7l_1)) | 0;
    result = imul(result, 31) + (this.o7l_1 == null ? 0 : getBooleanHashCode(this.o7l_1)) | 0;
    result = imul(result, 31) + (this.p7l_1 == null ? 0 : this.p7l_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaChatRequest))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaChatRequest ? other : THROW_CCE();
    if (!(this.j7l_1 === tmp0_other_with_cast.j7l_1))
      return false;
    if (!equals(this.k7l_1, tmp0_other_with_cast.k7l_1))
      return false;
    if (!equals(this.l7l_1, tmp0_other_with_cast.l7l_1))
      return false;
    if (!(this.m7l_1 === tmp0_other_with_cast.m7l_1))
      return false;
    if (!(this.n7l_1 == tmp0_other_with_cast.n7l_1))
      return false;
    if (!(this.o7l_1 == tmp0_other_with_cast.o7l_1))
      return false;
    if (!equals(this.p7l_1, tmp0_other_with_cast.p7l_1))
      return false;
    return true;
  }
  static q7l(seen0, model, messages, tools, stream, format, think, options, serializationConstructorMarker) {
    Companion_getInstance_1();
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance().h7l_1);
    }
    var $this = createThis(this);
    $this.j7l_1 = model;
    $this.k7l_1 = messages;
    if (0 === (seen0 & 4))
      $this.l7l_1 = null;
    else
      $this.l7l_1 = tools;
    if (0 === (seen0 & 8))
      $this.m7l_1 = true;
    else
      $this.m7l_1 = stream;
    if (0 === (seen0 & 16))
      $this.n7l_1 = null;
    else
      $this.n7l_1 = format;
    if (0 === (seen0 & 32))
      $this.o7l_1 = null;
    else
      $this.o7l_1 = think;
    if (0 === (seen0 & 64))
      $this.p7l_1 = null;
    else
      $this.p7l_1 = options;
    return $this;
  }
}
class Companion_0 {
  constructor() {
    Companion_instance_3 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.r7l_1 = [null, null, null, lazy(tmp_0, OllamaOptions$Companion$$childSerializers$_anonymous__yv8no2)];
  }
}
class $serializer_0 {
  constructor() {
    $serializer_instance_0 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaOptions', this, 4);
    tmp0_serialDesc.u25('temperature', true);
    tmp0_serialDesc.u25('top_p', true);
    tmp0_serialDesc.u25('num_predict', true);
    tmp0_serialDesc.u25('stop', true);
    this.s7l_1 = tmp0_serialDesc;
  }
  t7l(encoder, value) {
    var tmp0_desc = this.s7l_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_2().r7l_1;
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.u7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, DoubleSerializer_getInstance(), value.u7l_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.v7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, DoubleSerializer_getInstance(), value.v7l_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.w7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, IntSerializer_getInstance(), value.w7l_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.x7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, tmp2_cached[3].n1(), value.x7l_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.t7l(encoder, value instanceof OllamaOptions ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.s7l_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.f1y(tmp0_desc);
    var tmp9_cached = Companion_getInstance_2().r7l_1;
    if (tmp8_input.v1y()) {
      tmp4_local0 = tmp8_input.t1y(tmp0_desc, 0, DoubleSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, DoubleSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, IntSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, tmp9_cached[3].n1(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.t1y(tmp0_desc, 0, DoubleSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.t1y(tmp0_desc, 1, DoubleSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, IntSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, tmp9_cached[3].n1(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp8_input.g1y(tmp0_desc);
    return OllamaOptions.y7l(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  w1t() {
    return this.s7l_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_2().r7l_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(DoubleSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(tmp0_cached[3].n1())];
  }
}
class OllamaOptions {
  constructor(temperature, topP, numPredict, stop) {
    Companion_getInstance_2();
    temperature = temperature === VOID ? null : temperature;
    topP = topP === VOID ? null : topP;
    numPredict = numPredict === VOID ? null : numPredict;
    stop = stop === VOID ? null : stop;
    this.u7l_1 = temperature;
    this.v7l_1 = topP;
    this.w7l_1 = numPredict;
    this.x7l_1 = stop;
  }
  toString() {
    return 'OllamaOptions(temperature=' + this.u7l_1 + ', topP=' + this.v7l_1 + ', numPredict=' + this.w7l_1 + ', stop=' + toString(this.x7l_1) + ')';
  }
  hashCode() {
    var result = this.u7l_1 == null ? 0 : getNumberHashCode(this.u7l_1);
    result = imul(result, 31) + (this.v7l_1 == null ? 0 : getNumberHashCode(this.v7l_1)) | 0;
    result = imul(result, 31) + (this.w7l_1 == null ? 0 : this.w7l_1) | 0;
    result = imul(result, 31) + (this.x7l_1 == null ? 0 : hashCode(this.x7l_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaOptions))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaOptions ? other : THROW_CCE();
    if (!equals(this.u7l_1, tmp0_other_with_cast.u7l_1))
      return false;
    if (!equals(this.v7l_1, tmp0_other_with_cast.v7l_1))
      return false;
    if (!(this.w7l_1 == tmp0_other_with_cast.w7l_1))
      return false;
    if (!equals(this.x7l_1, tmp0_other_with_cast.x7l_1))
      return false;
    return true;
  }
  static y7l(seen0, temperature, topP, numPredict, stop, serializationConstructorMarker) {
    Companion_getInstance_2();
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_0().s7l_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.u7l_1 = null;
    else
      $this.u7l_1 = temperature;
    if (0 === (seen0 & 2))
      $this.v7l_1 = null;
    else
      $this.v7l_1 = topP;
    if (0 === (seen0 & 4))
      $this.w7l_1 = null;
    else
      $this.w7l_1 = numPredict;
    if (0 === (seen0 & 8))
      $this.x7l_1 = null;
    else
      $this.x7l_1 = stop;
    return $this;
  }
}
class Companion_1 {
  constructor() {
    Companion_instance_4 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_1 = lazy(tmp_0, OllamaMessage$Companion$$childSerializers$_anonymous__ecv4bb);
    var tmp_2 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.z7l_1 = [null, null, tmp_1, lazy(tmp_2, OllamaMessage$Companion$$childSerializers$_anonymous__ecv4bb_0)];
  }
}
class $serializer_1 {
  constructor() {
    $serializer_instance_1 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaMessage', this, 4);
    tmp0_serialDesc.u25('role', false);
    tmp0_serialDesc.u25('content', true);
    tmp0_serialDesc.u25('tool_calls', true);
    tmp0_serialDesc.u25('images', true);
    this.a7m_1 = tmp0_serialDesc;
  }
  b7m(encoder, value) {
    var tmp0_desc = this.a7m_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_3().z7l_1;
    tmp1_output.v1z(tmp0_desc, 0, value.c7l_1);
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.d7l_1 === '')) {
      tmp1_output.v1z(tmp0_desc, 1, value.d7l_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.e7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, tmp2_cached[2].n1(), value.e7l_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.f7l_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, tmp2_cached[3].n1(), value.f7l_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.b7m(encoder, value instanceof OllamaMessage ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.a7m_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.f1y(tmp0_desc);
    var tmp9_cached = Companion_getInstance_3().z7l_1;
    if (tmp8_input.v1y()) {
      tmp4_local0 = tmp8_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, tmp9_cached[2].n1(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, tmp9_cached[3].n1(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, tmp9_cached[2].n1(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, tmp9_cached[3].n1(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp8_input.g1y(tmp0_desc);
    return OllamaMessage.c7m(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  w1t() {
    return this.a7m_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_3().z7l_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), get_nullable(tmp0_cached[2].n1()), get_nullable(tmp0_cached[3].n1())];
  }
}
class OllamaMessage {
  constructor(role, content, toolCalls, images) {
    Companion_getInstance_3();
    content = content === VOID ? '' : content;
    toolCalls = toolCalls === VOID ? null : toolCalls;
    images = images === VOID ? null : images;
    this.c7l_1 = role;
    this.d7l_1 = content;
    this.e7l_1 = toolCalls;
    this.f7l_1 = images;
  }
  d7m(role, content, toolCalls, images) {
    return new OllamaMessage(role, content, toolCalls, images);
  }
  g7l(role, content, toolCalls, images, $super) {
    role = role === VOID ? this.c7l_1 : role;
    content = content === VOID ? this.d7l_1 : content;
    toolCalls = toolCalls === VOID ? this.e7l_1 : toolCalls;
    images = images === VOID ? this.f7l_1 : images;
    return $super === VOID ? this.d7m(role, content, toolCalls, images) : $super.d7m.call(this, role, content, toolCalls, images);
  }
  toString() {
    return 'OllamaMessage(role=' + this.c7l_1 + ', content=' + this.d7l_1 + ', toolCalls=' + toString(this.e7l_1) + ', images=' + toString(this.f7l_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.c7l_1);
    result = imul(result, 31) + getStringHashCode(this.d7l_1) | 0;
    result = imul(result, 31) + (this.e7l_1 == null ? 0 : hashCode(this.e7l_1)) | 0;
    result = imul(result, 31) + (this.f7l_1 == null ? 0 : hashCode(this.f7l_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaMessage))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaMessage ? other : THROW_CCE();
    if (!(this.c7l_1 === tmp0_other_with_cast.c7l_1))
      return false;
    if (!(this.d7l_1 === tmp0_other_with_cast.d7l_1))
      return false;
    if (!equals(this.e7l_1, tmp0_other_with_cast.e7l_1))
      return false;
    if (!equals(this.f7l_1, tmp0_other_with_cast.f7l_1))
      return false;
    return true;
  }
  static c7m(seen0, role, content, toolCalls, images, serializationConstructorMarker) {
    Companion_getInstance_3();
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_1().a7m_1);
    }
    var $this = createThis(this);
    $this.c7l_1 = role;
    if (0 === (seen0 & 2))
      $this.d7l_1 = '';
    else
      $this.d7l_1 = content;
    if (0 === (seen0 & 4))
      $this.e7l_1 = null;
    else
      $this.e7l_1 = toolCalls;
    if (0 === (seen0 & 8))
      $this.f7l_1 = null;
    else
      $this.f7l_1 = images;
    return $this;
  }
}
class Companion_2 {}
class $serializer_2 {
  constructor() {
    $serializer_instance_2 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaTool', this, 2);
    tmp0_serialDesc.u25('type', true);
    tmp0_serialDesc.u25('function', false);
    this.e7m_1 = tmp0_serialDesc;
  }
  f7m(encoder, value) {
    var tmp0_desc = this.e7m_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.g7m_1 === 'function')) {
      tmp1_output.v1z(tmp0_desc, 0, value.g7m_1);
    }
    tmp1_output.x1z(tmp0_desc, 1, $serializer_getInstance_3(), value.h7m_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.f7m(encoder, value instanceof OllamaTool ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.e7m_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, $serializer_getInstance_3(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, $serializer_getInstance_3(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return OllamaTool.i7m(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.e7m_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), $serializer_getInstance_3()];
  }
}
class OllamaTool {
  constructor(type, function_0) {
    type = type === VOID ? 'function' : type;
    this.g7m_1 = type;
    this.h7m_1 = function_0;
  }
  toString() {
    return 'OllamaTool(type=' + this.g7m_1 + ', function=' + this.h7m_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.g7m_1);
    result = imul(result, 31) + this.h7m_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaTool))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaTool ? other : THROW_CCE();
    if (!(this.g7m_1 === tmp0_other_with_cast.g7m_1))
      return false;
    if (!this.h7m_1.equals(tmp0_other_with_cast.h7m_1))
      return false;
    return true;
  }
  static i7m(seen0, type, function_0, serializationConstructorMarker) {
    if (!(2 === (2 & seen0))) {
      throwMissingFieldException(seen0, 2, $serializer_getInstance_2().e7m_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.g7m_1 = 'function';
    else
      $this.g7m_1 = type;
    $this.h7m_1 = function_0;
    return $this;
  }
}
class Companion_3 {}
class $serializer_3 {
  constructor() {
    $serializer_instance_3 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaFunctionDef', this, 3);
    tmp0_serialDesc.u25('name', false);
    tmp0_serialDesc.u25('description', false);
    tmp0_serialDesc.u25('parameters', false);
    this.j7m_1 = tmp0_serialDesc;
  }
  k7m(encoder, value) {
    var tmp0_desc = this.j7m_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.l7m_1);
    tmp1_output.v1z(tmp0_desc, 1, value.m7m_1);
    tmp1_output.x1z(tmp0_desc, 2, JsonObjectSerializer_getInstance(), value.n7m_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.k7m(encoder, value instanceof OllamaFunctionDef ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.j7m_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_input = decoder.f1y(tmp0_desc);
    if (tmp7_input.v1y()) {
      tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp7_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp7_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp7_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp7_input.r1y(tmp0_desc, 2, JsonObjectSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp7_input.g1y(tmp0_desc);
    return OllamaFunctionDef.o7m(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, null);
  }
  w1t() {
    return this.j7m_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance(), JsonObjectSerializer_getInstance()];
  }
}
class OllamaFunctionDef {
  constructor(name, description, parameters) {
    this.l7m_1 = name;
    this.m7m_1 = description;
    this.n7m_1 = parameters;
  }
  toString() {
    return 'OllamaFunctionDef(name=' + this.l7m_1 + ', description=' + this.m7m_1 + ', parameters=' + this.n7m_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.l7m_1);
    result = imul(result, 31) + getStringHashCode(this.m7m_1) | 0;
    result = imul(result, 31) + this.n7m_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaFunctionDef))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaFunctionDef ? other : THROW_CCE();
    if (!(this.l7m_1 === tmp0_other_with_cast.l7m_1))
      return false;
    if (!(this.m7m_1 === tmp0_other_with_cast.m7m_1))
      return false;
    if (!this.n7m_1.equals(tmp0_other_with_cast.n7m_1))
      return false;
    return true;
  }
  static o7m(seen0, name, description, parameters, serializationConstructorMarker) {
    if (!(7 === (7 & seen0))) {
      throwMissingFieldException(seen0, 7, $serializer_getInstance_3().j7m_1);
    }
    var $this = createThis(this);
    $this.l7m_1 = name;
    $this.m7m_1 = description;
    $this.n7m_1 = parameters;
    return $this;
  }
}
class Companion_4 {}
class $serializer_4 {
  constructor() {
    $serializer_instance_4 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaReqToolCall', this, 1);
    tmp0_serialDesc.u25('function', false);
    this.p7m_1 = tmp0_serialDesc;
  }
  q7m(encoder, value) {
    var tmp0_desc = this.p7m_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.x1z(tmp0_desc, 0, $serializer_getInstance_5(), value.r7m_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.q7m(encoder, value instanceof OllamaReqToolCall ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.p7m_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.f1y(tmp0_desc);
    if (tmp5_input.v1y()) {
      tmp4_local0 = tmp5_input.r1y(tmp0_desc, 0, $serializer_getInstance_5(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.r1y(tmp0_desc, 0, $serializer_getInstance_5(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp5_input.g1y(tmp0_desc);
    return OllamaReqToolCall.s7m(tmp3_bitMask0, tmp4_local0, null);
  }
  w1t() {
    return this.p7m_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [$serializer_getInstance_5()];
  }
}
class OllamaReqToolCall {
  constructor(function_0) {
    this.r7m_1 = function_0;
  }
  toString() {
    return 'OllamaReqToolCall(function=' + this.r7m_1.toString() + ')';
  }
  hashCode() {
    return this.r7m_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaReqToolCall))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaReqToolCall ? other : THROW_CCE();
    if (!this.r7m_1.equals(tmp0_other_with_cast.r7m_1))
      return false;
    return true;
  }
  static s7m(seen0, function_0, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_4().p7m_1);
    }
    var $this = createThis(this);
    $this.r7m_1 = function_0;
    return $this;
  }
}
class Companion_5 {}
class $serializer_5 {
  constructor() {
    $serializer_instance_5 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaReqFunction', this, 2);
    tmp0_serialDesc.u25('name', false);
    tmp0_serialDesc.u25('arguments', false);
    this.t7m_1 = tmp0_serialDesc;
  }
  u7m(encoder, value) {
    var tmp0_desc = this.t7m_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.v7m_1);
    tmp1_output.x1z(tmp0_desc, 1, JsonObjectSerializer_getInstance(), value.w7m_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.u7m(encoder, value instanceof OllamaReqFunction ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.t7m_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, JsonObjectSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, JsonObjectSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return OllamaReqFunction.x7m(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.t7m_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), JsonObjectSerializer_getInstance()];
  }
}
class OllamaReqFunction {
  constructor(name, arguments_0) {
    this.v7m_1 = name;
    this.w7m_1 = arguments_0;
  }
  toString() {
    return 'OllamaReqFunction(name=' + this.v7m_1 + ', arguments=' + this.w7m_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.v7m_1);
    result = imul(result, 31) + this.w7m_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaReqFunction))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaReqFunction ? other : THROW_CCE();
    if (!(this.v7m_1 === tmp0_other_with_cast.v7m_1))
      return false;
    if (!this.w7m_1.equals(tmp0_other_with_cast.w7m_1))
      return false;
    return true;
  }
  static x7m(seen0, name, arguments_0, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_5().t7m_1);
    }
    var $this = createThis(this);
    $this.v7m_1 = name;
    $this.w7m_1 = arguments_0;
    return $this;
  }
}
class Companion_6 {
  r3o() {
    return $serializer_getInstance_6();
  }
}
class $serializer_6 {
  constructor() {
    $serializer_instance_6 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaChatResponse', this, 7);
    tmp0_serialDesc.u25('model', true);
    tmp0_serialDesc.u25('created_at', true);
    tmp0_serialDesc.u25('message', true);
    tmp0_serialDesc.u25('done', true);
    tmp0_serialDesc.u25('prompt_eval_count', true);
    tmp0_serialDesc.u25('eval_count', true);
    tmp0_serialDesc.u25('error', true);
    this.y7m_1 = tmp0_serialDesc;
  }
  z7m(encoder, value) {
    var tmp0_desc = this.y7m_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.a7n_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.a7n_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.b7n_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 1, StringSerializer_getInstance(), value.b7n_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.c7n_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, $serializer_getInstance_7(), value.c7n_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.d7n_1 === false)) {
      tmp1_output.n1z(tmp0_desc, 3, value.d7n_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.e7n_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 4, IntSerializer_getInstance(), value.e7n_1);
    }
    if (tmp1_output.d20(tmp0_desc, 5) ? true : !(value.f7n_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 5, IntSerializer_getInstance(), value.f7n_1);
    }
    if (tmp1_output.d20(tmp0_desc, 6) ? true : !(value.g7n_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 6, StringSerializer_getInstance(), value.g7n_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.z7m(encoder, value instanceof OllamaChatResponse ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.y7m_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = false;
    var tmp8_local4 = null;
    var tmp9_local5 = null;
    var tmp10_local6 = null;
    var tmp11_input = decoder.f1y(tmp0_desc);
    if (tmp11_input.v1y()) {
      tmp4_local0 = tmp11_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp11_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp11_input.t1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp11_input.h1y(tmp0_desc, 3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp11_input.t1y(tmp0_desc, 4, IntSerializer_getInstance(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp11_input.t1y(tmp0_desc, 5, IntSerializer_getInstance(), tmp9_local5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp11_input.t1y(tmp0_desc, 6, StringSerializer_getInstance(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp11_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp11_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp11_input.t1y(tmp0_desc, 1, StringSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp11_input.t1y(tmp0_desc, 2, $serializer_getInstance_7(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp11_input.h1y(tmp0_desc, 3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp11_input.t1y(tmp0_desc, 4, IntSerializer_getInstance(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp11_input.t1y(tmp0_desc, 5, IntSerializer_getInstance(), tmp9_local5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp11_input.t1y(tmp0_desc, 6, StringSerializer_getInstance(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp11_input.g1y(tmp0_desc);
    return OllamaChatResponse.h7n(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, null);
  }
  w1t() {
    return this.y7m_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable($serializer_getInstance_7()), BooleanSerializer_getInstance(), get_nullable(IntSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(StringSerializer_getInstance())];
  }
}
class OllamaChatResponse {
  constructor(model, createdAt, message, done, promptEvalCount, evalCount, error) {
    model = model === VOID ? null : model;
    createdAt = createdAt === VOID ? null : createdAt;
    message = message === VOID ? null : message;
    done = done === VOID ? false : done;
    promptEvalCount = promptEvalCount === VOID ? null : promptEvalCount;
    evalCount = evalCount === VOID ? null : evalCount;
    error = error === VOID ? null : error;
    this.a7n_1 = model;
    this.b7n_1 = createdAt;
    this.c7n_1 = message;
    this.d7n_1 = done;
    this.e7n_1 = promptEvalCount;
    this.f7n_1 = evalCount;
    this.g7n_1 = error;
  }
  toString() {
    return 'OllamaChatResponse(model=' + this.a7n_1 + ', createdAt=' + this.b7n_1 + ', message=' + toString(this.c7n_1) + ', done=' + this.d7n_1 + ', promptEvalCount=' + this.e7n_1 + ', evalCount=' + this.f7n_1 + ', error=' + this.g7n_1 + ')';
  }
  hashCode() {
    var result = this.a7n_1 == null ? 0 : getStringHashCode(this.a7n_1);
    result = imul(result, 31) + (this.b7n_1 == null ? 0 : getStringHashCode(this.b7n_1)) | 0;
    result = imul(result, 31) + (this.c7n_1 == null ? 0 : this.c7n_1.hashCode()) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.d7n_1) | 0;
    result = imul(result, 31) + (this.e7n_1 == null ? 0 : this.e7n_1) | 0;
    result = imul(result, 31) + (this.f7n_1 == null ? 0 : this.f7n_1) | 0;
    result = imul(result, 31) + (this.g7n_1 == null ? 0 : getStringHashCode(this.g7n_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaChatResponse))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaChatResponse ? other : THROW_CCE();
    if (!(this.a7n_1 == tmp0_other_with_cast.a7n_1))
      return false;
    if (!(this.b7n_1 == tmp0_other_with_cast.b7n_1))
      return false;
    if (!equals(this.c7n_1, tmp0_other_with_cast.c7n_1))
      return false;
    if (!(this.d7n_1 === tmp0_other_with_cast.d7n_1))
      return false;
    if (!(this.e7n_1 == tmp0_other_with_cast.e7n_1))
      return false;
    if (!(this.f7n_1 == tmp0_other_with_cast.f7n_1))
      return false;
    if (!(this.g7n_1 == tmp0_other_with_cast.g7n_1))
      return false;
    return true;
  }
  static h7n(seen0, model, createdAt, message, done, promptEvalCount, evalCount, error, serializationConstructorMarker) {
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_6().y7m_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.a7n_1 = null;
    else
      $this.a7n_1 = model;
    if (0 === (seen0 & 2))
      $this.b7n_1 = null;
    else
      $this.b7n_1 = createdAt;
    if (0 === (seen0 & 4))
      $this.c7n_1 = null;
    else
      $this.c7n_1 = message;
    if (0 === (seen0 & 8))
      $this.d7n_1 = false;
    else
      $this.d7n_1 = done;
    if (0 === (seen0 & 16))
      $this.e7n_1 = null;
    else
      $this.e7n_1 = promptEvalCount;
    if (0 === (seen0 & 32))
      $this.f7n_1 = null;
    else
      $this.f7n_1 = evalCount;
    if (0 === (seen0 & 64))
      $this.g7n_1 = null;
    else
      $this.g7n_1 = error;
    return $this;
  }
}
class Companion_7 {
  constructor() {
    Companion_instance_10 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.i7n_1 = [null, null, null, lazy(tmp_0, OllamaRespMessage$Companion$$childSerializers$_anonymous__yt9jdl)];
  }
}
class $serializer_7 {
  constructor() {
    $serializer_instance_7 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaRespMessage', this, 4);
    tmp0_serialDesc.u25('role', true);
    tmp0_serialDesc.u25('content', true);
    tmp0_serialDesc.u25('thinking', true);
    tmp0_serialDesc.u25('tool_calls', true);
    this.j7n_1 = tmp0_serialDesc;
  }
  k7n(encoder, value) {
    var tmp0_desc = this.j7n_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_9().i7n_1;
    if (tmp1_output.d20(tmp0_desc, 0) ? true : !(value.l7n_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 0, StringSerializer_getInstance(), value.l7n_1);
    }
    if (tmp1_output.d20(tmp0_desc, 1) ? true : !(value.m7n_1 === '')) {
      tmp1_output.v1z(tmp0_desc, 1, value.m7n_1);
    }
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.n7n_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, StringSerializer_getInstance(), value.n7n_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.o7n_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, tmp2_cached[3].n1(), value.o7n_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.k7n(encoder, value instanceof OllamaRespMessage ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.j7n_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_input = decoder.f1y(tmp0_desc);
    var tmp9_cached = Companion_getInstance_9().i7n_1;
    if (tmp8_input.v1y()) {
      tmp4_local0 = tmp8_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp8_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, tmp9_cached[3].n1(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp8_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp8_input.t1y(tmp0_desc, 0, StringSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp8_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp8_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp8_input.t1y(tmp0_desc, 3, tmp9_cached[3].n1(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp8_input.g1y(tmp0_desc);
    return OllamaRespMessage.p7n(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, null);
  }
  w1t() {
    return this.j7n_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_9().i7n_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [get_nullable(StringSerializer_getInstance()), StringSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[3].n1())];
  }
}
class OllamaRespMessage {
  constructor(role, content, thinking, toolCalls) {
    Companion_getInstance_9();
    role = role === VOID ? null : role;
    content = content === VOID ? '' : content;
    thinking = thinking === VOID ? null : thinking;
    toolCalls = toolCalls === VOID ? null : toolCalls;
    this.l7n_1 = role;
    this.m7n_1 = content;
    this.n7n_1 = thinking;
    this.o7n_1 = toolCalls;
  }
  toString() {
    return 'OllamaRespMessage(role=' + this.l7n_1 + ', content=' + this.m7n_1 + ', thinking=' + this.n7n_1 + ', toolCalls=' + toString(this.o7n_1) + ')';
  }
  hashCode() {
    var result = this.l7n_1 == null ? 0 : getStringHashCode(this.l7n_1);
    result = imul(result, 31) + getStringHashCode(this.m7n_1) | 0;
    result = imul(result, 31) + (this.n7n_1 == null ? 0 : getStringHashCode(this.n7n_1)) | 0;
    result = imul(result, 31) + (this.o7n_1 == null ? 0 : hashCode(this.o7n_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaRespMessage))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaRespMessage ? other : THROW_CCE();
    if (!(this.l7n_1 == tmp0_other_with_cast.l7n_1))
      return false;
    if (!(this.m7n_1 === tmp0_other_with_cast.m7n_1))
      return false;
    if (!(this.n7n_1 == tmp0_other_with_cast.n7n_1))
      return false;
    if (!equals(this.o7n_1, tmp0_other_with_cast.o7n_1))
      return false;
    return true;
  }
  static p7n(seen0, role, content, thinking, toolCalls, serializationConstructorMarker) {
    Companion_getInstance_9();
    if (!(0 === (0 & seen0))) {
      throwMissingFieldException(seen0, 0, $serializer_getInstance_7().j7n_1);
    }
    var $this = createThis(this);
    if (0 === (seen0 & 1))
      $this.l7n_1 = null;
    else
      $this.l7n_1 = role;
    if (0 === (seen0 & 2))
      $this.m7n_1 = '';
    else
      $this.m7n_1 = content;
    if (0 === (seen0 & 4))
      $this.n7n_1 = null;
    else
      $this.n7n_1 = thinking;
    if (0 === (seen0 & 8))
      $this.o7n_1 = null;
    else
      $this.o7n_1 = toolCalls;
    return $this;
  }
}
class Companion_8 {}
class $serializer_8 {
  constructor() {
    $serializer_instance_8 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaRespToolCall', this, 1);
    tmp0_serialDesc.u25('function', false);
    this.q7n_1 = tmp0_serialDesc;
  }
  r7n(encoder, value) {
    var tmp0_desc = this.q7n_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.x1z(tmp0_desc, 0, $serializer_getInstance_9(), value.s7n_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.r7n(encoder, value instanceof OllamaRespToolCall ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.q7n_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.f1y(tmp0_desc);
    if (tmp5_input.v1y()) {
      tmp4_local0 = tmp5_input.r1y(tmp0_desc, 0, $serializer_getInstance_9(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.r1y(tmp0_desc, 0, $serializer_getInstance_9(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp5_input.g1y(tmp0_desc);
    return OllamaRespToolCall.t7n(tmp3_bitMask0, tmp4_local0, null);
  }
  w1t() {
    return this.q7n_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [$serializer_getInstance_9()];
  }
}
class OllamaRespToolCall {
  toString() {
    return 'OllamaRespToolCall(function=' + this.s7n_1.toString() + ')';
  }
  hashCode() {
    return this.s7n_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaRespToolCall))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaRespToolCall ? other : THROW_CCE();
    if (!this.s7n_1.equals(tmp0_other_with_cast.s7n_1))
      return false;
    return true;
  }
  static t7n(seen0, function_0, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_8().q7n_1);
    }
    var $this = createThis(this);
    $this.s7n_1 = function_0;
    return $this;
  }
}
class Companion_9 {}
class $serializer_9 {
  constructor() {
    $serializer_instance_9 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.ollama.OllamaRespFunction', this, 2);
    tmp0_serialDesc.u25('name', false);
    tmp0_serialDesc.u25('arguments', false);
    this.u7n_1 = tmp0_serialDesc;
  }
  v7n(encoder, value) {
    var tmp0_desc = this.u7n_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.w7n_1);
    tmp1_output.x1z(tmp0_desc, 1, JsonObjectSerializer_getInstance(), value.x7n_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.v7n(encoder, value instanceof OllamaRespFunction ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.u7n_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, JsonObjectSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.r1y(tmp0_desc, 1, JsonObjectSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return OllamaRespFunction.y7n(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.u7n_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), JsonObjectSerializer_getInstance()];
  }
}
class OllamaRespFunction {
  toString() {
    return 'OllamaRespFunction(name=' + this.w7n_1 + ', arguments=' + this.x7n_1.toString() + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.w7n_1);
    result = imul(result, 31) + this.x7n_1.hashCode() | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OllamaRespFunction))
      return false;
    var tmp0_other_with_cast = other instanceof OllamaRespFunction ? other : THROW_CCE();
    if (!(this.w7n_1 === tmp0_other_with_cast.w7n_1))
      return false;
    if (!this.x7n_1.equals(tmp0_other_with_cast.x7n_1))
      return false;
    return true;
  }
  static y7n(seen0, name, arguments_0, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_9().u7n_1);
    }
    var $this = createThis(this);
    $this.w7n_1 = name;
    $this.x7n_1 = arguments_0;
    return $this;
  }
}
class OllamaConfig {
  constructor(baseUrl, apiKey, modelName) {
    apiKey = apiKey === VOID ? 'ollama' : apiKey;
    this.z7n_1 = baseUrl;
    this.a7o_1 = apiKey;
    this.b7o_1 = modelName;
    this.c7o_1 = null;
    this.d7o_1 = null;
    this.e7o_1 = null;
    this.f7o_1 = null;
    this.g7o_1 = null;
    this.h7o_1 = new Long(60000, 0);
    this.i7o_1 = new ModelCapabilities(Support_Unsupported_getInstance());
  }
  m7o(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new OllamaCapabilitiesScope(this.i7o_1);
    block(this_0);
    tmp.i7o_1 = this_0.q7o();
  }
  j7o() {
    return new ModelConfig(this.z7n_1, this.a7o_1, this.b7o_1, VOID, VOID, VOID, VOID, VOID, this.h7o_1);
  }
  k7o() {
    return new OllamaParams(this.c7o_1, this.d7o_1, this.e7o_1, this.f7o_1, this.g7o_1);
  }
  l7o() {
    return this.i7o_1;
  }
}
class OllamaCapabilitiesScope {
  constructor(initial) {
    this.n7o_1 = initial.v5o_1.equals(Support_Supported_getInstance());
    this.o7o_1 = initial.w5o_1.equals(Support_Supported_getInstance());
    this.p7o_1 = initial.x5o_1.equals(Support_Supported_getInstance());
  }
  q7o() {
    return new ModelCapabilities(this.n7o_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), this.o7o_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.p7o_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance());
  }
}
class OllamaWireDecoder {
  constructor() {
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.r7o_1 = ArrayList.k();
    this.s7o_1 = StringBuilder.v();
    this.t7o_1 = Companion_instance.k60('msg');
    var tmp_0 = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp_0.u7o_1 = ArrayList.k();
    this.v7o_1 = Companion_getInstance().g5s_1;
    this.w7o_1 = null;
    this.x7o_1 = false;
    this.y7o_1 = false;
  }
  z6f(frame) {
    var tmp;
    if (frame instanceof Ndjson) {
      tmp = frame.i6m_1;
    } else {
      if (frame instanceof Sse) {
        tmp = frame.e6m_1;
      } else {
        if (frame instanceof Body) {
          tmp = frame.h6m_1;
        } else {
          if (frame instanceof HttpError) {
            this.w7o_1 = new ModelError('HTTP ' + frame.i6l_1 + ': ' + frame.k6l_1, frame.i6l_1 >= 500);
            return finishFailed(this);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
    var json = tmp;
    if (isBlank(json))
      return emptyList();
    // Inline function 'kotlin.runCatching' call
    var tmp_0;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = JsonUtil_getInstance().e6f(json, Companion_instance_9.r3o());
      tmp_0 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_1;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    // Inline function 'kotlin.getOrElse' call
    var this_0 = tmp_0;
    var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
    var tmp_2;
    if (exception == null) {
      var tmp_3 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_2 = (tmp_3 == null ? true : !(tmp_3 == null)) ? tmp_3 : THROW_CCE();
    } else {
      return emptyList();
    }
    var chunk = tmp_2;
    return this.z7o(chunk);
  }
  z7o(chunk) {
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    if (!this.y7o_1) {
      this.y7o_1 = true;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = new Started(null);
      events.l(element);
    }
    var tmp0_safe_receiver = chunk.g7n_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      this.w7o_1 = new ModelError(tmp0_safe_receiver, false);
      return plus_0(events, finishFailed(this));
    }
    if (chunk.d7n_1) {
      var tmp = this;
      var tmp1_elvis_lhs = chunk.e7n_1;
      var tmp_0 = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
      var tmp2_elvis_lhs = chunk.f7n_1;
      var tmp_1 = tmp2_elvis_lhs == null ? 0 : tmp2_elvis_lhs;
      var tmp3_elvis_lhs = chunk.e7n_1;
      var tmp_2 = tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
      var tmp4_elvis_lhs = chunk.f7n_1;
      tmp.v7o_1 = new Usage(tmp_0, tmp_1, tmp_2 + (tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs) | 0);
    }
    var tmp5_elvis_lhs = chunk.c7n_1;
    var tmp_3;
    if (tmp5_elvis_lhs == null) {
      return events;
    } else {
      tmp_3 = tmp5_elvis_lhs;
    }
    var message = tmp_3;
    var tmp6_safe_receiver = message.n7n_1;
    if (tmp6_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.text.isNotEmpty' call
      if (charSequenceLength(tmp6_safe_receiver) > 0) {
        // Inline function 'kotlin.collections.plusAssign' call
        var element_0 = new ReasoningDelta(tmp6_safe_receiver);
        events.l(element_0);
      }
    }
    // Inline function 'kotlin.text.isNotEmpty' call
    var this_0 = message.m7n_1;
    if (charSequenceLength(this_0) > 0) {
      this.s7o_1.tb(message.m7n_1);
      // Inline function 'kotlin.collections.plusAssign' call
      var element_1 = new TextDelta(message.m7n_1, this.t7o_1);
      events.l(element_1);
    }
    var tmp7_safe_receiver = message.o7n_1;
    if (tmp7_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s = tmp7_safe_receiver.y();
      while (_iterator__ex2g4s.z()) {
        var element_2 = _iterator__ex2g4s.a1();
        var ref = Companion_instance.k60('call');
        var call = new ToolCall_0(_ItemRef___get_value__impl__fpjuyb(ref), element_2.s7n_1.w7n_1, encodeArguments(this, element_2.s7n_1.x7n_1), new ProviderScopedId(Companion_getInstance_0().t6c_1, _ItemRef___get_value__impl__fpjuyb(ref)));
        // Inline function 'kotlin.collections.plusAssign' call
        this.r7o_1.l(call);
        // Inline function 'kotlin.collections.plusAssign' call
        var element_3 = new ToolCallDelta(call.t5v_1, get_lastIndex(this.r7o_1), element_2.s7n_1.w7n_1, call.v5v_1, ref);
        events.l(element_3);
      }
    }
    return events;
  }
  g6g() {
    if (this.x7o_1)
      return emptyList();
    if (!(this.w7o_1 == null))
      return finishFailed(this);
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    // Inline function 'kotlin.text.isNotEmpty' call
    var this_0 = this.s7o_1;
    if (charSequenceLength(this_0) > 0) {
      var tmp1 = this.u7o_1;
      // Inline function 'kotlin.collections.plusAssign' call
      var element = Companion_instance_0.t5t(this.s7o_1.toString(), this.t7o_1);
      tmp1.l(element);
    }
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = this.r7o_1.y();
    while (_iterator__ex2g4s.z()) {
      var element_0 = _iterator__ex2g4s.a1();
      var tmp0 = this.u7o_1;
      // Inline function 'kotlin.collections.plusAssign' call
      var element_1 = element_0.o60();
      tmp0.l(element_1);
      // Inline function 'kotlin.collections.plusAssign' call
      var element_2 = new ToolCallCompleted(element_0);
      events.l(element_2);
    }
    this.x7o_1 = true;
    // Inline function 'kotlin.collections.plusAssign' call
    var element_3 = new Finished(new Completed(VOID, toList(this.u7o_1), this.v7o_1));
    events.l(element_3);
    return events;
  }
}
//endregion
function get_argsJson() {
  _init_properties_OllamaChatModel_kt__7wgy2h();
  return argsJson;
}
var argsJson;
function toOllamaMessages(req) {
  _init_properties_OllamaChatModel_kt__7wgy2h();
  // Inline function 'kotlin.collections.mutableListOf' call
  var out = ArrayList.k();
  var tmp0_safe_receiver = req.b5y_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.takeIf' call
    var tmp_0;
    // Inline function 'kotlin.text.isNotBlank' call
    if (!isBlank(tmp0_safe_receiver)) {
      tmp_0 = tmp0_safe_receiver;
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  var tmp1_safe_receiver = tmp;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlin.collections.plusAssign' call
    var element = new OllamaMessage('system', tmp1_safe_receiver);
    out.l(element);
  }
  var _iterator__ex2g4s = req.c5y_1.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    if (item instanceof Message) {
      switch (item.r5o_1.o3_1) {
        case 0:
          // Inline function 'kotlin.collections.plusAssign' call

          var element_0 = new OllamaMessage('system', item.m5t());
          out.l(element_0);
          break;
        case 1:
          // Inline function 'kotlin.collections.filterIsInstance' call

          var tmp0 = item.s5o_1;
          // Inline function 'kotlin.collections.filterIsInstanceTo' call

          var destination = ArrayList.k();
          var _iterator__ex2g4s_0 = tmp0.y();
          while (_iterator__ex2g4s_0.z()) {
            var element_1 = _iterator__ex2g4s_0.a1();
            if (element_1 instanceof Image) {
              destination.l(element_1);
            }
          }

          // Inline function 'kotlin.collections.mapNotNull' call

          // Inline function 'kotlin.collections.mapNotNullTo' call

          var destination_0 = ArrayList.k();
          // Inline function 'kotlin.collections.forEach' call

          var _iterator__ex2g4s_1 = destination.y();
          while (_iterator__ex2g4s_1.z()) {
            var element_2 = _iterator__ex2g4s_1.a1();
            var tmp0_safe_receiver_0 = element_2.o6b_1;
            if (tmp0_safe_receiver_0 == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              destination_0.l(tmp0_safe_receiver_0);
            }
          }

          var images = destination_0;
          var tmp_1 = item.m5t();
          // Inline function 'kotlin.takeIf' call

          var tmp_2;
          // Inline function 'kotlin.collections.isNotEmpty' call

          if (!images.h1()) {
            tmp_2 = images;
          } else {
            tmp_2 = null;
          }

          var tmp$ret$19 = tmp_2;
          // Inline function 'kotlin.collections.plusAssign' call

          var element_3 = new OllamaMessage('user', tmp_1, VOID, tmp$ret$19);
          out.l(element_3);
          break;
        case 2:
          // Inline function 'kotlin.collections.plusAssign' call

          var element_4 = new OllamaMessage('assistant', item.m5t());
          out.l(element_4);
          break;
        case 3:
          break;
        default:
          noWhenBranchMatchedException();
          break;
      }
    } else {
      if (item instanceof ToolCall) {
        var last = lastOrNull(out);
        var call = new OllamaReqToolCall(new OllamaReqFunction(item.z68_1, parseArgs(item.a69_1)));
        if (!(last == null) && last.c7l_1 === 'assistant') {
          var tmp_3 = get_lastIndex(out);
          var tmp4_elvis_lhs = last.e7l_1;
          out.c3(tmp_3, last.g7l(VOID, VOID, plus(tmp4_elvis_lhs == null ? emptyList() : tmp4_elvis_lhs, call)));
        } else {
          // Inline function 'kotlin.collections.plusAssign' call
          var element_5 = new OllamaMessage('assistant', VOID, listOf(call));
          out.l(element_5);
        }
      } else {
        if (item instanceof ToolResult) {
          // Inline function 'kotlin.collections.plusAssign' call
          var element_6 = new OllamaMessage('tool', item.v68_1);
          out.l(element_6);
        } else {
          if (!(item instanceof ReasoningSummary)) {
            if (item instanceof ProviderItem) {
              ensureDroppable(item, 'ollama');
            } else {
              noWhenBranchMatchedException();
            }
          }
        }
      }
    }
  }
  return out;
}
function parseArgs(raw) {
  _init_properties_OllamaChatModel_kt__7wgy2h();
  var tmp;
  if (isBlank(raw)) {
    tmp = new JsonObject(emptyMap());
  } else {
    // Inline function 'kotlin.runCatching' call
    var tmp_0;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = get_jsonObject(get_argsJson().q3m(raw));
      tmp_0 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_1;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_0 = tmp_1;
    }
    // Inline function 'kotlin.getOrElse' call
    var this_0 = tmp_0;
    var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
    var tmp_2;
    if (exception == null) {
      var tmp_3 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_2 = (tmp_3 == null ? true : !(tmp_3 == null)) ? tmp_3 : THROW_CCE();
    } else {
      tmp_2 = new JsonObject(emptyMap());
    }
    tmp = tmp_2;
  }
  return tmp;
}
function argsJson$lambda($this$Json) {
  _init_properties_OllamaChatModel_kt__7wgy2h();
  $this$Json.h3n_1 = true;
  $this$Json.i3n_1 = true;
  return Unit_instance;
}
var properties_initialized_OllamaChatModel_kt_8o8tq3;
function _init_properties_OllamaChatModel_kt__7wgy2h() {
  if (!properties_initialized_OllamaChatModel_kt_8o8tq3) {
    properties_initialized_OllamaChatModel_kt_8o8tq3 = true;
    argsJson = Json(VOID, argsJson$lambda);
  }
}
function OllamaChatRequest$Companion$$childSerializers$_anonymous__6xlh2f() {
  return new ArrayListSerializer($serializer_getInstance_1());
}
function OllamaChatRequest$Companion$$childSerializers$_anonymous__6xlh2f_0() {
  return new ArrayListSerializer($serializer_getInstance_2());
}
var Companion_instance_2;
function Companion_getInstance_1() {
  if (Companion_instance_2 === VOID)
    new Companion();
  return Companion_instance_2;
}
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance === VOID)
    new $serializer();
  return $serializer_instance;
}
function OllamaOptions$Companion$$childSerializers$_anonymous__yv8no2() {
  return new ArrayListSerializer(StringSerializer_getInstance());
}
var Companion_instance_3;
function Companion_getInstance_2() {
  if (Companion_instance_3 === VOID)
    new Companion_0();
  return Companion_instance_3;
}
var $serializer_instance_0;
function $serializer_getInstance_0() {
  if ($serializer_instance_0 === VOID)
    new $serializer_0();
  return $serializer_instance_0;
}
function OllamaMessage$Companion$$childSerializers$_anonymous__ecv4bb() {
  return new ArrayListSerializer($serializer_getInstance_4());
}
function OllamaMessage$Companion$$childSerializers$_anonymous__ecv4bb_0() {
  return new ArrayListSerializer(StringSerializer_getInstance());
}
var Companion_instance_4;
function Companion_getInstance_3() {
  if (Companion_instance_4 === VOID)
    new Companion_1();
  return Companion_instance_4;
}
var $serializer_instance_1;
function $serializer_getInstance_1() {
  if ($serializer_instance_1 === VOID)
    new $serializer_1();
  return $serializer_instance_1;
}
var Companion_instance_5;
function Companion_getInstance_4() {
  return Companion_instance_5;
}
var $serializer_instance_2;
function $serializer_getInstance_2() {
  if ($serializer_instance_2 === VOID)
    new $serializer_2();
  return $serializer_instance_2;
}
var Companion_instance_6;
function Companion_getInstance_5() {
  return Companion_instance_6;
}
var $serializer_instance_3;
function $serializer_getInstance_3() {
  if ($serializer_instance_3 === VOID)
    new $serializer_3();
  return $serializer_instance_3;
}
var Companion_instance_7;
function Companion_getInstance_6() {
  return Companion_instance_7;
}
var $serializer_instance_4;
function $serializer_getInstance_4() {
  if ($serializer_instance_4 === VOID)
    new $serializer_4();
  return $serializer_instance_4;
}
var Companion_instance_8;
function Companion_getInstance_7() {
  return Companion_instance_8;
}
var $serializer_instance_5;
function $serializer_getInstance_5() {
  if ($serializer_instance_5 === VOID)
    new $serializer_5();
  return $serializer_instance_5;
}
var Companion_instance_9;
function Companion_getInstance_8() {
  return Companion_instance_9;
}
var $serializer_instance_6;
function $serializer_getInstance_6() {
  if ($serializer_instance_6 === VOID)
    new $serializer_6();
  return $serializer_instance_6;
}
function OllamaRespMessage$Companion$$childSerializers$_anonymous__yt9jdl() {
  return new ArrayListSerializer($serializer_getInstance_8());
}
var Companion_instance_10;
function Companion_getInstance_9() {
  if (Companion_instance_10 === VOID)
    new Companion_7();
  return Companion_instance_10;
}
var $serializer_instance_7;
function $serializer_getInstance_7() {
  if ($serializer_instance_7 === VOID)
    new $serializer_7();
  return $serializer_instance_7;
}
var Companion_instance_11;
function Companion_getInstance_10() {
  return Companion_instance_11;
}
var $serializer_instance_8;
function $serializer_getInstance_8() {
  if ($serializer_instance_8 === VOID)
    new $serializer_8();
  return $serializer_instance_8;
}
var Companion_instance_12;
function Companion_getInstance_11() {
  return Companion_instance_12;
}
var $serializer_instance_9;
function $serializer_getInstance_9() {
  if ($serializer_instance_9 === VOID)
    new $serializer_9();
  return $serializer_instance_9;
}
function ollama(_this__u8e3s4, baseUrl, apiKey, modelName, block) {
  apiKey = apiKey === VOID ? 'ollama' : apiKey;
  var tmp;
  if (block === VOID) {
    tmp = ollama$lambda;
  } else {
    tmp = block;
  }
  block = tmp;
  // Inline function 'kotlin.apply' call
  var this_0 = new OllamaConfig(baseUrl, apiKey, modelName);
  block(this_0);
  var cfg = this_0;
  return _this__u8e3s4.t5z(new OllamaChatModel(cfg.j7o(), _this__u8e3s4.v5z(), cfg.k7o(), cfg.l7o()));
}
function ollama$lambda(_this__u8e3s4) {
  return Unit_instance;
}
function finishFailed($this) {
  if ($this.x7o_1)
    return emptyList();
  $this.x7o_1 = true;
  return listOf(new Finished(new Failed(ensureNotNull($this.w7o_1), VOID, VOID, $this.v7o_1)));
}
function encodeArguments($this, args) {
  return args.toString();
}
//region block: post-declaration
initMetadataForClass(OllamaChatModel, 'OllamaChatModel', VOID, VOID, VOID, [1]);
initMetadataForClass(OllamaParams, 'OllamaParams', OllamaParams);
initMetadataForCompanion(Companion);
protoOf($serializer).k26 = typeParametersSerializers;
initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaChatRequest, 'OllamaChatRequest', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
initMetadataForCompanion(Companion_0);
protoOf($serializer_0).k26 = typeParametersSerializers;
initMetadataForObject($serializer_0, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaOptions, 'OllamaOptions', OllamaOptions, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
initMetadataForCompanion(Companion_1);
protoOf($serializer_1).k26 = typeParametersSerializers;
initMetadataForObject($serializer_1, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaMessage, 'OllamaMessage', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_1});
initMetadataForCompanion(Companion_2);
protoOf($serializer_2).k26 = typeParametersSerializers;
initMetadataForObject($serializer_2, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaTool, 'OllamaTool', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_2});
initMetadataForCompanion(Companion_3);
protoOf($serializer_3).k26 = typeParametersSerializers;
initMetadataForObject($serializer_3, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaFunctionDef, 'OllamaFunctionDef', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_3});
initMetadataForCompanion(Companion_4);
protoOf($serializer_4).k26 = typeParametersSerializers;
initMetadataForObject($serializer_4, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaReqToolCall, 'OllamaReqToolCall', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_4});
initMetadataForCompanion(Companion_5);
protoOf($serializer_5).k26 = typeParametersSerializers;
initMetadataForObject($serializer_5, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaReqFunction, 'OllamaReqFunction', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_5});
initMetadataForCompanion(Companion_6);
protoOf($serializer_6).k26 = typeParametersSerializers;
initMetadataForObject($serializer_6, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaChatResponse, 'OllamaChatResponse', OllamaChatResponse, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_6});
initMetadataForCompanion(Companion_7);
protoOf($serializer_7).k26 = typeParametersSerializers;
initMetadataForObject($serializer_7, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaRespMessage, 'OllamaRespMessage', OllamaRespMessage, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_7});
initMetadataForCompanion(Companion_8);
protoOf($serializer_8).k26 = typeParametersSerializers;
initMetadataForObject($serializer_8, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaRespToolCall, 'OllamaRespToolCall', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_8});
initMetadataForCompanion(Companion_9);
protoOf($serializer_9).k26 = typeParametersSerializers;
initMetadataForObject($serializer_9, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(OllamaRespFunction, 'OllamaRespFunction', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_9});
initMetadataForClass(OllamaConfig, 'OllamaConfig');
initMetadataForClass(OllamaCapabilitiesScope, 'OllamaCapabilitiesScope');
initMetadataForClass(OllamaWireDecoder, 'OllamaWireDecoder', OllamaWireDecoder);
//endregion
//region block: init
Companion_instance_5 = new Companion_2();
Companion_instance_6 = new Companion_3();
Companion_instance_7 = new Companion_4();
Companion_instance_8 = new Companion_5();
Companion_instance_9 = new Companion_6();
Companion_instance_11 = new Companion_8();
Companion_instance_12 = new Companion_9();
//endregion
//region block: exports
export {
  ollama as ollama3bi4tj0plt4pm,
};
//endregion

//# sourceMappingURL=koaks-model-provider-ollama.mjs.map
