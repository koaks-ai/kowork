import {
  ChatCompletionsModel2rl4figp5zhty as ChatCompletionsModel,
  ChatCompletionsParams2phuyy1p28jz5 as ChatCompletionsParams,
  normalizeChatCompletionsUrlbu0jml6vp44x as normalizeChatCompletionsUrl,
} from './koaks-model-provider-chat-completions.mjs';
import {
  VOID7hggqo3abtya as VOID,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  toString30pk9tzaqopn as toString,
  getNumberHashCode2l4nbdcihl25f as getNumberHashCode,
  hashCodeq5arwsb9dgti as hashCode,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  equals2au1ep9vhcato as equals,
  Long2qws0ah9gnpki as Long,
  Unit_instance104q5opgivhr8 as Unit_instance,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  createFailure8paxfkfa5dc7 as createFailure,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  _Result___get_isFailure__impl__jpirivzehaw445b0cy as _Result___get_isFailure__impl__jpiriv,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  toString1pkumu07cwy4m as toString_0,
  StringBuildermazzzhj6kkai as StringBuilder,
  ArrayList3it5z8td81qkl as ArrayList,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  emptyList1g2z5xcrvp2zy as emptyList,
  plus310ted5e4i90h as plus,
  charSequenceLength3278n89t01tmv as charSequenceLength,
  addAll1k27qatfgp3k5 as addAll,
  toList3jhuyej2anx2q as toList,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  listOfvhqybd2zx248 as listOf,
  checkIndexOverflow3frtmheghr0th as checkIndexOverflow,
  maxOrNull2e5ok5wkly1cp as maxOrNull,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  isBlank1dvkhjjvox3p0 as isBlank,
  joinToString1cxrrlmo0chqs as joinToString,
  FunctionAdapter3lcrrz3moet5b as FunctionAdapter,
  isInterface3d6p8outrmvmk as isInterface,
  Comparator2b3maoeh98xtg as Comparator,
  compareValues1n2ayl87ihzfk as compareValues,
  LinkedHashMap1zhqxkxv3xnkl as LinkedHashMap,
  HashSet2dzve9y63nf0v as HashSet,
  sortedWith2csnbbb21k0lg as sortedWith,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  Companion_getInstance2b73c6hwbaiuw as Companion_getInstance,
  DurationUnit_MILLISECONDS_getInstance1vv9i8zf23p5u as DurationUnit_MILLISECONDS_getInstance,
  toDurationba1nlt78o6vu as toDuration,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  charArrayOf27f4r3dozbrk1 as charArrayOf,
  trimEndvvzjdhan75g as trimEnd,
  collectionSizeOrDefault36dulx8yinfqm as collectionSizeOrDefault,
  coerceAtMost322komnqp70ag as coerceAtMost,
  drop3na99dw9feawf as drop,
  plus20p0vtfmu0596 as plus_0,
  distinct10qe1scfdvu5k as distinct,
  getBooleanHashCode1bbj3u6b3v0a7 as getBooleanHashCode,
  isCharSequence1ju9jr1w86plq as isCharSequence,
  trim11nh7r46at6sx as trim,
  endsWith3cq61xxngobwh as endsWith,
  mapCapacity1h45rc3eh9p2l as mapCapacity,
  coerceAtLeast2bkz8m9ik7hep as coerceAtLeast,
  LazyThreadSafetyMode_PUBLICATION_getInstance2x9bac6dffafm as LazyThreadSafetyMode_PUBLICATION_getInstance,
  lazy1261dae0bgscp as lazy,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  protoOf180f3jzyo7rfj as protoOf,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  createThis2j2avj17cvnv2 as createThis,
  Enum3alwj03lh1n41 as Enum,
  setOf45ia9pnfhe90 as setOf,
} from './kotlin-kotlin-stdlib.mjs';
import {
  ModelCapabilities1z2n3zkdibnvb as ModelCapabilities,
  Companion_getInstance3ot1bqjky10hu as Companion_getInstance_0,
  ModelConfig4o28u6uqe7xk as ModelConfig,
  Support_Supported_getInstance2iy50h3ebt6qe as Support_Supported_getInstance,
  Support_Unsupported_getInstance2l560r5zg87nd as Support_Unsupported_getInstance,
  Support_Unknown_getInstance3blv79i14mlk4 as Support_Unknown_getInstance,
  JsonUtil_getInstance3itlrleq4m1cs as JsonUtil_getInstance,
  ProviderCheckpoint1ql47nh16mrq3 as ProviderCheckpoint,
  _ProviderId___get_value__impl__xo1tux1l8qcslmantkx as _ProviderId___get_value__impl__xo1tux,
  Companion_instance13097inxmcdi as Companion_instance_0,
  Role_ASSISTANT_getInstance3m8z8upy020dy as Role_ASSISTANT_getInstance,
  Started1sf5a44qjgp0u as Started,
  CheckpointUpdated1ph6xqbn4fzwh as CheckpointUpdated,
  TextDeltaq9h7728thclc as TextDelta,
  ReasoningDeltaytmmln995w27 as ReasoningDelta,
  _ItemRef___get_value__impl__fpjuyb3vqbahagzpip9 as _ItemRef___get_value__impl__fpjuyb,
  ToolCallDelta1owom9vbem28s as ToolCallDelta,
  Cancelled_instance1itykyif0mdkk as Cancelled_instance,
  ProviderEvent1t0ljokdqil6g as ProviderEvent,
  Completedf7bahq5rqxjz as Completed,
  Incompletel3n48a644js as Incomplete,
  Failed2mkg32d93x5tt as Failed,
  Finished4z9e5g7v1wyk as Finished,
  ProviderItem17hp0vuxmlwze as ProviderItem,
  ReasoningSummary2dl0lxzty5z0 as ReasoningSummary,
  Message1x6kaj8ypdoee as Message,
  ToolResult2fndzcq38kgpy as ToolResult,
  ToolCall27jatgdodcelb as ToolCall,
  ItemAddede8lfykdsw28t as ItemAdded,
  toDispatchCall2p600t0sjcswe as toDispatchCall,
  ToolCallCompleted225u0jsfjmco7 as ToolCallCompleted,
  ProviderScopedId2kn7so5x8kdlf as ProviderScopedId,
  _ItemRef___init__impl__ipmeexzal33vlj7m90 as _ItemRef___init__impl__ipmeex,
  ReplayPolicy_Required_getInstance1o7kby0tmyj43 as ReplayPolicy_Required_getInstance,
  ReplayPolicy_Preferred_getInstance2bbct696f4twy as ReplayPolicy_Preferred_getInstance,
  UrlCitation1viudi8jaexgt as UrlCitation,
  FileCitationygaccnkkyy7b as FileCitation,
  Genericlzofu41340v as Generic,
  Usage3sdv1daz6y20z as Usage,
  MaxOutputTokens_instance2tn5unomigxz7 as MaxOutputTokens_instance,
  ContentFilter_instance10ein6t2i9053 as ContentFilter_instance,
  Other3cy8r7ld3h1ux as Other,
  Companion_instance3119tbznr6ao7 as Companion_instance_1,
  CheckpointScope_InRun_getInstancehlz4h897r3cf as CheckpointScope_InRun_getInstance,
  CheckpointScope_CrossTurn_getInstance3flwfeb5t4aet as CheckpointScope_CrossTurn_getInstance,
  ModelErrori9ofbqyilwwf as ModelError,
  ToolCallsfyoaxshhyk as ToolCall_0,
  Texttoggh19xftus as Text,
  Companion_getInstance2m4xts4fuklfa as Companion_getInstance_1,
  Ndjson1kkk3x9modr28 as Ndjson,
  Body2ccosqk3y8ycb as Body,
  Sset7uvtqde4kyu as Sse,
  HttpError1wj82nej166el as HttpError,
  Role_USER_getInstance1gsro7tt6a7i2 as Role_USER_getInstance,
  Role_SYSTEM_getInstance3m9lasmspf7k5 as Role_SYSTEM_getInstance,
  TransportException31a3s676rkip3 as TransportException,
  HttpMethod_GET_getInstancemtw2do2vtbsa as HttpMethod_GET_getInstance,
  authHeaders3pbiyo76b6dd9 as authHeaders,
  Framing_Json_getInstance1qaq7vxhw69ba as Framing_Json_getInstance,
  timeoutsvuf8aepeqg28 as timeouts,
  WireCall3namx761k5vmg as WireCall,
  HttpMethod_POST_getInstance2vunzl2e30rwd as HttpMethod_POST_getInstance,
  RetryBudget5rxtg4kf2dwq as RetryBudget,
  ChatModel1ekuxcd3gk3yy as ChatModel,
  Framing_Sse_getInstance1id84wnv2jikt as Framing_Sse_getInstance,
  ItemRef3v4f9mi7oyrky as ItemRef,
  JsonSchema1bzd59uqo2uv as JsonSchema,
  JsonObject_instance30hvkp8z8mfx9 as JsonObject_instance,
  Text_instance936fuxqirkv3 as Text_instance,
  rawFor3526oyw9fazp7 as rawFor,
} from './koaks-core.mjs';
import { Companion_getInstance3n3majy04gpy as Companion_getInstance_2 } from './okio-parent-okio.mjs';
import {
  get_jsonObject2u4z2ch1uuca9 as get_jsonObject,
  JsonObjectBuilder2nl6rv6vdayuk as JsonObjectBuilder,
  JsonObjectee06ihoeeiqj as JsonObject,
  JsonArray2urf8ey7u44sd as JsonArray,
  get_jsonPrimitivez17tyd5rw1ql as get_jsonPrimitive,
  get_contentOrNull35s97cgi8z9eo as get_contentOrNull,
  JsonPrimitive3ttzjh2ft5dnx as JsonPrimitive,
  get_intOrNulld29i64b3udf as get_intOrNull,
  JsonPrimitiveolttw629wj53 as JsonPrimitive_0,
  JsonArrayBuilderu8edol6ui3pj as JsonArrayBuilder,
  JsonPrimitive1xkjzc5d7ihuv as JsonPrimitive_1,
  JsonPrimitive2fp8648nd60dn as JsonPrimitive_2,
  JsonObjectSerializer_getInstance197qdg6ernwdp as JsonObjectSerializer_getInstance,
  JsonElementSerializer_getInstance1rgo1giz8g15y as JsonElementSerializer_getInstance,
} from './kotlinx-serialization-kotlinx-serialization-json.mjs';
import {
  firstOrNull12rzggh6e86lb as firstOrNull,
  delay1gna29w5m8r2h as delay,
  withTimeoutOrNull1s5mig5vy28xr as withTimeoutOrNull,
  CoroutineScopefcb5f5dwqcas as CoroutineScope,
  FlowCollector26clgpmzihvke as FlowCollector,
  flow3tazazxj2t7g4 as flow,
} from './kotlinx-coroutines-core.mjs';
import {
  ArrayListSerializer7k5wnrulb3y6 as ArrayListSerializer,
  StringSerializer_getInstance1k1oz5j50sfik as StringSerializer_getInstance,
  PluginGeneratedSerialDescriptorqdzeg5asqhfg as PluginGeneratedSerialDescriptor,
  BooleanSerializer_getInstancet3wtk7fl7i4f as BooleanSerializer_getInstance,
  DoubleSerializer_getInstance2avi1jm48x8le as DoubleSerializer_getInstance,
  IntSerializer_getInstance9scrtcljaiv6 as IntSerializer_getInstance,
  UnknownFieldExceptiona60e3a6v1xqo as UnknownFieldException,
  get_nullable197rfua9r7fsz as get_nullable,
  typeParametersSerializers2likxjr48tr7y as typeParametersSerializers,
  GeneratedSerializer1f7t7hssdd2ws as GeneratedSerializer,
  throwMissingFieldException2cmke0v3ynf14 as throwMissingFieldException,
} from './kotlinx-serialization-kotlinx-serialization-core.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class OpenAIChatModel extends ChatCompletionsModel {
  constructor(config, transport, params, capabilities) {
    params = params === VOID ? new OpenAIParams() : params;
    capabilities = capabilities === VOID ? new ModelCapabilities() : capabilities;
    super(config, transport, Companion_getInstance_0().q6c_1, new ChatCompletionsParams(params.n7e_1, VOID, params.o7e_1, params.p7e_1, params.q7e_1, params.r7e_1, params.s7e_1, params.t7e_1), capabilities);
  }
}
class OpenAIParams {
  constructor(temperature, maxCompletionTokens, topP, stop, presencePenalty, frequencyPenalty, reasoningEffort) {
    temperature = temperature === VOID ? null : temperature;
    maxCompletionTokens = maxCompletionTokens === VOID ? null : maxCompletionTokens;
    topP = topP === VOID ? null : topP;
    stop = stop === VOID ? null : stop;
    presencePenalty = presencePenalty === VOID ? null : presencePenalty;
    frequencyPenalty = frequencyPenalty === VOID ? null : frequencyPenalty;
    reasoningEffort = reasoningEffort === VOID ? null : reasoningEffort;
    this.n7e_1 = temperature;
    this.o7e_1 = maxCompletionTokens;
    this.p7e_1 = topP;
    this.q7e_1 = stop;
    this.r7e_1 = presencePenalty;
    this.s7e_1 = frequencyPenalty;
    this.t7e_1 = reasoningEffort;
  }
  toString() {
    return 'OpenAIParams(temperature=' + this.n7e_1 + ', maxCompletionTokens=' + this.o7e_1 + ', topP=' + this.p7e_1 + ', stop=' + toString(this.q7e_1) + ', presencePenalty=' + this.r7e_1 + ', frequencyPenalty=' + this.s7e_1 + ', reasoningEffort=' + this.t7e_1 + ')';
  }
  hashCode() {
    var result = this.n7e_1 == null ? 0 : getNumberHashCode(this.n7e_1);
    result = imul(result, 31) + (this.o7e_1 == null ? 0 : this.o7e_1) | 0;
    result = imul(result, 31) + (this.p7e_1 == null ? 0 : getNumberHashCode(this.p7e_1)) | 0;
    result = imul(result, 31) + (this.q7e_1 == null ? 0 : hashCode(this.q7e_1)) | 0;
    result = imul(result, 31) + (this.r7e_1 == null ? 0 : getNumberHashCode(this.r7e_1)) | 0;
    result = imul(result, 31) + (this.s7e_1 == null ? 0 : getNumberHashCode(this.s7e_1)) | 0;
    result = imul(result, 31) + (this.t7e_1 == null ? 0 : getStringHashCode(this.t7e_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof OpenAIParams))
      return false;
    var tmp0_other_with_cast = other instanceof OpenAIParams ? other : THROW_CCE();
    if (!equals(this.n7e_1, tmp0_other_with_cast.n7e_1))
      return false;
    if (!(this.o7e_1 == tmp0_other_with_cast.o7e_1))
      return false;
    if (!equals(this.p7e_1, tmp0_other_with_cast.p7e_1))
      return false;
    if (!equals(this.q7e_1, tmp0_other_with_cast.q7e_1))
      return false;
    if (!equals(this.r7e_1, tmp0_other_with_cast.r7e_1))
      return false;
    if (!equals(this.s7e_1, tmp0_other_with_cast.s7e_1))
      return false;
    if (!(this.t7e_1 == tmp0_other_with_cast.t7e_1))
      return false;
    return true;
  }
}
class OpenAIConfig {
  constructor(baseUrl, apiKey, modelName) {
    this.u7e_1 = baseUrl;
    this.v7e_1 = apiKey;
    this.w7e_1 = modelName;
    this.x7e_1 = null;
    this.y7e_1 = null;
    this.z7e_1 = null;
    this.a7f_1 = null;
    this.b7f_1 = null;
    this.c7f_1 = null;
    this.d7f_1 = null;
    this.e7f_1 = new Long(60000, 0);
    this.f7f_1 = new ModelCapabilities();
  }
  j7f(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new OpenAICapabilitiesScope(this.f7f_1);
    block(this_0);
    tmp.f7f_1 = this_0.o7f();
  }
  g7f() {
    return new ModelConfig(normalizeChatCompletionsUrl(this.u7e_1), this.v7e_1, this.w7e_1, VOID, VOID, VOID, VOID, VOID, this.e7f_1);
  }
  h7f() {
    return new OpenAIParams(this.x7e_1, this.y7e_1, this.z7e_1, this.a7f_1, this.b7f_1, this.c7f_1, this.d7f_1);
  }
  i7f() {
    return this.f7f_1;
  }
}
class OpenAICapabilitiesScope {
  constructor(initial) {
    this.k7f_1 = initial.v5o_1.equals(Support_Supported_getInstance());
    this.l7f_1 = initial.w5o_1.equals(Support_Supported_getInstance());
    this.m7f_1 = initial.x5o_1.equals(Support_Supported_getInstance());
    this.n7f_1 = initial.y5o_1.equals(Support_Supported_getInstance());
  }
  o7f() {
    return new ModelCapabilities(this.k7f_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), this.l7f_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.m7f_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.n7f_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance());
  }
}
class ResponsesCheckpointCodec {
  constructor() {
    this.p7f_1 = Companion_getInstance_0().r6c_1;
    this.q7f_1 = 1;
  }
  r7f(responseId, mode, basis, scope) {
    var payload = JsonUtil_getInstance().d6f(new ResponsesCheckpointPayload(responseId, mode.n3_1), Companion_instance_3.r3o());
    return new ProviderCheckpoint(this.p7f_1, this.q7f_1, basis, scope, Companion_getInstance_2().d40(payload));
  }
  s7f(checkpoint) {
    var migrated = this.t7f(checkpoint);
    // Inline function 'kotlin.runCatching' call
    var tmp;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = JsonUtil_getInstance().e6f(migrated.y6a_1.s42(), Companion_instance_3.r3o());
      tmp = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    // Inline function 'kotlin.Result.getOrNull' call
    var this_0 = tmp;
    var tmp_1;
    if (_Result___get_isFailure__impl__jpiriv(this_0)) {
      tmp_1 = null;
    } else {
      var tmp_2 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_1 = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
    }
    return tmp_1;
  }
  t7f(checkpoint) {
    // Inline function 'kotlin.require' call
    if (!(checkpoint.u6a_1 === this.p7f_1)) {
      var message = "checkpoint provider '" + _ProviderId___get_value__impl__xo1tux(checkpoint.u6a_1) + "' does not match codec '" + _ProviderId___get_value__impl__xo1tux(this.p7f_1) + "'";
      throw IllegalArgumentException.t(toString_0(message));
    }
    return checkpoint;
  }
}
class ToolAcc {
  constructor(callId, nativeItemId, name, args, ref) {
    callId = callId === VOID ? null : callId;
    nativeItemId = nativeItemId === VOID ? null : nativeItemId;
    name = name === VOID ? StringBuilder.v() : name;
    args = args === VOID ? StringBuilder.v() : args;
    ref = ref === VOID ? Companion_instance_0.k60('call') : ref;
    this.u7f_1 = callId;
    this.v7f_1 = nativeItemId;
    this.w7f_1 = name;
    this.x7f_1 = args;
    this.y7f_1 = ref;
  }
}
class MessageAcc {
  constructor(nativeItemId, role, text, refusal, annotations, ref) {
    nativeItemId = nativeItemId === VOID ? null : nativeItemId;
    role = role === VOID ? Role_ASSISTANT_getInstance() : role;
    text = text === VOID ? StringBuilder.v() : text;
    refusal = refusal === VOID ? StringBuilder.v() : refusal;
    var tmp;
    if (annotations === VOID) {
      // Inline function 'kotlin.collections.mutableListOf' call
      tmp = ArrayList.k();
    } else {
      tmp = annotations;
    }
    annotations = tmp;
    ref = ref === VOID ? Companion_instance_0.k60('msg') : ref;
    this.z7f_1 = nativeItemId;
    this.a7g_1 = role;
    this.b7g_1 = text;
    this.c7g_1 = refusal;
    this.d7g_1 = annotations;
    this.e7g_1 = ref;
  }
}
class sam$kotlin_Comparator$0 {
  constructor(function_0) {
    this.r7h_1 = function_0;
  }
  vi(a, b) {
    return this.r7h_1(a, b);
  }
  compare(a, b) {
    return this.vi(a, b);
  }
  n4() {
    return this.r7h_1;
  }
  equals(other) {
    var tmp;
    if (!(other == null) ? isInterface(other, Comparator) : false) {
      var tmp_0;
      if (!(other == null) ? isInterface(other, FunctionAdapter) : false) {
        tmp_0 = equals(this.n4(), other.n4());
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    return hashCode(this.n4());
  }
}
class ResponsesDecoder {
  constructor(mode, persistCheckpoint, basisItems, codec) {
    codec = codec === VOID ? new ResponsesCheckpointCodec() : codec;
    this.f7g_1 = mode;
    this.g7g_1 = persistCheckpoint;
    this.h7g_1 = basisItems;
    this.i7g_1 = codec;
    this.j7g_1 = LinkedHashMap.hc();
    this.k7g_1 = LinkedHashMap.hc();
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.l7g_1 = ArrayList.k();
    this.m7g_1 = HashSet.ga();
    this.n7g_1 = HashSet.ga();
    this.o7g_1 = Companion_getInstance_1().g5s_1;
    this.p7g_1 = null;
    this.q7g_1 = null;
    this.r7g_1 = null;
    this.s7g_1 = false;
    this.t7g_1 = false;
  }
  z6f(frame) {
    var tmp;
    if (frame instanceof HttpError) {
      this.q7g_1 = decodeHttpError(this, frame);
      tmp = finishFailed(this);
    } else {
      if (frame instanceof Sse) {
        tmp = this.s7h(frame.d6m_1, frame.e6m_1);
      } else {
        if (frame instanceof Body) {
          tmp = acceptCompletedJson(this, frame.h6m_1);
        } else {
          if (frame instanceof Ndjson) {
            tmp = this.s7h(null, frame.i6m_1);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
    return tmp;
  }
  s7h(event, data) {
    if (isBlank(data) || data === '[DONE]')
      return emptyList();
    // Inline function 'kotlin.runCatching' call
    var tmp;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = get_jsonObject(JsonUtil_getInstance().c6f_1.q3m(data));
      tmp = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_0;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    // Inline function 'kotlin.getOrElse' call
    var this_0 = tmp;
    var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
    var tmp_1;
    if (exception == null) {
      var tmp_2 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_1 = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
    } else {
      return emptyList();
    }
    var obj = tmp_1;
    return dispatch(this, event == null ? str(obj, 'type') : event, obj);
  }
  g6g() {
    if (this.s7g_1)
      return emptyList();
    if (!(this.q7g_1 == null))
      return finishFailed(this);
    // Inline function 'kotlin.collections.mutableListOf' call
    var events = ArrayList.k();
    // Inline function 'kotlin.collections.sortedBy' call
    var this_0 = this.k7g_1.l1();
    // Inline function 'kotlin.comparisons.compareBy' call
    var tmp = ResponsesDecoder$finish$lambda;
    var tmp$ret$1 = new sam$kotlin_Comparator$0(tmp);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = sortedWith(this_0, tmp$ret$1).y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      $l$block: {
        // Inline function 'kotlin.collections.component2' call
        var acc = element.n1();
        var tmp_0;
        // Inline function 'kotlin.text.isEmpty' call
        var this_1 = acc.b7g_1;
        if (charSequenceLength(this_1) === 0) {
          // Inline function 'kotlin.text.isEmpty' call
          var this_2 = acc.c7g_1;
          tmp_0 = charSequenceLength(this_2) === 0;
        } else {
          tmp_0 = false;
        }
        if (tmp_0) {
          break $l$block;
        }
        // Inline function 'kotlin.collections.plusAssign' call
        var elements = emitMapped(this, toItem_0(this, acc));
        addAll(events, elements);
      }
    }
    // Inline function 'kotlin.collections.sortedBy' call
    var this_3 = this.j7g_1.l1();
    // Inline function 'kotlin.comparisons.compareBy' call
    var tmp_1 = ResponsesDecoder$finish$lambda_0;
    var tmp$ret$9 = new sam$kotlin_Comparator$0(tmp_1);
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s_0 = sortedWith(this_3, tmp$ret$9).y();
    while (_iterator__ex2g4s_0.z()) {
      var element_0 = _iterator__ex2g4s_0.a1();
      $l$block_0: {
        // Inline function 'kotlin.collections.component2' call
        var acc_0 = element_0.n1();
        var tmp_2;
        // Inline function 'kotlin.text.isEmpty' call
        var this_4 = acc_0.w7f_1;
        if (charSequenceLength(this_4) === 0) {
          // Inline function 'kotlin.text.isEmpty' call
          var this_5 = acc_0.x7f_1;
          tmp_2 = charSequenceLength(this_5) === 0;
        } else {
          tmp_2 = false;
        }
        if (tmp_2) {
          break $l$block_0;
        }
        // Inline function 'kotlin.collections.plusAssign' call
        var elements_0 = emitMapped(this, toItem(this, acc_0));
        addAll(events, elements_0);
      }
    }
    this.s7g_1 = true;
    // Inline function 'kotlin.collections.plusAssign' call
    var element_1 = new Finished(terminalResponse(this));
    events.l(element_1);
    return events;
  }
}
class OpenAIResponsesModel$wireFrames$slambda$slambda {
  constructor(this$0, $request, $this_flow) {
    this.t7h_1 = this$0;
    this.u7h_1 = $request;
    this.v7h_1 = $this_flow;
  }
  w1f($this$withTimeoutOrNull, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8.bind(VOID, this, $this$withTimeoutOrNull), $completion);
  }
  td(p1, $completion) {
    return this.w1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class OpenAIResponsesModel$wireFrames$slambda {
  constructor(this$0, $request) {
    this.m7i_1 = this$0;
    this.n7i_1 = $request;
  }
  s6l($this$flow, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_0.bind(VOID, this, $this$flow), $completion);
  }
  td(p1, $completion) {
    return this.s6l((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class OpenAIResponsesModel extends ChatModel {
  constructor(config, transport, params, capabilities, codec) {
    params = params === VOID ? new ResponsesParams() : params;
    capabilities = capabilities === VOID ? get_DEFAULT_CAPABILITIES() : capabilities;
    codec = codec === VOID ? new ResponsesCheckpointCodec() : codec;
    super(config, transport);
    this.y7h_1 = params;
    this.z7h_1 = capabilities;
    this.a7i_1 = codec;
  }
  a5p() {
    return this.z7h_1;
  }
  y1s() {
    return new ResponsesDecoder(this.y7h_1.j7i_1, this.y7h_1.k7i_1, emptyList(), this.a7i_1);
  }
  e6g(request) {
    return new ResponsesDecoder(this.y7h_1.j7i_1, this.y7h_1.k7i_1, request.c5y_1, this.a7i_1);
  }
  j6g(req) {
    var body = JsonUtil_getInstance().d6f(this.o7i(req), Companion_getInstance_3().r3o());
    var expect = this.y7h_1.g7i_1 === true ? Framing_Json_getInstance() : Framing_Sse_getInstance();
    return new WireCall(HttpMethod_POST_getInstance(), this.c6g_1.n6g_1, authHeaders(this.c6g_1), body, expect, req.g5y_1, timeouts(this.c6g_1), this.c6g_1.w6g_1, this.c6g_1.x6g_1);
  }
  f6g(request) {
    if (!(this.y7h_1.g7i_1 === true))
      return super.f6g(request);
    return flow(OpenAIResponsesModel$wireFrames$slambda_0(this, request));
  }
  o7i(req) {
    var tmp0_safe_receiver = req.f5y_1;
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.takeIf' call
      var tmp_0;
      if (tmp0_safe_receiver.u6a_1 === Companion_getInstance_0().r6c_1) {
        tmp_0 = tmp0_safe_receiver;
      } else {
        tmp_0 = null;
      }
      tmp = tmp_0;
    }
    var tmp1_safe_receiver = tmp;
    var tmp_1;
    if (tmp1_safe_receiver == null) {
      tmp_1 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_1 = this.a7i_1.s7f(tmp1_safe_receiver);
    }
    var checkpoint = tmp_1;
    var chainStored = this.y7h_1.j7i_1.equals(ResponsesStateMode_ServerStored_getInstance()) && !(checkpoint == null);
    var tmp_2;
    if (chainStored) {
      tmp_2 = drop(req.c5y_1, coerceAtMost(ensureNotNull(req.f5y_1).w6a_1.c6b_1, req.c5y_1.b1()));
    } else {
      tmp_2 = req.c5y_1;
    }
    var inputItems = tmp_2;
    var tmp_3;
    switch (this.y7h_1.j7i_1.o3_1) {
      case 1:
        // Inline function 'kotlin.collections.orEmpty' call

        var tmp0_elvis_lhs = this.y7h_1.i7i_1;
        var tmp$ret$4 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
        tmp_3 = distinct(plus_0(tmp$ret$4, 'reasoning.encrypted_content'));
        break;
      case 0:
      case 2:
        tmp_3 = this.y7h_1.i7i_1;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    var include = tmp_3;
    var tmp_4 = toInput(inputItems);
    var tmp_5 = encodeTools(this, req);
    var tmp_6 = toTextFormat(req.e5y_1);
    var tmp_7 = chainStored ? checkpoint.q7i_1 : null;
    var tmp_8 = this.y7h_1.j7i_1.equals(ResponsesStateMode_ServerStored_getInstance());
    var tmp_9 = !(this.y7h_1.g7i_1 === true);
    var tmp_10;
    switch (this.z7h_1.v5o_1.o3_1) {
      case 0:
        var tmp_11;
        // Inline function 'kotlin.collections.isNotEmpty' call

        if (!req.d5y_1.h1()) {
          tmp_11 = true;
        } else {
          tmp_11 = null;
        }

        tmp_10 = tmp_11;
        break;
      case 1:
        tmp_10 = false;
        break;
      case 2:
        tmp_10 = null;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return new ResponsesRequest(this.c6g_1.p6g_1, tmp_4, req.b5y_1, tmp_5, tmp_6, tmp_7, tmp_8, tmp_9, include, this.y7h_1.e7i_1, this.y7h_1.b7i_1, this.y7h_1.c7i_1, this.y7h_1.d7i_1, tmp_10, this.y7h_1.f7i_1, this.y7h_1.g7i_1);
  }
  h6c(responseId, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_abandon__qxshi9.bind(VOID, this, responseId), $completion);
  }
}
class ResponsesParams {
  constructor(temperature, topP, maxOutputTokens, reasoning, truncation, background, backgroundPollIntervalMs, include, stateMode, persistCheckpoint, serverTools) {
    temperature = temperature === VOID ? null : temperature;
    topP = topP === VOID ? null : topP;
    maxOutputTokens = maxOutputTokens === VOID ? null : maxOutputTokens;
    reasoning = reasoning === VOID ? null : reasoning;
    truncation = truncation === VOID ? null : truncation;
    background = background === VOID ? null : background;
    backgroundPollIntervalMs = backgroundPollIntervalMs === VOID ? new Long(2000, 0) : backgroundPollIntervalMs;
    include = include === VOID ? null : include;
    stateMode = stateMode === VOID ? ResponsesStateMode_Replayable_getInstance() : stateMode;
    persistCheckpoint = persistCheckpoint === VOID ? false : persistCheckpoint;
    serverTools = serverTools === VOID ? emptyList() : serverTools;
    this.b7i_1 = temperature;
    this.c7i_1 = topP;
    this.d7i_1 = maxOutputTokens;
    this.e7i_1 = reasoning;
    this.f7i_1 = truncation;
    this.g7i_1 = background;
    this.h7i_1 = backgroundPollIntervalMs;
    this.i7i_1 = include;
    this.j7i_1 = stateMode;
    this.k7i_1 = persistCheckpoint;
    this.l7i_1 = serverTools;
    // Inline function 'kotlin.require' call
    if (!(this.h7i_1.s1(new Long(0, 0)) > 0)) {
      var message = 'backgroundPollIntervalMs must be positive';
      throw IllegalArgumentException.t(toString_0(message));
    }
  }
  toString() {
    return 'ResponsesParams(temperature=' + this.b7i_1 + ', topP=' + this.c7i_1 + ', maxOutputTokens=' + this.d7i_1 + ', reasoning=' + toString(this.e7i_1) + ', truncation=' + this.f7i_1 + ', background=' + this.g7i_1 + ', backgroundPollIntervalMs=' + this.h7i_1.toString() + ', include=' + toString(this.i7i_1) + ', stateMode=' + this.j7i_1.toString() + ', persistCheckpoint=' + this.k7i_1 + ', serverTools=' + toString_0(this.l7i_1) + ')';
  }
  hashCode() {
    var result = this.b7i_1 == null ? 0 : getNumberHashCode(this.b7i_1);
    result = imul(result, 31) + (this.c7i_1 == null ? 0 : getNumberHashCode(this.c7i_1)) | 0;
    result = imul(result, 31) + (this.d7i_1 == null ? 0 : this.d7i_1) | 0;
    result = imul(result, 31) + (this.e7i_1 == null ? 0 : this.e7i_1.hashCode()) | 0;
    result = imul(result, 31) + (this.f7i_1 == null ? 0 : getStringHashCode(this.f7i_1)) | 0;
    result = imul(result, 31) + (this.g7i_1 == null ? 0 : getBooleanHashCode(this.g7i_1)) | 0;
    result = imul(result, 31) + this.h7i_1.hashCode() | 0;
    result = imul(result, 31) + (this.i7i_1 == null ? 0 : hashCode(this.i7i_1)) | 0;
    result = imul(result, 31) + this.j7i_1.hashCode() | 0;
    result = imul(result, 31) + getBooleanHashCode(this.k7i_1) | 0;
    result = imul(result, 31) + hashCode(this.l7i_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ResponsesParams))
      return false;
    var tmp0_other_with_cast = other instanceof ResponsesParams ? other : THROW_CCE();
    if (!equals(this.b7i_1, tmp0_other_with_cast.b7i_1))
      return false;
    if (!equals(this.c7i_1, tmp0_other_with_cast.c7i_1))
      return false;
    if (!(this.d7i_1 == tmp0_other_with_cast.d7i_1))
      return false;
    if (!equals(this.e7i_1, tmp0_other_with_cast.e7i_1))
      return false;
    if (!(this.f7i_1 == tmp0_other_with_cast.f7i_1))
      return false;
    if (!(this.g7i_1 == tmp0_other_with_cast.g7i_1))
      return false;
    if (!this.h7i_1.equals(tmp0_other_with_cast.h7i_1))
      return false;
    if (!equals(this.i7i_1, tmp0_other_with_cast.i7i_1))
      return false;
    if (!this.j7i_1.equals(tmp0_other_with_cast.j7i_1))
      return false;
    if (!(this.k7i_1 === tmp0_other_with_cast.k7i_1))
      return false;
    if (!equals(this.l7i_1, tmp0_other_with_cast.l7i_1))
      return false;
    return true;
  }
}
class Companion {
  constructor() {
    Companion_instance_2 = this;
    var tmp = this;
    var tmp_0 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    var tmp_1 = lazy(tmp_0, ResponsesRequest$Companion$$childSerializers$_anonymous__ibm9u5);
    var tmp_2 = LazyThreadSafetyMode_PUBLICATION_getInstance();
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    tmp.p7i_1 = [null, null, null, tmp_1, null, null, null, null, lazy(tmp_2, ResponsesRequest$Companion$$childSerializers$_anonymous__ibm9u5_0), null, null, null, null, null, null, null, null];
  }
  r3o() {
    return $serializer_getInstance();
  }
}
class $serializer {
  constructor() {
    $serializer_instance = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.openai.responses.ResponsesRequest', this, 17);
    tmp0_serialDesc.u25('model', false);
    tmp0_serialDesc.u25('input', false);
    tmp0_serialDesc.u25('instructions', true);
    tmp0_serialDesc.u25('tools', true);
    tmp0_serialDesc.u25('text', true);
    tmp0_serialDesc.u25('previous_response_id', true);
    tmp0_serialDesc.u25('store', true);
    tmp0_serialDesc.u25('stream', true);
    tmp0_serialDesc.u25('include', true);
    tmp0_serialDesc.u25('reasoning', true);
    tmp0_serialDesc.u25('temperature', true);
    tmp0_serialDesc.u25('top_p', true);
    tmp0_serialDesc.u25('max_output_tokens', true);
    tmp0_serialDesc.u25('parallel_tool_calls', true);
    tmp0_serialDesc.u25('truncation', true);
    tmp0_serialDesc.u25('background', true);
    tmp0_serialDesc.u25('metadata', true);
    this.s7i_1 = tmp0_serialDesc;
  }
  t7i(encoder, value) {
    var tmp0_desc = this.s7i_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    var tmp2_cached = Companion_getInstance_3().p7i_1;
    tmp1_output.v1z(tmp0_desc, 0, value.u7i_1);
    tmp1_output.x1z(tmp0_desc, 1, JsonElementSerializer_getInstance(), value.v7i_1);
    if (tmp1_output.d20(tmp0_desc, 2) ? true : !(value.w7i_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 2, StringSerializer_getInstance(), value.w7i_1);
    }
    if (tmp1_output.d20(tmp0_desc, 3) ? true : !(value.x7i_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 3, tmp2_cached[3].n1(), value.x7i_1);
    }
    if (tmp1_output.d20(tmp0_desc, 4) ? true : !(value.y7i_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 4, $serializer_getInstance_1(), value.y7i_1);
    }
    if (tmp1_output.d20(tmp0_desc, 5) ? true : !(value.z7i_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 5, StringSerializer_getInstance(), value.z7i_1);
    }
    if (tmp1_output.d20(tmp0_desc, 6) ? true : !(value.a7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 6, BooleanSerializer_getInstance(), value.a7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 7) ? true : !(value.b7j_1 === true)) {
      tmp1_output.n1z(tmp0_desc, 7, value.b7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 8) ? true : !(value.c7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 8, tmp2_cached[8].n1(), value.c7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 9) ? true : !(value.d7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 9, JsonObjectSerializer_getInstance(), value.d7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 10) ? true : !(value.e7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 10, DoubleSerializer_getInstance(), value.e7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 11) ? true : !(value.f7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 11, DoubleSerializer_getInstance(), value.f7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 12) ? true : !(value.g7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 12, IntSerializer_getInstance(), value.g7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 13) ? true : !(value.h7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 13, BooleanSerializer_getInstance(), value.h7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 14) ? true : !(value.i7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 14, StringSerializer_getInstance(), value.i7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 15) ? true : !(value.j7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 15, BooleanSerializer_getInstance(), value.j7j_1);
    }
    if (tmp1_output.d20(tmp0_desc, 16) ? true : !(value.k7j_1 == null)) {
      tmp1_output.z1z(tmp0_desc, 16, JsonObjectSerializer_getInstance(), value.k7j_1);
    }
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.t7i(encoder, value instanceof ResponsesRequest ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.s7i_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_local2 = null;
    var tmp7_local3 = null;
    var tmp8_local4 = null;
    var tmp9_local5 = null;
    var tmp10_local6 = null;
    var tmp11_local7 = false;
    var tmp12_local8 = null;
    var tmp13_local9 = null;
    var tmp14_local10 = null;
    var tmp15_local11 = null;
    var tmp16_local12 = null;
    var tmp17_local13 = null;
    var tmp18_local14 = null;
    var tmp19_local15 = null;
    var tmp20_local16 = null;
    var tmp21_input = decoder.f1y(tmp0_desc);
    var tmp22_cached = Companion_getInstance_3().p7i_1;
    if (tmp21_input.v1y()) {
      tmp4_local0 = tmp21_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp21_input.r1y(tmp0_desc, 1, JsonElementSerializer_getInstance(), tmp5_local1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
      tmp6_local2 = tmp21_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
      tmp3_bitMask0 = tmp3_bitMask0 | 4;
      tmp7_local3 = tmp21_input.t1y(tmp0_desc, 3, tmp22_cached[3].n1(), tmp7_local3);
      tmp3_bitMask0 = tmp3_bitMask0 | 8;
      tmp8_local4 = tmp21_input.t1y(tmp0_desc, 4, $serializer_getInstance_1(), tmp8_local4);
      tmp3_bitMask0 = tmp3_bitMask0 | 16;
      tmp9_local5 = tmp21_input.t1y(tmp0_desc, 5, StringSerializer_getInstance(), tmp9_local5);
      tmp3_bitMask0 = tmp3_bitMask0 | 32;
      tmp10_local6 = tmp21_input.t1y(tmp0_desc, 6, BooleanSerializer_getInstance(), tmp10_local6);
      tmp3_bitMask0 = tmp3_bitMask0 | 64;
      tmp11_local7 = tmp21_input.h1y(tmp0_desc, 7);
      tmp3_bitMask0 = tmp3_bitMask0 | 128;
      tmp12_local8 = tmp21_input.t1y(tmp0_desc, 8, tmp22_cached[8].n1(), tmp12_local8);
      tmp3_bitMask0 = tmp3_bitMask0 | 256;
      tmp13_local9 = tmp21_input.t1y(tmp0_desc, 9, JsonObjectSerializer_getInstance(), tmp13_local9);
      tmp3_bitMask0 = tmp3_bitMask0 | 512;
      tmp14_local10 = tmp21_input.t1y(tmp0_desc, 10, DoubleSerializer_getInstance(), tmp14_local10);
      tmp3_bitMask0 = tmp3_bitMask0 | 1024;
      tmp15_local11 = tmp21_input.t1y(tmp0_desc, 11, DoubleSerializer_getInstance(), tmp15_local11);
      tmp3_bitMask0 = tmp3_bitMask0 | 2048;
      tmp16_local12 = tmp21_input.t1y(tmp0_desc, 12, IntSerializer_getInstance(), tmp16_local12);
      tmp3_bitMask0 = tmp3_bitMask0 | 4096;
      tmp17_local13 = tmp21_input.t1y(tmp0_desc, 13, BooleanSerializer_getInstance(), tmp17_local13);
      tmp3_bitMask0 = tmp3_bitMask0 | 8192;
      tmp18_local14 = tmp21_input.t1y(tmp0_desc, 14, StringSerializer_getInstance(), tmp18_local14);
      tmp3_bitMask0 = tmp3_bitMask0 | 16384;
      tmp19_local15 = tmp21_input.t1y(tmp0_desc, 15, BooleanSerializer_getInstance(), tmp19_local15);
      tmp3_bitMask0 = tmp3_bitMask0 | 32768;
      tmp20_local16 = tmp21_input.t1y(tmp0_desc, 16, JsonObjectSerializer_getInstance(), tmp20_local16);
      tmp3_bitMask0 = tmp3_bitMask0 | 65536;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp21_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp21_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp21_input.r1y(tmp0_desc, 1, JsonElementSerializer_getInstance(), tmp5_local1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          case 2:
            tmp6_local2 = tmp21_input.t1y(tmp0_desc, 2, StringSerializer_getInstance(), tmp6_local2);
            tmp3_bitMask0 = tmp3_bitMask0 | 4;
            break;
          case 3:
            tmp7_local3 = tmp21_input.t1y(tmp0_desc, 3, tmp22_cached[3].n1(), tmp7_local3);
            tmp3_bitMask0 = tmp3_bitMask0 | 8;
            break;
          case 4:
            tmp8_local4 = tmp21_input.t1y(tmp0_desc, 4, $serializer_getInstance_1(), tmp8_local4);
            tmp3_bitMask0 = tmp3_bitMask0 | 16;
            break;
          case 5:
            tmp9_local5 = tmp21_input.t1y(tmp0_desc, 5, StringSerializer_getInstance(), tmp9_local5);
            tmp3_bitMask0 = tmp3_bitMask0 | 32;
            break;
          case 6:
            tmp10_local6 = tmp21_input.t1y(tmp0_desc, 6, BooleanSerializer_getInstance(), tmp10_local6);
            tmp3_bitMask0 = tmp3_bitMask0 | 64;
            break;
          case 7:
            tmp11_local7 = tmp21_input.h1y(tmp0_desc, 7);
            tmp3_bitMask0 = tmp3_bitMask0 | 128;
            break;
          case 8:
            tmp12_local8 = tmp21_input.t1y(tmp0_desc, 8, tmp22_cached[8].n1(), tmp12_local8);
            tmp3_bitMask0 = tmp3_bitMask0 | 256;
            break;
          case 9:
            tmp13_local9 = tmp21_input.t1y(tmp0_desc, 9, JsonObjectSerializer_getInstance(), tmp13_local9);
            tmp3_bitMask0 = tmp3_bitMask0 | 512;
            break;
          case 10:
            tmp14_local10 = tmp21_input.t1y(tmp0_desc, 10, DoubleSerializer_getInstance(), tmp14_local10);
            tmp3_bitMask0 = tmp3_bitMask0 | 1024;
            break;
          case 11:
            tmp15_local11 = tmp21_input.t1y(tmp0_desc, 11, DoubleSerializer_getInstance(), tmp15_local11);
            tmp3_bitMask0 = tmp3_bitMask0 | 2048;
            break;
          case 12:
            tmp16_local12 = tmp21_input.t1y(tmp0_desc, 12, IntSerializer_getInstance(), tmp16_local12);
            tmp3_bitMask0 = tmp3_bitMask0 | 4096;
            break;
          case 13:
            tmp17_local13 = tmp21_input.t1y(tmp0_desc, 13, BooleanSerializer_getInstance(), tmp17_local13);
            tmp3_bitMask0 = tmp3_bitMask0 | 8192;
            break;
          case 14:
            tmp18_local14 = tmp21_input.t1y(tmp0_desc, 14, StringSerializer_getInstance(), tmp18_local14);
            tmp3_bitMask0 = tmp3_bitMask0 | 16384;
            break;
          case 15:
            tmp19_local15 = tmp21_input.t1y(tmp0_desc, 15, BooleanSerializer_getInstance(), tmp19_local15);
            tmp3_bitMask0 = tmp3_bitMask0 | 32768;
            break;
          case 16:
            tmp20_local16 = tmp21_input.t1y(tmp0_desc, 16, JsonObjectSerializer_getInstance(), tmp20_local16);
            tmp3_bitMask0 = tmp3_bitMask0 | 65536;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp21_input.g1y(tmp0_desc);
    return ResponsesRequest.l7j(tmp3_bitMask0, tmp4_local0, tmp5_local1, tmp6_local2, tmp7_local3, tmp8_local4, tmp9_local5, tmp10_local6, tmp11_local7, tmp12_local8, tmp13_local9, tmp14_local10, tmp15_local11, tmp16_local12, tmp17_local13, tmp18_local14, tmp19_local15, tmp20_local16, null);
  }
  w1t() {
    return this.s7i_1;
  }
  j26() {
    var tmp0_cached = Companion_getInstance_3().p7i_1;
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), JsonElementSerializer_getInstance(), get_nullable(StringSerializer_getInstance()), get_nullable(tmp0_cached[3].n1()), get_nullable($serializer_getInstance_1()), get_nullable(StringSerializer_getInstance()), get_nullable(BooleanSerializer_getInstance()), BooleanSerializer_getInstance(), get_nullable(tmp0_cached[8].n1()), get_nullable(JsonObjectSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(DoubleSerializer_getInstance()), get_nullable(IntSerializer_getInstance()), get_nullable(BooleanSerializer_getInstance()), get_nullable(StringSerializer_getInstance()), get_nullable(BooleanSerializer_getInstance()), get_nullable(JsonObjectSerializer_getInstance())];
  }
}
class ResponsesRequest {
  constructor(model, input, instructions, tools, text, previousResponseId, store, stream, include, reasoning, temperature, topP, maxOutputTokens, parallelToolCalls, truncation, background, metadata) {
    Companion_getInstance_3();
    instructions = instructions === VOID ? null : instructions;
    tools = tools === VOID ? null : tools;
    text = text === VOID ? null : text;
    previousResponseId = previousResponseId === VOID ? null : previousResponseId;
    store = store === VOID ? null : store;
    stream = stream === VOID ? true : stream;
    include = include === VOID ? null : include;
    reasoning = reasoning === VOID ? null : reasoning;
    temperature = temperature === VOID ? null : temperature;
    topP = topP === VOID ? null : topP;
    maxOutputTokens = maxOutputTokens === VOID ? null : maxOutputTokens;
    parallelToolCalls = parallelToolCalls === VOID ? null : parallelToolCalls;
    truncation = truncation === VOID ? null : truncation;
    background = background === VOID ? null : background;
    metadata = metadata === VOID ? null : metadata;
    this.u7i_1 = model;
    this.v7i_1 = input;
    this.w7i_1 = instructions;
    this.x7i_1 = tools;
    this.y7i_1 = text;
    this.z7i_1 = previousResponseId;
    this.a7j_1 = store;
    this.b7j_1 = stream;
    this.c7j_1 = include;
    this.d7j_1 = reasoning;
    this.e7j_1 = temperature;
    this.f7j_1 = topP;
    this.g7j_1 = maxOutputTokens;
    this.h7j_1 = parallelToolCalls;
    this.i7j_1 = truncation;
    this.j7j_1 = background;
    this.k7j_1 = metadata;
  }
  toString() {
    return 'ResponsesRequest(model=' + this.u7i_1 + ', input=' + toString_0(this.v7i_1) + ', instructions=' + this.w7i_1 + ', tools=' + toString(this.x7i_1) + ', text=' + toString(this.y7i_1) + ', previousResponseId=' + this.z7i_1 + ', store=' + this.a7j_1 + ', stream=' + this.b7j_1 + ', include=' + toString(this.c7j_1) + ', reasoning=' + toString(this.d7j_1) + ', temperature=' + this.e7j_1 + ', topP=' + this.f7j_1 + ', maxOutputTokens=' + this.g7j_1 + ', parallelToolCalls=' + this.h7j_1 + ', truncation=' + this.i7j_1 + ', background=' + this.j7j_1 + ', metadata=' + toString(this.k7j_1) + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.u7i_1);
    result = imul(result, 31) + hashCode(this.v7i_1) | 0;
    result = imul(result, 31) + (this.w7i_1 == null ? 0 : getStringHashCode(this.w7i_1)) | 0;
    result = imul(result, 31) + (this.x7i_1 == null ? 0 : hashCode(this.x7i_1)) | 0;
    result = imul(result, 31) + (this.y7i_1 == null ? 0 : this.y7i_1.hashCode()) | 0;
    result = imul(result, 31) + (this.z7i_1 == null ? 0 : getStringHashCode(this.z7i_1)) | 0;
    result = imul(result, 31) + (this.a7j_1 == null ? 0 : getBooleanHashCode(this.a7j_1)) | 0;
    result = imul(result, 31) + getBooleanHashCode(this.b7j_1) | 0;
    result = imul(result, 31) + (this.c7j_1 == null ? 0 : hashCode(this.c7j_1)) | 0;
    result = imul(result, 31) + (this.d7j_1 == null ? 0 : this.d7j_1.hashCode()) | 0;
    result = imul(result, 31) + (this.e7j_1 == null ? 0 : getNumberHashCode(this.e7j_1)) | 0;
    result = imul(result, 31) + (this.f7j_1 == null ? 0 : getNumberHashCode(this.f7j_1)) | 0;
    result = imul(result, 31) + (this.g7j_1 == null ? 0 : this.g7j_1) | 0;
    result = imul(result, 31) + (this.h7j_1 == null ? 0 : getBooleanHashCode(this.h7j_1)) | 0;
    result = imul(result, 31) + (this.i7j_1 == null ? 0 : getStringHashCode(this.i7j_1)) | 0;
    result = imul(result, 31) + (this.j7j_1 == null ? 0 : getBooleanHashCode(this.j7j_1)) | 0;
    result = imul(result, 31) + (this.k7j_1 == null ? 0 : this.k7j_1.hashCode()) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ResponsesRequest))
      return false;
    var tmp0_other_with_cast = other instanceof ResponsesRequest ? other : THROW_CCE();
    if (!(this.u7i_1 === tmp0_other_with_cast.u7i_1))
      return false;
    if (!equals(this.v7i_1, tmp0_other_with_cast.v7i_1))
      return false;
    if (!(this.w7i_1 == tmp0_other_with_cast.w7i_1))
      return false;
    if (!equals(this.x7i_1, tmp0_other_with_cast.x7i_1))
      return false;
    if (!equals(this.y7i_1, tmp0_other_with_cast.y7i_1))
      return false;
    if (!(this.z7i_1 == tmp0_other_with_cast.z7i_1))
      return false;
    if (!(this.a7j_1 == tmp0_other_with_cast.a7j_1))
      return false;
    if (!(this.b7j_1 === tmp0_other_with_cast.b7j_1))
      return false;
    if (!equals(this.c7j_1, tmp0_other_with_cast.c7j_1))
      return false;
    if (!equals(this.d7j_1, tmp0_other_with_cast.d7j_1))
      return false;
    if (!equals(this.e7j_1, tmp0_other_with_cast.e7j_1))
      return false;
    if (!equals(this.f7j_1, tmp0_other_with_cast.f7j_1))
      return false;
    if (!(this.g7j_1 == tmp0_other_with_cast.g7j_1))
      return false;
    if (!(this.h7j_1 == tmp0_other_with_cast.h7j_1))
      return false;
    if (!(this.i7j_1 == tmp0_other_with_cast.i7j_1))
      return false;
    if (!(this.j7j_1 == tmp0_other_with_cast.j7j_1))
      return false;
    if (!equals(this.k7j_1, tmp0_other_with_cast.k7j_1))
      return false;
    return true;
  }
  static l7j(seen0, model, input, instructions, tools, text, previousResponseId, store, stream, include, reasoning, temperature, topP, maxOutputTokens, parallelToolCalls, truncation, background, metadata, serializationConstructorMarker) {
    Companion_getInstance_3();
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance().s7i_1);
    }
    var $this = createThis(this);
    $this.u7i_1 = model;
    $this.v7i_1 = input;
    if (0 === (seen0 & 4))
      $this.w7i_1 = null;
    else
      $this.w7i_1 = instructions;
    if (0 === (seen0 & 8))
      $this.x7i_1 = null;
    else
      $this.x7i_1 = tools;
    if (0 === (seen0 & 16))
      $this.y7i_1 = null;
    else
      $this.y7i_1 = text;
    if (0 === (seen0 & 32))
      $this.z7i_1 = null;
    else
      $this.z7i_1 = previousResponseId;
    if (0 === (seen0 & 64))
      $this.a7j_1 = null;
    else
      $this.a7j_1 = store;
    if (0 === (seen0 & 128))
      $this.b7j_1 = true;
    else
      $this.b7j_1 = stream;
    if (0 === (seen0 & 256))
      $this.c7j_1 = null;
    else
      $this.c7j_1 = include;
    if (0 === (seen0 & 512))
      $this.d7j_1 = null;
    else
      $this.d7j_1 = reasoning;
    if (0 === (seen0 & 1024))
      $this.e7j_1 = null;
    else
      $this.e7j_1 = temperature;
    if (0 === (seen0 & 2048))
      $this.f7j_1 = null;
    else
      $this.f7j_1 = topP;
    if (0 === (seen0 & 4096))
      $this.g7j_1 = null;
    else
      $this.g7j_1 = maxOutputTokens;
    if (0 === (seen0 & 8192))
      $this.h7j_1 = null;
    else
      $this.h7j_1 = parallelToolCalls;
    if (0 === (seen0 & 16384))
      $this.i7j_1 = null;
    else
      $this.i7j_1 = truncation;
    if (0 === (seen0 & 32768))
      $this.j7j_1 = null;
    else
      $this.j7j_1 = background;
    if (0 === (seen0 & 65536))
      $this.k7j_1 = null;
    else
      $this.k7j_1 = metadata;
    return $this;
  }
}
class Companion_0 {
  r3o() {
    return $serializer_getInstance_0();
  }
}
class $serializer_0 {
  constructor() {
    $serializer_instance_0 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.openai.responses.ResponsesCheckpointPayload', this, 2);
    tmp0_serialDesc.u25('response_id', false);
    tmp0_serialDesc.u25('mode', false);
    this.m7j_1 = tmp0_serialDesc;
  }
  n7j(encoder, value) {
    var tmp0_desc = this.m7j_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.v1z(tmp0_desc, 0, value.q7i_1);
    tmp1_output.v1z(tmp0_desc, 1, value.r7i_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.n7j(encoder, value instanceof ResponsesCheckpointPayload ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.m7j_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_local1 = null;
    var tmp6_input = decoder.f1y(tmp0_desc);
    if (tmp6_input.v1y()) {
      tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
      tmp5_local1 = tmp6_input.p1y(tmp0_desc, 1);
      tmp3_bitMask0 = tmp3_bitMask0 | 2;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp6_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp6_input.p1y(tmp0_desc, 0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          case 1:
            tmp5_local1 = tmp6_input.p1y(tmp0_desc, 1);
            tmp3_bitMask0 = tmp3_bitMask0 | 2;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp6_input.g1y(tmp0_desc);
    return ResponsesCheckpointPayload.o7j(tmp3_bitMask0, tmp4_local0, tmp5_local1, null);
  }
  w1t() {
    return this.m7j_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [StringSerializer_getInstance(), StringSerializer_getInstance()];
  }
}
class ResponsesCheckpointPayload {
  constructor(responseId, mode) {
    this.q7i_1 = responseId;
    this.r7i_1 = mode;
  }
  toString() {
    return 'ResponsesCheckpointPayload(responseId=' + this.q7i_1 + ', mode=' + this.r7i_1 + ')';
  }
  hashCode() {
    var result = getStringHashCode(this.q7i_1);
    result = imul(result, 31) + getStringHashCode(this.r7i_1) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ResponsesCheckpointPayload))
      return false;
    var tmp0_other_with_cast = other instanceof ResponsesCheckpointPayload ? other : THROW_CCE();
    if (!(this.q7i_1 === tmp0_other_with_cast.q7i_1))
      return false;
    if (!(this.r7i_1 === tmp0_other_with_cast.r7i_1))
      return false;
    return true;
  }
  static o7j(seen0, responseId, mode, serializationConstructorMarker) {
    if (!(3 === (3 & seen0))) {
      throwMissingFieldException(seen0, 3, $serializer_getInstance_0().m7j_1);
    }
    var $this = createThis(this);
    $this.q7i_1 = responseId;
    $this.r7i_1 = mode;
    return $this;
  }
}
class Companion_1 {}
class $serializer_1 {
  constructor() {
    $serializer_instance_1 = this;
    var tmp0_serialDesc = new PluginGeneratedSerialDescriptor('org.koaks.provider.openai.responses.ResponsesText', this, 1);
    tmp0_serialDesc.u25('format', false);
    this.p7j_1 = tmp0_serialDesc;
  }
  q7j(encoder, value) {
    var tmp0_desc = this.p7j_1;
    var tmp1_output = encoder.f1y(tmp0_desc);
    tmp1_output.x1z(tmp0_desc, 0, JsonObjectSerializer_getInstance(), value.r7j_1);
    tmp1_output.g1y(tmp0_desc);
  }
  x1t(encoder, value) {
    return this.q7j(encoder, value instanceof ResponsesText ? value : THROW_CCE());
  }
  y1t(decoder) {
    var tmp0_desc = this.p7j_1;
    var tmp1_flag = true;
    var tmp2_index = 0;
    var tmp3_bitMask0 = 0;
    var tmp4_local0 = null;
    var tmp5_input = decoder.f1y(tmp0_desc);
    if (tmp5_input.v1y()) {
      tmp4_local0 = tmp5_input.r1y(tmp0_desc, 0, JsonObjectSerializer_getInstance(), tmp4_local0);
      tmp3_bitMask0 = tmp3_bitMask0 | 1;
    } else
      while (tmp1_flag) {
        tmp2_index = tmp5_input.w1y(tmp0_desc);
        switch (tmp2_index) {
          case -1:
            tmp1_flag = false;
            break;
          case 0:
            tmp4_local0 = tmp5_input.r1y(tmp0_desc, 0, JsonObjectSerializer_getInstance(), tmp4_local0);
            tmp3_bitMask0 = tmp3_bitMask0 | 1;
            break;
          default:
            throw UnknownFieldException.z1v(tmp2_index);
        }
      }
    tmp5_input.g1y(tmp0_desc);
    return ResponsesText.s7j(tmp3_bitMask0, tmp4_local0, null);
  }
  w1t() {
    return this.p7j_1;
  }
  j26() {
    // Inline function 'kotlin.arrayOf' call
    // Inline function 'kotlin.js.unsafeCast' call
    // Inline function 'kotlin.js.asDynamic' call
    return [JsonObjectSerializer_getInstance()];
  }
}
class ResponsesText {
  constructor(format) {
    this.r7j_1 = format;
  }
  toString() {
    return 'ResponsesText(format=' + this.r7j_1.toString() + ')';
  }
  hashCode() {
    return this.r7j_1.hashCode();
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof ResponsesText))
      return false;
    var tmp0_other_with_cast = other instanceof ResponsesText ? other : THROW_CCE();
    if (!this.r7j_1.equals(tmp0_other_with_cast.r7j_1))
      return false;
    return true;
  }
  static s7j(seen0, format, serializationConstructorMarker) {
    if (!(1 === (1 & seen0))) {
      throwMissingFieldException(seen0, 1, $serializer_getInstance_1().p7j_1);
    }
    var $this = createThis(this);
    $this.r7j_1 = format;
    return $this;
  }
}
class OpenAIResponsesConfig {
  constructor(baseUrl, apiKey, modelName) {
    this.t7j_1 = baseUrl;
    this.u7j_1 = apiKey;
    this.v7j_1 = modelName;
    this.w7j_1 = null;
    this.x7j_1 = null;
    this.y7j_1 = null;
    this.z7j_1 = null;
    this.a7k_1 = null;
    this.b7k_1 = null;
    this.c7k_1 = new Long(2000, 0);
    this.d7k_1 = new Long(60000, 0);
    this.e7k_1 = ResponsesStateMode_Replayable_getInstance();
    this.f7k_1 = false;
    this.g7k_1 = null;
    var tmp = this;
    // Inline function 'kotlin.collections.mutableListOf' call
    tmp.h7k_1 = ArrayList.k();
    this.i7k_1 = get_DEFAULT_RESPONSES_CAPABILITIES();
  }
  j7k(searchContextSize) {
    var tmp1 = this.h7k_1;
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.g3p('type', JsonPrimitive_0('web_search'));
    if (searchContextSize == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.g3p('search_context_size', JsonPrimitive_0(searchContextSize));
    }
    // Inline function 'kotlin.collections.plusAssign' call
    var element = builder.x3n();
    tmp1.l(element);
  }
  k7k(vectorStoreIds) {
    var tmp1 = this.h7k_1;
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.g3p('type', JsonPrimitive_0('file_search'));
    // Inline function 'kotlinx.serialization.json.buildJsonArray' call
    var builder_0 = new JsonArrayBuilder();
    // Inline function 'kotlin.collections.forEach' call
    var inductionVariable = 0;
    var last = vectorStoreIds.length;
    while (inductionVariable < last) {
      var element = vectorStoreIds[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      builder_0.e3p(JsonPrimitive_0(element));
    }
    var tmp$ret$3 = builder_0.x3n();
    builder.g3p('vector_store_ids', tmp$ret$3);
    // Inline function 'kotlin.collections.plusAssign' call
    var element_0 = builder.x3n();
    tmp1.l(element_0);
  }
  l7k(container) {
    var tmp1 = this.h7k_1;
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.g3p('type', JsonPrimitive_0('code_interpreter'));
    if (container == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder_0 = new JsonObjectBuilder();
      builder_0.g3p('type', JsonPrimitive_0(container));
      var tmp$ret$1 = builder_0.x3n();
      builder.g3p('container', tmp$ret$1);
    }
    // Inline function 'kotlin.collections.plusAssign' call
    var element = builder.x3n();
    tmp1.l(element);
  }
  m7k(block) {
    var tmp = this;
    // Inline function 'kotlin.apply' call
    var this_0 = new OpenAIResponsesCapabilitiesScope(this.i7k_1);
    block(this_0);
    tmp.i7k_1 = this_0.o7f();
  }
  g7f() {
    return new ModelConfig(normalizeResponsesUrl(this.t7j_1), this.u7j_1, this.v7j_1, VOID, VOID, VOID, VOID, VOID, this.d7k_1);
  }
  h7f() {
    return new ResponsesParams(this.w7j_1, this.x7j_1, this.y7j_1, this.z7j_1, this.a7k_1, this.b7k_1, this.c7k_1, this.g7k_1, this.e7k_1, this.f7k_1, toList(this.h7k_1));
  }
  i7f() {
    return this.i7k_1;
  }
}
class OpenAIResponsesCapabilitiesScope {
  constructor(initial) {
    this.n7k_1 = initial.v5o_1.equals(Support_Supported_getInstance());
    this.o7k_1 = initial.w5o_1.equals(Support_Supported_getInstance());
    this.p7k_1 = initial.x5o_1.equals(Support_Supported_getInstance());
    this.q7k_1 = initial.y5o_1.equals(Support_Supported_getInstance());
  }
  o7f() {
    return new ModelCapabilities(this.n7k_1 ? Support_Supported_getInstance() : Support_Unsupported_getInstance(), this.o7k_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.p7k_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), this.q7k_1 ? Support_Supported_getInstance() : Support_Unknown_getInstance(), Support_Unknown_getInstance());
  }
}
class ResponsesStateMode extends Enum {}
class ResponsesItemTypes {
  constructor() {
    ResponsesItemTypes_instance = this;
    this.u7g_1 = 'message';
    this.v7g_1 = 'function_call';
    this.w7g_1 = 'function_call_output';
    this.x7g_1 = 'file_search_call';
    this.y7g_1 = 'web_search_call';
    this.z7g_1 = 'computer_call';
    this.a7h_1 = 'computer_call_output';
    this.b7h_1 = 'reasoning';
    this.c7h_1 = 'image_generation_call';
    this.d7h_1 = 'code_interpreter_call';
    this.e7h_1 = 'local_shell_call';
    this.f7h_1 = 'local_shell_call_output';
    this.g7h_1 = 'mcp_list_tools';
    this.h7h_1 = 'mcp_approval_request';
    this.i7h_1 = 'mcp_approval_response';
    this.j7h_1 = 'mcp_call';
    this.k7h_1 = 'custom_tool_call';
    this.l7h_1 = 'custom_tool_call_output';
    this.m7h_1 = 'item_reference';
    this.n7h_1 = 'compaction';
    this.o7h_1 = 'tool_search_call';
    this.p7h_1 = 'apply_patch_call';
    this.q7h_1 = setOf(['message', 'function_call', 'function_call_output', 'file_search_call', 'web_search_call', 'computer_call', 'computer_call_output', 'reasoning', 'image_generation_call', 'code_interpreter_call', 'local_shell_call', 'local_shell_call_output', 'mcp_list_tools', 'mcp_approval_request', 'mcp_approval_response', 'mcp_call', 'custom_tool_call', 'custom_tool_call_output', 'item_reference', 'compaction', 'tool_search_call', 'apply_patch_call']);
  }
}
//endregion
function openai(_this__u8e3s4, baseUrl, apiKey, modelName, block) {
  baseUrl = baseUrl === VOID ? 'https://api.openai.com' : baseUrl;
  var tmp;
  if (block === VOID) {
    tmp = openai$lambda;
  } else {
    tmp = block;
  }
  block = tmp;
  // Inline function 'kotlin.apply' call
  var this_0 = new OpenAIConfig(baseUrl, apiKey, modelName);
  block(this_0);
  var cfg = this_0;
  return _this__u8e3s4.t5z(new OpenAIChatModel(cfg.g7f(), _this__u8e3s4.v5z(), cfg.h7f(), cfg.i7f()));
}
function openai$lambda(_this__u8e3s4) {
  return Unit_instance;
}
function acceptCompletedJson($this, text) {
  // Inline function 'kotlin.runCatching' call
  var tmp;
  try {
    // Inline function 'kotlin.Companion.success' call
    var value = get_jsonObject(JsonUtil_getInstance().c6f_1.q3m(text));
    tmp = _Result___init__impl__xyqfz8(value);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var e = $p;
      // Inline function 'kotlin.Companion.failure' call
      tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  // Inline function 'kotlin.getOrElse' call
  var this_0 = tmp;
  var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
  var tmp_1;
  if (exception == null) {
    var tmp_2 = _Result___get_value__impl__bjfvqg(this_0);
    tmp_1 = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
  } else {
    return emptyList();
  }
  var obj = tmp_1;
  var event;
  switch (str(obj, 'status')) {
    case 'queued':
      event = 'response.queued';
      break;
    case 'in_progress':
      event = 'response.in_progress';
      break;
    case 'completed':
      event = 'response.completed';
      break;
    case 'incomplete':
      event = 'response.incomplete';
      break;
    case 'failed':
      event = 'response.failed';
      break;
    case 'cancelled':
      event = 'response.cancelled';
      break;
    default:
      event = str(obj, 'type');
      break;
  }
  var wrapped = wrapResponse($this, obj);
  var eventStartsResponse;
  switch (event) {
    case 'response.created':
    case 'response.queued':
      eventStartsResponse = true;
      break;
    default:
      eventStartsResponse = event === 'response.in_progress';
      break;
  }
  var startedEvents = $this.t7g_1 || eventStartsResponse ? emptyList() : dispatch($this, 'response.created', wrapped);
  return plus(startedEvents, dispatch($this, event, wrapped));
}
function wrapResponse($this, obj) {
  var tmp;
  var tmp_0 = obj.l2g('response');
  if (tmp_0 instanceof JsonObject) {
    tmp = obj;
  } else {
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.g3p('response', obj);
    tmp = builder.x3n();
  }
  return tmp;
}
function dispatch($this, event, obj_0) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var events = ArrayList.k();
  switch (event) {
    case 'response.created':
    case 'response.in_progress':
    case 'response.queued':
      readResponseId($this, obj_0);
      if (!$this.t7g_1) {
        $this.t7g_1 = true;
        // Inline function 'kotlin.collections.plusAssign' call
        var element = new Started($this.p7g_1);
        events.l(element);
      }

      var tmp1_safe_receiver = currentCheckpoint($this);
      if (tmp1_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        // Inline function 'kotlin.collections.plusAssign' call
        var element_0 = new CheckpointUpdated(tmp1_safe_receiver);
        events.l(element_0);
      }

      break;
    case 'response.output_text.delta':
      // Inline function 'kotlin.text.orEmpty' call

      var tmp0_elvis_lhs = str(obj_0, 'delta');
      var delta = tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs;
      // Inline function 'kotlin.text.isNotEmpty' call

      if (charSequenceLength(delta) > 0) {
        var acc = messageAccFor$default($this, int(obj_0, 'output_index'), str(obj_0, 'item_id'));
        acc.b7g_1.tb(delta);
        // Inline function 'kotlin.collections.plusAssign' call
        var element_1 = new TextDelta(delta, acc.e7g_1);
        events.l(element_1);
      }

      break;
    case 'response.refusal.delta':
      var tmp2_safe_receiver = str(obj_0, 'delta');
      if (tmp2_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        messageAccFor$default($this, int(obj_0, 'output_index'), str(obj_0, 'item_id')).c7g_1.tb(tmp2_safe_receiver);
      }

      break;
    case 'response.reasoning_summary_text.delta':
    case 'response.reasoning.delta':
      // Inline function 'kotlin.text.orEmpty' call

      var tmp0_elvis_lhs_0 = str(obj_0, 'delta');
      var delta_0 = tmp0_elvis_lhs_0 == null ? '' : tmp0_elvis_lhs_0;
      // Inline function 'kotlin.text.isNotEmpty' call

      if (charSequenceLength(delta_0) > 0) {
        // Inline function 'kotlin.collections.plusAssign' call
        var element_2 = new ReasoningDelta(delta_0);
        events.l(element_2);
      }

      break;
    case 'response.function_call_arguments.delta':
      var tmp3_elvis_lhs = int(obj_0, 'output_index');
      var index = tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
      var acc_0 = accFor$default($this, index, VOID, str(obj_0, 'item_id'));
      // Inline function 'kotlin.text.orEmpty' call

      var tmp0_elvis_lhs_1 = str(obj_0, 'delta');
      var fragment = tmp0_elvis_lhs_1 == null ? '' : tmp0_elvis_lhs_1;
      acc_0.x7f_1.tb(fragment);
      // Inline function 'kotlin.collections.plusAssign' call

      var element_3 = new ToolCallDelta(_ItemRef___get_value__impl__fpjuyb(acc_0.y7f_1), index, VOID, fragment, acc_0.y7f_1);
      events.l(element_3);
      break;
    case 'response.output_item.added':
      var tmp4_elvis_lhs = obj(obj_0, 'item');
      var tmp;
      if (tmp4_elvis_lhs == null) {
        return events;
      } else {
        tmp = tmp4_elvis_lhs;
      }

      var item = tmp;
      switch (str(item, 'type')) {
        case 'function_call':
        case 'custom_tool_call':
          var acc_1 = accFor($this, int(obj_0, 'output_index'), str(item, 'call_id'), str(item, 'id'));
          // Inline function 'kotlin.text.isEmpty' call

          var this_0 = acc_1.w7f_1;
          if (charSequenceLength(this_0) === 0) {
            var tmp6_safe_receiver = str(item, 'name');
            if (tmp6_safe_receiver == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              acc_1.w7f_1.tb(tmp6_safe_receiver);
            }
          }

          // Inline function 'kotlin.text.isEmpty' call

          var this_1 = acc_1.x7f_1;
          if (charSequenceLength(this_1) === 0) {
            var tmp7_safe_receiver = str(item, 'arguments');
            var tmp_0;
            if (tmp7_safe_receiver == null) {
              tmp_0 = null;
            } else {
              // Inline function 'kotlin.takeIf' call
              var tmp_1;
              // Inline function 'kotlin.text.isNotEmpty' call
              if (charSequenceLength(tmp7_safe_receiver) > 0) {
                tmp_1 = tmp7_safe_receiver;
              } else {
                tmp_1 = null;
              }
              tmp_0 = tmp_1;
            }
            var tmp8_safe_receiver = tmp_0;
            if (tmp8_safe_receiver == null)
              null;
            else {
              // Inline function 'kotlin.let' call
              acc_1.x7f_1.tb(tmp8_safe_receiver);
            }
          }

          break;
        case 'message':
          messageAccFor($this, int(obj_0, 'output_index'), str(item, 'id'), role(item));
          break;
        default:
          break;
      }

      break;
    case 'response.output_item.done':
      var tmp9_elvis_lhs = obj(obj_0, 'item');
      var tmp_2;
      if (tmp9_elvis_lhs == null) {
        return events;
      } else {
        tmp_2 = tmp9_elvis_lhs;
      }

      var item_0 = tmp_2;
      var tmp10_safe_receiver = mapOutputItem($this, item_0, int(obj_0, 'output_index'));
      if (tmp10_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        // Inline function 'kotlin.collections.plusAssign' call
        var elements = emitMapped($this, tmp10_safe_receiver);
        addAll(events, elements);
      }

      break;
    case 'response.output_text.annotation.added':
      var tmp11_safe_receiver = obj(obj_0, 'annotation');
      if (tmp11_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        var tmp0 = messageAccFor$default($this, int(obj_0, 'output_index'), str(obj_0, 'item_id')).d7g_1;
        // Inline function 'kotlin.collections.plusAssign' call
        var element_4 = mapAnnotation($this, tmp11_safe_receiver);
        tmp0.l(element_4);
      }

      break;
    case 'response.completed':
      ingestTerminal($this, obj_0);
      break;
    case 'response.incomplete':
      ingestTerminal($this, obj_0);
      break;
    case 'response.cancelled':
      ingestTerminal($this, obj_0);
      $this.r7g_1 = Cancelled_instance;
      break;
    case 'response.failed':
    case 'error':
      $this.q7g_1 = decodeModelError($this, obj_0);
      return plus(events, finishFailed($this));
    default:
      if (!(event == null)) {
        // Inline function 'kotlin.collections.plusAssign' call
        var element_5 = new ProviderEvent(Companion_getInstance_0().r6c_1, event, obj_0.toString());
        events.l(element_5);
      }

      break;
  }
  return events;
}
function terminalResponse($this) {
  var checkpoint = currentCheckpoint($this);
  return !($this.r7g_1 == null) ? new Incomplete($this.p7g_1, ensureNotNull($this.r7g_1), toList($this.l7g_1), $this.o7g_1, checkpoint) : new Completed($this.p7g_1, toList($this.l7g_1), $this.o7g_1, checkpoint);
}
function finishFailed($this) {
  if ($this.s7g_1)
    return emptyList();
  $this.s7g_1 = true;
  return listOf(new Finished(new Failed(ensureNotNull($this.q7g_1), $this.p7g_1, VOID, $this.o7g_1)));
}
function ingestTerminal($this, obj_0) {
  var tmp0_elvis_lhs = obj(obj_0, 'response');
  var response = tmp0_elvis_lhs == null ? obj_0 : tmp0_elvis_lhs;
  readResponseId($this, response);
  var tmp1_safe_receiver = obj(response, 'usage');
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    $this.o7g_1 = mapUsage($this, tmp1_safe_receiver);
  }
  var tmp = response.l2g('output');
  var tmp2_safe_receiver = tmp instanceof JsonArray ? tmp : null;
  if (tmp2_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var _iterator__ex2g4s = tmp2_safe_receiver.y();
    while (_iterator__ex2g4s.z()) {
      var item = _iterator__ex2g4s.a1();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var tmp3 = checkIndexOverflow(_unary__edvuaz);
      $l$block: {
        var tmp0_elvis_lhs_0 = item instanceof JsonObject ? item : null;
        var tmp_0;
        if (tmp0_elvis_lhs_0 == null) {
          break $l$block;
        } else {
          tmp_0 = tmp0_elvis_lhs_0;
        }
        var item_0 = tmp_0;
        var tmp1_safe_receiver_0 = mapOutputItem($this, item_0, tmp3);
        if (tmp1_safe_receiver_0 == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          remember($this, tmp1_safe_receiver_0);
        }
      }
    }
  }
  if (str(response, 'status') === 'incomplete') {
    $this.r7g_1 = mapIncomplete($this, response);
  }
}
function accFor($this, index, callId, itemId) {
  var tmp0 = $this.j7g_1.j3();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (!(callId == null) && element.u7f_1 == callId || (!(itemId == null) && element.v7f_1 == itemId)) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    tmp$ret$1 = null;
  }
  var tmp0_safe_receiver = tmp$ret$1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    if (callId == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp0_safe_receiver.u7f_1 = callId;
    }
    if (itemId == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp0_safe_receiver.v7f_1 = itemId;
    }
    return tmp0_safe_receiver;
  }
  var tmp;
  if (index == null) {
    var tmp2_safe_receiver = maxOrNull($this.j7g_1.i3());
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver + 1 | 0;
    tmp = tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
  } else {
    tmp = index;
  }
  var key = tmp;
  // Inline function 'kotlin.collections.getOrPut' call
  var this_0 = $this.j7g_1;
  var value = this_0.h3(key);
  var tmp_0;
  if (value == null) {
    var answer = new ToolAcc();
    this_0.k3(key, answer);
    tmp_0 = answer;
  } else {
    tmp_0 = value;
  }
  // Inline function 'kotlin.also' call
  var this_1 = tmp_0;
  if (callId == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    this_1.u7f_1 = callId;
  }
  if (itemId == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    this_1.v7f_1 = itemId;
  }
  return this_1;
}
function accFor$default($this, index, callId, itemId, $super) {
  index = index === VOID ? null : index;
  callId = callId === VOID ? null : callId;
  itemId = itemId === VOID ? null : itemId;
  return accFor($this, index, callId, itemId);
}
function messageAccFor($this, index, itemId, role) {
  var tmp0 = $this.k7g_1.j3();
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (!(itemId == null) && element.z7f_1 == itemId) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    tmp$ret$1 = null;
  }
  var tmp0_safe_receiver = tmp$ret$1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    if (itemId == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp0_safe_receiver.z7f_1 = itemId;
    }
    if (role == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp0_safe_receiver.a7g_1 = role;
    }
    return tmp0_safe_receiver;
  }
  var tmp;
  if (index == null) {
    var tmp2_safe_receiver = maxOrNull($this.k7g_1.i3());
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver + 1 | 0;
    tmp = tmp3_elvis_lhs == null ? 0 : tmp3_elvis_lhs;
  } else {
    tmp = index;
  }
  var key = tmp;
  // Inline function 'kotlin.collections.getOrPut' call
  var this_0 = $this.k7g_1;
  var value = this_0.h3(key);
  var tmp_0;
  if (value == null) {
    var answer = new MessageAcc();
    this_0.k3(key, answer);
    tmp_0 = answer;
  } else {
    tmp_0 = value;
  }
  // Inline function 'kotlin.also' call
  var this_1 = tmp_0;
  if (itemId == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    this_1.z7f_1 = itemId;
  }
  if (role == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    this_1.a7g_1 = role;
  }
  return this_1;
}
function messageAccFor$default($this, index, itemId, role, $super) {
  index = index === VOID ? null : index;
  itemId = itemId === VOID ? null : itemId;
  role = role === VOID ? null : role;
  return messageAccFor($this, index, itemId, role);
}
function seenKey($this, item) {
  var tmp0_safe_receiver = item.e6b();
  var native = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.j6b_1;
  var tmp;
  if (item instanceof ToolCall) {
    tmp = 'call:' + (native == null ? _ItemRef___get_value__impl__fpjuyb(item.x68_1) : native);
  } else {
    if (item instanceof ToolResult) {
      var tmp_0 = _ItemRef___get_value__impl__fpjuyb(item.u68_1);
      tmp = 'result:' + tmp_0 + ':' + (native == null ? _ItemRef___get_value__impl__fpjuyb(item.s68_1) : native);
    } else {
      if (item instanceof Message) {
        var tmp_1 = item.r5o_1.toString();
        tmp = 'msg:' + tmp_1 + ':' + (native == null ? _ItemRef___get_value__impl__fpjuyb(item.p5o_1) : native);
      } else {
        if (item instanceof ReasoningSummary) {
          tmp = 'reason:' + (native == null ? _ItemRef___get_value__impl__fpjuyb(item.f6b_1) : native);
        } else {
          if (item instanceof ProviderItem) {
            tmp = 'prov:' + item.w5y_1 + ':' + (native == null ? _ItemRef___get_value__impl__fpjuyb(item.t5y_1) : native);
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
  }
  return tmp;
}
function remember($this, item) {
  if (!$this.m7g_1.l(seenKey($this, item)))
    return false;
  // Inline function 'kotlin.collections.plusAssign' call
  $this.l7g_1.l(item);
  return true;
}
function emitMapped($this, mapped) {
  // Inline function 'kotlin.collections.mutableListOf' call
  var events = ArrayList.k();
  if (remember($this, mapped)) {
    // Inline function 'kotlin.collections.plusAssign' call
    var element = new ItemAdded(mapped);
    events.l(element);
    var tmp0_safe_receiver = currentCheckpoint($this);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlin.collections.plusAssign' call
      var element_0 = new CheckpointUpdated(tmp0_safe_receiver);
      events.l(element_0);
    }
  }
  var tmp;
  if (mapped instanceof ToolCall) {
    tmp = $this.n7g_1.l(_ItemRef___get_value__impl__fpjuyb(mapped.x68_1));
  } else {
    tmp = false;
  }
  if (tmp) {
    // Inline function 'kotlin.collections.plusAssign' call
    var element_1 = new ToolCallCompleted(toDispatchCall(mapped));
    events.l(element_1);
  }
  return events;
}
function mapOutputItem($this, item, outputIndex) {
  var tmp0_elvis_lhs = str(item, 'type');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var type = tmp;
  var tmp1_safe_receiver = str(item, 'id');
  var tmp_0;
  if (tmp1_safe_receiver == null) {
    tmp_0 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_0 = new ProviderScopedId(Companion_getInstance_0().r6c_1, tmp1_safe_receiver);
  }
  var native = tmp_0;
  var tmp_1;
  switch (type) {
    case 'message':
      var acc = messageAccFor($this, outputIndex, str(item, 'id'), role(item));
      var contentText = extractOutputText($this, item);
      // Inline function 'kotlin.text.isNotEmpty' call

      if (charSequenceLength(contentText) > 0) {
        acc.b7g_1.jh();
        acc.b7g_1.tb(contentText);
      }

      var anns = extractAnnotations($this, item);
      // Inline function 'kotlin.collections.isNotEmpty' call

      if (!anns.h1()) {
        acc.d7g_1.b3();
        // Inline function 'kotlin.collections.plusAssign' call
        var this_0 = acc.d7g_1;
        addAll(this_0, anns);
      }

      var tmp3_safe_receiver = extractRefusal($this, item);
      if (tmp3_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        acc.c7g_1.jh();
        acc.c7g_1.tb(tmp3_safe_receiver);
      }

      tmp_1 = toItem_0($this, acc);
      break;
    case 'function_call':
    case 'custom_tool_call':
      var acc_0 = accFor($this, outputIndex, str(item, 'call_id'), str(item, 'id'));
      // Inline function 'kotlin.text.isEmpty' call

      var this_1 = acc_0.w7f_1;
      if (charSequenceLength(this_1) === 0) {
        var tmp4_safe_receiver = str(item, 'name');
        if (tmp4_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          acc_0.w7f_1.tb(tmp4_safe_receiver);
        }
      }

      // Inline function 'kotlin.text.isEmpty' call

      var this_2 = acc_0.x7f_1;
      if (charSequenceLength(this_2) === 0) {
        var tmp5_safe_receiver = str(item, 'arguments');
        var tmp_2;
        if (tmp5_safe_receiver == null) {
          tmp_2 = null;
        } else {
          // Inline function 'kotlin.takeIf' call
          var tmp_3;
          // Inline function 'kotlin.text.isNotEmpty' call
          if (charSequenceLength(tmp5_safe_receiver) > 0) {
            tmp_3 = tmp5_safe_receiver;
          } else {
            tmp_3 = null;
          }
          tmp_2 = tmp_3;
        }
        var tmp6_safe_receiver = tmp_2;
        if (tmp6_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          acc_0.x7f_1.tb(tmp6_safe_receiver);
        }
      }

      tmp_1 = toItem($this, acc_0);
      break;
    case 'function_call_output':
    case 'custom_tool_call_output':
    case 'computer_call_output':
    case 'local_shell_call_output':
      // Inline function 'kotlin.text.orEmpty' call

      var tmp0_elvis_lhs_0 = str(item, 'call_id');
      var callId = tmp0_elvis_lhs_0 == null ? '' : tmp0_elvis_lhs_0;
      // Inline function 'kotlin.text.ifBlank' call

      var tmp_4;
      if (isBlank(callId)) {
        tmp_4 = _ItemRef___get_value__impl__fpjuyb(Companion_instance_0.k60('call'));
      } else {
        tmp_4 = callId;
      }

      var tmp$ret$18 = tmp_4;
      var tmp_5 = _ItemRef___init__impl__ipmeex(tmp$ret$18);
      // Inline function 'kotlin.text.orEmpty' call

      var tmp0_elvis_lhs_1 = str(item, 'output');
      var tmp_6 = tmp0_elvis_lhs_1 == null ? '' : tmp0_elvis_lhs_1;
      var tmp7_safe_receiver = item.l2g('is_error');
      var tmp8_safe_receiver = tmp7_safe_receiver == null ? null : get_jsonPrimitive(tmp7_safe_receiver);
      tmp_1 = new ToolResult(VOID, native, tmp_5, tmp_6, (tmp8_safe_receiver == null ? null : get_contentOrNull(tmp8_safe_receiver)) === 'true');
      break;
    case 'reasoning':
      var summary = extractReasoningSummary($this, item);
      var tmp_7;
      if (!(item.l2g('encrypted_content') == null)) {
        // Inline function 'kotlin.text.ifBlank' call
        var tmp_8;
        if (isBlank(summary)) {
          tmp_8 = '[reasoning]';
        } else {
          tmp_8 = summary;
        }
        var tmp$ret$21 = tmp_8;
        tmp_7 = providerItem($this, item, type, tmp$ret$21, ReplayPolicy_Required_getInstance(), native);
      } else {
        tmp_7 = new ReasoningSummary(VOID, native, summary);
      }

      tmp_1 = tmp_7;
      break;
    case 'compaction':
      var tmp_9;
      if (str(item, 'encrypted_content') == null) {
        tmp_9 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_9 = '[compaction]';
      }

      var tmp10_elvis_lhs = tmp_9;
      tmp_1 = providerItem($this, item, type, tmp10_elvis_lhs == null ? '[compaction]' : tmp10_elvis_lhs, ReplayPolicy_Required_getInstance(), native);
      break;
    default:
      tmp_1 = providerItem($this, item, type, displayFor($this, item, type), ResponsesItemTypes_getInstance().q7h_1.v2(type) ? ReplayPolicy_Preferred_getInstance() : ReplayPolicy_Required_getInstance(), native);
      break;
  }
  return tmp_1;
}
function providerItem($this, item, type, display, replay, native) {
  return new ProviderItem(VOID, native, Companion_getInstance_0().r6c_1, type, display, replay, Companion_getInstance_2().d40(item.toString()));
}
function extractOutputText($this, item) {
  var tmp = item.l2g('content');
  var tmp0_elvis_lhs = tmp instanceof JsonArray ? tmp : null;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.text.orEmpty' call
    var tmp0_elvis_lhs_0 = str(item, 'text');
    return tmp0_elvis_lhs_0 == null ? '' : tmp0_elvis_lhs_0;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var content = tmp_0;
  // Inline function 'kotlin.collections.mapNotNull' call
  // Inline function 'kotlin.collections.mapNotNullTo' call
  var destination = ArrayList.k();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = content.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp$ret$1;
    $l$block: {
      var tmp0_elvis_lhs_1 = element instanceof JsonObject ? element : null;
      var tmp_1;
      if (tmp0_elvis_lhs_1 == null) {
        tmp$ret$1 = null;
        break $l$block;
      } else {
        tmp_1 = tmp0_elvis_lhs_1;
      }
      var part = tmp_1;
      var tmp1_subject = str(part, 'type');
      tmp$ret$1 = tmp1_subject === 'output_text' || (tmp1_subject === 'input_text' || tmp1_subject === 'text') ? str(part, 'text') : null;
    }
    var tmp0_safe_receiver = tmp$ret$1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      destination.l(tmp0_safe_receiver);
    }
  }
  return joinToString(destination, '');
}
function extractAnnotations($this, item) {
  var tmp = item.l2g('content');
  var tmp0_elvis_lhs = tmp instanceof JsonArray ? tmp : null;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return emptyList();
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var content = tmp_0;
  // Inline function 'kotlin.collections.flatMap' call
  // Inline function 'kotlin.collections.flatMapTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = content.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp$ret$0;
    $l$block_0: {
      var tmp0_elvis_lhs_0 = element instanceof JsonObject ? element : null;
      var tmp_1;
      if (tmp0_elvis_lhs_0 == null) {
        tmp$ret$0 = emptyList();
        break $l$block_0;
      } else {
        tmp_1 = tmp0_elvis_lhs_0;
      }
      var part = tmp_1;
      var tmp_2 = part.l2g('annotations');
      var tmp1_elvis_lhs = tmp_2 instanceof JsonArray ? tmp_2 : null;
      var tmp_3;
      if (tmp1_elvis_lhs == null) {
        tmp$ret$0 = emptyList();
        break $l$block_0;
      } else {
        tmp_3 = tmp1_elvis_lhs;
      }
      var anns = tmp_3;
      // Inline function 'kotlin.collections.mapNotNull' call
      // Inline function 'kotlin.collections.mapNotNullTo' call
      var destination_0 = ArrayList.k();
      // Inline function 'kotlin.collections.forEach' call
      var _iterator__ex2g4s_0 = anns.y();
      while (_iterator__ex2g4s_0.z()) {
        var element_0 = _iterator__ex2g4s_0.a1();
        var tmp0_safe_receiver = element_0 instanceof JsonObject ? element_0 : null;
        var tmp_4;
        if (tmp0_safe_receiver == null) {
          tmp_4 = null;
        } else {
          // Inline function 'kotlin.let' call
          tmp_4 = mapAnnotation($this, tmp0_safe_receiver);
        }
        var tmp0_safe_receiver_0 = tmp_4;
        if (tmp0_safe_receiver_0 == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          destination_0.l(tmp0_safe_receiver_0);
        }
      }
      tmp$ret$0 = destination_0;
    }
    var list = tmp$ret$0;
    addAll(destination, list);
  }
  return destination;
}
function extractRefusal($this, item) {
  var tmp = item.l2g('content');
  var tmp0_elvis_lhs = tmp instanceof JsonArray ? tmp : null;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return str(item, 'refusal');
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var content = tmp_0;
  // Inline function 'kotlin.collections.mapNotNull' call
  // Inline function 'kotlin.collections.mapNotNullTo' call
  var destination = ArrayList.k();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = content.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp$ret$0;
    $l$block: {
      var tmp0_elvis_lhs_0 = element instanceof JsonObject ? element : null;
      var tmp_1;
      if (tmp0_elvis_lhs_0 == null) {
        tmp$ret$0 = null;
        break $l$block;
      } else {
        tmp_1 = tmp0_elvis_lhs_0;
      }
      var part = tmp_1;
      // Inline function 'kotlin.takeIf' call
      var tmp_2;
      if (str(part, 'type') === 'refusal') {
        tmp_2 = part;
      } else {
        tmp_2 = null;
      }
      var tmp1_safe_receiver = tmp_2;
      tmp$ret$0 = tmp1_safe_receiver == null ? null : str(tmp1_safe_receiver, 'refusal');
    }
    var tmp0_safe_receiver = tmp$ret$0;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      destination.l(tmp0_safe_receiver);
    }
  }
  // Inline function 'kotlin.text.ifBlank' call
  var this_0 = joinToString(destination, '');
  var tmp_3;
  if (isBlank(this_0)) {
    tmp_3 = null;
  } else {
    tmp_3 = this_0;
  }
  return tmp_3;
}
function extractReasoningSummary($this, item) {
  var tmp = item.l2g('summary');
  var tmp0_elvis_lhs = tmp instanceof JsonArray ? tmp : null;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.text.orEmpty' call
    var tmp0_elvis_lhs_0 = str(item, 'content');
    return tmp0_elvis_lhs_0 == null ? '' : tmp0_elvis_lhs_0;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var summary = tmp_0;
  // Inline function 'kotlin.collections.mapNotNull' call
  // Inline function 'kotlin.collections.mapNotNullTo' call
  var destination = ArrayList.k();
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = summary.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp$ret$1;
    $l$block: {
      var tmp0_elvis_lhs_1 = element instanceof JsonObject ? element : null;
      var tmp_1;
      if (tmp0_elvis_lhs_1 == null) {
        tmp$ret$1 = null;
        break $l$block;
      } else {
        tmp_1 = tmp0_elvis_lhs_1;
      }
      var part = tmp_1;
      tmp$ret$1 = str(part, 'text');
    }
    var tmp0_safe_receiver = tmp$ret$1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      destination.l(tmp0_safe_receiver);
    }
  }
  return joinToString(destination, '');
}
function mapAnnotation($this, obj) {
  var tmp;
  switch (str(obj, 'type')) {
    case 'url_citation':
      // Inline function 'kotlin.text.orEmpty' call

      var tmp0_elvis_lhs = str(obj, 'url');
      var tmp$ret$0 = tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs;
      tmp = new UrlCitation(tmp$ret$0, str(obj, 'title'), int(obj, 'start_index'), int(obj, 'end_index'));
      break;
    case 'file_citation':
      // Inline function 'kotlin.text.orEmpty' call

      var tmp0_elvis_lhs_0 = str(obj, 'file_id');
      var tmp$ret$1 = tmp0_elvis_lhs_0 == null ? '' : tmp0_elvis_lhs_0;
      tmp = new FileCitation(tmp$ret$1, str(obj, 'filename'), int(obj, 'start_index'), int(obj, 'end_index'));
      break;
    default:
      var tmp1_elvis_lhs = str(obj, 'type');
      tmp = new Generic(tmp1_elvis_lhs == null ? 'unknown' : tmp1_elvis_lhs, obj.toString());
      break;
  }
  return tmp;
}
function mapUsage($this, obj_0) {
  var tmp0_elvis_lhs = int(obj_0, 'input_tokens');
  var input = tmp0_elvis_lhs == null ? 0 : tmp0_elvis_lhs;
  var tmp1_elvis_lhs = int(obj_0, 'output_tokens');
  var outputTok = tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  var tmp2_elvis_lhs = int(obj_0, 'total_tokens');
  var total = tmp2_elvis_lhs == null ? input + outputTok | 0 : tmp2_elvis_lhs;
  var tmp3_safe_receiver = obj(obj_0, 'input_tokens_details');
  var tmp4_elvis_lhs = tmp3_safe_receiver == null ? null : int(tmp3_safe_receiver, 'cached_tokens');
  var cached = tmp4_elvis_lhs == null ? 0 : tmp4_elvis_lhs;
  var tmp5_safe_receiver = obj(obj_0, 'output_tokens_details');
  var tmp6_elvis_lhs = tmp5_safe_receiver == null ? null : int(tmp5_safe_receiver, 'reasoning_tokens');
  var reasoning = tmp6_elvis_lhs == null ? 0 : tmp6_elvis_lhs;
  return new Usage(input, outputTok, total, cached, reasoning);
}
function mapIncomplete($this, obj_0) {
  var tmp0_safe_receiver = obj(obj_0, 'incomplete_details');
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : str(tmp0_safe_receiver, 'reason');
  var tmp2_elvis_lhs = tmp1_elvis_lhs == null ? str(obj_0, 'reason') : tmp1_elvis_lhs;
  var reason = tmp2_elvis_lhs == null ? 'unknown' : tmp2_elvis_lhs;
  switch (reason) {
    case 'max_output_tokens':
      return MaxOutputTokens_instance;
    case 'content_filter':
      return ContentFilter_instance;
    case 'cancelled':
      return Cancelled_instance;
    default:
      return new Other(reason);
  }
}
function readResponseId($this, obj_0) {
  var tmp = $this;
  var tmp0_elvis_lhs = str(obj_0, 'id');
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    var tmp1_safe_receiver = obj(obj_0, 'response');
    tmp_0 = tmp1_safe_receiver == null ? null : str(tmp1_safe_receiver, 'id');
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var tmp2_elvis_lhs = tmp_0;
  tmp.p7g_1 = tmp2_elvis_lhs == null ? $this.p7g_1 : tmp2_elvis_lhs;
}
function currentCheckpoint($this) {
  var tmp0_safe_receiver = $this.p7g_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = $this.i7g_1.r7f(tmp0_safe_receiver, $this.f7g_1, Companion_instance_1.b6b(plus($this.h7g_1, $this.l7g_1)), $this.g7g_1 ? CheckpointScope_CrossTurn_getInstance() : CheckpointScope_InRun_getInstance());
  }
  return tmp;
}
function decodeHttpError($this, frame) {
  // Inline function 'kotlin.runCatching' call
  var tmp;
  try {
    // Inline function 'kotlin.Companion.success' call
    var value = get_jsonObject(JsonUtil_getInstance().c6f_1.q3m(frame.k6l_1));
    tmp = _Result___init__impl__xyqfz8(value);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var e = $p;
      // Inline function 'kotlin.Companion.failure' call
      tmp_0 = _Result___init__impl__xyqfz8(createFailure(e));
    } else {
      throw $p;
    }
    tmp = tmp_0;
  }
  // Inline function 'kotlin.Result.getOrNull' call
  var this_0 = tmp;
  var tmp_1;
  if (_Result___get_isFailure__impl__jpiriv(this_0)) {
    tmp_1 = null;
  } else {
    var tmp_2 = _Result___get_value__impl__bjfvqg(this_0);
    tmp_1 = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
  }
  var parsed = tmp_1;
  var tmp1_elvis_lhs = parsed == null ? null : obj(parsed, 'error');
  var err = tmp1_elvis_lhs == null ? parsed : tmp1_elvis_lhs;
  var tmp3_elvis_lhs = err == null ? null : str(err, 'message');
  return new ModelError(tmp3_elvis_lhs == null ? 'HTTP ' + frame.i6l_1 + ': ' + frame.k6l_1 : tmp3_elvis_lhs, frame.i6l_1 === 429 || frame.i6l_1 >= 500);
}
function decodeModelError($this, obj_0) {
  var tmp0_elvis_lhs = obj(obj_0, 'error');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var tmp1_safe_receiver = obj(obj_0, 'response');
    tmp = tmp1_safe_receiver == null ? null : obj(tmp1_safe_receiver, 'error');
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var tmp2_elvis_lhs = tmp;
  var err = tmp2_elvis_lhs == null ? obj_0 : tmp2_elvis_lhs;
  var tmp3_elvis_lhs = str(err, 'message');
  return new ModelError(tmp3_elvis_lhs == null ? 'openai responses error ' + str(err, 'code') : tmp3_elvis_lhs, false);
}
function displayFor($this, item, type) {
  var tmp0_elvis_lhs = str(item, 'name');
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.text.ifBlank' call
    var this_0 = extractOutputText($this, item);
    var tmp_0;
    if (isBlank(this_0)) {
      tmp_0 = '[' + type + ']';
    } else {
      tmp_0 = this_0;
    }
    tmp = tmp_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function toCall($this, _this__u8e3s4) {
  var tmp = _ItemRef___get_value__impl__fpjuyb(_this__u8e3s4.y7f_1);
  var tmp_0 = _this__u8e3s4.w7f_1.toString();
  // Inline function 'kotlin.text.ifBlank' call
  var this_0 = _this__u8e3s4.x7f_1.toString();
  var tmp_1;
  if (isBlank(this_0)) {
    tmp_1 = '{}';
  } else {
    tmp_1 = this_0;
  }
  var tmp_2 = tmp_1;
  var tmp0_safe_receiver = _this__u8e3s4.u7f_1;
  var tmp_3;
  if (tmp0_safe_receiver == null) {
    tmp_3 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_3 = new ProviderScopedId(Companion_getInstance_0().r6c_1, tmp0_safe_receiver);
  }
  var tmp1_elvis_lhs = tmp_3;
  var tmp_4;
  if (tmp1_elvis_lhs == null) {
    var tmp2_safe_receiver = _this__u8e3s4.v7f_1;
    var tmp_5;
    if (tmp2_safe_receiver == null) {
      tmp_5 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_5 = new ProviderScopedId(Companion_getInstance_0().r6c_1, tmp2_safe_receiver);
    }
    tmp_4 = tmp_5;
  } else {
    tmp_4 = tmp1_elvis_lhs;
  }
  var tmp_6 = tmp_4;
  var tmp3_safe_receiver = _this__u8e3s4.v7f_1;
  var tmp_7;
  if (tmp3_safe_receiver == null) {
    tmp_7 = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp_7 = new ProviderScopedId(Companion_getInstance_0().r6c_1, tmp3_safe_receiver);
  }
  return new ToolCall_0(tmp, tmp_0, tmp_2, tmp_6, tmp_7);
}
function toItem($this, _this__u8e3s4) {
  return toCall($this, _this__u8e3s4).o60();
}
function toItem_0($this, _this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.z7f_1;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    tmp = new ProviderScopedId(Companion_getInstance_0().r6c_1, tmp0_safe_receiver);
  }
  var tmp_0 = tmp;
  var tmp_1 = _this__u8e3s4.a7g_1;
  var tmp_2;
  // Inline function 'kotlin.text.isEmpty' call
  var this_0 = _this__u8e3s4.b7g_1;
  if (charSequenceLength(this_0) === 0) {
    tmp_2 = emptyList();
  } else {
    tmp_2 = listOf(new Text(_this__u8e3s4.b7g_1.toString()));
  }
  var tmp_3 = tmp_2;
  // Inline function 'kotlin.text.ifBlank' call
  var this_1 = _this__u8e3s4.c7g_1.toString();
  var tmp_4;
  if (isBlank(this_1)) {
    tmp_4 = null;
  } else {
    tmp_4 = this_1;
  }
  var tmp$ret$4 = tmp_4;
  return new Message(_this__u8e3s4.e7g_1, tmp_0, tmp_1, tmp_3, tmp$ret$4, toList(_this__u8e3s4.d7g_1));
}
function ResponsesDecoder$finish$lambda(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = a.m1();
  var tmp$ret$1 = b.m1();
  return compareValues(tmp, tmp$ret$1);
}
function ResponsesDecoder$finish$lambda_0(a, b) {
  // Inline function 'kotlin.comparisons.compareValuesBy' call
  var tmp = a.m1();
  var tmp$ret$1 = b.m1();
  return compareValues(tmp, tmp$ret$1);
}
function str(_this__u8e3s4, key) {
  var tmp0_safe_receiver = _this__u8e3s4.l2g(key);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_safe_receiver_0 = tmp0_safe_receiver instanceof JsonPrimitive ? tmp0_safe_receiver : null;
    tmp = tmp0_safe_receiver_0 == null ? null : get_contentOrNull(tmp0_safe_receiver_0);
  }
  return tmp;
}
function int(_this__u8e3s4, key) {
  var tmp0_safe_receiver = _this__u8e3s4.l2g(key);
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_safe_receiver_0 = tmp0_safe_receiver instanceof JsonPrimitive ? tmp0_safe_receiver : null;
    tmp = tmp0_safe_receiver_0 == null ? null : get_intOrNull(tmp0_safe_receiver_0);
  }
  return tmp;
}
function obj(_this__u8e3s4, key) {
  var tmp = _this__u8e3s4.l2g(key);
  return tmp instanceof JsonObject ? tmp : null;
}
function role(_this__u8e3s4) {
  switch (str(_this__u8e3s4, 'role')) {
    case 'user':
      return Role_USER_getInstance();
    case 'system':
    case 'developer':
      return Role_SYSTEM_getInstance();
    default:
      return Role_ASSISTANT_getInstance();
  }
}
function get_DEFAULT_RESPONSES_CAPABILITIES() {
  _init_properties_ResponsesModel_kt__n4lql3();
  return DEFAULT_RESPONSES_CAPABILITIES;
}
var DEFAULT_RESPONSES_CAPABILITIES;
function get_DEFAULT_CAPABILITIES() {
  _init_properties_ResponsesModel_kt__n4lql3();
  return DEFAULT_CAPABILITIES;
}
var DEFAULT_CAPABILITIES;
function *_generator_invoke__zhh2q8($this, $this$withTimeoutOrNull, $completion) {
  var call = $this.t7h_1.j6g($this.u7h_1);
  while (true) {
    var tmp = firstOrNull($this.t7h_1.d6g_1.k6g(call), $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    var tmp0_elvis_lhs = tmp;
    var tmp_0;
    if (tmp0_elvis_lhs == null) {
      throw TransportException.x6l('background response returned no frame');
    } else {
      tmp_0 = tmp0_elvis_lhs;
    }
    var frame = tmp_0;
    var tmp_1 = $this.v7h_1.p1c(frame, $completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
    if (frame instanceof HttpError)
      return Unit_instance;
    var tmp1_elvis_lhs = frame instanceof Body ? frame : null;
    var tmp_2;
    if (tmp1_elvis_lhs == null) {
      throw TransportException.x6l('background response expected a JSON body');
    } else {
      tmp_2 = tmp1_elvis_lhs;
    }
    var body = tmp_2;
    // Inline function 'kotlin.runCatching' call
    var tmp_3;
    try {
      // Inline function 'kotlin.Companion.success' call
      var value = get_jsonObject(JsonUtil_getInstance().c6f_1.q3m(body.h6m_1));
      tmp_3 = _Result___init__impl__xyqfz8(value);
    } catch ($p) {
      var tmp_4;
      if ($p instanceof Error) {
        var e = $p;
        // Inline function 'kotlin.Companion.failure' call
        tmp_4 = _Result___init__impl__xyqfz8(createFailure(e));
      } else {
        throw $p;
      }
      tmp_3 = tmp_4;
    }
    // Inline function 'kotlin.getOrElse' call
    var this_0 = tmp_3;
    var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
    var tmp_5;
    if (exception == null) {
      var tmp_6 = _Result___get_value__impl__bjfvqg(this_0);
      tmp_5 = (tmp_6 == null ? true : !(tmp_6 == null)) ? tmp_6 : THROW_CCE();
    } else {
      throw TransportException.x6l('invalid background response JSON', VOID, exception);
    }
    var response = tmp_5;
    var tmp2_safe_receiver = response.l2g('id');
    var tmp3_safe_receiver = tmp2_safe_receiver == null ? null : get_jsonPrimitive(tmp2_safe_receiver);
    var tmp4_elvis_lhs = tmp3_safe_receiver == null ? null : tmp3_safe_receiver.y3o();
    var tmp_7;
    if (tmp4_elvis_lhs == null) {
      throw TransportException.x6l('background response is missing id');
    } else {
      tmp_7 = tmp4_elvis_lhs;
    }
    var id = tmp_7;
    var tmp5_safe_receiver = response.l2g('status');
    var tmp6_safe_receiver = tmp5_safe_receiver == null ? null : get_jsonPrimitive(tmp5_safe_receiver);
    var status = tmp6_safe_receiver == null ? null : tmp6_safe_receiver.y3o();
    switch (status) {
      case 'queued':
      case 'in_progress':
        Companion_getInstance();
        // Inline function 'kotlin.time.Companion.milliseconds' call

        var this_1 = $this.t7h_1.y7h_1.h7i_1;
        var tmp$ret$5 = toDuration(this_1, DurationUnit_MILLISECONDS_getInstance());
        var tmp_8 = delay(tmp$ret$5, $completion);
        if (tmp_8 === get_COROUTINE_SUSPENDED())
          tmp_8 = yield tmp_8;
        call = retrieveCall($this.t7h_1, id);
        break;
      case 'completed':
      case 'incomplete':
      case 'failed':
      case 'cancelled':
        return Unit_instance;
      default:
        throw TransportException.x6l('unknown background response status: ' + status);
    }
  }
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_0($this, $this$flow, $completion) {
  Companion_getInstance();
  // Inline function 'kotlin.time.Companion.milliseconds' call
  var this_0 = $this.m7i_1.c6g_1.t6g_1;
  var tmp = toDuration(this_0, DurationUnit_MILLISECONDS_getInstance());
  var tmp_0 = withTimeoutOrNull(tmp, OpenAIResponsesModel$wireFrames$slambda$slambda_0($this.m7i_1, $this.n7i_1, $this$flow), $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  var completed = tmp_0;
  if (completed == null) {
    throw TransportException.x6l('background response did not finish within ' + $this.m7i_1.c6g_1.t6g_1.toString() + 'ms');
  }
  return Unit_instance;
}
function OpenAIResponsesModel$wireFrames$slambda$slambda_0(this$0, $request, $this_flow) {
  var i = new OpenAIResponsesModel$wireFrames$slambda$slambda(this$0, $request, $this_flow);
  var l = ($this$withTimeoutOrNull, $completion) => i.w1f($this$withTimeoutOrNull, $completion);
  l.$arity = 1;
  return l;
}
function retrieveCall($this, responseId) {
  return new WireCall(HttpMethod_GET_getInstance(), trimEnd($this.c6g_1.n6g_1, charArrayOf([_Char___init__impl__6a9atx(47)])) + '/' + responseId, authHeaders($this.c6g_1), VOID, Framing_Json_getInstance(), VOID, timeouts($this.c6g_1), $this.c6g_1.w6g_1, $this.c6g_1.x6g_1);
}
function *_generator_abandon__qxshi9($this, responseId, $completion) {
  var url = trimEnd($this.c6g_1.n6g_1, charArrayOf([_Char___init__impl__6a9atx(47)])) + '/' + responseId + '/cancel';
  // Inline function 'kotlin.runCatching' call
  var tmp;
  try {
    var tmp_0 = firstOrNull($this.d6g_1.k6g(new WireCall(HttpMethod_POST_getInstance(), url, authHeaders($this.c6g_1), '{}', Framing_Json_getInstance(), VOID, timeouts($this.c6g_1), new RetryBudget(0))), $completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    // Inline function 'kotlin.Companion.success' call
    var value = tmp_0;
    tmp = _Result___init__impl__xyqfz8(value);
  } catch ($p) {
    var tmp_1;
    if ($p instanceof Error) {
      var e = $p;
      // Inline function 'kotlin.Companion.failure' call
      tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
    } else {
      throw $p;
    }
    tmp = tmp_1;
  }
  return Unit_instance;
}
function encodeTools($this, req) {
  // Inline function 'kotlin.collections.map' call
  var this_0 = req.d5y_1;
  // Inline function 'kotlin.collections.mapTo' call
  var destination = ArrayList.x(collectionSizeOrDefault(this_0, 10));
  var _iterator__ex2g4s = this_0.y();
  while (_iterator__ex2g4s.z()) {
    var item = _iterator__ex2g4s.a1();
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.g3p('type', JsonPrimitive_0('function'));
    builder.g3p('name', JsonPrimitive_0(item.c6k_1));
    builder.g3p('description', JsonPrimitive_0(item.d6k_1));
    builder.g3p('parameters', item.e6k_1);
    var tmp$ret$2 = builder.x3n();
    destination.l(tmp$ret$2);
  }
  var local = destination;
  var all = plus(local, $this.y7h_1.l7i_1);
  // Inline function 'kotlin.takeIf' call
  var tmp;
  // Inline function 'kotlin.collections.isNotEmpty' call
  if (!all.h1()) {
    tmp = all;
  } else {
    tmp = null;
  }
  return tmp;
}
function OpenAIResponsesModel$wireFrames$slambda_0(this$0, $request) {
  var i = new OpenAIResponsesModel$wireFrames$slambda(this$0, $request);
  var l = ($this$flow, $completion) => i.s6l($this$flow, $completion);
  l.$arity = 1;
  return l;
}
function normalizeResponsesUrl(baseUrl) {
  _init_properties_ResponsesModel_kt__n4lql3();
  // Inline function 'kotlin.text.trim' call
  var tmp$ret$0 = toString_0(trim(isCharSequence(baseUrl) ? baseUrl : THROW_CCE()));
  var trimmed = trimEnd(tmp$ret$0, charArrayOf([_Char___init__impl__6a9atx(47)]));
  return endsWith(trimmed, '/responses') ? trimmed : endsWith(trimmed, '/v1') ? trimmed + '/responses' : trimmed + '/v1/responses';
}
function toInput(items) {
  _init_properties_ResponsesModel_kt__n4lql3();
  if (items.h1()) {
    // Inline function 'kotlinx.serialization.json.buildJsonArray' call
    var builder = new JsonArrayBuilder();
    return builder.x3n();
  }
  // Inline function 'kotlin.collections.filterIsInstance' call
  // Inline function 'kotlin.collections.filterIsInstanceTo' call
  var destination = ArrayList.k();
  var _iterator__ex2g4s = items.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    if (element instanceof ToolCall) {
      destination.l(element);
    }
  }
  // Inline function 'kotlin.collections.associateBy' call
  var capacity = coerceAtLeast(mapCapacity(collectionSizeOrDefault(destination, 10)), 16);
  // Inline function 'kotlin.collections.associateByTo' call
  var destination_0 = LinkedHashMap.ic(capacity);
  var _iterator__ex2g4s_0 = destination.y();
  while (_iterator__ex2g4s_0.z()) {
    var element_0 = _iterator__ex2g4s_0.a1();
    var tmp$ret$4 = new ItemRef(element_0.x68_1);
    destination_0.k3(tmp$ret$4, element_0);
  }
  var calls = destination_0;
  // Inline function 'kotlinx.serialization.json.buildJsonArray' call
  var builder_0 = new JsonArrayBuilder();
  var _iterator__ex2g4s_1 = items.y();
  while (_iterator__ex2g4s_1.z()) {
    var item = _iterator__ex2g4s_1.a1();
    builder_0.e3p(toInputElement(item, calls));
  }
  return builder_0.x3n();
}
function toTextFormat(_this__u8e3s4) {
  _init_properties_ResponsesModel_kt__n4lql3();
  var tmp;
  if (equals(_this__u8e3s4, Text_instance)) {
    tmp = null;
  } else {
    if (equals(_this__u8e3s4, JsonObject_instance)) {
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder = new JsonObjectBuilder();
      builder.g3p('type', JsonPrimitive_0('json_object'));
      var tmp$ret$1 = builder.x3n();
      tmp = new ResponsesText(tmp$ret$1);
    } else {
      if (_this__u8e3s4 instanceof JsonSchema) {
        // Inline function 'kotlinx.serialization.json.buildJsonObject' call
        var builder_0 = new JsonObjectBuilder();
        builder_0.g3p('type', JsonPrimitive_0('json_schema'));
        builder_0.g3p('name', JsonPrimitive_0(_this__u8e3s4.d6e_1));
        builder_0.g3p('schema', _this__u8e3s4.e6e_1);
        builder_0.g3p('strict', JsonPrimitive_1(_this__u8e3s4.f6e_1));
        var tmp$ret$3 = builder_0.x3n();
        tmp = new ResponsesText(tmp$ret$3);
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return tmp;
}
function toInputElement(_this__u8e3s4, calls) {
  _init_properties_ResponsesModel_kt__n4lql3();
  var tmp;
  if (_this__u8e3s4 instanceof Message) {
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.g3p('type', JsonPrimitive_0('message'));
    builder.g3p('role', JsonPrimitive_0(wireName(_this__u8e3s4.r5o_1)));
    // Inline function 'kotlinx.serialization.json.buildJsonArray' call
    var builder_0 = new JsonArrayBuilder();
    // Inline function 'kotlin.collections.filterIsInstance' call
    var tmp0 = _this__u8e3s4.s5o_1;
    // Inline function 'kotlin.collections.filterIsInstanceTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element instanceof Text) {
        destination.l(element);
      }
    }
    // Inline function 'kotlin.collections.map' call
    // Inline function 'kotlin.collections.mapTo' call
    var destination_0 = ArrayList.x(collectionSizeOrDefault(destination, 10));
    var _iterator__ex2g4s_0 = destination.y();
    while (_iterator__ex2g4s_0.z()) {
      var item = _iterator__ex2g4s_0.a1();
      var tmp$ret$2 = item.p6b_1;
      destination_0.l(tmp$ret$2);
    }
    // Inline function 'kotlin.collections.ifEmpty' call
    var tmp_0;
    if (destination_0.h1()) {
      // Inline function 'kotlin.takeIf' call
      var this_0 = _this__u8e3s4.m5t();
      var tmp_1;
      // Inline function 'kotlin.text.isNotEmpty' call
      if (charSequenceLength(this_0) > 0) {
        tmp_1 = this_0;
      } else {
        tmp_1 = null;
      }
      var tmp0_safe_receiver = tmp_1;
      var tmp_2;
      if (tmp0_safe_receiver == null) {
        tmp_2 = null;
      } else {
        // Inline function 'kotlin.let' call
        tmp_2 = listOf(tmp0_safe_receiver);
      }
      // Inline function 'kotlin.collections.orEmpty' call
      var tmp0_elvis_lhs = tmp_2;
      tmp_0 = tmp0_elvis_lhs == null ? emptyList() : tmp0_elvis_lhs;
    } else {
      tmp_0 = destination_0;
    }
    var texts = tmp_0;
    // Inline function 'kotlin.collections.forEachIndexed' call
    var index = 0;
    var _iterator__ex2g4s_1 = texts.y();
    while (_iterator__ex2g4s_1.z()) {
      var item_0 = _iterator__ex2g4s_1.a1();
      var _unary__edvuaz = index;
      index = _unary__edvuaz + 1 | 0;
      var index_0 = checkIndexOverflow(_unary__edvuaz);
      builder_0.e3p(textPart(_this__u8e3s4.r5o_1, item_0, index_0 === 0 ? _this__u8e3s4.u5o_1 : emptyList()));
    }
    var tmp0_safe_receiver_0 = _this__u8e3s4.t5o_1;
    if (tmp0_safe_receiver_0 == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder_1 = new JsonObjectBuilder();
      builder_1.g3p('type', JsonPrimitive_0('refusal'));
      builder_1.g3p('refusal', JsonPrimitive_0(tmp0_safe_receiver_0));
      var tmp$ret$16 = builder_1.x3n();
      builder_0.e3p(tmp$ret$16);
    }
    var tmp$ret$20 = builder_0.x3n();
    builder.g3p('content', tmp$ret$20);
    tmp = builder.x3n();
  } else {
    if (_this__u8e3s4 instanceof ToolCall) {
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder_2 = new JsonObjectBuilder();
      var callId = wireCallId(_this__u8e3s4);
      builder_2.g3p('type', JsonPrimitive_0('function_call'));
      builder_2.g3p('name', JsonPrimitive_0(_this__u8e3s4.z68_1));
      builder_2.g3p('arguments', JsonPrimitive_0(_this__u8e3s4.a69_1));
      builder_2.g3p('call_id', JsonPrimitive_0(callId));
      var tmp0_safe_receiver_1 = rawFor(_this__u8e3s4.b69_1, Companion_getInstance_0().r6c_1);
      if (tmp0_safe_receiver_1 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder_2.g3p('id', JsonPrimitive_0(tmp0_safe_receiver_1));
      }
      tmp = builder_2.x3n();
    } else {
      if (_this__u8e3s4 instanceof ToolResult) {
        // Inline function 'kotlinx.serialization.json.buildJsonObject' call
        var builder_3 = new JsonObjectBuilder();
        var call = calls.h3(new ItemRef(_this__u8e3s4.u68_1));
        var tmp1_elvis_lhs = call == null ? null : wireCallId(call);
        var callId_0 = tmp1_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(_this__u8e3s4.u68_1) : tmp1_elvis_lhs;
        builder_3.g3p('type', JsonPrimitive_0('function_call_output'));
        builder_3.g3p('call_id', JsonPrimitive_0(callId_0));
        builder_3.g3p('output', JsonPrimitive_0(_this__u8e3s4.v68_1));
        var tmp2_safe_receiver = rawFor(_this__u8e3s4.t68_1, Companion_getInstance_0().r6c_1);
        if (tmp2_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          builder_3.g3p('id', JsonPrimitive_0(tmp2_safe_receiver));
        }
        tmp = builder_3.x3n();
      } else {
        if (_this__u8e3s4 instanceof ReasoningSummary) {
          // Inline function 'kotlinx.serialization.json.buildJsonObject' call
          var builder_4 = new JsonObjectBuilder();
          builder_4.g3p('type', JsonPrimitive_0('reasoning'));
          // Inline function 'kotlinx.serialization.json.buildJsonArray' call
          var builder_5 = new JsonArrayBuilder();
          // Inline function 'kotlinx.serialization.json.buildJsonObject' call
          var builder_6 = new JsonObjectBuilder();
          builder_6.g3p('type', JsonPrimitive_0('summary_text'));
          builder_6.g3p('text', JsonPrimitive_0(_this__u8e3s4.h6b_1));
          var tmp$ret$32 = builder_6.x3n();
          builder_5.e3p(tmp$ret$32);
          var tmp$ret$34 = builder_5.x3n();
          builder_4.g3p('summary', tmp$ret$34);
          tmp = builder_4.x3n();
        } else {
          if (_this__u8e3s4 instanceof ProviderItem) {
            var tmp_3;
            if (_this__u8e3s4.v5y_1 === Companion_getInstance_0().r6c_1) {
              // Inline function 'kotlin.runCatching' call
              var tmp_4;
              try {
                // Inline function 'kotlin.Companion.success' call
                var value = get_jsonObject(JsonUtil_getInstance().c6f_1.q3m(_this__u8e3s4.z5y_1.s42()));
                tmp_4 = _Result___init__impl__xyqfz8(value);
              } catch ($p) {
                var tmp_5;
                if ($p instanceof Error) {
                  var e = $p;
                  // Inline function 'kotlin.Companion.failure' call
                  tmp_5 = _Result___init__impl__xyqfz8(createFailure(e));
                } else {
                  throw $p;
                }
                tmp_4 = tmp_5;
              }
              // Inline function 'kotlin.getOrElse' call
              var this_1 = tmp_4;
              var exception = Result__exceptionOrNull_impl_p6xea9(this_1);
              var tmp_6;
              if (exception == null) {
                var tmp_7 = _Result___get_value__impl__bjfvqg(this_1);
                tmp_6 = (tmp_7 == null ? true : !(tmp_7 == null)) ? tmp_7 : THROW_CCE();
              } else {
                tmp_6 = fallbackProviderItem(_this__u8e3s4);
              }
              tmp_3 = tmp_6;
            } else {
              tmp_3 = fallbackProviderItem(_this__u8e3s4);
            }
            tmp = tmp_3;
          } else {
            noWhenBranchMatchedException();
          }
        }
      }
    }
  }
  return tmp;
}
function wireName(_this__u8e3s4) {
  _init_properties_ResponsesModel_kt__n4lql3();
  var tmp;
  switch (_this__u8e3s4.o3_1) {
    case 0:
      tmp = 'system';
      break;
    case 1:
      tmp = 'user';
      break;
    case 2:
      tmp = 'assistant';
      break;
    case 3:
      tmp = 'user';
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function textPart(role, text, annotations) {
  _init_properties_ResponsesModel_kt__n4lql3();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.g3p('type', JsonPrimitive_0(role.equals(Role_ASSISTANT_getInstance()) ? 'output_text' : 'input_text'));
  builder.g3p('text', JsonPrimitive_0(text));
  var tmp;
  if (role.equals(Role_ASSISTANT_getInstance())) {
    // Inline function 'kotlin.collections.isNotEmpty' call
    tmp = !annotations.h1();
  } else {
    tmp = false;
  }
  if (tmp) {
    // Inline function 'kotlinx.serialization.json.buildJsonArray' call
    var builder_0 = new JsonArrayBuilder();
    // Inline function 'kotlin.collections.forEach' call
    var _iterator__ex2g4s = annotations.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      builder_0.e3p(toJson(element));
    }
    var tmp$ret$4 = builder_0.x3n();
    builder.g3p('annotations', tmp$ret$4);
  }
  return builder.x3n();
}
function wireCallId(_this__u8e3s4) {
  _init_properties_ResponsesModel_kt__n4lql3();
  var tmp0_elvis_lhs = rawFor(_this__u8e3s4.y68_1, Companion_getInstance_0().r6c_1);
  return tmp0_elvis_lhs == null ? _ItemRef___get_value__impl__fpjuyb(_this__u8e3s4.x68_1) : tmp0_elvis_lhs;
}
function fallbackProviderItem(_this__u8e3s4) {
  _init_properties_ResponsesModel_kt__n4lql3();
  // Inline function 'kotlinx.serialization.json.buildJsonObject' call
  var builder = new JsonObjectBuilder();
  builder.g3p('type', JsonPrimitive_0(_this__u8e3s4.w5y_1));
  builder.g3p('content', JsonPrimitive_0(_this__u8e3s4.x5y_1));
  return builder.x3n();
}
function toJson(_this__u8e3s4) {
  _init_properties_ResponsesModel_kt__n4lql3();
  var tmp;
  if (_this__u8e3s4 instanceof UrlCitation) {
    // Inline function 'kotlinx.serialization.json.buildJsonObject' call
    var builder = new JsonObjectBuilder();
    builder.g3p('type', JsonPrimitive_0('url_citation'));
    builder.g3p('url', JsonPrimitive_0(_this__u8e3s4.k6a_1));
    var tmp0_safe_receiver = _this__u8e3s4.l6a_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.g3p('title', JsonPrimitive_0(tmp0_safe_receiver));
    }
    var tmp1_safe_receiver = _this__u8e3s4.m6a_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.g3p('start_index', JsonPrimitive_2(tmp1_safe_receiver));
    }
    var tmp2_safe_receiver = _this__u8e3s4.n6a_1;
    if (tmp2_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      builder.g3p('end_index', JsonPrimitive_2(tmp2_safe_receiver));
    }
    tmp = builder.x3n();
  } else {
    if (_this__u8e3s4 instanceof FileCitation) {
      // Inline function 'kotlinx.serialization.json.buildJsonObject' call
      var builder_0 = new JsonObjectBuilder();
      builder_0.g3p('type', JsonPrimitive_0('file_citation'));
      builder_0.g3p('file_id', JsonPrimitive_0(_this__u8e3s4.o6a_1));
      var tmp0_safe_receiver_0 = _this__u8e3s4.p6a_1;
      if (tmp0_safe_receiver_0 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder_0.g3p('filename', JsonPrimitive_0(tmp0_safe_receiver_0));
      }
      var tmp1_safe_receiver_0 = _this__u8e3s4.q6a_1;
      if (tmp1_safe_receiver_0 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder_0.g3p('start_index', JsonPrimitive_2(tmp1_safe_receiver_0));
      }
      var tmp2_safe_receiver_0 = _this__u8e3s4.r6a_1;
      if (tmp2_safe_receiver_0 == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        builder_0.g3p('end_index', JsonPrimitive_2(tmp2_safe_receiver_0));
      }
      tmp = builder_0.x3n();
    } else {
      if (_this__u8e3s4 instanceof Generic) {
        // Inline function 'kotlin.runCatching' call
        var tmp_0;
        try {
          // Inline function 'kotlin.Companion.success' call
          var value = get_jsonObject(JsonUtil_getInstance().c6f_1.q3m(_this__u8e3s4.t6a_1));
          tmp_0 = _Result___init__impl__xyqfz8(value);
        } catch ($p) {
          var tmp_1;
          if ($p instanceof Error) {
            var e = $p;
            // Inline function 'kotlin.Companion.failure' call
            tmp_1 = _Result___init__impl__xyqfz8(createFailure(e));
          } else {
            throw $p;
          }
          tmp_0 = tmp_1;
        }
        // Inline function 'kotlin.getOrElse' call
        var this_0 = tmp_0;
        var exception = Result__exceptionOrNull_impl_p6xea9(this_0);
        var tmp_2;
        if (exception == null) {
          var tmp_3 = _Result___get_value__impl__bjfvqg(this_0);
          tmp_2 = (tmp_3 == null ? true : !(tmp_3 == null)) ? tmp_3 : THROW_CCE();
        } else {
          // Inline function 'kotlinx.serialization.json.buildJsonObject' call
          var builder_1 = new JsonObjectBuilder();
          builder_1.g3p('type', JsonPrimitive_0(_this__u8e3s4.s6a_1));
          builder_1.g3p('payload', JsonPrimitive_0(_this__u8e3s4.t6a_1));
          tmp_2 = builder_1.x3n();
        }
        tmp = tmp_2;
      } else {
        noWhenBranchMatchedException();
      }
    }
  }
  return tmp;
}
var properties_initialized_ResponsesModel_kt_n5dr8n;
function _init_properties_ResponsesModel_kt__n4lql3() {
  if (!properties_initialized_ResponsesModel_kt_n5dr8n) {
    properties_initialized_ResponsesModel_kt_n5dr8n = true;
    DEFAULT_RESPONSES_CAPABILITIES = new ModelCapabilities(Support_Supported_getInstance(), Support_Supported_getInstance(), Support_Supported_getInstance(), Support_Supported_getInstance(), Support_Unknown_getInstance());
    DEFAULT_CAPABILITIES = get_DEFAULT_RESPONSES_CAPABILITIES();
  }
}
function ResponsesRequest$Companion$$childSerializers$_anonymous__ibm9u5() {
  return new ArrayListSerializer(JsonObjectSerializer_getInstance());
}
function ResponsesRequest$Companion$$childSerializers$_anonymous__ibm9u5_0() {
  return new ArrayListSerializer(StringSerializer_getInstance());
}
var Companion_instance_2;
function Companion_getInstance_3() {
  if (Companion_instance_2 === VOID)
    new Companion();
  return Companion_instance_2;
}
var $serializer_instance;
function $serializer_getInstance() {
  if ($serializer_instance === VOID)
    new $serializer();
  return $serializer_instance;
}
var Companion_instance_3;
function Companion_getInstance_4() {
  return Companion_instance_3;
}
var $serializer_instance_0;
function $serializer_getInstance_0() {
  if ($serializer_instance_0 === VOID)
    new $serializer_0();
  return $serializer_instance_0;
}
var Companion_instance_4;
function Companion_getInstance_5() {
  return Companion_instance_4;
}
var $serializer_instance_1;
function $serializer_getInstance_1() {
  if ($serializer_instance_1 === VOID)
    new $serializer_1();
  return $serializer_instance_1;
}
function openaiResponses(_this__u8e3s4, baseUrl, apiKey, modelName, block) {
  baseUrl = baseUrl === VOID ? 'https://api.openai.com' : baseUrl;
  var tmp;
  if (block === VOID) {
    tmp = openaiResponses$lambda;
  } else {
    tmp = block;
  }
  block = tmp;
  // Inline function 'kotlin.apply' call
  var this_0 = new OpenAIResponsesConfig(baseUrl, apiKey, modelName);
  block(this_0);
  var cfg = this_0;
  return _this__u8e3s4.t5z(new OpenAIResponsesModel(cfg.g7f(), _this__u8e3s4.v5z(), cfg.h7f(), cfg.i7f()));
}
function openaiResponses$lambda(_this__u8e3s4) {
  return Unit_instance;
}
var ResponsesStateMode_ServerStored_instance;
var ResponsesStateMode_Replayable_instance;
var ResponsesStateMode_Conversation_instance;
var ResponsesStateMode_entriesInitialized;
function ResponsesStateMode_initEntries() {
  if (ResponsesStateMode_entriesInitialized)
    return Unit_instance;
  ResponsesStateMode_entriesInitialized = true;
  ResponsesStateMode_ServerStored_instance = new ResponsesStateMode('ServerStored', 0);
  ResponsesStateMode_Replayable_instance = new ResponsesStateMode('Replayable', 1);
  ResponsesStateMode_Conversation_instance = new ResponsesStateMode('Conversation', 2);
}
var ResponsesItemTypes_instance;
function ResponsesItemTypes_getInstance() {
  if (ResponsesItemTypes_instance === VOID)
    new ResponsesItemTypes();
  return ResponsesItemTypes_instance;
}
function ResponsesStateMode_ServerStored_getInstance() {
  ResponsesStateMode_initEntries();
  return ResponsesStateMode_ServerStored_instance;
}
function ResponsesStateMode_Replayable_getInstance() {
  ResponsesStateMode_initEntries();
  return ResponsesStateMode_Replayable_instance;
}
function ResponsesStateMode_Conversation_getInstance() {
  ResponsesStateMode_initEntries();
  return ResponsesStateMode_Conversation_instance;
}
//region block: post-declaration
initMetadataForClass(OpenAIChatModel, 'OpenAIChatModel', VOID, VOID, VOID, [1]);
initMetadataForClass(OpenAIParams, 'OpenAIParams', OpenAIParams);
initMetadataForClass(OpenAIConfig, 'OpenAIConfig');
initMetadataForClass(OpenAICapabilitiesScope, 'OpenAICapabilitiesScope');
initMetadataForClass(ResponsesCheckpointCodec, 'ResponsesCheckpointCodec', ResponsesCheckpointCodec);
initMetadataForClass(ToolAcc, 'ToolAcc', ToolAcc);
initMetadataForClass(MessageAcc, 'MessageAcc', MessageAcc);
initMetadataForClass(sam$kotlin_Comparator$0, 'sam$kotlin_Comparator$0', VOID, VOID, [Comparator, FunctionAdapter]);
initMetadataForClass(ResponsesDecoder, 'ResponsesDecoder');
initMetadataForLambda(OpenAIResponsesModel$wireFrames$slambda$slambda, VOID, VOID, [1]);
initMetadataForLambda(OpenAIResponsesModel$wireFrames$slambda, VOID, VOID, [1]);
initMetadataForClass(OpenAIResponsesModel, 'OpenAIResponsesModel', VOID, VOID, VOID, [1]);
initMetadataForClass(ResponsesParams, 'ResponsesParams', ResponsesParams);
initMetadataForCompanion(Companion);
protoOf($serializer).k26 = typeParametersSerializers;
initMetadataForObject($serializer, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ResponsesRequest, 'ResponsesRequest', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance});
initMetadataForCompanion(Companion_0);
protoOf($serializer_0).k26 = typeParametersSerializers;
initMetadataForObject($serializer_0, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ResponsesCheckpointPayload, 'ResponsesCheckpointPayload', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_0});
initMetadataForCompanion(Companion_1);
protoOf($serializer_1).k26 = typeParametersSerializers;
initMetadataForObject($serializer_1, '$serializer', VOID, VOID, [GeneratedSerializer]);
initMetadataForClass(ResponsesText, 'ResponsesText', VOID, VOID, VOID, VOID, VOID, {0: $serializer_getInstance_1});
initMetadataForClass(OpenAIResponsesConfig, 'OpenAIResponsesConfig');
initMetadataForClass(OpenAIResponsesCapabilitiesScope, 'OpenAIResponsesCapabilitiesScope');
initMetadataForClass(ResponsesStateMode, 'ResponsesStateMode');
initMetadataForObject(ResponsesItemTypes, 'ResponsesItemTypes');
//endregion
//region block: init
Companion_instance_3 = new Companion_0();
Companion_instance_4 = new Companion_1();
//endregion
//region block: exports
export {
  ResponsesStateMode_Conversation_getInstance as ResponsesStateMode_Conversation_getInstance3qpbkvax9clq3,
  ResponsesStateMode_Replayable_getInstance as ResponsesStateMode_Replayable_getInstancetxnvwf44qxq8,
  ResponsesStateMode_ServerStored_getInstance as ResponsesStateMode_ServerStored_getInstance1q4xwl1q3bxkc,
  openaiResponses as openaiResponsess1z0i2bwwp6,
  openai as openaicl8tzbjx9bid,
};
//endregion

//# sourceMappingURL=koaks-model-provider-openai.mjs.map
