import {
  Unit_instance104q5opgivhr8 as Unit_instance,
  THROW_CCE2g6jy02ryeudk as THROW_CCE,
  Continuation1aa2oekvx7jm7 as Continuation,
  initMetadataForClassbxx6q50dy2s7 as initMetadataForClass,
  VOID7hggqo3abtya as VOID,
  get_COROUTINE_SUSPENDED3ujt3p13qm4iy as get_COROUTINE_SUSPENDED,
  suspendOrReturn49pspzlx5djv as suspendOrReturn,
  copyToArray2j022khrow2yi as copyToArray,
  emptyList1g2z5xcrvp2zy as emptyList,
  toString1pkumu07cwy4m as toString,
  throwUninitializedPropertyAccessExceptionyynx7gkm73wd as throwUninitializedPropertyAccessException,
  ArrayList3it5z8td81qkl as ArrayList,
  Companion_instance3fplhgf4ipvld as Companion_instance,
  _Result___init__impl__xyqfz81wclroc5pw7j2 as _Result___init__impl__xyqfz8,
  intercepted2ogpsikxxj4u0 as intercepted,
  EmptyCoroutineContext_getInstance2bxophqwsfm9n as EmptyCoroutineContext_getInstance,
  Key_instance2d3ch37kcwr5h as Key_instance,
  equals2au1ep9vhcato as equals,
  createCoroutineUninterceptedGeneratorVersion2gduom218i9ay as createCoroutineUninterceptedGeneratorVersion,
  IllegalStateExceptionkoljg5n0nrlr as IllegalStateException,
  initMetadataForInterface1egvbzx539z91 as initMetadataForInterface,
  UnsupportedOperationException2tkumpmhredt3 as UnsupportedOperationException,
  isInterface3d6p8outrmvmk as isInterface,
  toString30pk9tzaqopn as toString_0,
  initMetadataForObject1cxne3s9w65el as initMetadataForObject,
  hashCodeq5arwsb9dgti as hashCode,
  CancellationException3b36o9qz53rgr as CancellationException,
  Result__exceptionOrNull_impl_p6xea9boty10p2dkn4 as Result__exceptionOrNull_impl_p6xea9,
  _Result___get_value__impl__bjfvqgo6z1uu11rodr as _Result___get_value__impl__bjfvqg,
  createFailure8paxfkfa5dc7 as createFailure,
  AbstractCoroutineContextKey9xr9r6wlj5bm as AbstractCoroutineContextKey,
  AbstractCoroutineContextElement2rpehg0hv5szw as AbstractCoroutineContextElement,
  getxe4seun860fg as get,
  protoOf180f3jzyo7rfj as protoOf,
  minusKey2uxs00uz5ceqp as minusKey,
  ContinuationInterceptor2624y0vaqwxwf as ContinuationInterceptor,
  RuntimeException1r3t0zl97011n as RuntimeException,
  addSuppressedu5jwjfvsc039 as addSuppressed,
  getStringHashCode26igk1bx568vk as getStringHashCode,
  Enum3alwj03lh1n41 as Enum,
  startCoroutine327fwvtqvedik as startCoroutine,
  noWhenBranchMatchedException2a6r7ubxgky5j as noWhenBranchMatchedException,
  Long2qws0ah9gnpki as Long,
  Duration__isPositive_impl_tvkkt210kq31702887c as Duration__isPositive_impl_tvkkt2,
  Companion_getInstance2b73c6hwbaiuw as Companion_getInstance,
  DurationUnit_NANOSECONDS_getInstance25902sick92tf as DurationUnit_NANOSECONDS_getInstance,
  toDurationba1nlt78o6vu as toDuration,
  Duration__plus_impl_yu9v8f3rlq04uypocd2 as Duration__plus_impl_yu9v8f,
  _Duration___get_inWholeMilliseconds__impl__msfiryzor4f65wcski as _Duration___get_inWholeMilliseconds__impl__msfiry,
  ArrayDeque2dzc9uld4xi7n as ArrayDeque,
  captureStack1fzi4aczwc4hg as captureStack,
  Error3ofk6owajcepa as Error_0,
  Element2gr7ezmxqaln7 as Element,
  StringBuildermazzzhj6kkai as StringBuilder,
  plusolev77jfy5r9 as plus,
  get6d5x931vk0s as get_0,
  fold36i9psb7d5v48 as fold,
  minusKeyyqanvso9aovh as minusKey_0,
  anyToString3ho3k49fc56mj as anyToString,
  DurationUnit_MILLISECONDS_getInstance1vv9i8zf23p5u as DurationUnit_MILLISECONDS_getInstance,
  returnIfSuspended31u0py81m9mma as returnIfSuspended,
  ensureNotNull1e947j3ixpazm as ensureNotNull,
  toLongw1zpgk99d84b as toLong,
  IllegalArgumentException2asla15b5jaob as IllegalArgumentException,
  listOf1jh22dvmctj1r as listOf,
  NoSuchElementException679xzhnp5bpj as NoSuchElementException,
  compareTo3ankvs086tmwq as compareTo,
  last2n4gf5az1lkn4 as last,
  _Char___init__impl__6a9atx281r2pd9o601g as _Char___init__impl__6a9atx,
  initMetadataForCompanion1wyw17z38v6ac as initMetadataForCompanion,
  getKClass1s3j9wy1cofik as getKClass,
  Unitkvevlwgzwiuc as Unit,
  copyOf2ng0t8oizk6it as copyOf,
  initMetadataForLambda3af3he42mmnh as initMetadataForLambda,
  joinToString1cxrrlmo0chqs as joinToString,
  startCoroutineUninterceptedOrReturnGeneratorVersion1cv0wx9z0l0zn as startCoroutineUninterceptedOrReturnGeneratorVersion,
  throwKotlinNothingValueException2lxmvl03dor6f as throwKotlinNothingValueException,
  Exceptiondt2hlxn7j7vw as Exception,
  toLongOrNullutqivezb0wx1 as toLongOrNull,
  createCoroutineUninterceptedGeneratorVersion1ji2no4l6ift5 as createCoroutineUninterceptedGeneratorVersion_0,
  plus20p0vtfmu0596 as plus_0,
  KtList3hktaavzmj137 as KtList,
  listOfvhqybd2zx248 as listOf_0,
  getKClassFromExpression3vpejubogshaw as getKClassFromExpression,
  removeFirstOrNull15yg2tczrh8a7 as removeFirstOrNull,
  KtMutableList1beimitadwkna as KtMutableList,
  coerceIn302bduskdb54x as coerceIn,
  boxApply1qmzdb3dh90hg as boxApply,
  HashSet2dzve9y63nf0v as HashSet,
  LinkedHashSet2tkztfx86kyx2 as LinkedHashSet,
} from './kotlin-kotlin-stdlib.mjs';
import {
  atomic$ref$130aurmcwdfdf1 as atomic$ref$1,
  atomic$int$11d5swdyn6j0pu as atomic$int$1,
  atomic$boolean$1iggki4z65a2h as atomic$boolean$1,
  atomicfu$AtomicRefArray$ofNulls2kz3j9ehigwa3 as atomicfu$AtomicRefArray$ofNulls,
  atomic$long$129k9zwo6n9ogd as atomic$long$1,
} from './kotlinx-atomicfu.mjs';
//region block: imports
var imul = Math.imul;
//endregion
//region block: pre-declaration
class Job {}
function cancel$default(cause, $super) {
  cause = cause === VOID ? null : cause;
  var tmp;
  if ($super === VOID) {
    this.uv(cause);
    tmp = Unit_instance;
  } else {
    tmp = $super.uv.call(this, cause);
  }
  return tmp;
}
function invokeOnCompletion$default(onCancelling, invokeImmediately, handler, $super) {
  onCancelling = onCancelling === VOID ? false : onCancelling;
  invokeImmediately = invokeImmediately === VOID ? true : invokeImmediately;
  return $super === VOID ? this.ov(onCancelling, invokeImmediately, handler) : $super.ov.call(this, onCancelling, invokeImmediately, handler);
}
class ParentJob {}
class JobSupport {
  constructor(active) {
    this.eu_1 = atomic$ref$1(active ? get_EMPTY_ACTIVE() : get_EMPTY_NEW());
    this.fu_1 = atomic$ref$1(null);
  }
  m1() {
    return Key_instance_3;
  }
  cv(value) {
    this.fu_1.kotlinx$atomicfu$value = value;
  }
  dv() {
    return this.fu_1.kotlinx$atomicfu$value;
  }
  ev() {
    var tmp0_safe_receiver = this.dv();
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.ev();
  }
  gu(parent) {
    // Inline function 'kotlinx.coroutines.assert' call
    if (parent == null) {
      this.cv(NonDisposableHandle_instance);
      return Unit_instance;
    }
    parent.iv();
    var handle = parent.dw(this);
    this.cv(handle);
    if (this.gv()) {
      handle.bx();
      this.cv(NonDisposableHandle_instance);
    }
  }
  fv() {
    return this.eu_1.kotlinx$atomicfu$value;
  }
  lu() {
    var state = this.fv();
    var tmp;
    if (!(state == null) ? isInterface(state, Incomplete) : false) {
      tmp = state.lu();
    } else {
      tmp = false;
    }
    return tmp;
  }
  gv() {
    var tmp = this.fv();
    return !(!(tmp == null) ? isInterface(tmp, Incomplete) : false);
  }
  hv() {
    var state = this.fv();
    var tmp;
    if (state instanceof CompletedExceptionally) {
      tmp = true;
    } else {
      var tmp_0;
      if (state instanceof Finishing) {
        tmp_0 = state.r13();
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  iv() {
    // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
    while (true) {
      var state = this.fv();
      var tmp0_subject = startInternal(this, state);
      if (tmp0_subject === 0)
        return false;
      else if (tmp0_subject === 1)
        return true;
    }
  }
  jv() {
  }
  kv() {
    var state = this.fv();
    var tmp;
    if (state instanceof Finishing) {
      var tmp0_safe_receiver = state.e14();
      var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : this.lv(tmp0_safe_receiver, get_classSimpleName(this) + ' is cancelling');
      var tmp_0;
      if (tmp1_elvis_lhs == null) {
        var message = 'Job is still new or active: ' + this.toString();
        throw IllegalStateException.t4(toString(message));
      } else {
        tmp_0 = tmp1_elvis_lhs;
      }
      tmp = tmp_0;
    } else {
      if (!(state == null) ? isInterface(state, Incomplete) : false) {
        var message_0 = 'Job is still new or active: ' + this.toString();
        throw IllegalStateException.t4(toString(message_0));
      } else {
        if (state instanceof CompletedExceptionally) {
          tmp = this.mv(state.qu_1);
        } else {
          tmp = JobCancellationException.z13(get_classSimpleName(this) + ' has completed normally', null, this);
        }
      }
    }
    return tmp;
  }
  lv(_this__u8e3s4, message) {
    var tmp0_elvis_lhs = _this__u8e3s4 instanceof CancellationException ? _this__u8e3s4 : null;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlinx.coroutines.JobSupport.defaultCancellationException' call
      tmp = JobCancellationException.z13(message == null ? this.ou() : message, _this__u8e3s4, this);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
  mv(_this__u8e3s4, message, $super) {
    message = message === VOID ? null : message;
    return $super === VOID ? this.lv(_this__u8e3s4, message) : $super.lv.call(this, _this__u8e3s4, message);
  }
  nv(handler) {
    return this.qv(true, new InvokeOnCompletion(handler));
  }
  ov(onCancelling, invokeImmediately, handler) {
    var tmp;
    if (onCancelling) {
      tmp = new InvokeOnCancelling(handler);
    } else {
      tmp = new InvokeOnCompletion(handler);
    }
    return this.qv(invokeImmediately, tmp);
  }
  qv(invokeImmediately, node) {
    node.mx_1 = this;
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'kotlinx.coroutines.JobSupport.tryPutNodeIntoList' call
      // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
      while (true) {
        var state = this.fv();
        if (state instanceof Empty) {
          if (state.h13_1) {
            if (this.eu_1.atomicfu$compareAndSet(state, node)) {
              tmp$ret$0 = true;
              break $l$block_1;
            }
          } else {
            promoteEmptyToNodeList(this, state);
          }
        } else {
          if (!(state == null) ? isInterface(state, Incomplete) : false) {
            var list = state.ox();
            if (list == null) {
              promoteSingleToNodeList(this, state instanceof JobNode ? state : THROW_CCE());
            } else {
              var tmp;
              if (node.fx()) {
                var tmp0_safe_receiver = state instanceof Finishing ? state : null;
                var rootCause = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.e14();
                var tmp_0;
                if (rootCause == null) {
                  tmp_0 = list.sx(node, 5);
                } else {
                  if (invokeImmediately) {
                    node.cx(rootCause);
                  }
                  return NonDisposableHandle_instance;
                }
                tmp = tmp_0;
              } else {
                tmp = list.sx(node, 1);
              }
              if (tmp) {
                tmp$ret$0 = true;
                break $l$block_1;
              }
            }
          } else {
            tmp$ret$0 = false;
            break $l$block_1;
          }
        }
      }
    }
    var added = tmp$ret$0;
    if (added)
      return node;
    else if (invokeImmediately) {
      var tmp_1 = this.fv();
      var tmp0_safe_receiver_0 = tmp_1 instanceof CompletedExceptionally ? tmp_1 : null;
      node.cx(tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.qu_1);
    }
    return NonDisposableHandle_instance;
  }
  rv($completion) {
    if (!joinInternal(this)) {
      // Inline function 'kotlin.js.getCoroutineContext' call
      var tmp$ret$0 = $completion.lc();
      ensureActive(tmp$ret$0);
      return Unit_instance;
    }
    return joinSuspend(this, $completion);
  }
  sv(node) {
    // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
    while (true) {
      var state = this.fv();
      if (state instanceof JobNode) {
        if (!(state === node))
          return Unit_instance;
        if (this.eu_1.atomicfu$compareAndSet(state, get_EMPTY_ACTIVE()))
          return Unit_instance;
      } else {
        if (!(state == null) ? isInterface(state, Incomplete) : false) {
          if (!(state.ox() == null)) {
            node.tx();
          }
          return Unit_instance;
        } else {
          return Unit_instance;
        }
      }
    }
  }
  tv() {
    return false;
  }
  uv(cause) {
    var tmp;
    if (cause == null) {
      // Inline function 'kotlinx.coroutines.JobSupport.defaultCancellationException' call
      tmp = JobCancellationException.z13(null == null ? this.ou() : null, null, this);
    } else {
      tmp = cause;
    }
    this.wv(tmp);
  }
  ou() {
    return 'Job was cancelled';
  }
  wv(cause) {
    this.aw(cause);
  }
  xv(parentJob) {
    this.aw(parentJob);
  }
  yv(cause) {
    if (cause instanceof CancellationException)
      return true;
    return this.aw(cause) && this.gw();
  }
  zv(cause) {
    return this.aw(cause);
  }
  aw(cause) {
    var finalState = get_COMPLETING_ALREADY();
    if (this.tv()) {
      finalState = cancelMakeCompleting(this, cause);
      if (finalState === get_COMPLETING_WAITING_CHILDREN())
        return true;
    }
    if (finalState === get_COMPLETING_ALREADY()) {
      finalState = makeCancelling(this, cause);
    }
    var tmp;
    if (finalState === get_COMPLETING_ALREADY()) {
      tmp = true;
    } else if (finalState === get_COMPLETING_WAITING_CHILDREN()) {
      tmp = true;
    } else if (finalState === get_TOO_LATE_TO_CANCEL()) {
      tmp = false;
    } else {
      this.vu(finalState);
      tmp = true;
    }
    return tmp;
  }
  bw() {
    var state = this.fv();
    var tmp;
    if (state instanceof Finishing) {
      tmp = state.e14();
    } else {
      if (state instanceof CompletedExceptionally) {
        tmp = state.qu_1;
      } else {
        if (!(state == null) ? isInterface(state, Incomplete) : false) {
          var message = 'Cannot be cancelling child in this state: ' + toString(state);
          throw IllegalStateException.t4(toString(message));
        } else {
          tmp = null;
        }
      }
    }
    var rootCause = tmp;
    var tmp1_elvis_lhs = rootCause instanceof CancellationException ? rootCause : null;
    return tmp1_elvis_lhs == null ? JobCancellationException.z13('Parent job is ' + stateString(this, state), rootCause, this) : tmp1_elvis_lhs;
  }
  cw(proposedUpdate) {
    // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
    while (true) {
      var tmp1 = this.fv();
      $l$block: {
        var finalState = tryMakeCompleting(this, tmp1, proposedUpdate);
        if (finalState === get_COMPLETING_ALREADY())
          return false;
        else if (finalState === get_COMPLETING_WAITING_CHILDREN())
          return true;
        else if (finalState === get_COMPLETING_RETRY()) {
          break $l$block;
        } else {
          this.vu(finalState);
          return true;
        }
      }
    }
  }
  tu(proposedUpdate) {
    // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
    while (true) {
      var tmp1 = this.fv();
      $l$block: {
        var finalState = tryMakeCompleting(this, tmp1, proposedUpdate);
        if (finalState === get_COMPLETING_ALREADY())
          throw IllegalStateException.pd('Job ' + this.toString() + ' is already complete or completing, ' + ('but is being completed with ' + toString_0(proposedUpdate)), _get_exceptionOrNull__b3j7js(this, proposedUpdate));
        else if (finalState === get_COMPLETING_RETRY()) {
          break $l$block;
        } else
          return finalState;
      }
    }
  }
  dw(child) {
    // Inline function 'kotlin.also' call
    var this_0 = new ChildHandleNode(child);
    this_0.mx_1 = this;
    var node = this_0;
    var tmp$ret$2;
    $l$block_1: {
      // Inline function 'kotlinx.coroutines.JobSupport.tryPutNodeIntoList' call
      // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
      while (true) {
        var state = this.fv();
        if (state instanceof Empty) {
          if (state.h13_1) {
            if (this.eu_1.atomicfu$compareAndSet(state, node)) {
              tmp$ret$2 = true;
              break $l$block_1;
            }
          } else {
            promoteEmptyToNodeList(this, state);
          }
        } else {
          if (!(state == null) ? isInterface(state, Incomplete) : false) {
            var list = state.ox();
            if (list == null) {
              promoteSingleToNodeList(this, state instanceof JobNode ? state : THROW_CCE());
            } else {
              var addedBeforeCancellation = list.sx(node, 7);
              var tmp;
              if (addedBeforeCancellation) {
                tmp = true;
              } else {
                var addedBeforeCompletion = list.sx(node, 3);
                var latestState = this.fv();
                var tmp_0;
                if (latestState instanceof Finishing) {
                  tmp_0 = latestState.e14();
                } else {
                  // Inline function 'kotlinx.coroutines.assert' call
                  var tmp0_safe_receiver = latestState instanceof CompletedExceptionally ? latestState : null;
                  tmp_0 = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.qu_1;
                }
                var rootCause = tmp_0;
                node.cx(rootCause);
                var tmp_1;
                if (addedBeforeCompletion) {
                  // Inline function 'kotlinx.coroutines.assert' call
                  tmp_1 = true;
                } else {
                  return NonDisposableHandle_instance;
                }
                tmp = tmp_1;
              }
              if (tmp) {
                tmp$ret$2 = true;
                break $l$block_1;
              }
            }
          } else {
            tmp$ret$2 = false;
            break $l$block_1;
          }
        }
      }
    }
    var added = tmp$ret$2;
    if (added)
      return node;
    var tmp_2 = this.fv();
    var tmp0_safe_receiver_0 = tmp_2 instanceof CompletedExceptionally ? tmp_2 : null;
    node.cx(tmp0_safe_receiver_0 == null ? null : tmp0_safe_receiver_0.qu_1);
    return NonDisposableHandle_instance;
  }
  wu(exception) {
    throw exception;
  }
  ew(cause) {
  }
  fw() {
    return false;
  }
  gw() {
    return true;
  }
  hw(exception) {
    return false;
  }
  pu(state) {
  }
  vu(state) {
  }
  toString() {
    return this.iw() + '@' + get_hexAddress(this);
  }
  iw() {
    return this.xu() + '{' + stateString(this, this.fv()) + '}';
  }
  xu() {
    return get_classSimpleName(this);
  }
  jw() {
    var state = this.fv();
    // Inline function 'kotlin.check' call
    if (!!(!(state == null) ? isInterface(state, Incomplete) : false)) {
      var message = 'This job has not completed yet';
      throw IllegalStateException.t4(toString(message));
    }
    return _get_exceptionOrNull__b3j7js(this, state);
  }
  kw() {
    var state = this.fv();
    // Inline function 'kotlin.check' call
    if (!!(!(state == null) ? isInterface(state, Incomplete) : false)) {
      var message = 'This job has not completed yet';
      throw IllegalStateException.t4(toString(message));
    }
    if (state instanceof CompletedExceptionally)
      throw state.qu_1;
    return unboxState(state);
  }
  lw($completion) {
    $l$loop: while (true) {
      var state = this.fv();
      if (!(!(state == null) ? isInterface(state, Incomplete) : false)) {
        if (state instanceof CompletedExceptionally) {
          // Inline function 'kotlinx.coroutines.internal.recoverAndThrow' call
          throw state.qu_1;
        }
        return unboxState(state);
      }
      if (startInternal(this, state) >= 0)
        break $l$loop;
    }
    return awaitSuspend(this, $completion);
  }
}
class CoroutineScope {}
class AbstractCoroutine extends JobSupport {
  constructor(parentContext, initParentJob, active) {
    super(active);
    if (initParentJob) {
      this.gu(parentContext.yc(Key_instance_3));
    }
    this.ju_1 = parentContext.dn(this);
  }
  lc() {
    return this.ju_1;
  }
  ku() {
    return this.ju_1;
  }
  lu() {
    return super.lu();
  }
  mu(value) {
  }
  nu(cause, handled) {
  }
  ou() {
    return get_classSimpleName(this) + ' was cancelled';
  }
  pu(state) {
    if (state instanceof CompletedExceptionally) {
      this.nu(state.qu_1, state.su());
    } else {
      this.mu((state == null ? true : !(state == null)) ? state : THROW_CCE());
    }
  }
  nc(result) {
    var state = this.tu(toState_0(result));
    if (state === get_COMPLETING_WAITING_CHILDREN())
      return Unit_instance;
    this.uu(state);
  }
  uu(state) {
    return this.vu(state);
  }
  wu(exception) {
    handleCoroutineException(this.ju_1, exception);
  }
  xu() {
    var tmp0_elvis_lhs = get_coroutineName(this.ju_1);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return super.xu();
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var coroutineName = tmp;
    return '"' + coroutineName + '":' + super.xu();
  }
  yu(start, receiver, block) {
    start.bv(block, receiver, this);
  }
}
class NotCompleted {}
class CancelHandler {}
class DisposeHandlersOnCancel {
  constructor($outer, nodes) {
    this.qw_1 = $outer;
    this.pw_1 = nodes;
  }
  rw() {
    // Inline function 'kotlin.collections.forEach' call
    var indexedObject = this.pw_1;
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var element = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      element.ax().bx();
    }
  }
  cx(cause) {
    this.rw();
  }
  toString() {
    return 'DisposeHandlersOnCancel[' + toString(this.pw_1) + ']';
  }
}
class LockFreeLinkedListNode {
  constructor($box) {
    boxApply(this, $box);
    this.px_1 = this;
    this.qx_1 = this;
    this.rx_1 = false;
  }
  sx(node, permissionsBitmask) {
    var prev = this.qx_1;
    var tmp;
    if (prev instanceof ListClosed) {
      tmp = ((prev.b1l_1 & permissionsBitmask) === 0 && prev.sx(node, permissionsBitmask));
    } else {
      node.px_1 = this;
      node.qx_1 = prev;
      prev.px_1 = node;
      this.qx_1 = node;
      tmp = true;
    }
    return tmp;
  }
  m13(forbiddenElementsBit) {
    this.sx(new ListClosed(forbiddenElementsBit), forbiddenElementsBit);
  }
  tx() {
    if (this.rx_1)
      return false;
    var prev = this.qx_1;
    var next = this.px_1;
    prev.px_1 = next;
    next.qx_1 = prev;
    this.rx_1 = true;
    return true;
  }
  ux(node) {
    if (!(this.px_1 === this))
      return false;
    this.sx(node, -2147483648);
    return true;
  }
}
class Incomplete {}
class JobNode extends LockFreeLinkedListNode {
  nx() {
    var tmp = this.mx_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('job');
    }
  }
  lu() {
    return true;
  }
  ox() {
    return null;
  }
  bx() {
    return this.nx().sv(this);
  }
  toString() {
    return get_classSimpleName(this) + '@' + get_hexAddress(this) + '[job@' + get_hexAddress(this.nx()) + ']';
  }
}
class AwaitAllNode extends JobNode {
  constructor($outer, continuation, $box) {
    if ($box === VOID)
      $box = {};
    $box.zw_1 = $outer;
    super($box);
    this.ww_1 = continuation;
    this.yw_1 = atomic$ref$1(null);
  }
  ax() {
    var tmp = this.xw_1;
    if (!(tmp == null))
      return tmp;
    else {
      throwUninitializedPropertyAccessException('handle');
    }
  }
  dx(value) {
    this.yw_1.kotlinx$atomicfu$value = value;
  }
  ex() {
    return this.yw_1.kotlinx$atomicfu$value;
  }
  fx() {
    return false;
  }
  cx(cause) {
    if (!(cause == null)) {
      var token = this.ww_1.hx(cause);
      if (!(token == null)) {
        this.ww_1.ix(token);
        var tmp0_safe_receiver = this.ex();
        if (tmp0_safe_receiver == null)
          null;
        else {
          tmp0_safe_receiver.rw();
        }
      }
    } else if (this.zw_1.nw_1.atomicfu$decrementAndGet() === 0) {
      var tmp2 = this.ww_1;
      // Inline function 'kotlin.collections.map' call
      var this_0 = this.zw_1.mw_1;
      // Inline function 'kotlin.collections.mapTo' call
      var destination = ArrayList.x(this_0.length);
      var inductionVariable = 0;
      var last = this_0.length;
      while (inductionVariable < last) {
        var item = this_0[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        var tmp$ret$0 = item.gx();
        destination.l(tmp$ret$0);
      }
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var tmp$ret$3 = _Result___init__impl__xyqfz8(destination);
      tmp2.nc(tmp$ret$3);
    }
  }
}
class AwaitAll {
  constructor(deferreds) {
    this.mw_1 = deferreds;
    this.nw_1 = atomic$int$1(this.mw_1.length);
  }
  ow($completion) {
    var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
    cancellable.by();
    var tmp = 0;
    var tmp_0 = this.mw_1.length;
    // Inline function 'kotlin.arrayOfNulls' call
    var tmp_1 = Array(tmp_0);
    while (tmp < tmp_0) {
      var tmp_2 = tmp;
      var deferred = this.mw_1[tmp_2];
      deferred.iv();
      // Inline function 'kotlin.apply' call
      var this_0 = new AwaitAllNode(this, cancellable);
      this_0.xw_1 = invokeOnCompletion(deferred, VOID, this_0);
      tmp_1[tmp_2] = this_0;
      tmp = tmp + 1 | 0;
    }
    var nodes = tmp_1;
    var disposer = new DisposeHandlersOnCancel(this, nodes);
    // Inline function 'kotlin.collections.forEach' call
    var inductionVariable = 0;
    var last = nodes.length;
    while (inductionVariable < last) {
      var element = nodes[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      element.dx(disposer);
    }
    if (cancellable.gv()) {
      disposer.rw();
    } else {
      invokeOnCancellation(cancellable, disposer);
    }
    return cancellable.cy();
  }
}
class StandaloneCoroutine extends AbstractCoroutine {
  constructor(parentContext, active) {
    super(parentContext, true, active);
  }
  hw(exception) {
    handleCoroutineException(this.ju_1, exception);
    return true;
  }
}
class LazyStandaloneCoroutine extends StandaloneCoroutine {
  constructor(parentContext, block) {
    super(parentContext, false);
    this.py_1 = createCoroutineUninterceptedGeneratorVersion(block, this, this);
  }
  jv() {
    startCoroutineCancellable_0(this.py_1, this);
  }
}
class ScopeCoroutine extends AbstractCoroutine {
  constructor(context, uCont) {
    super(context, true, true);
    this.ty_1 = uCont;
  }
  fw() {
    return true;
  }
  vu(state) {
    resumeCancellableWith(intercepted(this.ty_1), recoverResult(state, this.ty_1));
  }
  uy() {
  }
  uu(state) {
    this.ty_1.nc(recoverResult(state, this.ty_1));
  }
}
class DispatchedCoroutine extends ScopeCoroutine {
  constructor(context, uCont) {
    super(context, uCont);
    this.iy_1 = atomic$int$1(0);
  }
  vu(state) {
    this.uu(state);
  }
  uu(state) {
    if (tryResume(this))
      return Unit_instance;
    resumeCancellableWith(intercepted(this.ty_1), recoverResult(state, this.ty_1));
  }
  cy() {
    if (trySuspend(this))
      return get_COROUTINE_SUSPENDED();
    var state = unboxState(this.fv());
    if (state instanceof CompletedExceptionally)
      throw state.qu_1;
    return (state == null ? true : !(state == null)) ? state : THROW_CCE();
  }
}
class DeferredCoroutine extends AbstractCoroutine {
  constructor(parentContext, active) {
    super(parentContext, true, active);
  }
  gx() {
    var tmp = this.kw();
    return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  }
  ow($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_await__mos7q6.bind(VOID, this), $completion);
  }
}
class LazyDeferredCoroutine extends DeferredCoroutine {
  constructor(parentContext, block) {
    super(parentContext, false);
    this.bz_1 = createCoroutineUninterceptedGeneratorVersion(block, this, this);
  }
  jv() {
    startCoroutineCancellable_0(this.bz_1, this);
  }
}
class CancellableContinuation {}
class DisposeOnCancel {
  constructor(handle) {
    this.hz_1 = handle;
  }
  cx(cause) {
    return this.hz_1.bx();
  }
  toString() {
    return 'DisposeOnCancel[' + toString(this.hz_1) + ']';
  }
}
class Runnable {}
class SchedulerTask {}
class DispatchedTask extends SchedulerTask {
  constructor(resumeMode) {
    super();
    this.rz_1 = resumeMode;
  }
  o10(takenState, cause) {
  }
  v10(state) {
    return (state == null ? true : !(state == null)) ? state : THROW_CCE();
  }
  f11(state) {
    var tmp0_safe_receiver = state instanceof CompletedExceptionally ? state : null;
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.qu_1;
  }
  h11() {
    // Inline function 'kotlinx.coroutines.assert' call
    try {
      var tmp = this.m10();
      var delegate = tmp instanceof DispatchedContinuation ? tmp : THROW_CCE();
      var continuation = delegate.kz_1;
      // Inline function 'kotlinx.coroutines.withContinuationContext' call
      delegate.mz_1;
      var context = continuation.lc();
      var state = this.n10();
      var exception = this.f11(state);
      var job = exception == null && get_isCancellableMode(this.rz_1) ? context.yc(Key_instance_3) : null;
      if (!(job == null) && !job.lu()) {
        var cause = job.kv();
        this.o10(state, cause);
        // Inline function 'kotlinx.coroutines.resumeWithStackTrace' call
        // Inline function 'kotlin.Companion.failure' call
        var exception_0 = recoverStackTrace(cause, continuation);
        var tmp$ret$1 = _Result___init__impl__xyqfz8(createFailure(exception_0));
        continuation.nc(tmp$ret$1);
      } else {
        if (!(exception == null)) {
          // Inline function 'kotlin.coroutines.resumeWithException' call
          // Inline function 'kotlin.Companion.failure' call
          var tmp$ret$3 = _Result___init__impl__xyqfz8(createFailure(exception));
          continuation.nc(tmp$ret$3);
        } else {
          // Inline function 'kotlin.coroutines.resume' call
          // Inline function 'kotlin.Companion.success' call
          var value = this.v10(state);
          var tmp$ret$5 = _Result___init__impl__xyqfz8(value);
          continuation.nc(tmp$ret$5);
        }
      }
    } catch ($p) {
      if ($p instanceof DispatchException) {
        var e = $p;
        handleCoroutineException(this.m10().lc(), e.a12_1);
      } else {
        if ($p instanceof Error) {
          var e_0 = $p;
          this.i11(e_0);
        } else {
          throw $p;
        }
      }
    }
  }
  i11(exception) {
    var reason = CoroutinesInternalError.b13('Fatal exception in coroutines machinery for ' + toString(this) + '. ' + "Please read KDoc to 'handleFatalException' method and report this incident to maintainers", exception);
    handleCoroutineException(this.m10().lc(), reason);
  }
}
class Waiter {}
class CancellableContinuationImpl extends DispatchedTask {
  constructor(delegate, resumeMode) {
    super(resumeMode);
    this.wx_1 = delegate;
    // Inline function 'kotlinx.coroutines.assert' call
    this.xx_1 = this.wx_1.lc();
    var tmp = this;
    // Inline function 'kotlinx.coroutines.decisionAndIndex' call
    var tmp$ret$1 = (0 << 29) + 536870911 | 0;
    tmp.yx_1 = atomic$int$1(tmp$ret$1);
    this.zx_1 = atomic$ref$1(Active_instance);
    this.ay_1 = atomic$ref$1(null);
  }
  m10() {
    return this.wx_1;
  }
  lc() {
    return this.xx_1;
  }
  fv() {
    return this.zx_1.kotlinx$atomicfu$value;
  }
  gv() {
    var tmp = this.fv();
    return !(!(tmp == null) ? isInterface(tmp, NotCompleted) : false);
  }
  hv() {
    var tmp = this.fv();
    return tmp instanceof CancelledContinuation;
  }
  by() {
    var tmp0_elvis_lhs = installParentHandle(this);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return Unit_instance;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var handle = tmp;
    if (this.gv()) {
      handle.bx();
      this.ay_1.kotlinx$atomicfu$value = NonDisposableHandle_instance;
    }
  }
  pz() {
    // Inline function 'kotlinx.coroutines.assert' call
    // Inline function 'kotlinx.coroutines.assert' call
    var state = this.zx_1.kotlinx$atomicfu$value;
    // Inline function 'kotlinx.coroutines.assert' call
    var tmp;
    if (state instanceof CompletedContinuation) {
      tmp = !(state.f10_1 == null);
    } else {
      tmp = false;
    }
    if (tmp) {
      this.l10();
      return false;
    }
    var tmp_0 = this.yx_1;
    // Inline function 'kotlinx.coroutines.decisionAndIndex' call
    tmp_0.kotlinx$atomicfu$value = (0 << 29) + 536870911 | 0;
    this.zx_1.kotlinx$atomicfu$value = Active_instance;
    return true;
  }
  n10() {
    return this.fv();
  }
  o10(takenState, cause) {
    var this_0 = this.zx_1;
    while (true) {
      var state = this_0.kotlinx$atomicfu$value;
      if (!(state == null) ? isInterface(state, NotCompleted) : false) {
        // Inline function 'kotlin.error' call
        var message = 'Not completed';
        throw IllegalStateException.t4(toString(message));
      } else {
        if (state instanceof CompletedExceptionally)
          return Unit_instance;
        else {
          if (state instanceof CompletedContinuation) {
            // Inline function 'kotlin.check' call
            if (!!state.i10()) {
              var message_0 = 'Must be called at most once';
              throw IllegalStateException.t4(toString(message_0));
            }
            var update = state.j10(VOID, VOID, VOID, VOID, cause);
            if (this.zx_1.atomicfu$compareAndSet(state, update)) {
              state.p10(this, cause);
              return Unit_instance;
            }
          } else {
            if (this.zx_1.atomicfu$compareAndSet(state, new CompletedContinuation(state, VOID, VOID, VOID, cause))) {
              return Unit_instance;
            }
          }
        }
      }
    }
    return Unit_instance;
  }
  q10(cause) {
    // Inline function 'kotlinx.atomicfu.loop' call
    var this_0 = this.zx_1;
    while (true) {
      var tmp1 = this_0.kotlinx$atomicfu$value;
      $l$block: {
        if (!(!(tmp1 == null) ? isInterface(tmp1, NotCompleted) : false))
          return false;
        var tmp;
        if (isInterface(tmp1, CancelHandler)) {
          tmp = true;
        } else {
          tmp = tmp1 instanceof Segment;
        }
        var update = new CancelledContinuation(this, cause, tmp);
        if (!this.zx_1.atomicfu$compareAndSet(tmp1, update)) {
          break $l$block;
        }
        if (isInterface(tmp1, CancelHandler)) {
          this.h10(tmp1, cause);
        } else {
          if (tmp1 instanceof Segment) {
            callSegmentOnCancellation(this, tmp1, cause);
          }
        }
        detachChildIfNonReusable(this);
        dispatchResume(this, this.rz_1);
        return true;
      }
    }
  }
  r10(cause) {
    if (cancelLater(this, cause))
      return Unit_instance;
    this.q10(cause);
    detachChildIfNonReusable(this);
  }
  h10(handler, cause) {
    // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.callCancelHandlerSafely' call
    try {
      handler.cx(cause);
    } catch ($p) {
      if ($p instanceof Error) {
        var ex = $p;
        handleCoroutineException(this.lc(), CompletionHandlerException.b10('Exception in invokeOnCancellation handler for ' + this.toString(), ex));
      } else {
        throw $p;
      }
    }
    return Unit_instance;
  }
  s10(onCancellation, cause, value) {
    try {
      onCancellation(cause, value, this.lc());
    } catch ($p) {
      if ($p instanceof Error) {
        var ex = $p;
        handleCoroutineException(this.lc(), CompletionHandlerException.b10('Exception in resume onCancellation handler for ' + this.toString(), ex));
      } else {
        throw $p;
      }
    }
  }
  t10(parent) {
    return parent.kv();
  }
  cy() {
    var isReusable_0 = isReusable(this);
    if (trySuspend_0(this)) {
      if (_get_parentHandle__f8dcex(this) == null) {
        installParentHandle(this);
      }
      if (isReusable_0) {
        this.u10();
      }
      return get_COROUTINE_SUSPENDED();
    }
    if (isReusable_0) {
      this.u10();
    }
    var state = this.fv();
    if (state instanceof CompletedExceptionally)
      throw recoverStackTrace(state.qu_1, this);
    if (get_isCancellableMode(this.rz_1)) {
      var job = this.lc().yc(Key_instance_3);
      if (!(job == null) && !job.lu()) {
        var cause = job.kv();
        this.o10(state, cause);
        throw recoverStackTrace(cause, this);
      }
    }
    return this.v10(state);
  }
  u10() {
    var tmp = this.wx_1;
    var tmp0_safe_receiver = tmp instanceof DispatchedContinuation ? tmp : null;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.w10(this);
    var tmp_0;
    if (tmp1_elvis_lhs == null) {
      return Unit_instance;
    } else {
      tmp_0 = tmp1_elvis_lhs;
    }
    var cancellationCause = tmp_0;
    this.l10();
    this.q10(cancellationCause);
  }
  nc(result) {
    return this.x10(toState(result, this), this.rz_1);
  }
  y10(value, onCancellation) {
    var tmp = this.rz_1;
    var tmp_0;
    if (onCancellation == null) {
      tmp_0 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_0 = CancellableContinuationImpl$resume$lambda(onCancellation);
    }
    return this.z10(value, tmp, tmp_0);
  }
  fz(value, onCancellation) {
    return this.z10(value, this.rz_1, onCancellation);
  }
  a11(segment, index) {
    var tmp0 = this.yx_1;
    $l$block: {
      // Inline function 'kotlinx.atomicfu.update' call
      while (true) {
        var cur = tmp0.kotlinx$atomicfu$value;
        // Inline function 'kotlinx.coroutines.index' call
        // Inline function 'kotlin.check' call
        if (!((cur & 536870911) === 536870911)) {
          var message = 'invokeOnCancellation should be called at most once';
          throw IllegalStateException.t4(toString(message));
        }
        // Inline function 'kotlinx.coroutines.decision' call
        // Inline function 'kotlinx.coroutines.decisionAndIndex' call
        var upd = (cur >> 29 << 29) + index | 0;
        if (tmp0.atomicfu$compareAndSet(cur, upd)) {
          break $l$block;
        }
      }
    }
    invokeOnCancellationImpl(this, segment);
  }
  dz(handler) {
    return invokeOnCancellation(this, new UserSupplied(handler));
  }
  gz(handler) {
    return invokeOnCancellationImpl(this, handler);
  }
  z10(proposedUpdate, resumeMode, onCancellation) {
    // Inline function 'kotlinx.atomicfu.loop' call
    var this_0 = this.zx_1;
    while (true) {
      var tmp1 = this_0.kotlinx$atomicfu$value;
      $l$block: {
        if (!(tmp1 == null) ? isInterface(tmp1, NotCompleted) : false) {
          var update = resumedState(this, tmp1, proposedUpdate, resumeMode, onCancellation, null);
          if (!this.zx_1.atomicfu$compareAndSet(tmp1, update)) {
            break $l$block;
          }
          detachChildIfNonReusable(this);
          dispatchResume(this, resumeMode);
          return Unit_instance;
        } else {
          if (tmp1 instanceof CancelledContinuation) {
            if (tmp1.e11()) {
              if (onCancellation == null)
                null;
              else {
                // Inline function 'kotlin.let' call
                this.s10(onCancellation, tmp1.qu_1, proposedUpdate);
              }
              return Unit_instance;
            }
          }
        }
        alreadyResumedError(this, proposedUpdate);
      }
    }
  }
  x10(proposedUpdate, resumeMode, onCancellation, $super) {
    onCancellation = onCancellation === VOID ? null : onCancellation;
    var tmp;
    if ($super === VOID) {
      this.z10(proposedUpdate, resumeMode, onCancellation);
      tmp = Unit_instance;
    } else {
      tmp = $super.z10.call(this, proposedUpdate, resumeMode, onCancellation);
    }
    return tmp;
  }
  l10() {
    var tmp0_elvis_lhs = _get_parentHandle__f8dcex(this);
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return Unit_instance;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var handle = tmp;
    handle.bx();
    this.ay_1.kotlinx$atomicfu$value = NonDisposableHandle_instance;
  }
  cz(value, idempotent, onCancellation) {
    return tryResumeImpl(this, value, idempotent, onCancellation);
  }
  hx(exception) {
    return tryResumeImpl(this, new CompletedExceptionally(exception), null, null);
  }
  ix(token) {
    // Inline function 'kotlinx.coroutines.assert' call
    dispatchResume(this, this.rz_1);
  }
  ez(_this__u8e3s4, value) {
    var tmp = this.wx_1;
    var dc = tmp instanceof DispatchedContinuation ? tmp : null;
    var tmp_0;
    if ((dc == null ? null : dc.jz_1) === _this__u8e3s4) {
      tmp_0 = 4;
    } else {
      tmp_0 = this.rz_1;
    }
    this.x10(value, tmp_0);
  }
  v10(state) {
    var tmp;
    if (state instanceof CompletedContinuation) {
      var tmp_0 = state.c10_1;
      tmp = (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
    } else {
      tmp = (state == null ? true : !(state == null)) ? state : THROW_CCE();
    }
    return tmp;
  }
  f11(state) {
    var tmp0_safe_receiver = super.f11(state);
    var tmp;
    if (tmp0_safe_receiver == null) {
      tmp = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp = recoverStackTrace(tmp0_safe_receiver, this.wx_1);
    }
    return tmp;
  }
  toString() {
    return this.g11() + '(' + toDebugString(this.wx_1) + '){' + _get_stateDebugRepresentation__bf18u4(this) + '}@' + get_hexAddress(this);
  }
  g11() {
    return 'CancellableContinuation';
  }
}
class UserSupplied {
  constructor(handler) {
    this.j11_1 = handler;
  }
  cx(cause) {
    this.j11_1(cause);
  }
  toString() {
    return 'CancelHandler.UserSupplied[' + get_classSimpleName(this.j11_1) + '@' + get_hexAddress(this) + ']';
  }
}
class Active {
  toString() {
    return 'Active';
  }
}
class CompletedContinuation {
  constructor(result, cancelHandler, onCancellation, idempotentResume, cancelCause) {
    cancelHandler = cancelHandler === VOID ? null : cancelHandler;
    onCancellation = onCancellation === VOID ? null : onCancellation;
    idempotentResume = idempotentResume === VOID ? null : idempotentResume;
    cancelCause = cancelCause === VOID ? null : cancelCause;
    this.c10_1 = result;
    this.d10_1 = cancelHandler;
    this.e10_1 = onCancellation;
    this.f10_1 = idempotentResume;
    this.g10_1 = cancelCause;
  }
  i10() {
    return !(this.g10_1 == null);
  }
  p10(cont, cause) {
    var tmp0_safe_receiver = this.d10_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      cont.h10(tmp0_safe_receiver, cause);
    }
    var tmp1_safe_receiver = this.e10_1;
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      cont.s10(tmp1_safe_receiver, cause, this.c10_1);
    }
  }
  k11(result, cancelHandler, onCancellation, idempotentResume, cancelCause) {
    return new CompletedContinuation(result, cancelHandler, onCancellation, idempotentResume, cancelCause);
  }
  j10(result, cancelHandler, onCancellation, idempotentResume, cancelCause, $super) {
    result = result === VOID ? this.c10_1 : result;
    cancelHandler = cancelHandler === VOID ? this.d10_1 : cancelHandler;
    onCancellation = onCancellation === VOID ? this.e10_1 : onCancellation;
    idempotentResume = idempotentResume === VOID ? this.f10_1 : idempotentResume;
    cancelCause = cancelCause === VOID ? this.g10_1 : cancelCause;
    return $super === VOID ? this.k11(result, cancelHandler, onCancellation, idempotentResume, cancelCause) : $super.k11.call(this, result, cancelHandler, onCancellation, idempotentResume, cancelCause);
  }
  toString() {
    return 'CompletedContinuation(result=' + toString_0(this.c10_1) + ', cancelHandler=' + toString_0(this.d10_1) + ', onCancellation=' + toString_0(this.e10_1) + ', idempotentResume=' + toString_0(this.f10_1) + ', cancelCause=' + toString_0(this.g10_1) + ')';
  }
  hashCode() {
    var result = this.c10_1 == null ? 0 : hashCode(this.c10_1);
    result = imul(result, 31) + (this.d10_1 == null ? 0 : hashCode(this.d10_1)) | 0;
    result = imul(result, 31) + (this.e10_1 == null ? 0 : hashCode(this.e10_1)) | 0;
    result = imul(result, 31) + (this.f10_1 == null ? 0 : hashCode(this.f10_1)) | 0;
    result = imul(result, 31) + (this.g10_1 == null ? 0 : hashCode(this.g10_1)) | 0;
    return result;
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CompletedContinuation))
      return false;
    var tmp0_other_with_cast = other instanceof CompletedContinuation ? other : THROW_CCE();
    if (!equals(this.c10_1, tmp0_other_with_cast.c10_1))
      return false;
    if (!equals(this.d10_1, tmp0_other_with_cast.d10_1))
      return false;
    if (!equals(this.e10_1, tmp0_other_with_cast.e10_1))
      return false;
    if (!equals(this.f10_1, tmp0_other_with_cast.f10_1))
      return false;
    if (!equals(this.g10_1, tmp0_other_with_cast.g10_1))
      return false;
    return true;
  }
}
class ChildContinuation extends JobNode {
  constructor(child) {
    super();
    this.p11_1 = child;
  }
  fx() {
    return true;
  }
  cx(cause) {
    this.p11_1.r10(this.p11_1.t10(this.nx()));
  }
}
class CompletableDeferredImpl extends JobSupport {
  constructor(parent) {
    super(true);
    this.gu(parent);
  }
  tv() {
    return true;
  }
  gx() {
    var tmp = this.kw();
    return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  }
  ow($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_await__mos7q6_0.bind(VOID, this), $completion);
  }
  s11(value) {
    return this.cw(value);
  }
  t11(exception) {
    return this.cw(new CompletedExceptionally(exception));
  }
}
class CompletableJob {}
class CompletedExceptionally {
  constructor(cause, handled) {
    handled = handled === VOID ? false : handled;
    this.qu_1 = cause;
    this.ru_1 = atomic$boolean$1(handled);
  }
  su() {
    return this.ru_1.kotlinx$atomicfu$value;
  }
  k10() {
    return this.ru_1.atomicfu$compareAndSet(false, true);
  }
  toString() {
    return get_classSimpleName(this) + '[' + this.qu_1.toString() + ']';
  }
}
class CancelledContinuation extends CompletedExceptionally {
  constructor(continuation, cause, handled) {
    super(cause == null ? CancellationException.nd('Continuation ' + toString(continuation) + ' was cancelled normally') : cause, handled);
    this.d11_1 = atomic$boolean$1(false);
  }
  e11() {
    return this.d11_1.atomicfu$compareAndSet(false, true);
  }
}
class Key extends AbstractCoroutineContextKey {
  constructor() {
    Key_instance_0 = null;
    var tmp = Key_instance;
    super(tmp, CoroutineDispatcher$Key$_init_$lambda_akl8b5);
    Key_instance_0 = this;
  }
}
class CoroutineDispatcher extends AbstractCoroutineContextElement {
  constructor() {
    Key_getInstance();
    super(Key_instance);
  }
  w11(context) {
    return true;
  }
  zc(continuation) {
    return new DispatchedContinuation(this, continuation);
  }
  ad(continuation) {
    var dispatched = continuation instanceof DispatchedContinuation ? continuation : THROW_CCE();
    dispatched.y11();
  }
  toString() {
    return get_classSimpleName(this) + '@' + get_hexAddress(this);
  }
}
class Key_0 {}
class Key_1 {}
class CoroutineName extends AbstractCoroutineContextElement {
  constructor(name) {
    super(Key_instance_2);
    this.e12_1 = name;
  }
  toString() {
    return 'CoroutineName(' + this.e12_1 + ')';
  }
  hashCode() {
    return getStringHashCode(this.e12_1);
  }
  equals(other) {
    if (this === other)
      return true;
    if (!(other instanceof CoroutineName))
      return false;
    var tmp0_other_with_cast = other instanceof CoroutineName ? other : THROW_CCE();
    if (!(this.e12_1 === tmp0_other_with_cast.e12_1))
      return false;
    return true;
  }
}
class GlobalScope {
  ku() {
    return EmptyCoroutineContext_getInstance();
  }
}
class CoroutineStart extends Enum {
  bv(block, receiver, completion) {
    var tmp;
    switch (this.o3_1) {
      case 0:
        startCoroutineCancellable(block, receiver, completion);
        tmp = Unit_instance;
        break;
      case 2:
        startCoroutine(block, receiver, completion);
        tmp = Unit_instance;
        break;
      case 3:
        startCoroutineUndispatched(block, receiver, completion);
        tmp = Unit_instance;
        break;
      case 1:
        tmp = Unit_instance;
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
    return tmp;
  }
  dy() {
    return this === CoroutineStart_LAZY_getInstance();
  }
}
class CopyableThrowable {}
class Delay {}
function invokeOnTimeout(timeMillis, block, context) {
  return get_DefaultDelay().h12(timeMillis, block, context);
}
class DelayWithTimeoutDiagnostics {}
class EventLoop extends CoroutineDispatcher {
  constructor() {
    super();
    this.k12_1 = new Long(0, 0);
    this.l12_1 = false;
    this.m12_1 = null;
  }
  n12() {
    var tmp0_elvis_lhs = this.m12_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return false;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var queue = tmp;
    var tmp1_elvis_lhs = queue.xk();
    var tmp_0;
    if (tmp1_elvis_lhs == null) {
      return false;
    } else {
      tmp_0 = tmp1_elvis_lhs;
    }
    var task = tmp_0;
    task.h11();
    return true;
  }
  o12(task) {
    var tmp0_elvis_lhs = this.m12_1;
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_0 = ArrayDeque.rk();
      this.m12_1 = this_0;
      tmp = this_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    var queue = tmp;
    queue.vk(task);
  }
  p12() {
    return this.k12_1.s1(delta(this, true)) >= 0;
  }
  q12() {
    var tmp0_safe_receiver = this.m12_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.h1();
    return tmp1_elvis_lhs == null ? true : tmp1_elvis_lhs;
  }
  r12(unconfined) {
    this.k12_1 = this.k12_1.u3(delta(this, unconfined));
    if (!unconfined)
      this.l12_1 = true;
  }
  s12(unconfined) {
    this.k12_1 = this.k12_1.v3(delta(this, unconfined));
    if (this.k12_1.s1(new Long(0, 0)) > 0)
      return Unit_instance;
    // Inline function 'kotlinx.coroutines.assert' call
    if (this.l12_1) {
      this.t12();
    }
  }
  t12() {
  }
}
class ThreadLocalEventLoop {
  constructor() {
    ThreadLocalEventLoop_instance = this;
    this.u12_1 = commonThreadLocal(new Symbol('ThreadLocalEventLoop'));
  }
  v12() {
    var tmp0_elvis_lhs = this.u12_1.x12();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      // Inline function 'kotlin.also' call
      var this_0 = createEventLoop();
      ThreadLocalEventLoop_getInstance().u12_1.y12(this_0);
      tmp = this_0;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    return tmp;
  }
}
class CompletionHandlerException extends RuntimeException {
  static b10(message, cause) {
    var $this = this.be(message, cause);
    captureStack($this, $this.a10_1);
    return $this;
  }
}
class CoroutinesInternalError extends Error_0 {
  static b13(message, cause) {
    var $this = this.he(message, cause);
    captureStack($this, $this.a13_1);
    return $this;
  }
}
class Key_2 {}
class NonDisposableHandle {
  ev() {
    return null;
  }
  bx() {
  }
  yv(cause) {
    return false;
  }
  toString() {
    return 'NonDisposableHandle';
  }
}
class DisposeOnCompletion extends JobNode {
  constructor(handle) {
    super();
    this.g13_1 = handle;
  }
  fx() {
    return false;
  }
  cx(cause) {
    return this.g13_1.bx();
  }
}
class Empty {
  constructor(isActive) {
    this.h13_1 = isActive;
  }
  lu() {
    return this.h13_1;
  }
  ox() {
    return null;
  }
  toString() {
    return 'Empty{' + (this.h13_1 ? 'Active' : 'New') + '}';
  }
}
class LockFreeLinkedListHead extends LockFreeLinkedListNode {}
class NodeList extends LockFreeLinkedListHead {
  lu() {
    return true;
  }
  ox() {
    return this;
  }
  l13(state) {
    // Inline function 'kotlin.text.buildString' call
    // Inline function 'kotlin.apply' call
    var this_0 = StringBuilder.v();
    this_0.tb('List{');
    this_0.tb(state);
    this_0.tb('}[');
    var first = true;
    // Inline function 'kotlinx.coroutines.internal.LockFreeLinkedListHead.forEach' call
    var cur = this.px_1;
    while (!equals(cur, this)) {
      var node = cur;
      if (node instanceof JobNode) {
        if (first) {
          first = false;
        } else
          this_0.tb(', ');
        this_0.sb(node);
      }
      cur = cur.px_1;
    }
    this_0.tb(']');
    return this_0.toString();
  }
  toString() {
    return get_DEBUG() ? this.l13('Active') : super.toString();
  }
}
class SynchronizedObject {}
class Finishing extends SynchronizedObject {
  constructor(list, isCompleting, rootCause) {
    super();
    this.n13_1 = list;
    this.o13_1 = atomic$boolean$1(isCompleting);
    this.p13_1 = atomic$ref$1(rootCause);
    this.q13_1 = atomic$ref$1(null);
  }
  ox() {
    return this.n13_1;
  }
  f14(value) {
    this.o13_1.kotlinx$atomicfu$value = value;
  }
  b14() {
    return this.o13_1.kotlinx$atomicfu$value;
  }
  l14(value) {
    this.p13_1.kotlinx$atomicfu$value = value;
  }
  e14() {
    return this.p13_1.kotlinx$atomicfu$value;
  }
  c14() {
    return _get_exceptionsHolder__nhszp(this) === get_SEALED();
  }
  r13() {
    return !(this.e14() == null);
  }
  lu() {
    return this.e14() == null;
  }
  s13(proposedException) {
    var eh = _get_exceptionsHolder__nhszp(this);
    var tmp;
    if (eh == null) {
      tmp = allocateList(this);
    } else {
      if (eh instanceof Error) {
        // Inline function 'kotlin.also' call
        var this_0 = allocateList(this);
        this_0.l(eh);
        tmp = this_0;
      } else {
        if (eh instanceof ArrayList) {
          tmp = eh instanceof ArrayList ? eh : THROW_CCE();
        } else {
          var message = 'State is ' + toString_0(eh);
          throw IllegalStateException.t4(toString(message));
        }
      }
    }
    var list = tmp;
    var rootCause = this.e14();
    if (rootCause == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      list.d3(0, rootCause);
    }
    if (!(proposedException == null) && !equals(proposedException, rootCause)) {
      list.l(proposedException);
    }
    _set_exceptionsHolder__tqm22h(this, get_SEALED());
    return list;
  }
  d14(exception) {
    var rootCause = this.e14();
    if (rootCause == null) {
      this.l14(exception);
      return Unit_instance;
    }
    if (exception === rootCause)
      return Unit_instance;
    var eh = _get_exceptionsHolder__nhszp(this);
    if (eh == null) {
      _set_exceptionsHolder__tqm22h(this, exception);
    } else {
      if (eh instanceof Error) {
        if (exception === eh)
          return Unit_instance;
        // Inline function 'kotlin.apply' call
        var this_0 = allocateList(this);
        this_0.l(eh);
        this_0.l(exception);
        _set_exceptionsHolder__tqm22h(this, this_0);
      } else {
        if (eh instanceof ArrayList) {
          (eh instanceof ArrayList ? eh : THROW_CCE()).l(exception);
        } else {
          // Inline function 'kotlin.error' call
          var message = 'State is ' + toString_0(eh);
          throw IllegalStateException.t4(toString(message));
        }
      }
    }
  }
  toString() {
    return 'Finishing[cancelling=' + this.r13() + ', completing=' + this.b14() + ', rootCause=' + toString_0(this.e14()) + ', exceptions=' + toString_0(_get_exceptionsHolder__nhszp(this)) + ', list=' + this.n13_1.toString() + ']';
  }
}
class ChildCompletion extends JobNode {
  constructor(parent, state, child, proposedUpdate) {
    super();
    this.q14_1 = parent;
    this.r14_1 = state;
    this.s14_1 = child;
    this.t14_1 = proposedUpdate;
  }
  fx() {
    return false;
  }
  cx(cause) {
    continueCompleting(this.q14_1, this.r14_1, this.s14_1, this.t14_1);
  }
}
class AwaitContinuation extends CancellableContinuationImpl {
  constructor(delegate, job) {
    super(delegate, 1);
    this.a15_1 = job;
  }
  t10(parent) {
    var state = this.a15_1.fv();
    if (state instanceof Finishing) {
      var tmp0_safe_receiver = state.e14();
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        return tmp0_safe_receiver;
      }
    }
    if (state instanceof CompletedExceptionally)
      return state.qu_1;
    return parent.kv();
  }
  g11() {
    return 'AwaitContinuation';
  }
}
class InactiveNodeList {
  constructor(list) {
    this.a14_1 = list;
  }
  ox() {
    return this.a14_1;
  }
  lu() {
    return false;
  }
  toString() {
    return get_DEBUG() ? this.a14_1.l13('New') : anyToString(this);
  }
}
class InvokeOnCompletion extends JobNode {
  constructor(handler) {
    super();
    this.f15_1 = handler;
  }
  fx() {
    return false;
  }
  cx(cause) {
    return this.f15_1(cause);
  }
}
class InvokeOnCancelling extends JobNode {
  constructor(handler) {
    super();
    this.k15_1 = handler;
    this.l15_1 = atomic$boolean$1(false);
  }
  fx() {
    return true;
  }
  cx(cause) {
    if (this.l15_1.atomicfu$compareAndSet(false, true))
      this.k15_1(cause);
  }
}
class ResumeOnCompletion extends JobNode {
  constructor(continuation) {
    super();
    this.q15_1 = continuation;
  }
  fx() {
    return false;
  }
  cx(cause) {
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = this.q15_1;
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
    this_0.nc(tmp$ret$0);
    return Unit_instance;
  }
}
class ChildHandleNode extends JobNode {
  constructor(childJob) {
    super();
    this.k14_1 = childJob;
  }
  ev() {
    return this.nx();
  }
  fx() {
    return true;
  }
  cx(cause) {
    return this.k14_1.xv(this.nx());
  }
  yv(cause) {
    return this.nx().yv(cause);
  }
}
class ResumeAwaitOnCompletion extends JobNode {
  constructor(continuation) {
    super();
    this.w15_1 = continuation;
  }
  fx() {
    return false;
  }
  cx(cause) {
    var state = this.nx().fv();
    // Inline function 'kotlinx.coroutines.assert' call
    if (state instanceof CompletedExceptionally) {
      var tmp0 = this.w15_1;
      // Inline function 'kotlin.coroutines.resumeWithException' call
      // Inline function 'kotlin.Companion.failure' call
      var exception = state.qu_1;
      var tmp$ret$1 = _Result___init__impl__xyqfz8(createFailure(exception));
      tmp0.nc(tmp$ret$1);
    } else {
      var tmp2 = this.w15_1;
      var tmp = unboxState(state);
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var value = (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
      var tmp$ret$3 = _Result___init__impl__xyqfz8(value);
      tmp2.nc(tmp$ret$3);
    }
  }
}
class IncompleteStateBox {
  constructor(state) {
    this.r15_1 = state;
  }
}
class JobImpl extends JobSupport {
  constructor(parent) {
    super(true);
    this.gu(parent);
    this.z15_1 = handlesExceptionF(this);
  }
  tv() {
    return true;
  }
  gw() {
    return this.z15_1;
  }
  u11() {
    return this.cw(Unit_instance);
  }
  t11(exception) {
    return this.cw(new CompletedExceptionally(exception));
  }
}
class MainCoroutineDispatcher extends CoroutineDispatcher {
  toString() {
    var tmp0_elvis_lhs = this.c16();
    return tmp0_elvis_lhs == null ? get_classSimpleName(this) + '@' + get_hexAddress(this) : tmp0_elvis_lhs;
  }
  c16() {
    var main = Dispatchers_getInstance().h16();
    if (this === main)
      return 'Dispatchers.Main';
    var tmp;
    try {
      tmp = main.b16();
    } catch ($p) {
      var tmp_0;
      if ($p instanceof UnsupportedOperationException) {
        var e = $p;
        tmp_0 = null;
      } else {
        throw $p;
      }
      tmp = tmp_0;
    }
    var immediate = tmp;
    if (this === immediate)
      return 'Dispatchers.Main.immediate';
    return null;
  }
}
class NonCancellable extends AbstractCoroutineContextElement {
  constructor() {
    NonCancellable_instance = null;
    super(Key_instance_3);
    NonCancellable_instance = this;
    this.j16_1 = "NonCancellable can be used only as an argument for 'withContext', direct usages of its API are prohibited";
  }
  lu() {
    return true;
  }
  hv() {
    return false;
  }
  iv() {
    return false;
  }
  rv($completion) {
    throw UnsupportedOperationException.da('This job is always active');
  }
  kv() {
    throw IllegalStateException.t4('This job is always active');
  }
  nv(handler) {
    return NonDisposableHandle_instance;
  }
  ov(onCancelling, invokeImmediately, handler) {
    return NonDisposableHandle_instance;
  }
  uv(cause) {
  }
  dw(child) {
    return NonDisposableHandle_instance;
  }
  toString() {
    return 'NonCancellable';
  }
}
class SupervisorJobImpl extends JobImpl {
  yv(cause) {
    return false;
  }
}
class TimeoutCancellationException extends CancellationException {
  static t16(message, coroutine) {
    var $this = this.nd(message);
    captureStack($this, $this.s16_1);
    $this.r16_1 = coroutine;
    return $this;
  }
  static u16(message) {
    return this.t16(message, null);
  }
  f12() {
    var tmp0_elvis_lhs = this.message;
    // Inline function 'kotlin.also' call
    var this_0 = TimeoutCancellationException.t16(tmp0_elvis_lhs == null ? '' : tmp0_elvis_lhs, this.r16_1);
    initCause(this_0, this);
    return this_0;
  }
}
class TimeoutCoroutine extends ScopeCoroutine {
  constructor(time, uCont) {
    super(uCont.lc(), uCont);
    this.z16_1 = time;
  }
  h11() {
    this.zv(TimeoutCancellationException_0(this.z16_1, get_delay(this.ju_1), this));
  }
  xu() {
    return super.xu() + '(timeMillis=' + this.z16_1.toString() + ')';
  }
}
class Unconfined extends CoroutineDispatcher {
  constructor() {
    Unconfined_instance = null;
    super();
    Unconfined_instance = this;
  }
  w11(context) {
    return false;
  }
  x11(context, block) {
    var yieldContext = context.yc(Key_instance_4);
    if (!(yieldContext == null)) {
      yieldContext.c17_1 = true;
      return Unit_instance;
    }
    throw UnsupportedOperationException.da('Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls.');
  }
  toString() {
    return 'Dispatchers.Unconfined';
  }
}
class Key_3 {}
class BufferOverflow extends Enum {}
class ConcurrentLinkedListNode {
  constructor(prev) {
    this.l18_1 = atomic$ref$1(null);
    this.m18_1 = atomic$ref$1(prev);
  }
  n18() {
    // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.nextOrIfClosed' call
    // Inline function 'kotlin.let' call
    var it = access$_get_nextOrClosed__ywzond(this);
    var tmp;
    if (it === access$_get_CLOSED_$tConcurrentLinkedListKt_wmtpdy()) {
      return null;
    } else {
      tmp = (it == null ? true : it instanceof ConcurrentLinkedListNode) ? it : THROW_CCE();
    }
    return tmp;
  }
  o18(value) {
    return this.l18_1.atomicfu$compareAndSet(null, value);
  }
  p18() {
    return this.n18() == null;
  }
  q18() {
    return this.m18_1.kotlinx$atomicfu$value;
  }
  r18() {
    // Inline function 'kotlinx.atomicfu.AtomicRef.lazySet' call
    this.m18_1.kotlinx$atomicfu$value = null;
  }
  s18() {
    return this.l18_1.atomicfu$compareAndSet(null, get_CLOSED());
  }
  e6() {
    // Inline function 'kotlinx.coroutines.assert' call
    if (this.p18())
      return Unit_instance;
    $l$loop_0: while (true) {
      var prev = _get_aliveSegmentLeft__mr4ndu(this);
      var next = _get_aliveSegmentRight__7ulr0b(this);
      var tmp0 = next.m18_1;
      $l$block: {
        // Inline function 'kotlinx.atomicfu.update' call
        while (true) {
          var cur = tmp0.kotlinx$atomicfu$value;
          var upd = cur === null ? null : prev;
          if (tmp0.atomicfu$compareAndSet(cur, upd)) {
            break $l$block;
          }
        }
      }
      if (!(prev === null))
        prev.l18_1.kotlinx$atomicfu$value = next;
      if (next.i18() && !next.p18())
        continue $l$loop_0;
      if (!(prev === null) && prev.i18())
        continue $l$loop_0;
      return Unit_instance;
    }
  }
}
class Segment extends ConcurrentLinkedListNode {
  constructor(id, prev, pointers) {
    super(prev);
    this.vz_1 = id;
    this.wz_1 = atomic$int$1(pointers << 16);
  }
  i18() {
    return this.wz_1.kotlinx$atomicfu$value === this.k17() && !this.p18();
  }
  j18() {
    var tmp0 = this.wz_1;
    var tmp$ret$1;
    $l$block_0: {
      // Inline function 'kotlinx.coroutines.internal.addConditionally' call
      while (true) {
        var cur = tmp0.kotlinx$atomicfu$value;
        if (!(!(cur === this.k17()) || this.p18())) {
          tmp$ret$1 = false;
          break $l$block_0;
        }
        if (tmp0.atomicfu$compareAndSet(cur, cur + 65536 | 0)) {
          tmp$ret$1 = true;
          break $l$block_0;
        }
      }
    }
    return tmp$ret$1;
  }
  k18() {
    return this.wz_1.atomicfu$addAndGet(-65536) === this.k17() && !this.p18();
  }
  h18() {
    if (this.wz_1.atomicfu$incrementAndGet() === this.k17()) {
      this.e6();
    }
  }
}
class ChannelSegment extends Segment {
  constructor(id, prev, channel, pointers) {
    super(id, prev, pointers);
    this.h17_1 = channel;
    this.i17_1 = atomicfu$AtomicRefArray$ofNulls(imul(get_SEGMENT_SIZE(), 2));
  }
  j17() {
    return ensureNotNull(this.h17_1);
  }
  k17() {
    return get_SEGMENT_SIZE();
  }
  l17(index, element) {
    setElementLazy(this, index, element);
  }
  m17(index) {
    var tmp = this.i17_1.atomicfu$get(imul(index, 2)).kotlinx$atomicfu$value;
    return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  }
  n17(index) {
    // Inline function 'kotlin.also' call
    var this_0 = this.m17(index);
    this.o17(index);
    return this_0;
  }
  o17(index) {
    setElementLazy(this, index, null);
  }
  p17(index) {
    return this.i17_1.atomicfu$get(imul(index, 2) + 1 | 0).kotlinx$atomicfu$value;
  }
  q17(index, value) {
    this.i17_1.atomicfu$get(imul(index, 2) + 1 | 0).kotlinx$atomicfu$value = value;
  }
  r17(index, from, to) {
    return this.i17_1.atomicfu$get(imul(index, 2) + 1 | 0).atomicfu$compareAndSet(from, to);
  }
  s17(index, update) {
    return this.i17_1.atomicfu$get(imul(index, 2) + 1 | 0).atomicfu$getAndSet(update);
  }
  xz(index, cause, context) {
    var isSender = index >= get_SEGMENT_SIZE();
    var index_0 = isSender ? index - get_SEGMENT_SIZE() | 0 : index;
    var element = this.m17(index_0);
    $l$loop: while (true) {
      var cur = this.p17(index_0);
      var tmp;
      if (!(cur == null) ? isInterface(cur, Waiter) : false) {
        tmp = true;
      } else {
        tmp = cur instanceof WaiterEB;
      }
      if (tmp) {
        var update = isSender ? get_INTERRUPTED_SEND() : get_INTERRUPTED_RCV();
        if (this.r17(index_0, cur, update)) {
          this.o17(index_0);
          this.f18(index_0, !isSender);
          if (isSender) {
            var tmp0_safe_receiver = this.j17().u17_1;
            if (tmp0_safe_receiver == null)
              null;
            else {
              callUndeliveredElement(tmp0_safe_receiver, element, context);
            }
          }
          return Unit_instance;
        }
      } else {
        if (cur === get_INTERRUPTED_SEND() || cur === get_INTERRUPTED_RCV()) {
          this.o17(index_0);
          if (isSender) {
            var tmp1_safe_receiver = this.j17().u17_1;
            if (tmp1_safe_receiver == null)
              null;
            else {
              callUndeliveredElement(tmp1_safe_receiver, element, context);
            }
          }
          return Unit_instance;
        } else {
          if (cur === get_RESUMING_BY_EB() || cur === get_RESUMING_BY_RCV())
            continue $l$loop;
          else {
            if (cur === get_DONE_RCV() || cur === get_BUFFERED())
              return Unit_instance;
            else {
              if (cur === get_CHANNEL_CLOSED())
                return Unit_instance;
              else {
                // Inline function 'kotlin.error' call
                var message = 'unexpected state: ' + toString_0(cur);
                throw IllegalStateException.t4(toString(message));
              }
            }
          }
        }
      }
    }
  }
  f18(index, receiver) {
    if (receiver) {
      var tmp = this.j17();
      var tmp0 = this.vz_1;
      // Inline function 'kotlin.Long.times' call
      var other = get_SEGMENT_SIZE();
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$1 = tmp0.w3(toLong(other)).u3(toLong(index));
      tmp.g18(tmp$ret$1);
    }
    this.h18();
  }
}
class SendBroadcast {}
class BufferedChannelIterator {
  constructor($outer) {
    this.v18_1 = $outer;
    this.t18_1 = get_NO_RECEIVE_RESULT();
    this.u18_1 = null;
  }
  o19($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_hasNext__q471nr.bind(VOID, this), $completion);
  }
  a11(segment, index) {
    var tmp0_safe_receiver = this.u18_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.a11(segment, index);
    }
  }
  a1() {
    var result = this.t18_1;
    // Inline function 'kotlin.check' call
    if (!!(result === get_NO_RECEIVE_RESULT())) {
      var message = '`hasNext()` has not been invoked';
      throw IllegalStateException.t4(toString(message));
    }
    this.t18_1 = get_NO_RECEIVE_RESULT();
    if (result === get_CHANNEL_CLOSED())
      throw recoverStackTrace_0(_get_receiveException__foorc1(this.v18_1));
    return (result == null ? true : !(result == null)) ? result : THROW_CCE();
  }
  d19(element) {
    var cont = ensureNotNull(this.u18_1);
    this.u18_1 = null;
    this.t18_1 = element;
    var tmp0_safe_receiver = this.v18_1.u17_1;
    return tryResume0(cont, true, tmp0_safe_receiver == null ? null : bindCancellationFun(this.v18_1, tmp0_safe_receiver, element));
  }
  p19() {
    var cont = ensureNotNull(this.u18_1);
    this.u18_1 = null;
    this.t18_1 = get_CHANNEL_CLOSED();
    var cause = this.v18_1.y18();
    if (cause == null) {
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var tmp$ret$0 = _Result___init__impl__xyqfz8(false);
      cont.nc(tmp$ret$0);
    } else {
      // Inline function 'kotlin.coroutines.resumeWithException' call
      // Inline function 'kotlin.Companion.failure' call
      var exception = recoverStackTrace(cause, cont);
      var tmp$ret$2 = _Result___init__impl__xyqfz8(createFailure(exception));
      cont.nc(tmp$ret$2);
    }
  }
}
class SendChannel {}
function close$default(cause, $super) {
  cause = cause === VOID ? null : cause;
  return $super === VOID ? this.n1a(cause) : $super.n1a.call(this, cause);
}
class ReceiveChannel {}
function cancel$default_0(cause, $super) {
  cause = cause === VOID ? null : cause;
  var tmp;
  if ($super === VOID) {
    this.uv(cause);
    tmp = Unit_instance;
  } else {
    tmp = $super.uv.call(this, cause);
  }
  return tmp;
}
class BufferedChannel {
  constructor(capacity, onUndeliveredElement) {
    onUndeliveredElement = onUndeliveredElement === VOID ? null : onUndeliveredElement;
    this.t17_1 = capacity;
    this.u17_1 = onUndeliveredElement;
    // Inline function 'kotlin.require' call
    if (!(this.t17_1 >= 0)) {
      var message = 'Invalid channel capacity: ' + this.t17_1 + ', should be >=0';
      throw IllegalArgumentException.t(toString(message));
    }
    this.v17_1 = atomic$long$1(new Long(0, 0));
    this.w17_1 = atomic$long$1(new Long(0, 0));
    this.x17_1 = atomic$long$1(initialBufferEnd(this.t17_1));
    this.y17_1 = atomic$long$1(_get_bufferEndCounter__2d4hee(this));
    var firstSegment = new ChannelSegment(new Long(0, 0), null, this, 3);
    this.z17_1 = atomic$ref$1(firstSegment);
    this.a18_1 = atomic$ref$1(firstSegment);
    var tmp = this;
    var tmp_0;
    if (_get_isRendezvousOrUnlimited__3mdufi(this)) {
      var tmp_1 = get_NULL_SEGMENT();
      tmp_0 = tmp_1 instanceof ChannelSegment ? tmp_1 : THROW_CCE();
    } else {
      tmp_0 = firstSegment;
    }
    tmp.b18_1 = atomic$ref$1(tmp_0);
    var tmp_2 = this;
    var tmp_3;
    if (this.u17_1 == null) {
      tmp_3 = null;
    } else {
      // Inline function 'kotlin.let' call
      tmp_3 = BufferedChannel$onUndeliveredElementReceiveCancellationConstructor$lambda(this);
    }
    tmp_2.c18_1 = tmp_3;
    this.d18_1 = atomic$ref$1(get_NO_CLOSE_CAUSE());
    this.e18_1 = atomic$ref$1(null);
  }
  x18() {
    // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
    return this.v17_1.kotlinx$atomicfu$value.h4(new Long(-1, 268435455));
  }
  z18() {
    return this.w17_1.kotlinx$atomicfu$value;
  }
  c1a(element, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_send__qhx0g0.bind(VOID, this, element), $completion);
  }
  d1a(element) {
    if (shouldSendSuspend0(this, this.v17_1.kotlinx$atomicfu$value))
      return Companion_getInstance_0().e1a();
    var tmp2 = get_INTERRUPTED_SEND();
    var tmp$ret$4;
    $l$block_4: {
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.sendImpl' call
      var segment = this.z17_1.kotlinx$atomicfu$value;
      $l$loop_0: while (true) {
        var sendersAndCloseStatusCur = this.v17_1.atomicfu$getAndIncrement$long();
        // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
        var s = sendersAndCloseStatusCur.h4(new Long(-1, 268435455));
        var closed = _get_isClosedForSend0__kxgf9m(this, sendersAndCloseStatusCur);
        // Inline function 'kotlin.Long.div' call
        var other = get_SEGMENT_SIZE();
        var id = s.x3(toLong(other));
        // Inline function 'kotlin.Long.rem' call
        var other_0 = get_SEGMENT_SIZE();
        var i = s.y3(toLong(other_0)).x1();
        if (!segment.vz_1.equals(id)) {
          var tmp0_elvis_lhs = findSegmentSend(this, id, segment);
          var tmp;
          if (tmp0_elvis_lhs == null) {
            var tmp_0;
            if (closed) {
              tmp$ret$4 = Companion_getInstance_0().y19(this.a19());
              break $l$block_4;
            } else {
              continue $l$loop_0;
            }
          } else {
            tmp = tmp0_elvis_lhs;
          }
          segment = tmp;
        }
        switch (updateCellSend(this, segment, i, element, s, tmp2, closed)) {
          case 0:
            segment.r18();
            tmp$ret$4 = Companion_getInstance_0().f19(Unit_instance);
            break $l$block_4;
          case 1:
            tmp$ret$4 = Companion_getInstance_0().f19(Unit_instance);
            break $l$block_4;
          case 2:
            if (closed) {
              segment.h18();
              tmp$ret$4 = Companion_getInstance_0().y19(this.a19());
              break $l$block_4;
            }

            var tmp2_safe_receiver = (!(tmp2 == null) ? isInterface(tmp2, Waiter) : false) ? tmp2 : null;
            if (tmp2_safe_receiver == null)
              null;
            else {
              prepareSenderForSuspension(this, tmp2_safe_receiver, segment, i);
            }

            segment.h18();
            tmp$ret$4 = Companion_getInstance_0().e1a();
            break $l$block_4;
          case 4:
            if (s.s1(this.z18()) < 0) {
              segment.r18();
            }

            tmp$ret$4 = Companion_getInstance_0().y19(this.a19());
            break $l$block_4;
          case 5:
            segment.r18();
            continue $l$loop_0;
          case 3:
            var message = 'unexpected';
            throw IllegalStateException.t4(toString(message));
        }
      }
    }
    return tmp$ret$4;
  }
  f1a(element) {
    var tmp$ret$3;
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.sendImpl' call
    var waiter = get_BUFFERED();
    var segment = this.z17_1.kotlinx$atomicfu$value;
    $l$loop_0: while (true) {
      var sendersAndCloseStatusCur = this.v17_1.atomicfu$getAndIncrement$long();
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
      var s = sendersAndCloseStatusCur.h4(new Long(-1, 268435455));
      var closed = _get_isClosedForSend0__kxgf9m(this, sendersAndCloseStatusCur);
      // Inline function 'kotlin.Long.div' call
      var other = get_SEGMENT_SIZE();
      var id = s.x3(toLong(other));
      // Inline function 'kotlin.Long.rem' call
      var other_0 = get_SEGMENT_SIZE();
      var i = s.y3(toLong(other_0)).x1();
      if (!segment.vz_1.equals(id)) {
        var tmp0_elvis_lhs = findSegmentSend(this, id, segment);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          var tmp_0;
          if (closed) {
            return Companion_getInstance_0().y19(this.a19());
          } else {
            continue $l$loop_0;
          }
        } else {
          tmp = tmp0_elvis_lhs;
        }
        segment = tmp;
      }
      switch (updateCellSend(this, segment, i, element, s, waiter, closed)) {
        case 0:
          segment.r18();
          return Companion_getInstance_0().f19(Unit_instance);
        case 1:
          return Companion_getInstance_0().f19(Unit_instance);
        case 2:
          if (closed) {
            segment.h18();
            return Companion_getInstance_0().y19(this.a19());
          }

          var tmp2_safe_receiver = (!(waiter == null) ? isInterface(waiter, Waiter) : false) ? waiter : null;
          if (tmp2_safe_receiver == null)
            null;
          else {
            prepareSenderForSuspension(this, tmp2_safe_receiver, segment, i);
          }

          var tmp4 = segment.vz_1;
          // Inline function 'kotlin.Long.times' call

          var other_1 = get_SEGMENT_SIZE();
          // Inline function 'kotlin.Long.plus' call

          var tmp$ret$5 = tmp4.w3(toLong(other_1)).u3(toLong(i));
          this.w19(tmp$ret$5);
          return Companion_getInstance_0().f19(Unit_instance);
        case 4:
          if (s.s1(this.z18()) < 0) {
            segment.r18();
          }

          return Companion_getInstance_0().y19(this.a19());
        case 5:
          segment.r18();
          continue $l$loop_0;
        case 3:
          var message = 'unexpected';
          throw IllegalStateException.t4(toString(message));
      }
    }
    return tmp$ret$3;
  }
  i19() {
  }
  b19() {
  }
  g1a($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_receive__aoggq9.bind(VOID, this), $completion);
  }
  w19(globalCellIndex) {
    // Inline function 'kotlinx.coroutines.assert' call
    var segment = this.a18_1.kotlinx$atomicfu$value;
    $l$loop_0: while (true) {
      var r = this.w17_1.kotlinx$atomicfu$value;
      // Inline function 'kotlin.Long.plus' call
      var other = this.t17_1;
      var tmp2 = r.u3(toLong(other));
      // Inline function 'kotlin.math.max' call
      var b = _get_bufferEndCounter__2d4hee(this);
      var tmp$ret$2 = tmp2.s1(b) >= 0 ? tmp2 : b;
      if (globalCellIndex.s1(tmp$ret$2) < 0)
        return Unit_instance;
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$3 = r.u3(toLong(1));
      if (!this.w17_1.atomicfu$compareAndSet(r, tmp$ret$3))
        continue $l$loop_0;
      // Inline function 'kotlin.Long.div' call
      var other_0 = get_SEGMENT_SIZE();
      var id = r.x3(toLong(other_0));
      // Inline function 'kotlin.Long.rem' call
      var other_1 = get_SEGMENT_SIZE();
      var i = r.y3(toLong(other_1)).x1();
      if (!segment.vz_1.equals(id)) {
        var tmp0_elvis_lhs = findSegmentReceive(this, id, segment);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          continue $l$loop_0;
        } else {
          tmp = tmp0_elvis_lhs;
        }
        segment = tmp;
      }
      var updCellResult = updateCellReceive(this, segment, i, r, null);
      if (updCellResult === get_FAILED()) {
        if (r.s1(this.x18()) < 0) {
          segment.r18();
        }
      } else {
        segment.r18();
        var tmp1_safe_receiver = this.u17_1;
        var tmp_0;
        if (tmp1_safe_receiver == null) {
          tmp_0 = null;
        } else {
          tmp_0 = callUndeliveredElementCatchingException(tmp1_safe_receiver, (updCellResult == null ? true : !(updCellResult == null)) ? updCellResult : THROW_CCE());
        }
        var tmp2_safe_receiver = tmp_0;
        if (tmp2_safe_receiver == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          throw tmp2_safe_receiver;
        }
      }
    }
  }
  g18(globalIndex) {
    if (_get_isRendezvousOrUnlimited__3mdufi(this))
      return Unit_instance;
    while (_get_bufferEndCounter__2d4hee(this).s1(globalIndex) <= 0) {
    }
    // Inline function 'kotlin.repeat' call
    var times = get_EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS();
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        var b = _get_bufferEndCounter__2d4hee(this);
        // Inline function 'kotlinx.coroutines.channels.ebCompletedCounter' call
        var ebCompleted = this.y17_1.kotlinx$atomicfu$value.h4(new Long(-1, 1073741823));
        if (b.equals(ebCompleted) && b.equals(_get_bufferEndCounter__2d4hee(this)))
          return Unit_instance;
      }
       while (inductionVariable < times);
    var tmp2 = this.y17_1;
    $l$block: {
      // Inline function 'kotlinx.atomicfu.update' call
      while (true) {
        var cur = tmp2.kotlinx$atomicfu$value;
        // Inline function 'kotlinx.coroutines.channels.ebCompletedCounter' call
        var tmp$ret$3 = cur.h4(new Long(-1, 1073741823));
        var upd = constructEBCompletedAndPauseFlag(tmp$ret$3, true);
        if (tmp2.atomicfu$compareAndSet(cur, upd)) {
          break $l$block;
        }
      }
    }
    while (true) {
      var b_0 = _get_bufferEndCounter__2d4hee(this);
      var ebCompletedAndBit = this.y17_1.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.channels.ebCompletedCounter' call
      var ebCompleted_0 = ebCompletedAndBit.h4(new Long(-1, 1073741823));
      // Inline function 'kotlinx.coroutines.channels.ebPauseExpandBuffers' call
      var pauseExpandBuffers = !ebCompletedAndBit.h4(new Long(0, 1073741824)).equals(new Long(0, 0));
      if (b_0.equals(ebCompleted_0) && b_0.equals(_get_bufferEndCounter__2d4hee(this))) {
        var tmp4 = this.y17_1;
        $l$block_0: {
          // Inline function 'kotlinx.atomicfu.update' call
          while (true) {
            var cur_0 = tmp4.kotlinx$atomicfu$value;
            // Inline function 'kotlinx.coroutines.channels.ebCompletedCounter' call
            var tmp$ret$8 = cur_0.h4(new Long(-1, 1073741823));
            var upd_0 = constructEBCompletedAndPauseFlag(tmp$ret$8, false);
            if (tmp4.atomicfu$compareAndSet(cur_0, upd_0)) {
              break $l$block_0;
            }
          }
        }
        return Unit_instance;
      }
      if (!pauseExpandBuffers) {
        this.y17_1.atomicfu$compareAndSet(ebCompletedAndBit, constructEBCompletedAndPauseFlag(ebCompleted_0, true));
      }
    }
  }
  y() {
    return new BufferedChannelIterator(this);
  }
  y18() {
    var tmp = this.d18_1.kotlinx$atomicfu$value;
    return (tmp == null ? true : tmp instanceof Error) ? tmp : THROW_CCE();
  }
  a19() {
    var tmp0_elvis_lhs = this.y18();
    return tmp0_elvis_lhs == null ? ClosedSendChannelException.l1a('Channel was closed') : tmp0_elvis_lhs;
  }
  m1a() {
  }
  n1a(cause) {
    return this.o1a(cause, false);
  }
  uv(cause) {
    this.q1a(cause);
  }
  q1a(cause) {
    return this.o1a(cause == null ? CancellationException.nd('Channel was cancelled') : cause, true);
  }
  o1a(cause, cancel) {
    if (cancel) {
      markCancellationStarted(this);
    }
    var closedByThisOperation = this.d18_1.atomicfu$compareAndSet(get_NO_CLOSE_CAUSE(), cause);
    if (cancel) {
      markCancelled(this);
    } else {
      markClosed(this);
    }
    completeCloseOrCancel(this);
    // Inline function 'kotlin.also' call
    this.m1a();
    if (closedByThisOperation) {
      invokeCloseHandler(this);
    }
    return closedByThisOperation;
  }
  x19() {
    return false;
  }
  v19() {
    return _get_isClosedForSend0__kxgf9m(this, this.v17_1.kotlinx$atomicfu$value);
  }
  w18() {
    return _get_isClosedForReceive0__f7qknl(this, this.v17_1.kotlinx$atomicfu$value);
  }
  z19() {
    $l$loop: while (true) {
      var segment = this.a18_1.kotlinx$atomicfu$value;
      var r = this.z18();
      var s = this.x18();
      if (s.s1(r) <= 0)
        return false;
      // Inline function 'kotlin.Long.div' call
      var other = get_SEGMENT_SIZE();
      var id = r.x3(toLong(other));
      if (!segment.vz_1.equals(id)) {
        var tmp0_elvis_lhs = findSegmentReceive(this, id, segment);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          var tmp_0;
          if (this.a18_1.kotlinx$atomicfu$value.vz_1.s1(id) < 0) {
            return false;
          } else {
            continue $l$loop;
          }
        } else {
          tmp = tmp0_elvis_lhs;
        }
        segment = tmp;
      }
      segment.r18();
      // Inline function 'kotlin.Long.rem' call
      var other_0 = get_SEGMENT_SIZE();
      var i = r.y3(toLong(other_0)).x1();
      if (isCellNonEmpty(this, segment, i, r))
        return true;
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$2 = r.u3(toLong(1));
      this.w17_1.atomicfu$compareAndSet(r, tmp$ret$2);
    }
  }
  toString() {
    var sb = StringBuilder.v();
    // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
    var tmp0_subject = this.v17_1.kotlinx$atomicfu$value.f4(60).x1();
    if (tmp0_subject === 2) {
      sb.tb('closed,');
    } else if (tmp0_subject === 3) {
      sb.tb('cancelled,');
    }
    sb.tb('capacity=' + this.t17_1 + ',');
    sb.tb('data=[');
    // Inline function 'kotlin.collections.filter' call
    var tmp0 = listOf([this.a18_1.kotlinx$atomicfu$value, this.z17_1.kotlinx$atomicfu$value, this.b18_1.kotlinx$atomicfu$value]);
    // Inline function 'kotlin.collections.filterTo' call
    var destination = ArrayList.k();
    var _iterator__ex2g4s = tmp0.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (!(element === get_NULL_SEGMENT())) {
        destination.l(element);
      }
    }
    var tmp$ret$4;
    $l$block: {
      // Inline function 'kotlin.collections.minBy' call
      var iterator = destination.y();
      if (!iterator.z())
        throw NoSuchElementException.i6();
      var minElem = iterator.a1();
      if (!iterator.z()) {
        tmp$ret$4 = minElem;
        break $l$block;
      }
      var minValue = minElem.vz_1;
      do {
        var e = iterator.a1();
        var v = e.vz_1;
        if (compareTo(minValue, v) > 0) {
          minElem = e;
          minValue = v;
        }
      }
       while (iterator.z());
      tmp$ret$4 = minElem;
    }
    var firstSegment = tmp$ret$4;
    var r = this.z18();
    var s = this.x18();
    var segment = firstSegment;
    append_elements: while (true) {
      var inductionVariable = 0;
      var last_0 = get_SEGMENT_SIZE();
      if (inductionVariable < last_0)
        process_cell: do {
          var i = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var tmp5 = segment.vz_1;
          // Inline function 'kotlin.Long.times' call
          var other = get_SEGMENT_SIZE();
          // Inline function 'kotlin.Long.plus' call
          var globalCellIndex = tmp5.w3(toLong(other)).u3(toLong(i));
          if (globalCellIndex.s1(s) >= 0 && globalCellIndex.s1(r) >= 0)
            break append_elements;
          var cellState = segment.p17(i);
          var element_0 = segment.m17(i);
          var tmp;
          if (!(cellState == null) ? isInterface(cellState, CancellableContinuation) : false) {
            tmp = globalCellIndex.s1(r) < 0 && globalCellIndex.s1(s) >= 0 ? 'receive' : globalCellIndex.s1(s) < 0 && globalCellIndex.s1(r) >= 0 ? 'send' : 'cont';
          } else {
            if (!(cellState == null) ? isInterface(cellState, SelectInstance) : false) {
              tmp = globalCellIndex.s1(r) < 0 && globalCellIndex.s1(s) >= 0 ? 'onReceive' : globalCellIndex.s1(s) < 0 && globalCellIndex.s1(r) >= 0 ? 'onSend' : 'select';
            } else {
              if (cellState instanceof ReceiveCatching) {
                tmp = 'receiveCatching';
              } else {
                if (cellState instanceof SendBroadcast) {
                  tmp = 'sendBroadcast';
                } else {
                  if (cellState instanceof WaiterEB) {
                    tmp = 'EB(' + cellState.toString() + ')';
                  } else {
                    if (equals(cellState, get_RESUMING_BY_RCV()) || equals(cellState, get_RESUMING_BY_EB())) {
                      tmp = 'resuming_sender';
                    } else {
                      if (cellState == null || (equals(cellState, get_IN_BUFFER()) || equals(cellState, get_DONE_RCV())) || (equals(cellState, get_POISONED()) || equals(cellState, get_INTERRUPTED_RCV()) || (equals(cellState, get_INTERRUPTED_SEND()) || equals(cellState, get_CHANNEL_CLOSED())))) {
                        continue process_cell;
                      } else {
                        tmp = toString(cellState);
                      }
                    }
                  }
                }
              }
            }
          }
          var cellStateString = tmp;
          if (!(element_0 == null)) {
            sb.tb('(' + cellStateString + ',' + toString_0(element_0) + '),');
          } else {
            sb.tb(cellStateString + ',');
          }
        }
         while (inductionVariable < last_0);
      var tmp2_elvis_lhs = segment.n18();
      var tmp_0;
      if (tmp2_elvis_lhs == null) {
        break append_elements;
      } else {
        tmp_0 = tmp2_elvis_lhs;
      }
      segment = tmp_0;
    }
    if (last(sb) === _Char___init__impl__6a9atx(44)) {
      sb.kh(sb.a() - 1 | 0);
    }
    sb.tb(']');
    return sb.toString();
  }
}
class WaiterEB {
  constructor(waiter) {
    this.c19_1 = waiter;
  }
  toString() {
    return 'WaiterEB(' + toString(this.c19_1) + ')';
  }
}
class ReceiveCatching {}
class Factory {
  constructor() {
    Factory_instance = this;
    this.s1a_1 = 2147483647;
    this.t1a_1 = 0;
    this.u1a_1 = -1;
    this.v1a_1 = -2;
    this.w1a_1 = -3;
    this.x1a_1 = 'kotlinx.coroutines.channels.defaultBuffer';
    this.y1a_1 = systemProp('kotlinx.coroutines.channels.defaultBuffer', 64, 1, 2147483646);
  }
}
class Failed {
  toString() {
    return 'Failed';
  }
}
class Closed extends Failed {
  constructor(cause) {
    super();
    this.z1a_1 = cause;
  }
  equals(other) {
    var tmp;
    if (other instanceof Closed) {
      tmp = equals(this.z1a_1, other.z1a_1);
    } else {
      tmp = false;
    }
    return tmp;
  }
  hashCode() {
    // Inline function 'kotlin.hashCode' call
    var tmp0_safe_receiver = this.z1a_1;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
    return tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs;
  }
  toString() {
    return 'Closed(' + toString_0(this.z1a_1) + ')';
  }
}
class Companion {
  constructor() {
    Companion_instance_0 = this;
    this.e19_1 = new Failed();
  }
  f19(value) {
    return _ChannelResult___init__impl__siwsuf(value);
  }
  e1a() {
    return _ChannelResult___init__impl__siwsuf(this.e19_1);
  }
  y19(cause) {
    return _ChannelResult___init__impl__siwsuf(new Closed(cause));
  }
}
class ChannelResult {
  constructor(holder) {
    Companion_getInstance_0();
    this.b1a_1 = holder;
  }
  toString() {
    return ChannelResult__toString_impl_rrcqu7(this.b1a_1);
  }
  hashCode() {
    return ChannelResult__hashCode_impl_lilec2(this.b1a_1);
  }
  equals(other) {
    return ChannelResult__equals_impl_f471ri(this.b1a_1, other);
  }
}
class ClosedSendChannelException extends IllegalStateException {
  static l1a(message) {
    var $this = this.t4(message);
    captureStack($this, $this.k1a_1);
    return $this;
  }
}
class ClosedReceiveChannelException extends NoSuchElementException {
  static u19(message) {
    var $this = this.p(message);
    captureStack($this, $this.t19_1);
    return $this;
  }
}
class ChannelCoroutine extends AbstractCoroutine {
  constructor(parentContext, _channel, initParentJob, active) {
    super(parentContext, initParentJob, active);
    this.d1b_1 = _channel;
  }
  j17() {
    return this;
  }
  uv(cause) {
    if (this.hv())
      return Unit_instance;
    var tmp;
    if (cause == null) {
      // Inline function 'kotlinx.coroutines.JobSupport.defaultCancellationException' call
      tmp = JobCancellationException.z13(null == null ? this.ou() : null, null, this);
    } else {
      tmp = cause;
    }
    this.wv(tmp);
  }
  r1a(cause, $super) {
    return this.vv(cause, ($super == null ? true : $super instanceof ChannelCoroutine) ? $super : THROW_CCE());
  }
  wv(cause) {
    var exception = this.mv(cause);
    this.d1b_1.uv(exception);
    this.zv(exception);
  }
  c1a(element, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_send__qhx0g0_0.bind(VOID, this, element), $completion);
  }
  d1a(element) {
    return this.d1b_1.d1a(element);
  }
  n1a(cause) {
    return this.d1b_1.n1a(cause);
  }
  g1a($completion) {
    return this.d1b_1.g1a($completion);
  }
  y() {
    return this.d1b_1.y();
  }
}
class ConflatedBufferedChannel extends BufferedChannel {
  constructor(capacity, onBufferOverflow, onUndeliveredElement) {
    onUndeliveredElement = onUndeliveredElement === VOID ? null : onUndeliveredElement;
    super(capacity, onUndeliveredElement);
    this.q1b_1 = capacity;
    this.r1b_1 = onBufferOverflow;
    // Inline function 'kotlin.require' call
    if (!!(this.r1b_1 === BufferOverflow_SUSPEND_getInstance())) {
      var message = 'This implementation does not support suspension for senders, use ' + getKClass(BufferedChannel).hf() + ' instead';
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(this.q1b_1 >= 1)) {
      var message_0 = 'Buffered channel capacity must be at least 1, but ' + this.q1b_1 + ' was specified';
      throw IllegalArgumentException.t(toString(message_0));
    }
  }
  x19() {
    return this.r1b_1.equals(BufferOverflow_DROP_OLDEST_getInstance());
  }
  c1a(element, $completion) {
    // Inline function 'kotlinx.coroutines.channels.onClosed' call
    var this_0 = trySendImpl(this, element, true);
    var tmp = _ChannelResult___get_holder__impl__pm9gzw(this_0);
    if (tmp instanceof Closed) {
      ChannelResult__exceptionOrNull_impl_16ei30(this_0);
      var tmp0_safe_receiver = this.u17_1;
      var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : callUndeliveredElementCatchingException(tmp0_safe_receiver, element);
      if (tmp1_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.let' call
        addSuppressed(tmp1_safe_receiver, this.a19());
        throw tmp1_safe_receiver;
      }
      throw this.a19();
    }
  }
  d1a(element) {
    return trySendImpl(this, element, false);
  }
}
class ProducerScope {}
class ProducerCoroutine extends ChannelCoroutine {
  constructor(parentContext, channel) {
    super(parentContext, channel, true, true);
  }
  lu() {
    return super.lu();
  }
  w1b(value) {
    this.d1b_1.p1a();
  }
  mu(value) {
    return this.w1b(value instanceof Unit ? value : THROW_CCE());
  }
  nu(cause, handled) {
    var processed = this.d1b_1.n1a(cause);
    if (!processed && !handled) {
      handleCoroutineException(this.ju_1, cause);
    }
  }
  r1a(cause, $super) {
    return this.vv(cause, ($super == null ? true : $super instanceof ProducerCoroutine) ? $super : THROW_CCE());
  }
}
class Flow {}
class AbstractFlow {
  z1b(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy.bind(VOID, this, collector), $completion);
  }
}
class SafeFlow extends AbstractFlow {
  constructor(block) {
    super();
    this.x1b_1 = block;
  }
  y1b(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collectSafely__fg77v4.bind(VOID, this, collector), $completion);
  }
}
class FusibleFlow {}
function fuse$default(context, capacity, onBufferOverflow, $super) {
  context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
  capacity = capacity === VOID ? -3 : capacity;
  onBufferOverflow = onBufferOverflow === VOID ? BufferOverflow_SUSPEND_getInstance() : onBufferOverflow;
  return $super === VOID ? this.l1c(context, capacity, onBufferOverflow) : $super.l1c.call(this, context, capacity, onBufferOverflow);
}
class ChannelFlow {
  constructor(context, capacity, onBufferOverflow) {
    this.g1c_1 = context;
    this.h1c_1 = capacity;
    this.i1c_1 = onBufferOverflow;
    // Inline function 'kotlinx.coroutines.assert' call
  }
  j1c() {
    return ChannelFlow$_get_collectToFun_$slambda_j53z2e_0(this);
  }
  k1c() {
    return this.h1c_1 === -3 ? -2 : this.h1c_1;
  }
  l1c(context, capacity, onBufferOverflow) {
    // Inline function 'kotlinx.coroutines.assert' call
    var newContext = context.dn(this.g1c_1);
    var newCapacity;
    var newOverflow;
    if (!onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance())) {
      newCapacity = capacity;
      newOverflow = onBufferOverflow;
    } else {
      var tmp;
      if (this.h1c_1 === -3) {
        tmp = capacity;
      } else if (capacity === -3) {
        tmp = this.h1c_1;
      } else if (this.h1c_1 === -2) {
        tmp = capacity;
      } else if (capacity === -2) {
        tmp = this.h1c_1;
      } else {
        // Inline function 'kotlinx.coroutines.assert' call
        // Inline function 'kotlinx.coroutines.assert' call
        var sum = this.h1c_1 + capacity | 0;
        tmp = sum >= 0 ? sum : 2147483647;
      }
      newCapacity = tmp;
      newOverflow = this.i1c_1;
    }
    if (equals(newContext, this.g1c_1) && newCapacity === this.h1c_1 && newOverflow.equals(this.i1c_1))
      return this;
    return this.e1c(newContext, newCapacity, newOverflow);
  }
  n1c(scope) {
    return produce_0(scope, this.g1c_1, this.k1c(), this.i1c_1, CoroutineStart_ATOMIC_getInstance(), VOID, this.j1c());
  }
  z1b(collector, $completion) {
    return coroutineScope(ChannelFlow$collect$slambda_0(collector, this), $completion);
  }
  o1c() {
    return null;
  }
  toString() {
    var props = ArrayList.x(4);
    var tmp0_safe_receiver = this.o1c();
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      props.l(tmp0_safe_receiver);
    }
    if (!(this.g1c_1 === EmptyCoroutineContext_getInstance())) {
      props.l('context=' + toString(this.g1c_1));
    }
    if (!(this.h1c_1 === -3)) {
      props.l('capacity=' + this.h1c_1);
    }
    if (!this.i1c_1.equals(BufferOverflow_SUSPEND_getInstance())) {
      props.l('onBufferOverflow=' + this.i1c_1.toString());
    }
    return get_classSimpleName(this) + '[' + joinToString(props, ', ') + ']';
  }
}
class ChannelFlowBuilder extends ChannelFlow {
  constructor(block, context, capacity, onBufferOverflow) {
    context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
    capacity = capacity === VOID ? -2 : capacity;
    onBufferOverflow = onBufferOverflow === VOID ? BufferOverflow_SUSPEND_getInstance() : onBufferOverflow;
    super(context, capacity, onBufferOverflow);
    this.d1c_1 = block;
  }
  e1c(context, capacity, onBufferOverflow) {
    return new ChannelFlowBuilder(this.d1c_1, context, capacity, onBufferOverflow);
  }
  f1c(scope, $completion) {
    return this.d1c_1(scope, $completion);
  }
  toString() {
    return 'block[' + toString(this.d1c_1) + '] -> ' + super.toString();
  }
}
class FlowCollector {}
class Emitter {
  constructor(flow, index, value, cont) {
    this.s1d_1 = flow;
    this.t1d_1 = index;
    this.u1d_1 = value;
    this.v1d_1 = cont;
  }
  bx() {
    return cancelEmitter(this.s1d_1, this);
  }
}
class AbstractSharedFlow extends SynchronizedObject {
  constructor() {
    super();
    this.g1d_1 = null;
    this.h1d_1 = 0;
    this.i1d_1 = 0;
    this.j1d_1 = null;
  }
  k1d() {
    var subscriptionCount;
    // Inline function 'kotlinx.coroutines.internal.synchronized' call
    // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
    var curSlots = this.g1d_1;
    var tmp;
    if (curSlots == null) {
      // Inline function 'kotlin.also' call
      var this_0 = this.a1e(2);
      this.g1d_1 = this_0;
      tmp = this_0;
    } else {
      var tmp_0;
      if (this.h1d_1 >= curSlots.length) {
        // Inline function 'kotlin.also' call
        var this_1 = copyOf(curSlots, imul(2, curSlots.length));
        this.g1d_1 = this_1;
        tmp_0 = this_1;
      } else {
        tmp_0 = curSlots;
      }
      tmp = tmp_0;
    }
    var slots = tmp;
    var index = this.i1d_1;
    var slot;
    $l$loop: while (true) {
      var tmp0_elvis_lhs = slots[index];
      var tmp_1;
      if (tmp0_elvis_lhs == null) {
        // Inline function 'kotlin.also' call
        var this_2 = this.z1d();
        slots[index] = this_2;
        tmp_1 = this_2;
      } else {
        tmp_1 = tmp0_elvis_lhs;
      }
      slot = tmp_1;
      index = index + 1 | 0;
      if (index >= slots.length)
        index = 0;
      if ((slot instanceof AbstractSharedFlowSlot ? slot : THROW_CCE()).c1e(this))
        break $l$loop;
    }
    this.i1d_1 = index;
    this.h1d_1 = this.h1d_1 + 1 | 0;
    subscriptionCount = this.j1d_1;
    var slot_0 = slot;
    if (subscriptionCount == null)
      null;
    else
      subscriptionCount.i1f(1);
    return slot_0;
  }
  o1d(slot) {
    var subscriptionCount;
    // Inline function 'kotlinx.coroutines.internal.synchronized' call
    // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
    this.h1d_1 = this.h1d_1 - 1 | 0;
    subscriptionCount = this.j1d_1;
    if (this.h1d_1 === 0)
      this.i1d_1 = 0;
    var resumes = (slot instanceof AbstractSharedFlowSlot ? slot : THROW_CCE()).e1e(this);
    var inductionVariable = 0;
    var last = resumes.length;
    while (inductionVariable < last) {
      var cont = resumes[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (cont == null)
        null;
      else {
        // Inline function 'kotlin.coroutines.resume' call
        // Inline function 'kotlin.Companion.success' call
        var tmp$ret$3 = _Result___init__impl__xyqfz8(Unit_instance);
        cont.nc(tmp$ret$3);
      }
    }
    if (subscriptionCount == null)
      null;
    else
      subscriptionCount.i1f(-1);
  }
}
class SharedFlowImpl extends AbstractSharedFlow {
  constructor(replay, bufferCapacity, onBufferOverflow) {
    super();
    this.y1c_1 = replay;
    this.z1c_1 = bufferCapacity;
    this.a1d_1 = onBufferOverflow;
    this.b1d_1 = null;
    this.c1d_1 = new Long(0, 0);
    this.d1d_1 = new Long(0, 0);
    this.e1d_1 = 0;
    this.f1d_1 = 0;
  }
  x1d() {
    var tmp = ensureNotNull(this.b1d_1);
    var tmp0 = this.c1d_1;
    // Inline function 'kotlin.Long.plus' call
    var other = _get_replaySize__dxgnb1(this);
    // Inline function 'kotlin.Long.minus' call
    var tmp$ret$1 = tmp0.u3(toLong(other)).v3(toLong(1));
    var tmp_0 = getBufferAt(tmp, tmp$ret$1);
    return (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
  }
  z1b(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_0.bind(VOID, this, collector), $completion);
  }
  p1d(value) {
    var resumes = get_EMPTY_RESUMES();
    // Inline function 'kotlinx.coroutines.internal.synchronized' call
    // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
    var tmp;
    if (tryEmitLocked(this, value)) {
      resumes = findSlotsToResumeLocked(this, resumes);
      tmp = true;
    } else {
      tmp = false;
    }
    var emitted = tmp;
    var indexedObject = resumes;
    var inductionVariable = 0;
    var last = indexedObject.length;
    while (inductionVariable < last) {
      var cont = indexedObject[inductionVariable];
      inductionVariable = inductionVariable + 1 | 0;
      if (cont == null)
        null;
      else {
        // Inline function 'kotlin.coroutines.resume' call
        // Inline function 'kotlin.Companion.success' call
        var tmp$ret$3 = _Result___init__impl__xyqfz8(Unit_instance);
        cont.nc(tmp$ret$3);
      }
    }
    return emitted;
  }
  p1c(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_emit__qph46j.bind(VOID, this, value), $completion);
  }
  y1d() {
    var index = this.c1d_1;
    if (index.s1(this.d1d_1) < 0)
      this.d1d_1 = index;
    return index;
  }
  w1d(oldIndex) {
    // Inline function 'kotlinx.coroutines.assert' call
    if (oldIndex.s1(this.d1d_1) > 0)
      return get_EMPTY_RESUMES();
    var head = _get_head__d7jo8b(this);
    // Inline function 'kotlin.Long.plus' call
    var other = this.e1d_1;
    var newMinCollectorIndex = head.u3(toLong(other));
    if (this.z1c_1 === 0 && this.f1d_1 > 0) {
      newMinCollectorIndex = newMinCollectorIndex.z3();
    }
    $l$block: {
      // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.forEachSlotLocked' call
      if (this.h1d_1 === 0) {
        break $l$block;
      }
      var tmp0_safe_receiver = this.g1d_1;
      if (tmp0_safe_receiver == null)
        null;
      else {
        // Inline function 'kotlin.collections.forEach' call
        var inductionVariable = 0;
        var last = tmp0_safe_receiver.length;
        while (inductionVariable < last) {
          var element = tmp0_safe_receiver[inductionVariable];
          inductionVariable = inductionVariable + 1 | 0;
          if (!(element == null)) {
            if (element.q1d_1.s1(new Long(0, 0)) >= 0 && element.q1d_1.s1(newMinCollectorIndex) < 0)
              newMinCollectorIndex = element.q1d_1;
          }
        }
      }
    }
    // Inline function 'kotlinx.coroutines.assert' call
    if (newMinCollectorIndex.s1(this.d1d_1) <= 0)
      return get_EMPTY_RESUMES();
    var newBufferEndIndex = _get_bufferEndIndex__d2rk18(this);
    var tmp;
    if (this.h1d_1 > 0) {
      var newBufferSize0 = newBufferEndIndex.v3(newMinCollectorIndex).x1();
      var tmp4 = this.f1d_1;
      // Inline function 'kotlin.comparisons.minOf' call
      var b = this.z1c_1 - newBufferSize0 | 0;
      tmp = Math.min(tmp4, b);
    } else {
      tmp = this.f1d_1;
    }
    var maxResumeCount = tmp;
    var resumes = get_EMPTY_RESUMES();
    var tmp6 = newBufferEndIndex;
    // Inline function 'kotlin.Long.plus' call
    var other_0 = this.f1d_1;
    var newQueueEndIndex = tmp6.u3(toLong(other_0));
    if (maxResumeCount > 0) {
      // Inline function 'kotlin.arrayOfNulls' call
      resumes = Array(maxResumeCount);
      var resumeCount = 0;
      var buffer = ensureNotNull(this.b1d_1);
      var inductionVariable_0 = newBufferEndIndex;
      if (inductionVariable_0.s1(newQueueEndIndex) < 0)
        $l$loop: do {
          var curEmitterIndex = inductionVariable_0;
          inductionVariable_0 = inductionVariable_0.u3(new Long(1, 0));
          var emitter = getBufferAt(buffer, curEmitterIndex);
          if (!(emitter === get_NO_VALUE())) {
            if (!(emitter instanceof Emitter))
              THROW_CCE();
            var tmp_0 = resumes;
            var _unary__edvuaz = resumeCount;
            resumeCount = _unary__edvuaz + 1 | 0;
            tmp_0[_unary__edvuaz] = emitter.v1d_1;
            setBufferAt(buffer, curEmitterIndex, get_NO_VALUE());
            setBufferAt(buffer, newBufferEndIndex, emitter.u1d_1);
            newBufferEndIndex = newBufferEndIndex.z3();
            if (resumeCount >= maxResumeCount)
              break $l$loop;
          }
        }
         while (inductionVariable_0.s1(newQueueEndIndex) < 0);
    }
    var newBufferSize1 = newBufferEndIndex.v3(head).x1();
    if (this.h1d_1 === 0)
      newMinCollectorIndex = newBufferEndIndex;
    var tmp13 = this.c1d_1;
    var tmp11 = newBufferEndIndex;
    // Inline function 'kotlin.comparisons.minOf' call
    var a = this.y1c_1;
    // Inline function 'kotlin.Long.minus' call
    var other_1 = Math.min(a, newBufferSize1);
    // Inline function 'kotlin.comparisons.maxOf' call
    var b_0 = tmp11.v3(toLong(other_1));
    var newReplayIndex = tmp13.s1(b_0) >= 0 ? tmp13 : b_0;
    if (this.z1c_1 === 0 && newReplayIndex.s1(newQueueEndIndex) < 0 && equals(getBufferAt(ensureNotNull(this.b1d_1), newReplayIndex), get_NO_VALUE())) {
      newBufferEndIndex = newBufferEndIndex.z3();
      newReplayIndex = newReplayIndex.z3();
    }
    updateBufferLocked(this, newReplayIndex, newMinCollectorIndex, newBufferEndIndex, newQueueEndIndex);
    cleanupTailLocked(this);
    // Inline function 'kotlin.collections.isNotEmpty' call
    // Inline function 'kotlin.collections.isEmpty' call
    if (!(resumes.length === 0))
      resumes = findSlotsToResumeLocked(this, resumes);
    return resumes;
  }
  z1d() {
    return new SharedFlowSlot();
  }
  a1e(size) {
    // Inline function 'kotlin.arrayOfNulls' call
    return Array(size);
  }
  l1c(context, capacity, onBufferOverflow) {
    return fuseSharedFlow(this, context, capacity, onBufferOverflow);
  }
}
class AbstractSharedFlowSlot {}
class SharedFlowSlot extends AbstractSharedFlowSlot {
  constructor() {
    super();
    this.q1d_1 = new Long(-1, -1);
    this.r1d_1 = null;
  }
  b1e(flow) {
    if (this.q1d_1.s1(new Long(0, 0)) >= 0)
      return false;
    this.q1d_1 = flow.y1d();
    return true;
  }
  c1e(flow) {
    return this.b1e(flow instanceof SharedFlowImpl ? flow : THROW_CCE());
  }
  d1e(flow) {
    // Inline function 'kotlinx.coroutines.assert' call
    var oldIndex = this.q1d_1;
    this.q1d_1 = new Long(-1, -1);
    this.r1d_1 = null;
    return flow.w1d(oldIndex);
  }
  e1e(flow) {
    return this.d1e(flow instanceof SharedFlowImpl ? flow : THROW_CCE());
  }
}
class StateFlowImpl extends AbstractSharedFlow {
  constructor(initialState) {
    super();
    this.j1e_1 = atomic$ref$1(initialState);
    this.k1e_1 = 0;
  }
  p1e(value) {
    updateState(this, null, value == null ? get_NULL() : value);
  }
  n1() {
    var tmp0 = get_NULL();
    // Inline function 'kotlinx.coroutines.internal.Symbol.unbox' call
    var value = this.j1e_1.kotlinx$atomicfu$value;
    var tmp;
    if (value === tmp0) {
      tmp = (null == null ? true : !(null == null)) ? null : THROW_CCE();
    } else {
      tmp = (value == null ? true : !(value == null)) ? value : THROW_CCE();
    }
    return tmp;
  }
  q1e(expect, update) {
    var tmp = expect == null ? get_NULL() : expect;
    return updateState(this, tmp, update == null ? get_NULL() : update);
  }
  p1d(value) {
    this.p1e(value);
    return true;
  }
  p1c(value, $completion) {
    this.p1e(value);
  }
  z1b(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_1.bind(VOID, this, collector), $completion);
  }
  z1d() {
    return new StateFlowSlot();
  }
  a1e(size) {
    // Inline function 'kotlin.arrayOfNulls' call
    return Array(size);
  }
  l1c(context, capacity, onBufferOverflow) {
    return fuseStateFlow(this, context, capacity, onBufferOverflow);
  }
}
class StateFlowSlot extends AbstractSharedFlowSlot {
  constructor() {
    super();
    this.l1e_1 = new WorkaroundAtomicReference(null);
  }
  r1e(flow) {
    if (!(get_value(this.l1e_1) == null))
      return false;
    set_value(this.l1e_1, get_NONE());
    return true;
  }
  c1e(flow) {
    return this.r1e(flow instanceof StateFlowImpl ? flow : THROW_CCE());
  }
  s1e(flow) {
    set_value(this.l1e_1, null);
    return get_EMPTY_RESUMES();
  }
  e1e(flow) {
    return this.s1e(flow instanceof StateFlowImpl ? flow : THROW_CCE());
  }
  m1e() {
    // Inline function 'kotlinx.coroutines.internal.loop' call
    var this_0 = this.l1e_1;
    while (true) {
      var state = get_value(this_0);
      if (state == null)
        return Unit_instance;
      else if (state === get_PENDING())
        return Unit_instance;
      else if (state === get_NONE()) {
        if (this.l1e_1.u1e(state, get_PENDING()))
          return Unit_instance;
      } else {
        if (this.l1e_1.u1e(state, get_NONE())) {
          // Inline function 'kotlin.coroutines.resume' call
          var this_1 = state instanceof CancellableContinuationImpl ? state : THROW_CCE();
          // Inline function 'kotlin.Companion.success' call
          var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
          this_1.nc(tmp$ret$0);
          return Unit_instance;
        }
      }
    }
  }
  o1e() {
    // Inline function 'kotlin.let' call
    // Inline function 'kotlinx.coroutines.assert' call
    return ensureNotNull(this.l1e_1.v1e(get_NONE())) === get_PENDING();
  }
  n1e($completion) {
    var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
    cancellable.by();
    $l$block: {
      // Inline function 'kotlinx.coroutines.assert' call
      if (this.l1e_1.u1e(get_NONE(), cancellable)) {
        break $l$block;
      }
      // Inline function 'kotlinx.coroutines.assert' call
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var tmp$ret$3 = _Result___init__impl__xyqfz8(Unit_instance);
      cancellable.nc(tmp$ret$3);
    }
    return cancellable.cy();
  }
}
class ChannelFlowOperator extends ChannelFlow {
  constructor(flow, context, capacity, onBufferOverflow) {
    super(context, capacity, onBufferOverflow);
    this.q1f_1 = flow;
  }
  f1c(scope, $completion) {
    return this.r1f(new SendingCollector(scope), $completion);
  }
  z1b(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_2.bind(VOID, this, collector), $completion);
  }
  toString() {
    return toString(this.q1f_1) + ' -> ' + super.toString();
  }
}
class ChannelFlowOperatorImpl extends ChannelFlowOperator {
  constructor(flow, context, capacity, onBufferOverflow) {
    context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
    capacity = capacity === VOID ? -3 : capacity;
    onBufferOverflow = onBufferOverflow === VOID ? BufferOverflow_SUSPEND_getInstance() : onBufferOverflow;
    super(flow, context, capacity, onBufferOverflow);
  }
  e1c(context, capacity, onBufferOverflow) {
    return new ChannelFlowOperatorImpl(this.q1f_1, context, capacity, onBufferOverflow);
  }
  r1f(collector, $completion) {
    return this.q1f_1.z1b(collector, $completion);
  }
}
class ChannelFlow$_get_collectToFun_$slambda_j53z2e {
  constructor(this$0) {
    this.s1f_1 = this$0;
  }
  v1f(it, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8.bind(VOID, this, it), $completion);
  }
  td(p1, $completion) {
    return this.v1f((!(p1 == null) ? isInterface(p1, ProducerScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class ChannelFlow$collect$slambda {
  constructor($collector, this$0) {
    this.t1f_1 = $collector;
    this.u1f_1 = this$0;
  }
  w1f($this$coroutineScope, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_0.bind(VOID, this, $this$coroutineScope), $completion);
  }
  td(p1, $completion) {
    return this.w1f((!(p1 == null) ? isInterface(p1, CoroutineScope) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class ChannelFlowOperator$collectWithContextUndispatched$slambda {
  constructor(this$0) {
    this.x1f_1 = this$0;
  }
  y1f(it, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_1.bind(VOID, this, it), $completion);
  }
  td(p1, $completion) {
    return this.y1f((!(p1 == null) ? isInterface(p1, FlowCollector) : false) ? p1 : THROW_CCE(), $completion);
  }
}
class UndispatchedContextCollector$emitRef$slambda {
  constructor($downstream) {
    this.z1f_1 = $downstream;
  }
  a1g(it, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_invoke__zhh2q8_2.bind(VOID, this, it), $completion);
  }
  td(p1, $completion) {
    return this.a1g((p1 == null ? true : !(p1 == null)) ? p1 : THROW_CCE(), $completion);
  }
}
class UndispatchedContextCollector {
  constructor(downstream, emitContext) {
    this.b1g_1 = emitContext;
    this.c1g_1 = threadContextElements(this.b1g_1);
    var tmp = this;
    tmp.d1g_1 = UndispatchedContextCollector$emitRef$slambda_0(downstream);
  }
  p1c(value, $completion) {
    return withContextUndispatched(this.b1g_1, value, this.c1g_1, this.d1g_1, $completion);
  }
}
class StackFrameContinuation {
  constructor(uCont, context) {
    this.e1g_1 = uCont;
    this.f1g_1 = context;
  }
  lc() {
    return this.f1g_1;
  }
  nc(result) {
    this.e1g_1.nc(result);
  }
}
class NopCollector {}
class SendingCollector {
  constructor(channel) {
    this.m1g_1 = channel;
  }
  p1c(value, $completion) {
    return this.m1g_1.c1a(value, $completion);
  }
}
class ThrowingCollector {}
class SubscribedFlowCollector {
  n1d($completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_onSubscription__25ehyk.bind(VOID, this), $completion);
  }
}
class ReadonlySharedFlow {
  constructor(flow, job) {
    this.o1g_1 = flow;
    this.p1g_1 = job;
  }
  l1c(context, capacity, onBufferOverflow) {
    return fuseSharedFlow(this, context, capacity, onBufferOverflow);
  }
  z1b(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_3.bind(VOID, this, collector), $completion);
  }
}
class ReadonlyStateFlow {
  constructor(flow, job) {
    this.q1g_1 = flow;
    this.r1g_1 = job;
  }
  l1c(context, capacity, onBufferOverflow) {
    return fuseStateFlow(this, context, capacity, onBufferOverflow);
  }
  z1b(collector, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_collect__dlomyy_4.bind(VOID, this, collector), $completion);
  }
}
class first$$inlined$collectWhile$1 {
  constructor($predicate, $result) {
    this.s1g_1 = $predicate;
    this.t1g_1 = $result;
  }
  v1g(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_emit__qph46j_0.bind(VOID, this, value), $completion);
  }
  p1c(value, $completion) {
    return this.v1g((value == null ? true : !(value == null)) ? value : THROW_CCE(), $completion);
  }
}
class firstOrNull$$inlined$collectWhile$1 {
  constructor($result) {
    this.w1g_1 = $result;
  }
  v1g(value, $completion) {
    this.w1g_1._v = value;
    if (!false) {
      throw AbortFlowException.u1g(this);
    }
  }
  p1c(value, $completion) {
    return this.v1g((value == null ? true : !(value == null)) ? value : THROW_CCE(), $completion);
  }
}
class first$$inlined$collectWhile$2 {
  constructor($result) {
    this.x1g_1 = $result;
  }
  v1g(value, $completion) {
    this.x1g_1._v = value;
    if (!false) {
      throw AbortFlowException.u1g(this);
    }
  }
  p1c(value, $completion) {
    return this.v1g((value == null ? true : !(value == null)) ? value : THROW_CCE(), $completion);
  }
}
class SegmentOrClosed {
  constructor(value) {
    this.a1a_1 = value;
  }
  toString() {
    return SegmentOrClosed__toString_impl_pzb2an(this.a1a_1);
  }
  hashCode() {
    return SegmentOrClosed__hashCode_impl_4855hs(this.a1a_1);
  }
  equals(other) {
    return SegmentOrClosed__equals_impl_6erq1g(this.a1a_1, other);
  }
}
class ExceptionSuccessfullyProcessed extends Exception {}
class DispatchedContinuation extends DispatchedTask {
  constructor(dispatcher, continuation) {
    super(-1);
    this.jz_1 = dispatcher;
    this.kz_1 = continuation;
    this.lz_1 = get_UNDEFINED();
    this.mz_1 = threadContextElements(this.lc());
    this.nz_1 = atomic$ref$1(null);
  }
  qz() {
    return !(this.nz_1.kotlinx$atomicfu$value == null);
  }
  d1h() {
    // Inline function 'kotlinx.atomicfu.loop' call
    var this_0 = this.nz_1;
    while (true) {
      if (!(this_0.kotlinx$atomicfu$value === get_REUSABLE_CLAIMED()))
        return Unit_instance;
    }
  }
  y11() {
    this.d1h();
    var tmp0_safe_receiver = _get_reusableCancellableContinuation__9qex09(this);
    if (tmp0_safe_receiver == null)
      null;
    else {
      tmp0_safe_receiver.l10();
    }
  }
  oz() {
    // Inline function 'kotlinx.atomicfu.loop' call
    var this_0 = this.nz_1;
    while (true) {
      var state = this_0.kotlinx$atomicfu$value;
      if (state === null) {
        this.nz_1.kotlinx$atomicfu$value = get_REUSABLE_CLAIMED();
        return null;
      } else {
        if (state instanceof CancellableContinuationImpl) {
          if (this.nz_1.atomicfu$compareAndSet(state, get_REUSABLE_CLAIMED())) {
            return state instanceof CancellableContinuationImpl ? state : THROW_CCE();
          }
        } else {
          if (state !== get_REUSABLE_CLAIMED()) {
            if (!(state instanceof Error)) {
              // Inline function 'kotlin.error' call
              var message = 'Inconsistent state ' + toString_0(state);
              throw IllegalStateException.t4(toString(message));
            }
          }
        }
      }
    }
  }
  w10(continuation) {
    // Inline function 'kotlinx.atomicfu.loop' call
    var this_0 = this.nz_1;
    while (true) {
      var state = this_0.kotlinx$atomicfu$value;
      if (state === get_REUSABLE_CLAIMED()) {
        if (this.nz_1.atomicfu$compareAndSet(get_REUSABLE_CLAIMED(), continuation))
          return null;
      } else {
        if (state instanceof Error) {
          // Inline function 'kotlin.require' call
          // Inline function 'kotlin.require' call
          if (!this.nz_1.atomicfu$compareAndSet(state, null)) {
            var message = 'Failed requirement.';
            throw IllegalArgumentException.t(toString(message));
          }
          return state;
        } else {
          // Inline function 'kotlin.error' call
          var message_0 = 'Inconsistent state ' + toString_0(state);
          throw IllegalStateException.t4(toString(message_0));
        }
      }
    }
  }
  sz(cause) {
    // Inline function 'kotlinx.atomicfu.loop' call
    var this_0 = this.nz_1;
    while (true) {
      var state = this_0.kotlinx$atomicfu$value;
      if (equals(state, get_REUSABLE_CLAIMED())) {
        if (this.nz_1.atomicfu$compareAndSet(get_REUSABLE_CLAIMED(), cause))
          return true;
      } else {
        if (state instanceof Error)
          return true;
        else {
          if (this.nz_1.atomicfu$compareAndSet(state, null))
            return false;
        }
      }
    }
  }
  n10() {
    var state = this.lz_1;
    // Inline function 'kotlinx.coroutines.assert' call
    this.lz_1 = get_UNDEFINED();
    return state;
  }
  m10() {
    return this;
  }
  nc(result) {
    var state = toState_0(result);
    if (safeIsDispatchNeeded(this.jz_1, this.lc())) {
      this.lz_1 = state;
      this.rz_1 = 0;
      safeDispatch(this.jz_1, this.lc(), this);
    } else {
      $l$block: {
        // Inline function 'kotlinx.coroutines.internal.executeUnconfined' call
        // Inline function 'kotlinx.coroutines.assert' call
        var eventLoop = ThreadLocalEventLoop_getInstance().v12();
        if (false && eventLoop.q12()) {
          break $l$block;
        }
        var tmp;
        if (eventLoop.p12()) {
          this.lz_1 = state;
          this.rz_1 = 0;
          eventLoop.o12(this);
          tmp = true;
        } else {
          // Inline function 'kotlinx.coroutines.runUnconfinedEventLoop' call
          eventLoop.r12(true);
          try {
            this.lc();
            // Inline function 'kotlinx.coroutines.withCoroutineContext' call
            this.mz_1;
            this.kz_1.nc(result);
            $l$loop: while (eventLoop.n12()) {
            }
          } catch ($p) {
            if ($p instanceof Error) {
              var e = $p;
              this.i11(e);
            } else {
              throw $p;
            }
          }
          finally {
            eventLoop.s12(true);
          }
          tmp = false;
        }
      }
    }
  }
  toString() {
    return 'DispatchedContinuation[' + this.jz_1.toString() + ', ' + toDebugString(this.kz_1) + ']';
  }
  lc() {
    return this.kz_1.lc();
  }
}
class DispatchException extends Exception {
  static e1h(cause, dispatcher, context) {
    var $this = this.xd('Coroutine dispatcher ' + dispatcher.toString() + ' threw an exception, context = ' + toString(context), cause);
    captureStack($this, $this.b12_1);
    $this.a12_1 = cause;
    return $this;
  }
  i2() {
    return this.a12_1;
  }
  get cause() {
    return this.i2();
  }
}
class UndeliveredElementException extends RuntimeException {
  static i1h(message, cause) {
    var $this = this.be(message, cause);
    captureStack($this, $this.h1h_1);
    return $this;
  }
}
class ContextScope {
  constructor(context) {
    this.j1h_1 = context;
  }
  ku() {
    return this.j1h_1;
  }
  toString() {
    return 'CoroutineScope(coroutineContext=' + toString(this.j1h_1) + ')';
  }
}
class Symbol {
  constructor(symbol) {
    this.k1h_1 = symbol;
  }
  toString() {
    return '<' + this.k1h_1 + '>';
  }
}
class SelectInstance {}
class ClauseData {
  p1h(select, internalResult) {
    var tmp0_safe_receiver = this.o1h_1;
    return tmp0_safe_receiver == null ? null : tmp0_safe_receiver(select, this.n1h_1, internalResult);
  }
}
class SelectImplementation {
  n19(clauseObject, result) {
    return TrySelectDetailedResult_0(trySelectInternal(this, clauseObject, result));
  }
}
class TrySelectDetailedResult extends Enum {}
class CancellableContinuationWithOwner {
  constructor($outer, cont, owner) {
    this.b1i_1 = $outer;
    this.z1h_1 = cont;
    this.a1i_1 = owner;
  }
  n1i(value, idempotent, onCancellation) {
    // Inline function 'kotlinx.coroutines.assert' call
    var token = this.z1h_1.cz(value, idempotent, MutexImpl$CancellableContinuationWithOwner$tryResume$lambda(this.b1i_1, this));
    if (!(token == null)) {
      // Inline function 'kotlinx.coroutines.assert' call
      this.b1i_1.x1h_1.kotlinx$atomicfu$value = this.a1i_1;
    }
    return token;
  }
  cz(value, idempotent, onCancellation) {
    return this.n1i(value instanceof Unit ? value : THROW_CCE(), idempotent, onCancellation);
  }
  o1i(value, onCancellation) {
    // Inline function 'kotlinx.coroutines.assert' call
    this.b1i_1.x1h_1.kotlinx$atomicfu$value = this.a1i_1;
    this.z1h_1.y10(Unit_instance, MutexImpl$CancellableContinuationWithOwner$resume$lambda(this.b1i_1, this));
  }
  fz(value, onCancellation) {
    return this.o1i(value instanceof Unit ? value : THROW_CCE(), onCancellation);
  }
  gv() {
    return this.z1h_1.gv();
  }
  hv() {
    return this.z1h_1.hv();
  }
  hx(exception) {
    return this.z1h_1.hx(exception);
  }
  ix(token) {
    this.z1h_1.ix(token);
  }
  dz(handler) {
    this.z1h_1.dz(handler);
  }
  a11(segment, index) {
    this.z1h_1.a11(segment, index);
  }
  p1i(_this__u8e3s4, value) {
    this.z1h_1.ez(_this__u8e3s4, Unit_instance);
  }
  ez(_this__u8e3s4, value) {
    return this.p1i(_this__u8e3s4, value instanceof Unit ? value : THROW_CCE());
  }
  pm(result) {
    this.z1h_1.nc(result);
  }
  nc(result) {
    return this.pm(result);
  }
  lc() {
    return this.z1h_1.lc();
  }
}
class SemaphoreAndMutexImpl {
  constructor(permits, acquiredPermits) {
    this.f1i_1 = permits;
    this.h1i_1 = atomic$long$1(new Long(0, 0));
    this.j1i_1 = atomic$long$1(new Long(0, 0));
    // Inline function 'kotlin.require' call
    if (!(this.f1i_1 > 0)) {
      var message = 'Semaphore should have at least 1 permit, but had ' + this.f1i_1;
      throw IllegalArgumentException.t(toString(message));
    }
    // Inline function 'kotlin.require' call
    if (!(0 <= acquiredPermits ? acquiredPermits <= this.f1i_1 : false)) {
      var message_0 = 'The number of acquired permits should be in 0..' + this.f1i_1;
      throw IllegalArgumentException.t(toString(message_0));
    }
    var s = new SemaphoreSegment(new Long(0, 0), null, 2);
    this.g1i_1 = atomic$ref$1(s);
    this.i1i_1 = atomic$ref$1(s);
    this.k1i_1 = atomic$int$1(this.f1i_1 - acquiredPermits | 0);
    var tmp = this;
    tmp.l1i_1 = SemaphoreAndMutexImpl$onCancellationRelease$lambda(this);
  }
  q1i() {
    // Inline function 'kotlin.math.max' call
    var a = this.k1i_1.kotlinx$atomicfu$value;
    return Math.max(a, 0);
  }
  m1i() {
    $l$loop: while (true) {
      var p = this.k1i_1.kotlinx$atomicfu$value;
      if (p > this.f1i_1) {
        coerceAvailablePermitsAtMaximum(this);
        continue $l$loop;
      }
      if (p <= 0)
        return false;
      if (this.k1i_1.atomicfu$compareAndSet(p, p - 1 | 0))
        return true;
    }
  }
  acquireCont(waiter) {
    var tmp$ret$1;
    $l$block_0: {
      // Inline function 'kotlinx.coroutines.sync.SemaphoreAndMutexImpl.acquire' call
      while (true) {
        var p = decPermits(this);
        if (p > 0) {
          waiter.fz(Unit_instance, this.l1i_1);
          tmp$ret$1 = Unit_instance;
          break $l$block_0;
        }
        if (addAcquireToQueue(this, isInterface(waiter, Waiter) ? waiter : THROW_CCE())) {
          tmp$ret$1 = Unit_instance;
          break $l$block_0;
        }
      }
      tmp$ret$1 = Unit_instance;
    }
    return tmp$ret$1;
  }
  s1i() {
    while (true) {
      var p = this.k1i_1.atomicfu$getAndIncrement();
      if (p >= this.f1i_1) {
        coerceAvailablePermitsAtMaximum(this);
        // Inline function 'kotlin.error' call
        var message = 'The number of released permits cannot be greater than ' + this.f1i_1;
        throw IllegalStateException.t4(toString(message));
      }
      if (p >= 0)
        return Unit_instance;
      if (tryResumeNextFromQueue(this))
        return Unit_instance;
    }
  }
}
class MutexImpl extends SemaphoreAndMutexImpl {
  constructor(locked) {
    super(1, locked ? 1 : 0);
    this.x1h_1 = atomic$ref$1(locked ? null : get_NO_OWNER());
    var tmp = this;
    tmp.y1h_1 = MutexImpl$onSelectCancellationUnlockConstructor$lambda(this);
  }
  d1i() {
    return this.q1i() === 0;
  }
  r1i(owner, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_lock__qllepv.bind(VOID, this, owner), $completion);
  }
  e1i(owner) {
    var tmp;
    switch (tryLockImpl(this, owner)) {
      case 0:
        tmp = true;
        break;
      case 1:
        tmp = false;
        break;
      case 2:
        var message = 'This mutex is already locked by the specified owner: ' + toString_0(owner);
        throw IllegalStateException.t4(toString(message));
      default:
        var message_0 = 'unexpected';
        throw IllegalStateException.t4(toString(message_0));
    }
    return tmp;
  }
  c1i(owner) {
    $l$loop_0: while (true) {
      // Inline function 'kotlin.check' call
      if (!this.d1i()) {
        var message = 'This mutex is not locked';
        throw IllegalStateException.t4(toString(message));
      }
      var curOwner = this.x1h_1.kotlinx$atomicfu$value;
      if (curOwner === get_NO_OWNER())
        continue $l$loop_0;
      // Inline function 'kotlin.check' call
      if (!(curOwner === owner || owner == null)) {
        var message_0 = 'This mutex is locked by ' + toString_0(curOwner) + ', but ' + toString_0(owner) + ' is expected';
        throw IllegalStateException.t4(toString(message_0));
      }
      if (!this.x1h_1.atomicfu$compareAndSet(curOwner, get_NO_OWNER()))
        continue $l$loop_0;
      this.s1i();
      return Unit_instance;
    }
  }
  toString() {
    return 'Mutex@' + get_hexAddress(this) + '[isLocked=' + this.d1i() + ',owner=' + toString_0(this.x1h_1.kotlinx$atomicfu$value) + ']';
  }
}
class SemaphoreSegment extends Segment {
  constructor(id, prev, pointers) {
    super(id, prev, pointers);
    this.x1i_1 = atomicfu$AtomicRefArray$ofNulls(get_SEGMENT_SIZE_0());
  }
  k17() {
    return get_SEGMENT_SIZE_0();
  }
  xz(index, cause, context) {
    // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.set' call
    var value = get_CANCELLED();
    this.x1i_1.atomicfu$get(index).kotlinx$atomicfu$value = value;
    this.h18();
  }
  toString() {
    return 'SemaphoreSegment[id=' + this.vz_1.toString() + ', hashCode=' + hashCode(this) + ']';
  }
}
class SetTimeoutBasedDispatcher extends CoroutineDispatcher {
  constructor() {
    super();
    this.h1j_1 = new ScheduledMessageQueue(this);
  }
  x11(context, block) {
    this.h1j_1.p1j(block);
  }
  h12(timeMillis, block, context) {
    var handle = w3cSetTimeout(SetTimeoutBasedDispatcher$invokeOnTimeout$lambda(block), delayToInt(timeMillis));
    return new ClearTimeout(handle);
  }
  g12(timeMillis, continuation) {
    var handle = w3cSetTimeout(SetTimeoutBasedDispatcher$scheduleResumeAfterDelay$lambda(continuation, this), delayToInt(timeMillis));
    invokeOnCancellation(continuation, new ClearTimeout(handle));
  }
}
class NodeDispatcher extends SetTimeoutBasedDispatcher {
  constructor() {
    NodeDispatcher_instance = null;
    super();
    NodeDispatcher_instance = this;
  }
  a1j() {
    process.nextTick(this.h1j_1.f1j_1);
  }
}
class MessageQueue {
  constructor() {
    this.i1j_1 = ArrayDeque.rk();
    this.j1j_1 = 16;
    this.k1j_1 = false;
  }
  p1j(element) {
    this.q1j(element);
    if (!this.k1j_1) {
      this.k1j_1 = true;
      this.m1j();
    }
  }
  l1j() {
    try {
      // Inline function 'kotlin.repeat' call
      var times = this.j1j_1;
      var inductionVariable = 0;
      if (inductionVariable < times)
        do {
          var index = inductionVariable;
          inductionVariable = inductionVariable + 1 | 0;
          var tmp0_elvis_lhs = removeFirstOrNull(this);
          var tmp;
          if (tmp0_elvis_lhs == null) {
            return Unit_instance;
          } else {
            tmp = tmp0_elvis_lhs;
          }
          var element = tmp;
          element.h11();
        }
         while (inductionVariable < times);
    }finally {
      if (this.h1()) {
        this.k1j_1 = false;
      } else {
        this.n1j();
      }
    }
  }
  q1j(element) {
    return this.i1j_1.l(element);
  }
  l(element) {
    return this.q1j((!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
  }
  r1j(index, element) {
    this.i1j_1.d3(index, element);
  }
  d3(index, element) {
    return this.r1j(index, (!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
  }
  s1j(element) {
    return this.i1j_1.z2(element);
  }
  z2(element) {
    if (!(!(element == null) ? isInterface(element, Runnable) : false))
      return false;
    return this.s1j((!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
  }
  t1j(elements) {
    return this.i1j_1.c1(elements);
  }
  c1(elements) {
    return this.t1j(elements);
  }
  u1j(elements) {
    return this.i1j_1.a3(elements);
  }
  a3(elements) {
    return this.u1j(elements);
  }
  b3() {
    this.i1j_1.b3();
  }
  v1j(index, element) {
    return this.i1j_1.c3(index, element);
  }
  c3(index, element) {
    return this.v1j(index, (!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
  }
  e3(index) {
    return this.i1j_1.e3(index);
  }
  i1(index) {
    return this.i1j_1.i1(index);
  }
  y2(fromIndex, toIndex) {
    return this.i1j_1.y2(fromIndex, toIndex);
  }
  h1() {
    return this.i1j_1.h1();
  }
  w1j(element) {
    return this.i1j_1.v2(element);
  }
  v2(element) {
    if (!(!(element == null) ? isInterface(element, Runnable) : false))
      return false;
    return this.w1j((!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
  }
  y() {
    return this.i1j_1.y();
  }
  x1j(elements) {
    return this.i1j_1.w2(elements);
  }
  w2(elements) {
    return this.x1j(elements);
  }
  f1(index) {
    return this.i1j_1.f1(index);
  }
  y1j(element) {
    return this.i1j_1.x2(element);
  }
  x2(element) {
    if (!(!(element == null) ? isInterface(element, Runnable) : false))
      return -1;
    return this.y1j((!(element == null) ? isInterface(element, Runnable) : false) ? element : THROW_CCE());
  }
  b1() {
    return this.i1j_1.nk_1;
  }
}
class ScheduledMessageQueue extends MessageQueue {
  constructor(dispatcher) {
    super();
    this.e1j_1 = dispatcher;
    var tmp = this;
    tmp.f1j_1 = ScheduledMessageQueue$processQueue$lambda(this);
  }
  m1j() {
    this.e1j_1.a1j();
  }
  n1j() {
    setTimeout(this.f1j_1, 0);
  }
  o1j(timeout) {
    setTimeout(this.f1j_1, timeout);
  }
}
class WindowMessageQueue extends MessageQueue {
  constructor(window_0) {
    super();
    this.c1k_1 = window_0;
    this.d1k_1 = 'dispatchCoroutine';
    this.c1k_1.addEventListener('message', WindowMessageQueue$lambda(this), true);
  }
  m1j() {
    var tmp = Promise.resolve(Unit_instance);
    tmp.then(WindowMessageQueue$schedule$lambda(this));
  }
  n1j() {
    this.c1k_1.postMessage(this.d1k_1, '*');
  }
}
class UnconfinedEventLoop extends EventLoop {
  x11(context, block) {
    unsupported();
  }
}
class SetTimeoutDispatcher extends SetTimeoutBasedDispatcher {
  constructor() {
    SetTimeoutDispatcher_instance = null;
    super();
    SetTimeoutDispatcher_instance = this;
  }
  a1j() {
    this.h1j_1.o1j(0);
  }
}
class ClearTimeout {
  constructor(handle, $box) {
    boxApply(this, $box);
    this.p1k_1 = handle;
  }
  bx() {
    w3cClearTimeout_0(this.p1k_1);
  }
  cx(cause) {
    this.bx();
  }
  toString() {
    return 'ClearTimeout[' + this.p1k_1 + ']';
  }
}
class WindowClearTimeout extends ClearTimeout {
  constructor($outer, handle, $box) {
    if ($box === VOID)
      $box = {};
    $box.l1k_1 = $outer;
    super(handle, $box);
  }
  bx() {
    w3cClearTimeout(this.l1k_1.n1k_1, this.p1k_1);
  }
}
class WindowDispatcher extends CoroutineDispatcher {
  constructor(window_0) {
    super();
    this.n1k_1 = window_0;
    this.o1k_1 = new WindowMessageQueue(this.n1k_1);
  }
  x11(context, block) {
    return this.o1k_1.p1j(block);
  }
  g12(timeMillis, continuation) {
    var handle = w3cSetTimeout_0(this.n1k_1, WindowDispatcher$scheduleResumeAfterDelay$lambda(continuation, this), delayToInt(timeMillis));
    invokeOnCancellation(continuation, new WindowClearTimeout(this, handle));
  }
  h12(timeMillis, block, context) {
    var handle = w3cSetTimeout_0(this.n1k_1, Runnable$run$ref(block), delayToInt(timeMillis));
    return new WindowClearTimeout(this, handle);
  }
}
class UndispatchedCoroutine extends ScopeCoroutine {
  uu(state) {
    return this.ty_1.nc(recoverResult(state, this.ty_1));
  }
}
class Dispatchers {
  constructor() {
    Dispatchers_instance = this;
    this.d16_1 = createDefaultDispatcher();
    this.e16_1 = Unconfined_getInstance();
    this.f16_1 = new JsMainDispatcher(this.d16_1, false);
    this.g16_1 = null;
  }
  h16() {
    var tmp0_elvis_lhs = this.g16_1;
    return tmp0_elvis_lhs == null ? this.f16_1 : tmp0_elvis_lhs;
  }
}
class JsMainDispatcher extends MainCoroutineDispatcher {
  constructor(delegate, invokeImmediately) {
    super();
    this.v1k_1 = delegate;
    this.w1k_1 = invokeImmediately;
    this.x1k_1 = this.w1k_1 ? this : new JsMainDispatcher(this.v1k_1, true);
  }
  b16() {
    return this.x1k_1;
  }
  w11(context) {
    return !this.w1k_1;
  }
  x11(context, block) {
    return this.v1k_1.x11(context, block);
  }
  toString() {
    var tmp0_elvis_lhs = this.c16();
    return tmp0_elvis_lhs == null ? this.v1k_1.toString() : tmp0_elvis_lhs;
  }
}
class JobCancellationException extends CancellationException {
  static z13(message, cause, job) {
    var $this = this.od(message, cause);
    captureStack($this, $this.y13_1);
    $this.x13_1 = job;
    return $this;
  }
  toString() {
    return super.toString() + '; job=' + toString(this.x13_1);
  }
  equals(other) {
    var tmp;
    if (other === this) {
      tmp = true;
    } else {
      var tmp_0;
      var tmp_1;
      var tmp_2;
      if (other instanceof JobCancellationException) {
        tmp_2 = other.message == this.message;
      } else {
        tmp_2 = false;
      }
      if (tmp_2) {
        tmp_1 = equals(other.x13_1, this.x13_1);
      } else {
        tmp_1 = false;
      }
      if (tmp_1) {
        tmp_0 = equals(other.cause, this.cause);
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    return tmp;
  }
  hashCode() {
    var tmp = imul(imul(getStringHashCode(ensureNotNull(this.message)), 31) + hashCode(this.x13_1) | 0, 31);
    var tmp0_safe_receiver = this.cause;
    var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : hashCode(tmp0_safe_receiver);
    return tmp + (tmp1_elvis_lhs == null ? 0 : tmp1_elvis_lhs) | 0;
  }
}
class AbortFlowException extends CancellationException {
  static u1g(owner) {
    var $this = this.nd('Flow was aborted, no more elements needed');
    captureStack($this, $this.l1g_1);
    $this.k1g_1 = owner;
    return $this;
  }
}
class SafeCollector {
  constructor(collector, collectContext) {
    this.q1c_1 = collector;
    this.r1c_1 = collectContext;
    var tmp = this;
    tmp.s1c_1 = this.r1c_1.cn(0, SafeCollector$collectContextSize$lambda);
    this.t1c_1 = null;
  }
  p1c(value, $completion) {
    return suspendOrReturn(/*#__NOINLINE__*/_generator_emit__qph46j_1.bind(VOID, this, value), $completion);
  }
  wc() {
  }
}
class WorkaroundAtomicReference {
  constructor(value) {
    this.t1e_1 = value;
  }
  x12() {
    return this.t1e_1;
  }
  y1g(value) {
    this.t1e_1 = value;
  }
  v1e(value) {
    var prev = this.t1e_1;
    this.t1e_1 = value;
    return prev;
  }
  u1e(expected, value) {
    if (this.t1e_1 === expected) {
      this.t1e_1 = value;
      return true;
    }
    return false;
  }
}
class DiagnosticCoroutineContextException extends RuntimeException {
  static c1h(context) {
    var $this = this.ra(toString(context));
    captureStack($this, $this.b1h_1);
    return $this;
  }
}
class ListClosed extends LockFreeLinkedListNode {
  constructor(forbiddenElementsBitmask) {
    super();
    this.b1l_1 = forbiddenElementsBitmask;
  }
}
class CommonThreadLocal {
  constructor() {
    this.w12_1 = null;
  }
  x12() {
    var tmp = this.w12_1;
    return (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
  }
  y12(value) {
    this.w12_1 = value;
  }
}
//endregion
function *_generator_joinAll__v1pfh(_this__u8e3s4, $completion) {
  // Inline function 'kotlin.collections.forEach' call
  var _iterator__ex2g4s = _this__u8e3s4.y();
  while (_iterator__ex2g4s.z()) {
    var element = _iterator__ex2g4s.a1();
    var tmp = element.rv($completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }
  return Unit_instance;
}
function joinAll(_this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_joinAll__v1pfh.bind(VOID, _this__u8e3s4), $completion);
}
function *_generator_awaitAll__ivbqpv(_this__u8e3s4, $completion) {
  var tmp;
  if (_this__u8e3s4.h1()) {
    tmp = emptyList();
  } else {
    // Inline function 'kotlin.collections.toTypedArray' call
    var tmp$ret$0 = copyToArray(_this__u8e3s4);
    var tmp_0 = (new AwaitAll(tmp$ret$0)).ow($completion);
    if (tmp_0 === get_COROUTINE_SUSPENDED())
      tmp_0 = yield tmp_0;
    tmp = tmp_0;
  }
  return tmp;
}
function awaitAll(_this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_awaitAll__ivbqpv.bind(VOID, _this__u8e3s4), $completion);
}
function launch(_this__u8e3s4, context, start, block) {
  context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
  start = start === VOID ? CoroutineStart_DEFAULT_getInstance() : start;
  var newContext = newCoroutineContext(_this__u8e3s4, context);
  var coroutine = start.dy() ? new LazyStandaloneCoroutine(newContext, block) : new StandaloneCoroutine(newContext, true);
  coroutine.yu(start, coroutine, block);
  return coroutine;
}
function withContext(context, block, $completion) {
  var tmp$ret$0;
  $l$block_0: {
    var oldContext = $completion.lc();
    var newContext = newCoroutineContext_0(oldContext, context);
    ensureActive(newContext);
    if (newContext === oldContext) {
      var coroutine = new ScopeCoroutine(newContext, $completion);
      tmp$ret$0 = startUndispatchedOrReturn(coroutine, coroutine, block);
      break $l$block_0;
    }
    if (equals(newContext.yc(Key_instance), oldContext.yc(Key_instance))) {
      var coroutine_0 = new UndispatchedCoroutine(newContext, $completion);
      // Inline function 'kotlinx.coroutines.withCoroutineContext' call
      coroutine_0.ju_1;
      tmp$ret$0 = startUndispatchedOrReturn(coroutine_0, coroutine_0, block);
      break $l$block_0;
    }
    var coroutine_1 = new DispatchedCoroutine(newContext, $completion);
    startCoroutineCancellable(block, coroutine_1, coroutine_1);
    tmp$ret$0 = coroutine_1.cy();
  }
  return tmp$ret$0;
}
function async(_this__u8e3s4, context, start, block) {
  context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
  start = start === VOID ? CoroutineStart_DEFAULT_getInstance() : start;
  var newContext = newCoroutineContext(_this__u8e3s4, context);
  var coroutine = start.dy() ? new LazyDeferredCoroutine(newContext, block) : new DeferredCoroutine(newContext, true);
  coroutine.yu(start, coroutine, block);
  return coroutine;
}
function trySuspend($this) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.iy_1;
  while (true) {
    switch (this_0.kotlinx$atomicfu$value) {
      case 0:
        if ($this.iy_1.atomicfu$compareAndSet(0, 1))
          return true;
        break;
      case 2:
        return false;
      default:
        // Inline function 'kotlin.error' call

        var message = 'Already suspended';
        throw IllegalStateException.t4(toString(message));
    }
  }
}
function tryResume($this) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.iy_1;
  while (true) {
    switch (this_0.kotlinx$atomicfu$value) {
      case 0:
        if ($this.iy_1.atomicfu$compareAndSet(0, 2))
          return true;
        break;
      case 1:
        return false;
      default:
        // Inline function 'kotlin.error' call

        var message = 'Already resumed';
        throw IllegalStateException.t4(toString(message));
    }
  }
}
function *_generator_await__mos7q6($this, $completion) {
  var tmp = $this.lw($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0 = tmp;
  return (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
}
function disposeOnCancellation(_this__u8e3s4, handle) {
  return invokeOnCancellation(_this__u8e3s4, new DisposeOnCancel(handle));
}
function invokeOnCancellation(_this__u8e3s4, handler) {
  var tmp;
  if (_this__u8e3s4 instanceof CancellableContinuationImpl) {
    _this__u8e3s4.gz(handler);
    tmp = Unit_instance;
  } else {
    throw UnsupportedOperationException.da('third-party implementation of CancellableContinuation is not supported');
  }
  return tmp;
}
function getOrCreateCancellableContinuation(delegate) {
  if (!(delegate instanceof DispatchedContinuation)) {
    return new CancellableContinuationImpl(delegate, 1);
  }
  var tmp0_safe_receiver = delegate.oz();
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.takeIf' call
    var tmp_0;
    if (tmp0_safe_receiver.pz()) {
      tmp_0 = tmp0_safe_receiver;
    } else {
      tmp_0 = null;
    }
    tmp = tmp_0;
  }
  var tmp1_elvis_lhs = tmp;
  var tmp_1;
  if (tmp1_elvis_lhs == null) {
    return new CancellableContinuationImpl(delegate, 2);
  } else {
    tmp_1 = tmp1_elvis_lhs;
  }
  return tmp_1;
}
function get_RESUME_TOKEN() {
  _init_properties_CancellableContinuationImpl_kt__6rrtdd();
  return RESUME_TOKEN;
}
var RESUME_TOKEN;
function _get_parentHandle__f8dcex($this) {
  return $this.ay_1.kotlinx$atomicfu$value;
}
function _get_stateDebugRepresentation__bf18u4($this) {
  var tmp0_subject = $this.fv();
  var tmp;
  if (!(tmp0_subject == null) ? isInterface(tmp0_subject, NotCompleted) : false) {
    tmp = 'Active';
  } else {
    if (tmp0_subject instanceof CancelledContinuation) {
      tmp = 'Cancelled';
    } else {
      tmp = 'Completed';
    }
  }
  return tmp;
}
function isReusable($this) {
  var tmp;
  if (get_isReusableMode($this.rz_1)) {
    var tmp_0 = $this.wx_1;
    tmp = (tmp_0 instanceof DispatchedContinuation ? tmp_0 : THROW_CCE()).qz();
  } else {
    tmp = false;
  }
  return tmp;
}
function cancelLater($this, cause) {
  if (!isReusable($this))
    return false;
  var tmp = $this.wx_1;
  var dispatched = tmp instanceof DispatchedContinuation ? tmp : THROW_CCE();
  return dispatched.sz(cause);
}
function callSegmentOnCancellation($this, segment, cause) {
  // Inline function 'kotlinx.coroutines.index' call
  var index = $this.yx_1.kotlinx$atomicfu$value & 536870911;
  // Inline function 'kotlin.check' call
  if (!!(index === 536870911)) {
    var message = 'The index for Segment.onCancellation(..) is broken';
    throw IllegalStateException.t4(toString(message));
  }
  // Inline function 'kotlinx.coroutines.CancellableContinuationImpl.callCancelHandlerSafely' call
  try {
    segment.xz(index, cause, $this.lc());
  } catch ($p) {
    if ($p instanceof Error) {
      var ex = $p;
      handleCoroutineException($this.lc(), CompletionHandlerException.b10('Exception in invokeOnCancellation handler for ' + $this.toString(), ex));
    } else {
      throw $p;
    }
  }
}
function trySuspend_0($this) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.yx_1;
  while (true) {
    var cur = this_0.kotlinx$atomicfu$value;
    // Inline function 'kotlinx.coroutines.decision' call
    switch (cur >> 29) {
      case 0:
        // Inline function 'kotlinx.coroutines.index' call

        // Inline function 'kotlinx.coroutines.decisionAndIndex' call

        var tmp$ret$2 = (1 << 29) + (cur & 536870911) | 0;
        if ($this.yx_1.atomicfu$compareAndSet(cur, tmp$ret$2))
          return true;
        break;
      case 2:
        return false;
      default:
        // Inline function 'kotlin.error' call

        var message = 'Already suspended';
        throw IllegalStateException.t4(toString(message));
    }
  }
}
function tryResume_0($this) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.yx_1;
  while (true) {
    var cur = this_0.kotlinx$atomicfu$value;
    // Inline function 'kotlinx.coroutines.decision' call
    switch (cur >> 29) {
      case 0:
        // Inline function 'kotlinx.coroutines.index' call

        // Inline function 'kotlinx.coroutines.decisionAndIndex' call

        var tmp$ret$2 = (2 << 29) + (cur & 536870911) | 0;
        if ($this.yx_1.atomicfu$compareAndSet(cur, tmp$ret$2))
          return true;
        break;
      case 1:
        return false;
      default:
        // Inline function 'kotlin.error' call

        var message = 'Already resumed';
        throw IllegalStateException.t4(toString(message));
    }
  }
}
function installParentHandle($this) {
  var tmp0_elvis_lhs = $this.lc().yc(Key_instance_3);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var parent = tmp;
  var handle = invokeOnCompletion(parent, VOID, new ChildContinuation($this));
  $this.ay_1.atomicfu$compareAndSet(null, handle);
  return handle;
}
function invokeOnCancellationImpl($this, handler) {
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.zx_1;
  while (true) {
    var state = this_0.kotlinx$atomicfu$value;
    if (state instanceof Active) {
      if ($this.zx_1.atomicfu$compareAndSet(state, handler))
        return Unit_instance;
    } else {
      var tmp;
      if (!(state == null) ? isInterface(state, CancelHandler) : false) {
        tmp = true;
      } else {
        tmp = state instanceof Segment;
      }
      if (tmp) {
        multipleHandlersError($this, handler, state);
      } else {
        if (state instanceof CompletedExceptionally) {
          if (!state.k10()) {
            multipleHandlersError($this, handler, state);
          }
          if (state instanceof CancelledContinuation) {
            var tmp1_safe_receiver = state instanceof CompletedExceptionally ? state : null;
            var cause = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.qu_1;
            if (isInterface(handler, CancelHandler)) {
              $this.h10(handler, cause);
            } else {
              var segment = handler instanceof Segment ? handler : THROW_CCE();
              callSegmentOnCancellation($this, segment, cause);
            }
          }
          return Unit_instance;
        } else {
          if (state instanceof CompletedContinuation) {
            if (!(state.d10_1 == null)) {
              multipleHandlersError($this, handler, state);
            }
            if (handler instanceof Segment)
              return Unit_instance;
            if (!isInterface(handler, CancelHandler))
              THROW_CCE();
            if (state.i10()) {
              $this.h10(handler, state.g10_1);
              return Unit_instance;
            }
            var update = state.j10(VOID, handler);
            if ($this.zx_1.atomicfu$compareAndSet(state, update))
              return Unit_instance;
          } else {
            if (handler instanceof Segment)
              return Unit_instance;
            if (!isInterface(handler, CancelHandler))
              THROW_CCE();
            var update_0 = new CompletedContinuation(state, handler);
            if ($this.zx_1.atomicfu$compareAndSet(state, update_0))
              return Unit_instance;
          }
        }
      }
    }
  }
}
function multipleHandlersError($this, handler, state) {
  // Inline function 'kotlin.error' call
  var message = "It's prohibited to register multiple handlers, tried to register " + toString(handler) + ', already has ' + toString_0(state);
  throw IllegalStateException.t4(toString(message));
}
function dispatchResume($this, mode) {
  if (tryResume_0($this))
    return Unit_instance;
  dispatch($this, mode);
}
function resumedState($this, state, proposedUpdate, resumeMode, onCancellation, idempotent) {
  var tmp;
  if (proposedUpdate instanceof CompletedExceptionally) {
    // Inline function 'kotlinx.coroutines.assert' call
    // Inline function 'kotlinx.coroutines.assert' call
    tmp = proposedUpdate;
  } else {
    if (!get_isCancellableMode(resumeMode) && idempotent == null) {
      tmp = proposedUpdate;
    } else {
      var tmp_0;
      var tmp_1;
      if (!(onCancellation == null)) {
        tmp_1 = true;
      } else {
        tmp_1 = isInterface(state, CancelHandler);
      }
      if (tmp_1) {
        tmp_0 = true;
      } else {
        tmp_0 = !(idempotent == null);
      }
      if (tmp_0) {
        tmp = new CompletedContinuation(proposedUpdate, isInterface(state, CancelHandler) ? state : null, onCancellation, idempotent);
      } else {
        tmp = proposedUpdate;
      }
    }
  }
  return tmp;
}
function tryResumeImpl($this, proposedUpdate, idempotent, onCancellation) {
  // Inline function 'kotlinx.atomicfu.loop' call
  var this_0 = $this.zx_1;
  while (true) {
    var tmp1 = this_0.kotlinx$atomicfu$value;
    $l$block: {
      if (!(tmp1 == null) ? isInterface(tmp1, NotCompleted) : false) {
        var update = resumedState($this, tmp1, proposedUpdate, $this.rz_1, onCancellation, idempotent);
        if (!$this.zx_1.atomicfu$compareAndSet(tmp1, update)) {
          break $l$block;
        }
        detachChildIfNonReusable($this);
        return get_RESUME_TOKEN();
      } else {
        if (tmp1 instanceof CompletedContinuation) {
          var tmp;
          if (!(idempotent == null) && tmp1.f10_1 === idempotent) {
            // Inline function 'kotlinx.coroutines.assert' call
            tmp = get_RESUME_TOKEN();
          } else {
            tmp = null;
          }
          return tmp;
        } else {
          return null;
        }
      }
    }
  }
}
function alreadyResumedError($this, proposedUpdate) {
  // Inline function 'kotlin.error' call
  var message = 'Already resumed, but proposed with update ' + toString_0(proposedUpdate);
  throw IllegalStateException.t4(toString(message));
}
function detachChildIfNonReusable($this) {
  if (!isReusable($this)) {
    $this.l10();
  }
}
function CancellableContinuationImpl$resume$lambda($onCancellation) {
  return (cause, _unused_var__etf5q3, _unused_var__etf5q3_0) => {
    $onCancellation(cause);
    return Unit_instance;
  };
}
var Active_instance;
function Active_getInstance() {
  return Active_instance;
}
var properties_initialized_CancellableContinuationImpl_kt_xtzb03;
function _init_properties_CancellableContinuationImpl_kt__6rrtdd() {
  if (!properties_initialized_CancellableContinuationImpl_kt_xtzb03) {
    properties_initialized_CancellableContinuationImpl_kt_xtzb03 = true;
    RESUME_TOKEN = new Symbol('RESUME_TOKEN');
  }
}
function CompletableDeferred(parent) {
  parent = parent === VOID ? null : parent;
  return new CompletableDeferredImpl(parent);
}
function *_generator_await__mos7q6_0($this, $completion) {
  var tmp = $this.lw($completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  var tmp_0 = tmp;
  return (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
}
function toState(_this__u8e3s4, caller) {
  // Inline function 'kotlin.getOrElse' call
  var exception = Result__exceptionOrNull_impl_p6xea9(_this__u8e3s4);
  var tmp;
  if (exception == null) {
    var tmp_0 = _Result___get_value__impl__bjfvqg(_this__u8e3s4);
    tmp = (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
  } else {
    tmp = new CompletedExceptionally(recoverStackTrace(exception, caller));
  }
  return tmp;
}
function toState_0(_this__u8e3s4) {
  // Inline function 'kotlin.getOrElse' call
  var exception = Result__exceptionOrNull_impl_p6xea9(_this__u8e3s4);
  var tmp;
  if (exception == null) {
    var tmp_0 = _Result___get_value__impl__bjfvqg(_this__u8e3s4);
    tmp = (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
  } else {
    tmp = new CompletedExceptionally(exception);
  }
  return tmp;
}
function recoverResult(state, uCont) {
  var tmp;
  if (state instanceof CompletedExceptionally) {
    // Inline function 'kotlin.Companion.failure' call
    var exception = recoverStackTrace(state.qu_1, uCont);
    tmp = _Result___init__impl__xyqfz8(createFailure(exception));
  } else {
    // Inline function 'kotlin.Companion.success' call
    var value = (state == null ? true : !(state == null)) ? state : THROW_CCE();
    tmp = _Result___init__impl__xyqfz8(value);
  }
  return tmp;
}
function CoroutineDispatcher$Key$_init_$lambda_akl8b5(it) {
  return it instanceof CoroutineDispatcher ? it : null;
}
var Key_instance_0;
function Key_getInstance() {
  if (Key_instance_0 === VOID)
    new Key();
  return Key_instance_0;
}
function handleCoroutineException(context, exception) {
  var tmp;
  if (exception instanceof DispatchException) {
    tmp = exception.a12_1;
  } else {
    tmp = exception;
  }
  var reportException = tmp;
  try {
    var tmp0_safe_receiver = context.yc(Key_instance_1);
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      tmp0_safe_receiver.c12(context, reportException);
      return Unit_instance;
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var t = $p;
      handleUncaughtCoroutineException(context, handlerException(reportException, t));
      return Unit_instance;
    } else {
      throw $p;
    }
  }
  handleUncaughtCoroutineException(context, reportException);
}
var Key_instance_1;
function Key_getInstance_0() {
  return Key_instance_1;
}
function handlerException(originalException, thrownException) {
  if (originalException === thrownException)
    return originalException;
  // Inline function 'kotlin.apply' call
  var this_0 = RuntimeException.be('Exception while trying to handle coroutine exception', thrownException);
  addSuppressed(this_0, originalException);
  return this_0;
}
var Key_instance_2;
function Key_getInstance_1() {
  return Key_instance_2;
}
var GlobalScope_instance;
function GlobalScope_getInstance() {
  return GlobalScope_instance;
}
function CoroutineScope_0(context) {
  return new ContextScope(!(context.yc(Key_instance_3) == null) ? context : context.dn(Job_0()));
}
function cancel(_this__u8e3s4, message, cause) {
  cause = cause === VOID ? null : cause;
  return cancel_0(_this__u8e3s4, CancellationException_0(message, cause));
}
function cancel_0(_this__u8e3s4, cause) {
  cause = cause === VOID ? null : cause;
  var tmp0_elvis_lhs = _this__u8e3s4.ku().yc(Key_instance_3);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = 'Scope cannot be cancelled because it does not have a job: ' + toString(_this__u8e3s4);
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var job = tmp;
  job.uv(cause);
}
function coroutineScope(block, $completion) {
  var coroutine = new ScopeCoroutine($completion.lc(), $completion);
  return startUndispatchedOrReturn(coroutine, coroutine, block);
}
var CoroutineStart_DEFAULT_instance;
var CoroutineStart_LAZY_instance;
var CoroutineStart_ATOMIC_instance;
var CoroutineStart_UNDISPATCHED_instance;
var CoroutineStart_entriesInitialized;
function CoroutineStart_initEntries() {
  if (CoroutineStart_entriesInitialized)
    return Unit_instance;
  CoroutineStart_entriesInitialized = true;
  CoroutineStart_DEFAULT_instance = new CoroutineStart('DEFAULT', 0);
  CoroutineStart_LAZY_instance = new CoroutineStart('LAZY', 1);
  CoroutineStart_ATOMIC_instance = new CoroutineStart('ATOMIC', 2);
  CoroutineStart_UNDISPATCHED_instance = new CoroutineStart('UNDISPATCHED', 3);
}
function CoroutineStart_DEFAULT_getInstance() {
  CoroutineStart_initEntries();
  return CoroutineStart_DEFAULT_instance;
}
function CoroutineStart_LAZY_getInstance() {
  CoroutineStart_initEntries();
  return CoroutineStart_LAZY_instance;
}
function CoroutineStart_ATOMIC_getInstance() {
  CoroutineStart_initEntries();
  return CoroutineStart_ATOMIC_instance;
}
function get_delay(_this__u8e3s4) {
  var tmp = _this__u8e3s4.yc(Key_instance);
  var tmp0_elvis_lhs = (!(tmp == null) ? isInterface(tmp, Delay) : false) ? tmp : null;
  return tmp0_elvis_lhs == null ? get_DefaultDelay() : tmp0_elvis_lhs;
}
function delay(timeMillis, $completion) {
  if (timeMillis.s1(new Long(0, 0)) <= 0)
    return Unit_instance;
  var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
  cancellable.by();
  if (timeMillis.s1(new Long(-1, 2147483647)) < 0) {
    get_delay(cancellable.lc()).g12(timeMillis, cancellable);
  }
  return cancellable.cy();
}
function delay_0(duration, $completion) {
  return delay(toDelayMillis(duration), $completion);
}
function toDelayMillis(_this__u8e3s4) {
  var tmp;
  switch (Duration__isPositive_impl_tvkkt2(_this__u8e3s4)) {
    case true:
      Companion_getInstance();
      // Inline function 'kotlin.time.Companion.nanoseconds' call

      var this_0 = new Long(999999, 0);
      var tmp$ret$0 = toDuration(this_0, DurationUnit_NANOSECONDS_getInstance());
      tmp = _Duration___get_inWholeMilliseconds__impl__msfiry(Duration__plus_impl_yu9v8f(_this__u8e3s4, tmp$ret$0));
      break;
    case false:
      tmp = new Long(0, 0);
      break;
    default:
      noWhenBranchMatchedException();
      break;
  }
  return tmp;
}
function delta($this, unconfined) {
  return unconfined ? new Long(0, 1) : new Long(1, 0);
}
var ThreadLocalEventLoop_instance;
function ThreadLocalEventLoop_getInstance() {
  if (ThreadLocalEventLoop_instance === VOID)
    new ThreadLocalEventLoop();
  return ThreadLocalEventLoop_instance;
}
var Key_instance_3;
function Key_getInstance_2() {
  return Key_instance_3;
}
var NonDisposableHandle_instance;
function NonDisposableHandle_getInstance() {
  return NonDisposableHandle_instance;
}
function ensureActive(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.yc(Key_instance_3);
  if (tmp0_safe_receiver == null)
    null;
  else {
    ensureActive_0(tmp0_safe_receiver);
  }
}
function invokeOnCompletion(_this__u8e3s4, invokeImmediately, handler) {
  invokeImmediately = invokeImmediately === VOID ? true : invokeImmediately;
  var tmp;
  if (_this__u8e3s4 instanceof JobSupport) {
    tmp = _this__u8e3s4.qv(invokeImmediately, handler);
  } else {
    var tmp_0 = handler.fx();
    tmp = _this__u8e3s4.ov(tmp_0, invokeImmediately, JobNode$invoke$ref(handler));
  }
  return tmp;
}
function ensureActive_0(_this__u8e3s4) {
  if (!_this__u8e3s4.lu())
    throw _this__u8e3s4.kv();
}
function cancel_1(_this__u8e3s4, message, cause) {
  cause = cause === VOID ? null : cause;
  return _this__u8e3s4.uv(CancellationException_0(message, cause));
}
function get_job(_this__u8e3s4) {
  var tmp0_elvis_lhs = _this__u8e3s4.yc(Key_instance_3);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var message = "Current context doesn't contain Job in it: " + toString(_this__u8e3s4);
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function cancel_2(_this__u8e3s4, cause) {
  cause = cause === VOID ? null : cause;
  var tmp0_safe_receiver = _this__u8e3s4.yc(Key_instance_3);
  if (tmp0_safe_receiver == null)
    null;
  else {
    tmp0_safe_receiver.uv(cause);
  }
}
function Job_0(parent) {
  parent = parent === VOID ? null : parent;
  return new JobImpl(parent);
}
function get_isActive(_this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4.yc(Key_instance_3);
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.lu();
  return tmp1_elvis_lhs == null ? true : tmp1_elvis_lhs;
}
function cancelAndJoin(_this__u8e3s4, $completion) {
  _this__u8e3s4.vv();
  return _this__u8e3s4.rv($completion);
}
function disposeOnCompletion(_this__u8e3s4, handle) {
  return invokeOnCompletion(_this__u8e3s4, VOID, new DisposeOnCompletion(handle));
}
function JobNode$invoke$ref($boundThis) {
  var l = (p0) => {
    $boundThis.cx(p0);
    return Unit_instance;
  };
  l.callableName = 'invoke';
  return l;
}
function get_COMPLETING_ALREADY() {
  _init_properties_JobSupport_kt__68f172();
  return COMPLETING_ALREADY;
}
var COMPLETING_ALREADY;
function get_COMPLETING_WAITING_CHILDREN() {
  _init_properties_JobSupport_kt__68f172();
  return COMPLETING_WAITING_CHILDREN;
}
var COMPLETING_WAITING_CHILDREN;
function get_COMPLETING_RETRY() {
  _init_properties_JobSupport_kt__68f172();
  return COMPLETING_RETRY;
}
var COMPLETING_RETRY;
function get_TOO_LATE_TO_CANCEL() {
  _init_properties_JobSupport_kt__68f172();
  return TOO_LATE_TO_CANCEL;
}
var TOO_LATE_TO_CANCEL;
function get_SEALED() {
  _init_properties_JobSupport_kt__68f172();
  return SEALED;
}
var SEALED;
function get_EMPTY_NEW() {
  _init_properties_JobSupport_kt__68f172();
  return EMPTY_NEW;
}
var EMPTY_NEW;
function get_EMPTY_ACTIVE() {
  _init_properties_JobSupport_kt__68f172();
  return EMPTY_ACTIVE;
}
var EMPTY_ACTIVE;
function _set_exceptionsHolder__tqm22h($this, value) {
  $this.q13_1.kotlinx$atomicfu$value = value;
}
function _get_exceptionsHolder__nhszp($this) {
  return $this.q13_1.kotlinx$atomicfu$value;
}
function allocateList($this) {
  return ArrayList.x(4);
}
function finalizeFinishingState($this, state, proposedUpdate) {
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  var tmp0_safe_receiver = proposedUpdate instanceof CompletedExceptionally ? proposedUpdate : null;
  var proposedException = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.qu_1;
  var wasCancelling;
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  wasCancelling = state.r13();
  var exceptions = state.s13(proposedException);
  var finalCause = getFinalRootCause($this, state, exceptions);
  if (!(finalCause == null)) {
    addSuppressedExceptions($this, finalCause, exceptions);
  }
  var finalException = finalCause;
  var finalState = finalException == null ? proposedUpdate : finalException === proposedException ? proposedUpdate : new CompletedExceptionally(finalException);
  if (!(finalException == null)) {
    var handled = cancelParent($this, finalException) || $this.hw(finalException);
    if (handled) {
      (finalState instanceof CompletedExceptionally ? finalState : THROW_CCE()).k10();
    }
  }
  if (!wasCancelling) {
    $this.ew(finalException);
  }
  $this.pu(finalState);
  var casSuccess = $this.eu_1.atomicfu$compareAndSet(state, boxIncomplete(finalState));
  // Inline function 'kotlinx.coroutines.assert' call
  completeStateFinalization($this, state, finalState);
  return finalState;
}
function getFinalRootCause($this, state, exceptions) {
  if (exceptions.h1()) {
    if (state.r13()) {
      // Inline function 'kotlinx.coroutines.JobSupport.defaultCancellationException' call
      return JobCancellationException.z13(null == null ? $this.ou() : null, null, $this);
    }
    return null;
  }
  var tmp$ret$2;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var _iterator__ex2g4s = exceptions.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (!(element instanceof CancellationException)) {
        tmp$ret$2 = element;
        break $l$block;
      }
    }
    tmp$ret$2 = null;
  }
  var firstNonCancellation = tmp$ret$2;
  if (!(firstNonCancellation == null))
    return firstNonCancellation;
  var first = exceptions.f1(0);
  if (first instanceof TimeoutCancellationException) {
    var tmp$ret$4;
    $l$block_0: {
      // Inline function 'kotlin.collections.firstOrNull' call
      var _iterator__ex2g4s_0 = exceptions.y();
      while (_iterator__ex2g4s_0.z()) {
        var element_0 = _iterator__ex2g4s_0.a1();
        var tmp;
        if (!(element_0 === first)) {
          tmp = element_0 instanceof TimeoutCancellationException;
        } else {
          tmp = false;
        }
        if (tmp) {
          tmp$ret$4 = element_0;
          break $l$block_0;
        }
      }
      tmp$ret$4 = null;
    }
    var detailedTimeoutException = tmp$ret$4;
    if (!(detailedTimeoutException == null))
      return detailedTimeoutException;
  }
  return first;
}
function addSuppressedExceptions($this, rootCause, exceptions) {
  if (exceptions.b1() <= 1)
    return Unit_instance;
  var seenExceptions = identitySet(exceptions.b1());
  var unwrappedCause = unwrap(rootCause);
  var _iterator__ex2g4s = exceptions.y();
  while (_iterator__ex2g4s.z()) {
    var exception = _iterator__ex2g4s.a1();
    var unwrapped = unwrap(exception);
    var tmp;
    var tmp_0;
    if (!(unwrapped === rootCause) && !(unwrapped === unwrappedCause)) {
      tmp_0 = !(unwrapped instanceof CancellationException);
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = seenExceptions.l(unwrapped);
    } else {
      tmp = false;
    }
    if (tmp) {
      addSuppressed(rootCause, unwrapped);
    }
  }
}
function tryFinalizeSimpleState($this, state, update) {
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  if (!$this.eu_1.atomicfu$compareAndSet(state, boxIncomplete(update)))
    return false;
  $this.ew(null);
  $this.pu(update);
  completeStateFinalization($this, state, update);
  return true;
}
function completeStateFinalization($this, state, update) {
  var tmp0_safe_receiver = $this.dv();
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    tmp0_safe_receiver.bx();
    $this.cv(NonDisposableHandle_instance);
  }
  var tmp1_safe_receiver = update instanceof CompletedExceptionally ? update : null;
  var cause = tmp1_safe_receiver == null ? null : tmp1_safe_receiver.qu_1;
  if (state instanceof JobNode) {
    try {
      state.cx(cause);
    } catch ($p) {
      if ($p instanceof Error) {
        var ex = $p;
        $this.wu(CompletionHandlerException.b10('Exception in completion handler ' + state.toString() + ' for ' + $this.toString(), ex));
      } else {
        throw $p;
      }
    }
  } else {
    var tmp2_safe_receiver = state.ox();
    if (tmp2_safe_receiver == null)
      null;
    else {
      notifyCompletion($this, tmp2_safe_receiver, cause);
    }
  }
}
function notifyCancelling($this, list, cause) {
  $this.ew(cause);
  list.m13(4);
  // Inline function 'kotlinx.coroutines.JobSupport.notifyHandlers' call
  var exception = null;
  // Inline function 'kotlinx.coroutines.internal.LockFreeLinkedListHead.forEach' call
  var cur = list.px_1;
  while (!equals(cur, list)) {
    var node = cur;
    var tmp;
    if (node instanceof JobNode) {
      tmp = node.fx();
    } else {
      tmp = false;
    }
    if (tmp) {
      try {
        node.cx(cause);
      } catch ($p) {
        if ($p instanceof Error) {
          var ex = $p;
          var tmp0_safe_receiver = exception;
          var tmp_0;
          if (tmp0_safe_receiver == null) {
            tmp_0 = null;
          } else {
            // Inline function 'kotlin.apply' call
            addSuppressed(tmp0_safe_receiver, ex);
            tmp_0 = tmp0_safe_receiver;
          }
          if (tmp_0 == null) {
            // Inline function 'kotlin.run' call
            exception = CompletionHandlerException.b10('Exception in completion handler ' + node.toString() + ' for ' + $this.toString(), ex);
          }
        } else {
          throw $p;
        }
      }
    }
    cur = cur.px_1;
  }
  var tmp0_safe_receiver_0 = exception;
  if (tmp0_safe_receiver_0 == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    $this.wu(tmp0_safe_receiver_0);
  }
  cancelParent($this, cause);
}
function cancelParent($this, cause) {
  if ($this.fw())
    return true;
  var isCancellation = cause instanceof CancellationException;
  var parent = $this.dv();
  if (parent === null || parent === NonDisposableHandle_instance) {
    return isCancellation;
  }
  return parent.yv(cause) || isCancellation;
}
function notifyCompletion($this, _this__u8e3s4, cause) {
  _this__u8e3s4.m13(1);
  // Inline function 'kotlinx.coroutines.JobSupport.notifyHandlers' call
  var exception = null;
  // Inline function 'kotlinx.coroutines.internal.LockFreeLinkedListHead.forEach' call
  var cur = _this__u8e3s4.px_1;
  while (!equals(cur, _this__u8e3s4)) {
    var node = cur;
    var tmp;
    if (node instanceof JobNode) {
      tmp = true;
    } else {
      tmp = false;
    }
    if (tmp) {
      try {
        node.cx(cause);
      } catch ($p) {
        if ($p instanceof Error) {
          var ex = $p;
          var tmp0_safe_receiver = exception;
          var tmp_0;
          if (tmp0_safe_receiver == null) {
            tmp_0 = null;
          } else {
            // Inline function 'kotlin.apply' call
            addSuppressed(tmp0_safe_receiver, ex);
            tmp_0 = tmp0_safe_receiver;
          }
          if (tmp_0 == null) {
            // Inline function 'kotlin.run' call
            exception = CompletionHandlerException.b10('Exception in completion handler ' + node.toString() + ' for ' + $this.toString(), ex);
          }
        } else {
          throw $p;
        }
      }
    }
    cur = cur.px_1;
  }
  var tmp0_safe_receiver_0 = exception;
  if (tmp0_safe_receiver_0 == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    $this.wu(tmp0_safe_receiver_0);
  }
}
function startInternal($this, state) {
  if (state instanceof Empty) {
    if (state.h13_1)
      return 0;
    if (!$this.eu_1.atomicfu$compareAndSet(state, get_EMPTY_ACTIVE()))
      return -1;
    $this.jv();
    return 1;
  } else {
    if (state instanceof InactiveNodeList) {
      if (!$this.eu_1.atomicfu$compareAndSet(state, state.a14_1))
        return -1;
      $this.jv();
      return 1;
    } else {
      return 0;
    }
  }
}
function promoteEmptyToNodeList($this, state) {
  var list = new NodeList();
  var update = state.h13_1 ? list : new InactiveNodeList(list);
  $this.eu_1.atomicfu$compareAndSet(state, update);
}
function promoteSingleToNodeList($this, state) {
  state.ux(new NodeList());
  // Inline function 'kotlinx.coroutines.internal.LockFreeLinkedListNode.nextNode' call
  var list = state.px_1;
  $this.eu_1.atomicfu$compareAndSet(state, list);
}
function joinInternal($this) {
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    var state = $this.fv();
    if (!(!(state == null) ? isInterface(state, Incomplete) : false))
      return false;
    if (startInternal($this, state) >= 0)
      return true;
  }
}
function joinSuspend($this, $completion) {
  var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
  cancellable.by();
  disposeOnCancellation(cancellable, invokeOnCompletion($this, VOID, new ResumeOnCompletion(cancellable)));
  return cancellable.cy();
}
function cancelMakeCompleting($this, cause) {
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    var state = $this.fv();
    var tmp;
    if (!(!(state == null) ? isInterface(state, Incomplete) : false)) {
      tmp = true;
    } else {
      var tmp_0;
      if (state instanceof Finishing) {
        tmp_0 = state.b14();
      } else {
        tmp_0 = false;
      }
      tmp = tmp_0;
    }
    if (tmp) {
      return get_COMPLETING_ALREADY();
    }
    var proposedUpdate = new CompletedExceptionally(createCauseException($this, cause));
    var finalState = tryMakeCompleting($this, state, proposedUpdate);
    if (!(finalState === get_COMPLETING_RETRY()))
      return finalState;
  }
}
function createCauseException($this, cause) {
  var tmp;
  if (cause == null ? true : cause instanceof Error) {
    var tmp_0;
    if (cause == null) {
      // Inline function 'kotlinx.coroutines.JobSupport.defaultCancellationException' call
      tmp_0 = JobCancellationException.z13(null == null ? $this.ou() : null, null, $this);
    } else {
      tmp_0 = cause;
    }
    tmp = tmp_0;
  } else {
    tmp = ((!(cause == null) ? isInterface(cause, ParentJob) : false) ? cause : THROW_CCE()).bw();
  }
  return tmp;
}
function makeCancelling($this, cause) {
  var causeExceptionCache = null;
  // Inline function 'kotlinx.coroutines.JobSupport.loopOnState' call
  while (true) {
    var tmp1 = $this.fv();
    $l$block: {
      if (tmp1 instanceof Finishing) {
        // Inline function 'kotlinx.coroutines.internal.synchronized' call
        // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
        if (tmp1.c14())
          return get_TOO_LATE_TO_CANCEL();
        var wasCancelling = tmp1.r13();
        if (!(cause == null) || !wasCancelling) {
          var tmp0_elvis_lhs = causeExceptionCache;
          var tmp;
          if (tmp0_elvis_lhs == null) {
            // Inline function 'kotlin.also' call
            var this_0 = createCauseException($this, cause);
            causeExceptionCache = this_0;
            tmp = this_0;
          } else {
            tmp = tmp0_elvis_lhs;
          }
          var causeException = tmp;
          tmp1.d14(causeException);
        }
        // Inline function 'kotlin.takeIf' call
        var this_1 = tmp1.e14();
        var tmp_0;
        if (!wasCancelling) {
          tmp_0 = this_1;
        } else {
          tmp_0 = null;
        }
        var notifyRootCause = tmp_0;
        if (notifyRootCause == null)
          null;
        else {
          // Inline function 'kotlin.let' call
          notifyCancelling($this, tmp1.n13_1, notifyRootCause);
        }
        return get_COMPLETING_ALREADY();
      } else {
        if (!(tmp1 == null) ? isInterface(tmp1, Incomplete) : false) {
          var tmp2_elvis_lhs = causeExceptionCache;
          var tmp_1;
          if (tmp2_elvis_lhs == null) {
            // Inline function 'kotlin.also' call
            var this_2 = createCauseException($this, cause);
            causeExceptionCache = this_2;
            tmp_1 = this_2;
          } else {
            tmp_1 = tmp2_elvis_lhs;
          }
          var causeException_0 = tmp_1;
          if (tmp1.lu()) {
            if (tryMakeCancelling($this, tmp1, causeException_0))
              return get_COMPLETING_ALREADY();
          } else {
            var finalState = tryMakeCompleting($this, tmp1, new CompletedExceptionally(causeException_0));
            if (finalState === get_COMPLETING_ALREADY()) {
              // Inline function 'kotlin.error' call
              var message = 'Cannot happen in ' + toString(tmp1);
              throw IllegalStateException.t4(toString(message));
            } else if (finalState === get_COMPLETING_RETRY()) {
              break $l$block;
            } else
              return finalState;
          }
        } else {
          return get_TOO_LATE_TO_CANCEL();
        }
      }
    }
  }
}
function getOrPromoteCancellingList($this, state) {
  var tmp0_elvis_lhs = state.ox();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    var tmp_0;
    if (state instanceof Empty) {
      tmp_0 = new NodeList();
    } else {
      if (state instanceof JobNode) {
        promoteSingleToNodeList($this, state);
        tmp_0 = null;
      } else {
        var message = 'State should have list: ' + toString(state);
        throw IllegalStateException.t4(toString(message));
      }
    }
    tmp = tmp_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function tryMakeCancelling($this, state, rootCause) {
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  var tmp0_elvis_lhs = getOrPromoteCancellingList($this, state);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return false;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var list = tmp;
  var cancelling = new Finishing(list, false, rootCause);
  if (!$this.eu_1.atomicfu$compareAndSet(state, cancelling))
    return false;
  notifyCancelling($this, list, rootCause);
  return true;
}
function tryMakeCompleting($this, state, proposedUpdate) {
  if (!(!(state == null) ? isInterface(state, Incomplete) : false))
    return get_COMPLETING_ALREADY();
  var tmp;
  var tmp_0;
  var tmp_1;
  if (state instanceof Empty) {
    tmp_1 = true;
  } else {
    tmp_1 = state instanceof JobNode;
  }
  if (tmp_1) {
    tmp_0 = !(state instanceof ChildHandleNode);
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = !(proposedUpdate instanceof CompletedExceptionally);
  } else {
    tmp = false;
  }
  if (tmp) {
    if (tryFinalizeSimpleState($this, state, proposedUpdate)) {
      return proposedUpdate;
    }
    return get_COMPLETING_RETRY();
  }
  return tryMakeCompletingSlowPath($this, state, proposedUpdate);
}
function tryMakeCompletingSlowPath($this, state, proposedUpdate) {
  var tmp0_elvis_lhs = getOrPromoteCancellingList($this, state);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return get_COMPLETING_RETRY();
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var list = tmp;
  var tmp1_elvis_lhs = state instanceof Finishing ? state : null;
  var finishing = tmp1_elvis_lhs == null ? new Finishing(list, false, null) : tmp1_elvis_lhs;
  var notifyRootCause;
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  if (finishing.b14())
    return get_COMPLETING_ALREADY();
  finishing.f14(true);
  if (!(finishing === state)) {
    if (!$this.eu_1.atomicfu$compareAndSet(state, finishing))
      return get_COMPLETING_RETRY();
  }
  // Inline function 'kotlinx.coroutines.assert' call
  var wasCancelling = finishing.r13();
  var tmp0_safe_receiver = proposedUpdate instanceof CompletedExceptionally ? proposedUpdate : null;
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    finishing.d14(tmp0_safe_receiver.qu_1);
  }
  // Inline function 'kotlin.takeIf' call
  var this_0 = finishing.e14();
  var tmp_0;
  if (!wasCancelling) {
    tmp_0 = this_0;
  } else {
    tmp_0 = null;
  }
  notifyRootCause = tmp_0;
  if (notifyRootCause == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    notifyCancelling($this, list, notifyRootCause);
  }
  var child = nextChild($this, list);
  if (!(child == null) && tryWaitForChild($this, finishing, child, proposedUpdate))
    return get_COMPLETING_WAITING_CHILDREN();
  list.m13(2);
  var anotherChild = nextChild($this, list);
  if (!(anotherChild == null) && tryWaitForChild($this, finishing, anotherChild, proposedUpdate))
    return get_COMPLETING_WAITING_CHILDREN();
  return finalizeFinishingState($this, finishing, proposedUpdate);
}
function _get_exceptionOrNull__b3j7js($this, _this__u8e3s4) {
  var tmp0_safe_receiver = _this__u8e3s4 instanceof CompletedExceptionally ? _this__u8e3s4 : null;
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.qu_1;
}
function tryWaitForChild($this, state, child, proposedUpdate) {
  var $this_0 = $this;
  var state_0 = state;
  var child_0 = child;
  var proposedUpdate_0 = proposedUpdate;
  $l$1: do {
    $l$0: do {
      var handle = invokeOnCompletion(child_0.k14_1, false, new ChildCompletion($this_0, state_0, child_0, proposedUpdate_0));
      if (!(handle === NonDisposableHandle_instance))
        return true;
      var tmp0_elvis_lhs = nextChild($this_0, child_0);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        return false;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var nextChild_0 = tmp;
      var tmp0 = $this_0;
      var tmp1 = state_0;
      var tmp3 = proposedUpdate_0;
      $this_0 = tmp0;
      state_0 = tmp1;
      child_0 = nextChild_0;
      proposedUpdate_0 = tmp3;
      continue $l$0;
    }
     while (false);
  }
   while (true);
}
function continueCompleting($this, state, lastChild, proposedUpdate) {
  // Inline function 'kotlinx.coroutines.assert' call
  var waitChild = nextChild($this, lastChild);
  if (!(waitChild == null) && tryWaitForChild($this, state, waitChild, proposedUpdate))
    return Unit_instance;
  state.n13_1.m13(2);
  var waitChildAgain = nextChild($this, lastChild);
  if (!(waitChildAgain == null) && tryWaitForChild($this, state, waitChildAgain, proposedUpdate)) {
    return Unit_instance;
  }
  var finalState = finalizeFinishingState($this, state, proposedUpdate);
  $this.vu(finalState);
}
function nextChild($this, _this__u8e3s4) {
  var cur = _this__u8e3s4;
  $l$loop: while (true) {
    // Inline function 'kotlinx.coroutines.internal.LockFreeLinkedListNode.isRemoved' call
    if (!cur.rx_1) {
      break $l$loop;
    }
    // Inline function 'kotlinx.coroutines.internal.LockFreeLinkedListNode.prevNode' call
    cur = cur.qx_1;
  }
  $l$loop_0: while (true) {
    // Inline function 'kotlinx.coroutines.internal.LockFreeLinkedListNode.nextNode' call
    cur = cur.px_1;
    // Inline function 'kotlinx.coroutines.internal.LockFreeLinkedListNode.isRemoved' call
    if (cur.rx_1)
      continue $l$loop_0;
    if (cur instanceof ChildHandleNode)
      return cur;
    if (cur instanceof NodeList)
      return null;
  }
}
function stateString($this, state) {
  var tmp;
  if (state instanceof Finishing) {
    tmp = state.r13() ? 'Cancelling' : state.b14() ? 'Completing' : 'Active';
  } else {
    if (!(state == null) ? isInterface(state, Incomplete) : false) {
      tmp = state.lu() ? 'Active' : 'New';
    } else {
      if (state instanceof CompletedExceptionally) {
        tmp = 'Cancelled';
      } else {
        tmp = 'Completed';
      }
    }
  }
  return tmp;
}
function awaitSuspend($this, $completion) {
  var cont = new AwaitContinuation(intercepted($completion), $this);
  cont.by();
  disposeOnCancellation(cont, invokeOnCompletion($this, VOID, new ResumeAwaitOnCompletion(cont)));
  return cont.cy();
}
function boxIncomplete(_this__u8e3s4) {
  _init_properties_JobSupport_kt__68f172();
  var tmp;
  if (!(_this__u8e3s4 == null) ? isInterface(_this__u8e3s4, Incomplete) : false) {
    tmp = new IncompleteStateBox(_this__u8e3s4);
  } else {
    tmp = _this__u8e3s4;
  }
  return tmp;
}
function unboxState(_this__u8e3s4) {
  _init_properties_JobSupport_kt__68f172();
  var tmp0_safe_receiver = _this__u8e3s4 instanceof IncompleteStateBox ? _this__u8e3s4 : null;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.r15_1;
  return tmp1_elvis_lhs == null ? _this__u8e3s4 : tmp1_elvis_lhs;
}
function handlesExceptionF($this) {
  var tmp = $this.dv();
  var tmp0_safe_receiver = tmp instanceof ChildHandleNode ? tmp : null;
  var tmp1_elvis_lhs = tmp0_safe_receiver == null ? null : tmp0_safe_receiver.nx();
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    return false;
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var parentJob = tmp_0;
  while (true) {
    if (parentJob.gw())
      return true;
    var tmp_1 = parentJob.dv();
    var tmp2_safe_receiver = tmp_1 instanceof ChildHandleNode ? tmp_1 : null;
    var tmp3_elvis_lhs = tmp2_safe_receiver == null ? null : tmp2_safe_receiver.nx();
    var tmp_2;
    if (tmp3_elvis_lhs == null) {
      return false;
    } else {
      tmp_2 = tmp3_elvis_lhs;
    }
    parentJob = tmp_2;
  }
}
var properties_initialized_JobSupport_kt_5iq8a4;
function _init_properties_JobSupport_kt__68f172() {
  if (!properties_initialized_JobSupport_kt_5iq8a4) {
    properties_initialized_JobSupport_kt_5iq8a4 = true;
    COMPLETING_ALREADY = new Symbol('COMPLETING_ALREADY');
    COMPLETING_WAITING_CHILDREN = new Symbol('COMPLETING_WAITING_CHILDREN');
    COMPLETING_RETRY = new Symbol('COMPLETING_RETRY');
    TOO_LATE_TO_CANCEL = new Symbol('TOO_LATE_TO_CANCEL');
    SEALED = new Symbol('SEALED');
    EMPTY_NEW = new Empty(false);
    EMPTY_ACTIVE = new Empty(true);
  }
}
var NonCancellable_instance;
function NonCancellable_getInstance() {
  if (NonCancellable_instance === VOID)
    new NonCancellable();
  return NonCancellable_instance;
}
function SupervisorJob(parent) {
  parent = parent === VOID ? null : parent;
  return new SupervisorJobImpl(parent);
}
function withTimeout(timeMillis, block, $completion) {
  if (timeMillis.s1(new Long(0, 0)) <= 0)
    throw TimeoutCancellationException.u16('Timed out immediately');
  return setupTimeout(new TimeoutCoroutine(timeMillis, $completion), block);
}
function setupTimeout(coroutine, block) {
  var cont = coroutine.ty_1;
  var context = cont.lc();
  disposeOnCompletion(coroutine, get_delay(context).h12(coroutine.z16_1, coroutine, coroutine.ju_1));
  return startUndispatchedOrReturnIgnoreTimeout(coroutine, coroutine, block);
}
function TimeoutCancellationException_0(time, delay, coroutine) {
  var tmp0_safe_receiver = isInterface(delay, DelayWithTimeoutDiagnostics) ? delay : null;
  var tmp;
  if (tmp0_safe_receiver == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.time.Companion.milliseconds' call
    Companion_getInstance();
    var tmp$ret$0 = toDuration(time, DurationUnit_MILLISECONDS_getInstance());
    tmp = tmp0_safe_receiver.i12(tmp$ret$0);
  }
  var tmp1_elvis_lhs = tmp;
  var message = tmp1_elvis_lhs == null ? 'Timed out waiting for ' + time.toString() + ' ms' : tmp1_elvis_lhs;
  return TimeoutCancellationException.t16(message, coroutine);
}
function withTimeout_0(timeout, block, $completion) {
  return withTimeout(toDelayMillis(timeout), block, $completion);
}
function *_generator_withTimeoutOrNull__chm0fj(timeMillis, block, $completion) {
  if (timeMillis.s1(new Long(0, 0)) <= 0)
    return null;
  var coroutine = {_v: null};
  try {
    // Inline function 'kotlin.js.suspendCoroutineUninterceptedOrReturnJS' call
    var timeoutCoroutine = new TimeoutCoroutine(timeMillis, $completion);
    coroutine._v = timeoutCoroutine;
    var tmp$ret$0 = setupTimeout(timeoutCoroutine, block);
    var tmp = returnIfSuspended(tmp$ret$0, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
    return tmp;
  } catch ($p) {
    if ($p instanceof TimeoutCancellationException) {
      var e = $p;
      if (e.r16_1 === coroutine._v) {
        return null;
      }
      throw e;
    } else {
      throw $p;
    }
  }
}
function withTimeoutOrNull(timeMillis, block, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_withTimeoutOrNull__chm0fj.bind(VOID, timeMillis, block), $completion);
}
function withTimeoutOrNull_0(timeout, block, $completion) {
  return withTimeoutOrNull(toDelayMillis(timeout), block, $completion);
}
var Unconfined_instance;
function Unconfined_getInstance() {
  if (Unconfined_instance === VOID)
    new Unconfined();
  return Unconfined_instance;
}
var Key_instance_4;
function Key_getInstance_3() {
  return Key_instance_4;
}
var BufferOverflow_SUSPEND_instance;
var BufferOverflow_DROP_OLDEST_instance;
var BufferOverflow_DROP_LATEST_instance;
var BufferOverflow_entriesInitialized;
function BufferOverflow_initEntries() {
  if (BufferOverflow_entriesInitialized)
    return Unit_instance;
  BufferOverflow_entriesInitialized = true;
  BufferOverflow_SUSPEND_instance = new BufferOverflow('SUSPEND', 0);
  BufferOverflow_DROP_OLDEST_instance = new BufferOverflow('DROP_OLDEST', 1);
  BufferOverflow_DROP_LATEST_instance = new BufferOverflow('DROP_LATEST', 2);
}
function BufferOverflow_SUSPEND_getInstance() {
  BufferOverflow_initEntries();
  return BufferOverflow_SUSPEND_instance;
}
function BufferOverflow_DROP_OLDEST_getInstance() {
  BufferOverflow_initEntries();
  return BufferOverflow_DROP_OLDEST_instance;
}
function BufferOverflow_DROP_LATEST_getInstance() {
  BufferOverflow_initEntries();
  return BufferOverflow_DROP_LATEST_instance;
}
function get_NULL_SEGMENT() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return NULL_SEGMENT;
}
var NULL_SEGMENT;
function get_SEGMENT_SIZE() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return SEGMENT_SIZE;
}
var SEGMENT_SIZE;
function get_EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS;
}
var EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS;
function get_BUFFERED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return BUFFERED;
}
var BUFFERED;
function get_IN_BUFFER() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return IN_BUFFER;
}
var IN_BUFFER;
function get_RESUMING_BY_RCV() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return RESUMING_BY_RCV;
}
var RESUMING_BY_RCV;
function get_RESUMING_BY_EB() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return RESUMING_BY_EB;
}
var RESUMING_BY_EB;
function get_POISONED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return POISONED;
}
var POISONED;
function get_DONE_RCV() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return DONE_RCV;
}
var DONE_RCV;
function get_INTERRUPTED_SEND() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return INTERRUPTED_SEND;
}
var INTERRUPTED_SEND;
function get_INTERRUPTED_RCV() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return INTERRUPTED_RCV;
}
var INTERRUPTED_RCV;
function get_CHANNEL_CLOSED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return CHANNEL_CLOSED;
}
var CHANNEL_CLOSED;
function get_SUSPEND() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return SUSPEND;
}
var SUSPEND;
function get_SUSPEND_NO_WAITER() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return SUSPEND_NO_WAITER;
}
var SUSPEND_NO_WAITER;
function get_FAILED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return FAILED;
}
var FAILED;
function get_NO_RECEIVE_RESULT() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return NO_RECEIVE_RESULT;
}
var NO_RECEIVE_RESULT;
function get_CLOSE_HANDLER_CLOSED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return CLOSE_HANDLER_CLOSED;
}
var CLOSE_HANDLER_CLOSED;
function get_CLOSE_HANDLER_INVOKED() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return CLOSE_HANDLER_INVOKED;
}
var CLOSE_HANDLER_INVOKED;
function get_NO_CLOSE_CAUSE() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return NO_CLOSE_CAUSE;
}
var NO_CLOSE_CAUSE;
function setElementLazy($this, index, value) {
  // Inline function 'kotlinx.atomicfu.AtomicRef.lazySet' call
  $this.i17_1.atomicfu$get(imul(index, 2)).kotlinx$atomicfu$value = value;
}
function *_generator_hasNext__q471nr($this, $completion) {
  var tmp;
  if (!($this.t18_1 === get_NO_RECEIVE_RESULT()) && !($this.t18_1 === get_CHANNEL_CLOSED())) {
    tmp = true;
  } else {
    var tmp0 = $this.v18_1;
    var tmp$ret$1;
    $l$block_0: {
      // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImpl' call
      var segment = tmp0.a18_1.kotlinx$atomicfu$value;
      $l$loop_0: while (true) {
        if (tmp0.w18()) {
          tmp$ret$1 = onClosedHasNext($this);
          break $l$block_0;
        }
        var r = tmp0.w17_1.atomicfu$getAndIncrement$long();
        // Inline function 'kotlin.Long.div' call
        var other = get_SEGMENT_SIZE();
        var id = r.x3(toLong(other));
        // Inline function 'kotlin.Long.rem' call
        var other_0 = get_SEGMENT_SIZE();
        var i = r.y3(toLong(other_0)).x1();
        if (!segment.vz_1.equals(id)) {
          var tmp0_elvis_lhs = findSegmentReceive(tmp0, id, segment);
          var tmp_0;
          if (tmp0_elvis_lhs == null) {
            continue $l$loop_0;
          } else {
            tmp_0 = tmp0_elvis_lhs;
          }
          segment = tmp_0;
        }
        var updCellResult = updateCellReceive(tmp0, segment, i, r, null);
        var tmp_1;
        if (updCellResult === get_SUSPEND()) {
          var tmp1_safe_receiver = (!(null == null) ? isInterface(null, Waiter) : false) ? null : null;
          if (tmp1_safe_receiver == null)
            null;
          else {
            prepareReceiverForSuspension(tmp0, tmp1_safe_receiver, segment, i);
          }
          var message = 'unreachable';
          throw IllegalStateException.t4(toString(message));
        } else if (updCellResult === get_FAILED()) {
          if (r.s1(tmp0.x18()) < 0) {
            segment.r18();
          }
          continue $l$loop_0;
        } else if (updCellResult === get_SUSPEND_NO_WAITER()) {
          var segm = segment;
          var tmp_2 = hasNextOnNoWaiterSuspend($this, segm, i, r, $completion);
          if (tmp_2 === get_COROUTINE_SUSPENDED())
            tmp_2 = yield tmp_2;
          return tmp_2;
        } else {
          segment.r18();
          $this.t18_1 = (updCellResult == null ? true : !(updCellResult == null)) ? updCellResult : THROW_CCE();
          tmp_1 = true;
        }
        tmp$ret$1 = tmp_1;
        break $l$block_0;
      }
    }
    tmp = tmp$ret$1;
  }
  return tmp;
}
function onClosedHasNext($this) {
  $this.t18_1 = get_CHANNEL_CLOSED();
  var tmp0_elvis_lhs = $this.v18_1.y18();
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return false;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var cause = tmp;
  throw recoverStackTrace_0(cause);
}
function hasNextOnNoWaiterSuspend($this, segment, index, r, $completion) {
  var cancellable = getOrCreateCancellableContinuation(intercepted($completion));
  try {
    $this.u18_1 = cancellable;
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImplOnNoWaiter' call
    var this_0 = $this.v18_1;
    var updCellResult = updateCellReceive(this_0, segment, index, r, $this);
    if (updCellResult === get_SUSPEND()) {
      prepareReceiverForSuspension(this_0, $this, segment, index);
    } else if (updCellResult === get_FAILED()) {
      if (r.s1(this_0.x18()) < 0) {
        segment.r18();
      }
      $l$block_0: {
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImpl' call
        var segment_0 = this_0.a18_1.kotlinx$atomicfu$value;
        $l$loop_0: while (true) {
          if (this_0.w18()) {
            onClosedHasNextNoWaiterSuspend($this);
            break $l$block_0;
          }
          var r_0 = this_0.w17_1.atomicfu$getAndIncrement$long();
          // Inline function 'kotlin.Long.div' call
          var other = get_SEGMENT_SIZE();
          var id = r_0.x3(toLong(other));
          // Inline function 'kotlin.Long.rem' call
          var other_0 = get_SEGMENT_SIZE();
          var i = r_0.y3(toLong(other_0)).x1();
          if (!segment_0.vz_1.equals(id)) {
            var tmp0_elvis_lhs = findSegmentReceive(this_0, id, segment_0);
            var tmp;
            if (tmp0_elvis_lhs == null) {
              continue $l$loop_0;
            } else {
              tmp = tmp0_elvis_lhs;
            }
            segment_0 = tmp;
          }
          var updCellResult_0 = updateCellReceive(this_0, segment_0, i, r_0, $this);
          if (updCellResult_0 === get_SUSPEND()) {
            var tmp1_safe_receiver = (!($this == null) ? isInterface($this, Waiter) : false) ? $this : null;
            if (tmp1_safe_receiver == null)
              null;
            else {
              prepareReceiverForSuspension(this_0, tmp1_safe_receiver, segment_0, i);
            }
          } else if (updCellResult_0 === get_FAILED()) {
            if (r_0.s1(this_0.x18()) < 0) {
              segment_0.r18();
            }
            continue $l$loop_0;
          } else if (updCellResult_0 === get_SUSPEND_NO_WAITER()) {
            // Inline function 'kotlin.error' call
            var message = 'unexpected';
            throw IllegalStateException.t4(toString(message));
          } else {
            segment_0.r18();
            var element = (updCellResult_0 == null ? true : !(updCellResult_0 == null)) ? updCellResult_0 : THROW_CCE();
            $this.t18_1 = element;
            $this.u18_1 = null;
            var tmp0_safe_receiver = $this.v18_1.u17_1;
            cancellable.fz(true, tmp0_safe_receiver == null ? null : bindCancellationFun($this.v18_1, tmp0_safe_receiver, element));
          }
          break $l$block_0;
        }
      }
    } else {
      segment.r18();
      var element_0 = (updCellResult == null ? true : !(updCellResult == null)) ? updCellResult : THROW_CCE();
      $this.t18_1 = element_0;
      $this.u18_1 = null;
      var tmp0_safe_receiver_0 = $this.v18_1.u17_1;
      cancellable.fz(true, tmp0_safe_receiver_0 == null ? null : bindCancellationFun($this.v18_1, tmp0_safe_receiver_0, element_0));
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      cancellable.u10();
      throw e;
    } else {
      throw $p;
    }
  }
  return cancellable.cy();
}
function onClosedHasNextNoWaiterSuspend($this) {
  var cont = ensureNotNull($this.u18_1);
  $this.u18_1 = null;
  $this.t18_1 = get_CHANNEL_CLOSED();
  var cause = $this.v18_1.y18();
  if (cause == null) {
    // Inline function 'kotlin.coroutines.resume' call
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(false);
    cont.nc(tmp$ret$0);
  } else {
    // Inline function 'kotlin.coroutines.resumeWithException' call
    // Inline function 'kotlin.Companion.failure' call
    var exception = recoverStackTrace(cause, cont);
    var tmp$ret$2 = _Result___init__impl__xyqfz8(createFailure(exception));
    cont.nc(tmp$ret$2);
  }
}
function _get_bufferEndCounter__2d4hee($this) {
  return $this.x17_1.kotlinx$atomicfu$value;
}
function _get_isRendezvousOrUnlimited__3mdufi($this) {
  // Inline function 'kotlin.let' call
  var it = _get_bufferEndCounter__2d4hee($this);
  return it.equals(new Long(0, 0)) || it.equals(new Long(-1, 2147483647));
}
function *_generator_send__qhx0g0($this, element, $completion) {
  $l$block_5: {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.sendImpl' call
    var segment = $this.z17_1.kotlinx$atomicfu$value;
    $l$loop_0: while (true) {
      var sendersAndCloseStatusCur = $this.v17_1.atomicfu$getAndIncrement$long();
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
      var s = sendersAndCloseStatusCur.h4(new Long(-1, 268435455));
      var closed = _get_isClosedForSend0__kxgf9m($this, sendersAndCloseStatusCur);
      // Inline function 'kotlin.Long.div' call
      var other = get_SEGMENT_SIZE();
      var id = s.x3(toLong(other));
      // Inline function 'kotlin.Long.rem' call
      var other_0 = get_SEGMENT_SIZE();
      var i = s.y3(toLong(other_0)).x1();
      if (!segment.vz_1.equals(id)) {
        var tmp0_elvis_lhs = findSegmentSend($this, id, segment);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          var tmp_0;
          if (closed) {
            var tmp_1 = onClosedSend($this, element, $completion);
            if (tmp_1 === get_COROUTINE_SUSPENDED())
              tmp_1 = yield tmp_1;
            break $l$block_5;
          } else {
            continue $l$loop_0;
          }
        } else {
          tmp = tmp0_elvis_lhs;
        }
        segment = tmp;
      }
      switch (updateCellSend($this, segment, i, element, s, null, closed)) {
        case 0:
          segment.r18();
          break $l$block_5;
        case 1:
          break $l$block_5;
        case 2:
          if (closed) {
            segment.h18();
            var tmp_2 = onClosedSend($this, element, $completion);
            if (tmp_2 === get_COROUTINE_SUSPENDED())
              tmp_2 = yield tmp_2;
            break $l$block_5;
          }

          var tmp2_safe_receiver = (!(null == null) ? isInterface(null, Waiter) : false) ? null : null;
          if (tmp2_safe_receiver == null)
            null;
          else {
            prepareSenderForSuspension($this, tmp2_safe_receiver, segment, i);
          }

          // Inline function 'kotlinx.coroutines.assert' call

          break $l$block_5;
        case 4:
          if (s.s1($this.z18()) < 0) {
            segment.r18();
          }

          var tmp_3 = onClosedSend($this, element, $completion);
          if (tmp_3 === get_COROUTINE_SUSPENDED())
            tmp_3 = yield tmp_3;
          break $l$block_5;
        case 5:
          segment.r18();
          continue $l$loop_0;
        case 3:
          var segm = segment;
          var tmp_4 = sendOnNoWaiterSuspend($this, segm, i, element, s, $completion);
          if (tmp_4 === get_COROUTINE_SUSPENDED())
            tmp_4 = yield tmp_4;
          break $l$block_5;
      }
    }
  }
  return Unit_instance;
}
function onClosedSend($this, element, $completion) {
  var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
  cancellable.by();
  $l$block: {
    var tmp0_safe_receiver = $this.u17_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : callUndeliveredElementCatchingException(tmp0_safe_receiver, element);
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      addSuppressed(tmp1_safe_receiver, $this.a19());
      // Inline function 'kotlinx.coroutines.resumeWithStackTrace' call
      // Inline function 'kotlin.Companion.failure' call
      var exception = recoverStackTrace(tmp1_safe_receiver, cancellable);
      var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception));
      cancellable.nc(tmp$ret$0);
      break $l$block;
    }
    // Inline function 'kotlinx.coroutines.resumeWithStackTrace' call
    var exception_0 = $this.a19();
    // Inline function 'kotlin.Companion.failure' call
    var exception_1 = recoverStackTrace(exception_0, cancellable);
    var tmp$ret$4 = _Result___init__impl__xyqfz8(createFailure(exception_1));
    cancellable.nc(tmp$ret$4);
  }
  return cancellable.cy();
}
function sendOnNoWaiterSuspend($this, segment, index, element, s, $completion) {
  var cancellable = getOrCreateCancellableContinuation(intercepted($completion));
  try {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.sendImplOnNoWaiter' call
    switch (updateCellSend($this, segment, index, element, s, cancellable, false)) {
      case 0:
        segment.r18();
        // Inline function 'kotlin.coroutines.resume' call

        // Inline function 'kotlin.Companion.success' call

        var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
        cancellable.nc(tmp$ret$0);
        break;
      case 1:
        // Inline function 'kotlin.coroutines.resume' call

        // Inline function 'kotlin.Companion.success' call

        var tmp$ret$3 = _Result___init__impl__xyqfz8(Unit_instance);
        cancellable.nc(tmp$ret$3);
        break;
      case 2:
        prepareSenderForSuspension($this, cancellable, segment, index);
        break;
      case 4:
        if (s.s1($this.z18()) < 0) {
          segment.r18();
        }

        onClosedSendOnNoWaiterSuspend($this, element, cancellable);
        break;
      case 5:
        segment.r18();
        $l$block_5: {
          // Inline function 'kotlinx.coroutines.channels.BufferedChannel.sendImpl' call
          var segment_0 = $this.z17_1.kotlinx$atomicfu$value;
          $l$loop_0: while (true) {
            var sendersAndCloseStatusCur = $this.v17_1.atomicfu$getAndIncrement$long();
            // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
            var s_0 = sendersAndCloseStatusCur.h4(new Long(-1, 268435455));
            var closed = _get_isClosedForSend0__kxgf9m($this, sendersAndCloseStatusCur);
            // Inline function 'kotlin.Long.div' call
            var other = get_SEGMENT_SIZE();
            var id = s_0.x3(toLong(other));
            // Inline function 'kotlin.Long.rem' call
            var other_0 = get_SEGMENT_SIZE();
            var i = s_0.y3(toLong(other_0)).x1();
            if (!segment_0.vz_1.equals(id)) {
              var tmp0_elvis_lhs = findSegmentSend($this, id, segment_0);
              var tmp;
              if (tmp0_elvis_lhs == null) {
                var tmp_0;
                if (closed) {
                  onClosedSendOnNoWaiterSuspend($this, element, cancellable);
                  break $l$block_5;
                } else {
                  continue $l$loop_0;
                }
              } else {
                tmp = tmp0_elvis_lhs;
              }
              segment_0 = tmp;
            }
            switch (updateCellSend($this, segment_0, i, element, s_0, cancellable, closed)) {
              case 0:
                segment_0.r18();
                // Inline function 'kotlin.coroutines.resume' call

                // Inline function 'kotlin.Companion.success' call

                var tmp$ret$12 = _Result___init__impl__xyqfz8(Unit_instance);
                cancellable.nc(tmp$ret$12);
                break $l$block_5;
              case 1:
                // Inline function 'kotlin.coroutines.resume' call

                // Inline function 'kotlin.Companion.success' call

                var tmp$ret$15 = _Result___init__impl__xyqfz8(Unit_instance);
                cancellable.nc(tmp$ret$15);
                break $l$block_5;
              case 2:
                if (closed) {
                  segment_0.h18();
                  onClosedSendOnNoWaiterSuspend($this, element, cancellable);
                  break $l$block_5;
                }

                var tmp2_safe_receiver = (!(cancellable == null) ? isInterface(cancellable, Waiter) : false) ? cancellable : null;
                if (tmp2_safe_receiver == null)
                  null;
                else {
                  prepareSenderForSuspension($this, tmp2_safe_receiver, segment_0, i);
                }

                break $l$block_5;
              case 4:
                if (s_0.s1($this.z18()) < 0) {
                  segment_0.r18();
                }

                onClosedSendOnNoWaiterSuspend($this, element, cancellable);
                break $l$block_5;
              case 5:
                segment_0.r18();
                continue $l$loop_0;
              case 3:
                // Inline function 'kotlin.error' call

                var message = 'unexpected';
                throw IllegalStateException.t4(toString(message));
            }
          }
        }

        break;
      default:
        // Inline function 'kotlin.error' call

        var message_0 = 'unexpected';
        throw IllegalStateException.t4(toString(message_0));
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      cancellable.u10();
      throw e;
    } else {
      throw $p;
    }
  }
  return cancellable.cy();
}
function prepareSenderForSuspension($this, _this__u8e3s4, segment, index) {
  _this__u8e3s4.a11(segment, index + get_SEGMENT_SIZE() | 0);
}
function onClosedSendOnNoWaiterSuspend($this, element, cont) {
  var tmp0_safe_receiver = $this.u17_1;
  if (tmp0_safe_receiver == null)
    null;
  else {
    callUndeliveredElement(tmp0_safe_receiver, element, cont.lc());
  }
  // Inline function 'kotlin.coroutines.resumeWithException' call
  // Inline function 'kotlin.Companion.failure' call
  var exception = recoverStackTrace($this.a19(), cont);
  var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception));
  cont.nc(tmp$ret$0);
}
function updateCellSend($this, segment, index, element, s, waiter, closed) {
  segment.l17(index, element);
  if (closed)
    return updateCellSendSlow($this, segment, index, element, s, waiter, closed);
  var state = segment.p17(index);
  if (state === null) {
    if (bufferOrRendezvousSend($this, s)) {
      if (segment.r17(index, null, get_BUFFERED())) {
        return 1;
      }
    } else {
      if (waiter == null) {
        return 3;
      } else {
        if (segment.r17(index, null, waiter))
          return 2;
      }
    }
  } else {
    if (!(state == null) ? isInterface(state, Waiter) : false) {
      segment.o17(index);
      var tmp;
      if (tryResumeReceiver($this, state, element)) {
        segment.q17(index, get_DONE_RCV());
        $this.b19();
        tmp = 0;
      } else {
        if (!(segment.s17(index, get_INTERRUPTED_RCV()) === get_INTERRUPTED_RCV())) {
          segment.f18(index, true);
        }
        tmp = 5;
      }
      return tmp;
    }
  }
  return updateCellSendSlow($this, segment, index, element, s, waiter, closed);
}
function updateCellSendSlow($this, segment, index, element, s, waiter, closed) {
  while (true) {
    var state = segment.p17(index);
    if (state === null) {
      if (bufferOrRendezvousSend($this, s) && !closed) {
        if (segment.r17(index, null, get_BUFFERED())) {
          return 1;
        }
      } else {
        if (closed) {
          if (segment.r17(index, null, get_INTERRUPTED_SEND())) {
            segment.f18(index, false);
            return 4;
          }
        } else if (waiter == null)
          return 3;
        else if (segment.r17(index, null, waiter))
          return 2;
      }
    } else if (state === get_IN_BUFFER()) {
      if (segment.r17(index, state, get_BUFFERED())) {
        return 1;
      }
    } else if (state === get_INTERRUPTED_RCV()) {
      segment.o17(index);
      return 5;
    } else if (state === get_POISONED()) {
      segment.o17(index);
      return 5;
    } else if (state === get_CHANNEL_CLOSED()) {
      segment.o17(index);
      completeCloseOrCancel($this);
      return 4;
    } else {
      // Inline function 'kotlinx.coroutines.assert' call
      segment.o17(index);
      var tmp;
      if (state instanceof WaiterEB) {
        tmp = state.c19_1;
      } else {
        tmp = state;
      }
      var receiver = tmp;
      var tmp_0;
      if (tryResumeReceiver($this, receiver, element)) {
        segment.q17(index, get_DONE_RCV());
        $this.b19();
        tmp_0 = 0;
      } else {
        if (!(segment.s17(index, get_INTERRUPTED_RCV()) === get_INTERRUPTED_RCV())) {
          segment.f18(index, true);
        }
        tmp_0 = 5;
      }
      return tmp_0;
    }
  }
}
function shouldSendSuspend0($this, curSendersAndCloseStatus) {
  if (_get_isClosedForSend0__kxgf9m($this, curSendersAndCloseStatus))
    return false;
  // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
  var tmp$ret$0 = curSendersAndCloseStatus.h4(new Long(-1, 268435455));
  return !bufferOrRendezvousSend($this, tmp$ret$0);
}
function bufferOrRendezvousSend($this, curSenders) {
  var tmp;
  if (curSenders.s1(_get_bufferEndCounter__2d4hee($this)) < 0) {
    tmp = true;
  } else {
    var tmp0 = $this.z18();
    // Inline function 'kotlin.Long.plus' call
    var other = $this.t17_1;
    var tmp$ret$0 = tmp0.u3(toLong(other));
    tmp = curSenders.s1(tmp$ret$0) < 0;
  }
  return tmp;
}
function tryResumeReceiver($this, _this__u8e3s4, element) {
  var tmp;
  if (isInterface(_this__u8e3s4, SelectInstance)) {
    tmp = _this__u8e3s4.h19($this, element);
  } else {
    if (_this__u8e3s4 instanceof ReceiveCatching) {
      if (!(_this__u8e3s4 instanceof ReceiveCatching))
        THROW_CCE();
      var tmp_0 = Companion_getInstance_0().f19(element);
      var tmp1_safe_receiver = $this.u17_1;
      tmp = tryResume0(_this__u8e3s4.g19_1, new ChannelResult(tmp_0), tmp1_safe_receiver == null ? null : bindCancellationFunResult($this, tmp1_safe_receiver));
    } else {
      if (_this__u8e3s4 instanceof BufferedChannelIterator) {
        if (!(_this__u8e3s4 instanceof BufferedChannelIterator))
          THROW_CCE();
        tmp = _this__u8e3s4.d19(element);
      } else {
        if (isInterface(_this__u8e3s4, CancellableContinuation)) {
          if (!isInterface(_this__u8e3s4, CancellableContinuation))
            THROW_CCE();
          var tmp2_safe_receiver = $this.u17_1;
          tmp = tryResume0(_this__u8e3s4, element, tmp2_safe_receiver == null ? null : bindCancellationFun_0($this, tmp2_safe_receiver));
        } else {
          var message = 'Unexpected receiver type: ' + toString(_this__u8e3s4);
          throw IllegalStateException.t4(toString(message));
        }
      }
    }
  }
  return tmp;
}
function *_generator_receive__aoggq9($this, $completion) {
  var tmp$ret$0;
  $l$block: {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImpl' call
    var segment = $this.a18_1.kotlinx$atomicfu$value;
    $l$loop_0: while (true) {
      if ($this.w18()) {
        throw recoverStackTrace_0(_get_receiveException__foorc1($this));
      }
      var r = $this.w17_1.atomicfu$getAndIncrement$long();
      // Inline function 'kotlin.Long.div' call
      var other = get_SEGMENT_SIZE();
      var id = r.x3(toLong(other));
      // Inline function 'kotlin.Long.rem' call
      var other_0 = get_SEGMENT_SIZE();
      var i = r.y3(toLong(other_0)).x1();
      if (!segment.vz_1.equals(id)) {
        var tmp0_elvis_lhs = findSegmentReceive($this, id, segment);
        var tmp;
        if (tmp0_elvis_lhs == null) {
          continue $l$loop_0;
        } else {
          tmp = tmp0_elvis_lhs;
        }
        segment = tmp;
      }
      var updCellResult = updateCellReceive($this, segment, i, r, null);
      var tmp_0;
      if (updCellResult === get_SUSPEND()) {
        var tmp1_safe_receiver = (!(null == null) ? isInterface(null, Waiter) : false) ? null : null;
        if (tmp1_safe_receiver == null)
          null;
        else {
          prepareReceiverForSuspension($this, tmp1_safe_receiver, segment, i);
        }
        var message = 'unexpected';
        throw IllegalStateException.t4(toString(message));
      } else if (updCellResult === get_FAILED()) {
        if (r.s1($this.x18()) < 0) {
          segment.r18();
        }
        continue $l$loop_0;
      } else if (updCellResult === get_SUSPEND_NO_WAITER()) {
        var segm = segment;
        var tmp_1 = receiveOnNoWaiterSuspend($this, segm, i, r, $completion);
        if (tmp_1 === get_COROUTINE_SUSPENDED())
          tmp_1 = yield tmp_1;
        tmp_0 = tmp_1;
      } else {
        segment.r18();
        return (updCellResult == null ? true : !(updCellResult == null)) ? updCellResult : THROW_CCE();
      }
      tmp$ret$0 = tmp_0;
      break $l$block;
    }
  }
  return tmp$ret$0;
}
function receiveOnNoWaiterSuspend($this, segment, index, r, $completion) {
  var cancellable = getOrCreateCancellableContinuation(intercepted($completion));
  try {
    // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImplOnNoWaiter' call
    var updCellResult = updateCellReceive($this, segment, index, r, cancellable);
    if (updCellResult === get_SUSPEND()) {
      prepareReceiverForSuspension($this, cancellable, segment, index);
    } else if (updCellResult === get_FAILED()) {
      if (r.s1($this.x18()) < 0) {
        segment.r18();
      }
      $l$block_0: {
        // Inline function 'kotlinx.coroutines.channels.BufferedChannel.receiveImpl' call
        var segment_0 = $this.a18_1.kotlinx$atomicfu$value;
        $l$loop_0: while (true) {
          if ($this.w18()) {
            onClosedReceiveOnNoWaiterSuspend($this, cancellable);
            break $l$block_0;
          }
          var r_0 = $this.w17_1.atomicfu$getAndIncrement$long();
          // Inline function 'kotlin.Long.div' call
          var other = get_SEGMENT_SIZE();
          var id = r_0.x3(toLong(other));
          // Inline function 'kotlin.Long.rem' call
          var other_0 = get_SEGMENT_SIZE();
          var i = r_0.y3(toLong(other_0)).x1();
          if (!segment_0.vz_1.equals(id)) {
            var tmp0_elvis_lhs = findSegmentReceive($this, id, segment_0);
            var tmp;
            if (tmp0_elvis_lhs == null) {
              continue $l$loop_0;
            } else {
              tmp = tmp0_elvis_lhs;
            }
            segment_0 = tmp;
          }
          var updCellResult_0 = updateCellReceive($this, segment_0, i, r_0, cancellable);
          if (updCellResult_0 === get_SUSPEND()) {
            var tmp1_safe_receiver = (!(cancellable == null) ? isInterface(cancellable, Waiter) : false) ? cancellable : null;
            if (tmp1_safe_receiver == null)
              null;
            else {
              prepareReceiverForSuspension($this, tmp1_safe_receiver, segment_0, i);
            }
          } else if (updCellResult_0 === get_FAILED()) {
            if (r_0.s1($this.x18()) < 0) {
              segment_0.r18();
            }
            continue $l$loop_0;
          } else if (updCellResult_0 === get_SUSPEND_NO_WAITER()) {
            // Inline function 'kotlin.error' call
            var message = 'unexpected';
            throw IllegalStateException.t4(toString(message));
          } else {
            segment_0.r18();
            var element = (updCellResult_0 == null ? true : !(updCellResult_0 == null)) ? updCellResult_0 : THROW_CCE();
            var tmp0_safe_receiver = $this.u17_1;
            var onCancellation = tmp0_safe_receiver == null ? null : bindCancellationFun_0($this, tmp0_safe_receiver);
            cancellable.fz(element, onCancellation);
          }
          break $l$block_0;
        }
      }
    } else {
      segment.r18();
      var element_0 = (updCellResult == null ? true : !(updCellResult == null)) ? updCellResult : THROW_CCE();
      var tmp0_safe_receiver_0 = $this.u17_1;
      var onCancellation_0 = tmp0_safe_receiver_0 == null ? null : bindCancellationFun_0($this, tmp0_safe_receiver_0);
      cancellable.fz(element_0, onCancellation_0);
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      cancellable.u10();
      throw e;
    } else {
      throw $p;
    }
  }
  return cancellable.cy();
}
function prepareReceiverForSuspension($this, _this__u8e3s4, segment, index) {
  $this.i19();
  _this__u8e3s4.a11(segment, index);
}
function onClosedReceiveOnNoWaiterSuspend($this, cont) {
  // Inline function 'kotlin.coroutines.resumeWithException' call
  // Inline function 'kotlin.Companion.failure' call
  var exception = _get_receiveException__foorc1($this);
  var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception));
  cont.nc(tmp$ret$0);
}
function updateCellReceive($this, segment, index, r, waiter) {
  var state = segment.p17(index);
  if (state === null) {
    // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
    var senders = $this.v17_1.kotlinx$atomicfu$value.h4(new Long(-1, 268435455));
    if (r.s1(senders) >= 0) {
      if (waiter === null) {
        return get_SUSPEND_NO_WAITER();
      }
      if (segment.r17(index, state, waiter)) {
        expandBuffer($this);
        return get_SUSPEND();
      }
    }
  } else if (state === get_BUFFERED())
    if (segment.r17(index, state, get_DONE_RCV())) {
      expandBuffer($this);
      return segment.n17(index);
    }
  return updateCellReceiveSlow($this, segment, index, r, waiter);
}
function updateCellReceiveSlow($this, segment, index, r, waiter) {
  $l$loop: while (true) {
    var state = segment.p17(index);
    if (state === null || state === get_IN_BUFFER()) {
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
      var senders = $this.v17_1.kotlinx$atomicfu$value.h4(new Long(-1, 268435455));
      if (r.s1(senders) < 0) {
        if (segment.r17(index, state, get_POISONED())) {
          expandBuffer($this);
          return get_FAILED();
        }
      } else {
        if (waiter === null) {
          return get_SUSPEND_NO_WAITER();
        }
        if (segment.r17(index, state, waiter)) {
          expandBuffer($this);
          return get_SUSPEND();
        }
      }
    } else if (state === get_BUFFERED()) {
      if (segment.r17(index, state, get_DONE_RCV())) {
        expandBuffer($this);
        return segment.n17(index);
      }
    } else if (state === get_INTERRUPTED_SEND())
      return get_FAILED();
    else if (state === get_POISONED())
      return get_FAILED();
    else if (state === get_CHANNEL_CLOSED()) {
      expandBuffer($this);
      return get_FAILED();
    } else if (state === get_RESUMING_BY_EB())
      continue $l$loop;
    else {
      if (segment.r17(index, state, get_RESUMING_BY_RCV())) {
        var helpExpandBuffer = state instanceof WaiterEB;
        var tmp;
        if (state instanceof WaiterEB) {
          tmp = state.c19_1;
        } else {
          tmp = state;
        }
        var sender = tmp;
        var tmp_0;
        if (tryResumeSender($this, sender, segment, index)) {
          segment.q17(index, get_DONE_RCV());
          expandBuffer($this);
          tmp_0 = segment.n17(index);
        } else {
          segment.q17(index, get_INTERRUPTED_SEND());
          segment.f18(index, false);
          if (helpExpandBuffer) {
            expandBuffer($this);
          }
          tmp_0 = get_FAILED();
        }
        return tmp_0;
      }
    }
  }
}
function tryResumeSender($this, _this__u8e3s4, segment, index) {
  var tmp;
  if (isInterface(_this__u8e3s4, CancellableContinuation)) {
    if (!isInterface(_this__u8e3s4, CancellableContinuation))
      THROW_CCE();
    tmp = tryResume0(_this__u8e3s4, Unit_instance);
  } else {
    if (isInterface(_this__u8e3s4, SelectInstance)) {
      if (!(_this__u8e3s4 instanceof SelectImplementation))
        THROW_CCE();
      var trySelectResult = _this__u8e3s4.n19($this, Unit_instance);
      if (trySelectResult === TrySelectDetailedResult_REREGISTER_getInstance()) {
        segment.o17(index);
      }
      tmp = trySelectResult === TrySelectDetailedResult_SUCCESSFUL_getInstance();
    } else {
      if (_this__u8e3s4 instanceof SendBroadcast) {
        tmp = tryResume0(_this__u8e3s4.j19_1, true);
      } else {
        var message = 'Unexpected waiter: ' + toString(_this__u8e3s4);
        throw IllegalStateException.t4(toString(message));
      }
    }
  }
  return tmp;
}
function expandBuffer($this) {
  if (_get_isRendezvousOrUnlimited__3mdufi($this))
    return Unit_instance;
  var segment = $this.b18_1.kotlinx$atomicfu$value;
  try_again: while (true) {
    var b = $this.x17_1.atomicfu$getAndIncrement$long();
    // Inline function 'kotlin.Long.div' call
    var other = get_SEGMENT_SIZE();
    var id = b.x3(toLong(other));
    var s = $this.x18();
    if (s.s1(b) <= 0) {
      if (segment.vz_1.s1(id) < 0 && !(segment.n18() == null)) {
        moveSegmentBufferEndToSpecifiedOrLast($this, id, segment);
      }
      incCompletedExpandBufferAttempts$default($this);
      return Unit_instance;
    }
    if (!segment.vz_1.equals(id)) {
      var tmp0_elvis_lhs = findSegmentBufferEnd($this, id, segment, b);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        continue try_again;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      segment = tmp;
    }
    // Inline function 'kotlin.Long.rem' call
    var other_0 = get_SEGMENT_SIZE();
    var i = b.y3(toLong(other_0)).x1();
    if (updateCellExpandBuffer($this, segment, i, b)) {
      incCompletedExpandBufferAttempts$default($this);
      return Unit_instance;
    } else {
      incCompletedExpandBufferAttempts$default($this);
      continue try_again;
    }
  }
}
function updateCellExpandBuffer($this, segment, index, b) {
  var state = segment.p17(index);
  if (!(state == null) ? isInterface(state, Waiter) : false) {
    if (b.s1($this.w17_1.kotlinx$atomicfu$value) >= 0) {
      if (segment.r17(index, state, get_RESUMING_BY_EB())) {
        var tmp;
        if (tryResumeSender($this, state, segment, index)) {
          segment.q17(index, get_BUFFERED());
          tmp = true;
        } else {
          segment.q17(index, get_INTERRUPTED_SEND());
          segment.f18(index, false);
          tmp = false;
        }
        return tmp;
      }
    }
  }
  return updateCellExpandBufferSlow($this, segment, index, b);
}
function updateCellExpandBufferSlow($this, segment, index, b) {
  $l$loop: while (true) {
    var state = segment.p17(index);
    if (!(state == null) ? isInterface(state, Waiter) : false) {
      if (b.s1($this.w17_1.kotlinx$atomicfu$value) < 0) {
        if (segment.r17(index, state, new WaiterEB(state)))
          return true;
      } else {
        if (segment.r17(index, state, get_RESUMING_BY_EB())) {
          var tmp;
          if (tryResumeSender($this, state, segment, index)) {
            segment.q17(index, get_BUFFERED());
            tmp = true;
          } else {
            segment.q17(index, get_INTERRUPTED_SEND());
            segment.f18(index, false);
            tmp = false;
          }
          return tmp;
        }
      }
    } else {
      if (state === get_INTERRUPTED_SEND())
        return false;
      else {
        if (state === null) {
          if (segment.r17(index, state, get_IN_BUFFER()))
            return true;
        } else {
          if (state === get_BUFFERED())
            return true;
          else {
            if (state === get_POISONED() || state === get_DONE_RCV() || state === get_INTERRUPTED_RCV())
              return true;
            else {
              if (state === get_CHANNEL_CLOSED())
                return true;
              else {
                if (state === get_RESUMING_BY_RCV())
                  continue $l$loop;
                else {
                  // Inline function 'kotlin.error' call
                  var message = 'Unexpected cell state: ' + toString_0(state);
                  throw IllegalStateException.t4(toString(message));
                }
              }
            }
          }
        }
      }
    }
  }
}
function incCompletedExpandBufferAttempts($this, nAttempts) {
  // Inline function 'kotlin.also' call
  // Inline function 'kotlinx.coroutines.channels.ebPauseExpandBuffers' call
  if (!$this.y17_1.atomicfu$addAndGet$long(nAttempts).h4(new Long(0, 1073741824)).equals(new Long(0, 0))) {
    $l$loop: while (true) {
      // Inline function 'kotlinx.coroutines.channels.ebPauseExpandBuffers' call
      if (!!$this.y17_1.kotlinx$atomicfu$value.h4(new Long(0, 1073741824)).equals(new Long(0, 0))) {
        break $l$loop;
      }
    }
  }
}
function incCompletedExpandBufferAttempts$default($this, nAttempts, $super) {
  nAttempts = nAttempts === VOID ? new Long(1, 0) : nAttempts;
  return incCompletedExpandBufferAttempts($this, nAttempts);
}
function _get_receiveException__foorc1($this) {
  var tmp0_elvis_lhs = $this.y18();
  return tmp0_elvis_lhs == null ? ClosedReceiveChannelException.u19('Channel was closed') : tmp0_elvis_lhs;
}
function invokeCloseHandler($this) {
  var tmp0 = $this.e18_1;
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlinx.atomicfu.getAndUpdate' call
    while (true) {
      var cur = tmp0.kotlinx$atomicfu$value;
      var tmp;
      if (cur === null) {
        tmp = get_CLOSE_HANDLER_CLOSED();
      } else {
        tmp = get_CLOSE_HANDLER_INVOKED();
      }
      var upd = tmp;
      if (tmp0.atomicfu$compareAndSet(cur, upd)) {
        tmp$ret$1 = cur;
        break $l$block;
      }
    }
  }
  var tmp0_elvis_lhs = tmp$ret$1;
  var tmp_0;
  if (tmp0_elvis_lhs == null) {
    return Unit_instance;
  } else {
    tmp_0 = tmp0_elvis_lhs;
  }
  var closeHandler = tmp_0;
  if (typeof closeHandler !== 'function')
    THROW_CCE();
  closeHandler($this.y18());
}
function markClosed($this) {
  var tmp0 = $this.v17_1;
  var tmp$ret$4;
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    while (true) {
      var cur = tmp0.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
      var tmp;
      switch (cur.f4(60).x1()) {
        case 0:
          // Inline function 'kotlinx.coroutines.channels.sendersCounter' call

          var tmp$ret$1 = cur.h4(new Long(-1, 268435455));
          tmp = constructSendersAndCloseStatus(tmp$ret$1, 2);
          break;
        case 1:
          // Inline function 'kotlinx.coroutines.channels.sendersCounter' call

          var tmp$ret$2 = cur.h4(new Long(-1, 268435455));
          tmp = constructSendersAndCloseStatus(tmp$ret$2, 3);
          break;
        default:
          return Unit_instance;
      }
      var upd = tmp;
      if (tmp0.atomicfu$compareAndSet(cur, upd)) {
        tmp$ret$4 = Unit_instance;
        break $l$block;
      }
    }
    tmp$ret$4 = Unit_instance;
  }
  return tmp$ret$4;
}
function markCancelled($this) {
  var tmp0 = $this.v17_1;
  var tmp$ret$2;
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    while (true) {
      var cur = tmp0.kotlinx$atomicfu$value;
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
      var tmp$ret$0 = cur.h4(new Long(-1, 268435455));
      var upd = constructSendersAndCloseStatus(tmp$ret$0, 3);
      if (tmp0.atomicfu$compareAndSet(cur, upd)) {
        tmp$ret$2 = Unit_instance;
        break $l$block;
      }
    }
    tmp$ret$2 = Unit_instance;
  }
  return tmp$ret$2;
}
function markCancellationStarted($this) {
  var tmp0 = $this.v17_1;
  var tmp$ret$3;
  $l$block: {
    // Inline function 'kotlinx.atomicfu.update' call
    while (true) {
      var cur = tmp0.kotlinx$atomicfu$value;
      var tmp;
      // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
      if (cur.f4(60).x1() === 0) {
        // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
        var tmp$ret$1 = cur.h4(new Long(-1, 268435455));
        tmp = constructSendersAndCloseStatus(tmp$ret$1, 1);
      } else {
        return Unit_instance;
      }
      var upd = tmp;
      if (tmp0.atomicfu$compareAndSet(cur, upd)) {
        tmp$ret$3 = Unit_instance;
        break $l$block;
      }
    }
    tmp$ret$3 = Unit_instance;
  }
  return tmp$ret$3;
}
function completeCloseOrCancel($this) {
  $this.v19();
}
function completeClose($this, sendersCur) {
  var lastSegment = closeLinkedList($this);
  if ($this.x19()) {
    var lastBufferedCellGlobalIndex = markAllEmptyCellsAsClosed($this, lastSegment);
    if (!lastBufferedCellGlobalIndex.equals(new Long(-1, -1))) {
      $this.w19(lastBufferedCellGlobalIndex);
    }
  }
  cancelSuspendedReceiveRequests($this, lastSegment, sendersCur);
  return lastSegment;
}
function completeCancel($this, sendersCur) {
  var lastSegment = completeClose($this, sendersCur);
  removeUnprocessedElements($this, lastSegment);
}
function closeLinkedList($this) {
  var lastSegment = $this.b18_1.kotlinx$atomicfu$value;
  // Inline function 'kotlin.let' call
  var it = $this.z17_1.kotlinx$atomicfu$value;
  if (it.vz_1.s1(lastSegment.vz_1) > 0)
    lastSegment = it;
  // Inline function 'kotlin.let' call
  var it_0 = $this.a18_1.kotlinx$atomicfu$value;
  if (it_0.vz_1.s1(lastSegment.vz_1) > 0)
    lastSegment = it_0;
  return close(lastSegment);
}
function markAllEmptyCellsAsClosed($this, lastSegment) {
  var segment = lastSegment;
  while (true) {
    var inductionVariable = get_SEGMENT_SIZE() - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = segment.vz_1;
        // Inline function 'kotlin.Long.times' call
        var other = get_SEGMENT_SIZE();
        // Inline function 'kotlin.Long.plus' call
        var globalIndex = tmp0.w3(toLong(other)).u3(toLong(index));
        if (globalIndex.s1($this.z18()) < 0)
          return new Long(-1, -1);
        cell_update: while (true) {
          var state = segment.p17(index);
          if (state === null || state === get_IN_BUFFER()) {
            if (segment.r17(index, state, get_CHANNEL_CLOSED())) {
              segment.h18();
              break cell_update;
            }
          } else if (state === get_BUFFERED())
            return globalIndex;
          else
            break cell_update;
        }
      }
       while (0 <= inductionVariable);
    var tmp0_elvis_lhs = segment.q18();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return new Long(-1, -1);
    } else {
      tmp = tmp0_elvis_lhs;
    }
    segment = tmp;
  }
}
function removeUnprocessedElements($this, lastSegment) {
  var onUndeliveredElement = $this.u17_1;
  var undeliveredElementException = null;
  var suspendedSenders = _InlineList___init__impl__z8n56();
  var segment = lastSegment;
  process_segments: while (true) {
    var inductionVariable = get_SEGMENT_SIZE() - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = segment.vz_1;
        // Inline function 'kotlin.Long.times' call
        var other = get_SEGMENT_SIZE();
        // Inline function 'kotlin.Long.plus' call
        var globalIndex = tmp0.w3(toLong(other)).u3(toLong(index));
        update_cell: while (true) {
          var state = segment.p17(index);
          if (state === get_DONE_RCV())
            break process_segments;
          else {
            if (state === get_BUFFERED()) {
              if (globalIndex.s1($this.z18()) < 0)
                break process_segments;
              if (segment.r17(index, state, get_CHANNEL_CLOSED())) {
                if (!(onUndeliveredElement == null)) {
                  var element = segment.m17(index);
                  undeliveredElementException = callUndeliveredElementCatchingException(onUndeliveredElement, element, undeliveredElementException);
                }
                segment.o17(index);
                segment.h18();
                break update_cell;
              }
            } else {
              if (state === get_IN_BUFFER() || state === null) {
                if (segment.r17(index, state, get_CHANNEL_CLOSED())) {
                  segment.h18();
                  break update_cell;
                }
              } else {
                var tmp;
                if (!(state == null) ? isInterface(state, Waiter) : false) {
                  tmp = true;
                } else {
                  tmp = state instanceof WaiterEB;
                }
                if (tmp) {
                  if (globalIndex.s1($this.z18()) < 0)
                    break process_segments;
                  var tmp_0;
                  if (state instanceof WaiterEB) {
                    tmp_0 = state.c19_1;
                  } else {
                    tmp_0 = (!(state == null) ? isInterface(state, Waiter) : false) ? state : THROW_CCE();
                  }
                  var sender = tmp_0;
                  if (segment.r17(index, state, get_CHANNEL_CLOSED())) {
                    if (!(onUndeliveredElement == null)) {
                      var element_0 = segment.m17(index);
                      undeliveredElementException = callUndeliveredElementCatchingException(onUndeliveredElement, element_0, undeliveredElementException);
                    }
                    suspendedSenders = InlineList__plus_impl_nuetvo(suspendedSenders, sender);
                    segment.o17(index);
                    segment.h18();
                    break update_cell;
                  }
                } else {
                  if (state === get_RESUMING_BY_EB() || state === get_RESUMING_BY_RCV())
                    break process_segments;
                  else {
                    if (state === get_RESUMING_BY_EB())
                      continue update_cell;
                    else {
                      break update_cell;
                    }
                  }
                }
              }
            }
          }
        }
      }
       while (0 <= inductionVariable);
    var tmp0_elvis_lhs = segment.q18();
    var tmp_1;
    if (tmp0_elvis_lhs == null) {
      break process_segments;
    } else {
      tmp_1 = tmp0_elvis_lhs;
    }
    segment = tmp_1;
  }
  var tmp4 = suspendedSenders;
  $l$block: {
    // Inline function 'kotlinx.coroutines.internal.InlineList.forEachReversed' call
    var tmp0_subject = access$_get_holder__kkflen(tmp4);
    if (tmp0_subject == null) {
      break $l$block;
    } else {
      if (!(tmp0_subject instanceof ArrayList)) {
        var tmp_2 = access$_get_holder__kkflen(tmp4);
        var it = (tmp_2 == null ? true : !(tmp_2 == null)) ? tmp_2 : THROW_CCE();
        resumeSenderOnCancelledChannel($this, it);
      } else {
        var tmp_3 = access$_get_holder__kkflen(tmp4);
        var list = tmp_3 instanceof ArrayList ? tmp_3 : THROW_CCE();
        var inductionVariable_0 = list.b1() - 1 | 0;
        if (0 <= inductionVariable_0)
          do {
            var i = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + -1 | 0;
            var it_0 = list.f1(i);
            resumeSenderOnCancelledChannel($this, it_0);
          }
           while (0 <= inductionVariable_0);
      }
    }
  }
  var tmp1_safe_receiver = undeliveredElementException;
  if (tmp1_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    throw tmp1_safe_receiver;
  }
}
function cancelSuspendedReceiveRequests($this, lastSegment, sendersCounter) {
  var suspendedReceivers = _InlineList___init__impl__z8n56();
  var segment = lastSegment;
  process_segments: while (!(segment == null)) {
    var inductionVariable = get_SEGMENT_SIZE() - 1 | 0;
    if (0 <= inductionVariable)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + -1 | 0;
        var tmp0 = segment.vz_1;
        // Inline function 'kotlin.Long.times' call
        var other = get_SEGMENT_SIZE();
        // Inline function 'kotlin.Long.plus' call
        if (tmp0.w3(toLong(other)).u3(toLong(index)).s1(sendersCounter) < 0)
          break process_segments;
        cell_update: while (true) {
          var state = segment.p17(index);
          if (state === null || state === get_IN_BUFFER()) {
            if (segment.r17(index, state, get_CHANNEL_CLOSED())) {
              segment.h18();
              break cell_update;
            }
          } else {
            if (state instanceof WaiterEB) {
              if (segment.r17(index, state, get_CHANNEL_CLOSED())) {
                suspendedReceivers = InlineList__plus_impl_nuetvo(suspendedReceivers, state.c19_1);
                segment.f18(index, true);
                break cell_update;
              }
            } else {
              if (!(state == null) ? isInterface(state, Waiter) : false) {
                if (segment.r17(index, state, get_CHANNEL_CLOSED())) {
                  suspendedReceivers = InlineList__plus_impl_nuetvo(suspendedReceivers, state);
                  segment.f18(index, true);
                  break cell_update;
                }
              } else {
                break cell_update;
              }
            }
          }
        }
      }
       while (0 <= inductionVariable);
    segment = segment.q18();
  }
  var tmp4 = suspendedReceivers;
  $l$block: {
    // Inline function 'kotlinx.coroutines.internal.InlineList.forEachReversed' call
    var tmp0_subject = access$_get_holder__kkflen(tmp4);
    if (tmp0_subject == null) {
      break $l$block;
    } else {
      if (!(tmp0_subject instanceof ArrayList)) {
        var tmp = access$_get_holder__kkflen(tmp4);
        var it = (tmp == null ? true : !(tmp == null)) ? tmp : THROW_CCE();
        resumeReceiverOnClosedChannel($this, it);
      } else {
        var tmp_0 = access$_get_holder__kkflen(tmp4);
        var list = tmp_0 instanceof ArrayList ? tmp_0 : THROW_CCE();
        var inductionVariable_0 = list.b1() - 1 | 0;
        if (0 <= inductionVariable_0)
          do {
            var i = inductionVariable_0;
            inductionVariable_0 = inductionVariable_0 + -1 | 0;
            var it_0 = list.f1(i);
            resumeReceiverOnClosedChannel($this, it_0);
          }
           while (0 <= inductionVariable_0);
      }
    }
  }
}
function resumeReceiverOnClosedChannel($this, _this__u8e3s4) {
  return resumeWaiterOnClosedChannel($this, _this__u8e3s4, true);
}
function resumeSenderOnCancelledChannel($this, _this__u8e3s4) {
  return resumeWaiterOnClosedChannel($this, _this__u8e3s4, false);
}
function resumeWaiterOnClosedChannel($this, _this__u8e3s4, receiver) {
  if (_this__u8e3s4 instanceof SendBroadcast) {
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = _this__u8e3s4.j19_1;
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(false);
    this_0.nc(tmp$ret$0);
  } else {
    if (isInterface(_this__u8e3s4, CancellableContinuation)) {
      // Inline function 'kotlin.coroutines.resumeWithException' call
      // Inline function 'kotlin.Companion.failure' call
      var exception = receiver ? _get_receiveException__foorc1($this) : $this.a19();
      var tmp$ret$2 = _Result___init__impl__xyqfz8(createFailure(exception));
      _this__u8e3s4.nc(tmp$ret$2);
    } else {
      if (_this__u8e3s4 instanceof ReceiveCatching) {
        var tmp4 = _this__u8e3s4.g19_1;
        // Inline function 'kotlin.coroutines.resume' call
        // Inline function 'kotlin.Companion.success' call
        var value = new ChannelResult(Companion_getInstance_0().y19($this.y18()));
        var tmp$ret$4 = _Result___init__impl__xyqfz8(value);
        tmp4.nc(tmp$ret$4);
      } else {
        if (_this__u8e3s4 instanceof BufferedChannelIterator) {
          _this__u8e3s4.p19();
        } else {
          if (isInterface(_this__u8e3s4, SelectInstance))
            _this__u8e3s4.h19($this, get_CHANNEL_CLOSED());
          else {
            // Inline function 'kotlin.error' call
            var message = 'Unexpected waiter: ' + toString(_this__u8e3s4);
            throw IllegalStateException.t4(toString(message));
          }
        }
      }
    }
  }
}
function _get_isClosedForSend0__kxgf9m($this, _this__u8e3s4) {
  return isClosed($this, _this__u8e3s4, false);
}
function _get_isClosedForReceive0__f7qknl($this, _this__u8e3s4) {
  return isClosed($this, _this__u8e3s4, true);
}
function isClosed($this, sendersAndCloseStatusCur, isClosedForReceive) {
  // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
  var tmp;
  switch (sendersAndCloseStatusCur.f4(60).x1()) {
    case 0:
      tmp = false;
      break;
    case 1:
      tmp = false;
      break;
    case 2:
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call

      var tmp$ret$1 = sendersAndCloseStatusCur.h4(new Long(-1, 268435455));
      completeClose($this, tmp$ret$1);
      tmp = isClosedForReceive ? !$this.z19() : true;
      break;
    case 3:
      // Inline function 'kotlinx.coroutines.channels.sendersCounter' call

      var tmp$ret$2 = sendersAndCloseStatusCur.h4(new Long(-1, 268435455));
      completeCancel($this, tmp$ret$2);
      tmp = true;
      break;
    default:
      // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call

      var message = 'unexpected close status: ' + sendersAndCloseStatusCur.f4(60).x1();
      throw IllegalStateException.t4(toString(message));
  }
  return tmp;
}
function isCellNonEmpty($this, segment, index, globalIndex) {
  while (true) {
    var state = segment.p17(index);
    if (state === null || state === get_IN_BUFFER()) {
      if (segment.r17(index, state, get_POISONED())) {
        expandBuffer($this);
        return false;
      }
    } else if (state === get_BUFFERED())
      return true;
    else if (state === get_INTERRUPTED_SEND())
      return false;
    else if (state === get_CHANNEL_CLOSED())
      return false;
    else if (state === get_DONE_RCV())
      return false;
    else if (state === get_POISONED())
      return false;
    else if (state === get_RESUMING_BY_EB())
      return true;
    else if (state === get_RESUMING_BY_RCV())
      return false;
    else
      return globalIndex.equals($this.z18());
  }
}
function findSegmentSend($this, id, startFrom) {
  var tmp0 = $this.z17_1;
  var tmp3 = createSegmentFunction();
  var tmp$ret$2;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    while (true) {
      var s = findSegmentInternal(startFrom, id, tmp3);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp1 = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
        var tmp$ret$0;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          while (true) {
            var cur = tmp0.kotlinx$atomicfu$value;
            if (cur.vz_1.s1(tmp1.vz_1) >= 0) {
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (!tmp1.j18()) {
              tmp$ret$0 = false;
              break $l$block_1;
            }
            if (tmp0.atomicfu$compareAndSet(cur, tmp1)) {
              if (cur.k18()) {
                cur.e6();
              }
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (tmp1.k18()) {
              tmp1.e6();
            }
          }
          tmp$ret$0 = Unit_instance;
        }
        tmp = tmp$ret$0;
      }
      if (tmp) {
        tmp$ret$2 = s;
        break $l$block_2;
      }
    }
  }
  // Inline function 'kotlin.let' call
  var it = tmp$ret$2;
  var tmp_0;
  if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(it)) {
    completeCloseOrCancel($this);
    var tmp0_0 = startFrom.vz_1;
    // Inline function 'kotlin.Long.times' call
    var other = get_SEGMENT_SIZE();
    if (tmp0_0.w3(toLong(other)).s1($this.z18()) < 0) {
      startFrom.r18();
    }
    tmp_0 = null;
  } else {
    var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(it);
    var tmp_1;
    if (segment.vz_1.s1(id) > 0) {
      var tmp2 = segment.vz_1;
      // Inline function 'kotlin.Long.times' call
      var other_0 = get_SEGMENT_SIZE();
      var tmp$ret$4 = tmp2.w3(toLong(other_0));
      updateSendersCounterIfLower($this, tmp$ret$4);
      var tmp4 = segment.vz_1;
      // Inline function 'kotlin.Long.times' call
      var other_1 = get_SEGMENT_SIZE();
      if (tmp4.w3(toLong(other_1)).s1($this.z18()) < 0) {
        segment.r18();
      }
      tmp_1 = null;
    } else {
      // Inline function 'kotlinx.coroutines.assert' call
      tmp_1 = segment;
    }
    tmp_0 = tmp_1;
  }
  return tmp_0;
}
function findSegmentReceive($this, id, startFrom) {
  var tmp0 = $this.a18_1;
  var tmp3 = createSegmentFunction();
  var tmp$ret$2;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    while (true) {
      var s = findSegmentInternal(startFrom, id, tmp3);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp1 = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
        var tmp$ret$0;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          while (true) {
            var cur = tmp0.kotlinx$atomicfu$value;
            if (cur.vz_1.s1(tmp1.vz_1) >= 0) {
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (!tmp1.j18()) {
              tmp$ret$0 = false;
              break $l$block_1;
            }
            if (tmp0.atomicfu$compareAndSet(cur, tmp1)) {
              if (cur.k18()) {
                cur.e6();
              }
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (tmp1.k18()) {
              tmp1.e6();
            }
          }
          tmp$ret$0 = Unit_instance;
        }
        tmp = tmp$ret$0;
      }
      if (tmp) {
        tmp$ret$2 = s;
        break $l$block_2;
      }
    }
  }
  // Inline function 'kotlin.let' call
  var it = tmp$ret$2;
  var tmp_0;
  if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(it)) {
    completeCloseOrCancel($this);
    var tmp0_0 = startFrom.vz_1;
    // Inline function 'kotlin.Long.times' call
    var other = get_SEGMENT_SIZE();
    if (tmp0_0.w3(toLong(other)).s1($this.x18()) < 0) {
      startFrom.r18();
    }
    tmp_0 = null;
  } else {
    var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(it);
    var tmp_1;
    if (!_get_isRendezvousOrUnlimited__3mdufi($this)) {
      var tmp2 = _get_bufferEndCounter__2d4hee($this);
      // Inline function 'kotlin.Long.div' call
      var other_0 = get_SEGMENT_SIZE();
      var tmp$ret$4 = tmp2.x3(toLong(other_0));
      tmp_1 = id.s1(tmp$ret$4) <= 0;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      var tmp4 = $this.b18_1;
      $l$block_5: {
        // Inline function 'kotlinx.coroutines.internal.moveForward' call
        while (true) {
          var cur_0 = tmp4.kotlinx$atomicfu$value;
          if (cur_0.vz_1.s1(segment.vz_1) >= 0) {
            break $l$block_5;
          }
          if (!segment.j18()) {
            break $l$block_5;
          }
          if (tmp4.atomicfu$compareAndSet(cur_0, segment)) {
            if (cur_0.k18()) {
              cur_0.e6();
            }
            break $l$block_5;
          }
          if (segment.k18()) {
            segment.e6();
          }
        }
      }
    }
    var tmp_2;
    if (segment.vz_1.s1(id) > 0) {
      var tmp6 = segment.vz_1;
      // Inline function 'kotlin.Long.times' call
      var other_1 = get_SEGMENT_SIZE();
      var tmp$ret$7 = tmp6.w3(toLong(other_1));
      updateReceiversCounterIfLower($this, tmp$ret$7);
      var tmp8 = segment.vz_1;
      // Inline function 'kotlin.Long.times' call
      var other_2 = get_SEGMENT_SIZE();
      if (tmp8.w3(toLong(other_2)).s1($this.x18()) < 0) {
        segment.r18();
      }
      tmp_2 = null;
    } else {
      // Inline function 'kotlinx.coroutines.assert' call
      tmp_2 = segment;
    }
    tmp_0 = tmp_2;
  }
  return tmp_0;
}
function findSegmentBufferEnd($this, id, startFrom, currentBufferEndCounter) {
  var tmp0 = $this.b18_1;
  var tmp3 = createSegmentFunction();
  var tmp$ret$2;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    while (true) {
      var s = findSegmentInternal(startFrom, id, tmp3);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp1 = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
        var tmp$ret$0;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          while (true) {
            var cur = tmp0.kotlinx$atomicfu$value;
            if (cur.vz_1.s1(tmp1.vz_1) >= 0) {
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (!tmp1.j18()) {
              tmp$ret$0 = false;
              break $l$block_1;
            }
            if (tmp0.atomicfu$compareAndSet(cur, tmp1)) {
              if (cur.k18()) {
                cur.e6();
              }
              tmp$ret$0 = true;
              break $l$block_1;
            }
            if (tmp1.k18()) {
              tmp1.e6();
            }
          }
          tmp$ret$0 = Unit_instance;
        }
        tmp = tmp$ret$0;
      }
      if (tmp) {
        tmp$ret$2 = s;
        break $l$block_2;
      }
    }
  }
  // Inline function 'kotlin.let' call
  var it = tmp$ret$2;
  var tmp_0;
  if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(it)) {
    completeCloseOrCancel($this);
    moveSegmentBufferEndToSpecifiedOrLast($this, id, startFrom);
    incCompletedExpandBufferAttempts$default($this);
    tmp_0 = null;
  } else {
    var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(it);
    var tmp_1;
    if (segment.vz_1.s1(id) > 0) {
      // Inline function 'kotlin.Long.plus' call
      var tmp_2 = currentBufferEndCounter.u3(toLong(1));
      var tmp2 = segment.vz_1;
      // Inline function 'kotlin.Long.times' call
      var other = get_SEGMENT_SIZE();
      var tmp$ret$4 = tmp2.w3(toLong(other));
      if ($this.x17_1.atomicfu$compareAndSet(tmp_2, tmp$ret$4)) {
        var tmp4 = segment.vz_1;
        // Inline function 'kotlin.Long.times' call
        var other_0 = get_SEGMENT_SIZE();
        var tmp$ret$5 = tmp4.w3(toLong(other_0));
        incCompletedExpandBufferAttempts($this, tmp$ret$5.v3(currentBufferEndCounter));
      } else {
        incCompletedExpandBufferAttempts$default($this);
      }
      tmp_1 = null;
    } else {
      // Inline function 'kotlinx.coroutines.assert' call
      tmp_1 = segment;
    }
    tmp_0 = tmp_1;
  }
  return tmp_0;
}
function moveSegmentBufferEndToSpecifiedOrLast($this, id, startFrom) {
  var segment = startFrom;
  $l$loop: while (segment.vz_1.s1(id) < 0) {
    var tmp0_elvis_lhs = segment.n18();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      break $l$loop;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    segment = tmp;
  }
  while (true) {
    $l$loop_0: while (segment.i18()) {
      var tmp1_elvis_lhs = segment.n18();
      var tmp_0;
      if (tmp1_elvis_lhs == null) {
        break $l$loop_0;
      } else {
        tmp_0 = tmp1_elvis_lhs;
      }
      segment = tmp_0;
    }
    var tmp0 = $this.b18_1;
    var tmp1 = segment;
    var tmp$ret$0;
    $l$block_1: {
      // Inline function 'kotlinx.coroutines.internal.moveForward' call
      while (true) {
        var cur = tmp0.kotlinx$atomicfu$value;
        if (cur.vz_1.s1(tmp1.vz_1) >= 0) {
          tmp$ret$0 = true;
          break $l$block_1;
        }
        if (!tmp1.j18()) {
          tmp$ret$0 = false;
          break $l$block_1;
        }
        if (tmp0.atomicfu$compareAndSet(cur, tmp1)) {
          if (cur.k18()) {
            cur.e6();
          }
          tmp$ret$0 = true;
          break $l$block_1;
        }
        if (tmp1.k18()) {
          tmp1.e6();
        }
      }
      tmp$ret$0 = Unit_instance;
    }
    if (tmp$ret$0)
      return Unit_instance;
  }
}
function updateSendersCounterIfLower($this, value) {
  var this_0 = $this.v17_1;
  while (true) {
    var cur = this_0.kotlinx$atomicfu$value;
    // Inline function 'kotlinx.coroutines.channels.sendersCounter' call
    var curCounter = cur.h4(new Long(-1, 268435455));
    if (curCounter.s1(value) >= 0)
      return Unit_instance;
    // Inline function 'kotlinx.coroutines.channels.sendersCloseStatus' call
    var tmp$ret$1 = cur.f4(60).x1();
    var update = constructSendersAndCloseStatus(curCounter, tmp$ret$1);
    if ($this.v17_1.atomicfu$compareAndSet(cur, update))
      return Unit_instance;
  }
  return Unit_instance;
}
function updateReceiversCounterIfLower($this, value) {
  var this_0 = $this.w17_1;
  while (true) {
    var cur = this_0.kotlinx$atomicfu$value;
    if (cur.s1(value) >= 0)
      return Unit_instance;
    if ($this.w17_1.atomicfu$compareAndSet(cur, value))
      return Unit_instance;
  }
  return Unit_instance;
}
function bindCancellationFunResult($this, _this__u8e3s4) {
  return BufferedChannel$onCancellationChannelResultImplDoNotCall$ref($this);
}
function onCancellationChannelResultImplDoNotCall($this, cause, element, context) {
  callUndeliveredElement(ensureNotNull($this.u17_1), ensureNotNull(ChannelResult__getOrNull_impl_f5e07h(element)), context);
}
function bindCancellationFun($this, _this__u8e3s4, element) {
  return BufferedChannel$bindCancellationFun$lambda(_this__u8e3s4, element);
}
function bindCancellationFun_0($this, _this__u8e3s4) {
  return BufferedChannel$onCancellationImplDoNotCall$ref($this);
}
function onCancellationImplDoNotCall($this, cause, element, context) {
  callUndeliveredElement(ensureNotNull($this.u17_1), element, context);
}
function BufferedChannel$onUndeliveredElementReceiveCancellationConstructor$lambda$lambda($element, this$0, $select) {
  return (_unused_var__etf5q3, _unused_var__etf5q3_0, _unused_var__etf5q3_1) => {
    var tmp;
    if (!($element === get_CHANNEL_CLOSED())) {
      callUndeliveredElement(this$0.u17_1, ($element == null ? true : !($element == null)) ? $element : THROW_CCE(), $select.lc());
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
function BufferedChannel$onUndeliveredElementReceiveCancellationConstructor$lambda(this$0) {
  return (select, _unused_var__etf5q3, element) => BufferedChannel$onUndeliveredElementReceiveCancellationConstructor$lambda$lambda(element, this$0, select);
}
function BufferedChannel$onCancellationChannelResultImplDoNotCall$ref($boundThis) {
  var l = (p0, p1, p2) => {
    onCancellationChannelResultImplDoNotCall($boundThis, p0, p1.b1a_1, p2);
    return Unit_instance;
  };
  l.callableName = 'onCancellationChannelResultImplDoNotCall';
  return l;
}
function BufferedChannel$bindCancellationFun$lambda($this_bindCancellationFun, $element) {
  return (_unused_var__etf5q3, _unused_var__etf5q3_0, context) => {
    callUndeliveredElement($this_bindCancellationFun, $element, context);
    return Unit_instance;
  };
}
function BufferedChannel$onCancellationImplDoNotCall$ref($boundThis) {
  var l = (p0, p1, p2) => {
    onCancellationImplDoNotCall($boundThis, p0, p1, p2);
    return Unit_instance;
  };
  l.callableName = 'onCancellationImplDoNotCall';
  return l;
}
function initialBufferEnd(capacity) {
  _init_properties_BufferedChannel_kt__d6uc4y();
  switch (capacity) {
    case 0:
      return new Long(0, 0);
    case 2147483647:
      return new Long(-1, 2147483647);
    default:
      return toLong(capacity);
  }
}
function tryResume0(_this__u8e3s4, value, onCancellation) {
  onCancellation = onCancellation === VOID ? null : onCancellation;
  _init_properties_BufferedChannel_kt__d6uc4y();
  // Inline function 'kotlin.let' call
  var token = _this__u8e3s4.cz(value, null, onCancellation);
  var tmp;
  if (!(token == null)) {
    _this__u8e3s4.ix(token);
    tmp = true;
  } else {
    tmp = false;
  }
  return tmp;
}
function constructEBCompletedAndPauseFlag(counter, pauseEB) {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return (pauseEB ? new Long(0, 1073741824) : new Long(0, 0)).u3(counter);
}
function constructSendersAndCloseStatus(counter, closeStatus) {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return toLong(closeStatus).e4(60).u3(counter);
}
function createSegmentFunction() {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return createSegment$ref();
}
function createSegment(id, prev) {
  _init_properties_BufferedChannel_kt__d6uc4y();
  return new ChannelSegment(id, prev, prev.j17(), 0);
}
function createSegment$ref() {
  var l = (p0, p1) => createSegment(p0, p1);
  l.callableName = 'createSegment';
  return l;
}
var properties_initialized_BufferedChannel_kt_58tjvw;
function _init_properties_BufferedChannel_kt__d6uc4y() {
  if (!properties_initialized_BufferedChannel_kt_58tjvw) {
    properties_initialized_BufferedChannel_kt_58tjvw = true;
    NULL_SEGMENT = new ChannelSegment(new Long(-1, -1), null, null, 0);
    SEGMENT_SIZE = systemProp('kotlinx.coroutines.bufferedChannel.segmentSize', 32);
    EXPAND_BUFFER_COMPLETION_WAIT_ITERATIONS = systemProp('kotlinx.coroutines.bufferedChannel.expandBufferCompletionWaitIterations', 10000);
    BUFFERED = new Symbol('BUFFERED');
    IN_BUFFER = new Symbol('SHOULD_BUFFER');
    RESUMING_BY_RCV = new Symbol('S_RESUMING_BY_RCV');
    RESUMING_BY_EB = new Symbol('RESUMING_BY_EB');
    POISONED = new Symbol('POISONED');
    DONE_RCV = new Symbol('DONE_RCV');
    INTERRUPTED_SEND = new Symbol('INTERRUPTED_SEND');
    INTERRUPTED_RCV = new Symbol('INTERRUPTED_RCV');
    CHANNEL_CLOSED = new Symbol('CHANNEL_CLOSED');
    SUSPEND = new Symbol('SUSPEND');
    SUSPEND_NO_WAITER = new Symbol('SUSPEND_NO_WAITER');
    FAILED = new Symbol('FAILED');
    NO_RECEIVE_RESULT = new Symbol('NO_RECEIVE_RESULT');
    CLOSE_HANDLER_CLOSED = new Symbol('CLOSE_HANDLER_CLOSED');
    CLOSE_HANDLER_INVOKED = new Symbol('CLOSE_HANDLER_INVOKED');
    NO_CLOSE_CAUSE = new Symbol('NO_CLOSE_CAUSE');
  }
}
var Factory_instance;
function Factory_getInstance() {
  if (Factory_instance === VOID)
    new Factory();
  return Factory_instance;
}
function _ChannelResult___init__impl__siwsuf(holder) {
  return holder;
}
function _ChannelResult___get_holder__impl__pm9gzw($this) {
  return $this;
}
function _ChannelResult___get_isSuccess__impl__odq1z9($this) {
  var tmp = _ChannelResult___get_holder__impl__pm9gzw($this);
  return !(tmp instanceof Failed);
}
function _ChannelResult___get_isClosed__impl__mg7kuu($this) {
  var tmp = _ChannelResult___get_holder__impl__pm9gzw($this);
  return tmp instanceof Closed;
}
function ChannelResult__getOrNull_impl_f5e07h($this) {
  var tmp;
  var tmp_0 = _ChannelResult___get_holder__impl__pm9gzw($this);
  if (!(tmp_0 instanceof Failed)) {
    var tmp_1 = _ChannelResult___get_holder__impl__pm9gzw($this);
    tmp = (tmp_1 == null ? true : !(tmp_1 == null)) ? tmp_1 : THROW_CCE();
  } else {
    tmp = null;
  }
  return tmp;
}
function ChannelResult__exceptionOrNull_impl_16ei30($this) {
  var tmp = _ChannelResult___get_holder__impl__pm9gzw($this);
  var tmp0_safe_receiver = tmp instanceof Closed ? tmp : null;
  return tmp0_safe_receiver == null ? null : tmp0_safe_receiver.z1a_1;
}
var Companion_instance_0;
function Companion_getInstance_0() {
  if (Companion_instance_0 === VOID)
    new Companion();
  return Companion_instance_0;
}
function ChannelResult__toString_impl_rrcqu7($this) {
  var tmp;
  if (_ChannelResult___get_holder__impl__pm9gzw($this) instanceof Closed) {
    tmp = _ChannelResult___get_holder__impl__pm9gzw($this).toString();
  } else {
    tmp = 'Value(' + toString_0(_ChannelResult___get_holder__impl__pm9gzw($this)) + ')';
  }
  return tmp;
}
function ChannelResult__hashCode_impl_lilec2($this) {
  return $this == null ? 0 : hashCode($this);
}
function ChannelResult__equals_impl_f471ri($this, other) {
  if (!(other instanceof ChannelResult))
    return false;
  var tmp0_other_with_cast = other instanceof ChannelResult ? other.b1a_1 : THROW_CCE();
  if (!equals($this, tmp0_other_with_cast))
    return false;
  return true;
}
function Channel(capacity, onBufferOverflow, onUndeliveredElement) {
  capacity = capacity === VOID ? 0 : capacity;
  onBufferOverflow = onBufferOverflow === VOID ? BufferOverflow_SUSPEND_getInstance() : onBufferOverflow;
  onUndeliveredElement = onUndeliveredElement === VOID ? null : onUndeliveredElement;
  var tmp;
  switch (capacity) {
    case 0:
      tmp = onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance()) ? new BufferedChannel(0, onUndeliveredElement) : new ConflatedBufferedChannel(1, onBufferOverflow, onUndeliveredElement);
      break;
    case -1:
      // Inline function 'kotlin.require' call

      if (!onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance())) {
        var message = 'CONFLATED capacity cannot be used with non-default onBufferOverflow';
        throw IllegalArgumentException.t(toString(message));
      }

      tmp = new ConflatedBufferedChannel(1, BufferOverflow_DROP_OLDEST_getInstance(), onUndeliveredElement);
      break;
    case 2147483647:
      tmp = new BufferedChannel(2147483647, onUndeliveredElement);
      break;
    case -2:
      tmp = onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance()) ? new BufferedChannel(Factory_getInstance().y1a_1, onUndeliveredElement) : new ConflatedBufferedChannel(1, onBufferOverflow, onUndeliveredElement);
      break;
    default:
      tmp = onBufferOverflow === BufferOverflow_SUSPEND_getInstance() ? new BufferedChannel(capacity, onUndeliveredElement) : new ConflatedBufferedChannel(capacity, onBufferOverflow, onUndeliveredElement);
      break;
  }
  return tmp;
}
function *_generator_send__qhx0g0_0($this, element, $completion) {
  var tmp = $this.d1b_1.c1a(element, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function cancelConsumed(_this__u8e3s4, cause) {
  var tmp;
  if (cause == null) {
    tmp = null;
  } else {
    // Inline function 'kotlin.let' call
    var tmp0_elvis_lhs = cause instanceof CancellationException ? cause : null;
    tmp = tmp0_elvis_lhs == null ? CancellationException_0('Channel was consumed, consumer had failed', cause) : tmp0_elvis_lhs;
  }
  _this__u8e3s4.uv(tmp);
}
function trySendImpl($this, element, isSendOp) {
  return $this.r1b_1 === BufferOverflow_DROP_LATEST_getInstance() ? trySendDropLatest($this, element, isSendOp) : $this.f1a(element);
}
function trySendDropLatest($this, element, isSendOp) {
  var result = protoOf(BufferedChannel).d1a.call($this, element);
  if (_ChannelResult___get_isSuccess__impl__odq1z9(result) || _ChannelResult___get_isClosed__impl__mg7kuu(result))
    return result;
  if (isSendOp) {
    var tmp0_safe_receiver = $this.u17_1;
    var tmp1_safe_receiver = tmp0_safe_receiver == null ? null : callUndeliveredElementCatchingException(tmp0_safe_receiver, element);
    if (tmp1_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.let' call
      throw tmp1_safe_receiver;
    }
  }
  return Companion_getInstance_0().f19(Unit_instance);
}
function produce(_this__u8e3s4, context, capacity, block) {
  context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
  capacity = capacity === VOID ? 0 : capacity;
  return produce_0(_this__u8e3s4, context, capacity, BufferOverflow_SUSPEND_getInstance(), CoroutineStart_DEFAULT_getInstance(), null, block);
}
function produce_0(_this__u8e3s4, context, capacity, onBufferOverflow, start, onCompletion, block) {
  context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
  capacity = capacity === VOID ? 0 : capacity;
  onBufferOverflow = onBufferOverflow === VOID ? BufferOverflow_SUSPEND_getInstance() : onBufferOverflow;
  start = start === VOID ? CoroutineStart_DEFAULT_getInstance() : start;
  onCompletion = onCompletion === VOID ? null : onCompletion;
  var channel = Channel(capacity, onBufferOverflow);
  var newContext = newCoroutineContext(_this__u8e3s4, context);
  var coroutine = new ProducerCoroutine(newContext, channel);
  if (!(onCompletion == null)) {
    coroutine.nv(onCompletion);
  }
  coroutine.yu(start, coroutine, block);
  return coroutine;
}
function flow(block) {
  return new SafeFlow(block);
}
function *_generator_collectSafely__fg77v4($this, collector, $completion) {
  var tmp = $this.x1b_1(collector, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function channelFlow(block) {
  return new ChannelFlowBuilder(block);
}
function *_generator_emitAllImpl__caj84m(_this__u8e3s4, channel, consume, $completion) {
  ensureActive_1(_this__u8e3s4);
  var cause = null;
  try {
    var _iterator__ex2g4s = channel.y();
    $l$loop: while (true) {
      var tmp = _iterator__ex2g4s.o19($completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
      if (!tmp) {
        break $l$loop;
      }
      var element = _iterator__ex2g4s.a1();
      var tmp_0 = _this__u8e3s4.p1c(element, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
    }
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      cause = e;
      throw e;
    } else {
      throw $p;
    }
  }
  finally {
    if (consume) {
      cancelConsumed(channel, cause);
    }
  }
  return Unit_instance;
}
function emitAllImpl(_this__u8e3s4, channel, consume, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_emitAllImpl__caj84m.bind(VOID, _this__u8e3s4, channel, consume), $completion);
}
function emitAll(_this__u8e3s4, channel, $completion) {
  return emitAllImpl(_this__u8e3s4, channel, true, $completion);
}
function *_generator_collect__dlomyy($this, collector, $completion) {
  // Inline function 'kotlin.js.getCoroutineContext' call
  var tmp$ret$0 = $completion.lc();
  var safeCollector = new SafeCollector(collector, tmp$ret$0);
  try {
    var tmp = $this.y1b(safeCollector, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }finally {
    safeCollector.wc();
  }
  return Unit_instance;
}
function get_NO_VALUE() {
  _init_properties_SharedFlow_kt__umasnn();
  return NO_VALUE;
}
var NO_VALUE;
function MutableSharedFlow(replay, extraBufferCapacity, onBufferOverflow) {
  replay = replay === VOID ? 0 : replay;
  extraBufferCapacity = extraBufferCapacity === VOID ? 0 : extraBufferCapacity;
  onBufferOverflow = onBufferOverflow === VOID ? BufferOverflow_SUSPEND_getInstance() : onBufferOverflow;
  _init_properties_SharedFlow_kt__umasnn();
  // Inline function 'kotlin.require' call
  if (!(replay >= 0)) {
    var message = 'replay cannot be negative, but was ' + replay;
    throw IllegalArgumentException.t(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(extraBufferCapacity >= 0)) {
    var message_0 = 'extraBufferCapacity cannot be negative, but was ' + extraBufferCapacity;
    throw IllegalArgumentException.t(toString(message_0));
  }
  // Inline function 'kotlin.require' call
  if (!(replay > 0 || extraBufferCapacity > 0 || onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance()))) {
    var message_1 = 'replay or extraBufferCapacity must be positive with non-default onBufferOverflow strategy ' + onBufferOverflow.toString();
    throw IllegalArgumentException.t(toString(message_1));
  }
  var bufferCapacity0 = replay + extraBufferCapacity | 0;
  var bufferCapacity = bufferCapacity0 < 0 ? 2147483647 : bufferCapacity0;
  return new SharedFlowImpl(replay, bufferCapacity, onBufferOverflow);
}
function _get_head__d7jo8b($this) {
  var tmp0 = $this.d1d_1;
  // Inline function 'kotlin.comparisons.minOf' call
  var b = $this.c1d_1;
  return tmp0.s1(b) <= 0 ? tmp0 : b;
}
function _get_replaySize__dxgnb1($this) {
  var tmp0 = _get_head__d7jo8b($this);
  // Inline function 'kotlin.Long.plus' call
  var other = $this.e1d_1;
  return tmp0.u3(toLong(other)).v3($this.c1d_1).x1();
}
function _get_totalSize__xhdb3o($this) {
  return $this.e1d_1 + $this.f1d_1 | 0;
}
function _get_bufferEndIndex__d2rk18($this) {
  var tmp0 = _get_head__d7jo8b($this);
  // Inline function 'kotlin.Long.plus' call
  var other = $this.e1d_1;
  return tmp0.u3(toLong(other));
}
function _get_queueEndIndex__4m025l($this) {
  var tmp0 = _get_head__d7jo8b($this);
  // Inline function 'kotlin.Long.plus' call
  var other = $this.e1d_1;
  var tmp2 = tmp0.u3(toLong(other));
  // Inline function 'kotlin.Long.plus' call
  var other_0 = $this.f1d_1;
  return tmp2.u3(toLong(other_0));
}
function *_generator_collect__dlomyy_0($this, collector, $completion) {
  var slot = $this.k1d();
  try {
    if (collector instanceof SubscribedFlowCollector) {
      var tmp = collector.n1d($completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
    }
    // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
    // Inline function 'kotlin.js.getCoroutineContext' call
    var collectorJob = $completion.lc().yc(Key_instance_3);
    while (true) {
      var newValue;
      $l$loop: while (true) {
        newValue = tryTakeValue($this, slot);
        if (!(newValue === get_NO_VALUE()))
          break $l$loop;
        var tmp_0 = awaitValue($this, slot, $completion);
        if (tmp_0 === get_COROUTINE_SUSPENDED())
          tmp_0 = yield tmp_0;
      }
      if (collectorJob == null)
        null;
      else {
        ensureActive_0(collectorJob);
      }
      var tmp_1 = collector.p1c((newValue == null ? true : !(newValue == null)) ? newValue : THROW_CCE(), $completion);
      if (tmp_1 === get_COROUTINE_SUSPENDED())
        tmp_1 = yield tmp_1;
    }
  }finally {
    $this.o1d(slot);
  }
}
function *_generator_emit__qph46j($this, value, $completion) {
  if ($this.p1d(value))
    return Unit_instance;
  var tmp = emitSuspend($this, value, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function tryEmitLocked($this, value) {
  if ($this.h1d_1 === 0)
    return tryEmitNoCollectorsLocked($this, value);
  if ($this.e1d_1 >= $this.z1c_1 && $this.d1d_1.s1($this.c1d_1) <= 0) {
    switch ($this.a1d_1.o3_1) {
      case 0:
        return false;
      case 2:
        return true;
      case 1:
        break;
      default:
        noWhenBranchMatchedException();
        break;
    }
  }
  enqueueLocked($this, value);
  $this.e1d_1 = $this.e1d_1 + 1 | 0;
  if ($this.e1d_1 > $this.z1c_1) {
    dropOldestLocked($this);
  }
  if (_get_replaySize__dxgnb1($this) > $this.y1c_1) {
    // Inline function 'kotlin.Long.plus' call
    var tmp$ret$0 = $this.c1d_1.u3(toLong(1));
    updateBufferLocked($this, tmp$ret$0, $this.d1d_1, _get_bufferEndIndex__d2rk18($this), _get_queueEndIndex__4m025l($this));
  }
  return true;
}
function tryEmitNoCollectorsLocked($this, value) {
  // Inline function 'kotlinx.coroutines.assert' call
  if ($this.y1c_1 === 0)
    return true;
  enqueueLocked($this, value);
  $this.e1d_1 = $this.e1d_1 + 1 | 0;
  if ($this.e1d_1 > $this.y1c_1) {
    dropOldestLocked($this);
  }
  var tmp = $this;
  var tmp0 = _get_head__d7jo8b($this);
  // Inline function 'kotlin.Long.plus' call
  var other = $this.e1d_1;
  tmp.d1d_1 = tmp0.u3(toLong(other));
  return true;
}
function dropOldestLocked($this) {
  setBufferAt(ensureNotNull($this.b1d_1), _get_head__d7jo8b($this), null);
  $this.e1d_1 = $this.e1d_1 - 1 | 0;
  // Inline function 'kotlin.Long.plus' call
  var newHead = _get_head__d7jo8b($this).u3(toLong(1));
  if ($this.c1d_1.s1(newHead) < 0)
    $this.c1d_1 = newHead;
  if ($this.d1d_1.s1(newHead) < 0) {
    correctCollectorIndexesOnDropOldest($this, newHead);
  }
  // Inline function 'kotlinx.coroutines.assert' call
}
function correctCollectorIndexesOnDropOldest($this, newHead) {
  $l$block: {
    // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.forEachSlotLocked' call
    if ($this.h1d_1 === 0) {
      break $l$block;
    }
    var tmp0_safe_receiver = $this.g1d_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var inductionVariable = 0;
      var last = tmp0_safe_receiver.length;
      while (inductionVariable < last) {
        var element = tmp0_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (!(element == null)) {
          if (element.q1d_1.s1(new Long(0, 0)) >= 0 && element.q1d_1.s1(newHead) < 0) {
            element.q1d_1 = newHead;
          }
        }
      }
    }
  }
  $this.d1d_1 = newHead;
}
function enqueueLocked($this, item) {
  var curSize = _get_totalSize__xhdb3o($this);
  var curBuffer = $this.b1d_1;
  var buffer = curBuffer == null ? growBuffer($this, null, 0, 2) : curSize >= curBuffer.length ? growBuffer($this, curBuffer, curSize, imul(curBuffer.length, 2)) : curBuffer;
  // Inline function 'kotlin.Long.plus' call
  var tmp$ret$0 = _get_head__d7jo8b($this).u3(toLong(curSize));
  setBufferAt(buffer, tmp$ret$0, item);
}
function growBuffer($this, curBuffer, curSize, newSize) {
  // Inline function 'kotlin.check' call
  if (!(newSize > 0)) {
    var message = 'Buffer size overflow';
    throw IllegalStateException.t4(toString(message));
  }
  // Inline function 'kotlin.arrayOfNulls' call
  // Inline function 'kotlin.also' call
  var this_0 = Array(newSize);
  $this.b1d_1 = this_0;
  var newBuffer = this_0;
  if (curBuffer == null)
    return newBuffer;
  var head = _get_head__d7jo8b($this);
  var inductionVariable = 0;
  if (inductionVariable < curSize)
    do {
      var i = inductionVariable;
      inductionVariable = inductionVariable + 1 | 0;
      // Inline function 'kotlin.Long.plus' call
      var tmp = head.u3(toLong(i));
      // Inline function 'kotlin.Long.plus' call
      var tmp$ret$6 = head.u3(toLong(i));
      setBufferAt(newBuffer, tmp, getBufferAt(curBuffer, tmp$ret$6));
    }
     while (inductionVariable < curSize);
  return newBuffer;
}
function emitSuspend($this, value, $completion) {
  var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
  cancellable.by();
  var resumes = get_EMPTY_RESUMES();
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  var tmp$ret$2;
  $l$block: {
    if (tryEmitLocked($this, value)) {
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
      cancellable.nc(tmp$ret$0);
      resumes = findSlotsToResumeLocked($this, resumes);
      tmp$ret$2 = null;
      break $l$block;
    }
    var tmp2 = _get_head__d7jo8b($this);
    // Inline function 'kotlin.Long.plus' call
    var other = _get_totalSize__xhdb3o($this);
    var tmp$ret$3 = tmp2.u3(toLong(other));
    // Inline function 'kotlin.also' call
    var this_0 = new Emitter($this, tmp$ret$3, value, cancellable);
    enqueueLocked($this, this_0);
    $this.f1d_1 = $this.f1d_1 + 1 | 0;
    if ($this.z1c_1 === 0)
      resumes = findSlotsToResumeLocked($this, resumes);
    tmp$ret$2 = this_0;
  }
  var emitter = tmp$ret$2;
  if (emitter == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    disposeOnCancellation(cancellable, emitter);
  }
  var indexedObject = resumes;
  var inductionVariable = 0;
  var last = indexedObject.length;
  while (inductionVariable < last) {
    var r = indexedObject[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    if (r == null)
      null;
    else {
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var tmp$ret$10 = _Result___init__impl__xyqfz8(Unit_instance);
      r.nc(tmp$ret$10);
    }
  }
  return cancellable.cy();
}
function cancelEmitter($this, emitter) {
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  if (emitter.t1d_1.s1(_get_head__d7jo8b($this)) < 0)
    return Unit_instance;
  var buffer = ensureNotNull($this.b1d_1);
  if (!(getBufferAt(buffer, emitter.t1d_1) === emitter))
    return Unit_instance;
  setBufferAt(buffer, emitter.t1d_1, get_NO_VALUE());
  cleanupTailLocked($this);
  return Unit_instance;
}
function updateBufferLocked($this, newReplayIndex, newMinCollectorIndex, newBufferEndIndex, newQueueEndIndex) {
  // Inline function 'kotlin.comparisons.minOf' call
  var newHead = newMinCollectorIndex.s1(newReplayIndex) <= 0 ? newMinCollectorIndex : newReplayIndex;
  // Inline function 'kotlinx.coroutines.assert' call
  var inductionVariable = _get_head__d7jo8b($this);
  if (inductionVariable.s1(newHead) < 0)
    do {
      var index = inductionVariable;
      inductionVariable = inductionVariable.u3(new Long(1, 0));
      setBufferAt(ensureNotNull($this.b1d_1), index, null);
    }
     while (inductionVariable.s1(newHead) < 0);
  $this.c1d_1 = newReplayIndex;
  $this.d1d_1 = newMinCollectorIndex;
  $this.e1d_1 = newBufferEndIndex.v3(newHead).x1();
  $this.f1d_1 = newQueueEndIndex.v3(newBufferEndIndex).x1();
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
  // Inline function 'kotlinx.coroutines.assert' call
}
function cleanupTailLocked($this) {
  if ($this.z1c_1 === 0 && $this.f1d_1 <= 1)
    return Unit_instance;
  var buffer = ensureNotNull($this.b1d_1);
  $l$loop: while (true) {
    var tmp;
    if ($this.f1d_1 > 0) {
      var tmp0 = _get_head__d7jo8b($this);
      // Inline function 'kotlin.Long.plus' call
      var other = _get_totalSize__xhdb3o($this);
      // Inline function 'kotlin.Long.minus' call
      var tmp$ret$1 = tmp0.u3(toLong(other)).v3(toLong(1));
      tmp = getBufferAt(buffer, tmp$ret$1) === get_NO_VALUE();
    } else {
      tmp = false;
    }
    if (!tmp) {
      break $l$loop;
    }
    $this.f1d_1 = $this.f1d_1 - 1 | 0;
    var tmp4 = _get_head__d7jo8b($this);
    // Inline function 'kotlin.Long.plus' call
    var other_0 = _get_totalSize__xhdb3o($this);
    var tmp$ret$2 = tmp4.u3(toLong(other_0));
    setBufferAt(buffer, tmp$ret$2, null);
  }
}
function tryTakeValue($this, slot) {
  var resumes = get_EMPTY_RESUMES();
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  var index = tryPeekLocked($this, slot);
  var tmp;
  if (index.s1(new Long(0, 0)) < 0) {
    tmp = get_NO_VALUE();
  } else {
    var oldIndex = slot.q1d_1;
    var newValue = getPeekedValueLockedAt($this, index);
    var tmp_0 = slot;
    // Inline function 'kotlin.Long.plus' call
    tmp_0.q1d_1 = index.u3(toLong(1));
    resumes = $this.w1d(oldIndex);
    tmp = newValue;
  }
  var value = tmp;
  var indexedObject = resumes;
  var inductionVariable = 0;
  var last = indexedObject.length;
  while (inductionVariable < last) {
    var resume = indexedObject[inductionVariable];
    inductionVariable = inductionVariable + 1 | 0;
    if (resume == null)
      null;
    else {
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var tmp$ret$4 = _Result___init__impl__xyqfz8(Unit_instance);
      resume.nc(tmp$ret$4);
    }
  }
  return value;
}
function tryPeekLocked($this, slot) {
  var index = slot.q1d_1;
  if (index.s1(_get_bufferEndIndex__d2rk18($this)) < 0)
    return index;
  if ($this.z1c_1 > 0)
    return new Long(-1, -1);
  if (index.s1(_get_head__d7jo8b($this)) > 0)
    return new Long(-1, -1);
  if ($this.f1d_1 === 0)
    return new Long(-1, -1);
  return index;
}
function getPeekedValueLockedAt($this, index) {
  var item = getBufferAt(ensureNotNull($this.b1d_1), index);
  var tmp;
  if (item instanceof Emitter) {
    tmp = item.u1d_1;
  } else {
    tmp = item;
  }
  return tmp;
}
function awaitValue($this, slot, $completion) {
  var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
  cancellable.by();
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  $l$block: {
    var index = tryPeekLocked($this, slot);
    if (index.s1(new Long(0, 0)) < 0) {
      slot.r1d_1 = cancellable;
    } else {
      // Inline function 'kotlin.coroutines.resume' call
      // Inline function 'kotlin.Companion.success' call
      var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
      cancellable.nc(tmp$ret$0);
      break $l$block;
    }
    slot.r1d_1 = cancellable;
  }
  return cancellable.cy();
}
function findSlotsToResumeLocked($this, resumesIn) {
  var resumes = resumesIn;
  var resumeCount = resumesIn.length;
  $l$block: {
    // Inline function 'kotlinx.coroutines.flow.internal.AbstractSharedFlow.forEachSlotLocked' call
    if ($this.h1d_1 === 0) {
      break $l$block;
    }
    var tmp0_safe_receiver = $this.g1d_1;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var inductionVariable = 0;
      var last = tmp0_safe_receiver.length;
      while (inductionVariable < last) {
        var element = tmp0_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (!(element == null)) {
          $l$block_1: {
            var tmp0_elvis_lhs = element.r1d_1;
            var tmp;
            if (tmp0_elvis_lhs == null) {
              break $l$block_1;
            } else {
              tmp = tmp0_elvis_lhs;
            }
            var cont = tmp;
            if (tryPeekLocked($this, element).s1(new Long(0, 0)) < 0) {
              break $l$block_1;
            }
            if (resumeCount >= resumes.length) {
              var tmp_0 = resumes;
              // Inline function 'kotlin.comparisons.maxOf' call
              var b = imul(2, resumes.length);
              var tmp$ret$2 = Math.max(2, b);
              resumes = copyOf(tmp_0, tmp$ret$2);
            }
            var tmp_1 = resumes;
            var _unary__edvuaz = resumeCount;
            resumeCount = _unary__edvuaz + 1 | 0;
            tmp_1[_unary__edvuaz] = cont;
            element.r1d_1 = null;
          }
        }
      }
    }
  }
  return resumes;
}
function getBufferAt(_this__u8e3s4, index) {
  _init_properties_SharedFlow_kt__umasnn();
  return _this__u8e3s4[index.x1() & (_this__u8e3s4.length - 1 | 0)];
}
function setBufferAt(_this__u8e3s4, index, item) {
  _init_properties_SharedFlow_kt__umasnn();
  return _this__u8e3s4[index.x1() & (_this__u8e3s4.length - 1 | 0)] = item;
}
function fuseSharedFlow(_this__u8e3s4, context, capacity, onBufferOverflow) {
  _init_properties_SharedFlow_kt__umasnn();
  if ((capacity === 0 || capacity === -3) && onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance())) {
    return _this__u8e3s4;
  }
  return new ChannelFlowOperatorImpl(_this__u8e3s4, context, capacity, onBufferOverflow);
}
var properties_initialized_SharedFlow_kt_tmefor;
function _init_properties_SharedFlow_kt__umasnn() {
  if (!properties_initialized_SharedFlow_kt_tmefor) {
    properties_initialized_SharedFlow_kt_tmefor = true;
    NO_VALUE = new Symbol('NO_VALUE');
  }
}
function get_NONE() {
  _init_properties_StateFlow_kt__eu9yi5();
  return NONE;
}
var NONE;
function get_PENDING() {
  _init_properties_StateFlow_kt__eu9yi5();
  return PENDING;
}
var PENDING;
function MutableStateFlow(value) {
  _init_properties_StateFlow_kt__eu9yi5();
  return new StateFlowImpl(value == null ? get_NULL() : value);
}
function fuseStateFlow(_this__u8e3s4, context, capacity, onBufferOverflow) {
  _init_properties_StateFlow_kt__eu9yi5();
  // Inline function 'kotlinx.coroutines.assert' call
  if (((0 <= capacity ? capacity <= 1 : false) || capacity === -2) && onBufferOverflow.equals(BufferOverflow_DROP_OLDEST_getInstance())) {
    return _this__u8e3s4;
  }
  return fuseSharedFlow(_this__u8e3s4, context, capacity, onBufferOverflow);
}
function updateState($this, expectedState, newState) {
  var curSequence;
  var curSlots;
  // Inline function 'kotlinx.coroutines.internal.synchronized' call
  // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
  var oldState = $this.j1e_1.kotlinx$atomicfu$value;
  if (!(expectedState == null) && !equals(oldState, expectedState))
    return false;
  if (equals(oldState, newState))
    return true;
  $this.j1e_1.kotlinx$atomicfu$value = newState;
  curSequence = $this.k1e_1;
  if ((curSequence & 1) === 0) {
    curSequence = curSequence + 1 | 0;
    $this.k1e_1 = curSequence;
  } else {
    $this.k1e_1 = curSequence + 2 | 0;
    return true;
  }
  curSlots = $this.g1d_1;
  while (true) {
    var tmp0_safe_receiver = curSlots;
    if (tmp0_safe_receiver == null)
      null;
    else {
      // Inline function 'kotlin.collections.forEach' call
      var inductionVariable = 0;
      var last = tmp0_safe_receiver.length;
      while (inductionVariable < last) {
        var element = tmp0_safe_receiver[inductionVariable];
        inductionVariable = inductionVariable + 1 | 0;
        if (element == null)
          null;
        else {
          element.m1e();
        }
      }
    }
    // Inline function 'kotlinx.coroutines.internal.synchronized' call
    // Inline function 'kotlinx.coroutines.internal.synchronizedImpl' call
    if ($this.k1e_1 === curSequence) {
      $this.k1e_1 = curSequence + 1 | 0;
      return true;
    }
    curSequence = $this.k1e_1;
    curSlots = $this.g1d_1;
  }
}
function *_generator_collect__dlomyy_1($this, collector, $completion) {
  var slot = $this.k1d();
  try {
    if (collector instanceof SubscribedFlowCollector) {
      var tmp = collector.n1d($completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
    }
    // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
    // Inline function 'kotlin.js.getCoroutineContext' call
    var collectorJob = $completion.lc().yc(Key_instance_3);
    var oldState = null;
    while (true) {
      var newState = $this.j1e_1.kotlinx$atomicfu$value;
      if (collectorJob == null)
        null;
      else {
        ensureActive_0(collectorJob);
      }
      if (oldState == null || !equals(oldState, newState)) {
        // Inline function 'kotlinx.coroutines.internal.Symbol.unbox' call
        var tmp_0;
        if (newState === get_NULL()) {
          tmp_0 = (null == null ? true : !(null == null)) ? null : THROW_CCE();
        } else {
          tmp_0 = (newState == null ? true : !(newState == null)) ? newState : THROW_CCE();
        }
        var tmp$ret$2 = tmp_0;
        var tmp_1 = collector.p1c(tmp$ret$2, $completion);
        if (tmp_1 === get_COROUTINE_SUSPENDED())
          tmp_1 = yield tmp_1;
        oldState = newState;
      }
      if (!slot.o1e()) {
        var tmp_2 = slot.n1e($completion);
        if (tmp_2 === get_COROUTINE_SUSPENDED())
          tmp_2 = yield tmp_2;
      }
    }
  }finally {
    $this.o1d(slot);
  }
}
var properties_initialized_StateFlow_kt_nsqikx;
function _init_properties_StateFlow_kt__eu9yi5() {
  if (!properties_initialized_StateFlow_kt_nsqikx) {
    properties_initialized_StateFlow_kt_nsqikx = true;
    NONE = new Symbol('NONE');
    PENDING = new Symbol('PENDING');
  }
}
function get_EMPTY_RESUMES() {
  _init_properties_AbstractSharedFlow_kt__h2xygb();
  return EMPTY_RESUMES;
}
var EMPTY_RESUMES;
var properties_initialized_AbstractSharedFlow_kt_2mpafr;
function _init_properties_AbstractSharedFlow_kt__h2xygb() {
  if (!properties_initialized_AbstractSharedFlow_kt_2mpafr) {
    properties_initialized_AbstractSharedFlow_kt_2mpafr = true;
    // Inline function 'kotlin.arrayOfNulls' call
    EMPTY_RESUMES = Array(0);
  }
}
function *_generator_invoke__zhh2q8($this, it, $completion) {
  var tmp = $this.s1f_1.f1c(it, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function *_generator_invoke__zhh2q8_0($this, $this$coroutineScope, $completion) {
  var tmp = emitAll($this.t1f_1, $this.u1f_1.n1c($this$coroutineScope), $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function ChannelFlow$_get_collectToFun_$slambda_j53z2e_0(this$0) {
  var i = new ChannelFlow$_get_collectToFun_$slambda_j53z2e(this$0);
  var l = (it, $completion) => i.v1f(it, $completion);
  l.$arity = 1;
  return l;
}
function ChannelFlow$collect$slambda_0($collector, this$0) {
  var i = new ChannelFlow$collect$slambda($collector, this$0);
  var l = ($this$coroutineScope, $completion) => i.w1f($this$coroutineScope, $completion);
  l.$arity = 1;
  return l;
}
function *_generator_invoke__zhh2q8_1($this, it, $completion) {
  var tmp = $this.x1f_1.r1f(it, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function collectWithContextUndispatched($this, collector, newContext, $completion) {
  // Inline function 'kotlin.js.getCoroutineContext' call
  var tmp$ret$0 = $completion.lc();
  var originalContextCollector = withUndispatchedContextCollector(collector, tmp$ret$0);
  return withContextUndispatched(newContext, originalContextCollector, VOID, ChannelFlowOperator$collectWithContextUndispatched$slambda_0($this), $completion);
}
function *_generator_collect__dlomyy_2($this, collector, $completion) {
  if ($this.h1c_1 === -3) {
    // Inline function 'kotlin.js.getCoroutineContext' call
    var collectContext = $completion.lc();
    var newContext = newCoroutineContext_0(collectContext, $this.g1c_1);
    if (equals(newContext, collectContext)) {
      var tmp = $this.r1f(collector, $completion);
      if (tmp === get_COROUTINE_SUSPENDED())
        tmp = yield tmp;
      return Unit_instance;
    }
    if (equals(newContext.yc(Key_instance), collectContext.yc(Key_instance))) {
      var tmp_0 = collectWithContextUndispatched($this, collector, newContext, $completion);
      if (tmp_0 === get_COROUTINE_SUSPENDED())
        tmp_0 = yield tmp_0;
      return Unit_instance;
    }
  }
  var tmp_1 = protoOf(ChannelFlow).z1b.call($this, collector, $completion);
  if (tmp_1 === get_COROUTINE_SUSPENDED())
    tmp_1 = yield tmp_1;
  return Unit_instance;
}
function ChannelFlowOperator$collectWithContextUndispatched$slambda_0(this$0) {
  var i = new ChannelFlowOperator$collectWithContextUndispatched$slambda(this$0);
  var l = (it, $completion) => i.y1f(it, $completion);
  l.$arity = 1;
  return l;
}
function withUndispatchedContextCollector(_this__u8e3s4, emitContext) {
  var tmp;
  var tmp_0;
  if (_this__u8e3s4 instanceof SendingCollector) {
    tmp_0 = true;
  } else {
    tmp_0 = _this__u8e3s4 instanceof NopCollector;
  }
  if (tmp_0) {
    tmp = _this__u8e3s4;
  } else {
    tmp = new UndispatchedContextCollector(_this__u8e3s4, emitContext);
  }
  return tmp;
}
function withContextUndispatched(newContext, value, countOrElement, block, $completion) {
  countOrElement = countOrElement === VOID ? threadContextElements(newContext) : countOrElement;
  // Inline function 'kotlinx.coroutines.withCoroutineContext' call
  // Inline function 'kotlin.coroutines.intrinsics.startCoroutineUninterceptedOrReturn' call
  var completion = new StackFrameContinuation($completion, newContext);
  return startCoroutineUninterceptedOrReturnGeneratorVersion(block, value, completion);
}
function *_generator_invoke__zhh2q8_2($this, it, $completion) {
  var tmp = $this.z1f_1.p1c(it, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function UndispatchedContextCollector$emitRef$slambda_0($downstream) {
  var i = new UndispatchedContextCollector$emitRef$slambda($downstream);
  var l = (it, $completion) => i.a1g(it, $completion);
  l.$arity = 1;
  return l;
}
function checkOwnership(_this__u8e3s4, owner) {
  if (!(_this__u8e3s4.k1g_1 === owner))
    throw _this__u8e3s4;
}
function get_NULL() {
  _init_properties_NullSurrogate_kt__n2yti9();
  return NULL;
}
var NULL;
var UNINITIALIZED;
var DONE;
var properties_initialized_NullSurrogate_kt_39v8bl;
function _init_properties_NullSurrogate_kt__n2yti9() {
  if (!properties_initialized_NullSurrogate_kt_39v8bl) {
    properties_initialized_NullSurrogate_kt_39v8bl = true;
    NULL = new Symbol('NULL');
    UNINITIALIZED = new Symbol('UNINITIALIZED');
    DONE = new Symbol('DONE');
  }
}
function checkContext(_this__u8e3s4, currentContext) {
  var result = currentContext.cn(0, checkContext$lambda(_this__u8e3s4));
  if (!(result === _this__u8e3s4.s1c_1)) {
    // Inline function 'kotlin.error' call
    var message = 'Flow invariant is violated:\n' + ('\t\tFlow was collected in ' + toString(_this__u8e3s4.r1c_1) + ',\n') + ('\t\tbut emission happened in ' + toString(currentContext) + '.\n') + "\t\tPlease refer to 'flow' documentation or use 'flowOn' instead";
    throw IllegalStateException.t4(toString(message));
  }
}
function transitiveCoroutineParent(_this__u8e3s4, collectJob) {
  var $this = _this__u8e3s4;
  var collectJob_0 = collectJob;
  $l$1: do {
    $l$0: do {
      if ($this === null)
        return null;
      if ($this === collectJob_0)
        return $this;
      if (!($this instanceof ScopeCoroutine))
        return $this;
      var tmp0 = $this.ev();
      var tmp1 = collectJob_0;
      $this = tmp0;
      collectJob_0 = tmp1;
      continue $l$0;
    }
     while (false);
  }
   while (true);
}
function checkContext$lambda($this_checkContext) {
  return (count, element) => {
    var key = element.m1();
    var collectElement = $this_checkContext.r1c_1.yc(key);
    var tmp;
    if (!(key === Key_instance_3)) {
      return !(element === collectElement) ? -2147483648 : count + 1 | 0;
    }
    var collectJob = (collectElement == null ? true : isInterface(collectElement, Job)) ? collectElement : THROW_CCE();
    var emissionParentJob = transitiveCoroutineParent(isInterface(element, Job) ? element : THROW_CCE(), collectJob);
    var tmp_0;
    if (!(emissionParentJob === collectJob)) {
      var message = 'Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n' + ('\t\tChild of ' + toString_0(emissionParentJob) + ', expected child of ' + toString_0(collectJob) + '.\n') + '\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n' + "\t\tTo mitigate this restriction please use 'channelFlow' builder instead of 'flow'";
      throw IllegalStateException.t4(toString(message));
    }
    return collectJob == null ? count : count + 1 | 0;
  };
}
function buffer(_this__u8e3s4, capacity, onBufferOverflow) {
  capacity = capacity === VOID ? -2 : capacity;
  onBufferOverflow = onBufferOverflow === VOID ? BufferOverflow_SUSPEND_getInstance() : onBufferOverflow;
  // Inline function 'kotlin.require' call
  if (!(capacity >= 0 || capacity === -2 || capacity === -1)) {
    var message = 'Buffer size should be non-negative, BUFFERED, or CONFLATED, but was ' + capacity;
    throw IllegalArgumentException.t(toString(message));
  }
  // Inline function 'kotlin.require' call
  if (!(!(capacity === -1) || onBufferOverflow.equals(BufferOverflow_SUSPEND_getInstance()))) {
    var message_0 = 'CONFLATED capacity cannot be used with non-default onBufferOverflow';
    throw IllegalArgumentException.t(toString(message_0));
  }
  var capacity_0 = capacity;
  var onBufferOverflow_0 = onBufferOverflow;
  if (capacity_0 === -1) {
    capacity_0 = 0;
    onBufferOverflow_0 = BufferOverflow_DROP_OLDEST_getInstance();
  }
  var tmp;
  if (isInterface(_this__u8e3s4, FusibleFlow)) {
    tmp = _this__u8e3s4.m1c(VOID, capacity_0, onBufferOverflow_0);
  } else {
    tmp = new ChannelFlowOperatorImpl(_this__u8e3s4, VOID, capacity_0, onBufferOverflow_0);
  }
  return tmp;
}
function ensureActive_1(_this__u8e3s4) {
  if (_this__u8e3s4 instanceof ThrowingCollector)
    throw _this__u8e3s4.n1g_1;
}
function asSharedFlow(_this__u8e3s4) {
  return new ReadonlySharedFlow(_this__u8e3s4, null);
}
function asStateFlow(_this__u8e3s4) {
  return new ReadonlyStateFlow(_this__u8e3s4, null);
}
function *_generator_onSubscription__25ehyk($this, $completion) {
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var tmp$ret$1 = $completion.lc();
  var safeCollector = new SafeCollector($this.l1d_1, tmp$ret$1);
  try {
    var tmp = $this.m1d_1(safeCollector, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  }finally {
    safeCollector.wc();
  }
  var tmp_0 = $this.l1d_1;
  if (tmp_0 instanceof SubscribedFlowCollector) {
    var tmp_1 = $this.l1d_1.n1d($completion);
    if (tmp_1 === get_COROUTINE_SUSPENDED())
      tmp_1 = yield tmp_1;
  }
  return Unit_instance;
}
function *_generator_collect__dlomyy_3($this, collector, $completion) {
  var tmp = $this.o1g_1.z1b(collector, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  throwKotlinNothingValueException();
}
function *_generator_collect__dlomyy_4($this, collector, $completion) {
  var tmp = $this.q1g_1.z1b(collector, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  throwKotlinNothingValueException();
}
function *_generator_emitAll__ugcct6(_this__u8e3s4, flow, $completion) {
  ensureActive_1(_this__u8e3s4);
  var tmp = flow.z1b(_this__u8e3s4, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function emitAll_0(_this__u8e3s4, flow, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_emitAll__ugcct6.bind(VOID, _this__u8e3s4, flow), $completion);
}
function *_generator_first__oum9l0(_this__u8e3s4, predicate, $completion) {
  var result = {_v: get_NULL()};
  // Inline function 'kotlinx.coroutines.flow.collectWhile' call
  var collector = new first$$inlined$collectWhile$1(predicate, result);
  try {
    var tmp = _this__u8e3s4.z1b(collector, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  } catch ($p) {
    if ($p instanceof AbortFlowException) {
      var e = $p;
      checkOwnership(e, collector);
      // Inline function 'kotlin.js.getCoroutineContext' call
      var tmp$ret$0 = $completion.lc();
      ensureActive(tmp$ret$0);
    } else {
      throw $p;
    }
  }
  if (result._v === get_NULL())
    throw NoSuchElementException.p('Expected at least one element matching the predicate');
  var tmp_0 = result._v;
  return (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
}
function first(_this__u8e3s4, predicate, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_first__oum9l0.bind(VOID, _this__u8e3s4, predicate), $completion);
}
function *_generator_firstOrNull__qcheue(_this__u8e3s4, $completion) {
  var result = {_v: null};
  // Inline function 'kotlinx.coroutines.flow.collectWhile' call
  var collector = new firstOrNull$$inlined$collectWhile$1(result);
  try {
    var tmp = _this__u8e3s4.z1b(collector, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  } catch ($p) {
    if ($p instanceof AbortFlowException) {
      var e = $p;
      checkOwnership(e, collector);
      // Inline function 'kotlin.js.getCoroutineContext' call
      var tmp$ret$0 = $completion.lc();
      ensureActive(tmp$ret$0);
    } else {
      throw $p;
    }
  }
  return result._v;
}
function firstOrNull(_this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_firstOrNull__qcheue.bind(VOID, _this__u8e3s4), $completion);
}
function *_generator_first__oum9l0_0(_this__u8e3s4, $completion) {
  var result = {_v: get_NULL()};
  // Inline function 'kotlinx.coroutines.flow.collectWhile' call
  var collector = new first$$inlined$collectWhile$2(result);
  try {
    var tmp = _this__u8e3s4.z1b(collector, $completion);
    if (tmp === get_COROUTINE_SUSPENDED())
      tmp = yield tmp;
  } catch ($p) {
    if ($p instanceof AbortFlowException) {
      var e = $p;
      checkOwnership(e, collector);
      // Inline function 'kotlin.js.getCoroutineContext' call
      var tmp$ret$0 = $completion.lc();
      ensureActive(tmp$ret$0);
    } else {
      throw $p;
    }
  }
  if (result._v === get_NULL())
    throw NoSuchElementException.p('Expected at least one element');
  var tmp_0 = result._v;
  return (tmp_0 == null ? true : !(tmp_0 == null)) ? tmp_0 : THROW_CCE();
}
function first_0(_this__u8e3s4, $completion) {
  return suspendOrReturn(/*#__NOINLINE__*/_generator_first__oum9l0_0.bind(VOID, _this__u8e3s4), $completion);
}
function *_generator_emit__qph46j_0($this, value, $completion) {
  var tmp;
  var tmp_0 = $this.s1g_1(value, $completion);
  if (tmp_0 === get_COROUTINE_SUSPENDED())
    tmp_0 = yield tmp_0;
  if (tmp_0) {
    $this.t1g_1._v = value;
    tmp = false;
  } else {
    tmp = true;
  }
  if (!tmp) {
    throw AbortFlowException.u1g($this);
  }
  return Unit_instance;
}
function set_value(_this__u8e3s4, value) {
  return _this__u8e3s4.y1g(value);
}
function get_value(_this__u8e3s4) {
  return _this__u8e3s4.x12();
}
function get_CLOSED() {
  _init_properties_ConcurrentLinkedList_kt__5gcgzy();
  return CLOSED;
}
var CLOSED;
function close(_this__u8e3s4) {
  _init_properties_ConcurrentLinkedList_kt__5gcgzy();
  var cur = _this__u8e3s4;
  while (true) {
    // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.nextOrIfClosed' call
    var this_0 = cur;
    // Inline function 'kotlin.let' call
    var it = access$_get_nextOrClosed__ywzond(this_0);
    var tmp;
    if (it === access$_get_CLOSED_$tConcurrentLinkedListKt_wmtpdy()) {
      return cur;
    } else {
      tmp = (it == null ? true : it instanceof ConcurrentLinkedListNode) ? it : THROW_CCE();
    }
    var next = tmp;
    if (next === null) {
      if (cur.s18())
        return cur;
    } else {
      cur = next;
    }
  }
}
function _SegmentOrClosed___init__impl__jnexvb(value) {
  return value;
}
function _get_value__a43j40($this) {
  return $this;
}
function _SegmentOrClosed___get_isClosed__impl__qmxmlo($this) {
  return _get_value__a43j40($this) === get_CLOSED();
}
function _SegmentOrClosed___get_segment__impl__jvcr9l($this) {
  var tmp;
  if (_get_value__a43j40($this) === get_CLOSED()) {
    var message = 'Does not contain segment';
    throw IllegalStateException.t4(toString(message));
  } else {
    var tmp_0 = _get_value__a43j40($this);
    tmp = tmp_0 instanceof Segment ? tmp_0 : THROW_CCE();
  }
  return tmp;
}
function SegmentOrClosed__toString_impl_pzb2an($this) {
  return 'SegmentOrClosed(value=' + toString_0($this) + ')';
}
function SegmentOrClosed__hashCode_impl_4855hs($this) {
  return $this == null ? 0 : hashCode($this);
}
function SegmentOrClosed__equals_impl_6erq1g($this, other) {
  if (!(other instanceof SegmentOrClosed))
    return false;
  var tmp0_other_with_cast = other instanceof SegmentOrClosed ? other.a1a_1 : THROW_CCE();
  if (!equals($this, tmp0_other_with_cast))
    return false;
  return true;
}
function _get_nextOrClosed__w0gmuv($this) {
  return $this.l18_1.kotlinx$atomicfu$value;
}
function _get_aliveSegmentLeft__mr4ndu($this) {
  var cur = $this.q18();
  while (!(cur === null) && cur.i18())
    cur = cur.m18_1.kotlinx$atomicfu$value;
  return cur;
}
function _get_aliveSegmentRight__7ulr0b($this) {
  // Inline function 'kotlinx.coroutines.assert' call
  var cur = ensureNotNull($this.n18());
  while (cur.i18()) {
    var tmp0_elvis_lhs = cur.n18();
    var tmp;
    if (tmp0_elvis_lhs == null) {
      return cur;
    } else {
      tmp = tmp0_elvis_lhs;
    }
    cur = tmp;
  }
  return cur;
}
function access$_get_nextOrClosed__ywzond($this) {
  return _get_nextOrClosed__w0gmuv($this);
}
function findSegmentInternal(_this__u8e3s4, id, createNewSegment) {
  _init_properties_ConcurrentLinkedList_kt__5gcgzy();
  var cur = _this__u8e3s4;
  $l$loop: while (cur.vz_1.s1(id) < 0 || cur.i18()) {
    // Inline function 'kotlinx.coroutines.internal.ConcurrentLinkedListNode.nextOrIfClosed' call
    var this_0 = cur;
    // Inline function 'kotlin.let' call
    var it = access$_get_nextOrClosed__ywzond(this_0);
    var tmp;
    if (it === access$_get_CLOSED_$tConcurrentLinkedListKt_wmtpdy()) {
      return _SegmentOrClosed___init__impl__jnexvb(get_CLOSED());
    } else {
      tmp = (it == null ? true : it instanceof ConcurrentLinkedListNode) ? it : THROW_CCE();
    }
    var next = tmp;
    if (!(next == null)) {
      cur = next;
      continue $l$loop;
    }
    // Inline function 'kotlin.Long.plus' call
    var newTail = createNewSegment(cur.vz_1.u3(toLong(1)), cur);
    if (cur.o18(newTail)) {
      if (cur.i18()) {
        cur.e6();
      }
      cur = newTail;
    }
  }
  return _SegmentOrClosed___init__impl__jnexvb(cur);
}
function access$_get_CLOSED_$tConcurrentLinkedListKt_wmtpdy() {
  return get_CLOSED();
}
var properties_initialized_ConcurrentLinkedList_kt_kwt434;
function _init_properties_ConcurrentLinkedList_kt__5gcgzy() {
  if (!properties_initialized_ConcurrentLinkedList_kt_kwt434) {
    properties_initialized_ConcurrentLinkedList_kt_kwt434 = true;
    CLOSED = new Symbol('CLOSED');
  }
}
function handleUncaughtCoroutineException(context, exception) {
  var _iterator__ex2g4s = get_platformExceptionHandlers().y();
  while (_iterator__ex2g4s.z()) {
    var handler = _iterator__ex2g4s.a1();
    try {
      handler.c12(context, exception);
    } catch ($p) {
      if ($p instanceof ExceptionSuccessfullyProcessed) {
        var _unused_var__etf5q3 = $p;
        return Unit_instance;
      } else {
        if ($p instanceof Error) {
          var t = $p;
          propagateExceptionFinalResort(handlerException(exception, t));
        } else {
          throw $p;
        }
      }
    }
  }
  try {
    addSuppressed(exception, DiagnosticCoroutineContextException.c1h(context));
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
    } else {
      throw $p;
    }
  }
  propagateExceptionFinalResort(exception);
}
function get_UNDEFINED() {
  _init_properties_DispatchedContinuation_kt__tnmqc0();
  return UNDEFINED;
}
var UNDEFINED;
function get_REUSABLE_CLAIMED() {
  _init_properties_DispatchedContinuation_kt__tnmqc0();
  return REUSABLE_CLAIMED;
}
var REUSABLE_CLAIMED;
function _get_reusableCancellableContinuation__9qex09($this) {
  var tmp = $this.nz_1.kotlinx$atomicfu$value;
  return tmp instanceof CancellableContinuationImpl ? tmp : null;
}
function safeDispatch(_this__u8e3s4, context, runnable) {
  _init_properties_DispatchedContinuation_kt__tnmqc0();
  try {
    _this__u8e3s4.x11(context, runnable);
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      throw DispatchException.e1h(e, _this__u8e3s4, context);
    } else {
      throw $p;
    }
  }
}
function safeIsDispatchNeeded(_this__u8e3s4, context) {
  _init_properties_DispatchedContinuation_kt__tnmqc0();
  try {
    return _this__u8e3s4.w11(context);
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      throw DispatchException.e1h(e, _this__u8e3s4, context);
    } else {
      throw $p;
    }
  }
}
function resumeCancellableWith(_this__u8e3s4, result) {
  _init_properties_DispatchedContinuation_kt__tnmqc0();
  var tmp;
  if (_this__u8e3s4 instanceof DispatchedContinuation) {
    // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.resumeCancellableWith' call
    var state = toState_0(result);
    if (safeIsDispatchNeeded(_this__u8e3s4.jz_1, _this__u8e3s4.lc())) {
      _this__u8e3s4.lz_1 = state;
      _this__u8e3s4.rz_1 = 1;
      safeDispatch(_this__u8e3s4.jz_1, _this__u8e3s4.lc(), _this__u8e3s4);
    } else {
      $l$block: {
        // Inline function 'kotlinx.coroutines.internal.executeUnconfined' call
        // Inline function 'kotlinx.coroutines.assert' call
        var eventLoop = ThreadLocalEventLoop_getInstance().v12();
        if (false && eventLoop.q12()) {
          break $l$block;
        }
        var tmp_0;
        if (eventLoop.p12()) {
          _this__u8e3s4.lz_1 = state;
          _this__u8e3s4.rz_1 = 1;
          eventLoop.o12(_this__u8e3s4);
          tmp_0 = true;
        } else {
          // Inline function 'kotlinx.coroutines.runUnconfinedEventLoop' call
          eventLoop.r12(true);
          try {
            var tmp$ret$4;
            $l$block_0: {
              // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.resumeCancelled' call
              var job = _this__u8e3s4.lc().yc(Key_instance_3);
              if (!(job == null) && !job.lu()) {
                var cause = job.kv();
                _this__u8e3s4.o10(state, cause);
                // Inline function 'kotlin.coroutines.resumeWithException' call
                // Inline function 'kotlin.Companion.failure' call
                var tmp$ret$2 = _Result___init__impl__xyqfz8(createFailure(cause));
                _this__u8e3s4.nc(tmp$ret$2);
                tmp$ret$4 = true;
                break $l$block_0;
              }
              tmp$ret$4 = false;
            }
            if (!tmp$ret$4) {
              // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.resumeUndispatchedWith' call
              _this__u8e3s4.kz_1;
              // Inline function 'kotlinx.coroutines.withContinuationContext' call
              _this__u8e3s4.mz_1;
              _this__u8e3s4.kz_1.nc(result);
            }
            $l$loop: while (eventLoop.n12()) {
            }
          } catch ($p) {
            if ($p instanceof Error) {
              var e = $p;
              _this__u8e3s4.i11(e);
            } else {
              throw $p;
            }
          }
          finally {
            eventLoop.s12(true);
          }
          tmp_0 = false;
        }
      }
    }
    tmp = Unit_instance;
  } else {
    _this__u8e3s4.nc(result);
    tmp = Unit_instance;
  }
  return tmp;
}
var properties_initialized_DispatchedContinuation_kt_2siadq;
function _init_properties_DispatchedContinuation_kt__tnmqc0() {
  if (!properties_initialized_DispatchedContinuation_kt_2siadq) {
    properties_initialized_DispatchedContinuation_kt_2siadq = true;
    UNDEFINED = new Symbol('UNDEFINED');
    REUSABLE_CLAIMED = new Symbol('REUSABLE_CLAIMED');
  }
}
function get_isReusableMode(_this__u8e3s4) {
  return _this__u8e3s4 === 2;
}
function get_isCancellableMode(_this__u8e3s4) {
  return _this__u8e3s4 === 1 || _this__u8e3s4 === 2;
}
function dispatch(_this__u8e3s4, mode) {
  // Inline function 'kotlinx.coroutines.assert' call
  var delegate = _this__u8e3s4.m10();
  var undispatched = mode === 4;
  var tmp;
  var tmp_0;
  if (!undispatched) {
    tmp_0 = delegate instanceof DispatchedContinuation;
  } else {
    tmp_0 = false;
  }
  if (tmp_0) {
    tmp = get_isCancellableMode(mode) === get_isCancellableMode(_this__u8e3s4.rz_1);
  } else {
    tmp = false;
  }
  if (tmp) {
    var dispatcher = delegate.jz_1;
    var context = delegate.lc();
    if (safeIsDispatchNeeded(dispatcher, context)) {
      safeDispatch(dispatcher, context, _this__u8e3s4);
    } else {
      resumeUnconfined(_this__u8e3s4);
    }
  } else {
    resume(_this__u8e3s4, delegate, undispatched);
  }
}
function resumeUnconfined(_this__u8e3s4) {
  var eventLoop = ThreadLocalEventLoop_getInstance().v12();
  if (eventLoop.p12()) {
    eventLoop.o12(_this__u8e3s4);
  } else {
    // Inline function 'kotlinx.coroutines.runUnconfinedEventLoop' call
    eventLoop.r12(true);
    try {
      resume(_this__u8e3s4, _this__u8e3s4.m10(), true);
      $l$loop: while (eventLoop.n12()) {
      }
    } catch ($p) {
      if ($p instanceof Error) {
        var e = $p;
        _this__u8e3s4.i11(e);
      } else {
        throw $p;
      }
    }
    finally {
      eventLoop.s12(true);
    }
  }
}
function resume(_this__u8e3s4, delegate, undispatched) {
  var state = _this__u8e3s4.n10();
  var exception = _this__u8e3s4.f11(state);
  var tmp;
  if (!(exception == null)) {
    // Inline function 'kotlin.Companion.failure' call
    tmp = _Result___init__impl__xyqfz8(createFailure(exception));
  } else {
    // Inline function 'kotlin.Companion.success' call
    var value = _this__u8e3s4.v10(state);
    tmp = _Result___init__impl__xyqfz8(value);
  }
  var result = tmp;
  if (undispatched) {
    // Inline function 'kotlinx.coroutines.internal.DispatchedContinuation.resumeUndispatchedWith' call
    var this_0 = delegate instanceof DispatchedContinuation ? delegate : THROW_CCE();
    this_0.kz_1;
    // Inline function 'kotlinx.coroutines.withContinuationContext' call
    this_0.mz_1;
    this_0.kz_1.nc(result);
  } else {
    delegate.nc(result);
  }
}
function _InlineList___init__impl__z8n56(holder) {
  holder = holder === VOID ? null : holder;
  return holder;
}
function _get_holder__f6h5pd($this) {
  return $this;
}
function InlineList__plus_impl_nuetvo($this, element) {
  // Inline function 'kotlinx.coroutines.assert' call
  var tmp0_subject = _get_holder__f6h5pd($this);
  var tmp;
  if (tmp0_subject == null) {
    tmp = _InlineList___init__impl__z8n56(element);
  } else {
    if (tmp0_subject instanceof ArrayList) {
      var tmp_0 = _get_holder__f6h5pd($this);
      (tmp_0 instanceof ArrayList ? tmp_0 : THROW_CCE()).l(element);
      tmp = _InlineList___init__impl__z8n56(_get_holder__f6h5pd($this));
    } else {
      var list = ArrayList.x(4);
      var tmp_1 = _get_holder__f6h5pd($this);
      list.l((tmp_1 == null ? true : !(tmp_1 == null)) ? tmp_1 : THROW_CCE());
      list.l(element);
      tmp = _InlineList___init__impl__z8n56(list);
    }
  }
  return tmp;
}
function access$_get_holder__kkflen($this) {
  return _get_holder__f6h5pd($this);
}
function callUndeliveredElement(_this__u8e3s4, element, context) {
  var tmp0_safe_receiver = callUndeliveredElementCatchingException(_this__u8e3s4, element, null);
  if (tmp0_safe_receiver == null)
    null;
  else {
    // Inline function 'kotlin.let' call
    handleCoroutineException(context, tmp0_safe_receiver);
  }
}
function callUndeliveredElementCatchingException(_this__u8e3s4, element, undeliveredElementException) {
  undeliveredElementException = undeliveredElementException === VOID ? null : undeliveredElementException;
  try {
    _this__u8e3s4(element);
  } catch ($p) {
    if ($p instanceof Error) {
      var ex = $p;
      if (!(undeliveredElementException == null) && !(undeliveredElementException.cause === ex)) {
        addSuppressed(undeliveredElementException, ex);
      } else {
        return UndeliveredElementException.i1h('Exception in undelivered element handler for ' + toString_0(element), ex);
      }
    } else {
      throw $p;
    }
  }
  return undeliveredElementException;
}
function systemProp(propertyName, defaultValue, minValue, maxValue) {
  minValue = minValue === VOID ? 1 : minValue;
  maxValue = maxValue === VOID ? 2147483647 : maxValue;
  return systemProp_0(propertyName, toLong(defaultValue), toLong(minValue), toLong(maxValue)).x1();
}
function systemProp_0(propertyName, defaultValue, minValue, maxValue) {
  minValue = minValue === VOID ? new Long(1, 0) : minValue;
  maxValue = maxValue === VOID ? new Long(-1, 2147483647) : maxValue;
  var tmp0_elvis_lhs = systemProp_1(propertyName);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return defaultValue;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var value = tmp;
  var tmp1_elvis_lhs = toLongOrNull(value);
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    var message = "System property '" + propertyName + "' has unrecognized value '" + value + "'";
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  var parsed = tmp_0;
  if (!(minValue.s1(parsed) <= 0 ? parsed.s1(maxValue) <= 0 : false)) {
    // Inline function 'kotlin.error' call
    var message_0 = "System property '" + propertyName + "' should be in range " + minValue.toString() + '..' + maxValue.toString() + ", but is '" + parsed.toString() + "'";
    throw IllegalStateException.t4(toString(message_0));
  }
  return parsed;
}
function startCoroutineCancellable(_this__u8e3s4, receiver, completion) {
  // Inline function 'kotlinx.coroutines.intrinsics.runSafely' call
  try {
    var tmp = intercepted(createCoroutineUninterceptedGeneratorVersion(_this__u8e3s4, receiver, completion));
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
    resumeCancellableWith(tmp, tmp$ret$0);
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      dispatcherFailure(completion, e);
    } else {
      throw $p;
    }
  }
  return Unit_instance;
}
function startCoroutineCancellable_0(_this__u8e3s4, fatalCompletion) {
  // Inline function 'kotlinx.coroutines.intrinsics.runSafely' call
  try {
    var tmp = intercepted(_this__u8e3s4);
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
    resumeCancellableWith(tmp, tmp$ret$0);
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      dispatcherFailure(fatalCompletion, e);
    } else {
      throw $p;
    }
  }
  return Unit_instance;
}
function dispatcherFailure(completion, e) {
  var tmp;
  if (e instanceof DispatchException) {
    tmp = e.a12_1;
  } else {
    tmp = e;
  }
  var reportException = tmp;
  // Inline function 'kotlin.Companion.failure' call
  var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(reportException));
  completion.nc(tmp$ret$0);
  throw reportException;
}
function startCoroutineCancellable_1(_this__u8e3s4, completion) {
  // Inline function 'kotlinx.coroutines.intrinsics.runSafely' call
  try {
    var tmp = intercepted(createCoroutineUninterceptedGeneratorVersion_0(_this__u8e3s4, completion));
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(Unit_instance);
    resumeCancellableWith(tmp, tmp$ret$0);
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      dispatcherFailure(completion, e);
    } else {
      throw $p;
    }
  }
  return Unit_instance;
}
function startUndispatchedOrReturn(_this__u8e3s4, receiver, block) {
  return startUndspatched(_this__u8e3s4, true, receiver, block);
}
function startUndispatchedOrReturnIgnoreTimeout(_this__u8e3s4, receiver, block) {
  return startUndspatched(_this__u8e3s4, false, receiver, block);
}
function startCoroutineUndispatched(_this__u8e3s4, receiver, completion) {
  // Inline function 'kotlinx.coroutines.internal.probeCoroutineCreated' call
  var actualCompletion = completion;
  var tmp;
  try {
    // Inline function 'kotlinx.coroutines.withCoroutineContext' call
    actualCompletion.lc();
    // Inline function 'kotlinx.coroutines.internal.probeCoroutineResumed' call
    // Inline function 'kotlin.coroutines.intrinsics.startCoroutineUninterceptedOrReturn' call
    tmp = startCoroutineUninterceptedOrReturnGeneratorVersion(_this__u8e3s4, receiver, actualCompletion);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof Error) {
      var e = $p;
      var tmp_1;
      if (e instanceof DispatchException) {
        tmp_1 = e.a12_1;
      } else {
        tmp_1 = e;
      }
      var reportException = tmp_1;
      // Inline function 'kotlin.coroutines.resumeWithException' call
      // Inline function 'kotlin.Companion.failure' call
      var tmp$ret$5 = _Result___init__impl__xyqfz8(createFailure(reportException));
      actualCompletion.nc(tmp$ret$5);
      return Unit_instance;
    } else {
      throw $p;
    }
  }
  var value = tmp;
  if (!(value === get_COROUTINE_SUSPENDED())) {
    // Inline function 'kotlin.coroutines.resume' call
    // Inline function 'kotlin.Companion.success' call
    var value_0 = (value == null ? true : !(value == null)) ? value : THROW_CCE();
    var tmp$ret$7 = _Result___init__impl__xyqfz8(value_0);
    actualCompletion.nc(tmp$ret$7);
  }
}
function startUndspatched(_this__u8e3s4, alwaysRethrow, receiver, block) {
  var tmp;
  try {
    // Inline function 'kotlin.coroutines.intrinsics.startCoroutineUninterceptedOrReturn' call
    tmp = startCoroutineUninterceptedOrReturnGeneratorVersion(block, receiver, _this__u8e3s4);
  } catch ($p) {
    var tmp_0;
    if ($p instanceof DispatchException) {
      var e = $p;
      dispatchExceptionAndMakeCompleting(_this__u8e3s4, e);
    } else {
      if ($p instanceof Error) {
        var e_0 = $p;
        tmp_0 = new CompletedExceptionally(e_0);
      } else {
        throw $p;
      }
    }
    tmp = tmp_0;
  }
  var result = tmp;
  if (result === get_COROUTINE_SUSPENDED())
    return get_COROUTINE_SUSPENDED();
  var state = _this__u8e3s4.tu(result);
  if (state === get_COMPLETING_WAITING_CHILDREN())
    return get_COROUTINE_SUSPENDED();
  _this__u8e3s4.uy();
  var tmp_1;
  if (state instanceof CompletedExceptionally) {
    var tmp_2;
    if (alwaysRethrow || notOwnTimeout(_this__u8e3s4, state.qu_1)) {
      throw recoverStackTrace(state.qu_1, _this__u8e3s4.ty_1);
    } else {
      if (result instanceof CompletedExceptionally) {
        throw recoverStackTrace(result.qu_1, _this__u8e3s4.ty_1);
      } else {
        tmp_2 = result;
      }
    }
    tmp_1 = tmp_2;
  } else {
    tmp_1 = unboxState(state);
  }
  return tmp_1;
}
function dispatchExceptionAndMakeCompleting(_this__u8e3s4, e) {
  _this__u8e3s4.cw(new CompletedExceptionally(e.a12_1));
  throw recoverStackTrace(e.a12_1, _this__u8e3s4.ty_1);
}
function notOwnTimeout(_this__u8e3s4, cause) {
  var tmp;
  if (!(cause instanceof TimeoutCancellationException)) {
    tmp = true;
  } else {
    tmp = !(cause.r16_1 === _this__u8e3s4);
  }
  return tmp;
}
var DUMMY_PROCESS_RESULT_FUNCTION;
function get_STATE_REG() {
  _init_properties_Select_kt__zhm2jg();
  return STATE_REG;
}
var STATE_REG;
function get_STATE_COMPLETED() {
  _init_properties_Select_kt__zhm2jg();
  return STATE_COMPLETED;
}
var STATE_COMPLETED;
function get_STATE_CANCELLED() {
  _init_properties_Select_kt__zhm2jg();
  return STATE_CANCELLED;
}
var STATE_CANCELLED;
function get_NO_RESULT() {
  _init_properties_Select_kt__zhm2jg();
  return NO_RESULT;
}
var NO_RESULT;
var PARAM_CLAUSE_0;
function trySelectInternal($this, clauseObject, internalResult) {
  $l$loop: while (true) {
    var curState = $this.k19_1.kotlinx$atomicfu$value;
    if (isInterface(curState, CancellableContinuation)) {
      var tmp0_elvis_lhs = findClause($this, clauseObject);
      var tmp;
      if (tmp0_elvis_lhs == null) {
        continue $l$loop;
      } else {
        tmp = tmp0_elvis_lhs;
      }
      var clause = tmp;
      var onCancellation = clause.p1h($this, internalResult);
      if ($this.k19_1.atomicfu$compareAndSet(curState, clause)) {
        var cont = isInterface(curState, CancellableContinuation) ? curState : THROW_CCE();
        $this.m19_1 = internalResult;
        if (tryResume_1(cont, onCancellation))
          return 0;
        $this.m19_1 = get_NO_RESULT();
        return 2;
      }
    } else {
      var tmp_0;
      if (equals(curState, get_STATE_COMPLETED())) {
        tmp_0 = true;
      } else {
        tmp_0 = curState instanceof ClauseData;
      }
      if (tmp_0)
        return 3;
      else {
        if (equals(curState, get_STATE_CANCELLED()))
          return 2;
        else {
          if (equals(curState, get_STATE_REG())) {
            if ($this.k19_1.atomicfu$compareAndSet(curState, listOf_0(clauseObject)))
              return 1;
          } else {
            if (isInterface(curState, KtList)) {
              if ($this.k19_1.atomicfu$compareAndSet(curState, plus_0(curState, clauseObject)))
                return 1;
            } else {
              // Inline function 'kotlin.error' call
              var message = 'Unexpected state: ' + toString(curState);
              throw IllegalStateException.t4(toString(message));
            }
          }
        }
      }
    }
  }
}
function findClause($this, clauseObject) {
  var tmp0_elvis_lhs = $this.l19_1;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return null;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var clauses = tmp;
  // Inline function 'kotlin.collections.find' call
  var tmp$ret$1;
  $l$block: {
    // Inline function 'kotlin.collections.firstOrNull' call
    var _iterator__ex2g4s = clauses.y();
    while (_iterator__ex2g4s.z()) {
      var element = _iterator__ex2g4s.a1();
      if (element.m1h_1 === clauseObject) {
        tmp$ret$1 = element;
        break $l$block;
      }
    }
    tmp$ret$1 = null;
  }
  var tmp1_elvis_lhs = tmp$ret$1;
  var tmp_0;
  if (tmp1_elvis_lhs == null) {
    var message = 'Clause with object ' + toString(clauseObject) + ' is not found';
    throw IllegalStateException.t4(toString(message));
  } else {
    tmp_0 = tmp1_elvis_lhs;
  }
  return tmp_0;
}
var TrySelectDetailedResult_SUCCESSFUL_instance;
var TrySelectDetailedResult_REREGISTER_instance;
var TrySelectDetailedResult_CANCELLED_instance;
var TrySelectDetailedResult_ALREADY_SELECTED_instance;
var TrySelectDetailedResult_entriesInitialized;
function TrySelectDetailedResult_initEntries() {
  if (TrySelectDetailedResult_entriesInitialized)
    return Unit_instance;
  TrySelectDetailedResult_entriesInitialized = true;
  TrySelectDetailedResult_SUCCESSFUL_instance = new TrySelectDetailedResult('SUCCESSFUL', 0);
  TrySelectDetailedResult_REREGISTER_instance = new TrySelectDetailedResult('REREGISTER', 1);
  TrySelectDetailedResult_CANCELLED_instance = new TrySelectDetailedResult('CANCELLED', 2);
  TrySelectDetailedResult_ALREADY_SELECTED_instance = new TrySelectDetailedResult('ALREADY_SELECTED', 3);
}
function TrySelectDetailedResult_0(trySelectInternalResult) {
  _init_properties_Select_kt__zhm2jg();
  var tmp;
  switch (trySelectInternalResult) {
    case 0:
      tmp = TrySelectDetailedResult_SUCCESSFUL_getInstance();
      break;
    case 1:
      tmp = TrySelectDetailedResult_REREGISTER_getInstance();
      break;
    case 2:
      tmp = TrySelectDetailedResult_CANCELLED_getInstance();
      break;
    case 3:
      tmp = TrySelectDetailedResult_ALREADY_SELECTED_getInstance();
      break;
    default:
      var message = 'Unexpected internal result: ' + trySelectInternalResult;
      throw IllegalStateException.t4(toString(message));
  }
  return tmp;
}
function tryResume_1(_this__u8e3s4, onCancellation) {
  _init_properties_Select_kt__zhm2jg();
  var tmp0_elvis_lhs = _this__u8e3s4.cz(Unit_instance, null, onCancellation);
  var tmp;
  if (tmp0_elvis_lhs == null) {
    return false;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  var token = tmp;
  _this__u8e3s4.ix(token);
  return true;
}
function DUMMY_PROCESS_RESULT_FUNCTION$lambda(_unused_var__etf5q3, _unused_var__etf5q3_0, _unused_var__etf5q3_1) {
  _init_properties_Select_kt__zhm2jg();
  return null;
}
function TrySelectDetailedResult_SUCCESSFUL_getInstance() {
  TrySelectDetailedResult_initEntries();
  return TrySelectDetailedResult_SUCCESSFUL_instance;
}
function TrySelectDetailedResult_REREGISTER_getInstance() {
  TrySelectDetailedResult_initEntries();
  return TrySelectDetailedResult_REREGISTER_instance;
}
function TrySelectDetailedResult_CANCELLED_getInstance() {
  TrySelectDetailedResult_initEntries();
  return TrySelectDetailedResult_CANCELLED_instance;
}
function TrySelectDetailedResult_ALREADY_SELECTED_getInstance() {
  TrySelectDetailedResult_initEntries();
  return TrySelectDetailedResult_ALREADY_SELECTED_instance;
}
var properties_initialized_Select_kt_7rpl36;
function _init_properties_Select_kt__zhm2jg() {
  if (!properties_initialized_Select_kt_7rpl36) {
    properties_initialized_Select_kt_7rpl36 = true;
    DUMMY_PROCESS_RESULT_FUNCTION = DUMMY_PROCESS_RESULT_FUNCTION$lambda;
    STATE_REG = new Symbol('STATE_REG');
    STATE_COMPLETED = new Symbol('STATE_COMPLETED');
    STATE_CANCELLED = new Symbol('STATE_CANCELLED');
    NO_RESULT = new Symbol('NO_RESULT');
    PARAM_CLAUSE_0 = new Symbol('PARAM_CLAUSE_0');
  }
}
function get_NO_OWNER() {
  _init_properties_Mutex_kt__jod56b();
  return NO_OWNER;
}
var NO_OWNER;
var ON_LOCK_ALREADY_LOCKED_BY_OWNER;
function Mutex(locked) {
  locked = locked === VOID ? false : locked;
  _init_properties_Mutex_kt__jod56b();
  return new MutexImpl(locked);
}
function MutexImpl$CancellableContinuationWithOwner$tryResume$lambda(this$0, this$1) {
  return (_unused_var__etf5q3, _unused_var__etf5q3_0, _unused_var__etf5q3_1) => {
    // Inline function 'kotlinx.coroutines.assert' call
    this$0.x1h_1.kotlinx$atomicfu$value = this$1.a1i_1;
    this$0.c1i(this$1.a1i_1);
    return Unit_instance;
  };
}
function MutexImpl$CancellableContinuationWithOwner$resume$lambda(this$0, this$1) {
  return (it) => {
    this$0.c1i(this$1.a1i_1);
    return Unit_instance;
  };
}
function holdsLockImpl($this, owner) {
  $l$loop: while (true) {
    if (!$this.d1i())
      return 0;
    var curOwner = $this.x1h_1.kotlinx$atomicfu$value;
    if (curOwner === get_NO_OWNER())
      continue $l$loop;
    return curOwner === owner ? 1 : 2;
  }
}
function *_generator_lock__qllepv($this, owner, $completion) {
  if ($this.e1i(owner))
    return Unit_instance;
  var tmp = lockSuspend($this, owner, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function lockSuspend($this, owner, $completion) {
  var cancellable = getOrCreateCancellableContinuation(intercepted($completion));
  try {
    var contWithOwner = new CancellableContinuationWithOwner($this, cancellable, owner);
    $this.acquireCont(contWithOwner);
  } catch ($p) {
    if ($p instanceof Error) {
      var e = $p;
      cancellable.u10();
      throw e;
    } else {
      throw $p;
    }
  }
  return cancellable.cy();
}
function tryLockImpl($this, owner) {
  $l$loop: while (true) {
    if ($this.m1i()) {
      // Inline function 'kotlinx.coroutines.assert' call
      $this.x1h_1.kotlinx$atomicfu$value = owner;
      return 0;
    } else {
      if (owner == null)
        return 1;
      switch (holdsLockImpl($this, owner)) {
        case 1:
          return 2;
        case 2:
          return 1;
        case 0:
          continue $l$loop;
      }
    }
  }
}
function MutexImpl$onSelectCancellationUnlockConstructor$lambda$lambda(this$0, $owner) {
  return (_unused_var__etf5q3, _unused_var__etf5q3_0, _unused_var__etf5q3_1) => {
    this$0.c1i($owner);
    return Unit_instance;
  };
}
function MutexImpl$onSelectCancellationUnlockConstructor$lambda(this$0) {
  return (_unused_var__etf5q3, owner, _unused_var__etf5q3_0) => MutexImpl$onSelectCancellationUnlockConstructor$lambda$lambda(this$0, owner);
}
var properties_initialized_Mutex_kt_yv4p3j;
function _init_properties_Mutex_kt__jod56b() {
  if (!properties_initialized_Mutex_kt_yv4p3j) {
    properties_initialized_Mutex_kt_yv4p3j = true;
    NO_OWNER = new Symbol('NO_OWNER');
    ON_LOCK_ALREADY_LOCKED_BY_OWNER = new Symbol('ALREADY_LOCKED_BY_OWNER');
  }
}
function get_MAX_SPIN_CYCLES() {
  _init_properties_Semaphore_kt__t514r6();
  return MAX_SPIN_CYCLES;
}
var MAX_SPIN_CYCLES;
function get_PERMIT() {
  _init_properties_Semaphore_kt__t514r6();
  return PERMIT;
}
var PERMIT;
function get_TAKEN() {
  _init_properties_Semaphore_kt__t514r6();
  return TAKEN;
}
var TAKEN;
function get_BROKEN() {
  _init_properties_Semaphore_kt__t514r6();
  return BROKEN;
}
var BROKEN;
function get_CANCELLED() {
  _init_properties_Semaphore_kt__t514r6();
  return CANCELLED;
}
var CANCELLED;
function get_SEGMENT_SIZE_0() {
  _init_properties_Semaphore_kt__t514r6();
  return SEGMENT_SIZE_0;
}
var SEGMENT_SIZE_0;
function decPermits($this) {
  $l$loop: while (true) {
    var p = $this.k1i_1.atomicfu$getAndDecrement();
    if (p > $this.f1i_1)
      continue $l$loop;
    return p;
  }
}
function coerceAvailablePermitsAtMaximum($this) {
  $l$loop_0: while (true) {
    var cur = $this.k1i_1.kotlinx$atomicfu$value;
    if (cur <= $this.f1i_1)
      break $l$loop_0;
    if ($this.k1i_1.atomicfu$compareAndSet(cur, $this.f1i_1))
      break $l$loop_0;
  }
}
function addAcquireToQueue($this, waiter) {
  var curTail = $this.i1i_1.kotlinx$atomicfu$value;
  var enqIdx = $this.j1i_1.atomicfu$getAndIncrement$long();
  var createNewSegment = createSegment$ref_0();
  var tmp2 = $this.i1i_1;
  // Inline function 'kotlin.Long.div' call
  var other = get_SEGMENT_SIZE_0();
  var tmp3 = enqIdx.x3(toLong(other));
  var tmp$ret$3;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    while (true) {
      var s = findSegmentInternal(curTail, tmp3, createNewSegment);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp1 = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
        var tmp$ret$1;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          while (true) {
            var cur = tmp2.kotlinx$atomicfu$value;
            if (cur.vz_1.s1(tmp1.vz_1) >= 0) {
              tmp$ret$1 = true;
              break $l$block_1;
            }
            if (!tmp1.j18()) {
              tmp$ret$1 = false;
              break $l$block_1;
            }
            if (tmp2.atomicfu$compareAndSet(cur, tmp1)) {
              if (cur.k18()) {
                cur.e6();
              }
              tmp$ret$1 = true;
              break $l$block_1;
            }
            if (tmp1.k18()) {
              tmp1.e6();
            }
          }
          tmp$ret$1 = Unit_instance;
        }
        tmp = tmp$ret$1;
      }
      if (tmp) {
        tmp$ret$3 = s;
        break $l$block_2;
      }
    }
  }
  var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(tmp$ret$3);
  // Inline function 'kotlin.Long.rem' call
  var other_0 = get_SEGMENT_SIZE_0();
  var i = enqIdx.y3(toLong(other_0)).x1();
  // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.cas' call
  if (segment.x1i_1.atomicfu$get(i).atomicfu$compareAndSet(null, waiter)) {
    waiter.a11(segment, i);
    return true;
  }
  var tmp14 = get_PERMIT();
  // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.cas' call
  var value = get_TAKEN();
  if (segment.x1i_1.atomicfu$get(i).atomicfu$compareAndSet(tmp14, value)) {
    if (isInterface(waiter, CancellableContinuation)) {
      if (!isInterface(waiter, CancellableContinuation))
        THROW_CCE();
      waiter.fz(Unit_instance, $this.l1i_1);
    } else {
      if (isInterface(waiter, SelectInstance)) {
        waiter.l1h(Unit_instance);
      } else {
        // Inline function 'kotlin.error' call
        var message = 'unexpected: ' + toString(waiter);
        throw IllegalStateException.t4(toString(message));
      }
    }
    return true;
  }
  // Inline function 'kotlinx.coroutines.assert' call
  return false;
}
function tryResumeNextFromQueue($this) {
  var curHead = $this.g1i_1.kotlinx$atomicfu$value;
  var deqIdx = $this.h1i_1.atomicfu$getAndIncrement$long();
  // Inline function 'kotlin.Long.div' call
  var other = get_SEGMENT_SIZE_0();
  var id = deqIdx.x3(toLong(other));
  var createNewSegment = createSegment$ref_1();
  var tmp2 = $this.g1i_1;
  var tmp$ret$3;
  $l$block_2: {
    // Inline function 'kotlinx.coroutines.internal.findSegmentAndMoveForward' call
    while (true) {
      var s = findSegmentInternal(curHead, id, createNewSegment);
      var tmp;
      if (_SegmentOrClosed___get_isClosed__impl__qmxmlo(s)) {
        tmp = true;
      } else {
        var tmp1 = _SegmentOrClosed___get_segment__impl__jvcr9l(s);
        var tmp$ret$1;
        $l$block_1: {
          // Inline function 'kotlinx.coroutines.internal.moveForward' call
          while (true) {
            var cur = tmp2.kotlinx$atomicfu$value;
            if (cur.vz_1.s1(tmp1.vz_1) >= 0) {
              tmp$ret$1 = true;
              break $l$block_1;
            }
            if (!tmp1.j18()) {
              tmp$ret$1 = false;
              break $l$block_1;
            }
            if (tmp2.atomicfu$compareAndSet(cur, tmp1)) {
              if (cur.k18()) {
                cur.e6();
              }
              tmp$ret$1 = true;
              break $l$block_1;
            }
            if (tmp1.k18()) {
              tmp1.e6();
            }
          }
          tmp$ret$1 = Unit_instance;
        }
        tmp = tmp$ret$1;
      }
      if (tmp) {
        tmp$ret$3 = s;
        break $l$block_2;
      }
    }
  }
  var segment = _SegmentOrClosed___get_segment__impl__jvcr9l(tmp$ret$3);
  segment.r18();
  if (segment.vz_1.s1(id) > 0)
    return false;
  // Inline function 'kotlin.Long.rem' call
  var other_0 = get_SEGMENT_SIZE_0();
  var i = deqIdx.y3(toLong(other_0)).x1();
  // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.getAndSet' call
  var value = get_PERMIT();
  var cellState = segment.x1i_1.atomicfu$get(i).atomicfu$getAndSet(value);
  if (cellState === null) {
    // Inline function 'kotlin.repeat' call
    var times = get_MAX_SPIN_CYCLES();
    var inductionVariable = 0;
    if (inductionVariable < times)
      do {
        var index = inductionVariable;
        inductionVariable = inductionVariable + 1 | 0;
        // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.get' call
        if (segment.x1i_1.atomicfu$get(i).kotlinx$atomicfu$value === get_TAKEN())
          return true;
      }
       while (inductionVariable < times);
    var tmp15 = get_PERMIT();
    // Inline function 'kotlinx.coroutines.sync.SemaphoreSegment.cas' call
    var value_0 = get_BROKEN();
    return !segment.x1i_1.atomicfu$get(i).atomicfu$compareAndSet(tmp15, value_0);
  } else if (cellState === get_CANCELLED())
    return false;
  else
    return tryResumeAcquire($this, cellState);
}
function tryResumeAcquire($this, _this__u8e3s4) {
  var tmp;
  if (isInterface(_this__u8e3s4, CancellableContinuation)) {
    if (!isInterface(_this__u8e3s4, CancellableContinuation))
      THROW_CCE();
    var token = _this__u8e3s4.cz(Unit_instance, null, $this.l1i_1);
    var tmp_0;
    if (!(token == null)) {
      _this__u8e3s4.ix(token);
      tmp_0 = true;
    } else {
      tmp_0 = false;
    }
    tmp = tmp_0;
  } else {
    if (isInterface(_this__u8e3s4, SelectInstance)) {
      tmp = _this__u8e3s4.h19($this, Unit_instance);
    } else {
      var message = 'unexpected: ' + toString(_this__u8e3s4);
      throw IllegalStateException.t4(toString(message));
    }
  }
  return tmp;
}
function SemaphoreAndMutexImpl$onCancellationRelease$lambda(this$0) {
  return (_unused_var__etf5q3, _unused_var__etf5q3_0, _unused_var__etf5q3_1) => {
    this$0.s1i();
    return Unit_instance;
  };
}
function createSegment$ref_0() {
  var l = (p0, p1) => createSegment_0(p0, p1);
  l.callableName = 'createSegment';
  return l;
}
function createSegment$ref_1() {
  var l = (p0, p1) => createSegment_0(p0, p1);
  l.callableName = 'createSegment';
  return l;
}
function createSegment_0(id, prev) {
  _init_properties_Semaphore_kt__t514r6();
  return new SemaphoreSegment(id, prev, 0);
}
var properties_initialized_Semaphore_kt_uqcwok;
function _init_properties_Semaphore_kt__t514r6() {
  if (!properties_initialized_Semaphore_kt_uqcwok) {
    properties_initialized_Semaphore_kt_uqcwok = true;
    MAX_SPIN_CYCLES = systemProp('kotlinx.coroutines.semaphore.maxSpinCycles', 100);
    PERMIT = new Symbol('PERMIT');
    TAKEN = new Symbol('TAKEN');
    BROKEN = new Symbol('BROKEN');
    CANCELLED = new Symbol('CANCELLED');
    SEGMENT_SIZE_0 = systemProp('kotlinx.coroutines.semaphore.segmentSize', 16);
  }
}
function createDefaultDispatcher() {
  var tmp;
  if (isJsdom()) {
    tmp = NodeDispatcher_getInstance();
  } else {
    var tmp_0;
    var tmp_1;
    if (!(typeof window === 'undefined')) {
      // Inline function 'kotlin.js.asDynamic' call
      tmp_1 = window != null;
    } else {
      tmp_1 = false;
    }
    if (tmp_1) {
      // Inline function 'kotlin.js.asDynamic' call
      tmp_0 = !(typeof window.addEventListener === 'undefined');
    } else {
      tmp_0 = false;
    }
    if (tmp_0) {
      tmp = asCoroutineDispatcher(window);
    } else {
      if (typeof process === 'undefined' || typeof process.nextTick === 'undefined') {
        tmp = SetTimeoutDispatcher_getInstance();
      } else {
        tmp = NodeDispatcher_getInstance();
      }
    }
  }
  return tmp;
}
function isJsdom() {
  return !(typeof navigator === 'undefined') && navigator != null && navigator.userAgent != null && !(typeof navigator.userAgent === 'undefined') && !(typeof navigator.userAgent.match === 'undefined') && navigator.userAgent.match('\\bjsdom\\b');
}
var counter;
function get_DEBUG() {
  return DEBUG;
}
var DEBUG;
function get_classSimpleName(_this__u8e3s4) {
  var tmp0_elvis_lhs = getKClassFromExpression(_this__u8e3s4).hf();
  return tmp0_elvis_lhs == null ? 'Unknown' : tmp0_elvis_lhs;
}
function get_hexAddress(_this__u8e3s4) {
  // Inline function 'kotlin.js.asDynamic' call
  var result = _this__u8e3s4.__debug_counter;
  if (!(typeof result === 'number')) {
    counter = counter + 1 | 0;
    result = counter;
    // Inline function 'kotlin.js.asDynamic' call
    _this__u8e3s4.__debug_counter = result;
  }
  return ((!(result == null) ? typeof result === 'number' : false) ? result : THROW_CCE()).toString();
}
var NodeDispatcher_instance;
function NodeDispatcher_getInstance() {
  if (NodeDispatcher_instance === VOID)
    new NodeDispatcher();
  return NodeDispatcher_instance;
}
function ScheduledMessageQueue$processQueue$lambda(this$0) {
  return () => {
    this$0.l1j();
    return Unit_instance;
  };
}
function w3cSetTimeout(handler, timeout) {
  return setTimeout(handler, timeout);
}
function WindowMessageQueue$lambda(this$0) {
  return (event) => {
    var tmp;
    if (event.source == this$0.c1k_1 && event.data == this$0.d1k_1) {
      event.stopPropagation();
      this$0.l1j();
      tmp = Unit_instance;
    }
    return Unit_instance;
  };
}
function WindowMessageQueue$schedule$lambda(this$0) {
  return (it) => {
    this$0.l1j();
    return Unit_instance;
  };
}
function w3cSetTimeout_0(window_0, handler, timeout) {
  return setTimeout_0(window_0, handler, timeout);
}
function w3cClearTimeout(window_0, handle) {
  return window_0.clearTimeout(handle);
}
function w3cClearTimeout_0(handle) {
  return clearTimeout(handle);
}
function setTimeout_0(window_0, handler, timeout) {
  return window_0.setTimeout(handler, timeout);
}
function await_0(_this__u8e3s4, $completion) {
  var cancellable = new CancellableContinuationImpl(intercepted($completion), 1);
  cancellable.by();
  var tmp = await$lambda(cancellable);
  _this__u8e3s4.then(tmp, await$lambda_0(cancellable));
  return cancellable.cy();
}
function promise(_this__u8e3s4, context, start, block) {
  context = context === VOID ? EmptyCoroutineContext_getInstance() : context;
  start = start === VOID ? CoroutineStart_DEFAULT_getInstance() : start;
  return asPromise(async(_this__u8e3s4, context, start, block));
}
function asPromise(_this__u8e3s4) {
  var promise = new Promise(asPromise$lambda(_this__u8e3s4));
  // Inline function 'kotlin.js.asDynamic' call
  promise.deferred = _this__u8e3s4;
  return promise;
}
function await$lambda($cont) {
  return (it) => {
    // Inline function 'kotlin.coroutines.resume' call
    var this_0 = $cont;
    // Inline function 'kotlin.Companion.success' call
    var tmp$ret$0 = _Result___init__impl__xyqfz8(it);
    this_0.nc(tmp$ret$0);
    return Unit_instance;
  };
}
function await$lambda_0($cont) {
  return (it) => {
    var tmp0 = $cont;
    var tmp0_elvis_lhs = it instanceof Error ? it : null;
    // Inline function 'kotlin.coroutines.resumeWithException' call
    // Inline function 'kotlin.Companion.failure' call
    var exception = tmp0_elvis_lhs == null ? Exception.l5('Non-Kotlin exception ' + it.toString()) : tmp0_elvis_lhs;
    var tmp$ret$0 = _Result___init__impl__xyqfz8(createFailure(exception));
    tmp0.nc(tmp$ret$0);
    return Unit_instance;
  };
}
function asPromise$lambda$lambda($this_asPromise, $reject, $resolve) {
  return (it) => {
    var e = $this_asPromise.jw();
    var tmp;
    if (!(e == null)) {
      tmp = $reject(e);
    } else {
      tmp = $resolve($this_asPromise.gx());
    }
    return Unit_instance;
  };
}
function asPromise$lambda($this_asPromise) {
  return (resolve, reject) => {
    $this_asPromise.nv(asPromise$lambda$lambda($this_asPromise, reject, resolve));
    return Unit_instance;
  };
}
function asCoroutineDispatcher(_this__u8e3s4) {
  // Inline function 'kotlin.js.asDynamic' call
  var tmp0_elvis_lhs = _this__u8e3s4.coroutineDispatcher;
  var tmp;
  if (tmp0_elvis_lhs == null) {
    // Inline function 'kotlin.also' call
    var this_0 = new WindowDispatcher(_this__u8e3s4);
    // Inline function 'kotlin.js.asDynamic' call
    _this__u8e3s4.coroutineDispatcher = this_0;
    tmp = this_0;
  } else {
    tmp = tmp0_elvis_lhs;
  }
  return tmp;
}
function propagateExceptionFinalResort(exception) {
  console.error(exception.toString());
}
function createEventLoop() {
  return new UnconfinedEventLoop();
}
function unsupported() {
  throw UnsupportedOperationException.da('runBlocking event loop is not supported');
}
var SetTimeoutDispatcher_instance;
function SetTimeoutDispatcher_getInstance() {
  if (SetTimeoutDispatcher_instance === VOID)
    new SetTimeoutDispatcher();
  return SetTimeoutDispatcher_instance;
}
function SetTimeoutBasedDispatcher$invokeOnTimeout$lambda($block) {
  return () => {
    $block.h11();
    return Unit_instance;
  };
}
function SetTimeoutBasedDispatcher$scheduleResumeAfterDelay$lambda($continuation, this$0) {
  return () => {
    // Inline function 'kotlin.with' call
    $continuation.ez(this$0, Unit_instance);
    return Unit_instance;
  };
}
function WindowDispatcher$scheduleResumeAfterDelay$lambda($continuation, this$0) {
  return () => {
    // Inline function 'kotlin.with' call
    $continuation.ez(this$0, Unit_instance);
    return Unit_instance;
  };
}
function Runnable$run$ref($boundThis) {
  var l = () => {
    $boundThis.h11();
    return Unit_instance;
  };
  l.callableName = 'run';
  return l;
}
function delayToInt(timeMillis) {
  return coerceIn(timeMillis, new Long(0, 0), new Long(2147483647, 0)).x1();
}
function toDebugString(_this__u8e3s4) {
  return toString(_this__u8e3s4);
}
function get_DefaultDelay() {
  var tmp = Dispatchers_getInstance().d16_1;
  return isInterface(tmp, Delay) ? tmp : THROW_CCE();
}
function newCoroutineContext(_this__u8e3s4, context) {
  var combined = _this__u8e3s4.ku().dn(context);
  return !(combined === Dispatchers_getInstance().d16_1) && combined.yc(Key_instance) == null ? combined.dn(Dispatchers_getInstance().d16_1) : combined;
}
function newCoroutineContext_0(_this__u8e3s4, addedContext) {
  return _this__u8e3s4.dn(addedContext);
}
function get_coroutineName(_this__u8e3s4) {
  return null;
}
var Dispatchers_instance;
function Dispatchers_getInstance() {
  if (Dispatchers_instance === VOID)
    new Dispatchers();
  return Dispatchers_instance;
}
function CancellationException_0(message, cause) {
  return CancellationException.od(message, cause);
}
function *_generator_emit__qph46j_1($this, value, $completion) {
  // Inline function 'kotlinx.coroutines.currentCoroutineContext' call
  // Inline function 'kotlin.js.getCoroutineContext' call
  var currentContext = $completion.lc();
  ensureActive(currentContext);
  if (!($this.t1c_1 === currentContext)) {
    checkContext($this, currentContext);
    $this.t1c_1 = currentContext;
  }
  var tmp = $this.q1c_1.p1c(value, $completion);
  if (tmp === get_COROUTINE_SUSPENDED())
    tmp = yield tmp;
  return Unit_instance;
}
function SafeCollector$collectContextSize$lambda(count, _unused_var__etf5q3) {
  return count + 1 | 0;
}
function identitySet(expectedSize) {
  return HashSet.e1(expectedSize);
}
function get_platformExceptionHandlers_() {
  _init_properties_CoroutineExceptionHandlerImpl_kt__37d7wf();
  return platformExceptionHandlers_;
}
var platformExceptionHandlers_;
function get_platformExceptionHandlers() {
  _init_properties_CoroutineExceptionHandlerImpl_kt__37d7wf();
  return get_platformExceptionHandlers_();
}
var properties_initialized_CoroutineExceptionHandlerImpl_kt_qhrgvx;
function _init_properties_CoroutineExceptionHandlerImpl_kt__37d7wf() {
  if (!properties_initialized_CoroutineExceptionHandlerImpl_kt_qhrgvx) {
    properties_initialized_CoroutineExceptionHandlerImpl_kt_qhrgvx = true;
    // Inline function 'kotlin.collections.mutableSetOf' call
    platformExceptionHandlers_ = LinkedHashSet.g1();
  }
}
function unwrap(exception) {
  return exception;
}
function initCause(_this__u8e3s4, cause) {
}
function recoverStackTrace(exception, continuation) {
  return exception;
}
function recoverStackTrace_0(exception) {
  return exception;
}
function systemProp_1(propertyName) {
  return null;
}
function threadContextElements(context) {
  return 0;
}
function commonThreadLocal(name) {
  return new CommonThreadLocal();
}
//region block: post-declaration
initMetadataForInterface(Job, 'Job', VOID, VOID, [Element], [0]);
initMetadataForInterface(ParentJob, 'ParentJob', VOID, VOID, [Job], [0]);
protoOf(JobSupport).pv = invokeOnCompletion$default;
protoOf(JobSupport).vv = cancel$default;
protoOf(JobSupport).dn = plus;
protoOf(JobSupport).yc = get_0;
protoOf(JobSupport).cn = fold;
protoOf(JobSupport).bn = minusKey_0;
initMetadataForClass(JobSupport, 'JobSupport', VOID, VOID, [Job, ParentJob], [0]);
initMetadataForInterface(CoroutineScope, 'CoroutineScope');
initMetadataForClass(AbstractCoroutine, 'AbstractCoroutine', VOID, VOID, [JobSupport, Job, Continuation, CoroutineScope], [0]);
initMetadataForInterface(NotCompleted, 'NotCompleted');
initMetadataForInterface(CancelHandler, 'CancelHandler', VOID, VOID, [NotCompleted]);
initMetadataForClass(DisposeHandlersOnCancel, 'DisposeHandlersOnCancel', VOID, VOID, [CancelHandler]);
initMetadataForClass(LockFreeLinkedListNode, 'LockFreeLinkedListNode', LockFreeLinkedListNode);
initMetadataForInterface(Incomplete, 'Incomplete');
initMetadataForClass(JobNode, 'JobNode', VOID, VOID, [LockFreeLinkedListNode, Incomplete]);
initMetadataForClass(AwaitAllNode, 'AwaitAllNode');
initMetadataForClass(AwaitAll, 'AwaitAll', VOID, VOID, VOID, [0]);
initMetadataForClass(StandaloneCoroutine, 'StandaloneCoroutine', VOID, VOID, VOID, [0]);
initMetadataForClass(LazyStandaloneCoroutine, 'LazyStandaloneCoroutine', VOID, VOID, VOID, [0]);
initMetadataForClass(ScopeCoroutine, 'ScopeCoroutine', VOID, VOID, VOID, [0]);
initMetadataForClass(DispatchedCoroutine, 'DispatchedCoroutine', VOID, VOID, VOID, [0]);
initMetadataForClass(DeferredCoroutine, 'DeferredCoroutine', VOID, VOID, [AbstractCoroutine, Job], [0]);
initMetadataForClass(LazyDeferredCoroutine, 'LazyDeferredCoroutine', VOID, VOID, VOID, [0]);
initMetadataForInterface(CancellableContinuation, 'CancellableContinuation', VOID, VOID, [Continuation]);
initMetadataForClass(DisposeOnCancel, 'DisposeOnCancel', VOID, VOID, [CancelHandler]);
initMetadataForInterface(Runnable, 'Runnable');
initMetadataForClass(SchedulerTask, 'SchedulerTask', VOID, VOID, [Runnable]);
initMetadataForClass(DispatchedTask, 'DispatchedTask');
initMetadataForInterface(Waiter, 'Waiter');
initMetadataForClass(CancellableContinuationImpl, 'CancellableContinuationImpl', VOID, VOID, [DispatchedTask, CancellableContinuation, Waiter]);
initMetadataForClass(UserSupplied, 'UserSupplied', VOID, VOID, [CancelHandler]);
initMetadataForObject(Active, 'Active', VOID, VOID, [NotCompleted]);
initMetadataForClass(CompletedContinuation, 'CompletedContinuation');
initMetadataForClass(ChildContinuation, 'ChildContinuation');
initMetadataForClass(CompletableDeferredImpl, 'CompletableDeferredImpl', VOID, VOID, [JobSupport, Job], [0]);
initMetadataForInterface(CompletableJob, 'CompletableJob', VOID, VOID, [Job], [0]);
initMetadataForClass(CompletedExceptionally, 'CompletedExceptionally');
initMetadataForClass(CancelledContinuation, 'CancelledContinuation');
initMetadataForObject(Key, 'Key');
protoOf(CoroutineDispatcher).yc = get;
protoOf(CoroutineDispatcher).bn = minusKey;
initMetadataForClass(CoroutineDispatcher, 'CoroutineDispatcher', VOID, VOID, [AbstractCoroutineContextElement, ContinuationInterceptor]);
initMetadataForObject(Key_0, 'Key');
initMetadataForObject(Key_1, 'Key');
initMetadataForClass(CoroutineName, 'CoroutineName');
initMetadataForObject(GlobalScope, 'GlobalScope', VOID, VOID, [CoroutineScope]);
initMetadataForClass(CoroutineStart, 'CoroutineStart');
initMetadataForInterface(CopyableThrowable, 'CopyableThrowable');
initMetadataForInterface(Delay, 'Delay', VOID, VOID, VOID, [1]);
initMetadataForInterface(DelayWithTimeoutDiagnostics, 'DelayWithTimeoutDiagnostics', VOID, VOID, [Delay], [1]);
initMetadataForClass(EventLoop, 'EventLoop');
initMetadataForObject(ThreadLocalEventLoop, 'ThreadLocalEventLoop');
initMetadataForClass(CompletionHandlerException, 'CompletionHandlerException');
initMetadataForClass(CoroutinesInternalError, 'CoroutinesInternalError');
initMetadataForObject(Key_2, 'Key');
initMetadataForObject(NonDisposableHandle, 'NonDisposableHandle');
initMetadataForClass(DisposeOnCompletion, 'DisposeOnCompletion');
initMetadataForClass(Empty, 'Empty', VOID, VOID, [Incomplete]);
initMetadataForClass(LockFreeLinkedListHead, 'LockFreeLinkedListHead', LockFreeLinkedListHead);
initMetadataForClass(NodeList, 'NodeList', NodeList, VOID, [LockFreeLinkedListHead, Incomplete]);
initMetadataForClass(SynchronizedObject, 'SynchronizedObject', SynchronizedObject);
initMetadataForClass(Finishing, 'Finishing', VOID, VOID, [SynchronizedObject, Incomplete]);
initMetadataForClass(ChildCompletion, 'ChildCompletion');
initMetadataForClass(AwaitContinuation, 'AwaitContinuation');
initMetadataForClass(InactiveNodeList, 'InactiveNodeList', VOID, VOID, [Incomplete]);
initMetadataForClass(InvokeOnCompletion, 'InvokeOnCompletion');
initMetadataForClass(InvokeOnCancelling, 'InvokeOnCancelling');
initMetadataForClass(ResumeOnCompletion, 'ResumeOnCompletion');
initMetadataForClass(ChildHandleNode, 'ChildHandleNode');
initMetadataForClass(ResumeAwaitOnCompletion, 'ResumeAwaitOnCompletion');
initMetadataForClass(IncompleteStateBox, 'IncompleteStateBox');
initMetadataForClass(JobImpl, 'JobImpl', VOID, VOID, [JobSupport, CompletableJob], [0]);
initMetadataForClass(MainCoroutineDispatcher, 'MainCoroutineDispatcher');
protoOf(NonCancellable).pv = invokeOnCompletion$default;
protoOf(NonCancellable).vv = cancel$default;
initMetadataForObject(NonCancellable, 'NonCancellable', VOID, VOID, [AbstractCoroutineContextElement, Job], [0]);
initMetadataForClass(SupervisorJobImpl, 'SupervisorJobImpl', VOID, VOID, VOID, [0]);
initMetadataForClass(TimeoutCancellationException, 'TimeoutCancellationException', VOID, VOID, [CancellationException, CopyableThrowable]);
initMetadataForClass(TimeoutCoroutine, 'TimeoutCoroutine', VOID, VOID, [ScopeCoroutine, Runnable], [0]);
initMetadataForObject(Unconfined, 'Unconfined');
initMetadataForObject(Key_3, 'Key');
initMetadataForClass(BufferOverflow, 'BufferOverflow');
initMetadataForClass(ConcurrentLinkedListNode, 'ConcurrentLinkedListNode');
initMetadataForClass(Segment, 'Segment', VOID, VOID, [ConcurrentLinkedListNode, NotCompleted]);
initMetadataForClass(ChannelSegment, 'ChannelSegment');
initMetadataForClass(SendBroadcast, 'SendBroadcast', VOID, VOID, [Waiter]);
initMetadataForClass(BufferedChannelIterator, 'BufferedChannelIterator', VOID, VOID, [Waiter], [0, 3]);
initMetadataForInterface(SendChannel, 'SendChannel', VOID, VOID, VOID, [1]);
initMetadataForInterface(ReceiveChannel, 'ReceiveChannel', VOID, VOID, VOID, [0]);
protoOf(BufferedChannel).p1a = close$default;
protoOf(BufferedChannel).r1a = cancel$default_0;
initMetadataForClass(BufferedChannel, 'BufferedChannel', VOID, VOID, [SendChannel, ReceiveChannel], [1, 4, 0, 3]);
initMetadataForClass(WaiterEB, 'WaiterEB');
initMetadataForClass(ReceiveCatching, 'ReceiveCatching', VOID, VOID, [Waiter]);
initMetadataForObject(Factory, 'Factory');
initMetadataForClass(Failed, 'Failed', Failed);
initMetadataForClass(Closed, 'Closed');
initMetadataForCompanion(Companion);
initMetadataForClass(ChannelResult, 'ChannelResult');
initMetadataForClass(ClosedSendChannelException, 'ClosedSendChannelException');
initMetadataForClass(ClosedReceiveChannelException, 'ClosedReceiveChannelException');
protoOf(ChannelCoroutine).p1a = close$default;
initMetadataForClass(ChannelCoroutine, 'ChannelCoroutine', VOID, VOID, [AbstractCoroutine, SendChannel, ReceiveChannel], [1, 0]);
initMetadataForClass(ConflatedBufferedChannel, 'ConflatedBufferedChannel', VOID, VOID, VOID, [1, 0]);
initMetadataForInterface(ProducerScope, 'ProducerScope', VOID, VOID, [CoroutineScope, SendChannel], [1]);
initMetadataForClass(ProducerCoroutine, 'ProducerCoroutine', VOID, VOID, [ChannelCoroutine, ProducerScope], [1, 0]);
initMetadataForInterface(Flow, 'Flow', VOID, VOID, VOID, [1]);
initMetadataForClass(AbstractFlow, 'AbstractFlow', VOID, VOID, [Flow], [1]);
initMetadataForClass(SafeFlow, 'SafeFlow', VOID, VOID, VOID, [1]);
initMetadataForInterface(FusibleFlow, 'FusibleFlow', VOID, VOID, [Flow], [1]);
protoOf(ChannelFlow).m1c = fuse$default;
initMetadataForClass(ChannelFlow, 'ChannelFlow', VOID, VOID, [FusibleFlow], [1]);
initMetadataForClass(ChannelFlowBuilder, 'ChannelFlowBuilder', VOID, VOID, VOID, [1]);
initMetadataForInterface(FlowCollector, 'FlowCollector', VOID, VOID, VOID, [1]);
initMetadataForClass(Emitter, 'Emitter');
initMetadataForClass(AbstractSharedFlow, 'AbstractSharedFlow');
protoOf(SharedFlowImpl).m1c = fuse$default;
initMetadataForClass(SharedFlowImpl, 'SharedFlowImpl', VOID, VOID, [AbstractSharedFlow, FlowCollector, Flow, FusibleFlow], [1]);
initMetadataForClass(AbstractSharedFlowSlot, 'AbstractSharedFlowSlot');
initMetadataForClass(SharedFlowSlot, 'SharedFlowSlot', SharedFlowSlot);
protoOf(StateFlowImpl).m1c = fuse$default;
initMetadataForClass(StateFlowImpl, 'StateFlowImpl', VOID, VOID, [AbstractSharedFlow, FlowCollector, Flow, FusibleFlow], [1]);
initMetadataForClass(StateFlowSlot, 'StateFlowSlot', StateFlowSlot, VOID, VOID, [0]);
initMetadataForClass(ChannelFlowOperator, 'ChannelFlowOperator', VOID, VOID, VOID, [1, 2]);
initMetadataForClass(ChannelFlowOperatorImpl, 'ChannelFlowOperatorImpl', VOID, VOID, VOID, [1]);
initMetadataForLambda(ChannelFlow$_get_collectToFun_$slambda_j53z2e, VOID, VOID, [1]);
initMetadataForLambda(ChannelFlow$collect$slambda, VOID, VOID, [1]);
initMetadataForLambda(ChannelFlowOperator$collectWithContextUndispatched$slambda, VOID, VOID, [1]);
initMetadataForLambda(UndispatchedContextCollector$emitRef$slambda, VOID, VOID, [1]);
initMetadataForClass(UndispatchedContextCollector, 'UndispatchedContextCollector', VOID, VOID, [FlowCollector], [1]);
initMetadataForClass(StackFrameContinuation, 'StackFrameContinuation', VOID, VOID, [Continuation]);
initMetadataForObject(NopCollector, 'NopCollector', VOID, VOID, [FlowCollector], [1]);
initMetadataForClass(SendingCollector, 'SendingCollector', VOID, VOID, [FlowCollector], [1]);
initMetadataForClass(ThrowingCollector, 'ThrowingCollector', VOID, VOID, [FlowCollector], [1]);
initMetadataForClass(SubscribedFlowCollector, 'SubscribedFlowCollector', VOID, VOID, [FlowCollector], [0, 1]);
protoOf(ReadonlySharedFlow).m1c = fuse$default;
initMetadataForClass(ReadonlySharedFlow, 'ReadonlySharedFlow', VOID, VOID, [Flow, FusibleFlow], [1]);
protoOf(ReadonlyStateFlow).m1c = fuse$default;
initMetadataForClass(ReadonlyStateFlow, 'ReadonlyStateFlow', VOID, VOID, [Flow, FusibleFlow], [1]);
initMetadataForClass(first$$inlined$collectWhile$1, VOID, VOID, VOID, [FlowCollector], [1]);
initMetadataForClass(firstOrNull$$inlined$collectWhile$1, VOID, VOID, VOID, [FlowCollector], [1]);
initMetadataForClass(first$$inlined$collectWhile$2, VOID, VOID, VOID, [FlowCollector], [1]);
initMetadataForClass(SegmentOrClosed, 'SegmentOrClosed');
initMetadataForObject(ExceptionSuccessfullyProcessed, 'ExceptionSuccessfullyProcessed');
initMetadataForClass(DispatchedContinuation, 'DispatchedContinuation', VOID, VOID, [DispatchedTask, Continuation]);
initMetadataForClass(DispatchException, 'DispatchException');
initMetadataForClass(UndeliveredElementException, 'UndeliveredElementException');
initMetadataForClass(ContextScope, 'ContextScope', VOID, VOID, [CoroutineScope]);
initMetadataForClass(Symbol, 'Symbol');
initMetadataForInterface(SelectInstance, 'SelectInstance');
initMetadataForClass(ClauseData, 'ClauseData', VOID, VOID, VOID, [1]);
initMetadataForClass(SelectImplementation, 'SelectImplementation', VOID, VOID, [CancelHandler, SelectInstance, Waiter], [0, 2]);
initMetadataForClass(TrySelectDetailedResult, 'TrySelectDetailedResult');
initMetadataForClass(CancellableContinuationWithOwner, 'CancellableContinuationWithOwner', VOID, VOID, [CancellableContinuation, Waiter]);
initMetadataForClass(SemaphoreAndMutexImpl, 'SemaphoreAndMutexImpl', VOID, VOID, VOID, [0]);
initMetadataForClass(MutexImpl, 'MutexImpl', VOID, VOID, VOID, [1, 0]);
initMetadataForClass(SemaphoreSegment, 'SemaphoreSegment');
initMetadataForClass(SetTimeoutBasedDispatcher, 'SetTimeoutBasedDispatcher', VOID, VOID, [CoroutineDispatcher, Delay], [1]);
initMetadataForObject(NodeDispatcher, 'NodeDispatcher', VOID, VOID, VOID, [1]);
initMetadataForClass(MessageQueue, 'MessageQueue', VOID, VOID, [KtMutableList]);
initMetadataForClass(ScheduledMessageQueue, 'ScheduledMessageQueue');
initMetadataForClass(WindowMessageQueue, 'WindowMessageQueue');
initMetadataForClass(UnconfinedEventLoop, 'UnconfinedEventLoop', UnconfinedEventLoop);
initMetadataForObject(SetTimeoutDispatcher, 'SetTimeoutDispatcher', VOID, VOID, VOID, [1]);
initMetadataForClass(ClearTimeout, 'ClearTimeout', VOID, VOID, [CancelHandler]);
initMetadataForClass(WindowClearTimeout, 'WindowClearTimeout');
initMetadataForClass(WindowDispatcher, 'WindowDispatcher', VOID, VOID, [CoroutineDispatcher, Delay], [1]);
initMetadataForClass(UndispatchedCoroutine, 'UndispatchedCoroutine', VOID, VOID, VOID, [0]);
initMetadataForObject(Dispatchers, 'Dispatchers');
initMetadataForClass(JsMainDispatcher, 'JsMainDispatcher');
initMetadataForClass(JobCancellationException, 'JobCancellationException');
initMetadataForClass(AbortFlowException, 'AbortFlowException');
initMetadataForClass(SafeCollector, 'SafeCollector', VOID, VOID, [FlowCollector], [1]);
initMetadataForClass(WorkaroundAtomicReference, 'WorkaroundAtomicReference');
initMetadataForClass(DiagnosticCoroutineContextException, 'DiagnosticCoroutineContextException');
initMetadataForClass(ListClosed, 'ListClosed');
initMetadataForClass(CommonThreadLocal, 'CommonThreadLocal', CommonThreadLocal);
//endregion
//region block: init
Active_instance = new Active();
Key_instance_1 = new Key_0();
Key_instance_2 = new Key_1();
GlobalScope_instance = new GlobalScope();
Key_instance_3 = new Key_2();
NonDisposableHandle_instance = new NonDisposableHandle();
Key_instance_4 = new Key_3();
counter = 0;
DEBUG = false;
//endregion
//region block: exports
export {
  CoroutineStart_LAZY_getInstance as CoroutineStart_LAZY_getInstance1py9n0s9t79vw,
  emitAll_0 as emitAllzzmeew3d68ub,
  firstOrNull as firstOrNull12rzggh6e86lb,
  first_0 as first1bt0pe0qnx8f4,
  first as firstm7c7rh2w8aro,
  awaitAll as awaitAlls867ch610czr,
  await_0 as await3mtczq8ld88gb,
  cancelAndJoin as cancelAndJoinca5q7i6o6enf,
  coroutineScope as coroutineScope327xjtgzh1k2v,
  delay as delay1mo3xq8p6x68f,
  delay_0 as delay1gna29w5m8r2h,
  joinAll as joinAll1exxrn3zbq8yl,
  withContext as withContext7utithjmd2zo,
  withTimeoutOrNull as withTimeoutOrNull30gvkflmp8gj3,
  withTimeoutOrNull_0 as withTimeoutOrNull1s5mig5vy28xr,
  withTimeout as withTimeoutbx36s8h1ezlh,
  withTimeout_0 as withTimeoutma886m9gez3y,
  Key_instance_1 as Key_instancexdagtxajq561,
  Dispatchers_getInstance as Dispatchers_getInstance1nk2l7rcqz5wi,
  GlobalScope_instance as GlobalScope_instance3rq364dcgnf9q,
  Key_instance_3 as Key_instance3o7pj7ik1b183,
  NonCancellable_getInstance as NonCancellable_getInstance1ugmverrxjd6t,
  Channel as Channel3r72atmcithql,
  ProducerScope as ProducerScopeb3mmhvfa6ll7,
  cancelConsumed as cancelConsumed2i0oizqhmljf6,
  produce as produce1iljho2c8bp6o,
  FlowCollector as FlowCollector26clgpmzihvke,
  Flow as Flow3375h4584bu3w,
  MutableSharedFlow as MutableSharedFlow3g4w4npzofx4w,
  MutableStateFlow as MutableStateFlow34bfoyvwu8czu,
  asSharedFlow as asSharedFlow2buz3fbrowsyg,
  asStateFlow as asStateFlow34rribx643ke5,
  buffer as buffer2o7vhreze5nfc,
  channelFlow as channelFlow1or0c85tk04v1,
  flow as flow3tazazxj2t7g4,
  recoverStackTrace as recoverStackTrace2i3si2i8nvw1k,
  startCoroutineCancellable_1 as startCoroutineCancellable18shtfwdieib,
  Mutex as Mutex16li1l0asjv17,
  CancellableContinuationImpl as CancellableContinuationImpl1cx201opicavg,
  CancellationException_0 as CancellationExceptionjngvjj221x3v,
  CompletableDeferred as CompletableDeferred2lnqvsbvx74d3,
  CompletableJob as CompletableJob1w6swnu15iclo,
  CopyableThrowable as CopyableThrowable1mvc99jcyvivf,
  CoroutineName as CoroutineName2g5zosw74tf0f,
  CoroutineScope_0 as CoroutineScopelux7s7zphw7e,
  CoroutineScope as CoroutineScopefcb5f5dwqcas,
  Job_0 as Job13y4jkazwjho0,
  SupervisorJob as SupervisorJobythnfxkr3jxc,
  TimeoutCancellationException as TimeoutCancellationException198b5zwr3v3uw,
  async as asyncz02dsa2nb2zt,
  cancel_0 as cancel36mj9lv3a0whl,
  cancel_2 as cancel2en0dn4yvpufo,
  cancel as cancel2ztysw4v4hav6,
  cancel_1 as cancel1xim2hrvjmwpn,
  ensureActive as ensureActive2yo7199srjlgl,
  get_isActive as get_isActive3hyjjajobpa4m,
  get_job as get_job2zvlvce9o9a29,
  launch as launch1c91vkjzdi9sd,
  promise as promise1ky6tawqaxbt4,
};
//endregion

//# sourceMappingURL=kotlinx-coroutines-core.mjs.map
